"""Application entry point for exact caller-owned Lua, outside Operation Plans."""

from pathlib import Path

from spa.contracts.caller_script import (
    ScriptRunRequest,
    ScriptRunResult,
    ScriptSuccessDiagnostics,
)
from spa.contracts.operation import RUNTIME_FAILURE_CODES, OperationDescriptor
from spa.contracts.ports import OperationServices
from spa.contracts.public import RuntimeRequirements


def run_script(
    request: ScriptRunRequest, services: OperationServices
) -> ScriptRunResult:
    if services.invoke_script is None:
        raise RuntimeError("Caller-script adapter is not configured")
    if services.observe_script_file is None:
        raise RuntimeError("Caller-script File Adapter is not configured")
    observed = services.invoke_script(services.probe_runtime(request), request)
    return ScriptRunResult(
        executable=observed.executable,
        working_directory=observed.working_directory,
        timeout_seconds=request.timeout_seconds,
        output_limit_bytes=observed.output_limit_bytes,
        diagnostics=ScriptSuccessDiagnostics.model_validate(
            observed.diagnostics.model_dump()
        ),
        files=[
            services.observe_script_file(Path(observed.working_directory) / path)
            for path in request.declared_files
        ],
    )


SCRIPT_OPERATIONS = (
    OperationDescriptor(
        "script run",
        ScriptRunRequest,
        ScriptRunResult,
        run_script,
        lambda result: (
            f"Caller script process exited with status {result.diagnostics.exit_status}"
        ),
        RuntimeRequirements(
            lua_language="Lua 5.4",
            minimum_api_version=41,
            required_capabilities=["aseprite_runtime_introspection"],
        ),
        RUNTIME_FAILURE_CODES,
        execution_kind="script-run",
        determinism="caller-defined",
        side_effects=("caller-defined",),
        help_summary="Run caller-owned Lua and report process outcomes and declared files.",
    ),
)
