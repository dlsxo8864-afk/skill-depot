"""Aseprite Runtime Integration adapter."""
