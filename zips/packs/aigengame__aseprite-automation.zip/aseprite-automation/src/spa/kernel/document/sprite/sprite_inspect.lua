-- Shared fixed inspection semantics for packaged Sprite handlers.
local module = {}
local layer_selection =
  dofile(assert(app.params.layer_select, "Missing Kernel resource: layer_select"))
local slice_inspection =
  dofile(assert(app.params.slice_inspect, "Missing Kernel resource: slice_inspect"))
local json_null = json.decode("null")

local function rgba(color)
  return {
    red = color.red,
    green = color.green,
    blue = color.blue,
    alpha = color.alpha,
  }
end

local function rectangle(value)
  return { x = value.x, y = value.y, width = value.width, height = value.height }
end

local function point(value) return { x = value.x, y = value.y } end

local function size(value) return { width = value.width, height = value.height } end

local function color_mode(value)
  if value == ColorMode.RGB then return "rgb" end
  if value == ColorMode.GRAY then return "grayscale" end
  if value == ColorMode.INDEXED then return "indexed" end
  error("unsupported Sprite Color Mode")
end

local blend_modes = {
  { BlendMode.NORMAL, "normal" },
  { BlendMode.MULTIPLY, "multiply" },
  { BlendMode.SCREEN, "screen" },
  { BlendMode.OVERLAY, "overlay" },
  { BlendMode.DARKEN, "darken" },
  { BlendMode.LIGHTEN, "lighten" },
  { BlendMode.COLOR_DODGE, "color_dodge" },
  { BlendMode.COLOR_BURN, "color_burn" },
  { BlendMode.HARD_LIGHT, "hard_light" },
  { BlendMode.SOFT_LIGHT, "soft_light" },
  { BlendMode.DIFFERENCE, "difference" },
  { BlendMode.EXCLUSION, "exclusion" },
  { BlendMode.HSL_HUE, "hsl_hue" },
  { BlendMode.HSL_SATURATION, "hsl_saturation" },
  { BlendMode.HSL_COLOR, "hsl_color" },
  { BlendMode.HSL_LUMINOSITY, "hsl_luminosity" },
  { BlendMode.ADDITION, "addition" },
  { BlendMode.SUBTRACT, "subtract" },
  { BlendMode.DIVIDE, "divide" },
}

local function blend_mode(value)
  for _, item in ipairs(blend_modes) do
    if value == item[1] then return item[2] end
  end
  return "unknown_" .. tostring(value)
end

function module.blend_mode_constant(name)
  for _, item in ipairs(blend_modes) do
    if name == item[2] then return item[1] end
  end
  return nil
end

local function tag_direction(value)
  if value == AniDir.FORWARD then return "forward" end
  if value == AniDir.REVERSE then return "reverse" end
  if value == AniDir.PING_PONG then return "ping_pong" end
  if value == AniDir.PING_PONG_REVERSE then return "ping_pong_reverse" end
  error("unsupported Tag Animation Direction")
end

local function copy_path(path, index)
  local result = {}
  for i, value in ipairs(path) do
    result[i] = value
  end
  result[#result + 1] = index
  return result
end

local function path_key(path) return table.concat(path, "/") end

local function verified_layer_uuids(left, right, prefix, verified)
  for index = 1, math.min(#left, #right) do
    local layer = left[index]
    local other = right[index]
    local path = copy_path(prefix, index)
    if layer.name == other.name and layer.isGroup == other.isGroup then
      local uuid = tostring(layer.uuid)
      if uuid == tostring(other.uuid) then verified[path_key(path)] = uuid end
      if layer.isGroup then verified_layer_uuids(layer.layers, other.layers, path, verified) end
    end
  end
end

function module.persisted_layer_uuids(sprite, other)
  local verified = {}
  if sprite.useLayerUuids and other.useLayerUuids then
    verified_layer_uuids(sprite.layers, other.layers, {}, verified)
  end
  return verified
end

function module.saved_layer_uuids(sprite, path)
  if not sprite.useLayerUuids then return {} end
  local previous = {
    sprite = app.activeSprite,
    layer = app.activeLayer,
    frame = app.activeFrame,
  }
  local other = assert(app.open(path), "could not reopen Sprite for UUID verification")
  local ok, verified = pcall(module.persisted_layer_uuids, sprite, other)
  other:close()
  if previous.sprite ~= nil and previous.sprite.isValid then
    pcall(function() app.activeSprite = previous.sprite end)
    pcall(function() app.activeLayer = previous.layer end)
    pcall(function() app.activeFrame = previous.frame end)
  end
  if not ok then error(verified) end
  return verified
end

local function inspect_layers(layers, parent_path, paths, counts, verified_uuids)
  local result = {}
  for index = 1, #layers do
    local layer = layers[index]
    local path = copy_path(parent_path, index)
    paths[layer] = path
    counts.layers = counts.layers + 1
    local children = {}
    if layer.isGroup then
      children = inspect_layers(layer.layers, path, paths, counts, verified_uuids)
    end
    result[#result + 1] = {
      path = path,
      name = layer.name,
      layer_uuid = verified_uuids[path_key(path)] or json_null,
      opacity = layer.opacity == nil and json_null or layer.opacity,
      blend_mode = layer.blendMode == nil and json_null or blend_mode(layer.blendMode),
      is_image = layer.isImage,
      is_group = layer.isGroup,
      is_tilemap = layer.isTilemap,
      is_reference = layer.isReference,
      is_visible = layer.isVisible,
      is_editable = layer.isEditable,
      is_continuous = layer.isContinuous,
      is_collapsed = layer.isCollapsed,
      is_transparent = layer.isTransparent,
      is_background = layer.isBackground,
      children = children,
    }
  end
  return result
end

local function requested_set(scope)
  local result = {}
  for index = 1, #scope do
    result[scope[index]] = true
  end
  return result
end

function module.inspect(sprite, scope, verified_uuids)
  local requested = requested_set(scope)
  local paths = {}
  local counts = { layers = 0 }
  local all_layers = inspect_layers(sprite.layers, {}, paths, counts, verified_uuids or {})
  local result = {
    metadata = {
      width = sprite.width,
      height = sprite.height,
      color_mode = color_mode(sprite.colorMode),
      frame_count = #sprite.frames,
      tag_count = #sprite.tags,
      palette_count = #sprite.palettes,
      layer_count = counts.layers,
      cel_count = #sprite.cels,
      slice_count = #sprite.slices,
      tileset_count = #sprite.tilesets,
      transparent_color_index = sprite.transparentColor,
      grid_bounds = rectangle(sprite.gridBounds),
      pixel_ratio = size(sprite.pixelRatio),
      use_layer_uuids = sprite.useLayerUuids,
    },
    frames = json_null,
    tags = json_null,
    palettes = json_null,
    layers = json_null,
    cels = json_null,
    slices = json_null,
    tilesets = json_null,
  }

  if requested.frames then
    local frames = {}
    for index = 1, #sprite.frames do
      local frame = sprite.frames[index]
      frames[#frames + 1] = {
        frame_number = frame.frameNumber,
        duration_ms = math.floor(frame.duration * 1000 + 0.5),
      }
    end
    result.frames = frames
  end

  if requested.tags then
    local tags = {}
    for index = 1, #sprite.tags do
      local tag = sprite.tags[index]
      tags[#tags + 1] = {
        name = tag.name,
        from_frame = tag.fromFrame.frameNumber,
        to_frame = tag.toFrame.frameNumber,
        direction = tag_direction(tag.aniDir),
        repeats = tag.repeats,
        color = rgba(tag.color),
      }
    end
    result.tags = tags
  end

  if requested.palettes then
    local palettes = {}
    for palette_index = 1, #sprite.palettes do
      local palette = sprite.palettes[palette_index]
      local entries = {}
      for index = 0, #palette - 1 do
        entries[#entries + 1] = { index = index, color = rgba(palette:getColor(index)) }
      end
      palettes[#palettes + 1] = {
        frame_number = palette.frame.frameNumber,
        entries = entries,
      }
    end
    result.palettes = palettes
  end

  if requested.layers then result.layers = all_layers end

  if requested.cels then
    local cels = {}
    for index = 1, #sprite.cels do
      local cel = sprite.cels[index]
      cels[#cels + 1] = {
        layer_path = layer_selection.current_path(sprite, cel.layer),
        frame_number = cel.frameNumber,
        bounds = rectangle(cel.bounds),
        opacity = cel.opacity,
        z_index = cel.zIndex,
      }
    end
    result.cels = cels
  end

  if requested.slices then result.slices = slice_inspection.inspect(sprite) end

  if requested.tilesets then
    local tilesets = {}
    for index = 1, #sprite.tilesets do
      local tileset = sprite.tilesets[index]
      tilesets[#tilesets + 1] = {
        name = tileset.name,
        tile_count = #tileset,
        base_index = tileset.baseIndex,
        grid_origin = point(tileset.grid.origin),
        tile_size = size(tileset.grid.tileSize),
      }
    end
    result.tilesets = tilesets
  end

  return result
end

return module
