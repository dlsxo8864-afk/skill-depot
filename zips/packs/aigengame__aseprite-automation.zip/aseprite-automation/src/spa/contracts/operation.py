"""Shared Operation Descriptor mechanics at the application-contract boundary."""

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from typing import get_args

from pydantic import BaseModel

from spa.contracts.ports import OperationServices
from spa.contracts.public import (
    ExecutionKind,
    FailureCodeSpec,
    OperationDeterminism,
    OperationSchema,
    RuntimeRequest,
    RuntimeRequirements,
    failure_schema,
    validate_operation_determinism,
)
from spa.contracts.schema import CompactJsonSchema

COMMON_CLI_FLAGS = {
    "input_json": "--input-json",
    "schema": "--schema",
    "json_output": "--json",
    "human": "--human",
}
RUNTIME_CLI_FLAGS = {
    "aseprite": "--aseprite",
    "timeout_seconds": "--timeout-seconds",
}
ACCESS_FAILURE_CODES = ("invalid_request",)
RUNTIME_FAILURE_CODES = (
    "invalid_request",
    "executable_not_found",
    "resource_incomplete",
    "process_start_failed",
    "process_timeout",
    "output_limit_exceeded",
    "process_failed",
    "kernel_response_missing",
    "kernel_response_invalid",
    "kernel_execution_failed",
    "runtime_incompatible",
)


@dataclass(frozen=True)
class OperationDescriptor[RequestT: BaseModel, ResultT: BaseModel]:
    name: str
    request_type: type[RequestT]
    result_type: type[ResultT]
    execute: Callable[[RequestT, OperationServices], ResultT]
    render_human: Callable[[ResultT], str]
    runtime_requirements: RuntimeRequirements | None
    failure_codes: tuple[str, ...]
    execution_kind: ExecutionKind = "read"
    determinism: OperationDeterminism = "deterministic"
    side_effects: tuple[str, ...] = ()
    plan_eligible: bool = False
    probe_before_execute: bool = True
    help_summary: str = field(kw_only=True)

    def __post_init__(self) -> None:
        validate_operation_determinism(self.execution_kind, self.determinism)
        if (self.name == "script run") != (self.execution_kind == "script-run"):
            raise ValueError("script run is the only caller-owned execution identity")
        if self.execution_kind == "script-run" and self.plan_eligible:
            raise ValueError("Caller scripts cannot be Operation Plan Steps")
        command = f"spa {self.name}"
        operation_field = self.result_type.model_fields.get("operation")
        if (
            operation_field is None
            or get_args(operation_field.annotation) != (command,)
            or (
                not operation_field.is_required() and operation_field.default != command
            )
        ):
            raise ValueError(f"Result Operation identity does not match {command}")
        if self.runtime_requirements is not None and not issubclass(
            self.request_type, RuntimeRequest
        ):
            raise ValueError(
                f"Runtime Operation Request must extend RuntimeRequest: {command}"
            )
        if (
            self.runtime_requirements is not None
            and "runtime_incompatible" not in self.failure_codes
        ):
            raise ValueError(
                f"Runtime Operation must declare runtime_incompatible: {command}"
            )

    @property
    def cli_flags(self) -> dict[str, str]:
        return COMMON_CLI_FLAGS | (RUNTIME_CLI_FLAGS if self.requires_runtime else {})

    @property
    def requires_runtime(self) -> bool:
        return self.runtime_requirements is not None

    def schema(self, failure_codes: Mapping[str, FailureCodeSpec]) -> OperationSchema:
        command = f"spa {self.name}"
        return OperationSchema(
            operation=command,
            help_summary=self.help_summary,
            execution_kind=self.execution_kind,
            determinism=self.determinism,
            side_effects=list(self.side_effects),
            requires_runtime=self.requires_runtime,
            plan_eligible=self.plan_eligible,
            runtime_requirements=self.runtime_requirements,
            request_schema=self.request_type.model_json_schema(
                schema_generator=CompactJsonSchema
            ),
            result_schema=self.result_type.model_json_schema(
                schema_generator=CompactJsonSchema
            ),
            failure_schema=failure_schema(self.failure_codes, command, failure_codes),
            invocation_schema={
                "$schema": "https://json-schema.org/draft/2020-12/schema",
                "type": "object",
                "properties": {
                    "command": {"const": command},
                    "input_json": {
                        "type": "string",
                        "description": "JSON object matching request_schema, or '-' to read that object from stdin.",
                    },
                    "schema": {"type": "boolean"},
                    "json_output": {"type": "boolean"},
                    "human": {"type": "boolean"},
                },
                "required": ["command"],
                "additionalProperties": False,
                "x-cli-flags": self.cli_flags,
            },
        )
