"""Access Projection tests."""
