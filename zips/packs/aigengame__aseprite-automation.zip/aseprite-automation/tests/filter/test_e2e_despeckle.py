"""Native Despeckle through the public Filter surface."""

import pytest

from tests.filter.support import FIXTURES, observe_images, pixels
from tests.native_invocation import expect_success, run, run_lua
from tests.support import process_diagnostics

pytestmark = pytest.mark.e2e


def pixel_input(mode="rgb", **options):
    selected = pixels(mode, **options)
    del selected["kind"]
    return selected


def apply(source, target, selected, width=3, height=1, tiled_mode="none", **intent):
    """Run `spa filter despeckle` and return `(returncode, envelope)`.

    This adds the Source and Target fields, `in_place` and `overwrite` from
    intent (default False), and the window and tiled mode defaults.
    """
    outcome = run(
        "filter despeckle",
        {
            "source_sprite_file": str(source),
            "target_sprite_file": str(target),
            "in_place": intent.pop("in_place", False),
            "overwrite": intent.pop("overwrite", False),
            "pixels": selected,
            "width": width,
            "height": height,
            "tiled_mode": tiled_mode,
            **intent,
        },
    )
    return outcome.returncode, outcome.envelope


def test_despeckle_uses_native_median_and_verifies_persistence(tmp_path, runtime):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(FIXTURES / "source.lua", runtime, source=source, mode="grayscale")
    assert lua.returncode == 0, process_diagnostics(lua)
    original = source.read_bytes()
    code, result = apply(source, target, pixel_input("grayscale"))
    assert code == 0, result
    assert result["anchor"] == {"x": 1, "y": 0}
    assert result["sample_count"] == 3
    assert result["persisted_reopen_verified"] is True
    assert result["processed_image_numbers"] == [1]
    assert result["changed"] is True
    observed = observe_images(runtime, target)
    assert [value & 255 for value in observed["cels"][0]["pixels"]] == [100, 100, 40]
    assert source.read_bytes() == original


def channel_sets(names):
    from itertools import combinations

    return [
        list(combo)
        for size in range(1, len(names) + 1)
        for combo in combinations(names, size)
    ]


RGB_SETS = channel_sets(["red", "green", "blue", "alpha"])
GRAY_SETS = channel_sets(["gray", "alpha"])
INDEXED_SETS = [names for names in RGB_SETS if "green" in names]
FLAGS = {"red": 1, "green": 2, "blue": 4, "alpha": 8, "gray": 16}


@pytest.mark.parametrize(
    "mode,names",
    [("rgb", n) for n in RGB_SETS]
    + [("grayscale", n) for n in GRAY_SETS]
    + [("indexed", n) for n in INDEXED_SETS]
    + [("indexed", [])],
)
def test_every_channel_branch_matches_independent_native_command(
    tmp_path, runtime, mode, names
):
    source, target, baseline = [
        tmp_path / name
        for name in ("source.aseprite", "target.aseprite", "native.aseprite")
    ]
    lua = run_lua(FIXTURES / "despeckle_source.lua", runtime, source=source, mode=mode)
    assert lua.returncode == 0, process_diagnostics(lua)
    flags = sum(FLAGS[name] for name in names) if names else 32
    lua = run_lua(
        FIXTURES / "despeckle_native_baseline.lua",
        runtime,
        source=source,
        target=baseline,
        channels=flags,
        width=3,
        height=1,
        tiled_mode="none",
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    channels = {"kind": "components", "names": names} if names else {"kind": "index"}
    selected = pixel_input(mode, channels=channels)
    if mode == "indexed":
        selected["palette_frame_number"] = 1
    code, result = apply(source, target, selected)
    assert code == 0, result
    before, after = observe_images(runtime, source), observe_images(runtime, target)
    assert after == observe_images(runtime, baseline)
    assert after["palette"] == before["palette"]
    assert result["channels"] == channels
    assert result["persisted_reopen_verified"] is True
    if names:
        pixel = after["cels"][0]["pixels"][1]
        components = (
            after["palette"][pixel]
            if mode == "indexed"
            else [
                (pixel >> (8 * index)) & 255
                for index in range(2 if mode == "grayscale" else 4)
            ]
        )
        labels = (
            ["gray", "alpha"]
            if mode == "grayscale"
            else ["red", "green", "blue", "alpha"]
        )
        original = [200, 60] if mode == "grayscale" else [200, 40, 100, 60]
        median = [100, 128] if mode == "grayscale" else [100, 100, 100, 128]
        assert components == [
            median[i] if name in names else original[i] for i, name in enumerate(labels)
        ]


@pytest.mark.parametrize(
    "width,height", [(2, 2), (3, 3), (100, 1), (1, 100), (100, 100)]
)
@pytest.mark.parametrize("tiled_mode", ["none", "x", "y", "both"])
def test_windows_and_edges_match_native(tmp_path, runtime, width, height, tiled_mode):
    source, target, baseline = [
        tmp_path / name
        for name in ("source.aseprite", "target.aseprite", "native.aseprite")
    ]
    lua = run_lua(
        FIXTURES / "despeckle_source.lua",
        runtime,
        source=source,
        mode="grayscale",
        grid="true",
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    lua = run_lua(
        FIXTURES / "despeckle_native_baseline.lua",
        runtime,
        source=source,
        target=baseline,
        channels=16,
        width=width,
        height=height,
        tiled_mode=tiled_mode,
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    code, result = apply(
        source, target, pixel_input("grayscale"), width, height, tiled_mode
    )
    assert code == 0, result
    assert result["anchor"] == {"x": width // 2, "y": height // 2}
    assert result["sample_count"] == width * height
    after = observe_images(runtime, target)
    assert after == observe_images(runtime, baseline)
    # Independent acceptance oracle: upper median, repeat/wrap at each Image edge.
    original = [p & 255 for p in observe_images(runtime, source)["cels"][0]["pixels"]]

    def coordinate(value, tiled):
        return value % 3 if tiled else min(2, max(0, value))

    expected = []
    for y in range(3):
        for x in range(3):
            samples = [
                original[
                    coordinate(y + dy - height // 2, tiled_mode in ("y", "both")) * 3
                    + coordinate(x + dx - width // 2, tiled_mode in ("x", "both"))
                ]
                for dy in range(height)
                for dx in range(width)
            ]
            expected.append(sorted(samples)[len(samples) // 2])
    actual = [p & 255 for p in after["cels"][0]["pixels"]]
    if width == 100 and height == 1 and tiled_mode in ("none", "y"):
        # Native 1.3.18.5 advances getx while its address waits at the left edge.
        # The owner accepted native output; do not implement ideal clamping in SPA.
        assert actual == [100] * 3 + [200] * 3 + [40] * 3
        assert actual != expected
    else:
        assert actual == expected


@pytest.mark.parametrize("mode", ["rgb", "grayscale", "indexed"])
def test_one_by_one_reports_native_unchanged_pixels(tmp_path, runtime, mode):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(FIXTURES / "despeckle_source.lua", runtime, source=source, mode=mode)
    assert lua.returncode == 0, process_diagnostics(lua)
    selected = pixel_input(mode)
    if mode == "indexed":
        selected.update(channels={"kind": "index"}, palette_frame_number=1)
    code, result = apply(source, target, selected, 1, 1)
    assert code == 0, result
    assert result["changed"] is False
    assert result["processed_image_numbers"] == [1]
    assert observe_images(runtime, target) == observe_images(runtime, source)


@pytest.mark.parametrize(
    "index,components,expected", [(1, False, 1), (1, True, 2), (2, True, 2)]
)
def test_one_by_one_keeps_native_rgb_map_outcome(
    tmp_path, runtime, index, components, expected
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(
        FIXTURES / "despeckle_source.lua",
        runtime,
        source=source,
        mode="indexed",
        duplicate="true",
        index=index,
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    channels = (
        {"kind": "components", "names": ["red", "green", "blue", "alpha"]}
        if components
        else {"kind": "index"}
    )
    code, result = apply(
        source,
        target,
        pixel_input("indexed", palette_frame_number=1, channels=channels),
        1,
        1,
    )
    assert code == 0, result
    assert result["changed"] == (index != expected)
    assert result["processed_image_numbers"] == [1]
    assert observe_images(runtime, target)["cels"][0]["pixels"] == [expected]
    assert result["palette_before"] == result["palette_after"]


@pytest.mark.parametrize("names", [n for n in RGB_SETS if "green" not in n])
def test_defective_indexed_channels_refuse_without_publishing(tmp_path, runtime, names):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(
        FIXTURES / "despeckle_source.lua", runtime, source=source, mode="indexed"
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    original = source.read_bytes()
    target.write_bytes(b"keep existing target")
    code, result = apply(
        source,
        target,
        pixel_input(
            "indexed",
            palette_frame_number=1,
            channels={"kind": "components", "names": names},
        ),
        overwrite=True,
    )
    assert code != 0 and result["code"] == "filter_unsupported_document", result
    assert "Green" in result["message"]
    assert result["message"] == result["details"]["reason"]
    info = expect_success("info", {})
    gap = next(
        gap
        for gap in info["capability_gaps"]
        if gap["capability"] == "spa filter despeckle: Indexed components without Green"
    )
    assert result["message"] == gap["reason"]
    assert (
        source.read_bytes() == original
        and target.read_bytes() == b"keep existing target"
    )


# test_e2e_filter_refusals.py holds the RGB row with the exact reason.
@pytest.mark.parametrize("mode", ["grayscale", "indexed"])
def test_background_alpha_refuses_whole_request(tmp_path, runtime, mode):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(
        FIXTURES / "despeckle_source.lua",
        runtime,
        source=source,
        mode=mode,
        background="true",
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    selected = pixel_input(
        mode,
        channels={
            "kind": "components",
            "names": ["gray", "alpha"] if mode == "grayscale" else ["green", "alpha"],
        },
    )
    if mode == "indexed":
        selected["palette_frame_number"] = 1
    original = source.read_bytes()
    code, result = apply(source, target, selected)
    assert code != 0 and result["code"] == "filter_unsupported_document", result
    assert "Background" in result["message"]
    assert not target.exists() and source.read_bytes() == original


@pytest.mark.parametrize(
    "selection",
    [
        {"kind": "empty"},
        {"kind": "all", "rectangle": {"x": 1, "y": 0, "width": 1, "height": 1}},
    ],
)
def test_explicit_selection_and_linked_target(tmp_path, runtime, selection):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(
        FIXTURES / "despeckle_source.lua",
        runtime,
        source=source,
        mode="grayscale",
        linked="true",
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    before = observe_images(runtime, source)
    code, result = apply(source, target, pixel_input("grayscale", selection=selection))
    assert code == 0, result
    assert result["processed_image_numbers"] == [1]
    assert {cel["frame_number"] for cel in result["affected_cels"]} == {1, 2}
    assert len(result["existing_target_cels"]) == 1
    after = observe_images(runtime, target)
    expected = [100, 100, 40] if selection["kind"] != "empty" else [100, 200, 40]
    assert len(after["cels"]) == 2
    for cel in after["cels"]:
        assert [p & 255 for p in cel["pixels"]] == expected
    assert after["palette"] == before["palette"]


@pytest.mark.parametrize(
    "selection, expected, values",
    [
        (
            None,
            {"kind": "all", "rectangle": {"x": 0, "y": 0, "width": 3, "height": 1}},
            [100, 100, 40],
        ),
        (
            {"kind": "all", "rectangle": {"x": -1, "y": 0, "width": 3, "height": 1}},
            {"kind": "all", "rectangle": {"x": 0, "y": 0, "width": 2, "height": 1}},
            [100, 100, 40],
        ),
        (
            {"kind": "all", "rectangle": {"x": -3, "y": 0, "width": 1, "height": 1}},
            {"kind": "empty"},
            [100, 200, 40],
        ),
        (
            {
                "kind": "mask",
                "bounds": {"x": -1, "y": 0, "width": 3, "height": 1},
                "rows": [
                    {"y": 0, "runs": [{"x": -1, "length": 1}, {"x": 1, "length": 1}]}
                ],
            },
            {"kind": "all", "rectangle": {"x": 1, "y": 0, "width": 1, "height": 1}},
            [100, 100, 40],
        ),
        (
            {"kind": "all", "rectangle": {"x": 0, "y": 0, "width": 1, "height": 1}},
            {"kind": "all", "rectangle": {"x": 0, "y": 0, "width": 1, "height": 1}},
            [100, 200, 40],
        ),
        (
            {
                "kind": "mask",
                "bounds": {"x": 0, "y": 0, "width": 3, "height": 1},
                "rows": [
                    {"y": 0, "runs": [{"x": 0, "length": 1}, {"x": 2, "length": 1}]}
                ],
            },
            {
                "kind": "mask",
                "bounds": {"x": 0, "y": 0, "width": 3, "height": 1},
                "rows": [
                    {"y": 0, "runs": [{"x": 0, "length": 1}, {"x": 2, "length": 1}]}
                ],
            },
            [100, 200, 40],
        ),
    ],
    ids=[
        "omitted",
        "clipped-rectangle",
        "outside-canvas",
        "mask-normalized-to-all",
        "origin-retained",
        "mask-hole-retained",
    ],
)
def test_native_selection_normalization_and_named_target_remain_valid(
    tmp_path, runtime, selection, expected, values
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(FIXTURES / "source.lua", runtime, source=source, mode="grayscale")
    assert lua.returncode == 0, process_diagnostics(lua)
    selected = pixel_input(
        "grayscale",
        selection=selection,
        cels_target={
            "kind": "selected",
            "layers": [{"layer_name": "Ink"}],
            "frame_numbers": [1],
        },
    )
    code, result = apply(source, target, selected)
    assert code == 0, result
    assert result["selection"] == expected
    assert (
        result["requested_intersections"]
        == result["existing_target_cels"]
        == [{"layer_path": [1], "frame_number": 1, "image_number": 1}]
    )
    after = observe_images(runtime, target)
    assert [value & 255 for value in after["cels"][0]["pixels"]] == values
    assert result["persisted_reopen_verified"] is True


def test_selected_cartesian_absences_remain_valid(tmp_path, runtime):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    lua = run_lua(
        FIXTURES / "target_scene.lua", runtime, source=source, mode="cartesian"
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    code, result = apply(
        source,
        target,
        pixel_input(
            cels_target={
                "kind": "selected",
                "layers": [{"layer_path": [1]}, {"layer_name": "Second"}],
                "frame_numbers": [3, 1, 2],
            }
        ),
        1,
        1,
    )
    assert code == 0, result
    assert len(result["requested_intersections"]) == 6
    assert len(result["existing_target_cels"]) == 3
    assert (
        sum(cel["image_number"] is None for cel in result["requested_intersections"])
        == 3
    )
    assert observe_images(runtime, target) == observe_images(runtime, source)
