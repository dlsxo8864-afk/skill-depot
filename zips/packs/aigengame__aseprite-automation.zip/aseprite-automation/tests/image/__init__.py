"""Image authoring tests."""
