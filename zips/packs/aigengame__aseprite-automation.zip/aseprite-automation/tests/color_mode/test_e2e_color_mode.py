"""Native Color Mode conversions through the installed SPA surface."""

import json
import os
import shutil
import sys
from collections.abc import Iterator
from contextlib import ExitStack, contextmanager
from importlib.resources import files
from pathlib import Path

import pytest

from tests.host_permissions import deny_access
from tests.native_invocation import expect_success, run, run_lua
from tests.support import (
    change_sprite_color_mode,
    color_mode_conversion,
    inject_palette_change,
    process_diagnostics,
)

pytestmark = pytest.mark.e2e

FIXTURES = Path(__file__).parent / "fixtures"


@contextmanager
def _deny_file_reading(file: Path) -> Iterator[None]:
    """Deny reading an owned test file; skip if this process can still read it."""
    with deny_access(file, "read"):
        try:
            file.read_bytes()
        except PermissionError:
            pass
        else:
            pytest.skip("cannot reproduce an unreadable file")
        yield


def make_source(
    source: Path, runtime, mode: str = "rgb", *, scene: bool = False
) -> None:
    lua = run_lua(
        FIXTURES / ("scene.lua" if scene else "source.lua"),
        runtime,
        source=source,
        mode=mode,
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    if scene:
        inject_palette_change(
            source,
            [
                (40, 90, 120, 255),
                (40, 60, 220, 255),
                (220, 150, 40, 128),
                (0, 0, 0, 0),
                (230, 80, 90, 255),
                (255, 255, 255, 255),
            ],
            frame_number=3,
        )


def test_rgb_to_grayscale_preserves_source_and_reports_reopened_images(
    tmp_path, runtime
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime)
    original = source.read_bytes()
    code, result = change_sprite_color_mode(
        source,
        target,
        {
            "source_color_mode": "rgb",
            "target": {"color_mode": "grayscale", "to_gray": "luma"},
        },
    )
    assert code == 0, result
    assert result["source_color_mode"] == "rgb"
    assert result["target_color_mode"] == "grayscale"
    assert result["changed"] is True
    assert result["persisted_reopen_verified"] is True
    assert result["before"]["images"][0]["bytes_per_pixel"] == 4
    assert result["after"]["images"][0]["bytes_per_pixel"] == 2
    assert (
        result["before"]["images"][0]["content"]
        != result["after"]["images"][0]["content"]
    )
    inspected = expect_success(
        "sprite get",
        {"sprite_file": str(target), "inspection_scope": ["cels", "palettes"]},
    )
    assert inspected["metadata"]["color_mode"] == "grayscale"
    assert source.read_bytes() == original


@pytest.mark.parametrize("source_mode", ["rgb", "grayscale", "indexed"])
@pytest.mark.parametrize("target_mode", ["rgb", "grayscale", "indexed"])
def test_every_color_mode_pair(tmp_path, runtime, source_mode, target_mode):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime, source_mode)
    original = source.read_bytes()
    code, result = change_sprite_color_mode(
        source, target, color_mode_conversion(source_mode, target_mode)
    )
    assert code == 0, result
    assert result["after"]["color_mode"] == target_mode
    assert result["changed"] == (source_mode != target_mode)
    if source_mode == target_mode:
        assert result["before"] == result["after"]
        assert result["mapping"] is None and result["dithering"] is None
    elif target_mode == "indexed":
        assert result["mapping"] == {
            "requested_rgb_map_algorithm": "default",
            "effective_rgb_map_algorithm": "octree",
            "color_best_fit_criteria": "default",
        }
        assert (
            sum(
                item["pixel_count"]
                for item in result["after"]["images"][0]["palette_indices"]
            )
            == 3
        )
        if source_mode == "rgb":
            assert result["dithering"]["effective_algorithm"] == "none"
        else:
            assert result["dithering"] is None
    assert source.read_bytes() == original


@pytest.mark.parametrize(
    "algorithm,matrix,size",
    [
        ("ordered", None, 8),
        ("old", None, 8),
        ("ordered", {"kind": "installed", "id": "bayer4x4"}, 4),
        ("old", {"kind": "installed", "id": "bayer2x2"}, 2),
        ("ordered", {"kind": "installed", "id": "bayer8x8"}, 8),
    ],
)
def test_dithering_matrix_resolution(tmp_path, runtime, algorithm, matrix, size):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime)
    conversion = color_mode_conversion("rgb", "indexed")
    conversion["target"]["dithering"] = {"algorithm": algorithm}
    if matrix is not None:
        conversion["target"]["dithering"]["matrix"] = matrix
    code, result = change_sprite_color_mode(source, target, conversion)
    assert code == 0, result
    facts = result["dithering"]
    assert facts["effective_algorithm"] == algorithm
    assert facts["matrix"]["requested"] == matrix
    assert facts["matrix"]["width"] == facts["matrix"]["height"] == size
    assert facts["matrix"]["identity"] == f"bayer{size}x{size}"
    assert facts["matrix"]["provenance"] == (
        "installed" if matrix else "native-default"
    )


@pytest.mark.parametrize("profile_first", [True, False])
@pytest.mark.parametrize(
    "profile_operation", ["assign-color-profile", "convert-color-profile"]
)
def test_plan_combines_color_mode_and_profile_steps(
    tmp_path, runtime, profile_first, profile_operation
):
    if (
        profile_operation == "convert-color-profile"
        and "aseprite_convert_color_profile" not in runtime.verified_capabilities
    ):
        assert sys.platform == "linux", "expected native Color Profile conversion"
        pytest.skip("selected Linux runtime has no native Color Profile converter")
    source, planned = tmp_path / "source.aseprite", tmp_path / "plan.aseprite"
    make_source(source, runtime)
    original = source.read_bytes()
    profile: dict = {"kind": "none"}
    if profile_operation == "convert-color-profile":
        icc = tmp_path / "linear.icc"
        icc.write_bytes(
            files("spa.kernel").joinpath("color/profiles/linear_srgb.icc").read_bytes()
        )
        profile = {"kind": "icc", "icc_file": str(icc)}
    steps = [
        {
            "operation": f"sprite {profile_operation}",
            "input": {"profile": profile},
        },
        {
            "operation": "sprite change-color-mode",
            "input": {"conversion": color_mode_conversion("rgb", "indexed")},
        },
    ]
    if not profile_first:
        steps.reverse()
    expected = []
    current = source
    for number, step in enumerate(steps):
        target = tmp_path / f"standalone-{number}.aseprite"
        result = expect_success(
            step["operation"],
            {
                "source_sprite_file": str(current),
                "target_sprite_file": str(target),
                "in_place": False,
                "overwrite": False,
                **step["input"],
            },
        )
        expected.append(result)
        current = target
    result = expect_success(
        "plan run",
        {
            "plan": {
                "source_sprite_file": str(source),
                "target_sprite_file": str(planned),
                "steps": steps,
                "postconditions": {"color_mode": "indexed"},
            }
        },
    )
    assert [step["operation"] for step in result["steps"]] == [
        step["operation"] for step in steps
    ]
    for actual, standalone in zip(result["steps"], expected, strict=True):
        assert actual["result"]["persisted_reopen_verified"] is False
        assert {
            key: value
            for key, value in actual["result"].items()
            if key != "persisted_reopen_verified"
        } == {
            key: value
            for key, value in standalone.items()
            if key
            not in {"status", "operation", "target_commit", "persisted_reopen_verified"}
        }
    assert result["persisted_reopen_verified"] is True
    assert result["final_sprite"]["metadata"]["color_mode"] == "indexed"
    assert source.read_bytes() == original


@pytest.mark.parametrize(
    "source_mode,target_mode",
    [
        ("rgb", "indexed"),
        ("indexed", "rgb"),
        ("indexed", "grayscale"),
        ("grayscale", "indexed"),
        ("rgb", "grayscale"),
        ("grayscale", "rgb"),
        ("indexed", "indexed"),
    ],
)
def test_complete_sprite_images_palette_basis_and_links(
    tmp_path, runtime, source_mode, target_mode
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime, source_mode, scene=True)
    original = source.read_bytes()
    code, result = change_sprite_color_mode(
        source, target, color_mode_conversion(source_mode, target_mode)
    )
    assert code == 0, result
    before, after = result["before"], result["after"]
    assert len(before["palettes"]["palette_changes"]) == 2
    assert {item["kind"] for item in after["images"]} == {"cel", "tile", "tilemap"}
    assert len(before["tilesets"]) == len(after["tilesets"]) == 2
    assert [cel["image_number"] for cel in before["cels"]] == [
        cel["image_number"] for cel in after["cels"]
    ]
    assert any(cel["is_background"] for cel in after["cels"])
    assert len({cel["image_number"] for cel in before["cels"]}) < len(before["cels"])
    assert {
        image["palette_frame_number"]
        for image in before["images"]
        if image["kind"] == "cel"
    } == {1, 3}
    assert {
        image["conversion_frame_number"]
        for image in before["images"]
        if image["kind"] == "tile"
    } == {1}
    for old, new in zip(before["images"], after["images"], strict=True):
        if old["kind"] == "tilemap":
            assert old == new
        else:
            assert (
                new["bytes_per_pixel"]
                == {"rgb": 4, "grayscale": 2, "indexed": 1}[target_mode]
            )
    if source_mode != target_mode and target_mode == "indexed":
        assert all(cel["opacity"] == 255 for cel in after["cels"])
        assert after["transparent_color_index"] == 3
    if source_mode != target_mode and target_mode == "grayscale":
        assert len(after["palettes"]["palette_changes"]) == 1
        assert len(after["palettes"]["palette_changes"][0]["entries"]) == 256
    assert source.read_bytes() == original


def fnv1a64(data: bytes) -> str:
    """Return the FNV-1a 64-bit digest of data as 16 lowercase hex digits."""
    value = 0xCBF29CE484222325
    for byte in data:
        value = (value ^ byte) * 0x100000001B3 % 2**64
    return f"{value:016x}"


def dump_cels(runtime, sprite_file: Path) -> dict:
    """Return the `cel_dump.lua` record of each Cel and Tile in sprite_file."""
    response = sprite_file.with_suffix(".cels.json")
    lua = run_lua(
        FIXTURES / "cel_dump.lua", runtime, source=sprite_file, response=response
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    return json.loads(response.read_text())


def assert_reported_digests(after: dict, dumped: dict) -> None:
    """Assert that each reported content digest hashes the dumped raw bytes."""
    contents = {image["image_number"]: image["content"] for image in after["images"]}
    cels = {(cel["frame_number"], *cel["layer_path"]): cel for cel in dumped["cels"]}
    tiles = {
        (tile["tileset_number"], tile["tile_index"]): tile for tile in dumped["tiles"]
    }
    assert len(after["cels"]) == len(cels)
    for cel in after["cels"]:
        raw = cels[(cel["frame_number"], *cel["layer_path"])]["bytes"]
        assert contents[cel["image_number"]] == fnv1a64(bytes.fromhex(raw))
    for tileset in after["tilesets"]:
        for tile in tileset["tiles"]:
            raw = tiles[(tileset["tileset_number"], tile["tile_index"])]["bytes"]
            if tile["image_number"] is None:
                assert raw is None
            else:
                assert contents[tile["image_number"]] == fnv1a64(bytes.fromhex(raw))


def assert_native_reference(tmp_path, runtime, source, result, options):
    options_file, reference, receipt = [
        tmp_path / name
        for name in ("options.json", "reference.aseprite", "receipt.aseprite")
    ]
    options_file.write_text(json.dumps(options))
    lua = run_lua(
        FIXTURES / "native_reference.lua",
        runtime,
        source=source,
        target=reference,
        options=options_file,
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    mode = result["target_color_mode"]
    code, observed = change_sprite_color_mode(
        reference, receipt, color_mode_conversion(mode, mode)
    )
    assert code == 0, observed
    assert observed["after"] == result["after"]
    # The SPA observer reads both sides above. The independent dump compares
    # Cel position and raw bytes, and checks each reported digest.
    dumped = dump_cels(runtime, Path(result["target_commit"]["target_sprite_file"]))
    assert dumped == dump_cels(runtime, reference)
    assert_reported_digests(result["after"], dumped)


@pytest.mark.parametrize("source_mode", ["rgb", "grayscale"])
@pytest.mark.parametrize("mapping", ["default", "rgb5a3", "octree"])
@pytest.mark.parametrize(
    "criteria", ["default", "rgb", "linearizedRGB", "ciexyz", "cielab"]
)
def test_mapping_choices_match_direct_native_command(
    tmp_path, runtime, source_mode, mapping, criteria
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime, source_mode, scene=True)
    conversion = color_mode_conversion(source_mode, "indexed")
    conversion["target"].update(
        rgb_map_algorithm=mapping, color_best_fit_criteria=criteria
    )
    code, result = change_sprite_color_mode(source, target, conversion)
    assert code == 0, result
    assert result["mapping"]["requested_rgb_map_algorithm"] == mapping
    assert result["mapping"]["color_best_fit_criteria"] == criteria
    assert_native_reference(
        tmp_path,
        runtime,
        source,
        result,
        {
            "format": "indexed",
            "rgbmap": mapping,
            "fitCriteria": criteria,
            "dithering": "none",
        },
    )


@pytest.mark.parametrize("source_mode", ["rgb", "indexed"])
@pytest.mark.parametrize("to_gray", ["luma", "hsv", "hsl"])
def test_to_gray_choices_match_direct_native_command(
    tmp_path, runtime, source_mode, to_gray
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime, source_mode, scene=True)
    conversion = color_mode_conversion(source_mode, "grayscale")
    conversion["target"]["to_gray"] = to_gray
    code, result = change_sprite_color_mode(source, target, conversion)
    assert code == 0, result
    assert_native_reference(
        tmp_path, runtime, source, result, {"format": "gray", "toGray": to_gray}
    )


@pytest.mark.parametrize("factor", [0, 0.345, 1])
def test_error_diffusion_factor_matches_native_and_reports_effective_percent(
    tmp_path, runtime, factor
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime, scene=True)
    conversion = color_mode_conversion("rgb", "indexed")
    conversion["target"]["dithering"] = {
        "algorithm": "error-diffusion",
        "dithering_factor": factor,
    }
    code, result = change_sprite_color_mode(source, target, conversion)
    assert code == 0, result
    assert result["dithering"]["dithering_factor"] == factor
    assert result["dithering"]["effective_factor_percent"] == int(factor * 100)
    assert result["dithering"]["matrix"] is None
    assert_native_reference(
        tmp_path,
        runtime,
        source,
        result,
        {
            "format": "indexed",
            "rgbmap": "default",
            "fitCriteria": "default",
            "dithering": "error-diffusion",
            "ditheringFactor": factor,
        },
    )


@pytest.mark.parametrize("algorithm", ["ordered", "old"])
def test_file_matrix_matches_installed_matrix_and_native_pixels(
    tmp_path, runtime, algorithm
):
    source = tmp_path / "source.aseprite"
    make_source(source, runtime, scene=True)
    conversion = color_mode_conversion("rgb", "indexed")
    conversion["target"]["dithering"] = {
        "algorithm": algorithm,
        "matrix": {"kind": "installed", "id": "bayer4x4"},
    }
    code, installed = change_sprite_color_mode(
        source, tmp_path / "installed.aseprite", conversion
    )
    assert code == 0, installed
    path = installed["dithering"]["matrix"]["resolved_path"]
    conversion["target"]["dithering"]["matrix"] = {"kind": "file", "path": path}
    code, explicit = change_sprite_color_mode(
        source, tmp_path / "explicit.aseprite", conversion
    )
    assert code == 0, explicit
    assert explicit["after"] == installed["after"]
    assert explicit["dithering"]["matrix"]["provenance"] == "file"
    assert explicit["dithering"]["matrix"]["requested"]["path"] == path
    assert_native_reference(
        tmp_path,
        runtime,
        source,
        explicit,
        {
            "format": "indexed",
            "rgbmap": "default",
            "fitCriteria": "default",
            "dithering": algorithm,
            "ditheringMatrix": path,
        },
    )


@pytest.mark.parametrize("algorithm", ["ordered", "old"])
@pytest.mark.parametrize("via_plan", [False, True])
def test_matrix_image_can_extend_beyond_canvas(tmp_path, runtime, algorithm, via_plan):
    source = tmp_path / "source.aseprite"
    make_source(source, runtime, scene=True)
    original = source.read_bytes()
    matrices = [tmp_path / f"matrix-{size}.aseprite" for size in (2, 4)]
    for matrix, size in zip(matrices, (2, 4), strict=True):
        lua = run_lua(
            FIXTURES / "matrix_coverage.lua",
            runtime,
            target=matrix,
            image_width=size,
            image_height=size,
        )
        assert lua.returncode == 0, process_diagnostics(lua)
    conversion = color_mode_conversion("rgb", "indexed")
    conversion["target"]["dithering"] = {"algorithm": algorithm}
    code, default = change_sprite_color_mode(
        source, tmp_path / "default.aseprite", conversion
    )
    assert code == 0, default
    conversion["target"]["dithering"]["matrix"] = {
        "kind": "file",
        "path": str(matrices[0]),
    }
    code, equivalent = change_sprite_color_mode(
        source, tmp_path / "equivalent.aseprite", conversion
    )
    assert code == 0, equivalent
    assert equivalent["after"] != default["after"]
    for matrix in matrices:
        # The independent native command must produce the same pixels for both
        # Images, and differ from omitted Bayer 8x8 to rule out native fallback.
        reference_dir = tmp_path / f"native-{matrix.stem}"
        reference_dir.mkdir()
        assert_native_reference(
            reference_dir,
            runtime,
            source,
            equivalent,
            {
                "format": "indexed",
                "rgbmap": "default",
                "fitCriteria": "default",
                "dithering": algorithm,
                "ditheringMatrix": str(matrix),
            },
        )
    conversion["target"]["dithering"]["matrix"]["path"] = str(matrices[1])
    target = tmp_path / "target.aseprite"
    if via_plan:
        result = expect_success(
            "plan run",
            {
                "plan": {
                    "source_sprite_file": str(source),
                    "target_sprite_file": str(target),
                    "steps": [
                        {
                            "operation": "sprite change-color-mode",
                            "input": {"conversion": conversion},
                        }
                    ],
                },
            },
        )
    else:
        code, result = change_sprite_color_mode(source, target, conversion)
        assert code == 0, result
    assert result["persisted_reopen_verified"] is True
    evidence = result["steps"][0]["result"] if via_plan else result
    assert evidence["after"] == equivalent["after"]
    matrix = evidence["dithering"]["matrix"]
    assert matrix["width"] == matrix["height"] == 2
    assert matrix["provenance"] == "file"
    assert matrix["resolved_path"] == str(matrices[1])
    assert source.read_bytes() == original


@pytest.mark.parametrize(
    "failure",
    [
        "missing-id",
        "missing-file",
        "invalid",
        "unreadable",
        "undersized-width",
        "undersized-height",
        "wrong-source",
    ],
)
@pytest.mark.parametrize("via_plan", [False, True])
def test_preflight_failure_preserves_existing_source_and_target(
    tmp_path, runtime, failure, via_plan
):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime)
    original = source.read_bytes()
    target.write_bytes(b"existing target must survive")
    conversion = color_mode_conversion("rgb", "indexed")
    matrix = tmp_path / "matrix.bmp"
    if failure.startswith("undersized-"):
        matrix = matrix.with_suffix(".aseprite")
        lua = run_lua(
            FIXTURES / "matrix_coverage.lua",
            runtime,
            target=matrix,
            image_width=1 if failure == "undersized-width" else 2,
            image_height=1 if failure == "undersized-height" else 2,
        )
        assert lua.returncode == 0, process_diagnostics(lua)
    if failure == "missing-id":
        selected = {"kind": "installed", "id": "Bayer8x8-does-not-exist"}
    else:
        selected = {"kind": "file", "path": str(matrix)}
        if failure in {"invalid", "unreadable"}:
            matrix.write_bytes(b"not a native image")
    conversion["target"]["dithering"] = {"algorithm": "ordered", "matrix": selected}
    if failure == "wrong-source":
        conversion = color_mode_conversion("indexed", "rgb")
    with ExitStack() as permissions:
        if failure == "unreadable":
            permissions.enter_context(_deny_file_reading(matrix))
        if via_plan:
            refused = run(
                "plan run",
                {
                    "plan": {
                        "source_sprite_file": str(source),
                        "target_sprite_file": str(target),
                        "overwrite": True,
                        "steps": [
                            {
                                "operation": "frame add",
                                "input": {"frame_number": 2, "duration_ms": 100},
                            },
                            {
                                "operation": "sprite change-color-mode",
                                "input": {"conversion": conversion},
                            },
                        ],
                    },
                },
            )
        else:
            refused = run(
                "sprite change-color-mode",
                {
                    "source_sprite_file": str(source),
                    "target_sprite_file": str(target),
                    "in_place": False,
                    "overwrite": True,
                    "conversion": conversion,
                },
            )
    result = refused.envelope
    assert refused.returncode != 0, result
    assert result["code"] == (
        "color_mode_mismatch"
        if failure == "wrong-source"
        else "dithering_matrix_invalid"
    ), result
    if via_plan:
        assert result["details"]["step_number"] == 2
    if failure in {"unreadable", "invalid"}:
        assert result["details"]["reason"] == failure
    if failure.startswith("undersized-"):
        assert result["details"]["reason"] == "invalid"
    assert source.read_bytes() == original
    assert target.read_bytes() == b"existing target must survive"
    assert not list(tmp_path.glob("*.stage*"))


def test_ambiguous_installed_matrix_is_rejected_before_publication(tmp_path, runtime):
    from dataclasses import replace

    from spa.adapters.aseprite.aseprite import invoke
    from spa.adapters.files import LocalTargetFiles
    from spa.authoring.color.color_mode import ColorModeRequest, change_color_mode
    from spa.contracts.ports import OperationIssue, OperationServices

    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime)
    data = tmp_path / "data"
    data.mkdir()
    for child in Path(runtime.resource_path).parent.iterdir():
        if child.name != "extensions":
            if os.name == "nt":
                if child.is_dir():
                    shutil.copytree(child, data / child.name)
                else:
                    shutil.copyfile(child, data / child.name)
            else:
                (data / child.name).symlink_to(
                    child, target_is_directory=child.is_dir()
                )
    for name in ("first", "second"):
        extension = data / "extensions" / name
        extension.mkdir(parents=True)
        (extension / "package.json").write_text(
            json.dumps(
                {
                    "name": name,
                    "version": "1.0.0",
                    "contributes": {
                        "ditheringMatrices": [
                            {"id": "duplicate", "path": "matrix.bmp"},
                        ]
                    },
                }
            )
        )
    selected = replace(runtime, resource_path=str(data / "gui.xml"))
    services = OperationServices(lambda _request: selected, invoke, LocalTargetFiles())
    conversion = color_mode_conversion("rgb", "indexed")
    conversion["target"]["dithering"] = {
        "algorithm": "ordered",
        "matrix": {"kind": "installed", "id": "duplicate"},
    }
    request = ColorModeRequest.model_validate(
        {
            "source_sprite_file": str(source),
            "target_sprite_file": str(target),
            "in_place": False,
            "overwrite": False,
            "conversion": conversion,
        }
    )
    with pytest.raises(OperationIssue) as failure:
        change_color_mode(request, services)
    assert failure.value.code == "dithering_matrix_invalid"
    assert failure.value.details.reason == "ambiguous"
    assert len(failure.value.details.matches) == 2
    assert not target.exists()


def test_plan_create_then_convert_uses_final_mode_for_postconditions(tmp_path):
    target = tmp_path / "target.aseprite"
    result = expect_success(
        "plan run",
        {
            "plan": {
                "target_sprite_file": str(target),
                "steps": [
                    {
                        "operation": "sprite create",
                        "input": {
                            "width": 2,
                            "height": 2,
                            "color_mode": "rgb",
                            "initial_layer": {"kind": "transparent"},
                        },
                    },
                    {
                        "operation": "sprite change-color-mode",
                        "input": {
                            "conversion": color_mode_conversion("rgb", "grayscale")
                        },
                    },
                    {
                        "operation": "sprite change-color-mode",
                        "input": {
                            "conversion": color_mode_conversion("grayscale", "indexed")
                        },
                    },
                    {
                        "operation": "sprite get",
                        "input": {"inspection_scope": ["cels"]},
                    },
                ],
                "postconditions": {"color_mode": "indexed"},
            }
        },
    )
    assert result["steps"][0]["result"]["sprite"]["metadata"]["color_mode"] == "rgb"
    assert result["final_sprite"]["metadata"]["color_mode"] == "indexed"
    assert result["persisted_reopen_verified"] is True


def test_failed_postcondition_after_conversion_rolls_back_target(tmp_path, runtime):
    source, target = tmp_path / "source.aseprite", tmp_path / "target.aseprite"
    make_source(source, runtime)
    original = source.read_bytes()
    target.write_bytes(b"previous target")
    failed = run(
        "plan run",
        {
            "plan": {
                "source_sprite_file": str(source),
                "target_sprite_file": str(target),
                "overwrite": True,
                "steps": [
                    {
                        "operation": "sprite change-color-mode",
                        "input": {
                            "conversion": color_mode_conversion("rgb", "grayscale")
                        },
                    }
                ],
                "postconditions": {"color_mode": "rgb"},
            },
        },
    )
    result = failed.envelope
    assert failed.returncode != 0 and result["code"] == "kernel_execution_failed", (
        result
    )
    assert result["details"]["failed_step"] is None, result
    assert result["details"]["reason"].endswith("Plan color_mode Postcondition failed")
    assert source.read_bytes() == original
    assert target.read_bytes() == b"previous target"


def test_in_place_conversion_commits_only_after_verified_reopen(tmp_path, runtime):
    source = tmp_path / "source.aseprite"
    make_source(source, runtime)
    original = source.read_bytes()
    result = expect_success(
        "sprite change-color-mode",
        {
            "source_sprite_file": str(source),
            "target_sprite_file": str(source),
            "in_place": True,
            "overwrite": True,
            "conversion": color_mode_conversion("rgb", "indexed"),
        },
    )
    assert result["persisted_reopen_verified"] is True
    assert source.read_bytes() != original
    stable = source.read_bytes()
    refused = run(
        "sprite change-color-mode",
        {
            "source_sprite_file": str(source),
            "target_sprite_file": str(source),
            "in_place": True,
            "overwrite": True,
            "conversion": color_mode_conversion("rgb", "grayscale"),
        },
    )
    rejected = refused.envelope
    assert refused.returncode != 0 and rejected["code"] == "color_mode_mismatch", (
        rejected
    )
    assert source.read_bytes() == stable


def test_shared_owner_restores_editor_state_on_success_and_failure(tmp_path, runtime):
    from importlib.resources import files

    from spa.authoring.color.color_mode import COLOR_MODE_RESOURCES

    source, invalid = tmp_path / "source.aseprite", tmp_path / "invalid.bmp"
    make_source(source, runtime)
    original = source.read_bytes()
    invalid.write_bytes(b"invalid image")
    lua = run_lua(
        FIXTURES / "state_restoration.lua",
        runtime,
        source=source,
        invalid_matrix=invalid,
        workspace=tmp_path,
        aseprite_data=Path(runtime.resource_path).parent,
        **{
            resource.parameter_name: str(
                files("spa.kernel").joinpath(resource.package_path)
            )
            for resource in COLOR_MODE_RESOURCES
        },
    )
    assert lua.returncode == 0, process_diagnostics(lua)
    assert source.read_bytes() == original
