"""Frame behavior ownership tests."""
