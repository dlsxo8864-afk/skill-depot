"""Explicit raster preparation tests."""
