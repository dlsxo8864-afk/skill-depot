"""Application behavior tests."""
