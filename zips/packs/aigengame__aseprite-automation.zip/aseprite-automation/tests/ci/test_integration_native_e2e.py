"""Exercise native workflow shell steps with real Git and a controlled GitHub API."""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from tests.support import workflow_step

WORKFLOW = Path(__file__).resolve().parents[2] / ".github/workflows/native-e2e.yml"
pytestmark = pytest.mark.skipif(
    os.name == "nt",
    reason="Executes the hosted Linux workflows' Bash steps, not the portable runner",
)


def run_step(
    name: str, repository: Path, env: dict[str, str], workflow: Path = WORKFLOW
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["bash", "-e", "-o", "pipefail", "-c", workflow_step(workflow, name)],
        cwd=repository,
        env=env,
        capture_output=True,
        text=True,
        timeout=10,
        check=False,
    )


@pytest.fixture
def candidate(tmp_path: Path) -> tuple[Path, dict[str, str], dict]:
    def git(*args: str) -> str:
        return subprocess.check_output(
            ["git", "-C", str(tmp_path), *args], text=True, stderr=subprocess.PIPE
        ).strip()

    git("init", "--initial-branch=main")
    git("config", "user.name", "Native gate test")
    git("config", "user.email", "ci@example.invalid")
    git("config", "commit.gpgsign", "false")
    git("commit", "--allow-empty", "-m", "base")
    base = git("rev-parse", "HEAD")
    git("checkout", "-b", "feature")
    git("commit", "--allow-empty", "-m", "head")
    head = git("rev-parse", "HEAD")
    git("checkout", "main")
    git("merge", "--no-ff", "feature", "-m", "merge preview")
    merge = git("rev-parse", "HEAD")
    response = {
        "number": 125,
        "state": "open",
        "mergeable": True,
        "base": {"ref": "main", "sha": base},
        "head": {"sha": head},
        "merge_commit_sha": merge,
    }
    api = tmp_path / "pull.json"
    api.write_text(json.dumps(response))
    tools = tmp_path / "bin"
    tools.mkdir()
    gh = tools / "gh"
    gh.write_text(
        f"#!{sys.executable}\n"
        "import os, sys\nfrom pathlib import Path\n"
        "assert sys.argv[1:] == ['api', 'repos/example/spa/pulls/125']\n"
        "print(Path(os.environ['SPA_TEST_PR_RESPONSE']).read_text())\n"
    )
    gh.chmod(0o755)
    env = {
        **os.environ,
        "PATH": f"{tools}{os.pathsep}{os.environ['PATH']}",
        "SPA_TEST_PR_RESPONSE": str(api),
        "SPA_PR_NUMBER": "125",
        "SPA_NATIVE_TARGET": str(tmp_path / "spa-native-target.json"),
        "RUNNER_TEMP": str(tmp_path),
        "GITHUB_REPOSITORY": "example/spa",
        "GITHUB_SHA": base,
        "GITHUB_REF": "refs/heads/main",
        "GITHUB_OUTPUT": str(tmp_path / "outputs"),
        "GITHUB_STEP_SUMMARY": str(tmp_path / "summary"),
    }
    return tmp_path, env, response


def test_pr_gate_verifies_the_merge_instead_of_the_dispatch_sha(candidate) -> None:
    repository, env, response = candidate
    for name in (
        "Resolve the native test target",
        "Check the merge parents before testing",
        "Reject a changed PR after testing",
    ):
        result = run_step(name, repository, env)
        assert result.returncode == 0, result.stderr
    target = json.loads(Path(env["SPA_NATIVE_TARGET"]).read_text())
    assert target == {
        "kind": "pull_request",
        "number": 125,
        "base_ref": "main",
        "base": response["base"]["sha"],
        "head": response["head"]["sha"],
        "sha": response["merge_commit_sha"],
    }
    outputs = dict(
        line.split("=", 1)
        for line in Path(env["GITHUB_OUTPUT"]).read_text().splitlines()
    )
    assert outputs["sha"] == response["merge_commit_sha"]
    assert json.loads(outputs["target"]) == target
    summary = Path(env["GITHUB_STEP_SUMMARY"]).read_text()
    assert "PR target is unchanged after testing" in summary
    assert response["merge_commit_sha"] in summary


@pytest.mark.parametrize("mergeable", [False, None])
def test_unavailable_merge_preview_fails_before_checkout(candidate, mergeable) -> None:
    repository, env, response = candidate
    response["mergeable"] = mergeable
    Path(env["SPA_TEST_PR_RESPONSE"]).write_text(json.dumps(response))
    result = run_step("Resolve the native test target", repository, env)
    assert result.returncode != 0
    assert "PR has no current merge result" in result.stderr
    assert not Path(env["GITHUB_OUTPUT"]).exists()


@pytest.mark.parametrize("change", ["base", "head", "merge", "closed", "base_ref"])
def test_pr_changes_invalidate_native_evidence(candidate, change: str) -> None:
    repository, env, response = candidate
    assert run_step("Resolve the native test target", repository, env).returncode == 0
    if change in {"base", "head"}:
        response[change]["sha"] = "f" * 40
    elif change == "merge":
        response["merge_commit_sha"] = "f" * 40
    elif change == "base_ref":
        response["base"]["ref"] = "dev"
    else:
        response["state"] = "closed"
    Path(env["SPA_TEST_PR_RESPONSE"]).write_text(json.dumps(response))
    result = run_step("Reject a changed PR after testing", repository, env)
    assert result.returncode != 0
    assert "this run cannot admit merge" in result.stderr
    assert "unchanged after testing" not in Path(env["GITHUB_STEP_SUMMARY"]).read_text()


@pytest.mark.parametrize("change", ["head", "base"])
def test_repeating_preparation_resolves_a_changed_pr_target(candidate, change) -> None:
    repository, env, response = candidate

    def git(*args: str) -> str:
        return subprocess.check_output(
            ["git", "-C", str(repository), *args], text=True, stderr=subprocess.PIPE
        ).strip()

    assert run_step("Resolve the native test target", repository, env).returncode == 0
    previous = json.loads(Path(env["SPA_NATIVE_TARGET"]).read_text())
    git("checkout", "-b", "updated", response[change]["sha"])
    (repository / "README.md").write_text("Documentation-only change.\n")
    git("add", "README.md")
    git("commit", "-m", "docs: update candidate")
    response[change]["sha"] = git("rev-parse", "HEAD")
    git("checkout", "-b", "new-preview", response["base"]["sha"])
    git("merge", "--no-ff", response["head"]["sha"], "-m", "new merge preview")
    response["merge_commit_sha"] = git("rev-parse", "HEAD")
    Path(env["SPA_TEST_PR_RESPONSE"]).write_text(json.dumps(response))

    # A retained successful preparation cannot admit this new Git target.
    result = run_step("Reject a changed PR after testing", repository, env)
    assert result.returncode != 0
    assert json.loads(Path(env["SPA_NATIVE_TARGET"]).read_text()) == previous

    for name in (
        "Resolve the native test target",
        "Check the merge parents before testing",
        "Reject a changed PR after testing",
    ):
        result = run_step(name, repository, env)
        assert result.returncode == 0, result.stderr
    current = json.loads(Path(env["SPA_NATIVE_TARGET"]).read_text())
    assert current[change] != previous[change]
    assert current["sha"] == response["merge_commit_sha"] != previous["sha"]
    outputs = dict(
        line.split("=", 1)
        for line in Path(env["GITHUB_OUTPUT"]).read_text().splitlines()
    )
    assert json.loads(outputs["target"]) == current


def test_pr_metadata_edits_do_not_invalidate_the_tested_source(candidate) -> None:
    repository, env, response = candidate
    assert run_step("Resolve the native test target", repository, env).returncode == 0
    response.update(title="New title", body="New description", labels=[])
    Path(env["SPA_TEST_PR_RESPONSE"]).write_text(json.dumps(response))
    result = run_step("Reject a changed PR after testing", repository, env)
    assert result.returncode == 0, result.stderr


def test_stale_merge_parents_fail_before_native_setup(candidate) -> None:
    repository, env, response = candidate
    response["head"]["sha"] = "f" * 40
    Path(env["SPA_TEST_PR_RESPONSE"]).write_text(json.dumps(response))
    assert run_step("Resolve the native test target", repository, env).returncode == 0
    result = run_step("Check the merge parents before testing", repository, env)
    assert result.returncode != 0
    assert "Merge preview parents do not match" in result.stderr


def test_main_verification_uses_the_exact_event_sha(candidate) -> None:
    repository, env, response = candidate
    env["SPA_PR_NUMBER"] = ""
    subprocess.run(
        ["git", "checkout", env["GITHUB_SHA"]],
        cwd=repository,
        check=True,
        capture_output=True,
    )
    for name in (
        "Resolve the native test target",
        "Check the merge parents before testing",
        "Reject a changed PR after testing",
    ):
        result = run_step(name, repository, env)
        assert result.returncode == 0, result.stderr
    assert json.loads(Path(env["SPA_NATIVE_TARGET"]).read_text()) == {
        "kind": "main",
        "sha": response["base"]["sha"],
    }
    assert "PR target is unchanged" not in Path(env["GITHUB_STEP_SUMMARY"]).read_text()


def test_main_mode_rejects_a_dev_dispatch(candidate) -> None:
    repository, env, _ = candidate
    env.update(SPA_PR_NUMBER="", GITHUB_REF="refs/heads/dev")
    result = run_step("Resolve the native test target", repository, env)
    assert result.returncode != 0
    assert "must be dispatched from main" in result.stderr


def test_api_failure_cannot_validate_previous_success(candidate) -> None:
    repository, env, _ = candidate
    assert run_step("Resolve the native test target", repository, env).returncode == 0
    Path(env["SPA_TEST_PR_RESPONSE"]).write_text("not JSON")
    result = run_step("Reject a changed PR after testing", repository, env)
    assert result.returncode != 0
    assert "this run cannot admit merge" in result.stderr


@pytest.mark.parametrize("job", ["PREPARE", "SHARDS"])
@pytest.mark.parametrize("state", ["success", "failure", "cancelled", "skipped"])
def test_native_aggregate_requires_every_shard_to_succeed(
    candidate, job: str, state: str
) -> None:
    repository, env, _ = candidate
    env.update(SPA_PREPARE_RESULT="success", SPA_SHARDS_RESULT="success")
    env[f"SPA_{job}_RESULT"] = state
    result = run_step("Require successful preparation and every shard", repository, env)
    assert (result.returncode == 0) == (state == "success")


@pytest.mark.parametrize("job", ["PREPARE", "QUALITY", "SHARDS"])
@pytest.mark.parametrize("state", ["success", "failure", "cancelled", "skipped"])
def test_release_aggregate_requires_quality_and_every_shard(
    candidate, job: str, state: str
) -> None:
    repository, env, _ = candidate
    env.update(
        SPA_PREPARE_RESULT="success",
        SPA_QUALITY_RESULT="success",
        SPA_SHARDS_RESULT="success",
    )
    env[f"SPA_{job}_RESULT"] = state
    result = run_step(
        "Require all release verification jobs",
        repository,
        env,
        WORKFLOW.with_name("release.yml"),
    )
    assert (result.returncode == 0) == (state == "success")


@pytest.mark.parametrize(
    "shards,workers,success", [("", "", True), ("3", "1", True), ("0", "1", False)]
)
@pytest.mark.parametrize("workflow", [WORKFLOW, WORKFLOW.with_name("release.yml")])
def test_workflow_configuration_uses_shared_parameters(
    candidate, shards, workers, success, workflow
):
    repository, env, _ = candidate
    script_dir = repository / "scripts"
    script_dir.mkdir()
    for name in ("native_e2e.py", "verify_pytest_execution.py"):
        (script_dir / name).write_text(
            (WORKFLOW.parents[2] / "scripts" / name).read_text()
        )
    env.update(SPA_E2E_SHARDS=shards, SPA_E2E_WORKERS=workers)
    result = run_step("Configure native shards", repository, env, workflow)
    assert (result.returncode == 0) == success, result.stderr
    if success:
        value = Path(env["GITHUB_OUTPUT"]).read_text().removeprefix("matrix=")
        count = int(shards) if shards else 8
        assert json.loads(value)["include"] == [
            {"shard_index": index, "shards": count} for index in range(count)
        ]
    else:
        assert "shards and workers must be positive integers" in result.stderr
