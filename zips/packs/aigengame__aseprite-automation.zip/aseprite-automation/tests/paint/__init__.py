"""Paint Domain Module tests."""
