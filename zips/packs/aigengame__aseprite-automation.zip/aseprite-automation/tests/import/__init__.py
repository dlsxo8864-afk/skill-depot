"""External raster import tests."""
