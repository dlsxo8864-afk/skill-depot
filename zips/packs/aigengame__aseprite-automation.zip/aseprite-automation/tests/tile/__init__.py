"""Tile Authoring tests."""
