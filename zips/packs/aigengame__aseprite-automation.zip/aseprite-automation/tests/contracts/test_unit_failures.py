"""Public Failure Code registration and schema conformance for issue #64."""

import json
from dataclasses import replace
from functools import partial
from importlib import import_module
from inspect import getsource
from types import MappingProxyType
from typing import Literal, get_args

import pytest
from jsonschema import Draft202012Validator
from jsonschema import ValidationError as SchemaError
from pydantic import ValidationError

from spa.application.dispatch import _runtime_failure, dispatch
from spa.application.failure_registry import FAILURE_CODES
from spa.application.surface import ACCESS_FAILURE_CODES, OPERATIONS
from spa.authoring.color.color_mode import (
    ColorModeMismatchDetails,
    InstalledMatrix,
    MatrixFailureDetails,
)
from spa.authoring.color.palette import (
    PaletteChangeDetails,
    PaletteEntryDetails,
    PaletteFrameDetails,
    PalettePersistenceDetails,
    PaletteTransformDetails,
)
from spa.authoring.color.palette_file import PaletteFileDetails
from spa.authoring.color.profile import ProfileFileDetails, ProfileSourceDetails
from spa.authoring.color.quantization import QuantizationDetails
from spa.authoring.document.animation import AuditLimitDetails
from spa.authoring.document.cel_contracts import CelAddress as LifecycleCelAddress
from spa.authoring.document.cel_contracts import CelFrameRangeDetails, CelTargetDetails
from spa.authoring.document.layer import LayerAddress, LayerTargetDetails
from spa.authoring.document.slice import SliceAddress, SliceTargetDetails
from spa.authoring.document.sprite import (
    SpriteCopyStagingDetails,
    SpriteCropBoundsDetails,
    SpriteGeometryUnsupportedDetails,
    SpriteUnsupportedContentDetails,
)
from spa.authoring.document.tag import TagAddress, TagRangeDetails, TagTargetDetails
from spa.authoring.raster.filter import FilterRejection
from spa.authoring.raster.image import ImageRotatePositionDetails
from spa.authoring.raster.image_import import ImageImportDetails
from spa.authoring.raster.image_snapshot import SnapshotDetails
from spa.authoring.raster.invert_outline import FilterIndexRejection
from spa.authoring.raster.paint_composite import (
    CompositeCapabilityDetails,
    CompositeDetails,
)
from spa.authoring.raster.paint_native import PaintCapabilityDetails
from spa.authoring.raster.selection import SelectionDetails
from spa.authoring.tile.inspection import TileInspectionDetails, TilesetTarget
from spa.authoring.tile.lifecycle import TileLifecycleDetails
from spa.authoring.tile.regions import TilemapRegionDetails
from spa.authoring.tile.tileset_lifecycle import (
    TilesetInUseDetails,
    TilesetLifecycleDetails,
)
from spa.contracts.artifact import (
    ArtifactFileDetails,
    ArtifactVerificationDetails,
    PartialPublicationDetails,
)
from spa.contracts.mutation import TargetCommitDetails
from spa.contracts.ports import (
    ArtifactFileEvidence,
    ArtifactVerificationEvidence,
    DiscoveryEvidence,
    HandlerEvidence,
    LaunchEvidence,
    PostconditionEvidence,
    ProcessEvidence,
    PublishedArtifactDestination,
    ResourceEvidence,
    ResponseEvidence,
    RuntimeCompatibilityEvidence,
    RuntimeIssue,
    RuntimeIssueKind,
    TargetCommitEvidence,
    UnpublishedArtifactDestination,
)
from spa.contracts.public import (
    CapabilityGap,
    Diagnostics,
    FailureEnvelope,
    KernelExecutionDetails,
    KernelProtocolDetail,
    NotFoundDetails,
    ProcessDetails,
    ProcessStartDetails,
    RequestDetails,
    ResourceDetails,
    RuntimeCompatibilityDetails,
    ValidationIssue,
    VersionRequest,
    VersionResult,
    failure_envelope,
    failure_schema,
    register_failure_codes,
)
from spa.contracts.raster import Point, PositiveRectangle, Size
from spa.delivery.animation_contracts import AnimationExportDetails
from spa.delivery.export_contracts import ExportImageDetails
from spa.delivery.palette import PaletteExportDetails
from spa.delivery.sheet_contracts import SheetRejection
from spa.delivery.tileset import TilesetExportDetails
from spa.preparation.raster import PreparationDetails
from tests.support import operation_services

registered_failure_envelope = partial(failure_envelope, failure_codes=FAILURE_CODES)
registered_failure_schema = partial(failure_schema, failure_codes=FAILURE_CODES)

RUNTIME_ISSUE_CASES = (
    ("discovery_absent", "executable_not_found"),
    ("resources_absent", "resource_incomplete"),
    ("launch_failed", "process_start_failed"),
    ("deadline", "process_timeout"),
    ("output_overflow", "output_limit_exceeded"),
    ("process_failed", "process_failed"),
    ("exit_mismatch", "process_failed"),
    ("response_absent", "kernel_response_missing"),
    ("response_malformed", "kernel_response_invalid"),
    ("handler_rejected", "kernel_execution_failed"),
    ("postcondition_failed", "kernel_response_invalid"),
    ("runtime_incompatible", "runtime_incompatible"),
)
# Only an Operation that owns the failure reports these kinds, so `info` cannot
# classify them. Each kind names the module and test that classify it.
OWNED_RUNTIME_ISSUE_CASES = {
    "target_commit_failed": (
        __name__,
        "test_target_commit_failure_is_owned_by_mutating_sprite_operation",
    ),
    "artifact_file_failed": (
        __name__,
        "test_export_failures_are_owned_by_export_image",
    ),
    "artifact_verification_failed": (
        __name__,
        "test_export_failures_are_owned_by_export_image",
    ),
    "partial_publication": (
        "tests.export.test_integration_tileset_export",
        "test_partial_publication_projects_registered_failure_details",
    ),
}


def test_all_installed_failure_codes_are_registered_once() -> None:
    # The exact set notices a removed or an added public code. The registration test
    # below holds the duplicate refusal.
    assert set(FAILURE_CODES) == {
        "animation_export_invalid",
        "artifact_file_failed",
        "artifact_verification_failed",
        "audit_limit_exceeded",
        "cel_already_exists",
        "cel_background_color_incompatible",
        "cel_background_color_required",
        "cel_frame_out_of_bounds",
        "cel_not_found",
        "cel_unsupported_target",
        "color_mode_mismatch",
        "color_profile_file_failed",
        "color_profile_source_unsupported",
        "dithering_matrix_invalid",
        "executable_not_found",
        "export_image_invalid",
        "export_sheet_unsupported",
        "filter_index_out_of_bounds",
        "filter_invalid_target",
        "filter_unsupported_document",
        "image_canvas_fill_invalid",
        "image_composition_unsupported",
        "image_crop_out_of_bounds",
        "image_import_incompatible",
        "image_rectangle_out_of_bounds",
        "image_resize_palette_basis_invalid",
        "image_resize_position_out_of_bounds",
        "image_rotate_position_out_of_bounds",
        "image_snapshot_invalid",
        "image_transform_position_out_of_bounds",
        "invalid_request",
        "kernel_execution_failed",
        "kernel_response_invalid",
        "kernel_response_missing",
        "layer_ambiguous",
        "layer_invalid_path",
        "layer_invalid_position",
        "layer_missing",
        "layer_parent_not_group",
        "layer_unsupported_target",
        "layer_uuid_unpersisted",
        "motion_linked_cel",
        "motion_position_out_of_bounds",
        "output_limit_exceeded",
        "paint_capability_gap",
        "paint_composite_invalid",
        "paint_composite_unsupported",
        "palette_change_missing",
        "palette_export_rejected",
        "palette_file_failed",
        "palette_frame_out_of_bounds",
        "palette_index_out_of_bounds",
        "palette_persistence_failed",
        "palette_quantization_rejected",
        "palette_transform_rejected",
        "partial_publication",
        "preparation_rejected",
        "process_failed",
        "process_start_failed",
        "process_timeout",
        "resource_incomplete",
        "runtime_incompatible",
        "selection_invalid",
        "selection_out_of_bounds",
        "slice_ambiguous",
        "slice_geometry_unsupported",
        "slice_missing",
        "sprite_copy_staging_failed",
        "sprite_crop_out_of_bounds",
        "sprite_flatten_unsupported_content",
        "sprite_geometry_unsupported_content",
        "tag_ambiguous",
        "tag_missing",
        "tag_range_out_of_bounds",
        "target_commit_failed",
        "tile_index_out_of_bounds",
        "tile_key_ambiguous",
        "tile_key_missing",
        "tile_lifecycle_invalid",
        "tile_region_out_of_bounds",
        "tile_snapshot_destination_required",
        "tilemap_cel_missing",
        "tilemap_frame_out_of_bounds",
        "tilemap_layer_required",
        "tilemap_region_invalid",
        "tileset_ambiguous",
        "tileset_export_unsupported",
        "tileset_in_use",
        "tileset_lifecycle_invalid",
        "tileset_missing",
    }


def test_installed_failure_registry_is_one_immutable_composition() -> None:
    from spa.contracts import public as contracts

    assert isinstance(FAILURE_CODES, MappingProxyType)
    assert "FAILURE_CODES" not in vars(contracts)
    assert "install_failure_codes" not in vars(contracts)
    assert "failure_registry" not in getsource(contracts)
    assert TargetCommitDetails.__module__ == "spa.contracts.mutation"


def test_registration_refuses_duplicate_invalid_and_unsupported_entries() -> None:
    spec = FAILURE_CODES["invalid_request"]
    with pytest.raises(ValueError, match="Duplicate"):
        register_failure_codes((spec, spec))
    with pytest.raises(ValueError, match="lower_snake_case"):
        register_failure_codes((replace(spec, code="INVALID_REQUEST"),))
    with pytest.raises(ValueError, match="Details"):
        register_failure_codes((replace(spec, details_type=FailureEnvelope),))


def test_failure_construction_derives_category_and_refuses_mismatch() -> None:
    details = RequestDetails(
        errors=[ValidationIssue(location=[], code="test", message="bad")]
    )
    outcome = registered_failure_envelope(
        "spa version",
        "invalid_request",
        "bad",
        details,
        applicable_codes=("invalid_request",),
    )
    assert outcome.category == "input"
    with pytest.raises(ValueError, match="Unknown Failure Code"):
        registered_failure_envelope(
            "spa version",
            "not_registered",
            "bad",
            details,
            applicable_codes=("invalid_request",),
        )
    with pytest.raises(ValueError, match="Details"):
        registered_failure_envelope(
            "spa version",
            "invalid_request",
            "bad",
            ProcessDetails(executable="x"),
            applicable_codes=("invalid_request",),
        )
    with pytest.raises(ValueError, match="not applicable"):
        registered_failure_envelope(
            "spa version",
            "process_start_failed",
            "bad",
            ProcessStartDetails(executable="x", exit_status=None),
            applicable_codes=("invalid_request",),
        )


def test_each_registered_code_has_a_constrained_public_schema() -> None:
    details_by_type = {
        ExportImageDetails: ExportImageDetails(reason="area"),
        AnimationExportDetails: AnimationExportDetails(
            reason="gif_duration", message="Frame is shorter than 10 ms"
        ),
        TilesetExportDetails: TilesetExportDetails(reason="tile_key_missing"),
        PartialPublicationDetails: PartialPublicationDetails(
            destinations=[
                PublishedArtifactDestination(
                    role="tileset-image",
                    path="atlas.png",
                    existed_before=False,
                    state="published",
                    replaced_existing=False,
                ),
                UnpublishedArtifactDestination(
                    role="map-data",
                    path="map.json",
                    existed_before=False,
                    state="not_published",
                ),
            ]
        ),
        PreparationDetails: PreparationDetails(reason="input", message="Invalid PNG"),
        ImageImportDetails: ImageImportDetails(
            path="input.png", reason="palette", message="Changed used index"
        ),
        TileInspectionDetails: TileInspectionDetails(
            target=TilesetTarget(tileset_index=1)
        ),
        TilemapRegionDetails: TilemapRegionDetails(
            target=LifecycleCelAddress(
                layer=LayerAddress(layer_path=[1]), frame_number=1
            ),
            reason="tile_cells_limit",
            message="Image exceeds the Tile Cell limit",
        ),
        TileLifecycleDetails: TileLifecycleDetails(
            target=TilesetTarget(tileset_index=1),
            reason="replacement_required",
            message="Removing a used Tile requires an explicit replacement",
        ),
        FilterIndexRejection: FilterIndexRejection.model_validate(
            {
                "reason": "Index outside Palette",
                "palette_basis": {
                    "frame_number": 2,
                    "palette_frame_number": 1,
                    "palette_size": 129,
                },
                "index_violations": [
                    {
                        "layer_path": [1],
                        "frame_number": 1,
                        "canvas_position": {"x": 0, "y": 0},
                        "source_index": 0,
                        "result_index": 255,
                    }
                ],
            }
        ),
        FilterRejection: FilterRejection(reason="selected Layer cannot edit pixels"),
        PalettePersistenceDetails: PalettePersistenceDetails(
            palette_frame_number=1,
            expected_palette_size=5,
            reopened_palette_size=256,
            reason="Native save/reopen changed Palette size",
        ),
        QuantizationDetails: QuantizationDetails(
            palette_frame_number=1,
            reason="index_out_of_bounds",
            original_palette_size=8,
            candidate_palette_size=2,
            index=3,
        ),
        PaletteExportDetails: PaletteExportDetails(
            reason="indexed_png_capacity", palette_size=257
        ),
        PaletteFileDetails: PaletteFileDetails(
            path="colors.gpl", reason="invalid", message="bad header"
        ),
        ColorModeMismatchDetails: ColorModeMismatchDetails(
            expected="rgb", actual="indexed"
        ),
        MatrixFailureDetails: MatrixFailureDetails(
            matrix=InstalledMatrix(kind="installed", id="missing"),
            reason="missing",
            matches=[],
        ),
        PaletteTransformDetails: PaletteTransformDetails(
            reason="growth_entries", palette_frame_number=1
        ),
        ProfileFileDetails: ProfileFileDetails(path="profile.icc", reason="invalid"),
        ProfileSourceDetails: ProfileSourceDetails(icc_color_space="Lab"),
        PaletteFrameDetails: PaletteFrameDetails(frame_number=6, frame_count=5),
        PaletteChangeDetails: PaletteChangeDetails(
            palette_frame_number=2, frame_count=5
        ),
        PaletteEntryDetails: PaletteEntryDetails(
            palette_frame_number=1, index=4, palette_size=4
        ),
        CompositeDetails: CompositeDetails(reason="Snapshot Color Mode differs"),
        CompositeCapabilityDetails: CompositeCapabilityDetails(
            gap=CapabilityGap(
                capability="spa paint composite: grayscale addition",
                aseprite_version="1.3.18.5-dev",
                reason="Native Addition selects Exclusion",
            )
        ),
        PaintCapabilityDetails: PaintCapabilityDetails(
            gap=CapabilityGap(
                capability="shading Ink",
                aseprite_version="1.3.18.5",
                reason="explicit Shade configuration unavailable",
            )
        ),
        SelectionDetails: SelectionDetails(reason="coverage outside Canvas Rectangle"),
        TilesetLifecycleDetails: TilesetLifecycleDetails(
            target=TilesetTarget(tileset_index=1),
            reason="grid_mismatch",
            message="Source and target Grid differ",
        ),
        TilesetInUseDetails: TilesetInUseDetails.model_validate(
            {
                "target": {"tileset_index": 1},
                "tileset": {
                    "tileset_index": 1,
                    "name": "terrain",
                    "base_index": 1,
                    "tile_count": 2,
                    "grid": {
                        "origin": {"x": 0, "y": 0},
                        "tile_size": {"width": 2, "height": 3},
                    },
                    "layers": [{"layer_path": [2], "layer_uuid": None, "name": "map"}],
                },
                "layers": [{"layer_path": [2], "layer_uuid": None, "name": "map"}],
            }
        ),
        SnapshotDetails: SnapshotDetails(reason="incompatible bounds"),
        RequestDetails: RequestDetails(errors=[]),
        NotFoundDetails: NotFoundDetails(requested_path=None, searched=[]),
        ResourceDetails: ResourceDetails(canonical_path="/aseprite", searched=[]),
        ProcessStartDetails: ProcessStartDetails(
            executable="/aseprite", exit_status=None
        ),
        ProcessDetails: ProcessDetails(executable="/aseprite"),
        KernelProtocolDetail: KernelProtocolDetail(response_path="/response.json"),
        KernelExecutionDetails: KernelExecutionDetails(
            response_path="/response.json", reason="refused"
        ),
        RuntimeCompatibilityDetails: RuntimeCompatibilityDetails(
            aseprite_version="old",
            lua_version="Lua 5.3",
            api_version=40,
            required_lua_language="Lua 5.4",
            minimum_api_version=41,
            missing_capabilities=["aseprite_runtime_introspection"],
        ),
        TargetCommitDetails: TargetCommitDetails(
            target_sprite_file="sprite.aseprite", reason="target_not_file"
        ),
        SpriteCopyStagingDetails: SpriteCopyStagingDetails(
            source_sprite_file="source.aseprite", target_sprite_file="copy.aseprite"
        ),
        ArtifactFileDetails: ArtifactFileDetails(
            path="image.png", reason="destination_exists"
        ),
        ArtifactVerificationDetails: ArtifactVerificationDetails(
            path="image.png", reason="content mismatch"
        ),
        SheetRejection: SheetRejection(reason="palette_mismatch"),
        LayerTargetDetails: LayerTargetDetails(
            address_role="target", address=LayerAddress(layer_path=[1])
        ),
        CelTargetDetails: CelTargetDetails(
            target=LifecycleCelAddress(
                layer=LayerAddress(layer_path=[1]), frame_number=1
            )
        ),
        CelFrameRangeDetails: CelFrameRangeDetails(from_frame=1, to_frame=2),
        ImageRotatePositionDetails: ImageRotatePositionDetails(
            target=LifecycleCelAddress(
                layer=LayerAddress(layer_path=[1]), frame_number=2
            ),
            coordinate_space="canvas-pixel",
            attempted_position=Point(x=-32774, y=32767),
            allowed_minimum=-32768,
            allowed_maximum=32767,
        ),
        TagTargetDetails: TagTargetDetails(address=TagAddress(tag_index=1)),
        SliceTargetDetails: SliceTargetDetails(address=SliceAddress(slice_index=1)),
        TagRangeDetails: TagRangeDetails(from_frame=1, to_frame=2, frame_count=1),
        SpriteUnsupportedContentDetails: SpriteUnsupportedContentDetails(
            source_sprite_file="sprite.aseprite",
            tileset_count=1,
            tilemap_layer_count=0,
        ),
        AuditLimitDetails: AuditLimitDetails(
            unit="coverage_observations",
            requested=1025,
            allowed_maximum=1024,
        ),
        SpriteGeometryUnsupportedDetails: SpriteGeometryUnsupportedDetails(
            source_sprite_file="sprite.aseprite",
            tileset_count=1,
            tilemap_layer_count=0,
            tilemap_cel_count=0,
            tilemap_image_count=0,
        ),
        SpriteCropBoundsDetails: SpriteCropBoundsDetails(
            rectangle=PositiveRectangle(x=3, y=1, width=2, height=2),
            canvas=Size(width=4, height=4),
        ),
    }
    for code, spec in FAILURE_CODES.items():
        schema = registered_failure_schema((code,), "spa info")
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(schema)
        details_schema = spec.details_type.model_json_schema()
        assert details_schema["properties"]["kind"]["const"] == spec.details_kind
        outcome = registered_failure_envelope(
            "spa info",
            code,
            "failed",
            details_by_type[spec.details_type],
            applicable_codes=(code,),
        ).model_dump(mode="json")
        validator.validate(outcome)
        assert not validator.is_valid(
            outcome | {"category": "input" if spec.category != "input" else "execution"}
        )
        wrong_details = (
            ProcessDetails(executable="/aseprite")
            if spec.details_type is RequestDetails
            else RequestDetails(errors=[])
        )
        assert not validator.is_valid(
            outcome | {"details": wrong_details.model_dump(mode="json")}
        )


def test_kernel_protocol_detail_does_not_expose_private_version() -> None:
    outcome = registered_failure_envelope(
        "spa info",
        "kernel_response_invalid",
        "invalid response",
        KernelProtocolDetail(response_path="/response.json"),
        applicable_codes=("kernel_response_invalid",),
    ).model_dump(mode="json")
    details = outcome["details"]
    assert outcome["category"] == "kernel_protocol"
    assert details["kind"] == "kernel_protocol"
    assert set(details) == {
        "kind",
        "response_path",
        "failed_step",
        "failed_operation",
    }
    assert details["failed_step"] is None
    assert details["failed_operation"] is None
    validator = Draft202012Validator(
        registered_failure_schema(("kernel_response_invalid",), "spa info")
    )
    validator.validate(outcome)
    assert not validator.is_valid(outcome | {"category": "protocol"})
    for field in ("protocol_version", "kernel_protocol_version"):
        assert not validator.is_valid(outcome | {"details": details | {field: 1}})


def test_process_start_failure_cannot_claim_a_process_exit_status() -> None:
    with pytest.raises(ValidationError):
        ProcessStartDetails(executable="/aseprite", exit_status=7)
    failure = registered_failure_envelope(
        "spa info",
        "process_start_failed",
        "launch denied",
        ProcessStartDetails(executable="/aseprite", exit_status=None),
        applicable_codes=("process_start_failed",),
    ).model_dump(mode="json")
    validator = Draft202012Validator(
        registered_failure_schema(("process_start_failed",), "spa info")
    )
    validator.validate(failure)
    assert not validator.is_valid(
        failure | {"details": failure["details"] | {"exit_status": 7}}
    )
    with pytest.raises(ValueError, match="Details"):
        registered_failure_envelope(
            "spa info",
            "process_start_failed",
            "launch denied",
            ProcessDetails(executable="/aseprite", exit_status=7),
            applicable_codes=("process_start_failed",),
        )


def test_failure_schema_refuses_unknown_and_duplicate_applicability() -> None:
    with pytest.raises(ValueError, match="Unknown Failure Code"):
        registered_failure_schema(("not_registered",), "spa")
    with pytest.raises(ValueError, match="unique"):
        registered_failure_schema(("invalid_request", "invalid_request"), "spa")


def test_failure_schema_shares_envelope_and_preserves_code_details_associations() -> (
    None
):
    schema = registered_failure_schema(
        ("invalid_request", "process_failed"), "spa info"
    )
    Draft202012Validator.check_schema(schema)
    assert schema["properties"]["operation"] == {"const": "spa info"}
    assert "message" in schema["properties"]
    assert all("message" not in branch["properties"] for branch in schema["oneOf"])
    validator = Draft202012Validator(schema)
    request_failure = {
        "status": "failure",
        "operation": "spa info",
        "code": "invalid_request",
        "category": "input",
        "message": "Invalid request",
        "details": {"kind": "invalid_request", "errors": []},
    }
    process_failure = request_failure | {
        "code": "process_failed",
        "category": "execution",
        "details": {"kind": "process", "executable": "/aseprite", "exit_status": 1},
    }
    for valid in (request_failure, process_failure):
        validator.validate(valid)
        for key in ("status", "operation", "code", "category", "message", "details"):
            assert not validator.is_valid({k: v for k, v in valid.items() if k != key})
        assert not validator.is_valid(valid | {"operation": "spa version"})
        assert not validator.is_valid(valid | {"extra": True})
    assert not validator.is_valid(request_failure | {"category": "execution"})
    assert not validator.is_valid(
        request_failure | {"details": process_failure["details"]}
    )
    assert not validator.is_valid(process_failure | {"code": "process_start_failed"})


def test_failure_schema_rejects_wrong_code_category_details_and_missing_fields() -> (
    None
):
    outcome = registered_failure_envelope(
        "spa version",
        "invalid_request",
        "bad",
        RequestDetails(
            errors=[ValidationIssue(location=[], code="test", message="bad")]
        ),
        applicable_codes=("invalid_request",),
    ).model_dump(mode="json")
    validator = Draft202012Validator(
        registered_failure_schema(("invalid_request",), "spa version")
    )
    validator.validate(outcome)
    for field, value in (
        ("code", "process_failed"),
        ("category", "execution"),
        ("details", {"kind": "process", "executable": "x"}),
    ):
        with pytest.raises(SchemaError):
            validator.validate(outcome | {field: value})
    for field in ("status", "code", "category"):
        changed = outcome.copy()
        del changed[field]
        with pytest.raises(SchemaError):
            validator.validate(changed)
    changed = outcome.copy()
    changed["details"] = {"errors": outcome["details"]["errors"]}
    with pytest.raises(SchemaError):
        validator.validate(changed)
    with pytest.raises(SchemaError):
        validator.validate(outcome | {"operation": "spa info"})


def test_descriptor_applicability_does_not_advertise_other_codes() -> None:
    by_name = {descriptor.name: descriptor for descriptor in OPERATIONS}
    assert by_name["version"].failure_codes == ("invalid_request",)
    assert set(by_name["info"].failure_codes) == {
        "invalid_request",
        "executable_not_found",
        "resource_incomplete",
        "process_start_failed",
        "process_timeout",
        "output_limit_exceeded",
        "process_failed",
        "kernel_response_missing",
        "kernel_response_invalid",
        "kernel_execution_failed",
        "runtime_incompatible",
    }
    assert by_name["schema"].failure_codes == by_name["info"].failure_codes
    failure = registered_failure_envelope(
        "spa info",
        "process_start_failed",
        "launch denied",
        ProcessStartDetails(executable="x", exit_status=None),
        applicable_codes=by_name["info"].failure_codes,
    ).model_dump(mode="json")
    Draft202012Validator(by_name["info"].schema(FAILURE_CODES).failure_schema).validate(
        failure
    )
    with pytest.raises(SchemaError):
        Draft202012Validator(
            by_name["version"].schema(FAILURE_CODES).failure_schema
        ).validate(failure)


def test_registry_and_access_applicability_are_closed_over_installed_producers() -> (
    None
):
    # run_cli currently produces only invalid_request before Descriptor selection.
    # A later Access code needs its own CLI producer witness in the same feature slice.
    assert ACCESS_FAILURE_CODES == ("invalid_request",)
    declared = set(ACCESS_FAILURE_CODES)
    for descriptor in OPERATIONS:
        declared.update(descriptor.failure_codes)
    assert set(FAILURE_CODES) == declared
    info = next(descriptor for descriptor in OPERATIONS if descriptor.name == "info")
    assert set(info.failure_codes) == {"invalid_request"} | {
        code for _, code in RUNTIME_ISSUE_CASES
    }
    access_schema = Draft202012Validator(
        registered_failure_schema(ACCESS_FAILURE_CODES, "spa")
    )
    access_failure = registered_failure_envelope(
        "spa",
        "invalid_request",
        "bad",
        RequestDetails(errors=[]),
        applicable_codes=ACCESS_FAILURE_CODES,
    ).model_dump(mode="json")
    access_schema.validate(access_failure)
    assert not access_schema.is_valid(access_failure | {"operation": "spa version"})
    other_failure = registered_failure_envelope(
        "spa",
        "process_start_failed",
        "failed",
        ProcessStartDetails(executable="x", exit_status=None),
        applicable_codes=info.failure_codes,
    ).model_dump(mode="json")
    assert not access_schema.is_valid(other_failure)


def test_descriptor_rejects_result_operation_identity_mismatch() -> None:
    version = next(
        descriptor for descriptor in OPERATIONS if descriptor.name == "version"
    )
    with pytest.raises(ValueError, match="Result Operation identity"):
        replace(version, name="renamed")


def test_descriptor_rejects_result_operation_with_stale_default() -> None:
    class RenamedResult(VersionResult):
        operation: Literal["spa renamed"] = "spa version"

    version = next(
        descriptor for descriptor in OPERATIONS if descriptor.name == "version"
    )
    with pytest.raises(ValueError, match="Result Operation identity"):
        replace(version, name="renamed", result_type=RenamedResult)


def test_runtime_descriptor_declares_compatibility_failure() -> None:
    info = next(descriptor for descriptor in OPERATIONS if descriptor.name == "info")

    with pytest.raises(ValueError, match="runtime_incompatible"):
        replace(info, failure_codes=("invalid_request",))


def test_application_refuses_failure_not_declared_by_selected_descriptor() -> None:
    version = next(
        descriptor for descriptor in OPERATIONS if descriptor.name == "version"
    )

    def launch_issue(_request: object, _probe: object) -> None:
        raise RuntimeIssue(
            "launch_failed", "failed", LaunchEvidence(executable="/aseprite")
        )

    misclassified = replace(version, execute=launch_issue)
    with pytest.raises(ValueError, match="not applicable to spa version"):
        dispatch(
            misclassified,
            None,
            {},
            operation_services(lambda _request: None),
            FAILURE_CODES,
        )


def test_application_refuses_result_outside_descriptor_contract() -> None:
    version = next(
        descriptor for descriptor in OPERATIONS if descriptor.name == "version"
    )
    wrong_result = replace(version, execute=lambda _request, _probe: VersionRequest())
    with pytest.raises(TypeError, match="Operation Result does not match spa version"):
        dispatch(
            wrong_result,
            None,
            {},
            operation_services(lambda _request: None),
            FAILURE_CODES,
        )

    wrong_failure = FailureEnvelope(
        operation="spa version",
        code="process_failed",
        category="execution",
        message="failed",
        details=ProcessDetails(executable="/aseprite", exit_status=7),
    )
    wrong_failure_result = replace(
        version, execute=lambda _request, _probe: wrong_failure
    )
    with pytest.raises(ValueError, match="not applicable to spa version"):
        dispatch(
            wrong_failure_result,
            None,
            {},
            operation_services(lambda _request: None),
            FAILURE_CODES,
        )


def test_runtime_issue_requires_kind_specific_private_evidence() -> None:
    with pytest.raises(TypeError, match="Invalid private evidence"):
        RuntimeIssue("launch_failed", "failed", {})


def _evidence_for(kind: str):
    if kind == "discovery_absent":
        return DiscoveryEvidence(requested_path=None, searched=[])
    if kind == "resources_absent":
        return ResourceEvidence(canonical_path="/aseprite", searched=[])
    if kind == "launch_failed":
        return LaunchEvidence(executable="/aseprite")
    if kind in {"deadline", "output_overflow", "process_failed", "exit_mismatch"}:
        return ProcessEvidence(executable="/aseprite", exit_status=13)
    if kind in {"response_absent", "response_malformed"}:
        return ResponseEvidence(response_path="/response.json")
    if kind == "handler_rejected":
        return HandlerEvidence(response_path="/response.json", reason="refused")
    if kind == "postcondition_failed":
        return PostconditionEvidence(
            response_path="/response.json", reason="incomplete"
        )
    if kind == "runtime_incompatible":
        return RuntimeCompatibilityEvidence(
            aseprite_version="old",
            lua_version="Lua 5.3",
            api_version=40,
            required_lua_language="Lua 5.4",
            minimum_api_version=41,
            missing_capabilities=("aseprite_runtime_introspection",),
        )
    raise AssertionError(kind)


def test_every_runtime_issue_kind_has_a_classification_case() -> None:
    kinds = [kind for kind, _ in RUNTIME_ISSUE_CASES] + list(OWNED_RUNTIME_ISSUE_CASES)
    assert len(kinds) == len(set(kinds))
    assert set(kinds) == set(get_args(RuntimeIssueKind))
    for module, test in OWNED_RUNTIME_ISSUE_CASES.values():
        assert callable(getattr(import_module(module), test, None)), (module, test)


@pytest.mark.parametrize(("kind", "expected_code"), RUNTIME_ISSUE_CASES)
def test_every_runtime_issue_kind_classifies_to_a_registered_failure(
    kind: str, expected_code: str
) -> None:
    info = next(descriptor for descriptor in OPERATIONS if descriptor.name == "info")
    outcome = _runtime_failure(
        info,
        RuntimeIssue(kind, "failed", _evidence_for(kind)),
        FAILURE_CODES,
    )
    assert outcome.code == expected_code
    assert outcome.category == FAILURE_CODES[expected_code].category
    Draft202012Validator(info.schema(FAILURE_CODES).failure_schema).validate(
        outcome.model_dump(mode="json")
    )


def test_current_failure_facts_survive_public_guidance_cleanup() -> None:
    info = next(descriptor for descriptor in OPERATIONS if descriptor.name == "info")
    executable = "/caller/issue #251/aseprite"
    diagnostics = Diagnostics(
        stdout="Caller output: see docs/ADR-1234.md",
        stderr="Caller script says probe failed",
        exit_status=13,
    )
    outcome = _runtime_failure(
        info,
        RuntimeIssue(
            "process_failed",
            "Aseprite exited with status 13",
            ProcessEvidence(executable=executable, exit_status=13),
            diagnostics,
        ),
        FAILURE_CODES,
    )
    assert outcome.message == "Aseprite exited with status 13"
    assert outcome.details == ProcessDetails(executable=executable, exit_status=13)
    assert outcome.diagnostics == diagnostics
    assert outcome.code == "process_failed" and outcome.category == "execution"
    assert "evidence" not in outcome.model_dump()
    Draft202012Validator(info.schema(FAILURE_CODES).failure_schema).validate(
        outcome.model_dump(mode="json")
    )


def test_target_commit_failure_is_owned_by_mutating_sprite_operation() -> None:
    create = next(
        descriptor for descriptor in OPERATIONS if descriptor.name == "sprite create"
    )
    outcome = _runtime_failure(
        create,
        RuntimeIssue(
            "target_commit_failed",
            "failed",
            TargetCommitEvidence(
                target_sprite_file="sprite.aseprite", reason="target_not_file"
            ),
        ),
        FAILURE_CODES,
    )
    assert outcome.code == "target_commit_failed"
    assert outcome.details == TargetCommitDetails(
        target_sprite_file="sprite.aseprite", reason="target_not_file"
    )
    Draft202012Validator(create.schema(FAILURE_CODES).failure_schema).validate(
        outcome.model_dump(mode="json")
    )


@pytest.mark.parametrize(
    ("kind", "evidence", "details_type"),
    [
        (
            "artifact_file_failed",
            ArtifactFileEvidence("image.png", "destination_exists"),
            ArtifactFileDetails,
        ),
        (
            "artifact_verification_failed",
            ArtifactVerificationEvidence("image.png", "content mismatch"),
            ArtifactVerificationDetails,
        ),
    ],
)
def test_export_failures_are_owned_by_export_image(
    kind: str,
    evidence: ArtifactFileEvidence | ArtifactVerificationEvidence,
    details_type: type[ArtifactFileDetails] | type[ArtifactVerificationDetails],
) -> None:
    export = next(
        descriptor for descriptor in OPERATIONS if descriptor.name == "export image"
    )
    outcome = _runtime_failure(
        export, RuntimeIssue(kind, "failed", evidence), FAILURE_CODES
    )
    assert outcome.code == kind
    assert isinstance(outcome.details, details_type)
    Draft202012Validator(export.schema(FAILURE_CODES).failure_schema).validate(
        outcome.model_dump(mode="json")
    )


@pytest.mark.parametrize("replacement", [{}, {"replaced_existing": None}])
def test_published_destination_requires_replacement_fact_in_model_and_schema(
    replacement: dict,
) -> None:
    destination = {
        "role": "tileset-image",
        "path": "/atlas.png",
        "existed_before": False,
        "state": "published",
    }
    invalid = {
        "kind": "partial_publication",
        "destinations": [destination | replacement],
    }
    validator = Draft202012Validator(PartialPublicationDetails.model_json_schema())
    assert not validator.is_valid(invalid)
    with pytest.raises(ValidationError):
        PartialPublicationDetails.model_validate_json(json.dumps(invalid))
    for replaced in (False, True):
        valid = {
            "kind": "partial_publication",
            "destinations": [destination | {"replaced_existing": replaced}],
        }
        validator.validate(valid)
        assert PartialPublicationDetails.model_validate_json(json.dumps(valid))
