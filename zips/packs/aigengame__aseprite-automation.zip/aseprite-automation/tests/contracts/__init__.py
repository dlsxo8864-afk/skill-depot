"""Published Language contract tests."""
