"""SPA test suite."""
