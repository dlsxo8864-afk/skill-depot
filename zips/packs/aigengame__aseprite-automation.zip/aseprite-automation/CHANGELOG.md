# Changelog

## [0.5.2](https://github.com/aigengame/aseprite-automation/compare/v0.5.1...v0.5.2) (2026-10-24)


### Bug Fixes

* **export:** check export gif destinations before the first Kernel invocation ([#286](https://github.com/aigengame/aseprite-automation/issues/286)) ([cca13c7](https://github.com/aigengame/aseprite-automation/commit/cca13c71315d0f288e7be099f43b5814ca3699e1)), closes [#279](https://github.com/aigengame/aseprite-automation/issues/279)
* **mcp:** deepen the CLI invocation module that owns process-tree cleanup ([#274](https://github.com/aigengame/aseprite-automation/issues/274)) ([d000506](https://github.com/aigengame/aseprite-automation/commit/d0005064acb6749c76e5f31e5e4e2448f1c4bcd6)), closes [#269](https://github.com/aigengame/aseprite-automation/issues/269)
* **release:** wait for PyPI file visibility ([#275](https://github.com/aigengame/aseprite-automation/issues/275)) ([58ec4b0](https://github.com/aigengame/aseprite-automation/commit/58ec4b04b14020766b38d3f0b19086f0351ae1dc))

## [0.5.1](https://github.com/aigengame/aseprite-automation/compare/v0.5.0...v0.5.1) (2026-10-17)


### Bug Fixes

* **ci:** retire owned Windows native shard trees ([#263](https://github.com/aigengame/aseprite-automation/issues/263)) ([077bbf5](https://github.com/aigengame/aseprite-automation/commit/077bbf5b4fa1a673a9723d732e3afe55c8bac874)), closes [#231](https://github.com/aigengame/aseprite-automation/issues/231)
* **color:** preserve Windows absolute dithering matrix paths ([#257](https://github.com/aigengame/aseprite-automation/issues/257)) ([4bcfa32](https://github.com/aigengame/aseprite-automation/commit/4bcfa32d209dfece3074fdaf0997e754065d0cb0))
* **mcp:** retire owned Windows invocation children ([#264](https://github.com/aigengame/aseprite-automation/issues/264)) ([f265f3c](https://github.com/aigengame/aseprite-automation/commit/f265f3c59b57a0ad2981221d13f2761b0c846787)), closes [#233](https://github.com/aigengame/aseprite-automation/issues/233)

## [0.5.0](https://github.com/aigengame/aseprite-automation/compare/v0.4.0...v0.5.0) (2026-10-15)


### ⚠ BREAKING CHANGES

* **discovery:** Discovery no longer emits minimum_aseprite_version or invocation_schema.properties.argv. Read request_schema and runtime_requirements directly.

### Bug Fixes

* **ci:** allow hosted admission to read Release drafts ([#207](https://github.com/aigengame/aseprite-automation/issues/207)) ([3ee9973](https://github.com/aigengame/aseprite-automation/commit/3ee9973f5bcbbd093711ebe4ed5b4755bffcca87))
* **cli:** explain commands and add help navigation ([#249](https://github.com/aigengame/aseprite-automation/issues/249)) ([8776602](https://github.com/aigengame/aseprite-automation/commit/8776602ebde13404f22f41c9987443bdeb84de19))


### Code Refactoring

* **discovery:** compact machine contracts and runtime facts ([#250](https://github.com/aigengame/aseprite-automation/issues/250)) ([026a6bc](https://github.com/aigengame/aseprite-automation/commit/026a6bcf783f85626201743843025002f33c2e82))

## [0.4.0](https://github.com/aigengame/aseprite-automation/compare/v0.3.0...v0.4.0) (2026-10-10)


### ⚠ BREAKING CHANGES

* **delivery:** export image requires explicit area, layer composition, and composition color mode choices; resolved area and composition facts are structured objects.

### Features

* **delivery:** add verified sprite sheet export path ([17313a6](https://github.com/aigengame/aseprite-automation/commit/17313a66c45d14979191706a1b46d9b3f62b2e3d))
* **delivery:** encode native Tileset atlases with keyed map metadata ([c9e81ab](https://github.com/aigengame/aseprite-automation/commit/c9e81ab252dffa64d9f36cda4185554c9ba63d0e))
* **delivery:** expand static PNG export controls ([#185](https://github.com/aigengame/aseprite-automation/issues/185)) ([aee970d](https://github.com/aigengame/aseprite-automation/commit/aee970dfd6f1be3ecd8818dfe4efda8ce445242c))
* **delivery:** export verified native Sprite Sheets ([ee18c71](https://github.com/aigengame/aseprite-automation/commit/ee18c7189629800336eedf4467c252aa944b17e3))
* **delivery:** export verified Tileset atlases and map data ([26cd1de](https://github.com/aigengame/aseprite-automation/commit/26cd1de664329c228a170cb349f3954834db5103))
* **delivery:** publish bounded Artifact sets with partial failure states ([5ba868b](https://github.com/aigengame/aseprite-automation/commit/5ba868b51d15d91bd16e79e5a52b06109c2bbe1d))
* **delivery:** verify and publish Tileset atlas and map pairs ([51114be](https://github.com/aigengame/aseprite-automation/commit/51114bebe13c155bcfbce82d859bf2bc9d7ccb12))
* **delivery:** verify sprite sheet composition and metadata ([865e1f9](https://github.com/aigengame/aseprite-automation/commit/865e1f97179eed232912af7faf4929d0461d9e01))
* **export:** add verified GIF and PNG sequence delivery ([fd44478](https://github.com/aigengame/aseprite-automation/commit/fd444781bffcb1ba646ce05478552c866e8759a7))
* **export:** decode GIF and sequence PNG artifacts independently ([cb621e6](https://github.com/aigengame/aseprite-automation/commit/cb621e6903dede226075503ab21f64d8bc80edad))
* **export:** deliver verified RGB PNG sequence tracer ([e5ea1ba](https://github.com/aigengame/aseprite-automation/commit/e5ea1ba5be124b83eb796d179d5538f1e9037ed9))
* **export:** verify Tag playback and native GIF and PNG representations ([356fab9](https://github.com/aigengame/aseprite-automation/commit/356fab9e9fc6142be9cc2a96c5393fd52a48300f))
* **mcp:** expose schema-derived stdio tools and PNG content ([#188](https://github.com/aigengame/aseprite-automation/issues/188)) ([7fabeab](https://github.com/aigengame/aseprite-automation/commit/7fabeabd45d6450e752cfeebb95035e398aca72a))
* **release:** publish SPA to PyPI as sprite-automation ([#191](https://github.com/aigengame/aseprite-automation/issues/191)) ([49998d6](https://github.com/aigengame/aseprite-automation/commit/49998d68367c7be2913f63b1b7140fb341273d87))
* **script:** run exact caller-owned Lua outside core operations ([#184](https://github.com/aigengame/aseprite-automation/issues/184)) ([ec7fd14](https://github.com/aigengame/aseprite-automation/commit/ec7fd148d1957cfde22485950d01e152fd68bcb3))


### Bug Fixes

* **color:** replace bundled Apple P3 with a redistributable reference ([#195](https://github.com/aigengame/aseprite-automation/issues/195)) ([f93dcb0](https://github.com/aigengame/aseprite-automation/commit/f93dcb0bb8f7380e2c4cf6a2f4db8053628fd1a4))
* **contracts:** require replacement facts for published artifacts ([9ddaa6e](https://github.com/aigengame/aseprite-automation/commit/9ddaa6e99296e350a46392e606789bda734190d9)), closes [#50](https://github.com/aigengame/aseprite-automation/issues/50)
* **delivery:** clean sprite sheet staging after native interruption ([0bd12a5](https://github.com/aigengame/aseprite-automation/commit/0bd12a534f0868f31175a9ca348cce2499f3f41d))
* **delivery:** name native ICC copies before PNG encoding ([3a78a00](https://github.com/aigengame/aseprite-automation/commit/3a78a00aaf4a4ffac8756326b02b0ba6bc53ff9d))
* **delivery:** report the allowed atlas dimension range ([7a31a75](https://github.com/aigengame/aseprite-automation/commit/7a31a75f990eb090be14d991d711026cc6dd0e2c)), closes [#50](https://github.com/aigengame/aseprite-automation/issues/50)
* **delivery:** supply missing ICC names before atlas encoding ([245e364](https://github.com/aigengame/aseprite-automation/commit/245e364ee948f6aa2a1f76e49ae7eb9cd37ba420))
* **export:** close publication and consumer review gaps ([ba06afa](https://github.com/aigengame/aseprite-automation/commit/ba06afacd202e9a7ccc17b4ea0d5a765441f5fbc))
* **export:** keep sequence directories outside native formatting ([03a635d](https://github.com/aigengame/aseprite-automation/commit/03a635d14cf02f9cfeb6b53d0f19952829b08954))
* **export:** name private ICC profiles for headless PNG encoding ([a0edd12](https://github.com/aigengame/aseprite-automation/commit/a0edd12ef1a6ca417529867e600e77e9038f43d3))
* **export:** validate resolved playback and native destination expansion ([e62eed4](https://github.com/aigengame/aseprite-automation/commit/e62eed4b894a66c6e22bb5211634b1c28065f996))


### Performance Improvements

* **tile:** avoid repeated native Key scans during reorder ([#203](https://github.com/aigengame/aseprite-automation/issues/203)) ([2daa7f3](https://github.com/aigengame/aseprite-automation/commit/2daa7f36cfa550313562c80bb539ca827b678be0)), closes [#202](https://github.com/aigengame/aseprite-automation/issues/202)

## [0.3.0](https://github.com/aigengame/aseprite-automation/compare/v0.2.0...v0.3.0) (2026-10-05)

> Withdrawn before publication. Native verification did not pass. The historical
> tag retains the original reviewed commit; no GitHub Release or PyPI upload was
> published. See [release reconciliation](docs/releasing.md#withdrawn-pre-pypi-release).


### Features

* **animation:** audit declared coverage and compare frames with verified preview ([d4fa466](https://github.com/aigengame/aseprite-automation/commit/d4fa4661c54b8a15ddc4736b02f1cece8e388994))
* **animation:** audit structure, compare frames, and export continuity preview ([a5df60a](https://github.com/aigengame/aseprite-automation/commit/a5df60a0a8617268f1e4d0494b78c83a1dc86d18))
* **cel:** add native Cel relationship mutations ([cecff51](https://github.com/aigengame/aseprite-automation/commit/cecff517e5240a8a9bb88c84021e29fdf0689961))
* **cel:** add native Cel relationship mutations ([c3c5d4e](https://github.com/aigengame/aseprite-automation/commit/c3c5d4e37567ab25d16231ac565ac4beca74c47b))
* **cel:** allow explicit initial Image size ([#106](https://github.com/aigengame/aseprite-automation/issues/106)) ([#134](https://github.com/aigengame/aseprite-automation/issues/134)) ([ec6a096](https://github.com/aigengame/aseprite-automation/commit/ec6a096f61d264bbc32611be64d12e875887eb34))
* **cel:** implement exact Cel inspection and lifecycle ([#13](https://github.com/aigengame/aseprite-automation/issues/13)) ([#94](https://github.com/aigengame/aseprite-automation/issues/94)) ([40b8ff9](https://github.com/aigengame/aseprite-automation/commit/40b8ff905a2ef9f3c41ca18861b8940e9da9f0cb))
* **cel:** support explicit Tilemap Cel creation ([#171](https://github.com/aigengame/aseprite-automation/issues/171)) ([da72fd2](https://github.com/aigengame/aseprite-automation/commit/da72fd2626ed54a323130e4de485f08a4c5aebc8))
* **color:** assign and convert native Color Profiles ([#34](https://github.com/aigengame/aseprite-automation/issues/34)) ([#151](https://github.com/aigengame/aseprite-automation/issues/151)) ([56fcf84](https://github.com/aigengame/aseprite-automation/commit/56fcf844066c47fbac92c49cfb3a3dad161d9f6e))
* deliver native Despeckle and Convolution discovery ([#160](https://github.com/aigengame/aseprite-automation/issues/160)) ([77c31bd](https://github.com/aigengame/aseprite-automation/commit/77c31bdc5d004be7673080967d30e1ca791c736d))
* **example:** deliver wizard assets and playable target practice ([#99](https://github.com/aigengame/aseprite-automation/issues/99)) ([e4ce2f5](https://github.com/aigengame/aseprite-automation/commit/e4ce2f585c36bb3c349f7f81bb4953ced543a5f0))
* **example:** validate the hybrid wizard animation workflow ([#101](https://github.com/aigengame/aseprite-automation/issues/101)) ([324f691](https://github.com/aigengame/aseprite-automation/commit/324f6912e5f5f96197cc7221b108586fe0ddf670))
* **filter:** add Color Curve and Replace Color ([#158](https://github.com/aigengame/aseprite-automation/issues/158)) ([0bdf1d9](https://github.com/aigengame/aseprite-automation/commit/0bdf1d9ee2ad8421508cc9344a8e1af193c963a0))
* **filter:** add native brightness and contrast applications ([#154](https://github.com/aigengame/aseprite-automation/issues/154)) ([426fa46](https://github.com/aigengame/aseprite-automation/commit/426fa46bd3fdf35d6c409cff69578f006b54d8f3))
* **filter:** add native Invert Color and Outline ([#38](https://github.com/aigengame/aseprite-automation/issues/38)) ([#159](https://github.com/aigengame/aseprite-automation/issues/159)) ([27f5f01](https://github.com/aigengame/aseprite-automation/commit/27f5f0101349e3c9521ce46e8be29bd15e9d2272))
* **filter:** apply native hue saturation and alpha adjustments ([#155](https://github.com/aigengame/aseprite-automation/issues/155)) ([8f2af5c](https://github.com/aigengame/aseprite-automation/commit/8f2af5cf606f3656cfe0e01f7a3f7bef4b8faba5)), closes [#36](https://github.com/aigengame/aseprite-automation/issues/36)
* **filter:** support Manual Tilemap brightness and contrast ([#156](https://github.com/aigengame/aseprite-automation/issues/156)) ([15c2f6a](https://github.com/aigengame/aseprite-automation/commit/15c2f6acce157b38b736b63e4bdb9f7cabd37127))
* **frame:** edit, move, and remove addressed Frames ([#93](https://github.com/aigengame/aseprite-automation/issues/93)) ([7958178](https://github.com/aigengame/aseprite-automation/commit/79581780e06bfa3b0524eba49008b18e9702f1fc))
* **frame:** implement Frame inspection and authoring ([#11](https://github.com/aigengame/aseprite-automation/issues/11)) ([#88](https://github.com/aigengame/aseprite-automation/issues/88)) ([0278918](https://github.com/aigengame/aseprite-automation/commit/02789186520747cc6378748a1ed25763c867c173))
* **image:** add Cel-targeted resize with explicit placement ([#98](https://github.com/aigengame/aseprite-automation/issues/98)) ([b19a249](https://github.com/aigengame/aseprite-automation/commit/b19a249674cbb8d9863cf6c5b6616d213063dd19))
* **image:** flip and quarter-turn Images ([#23](https://github.com/aigengame/aseprite-automation/issues/23)) ([#112](https://github.com/aigengame/aseprite-automation/issues/112)) ([1bec7cf](https://github.com/aigengame/aseprite-automation/commit/1bec7cf8c8db8512e11b7deae588244abba0733c))
* **image:** implement crop and canvas resize ([#22](https://github.com/aigengame/aseprite-automation/issues/22)) ([#113](https://github.com/aigengame/aseprite-automation/issues/113)) ([d230c0b](https://github.com/aigengame/aseprite-automation/commit/d230c0b1dd402e3ffe64d265ff1417716a5e6b87))
* **image:** import compatible external PNG into empty Cel slots ([#169](https://github.com/aigengame/aseprite-automation/issues/169)) ([9cac1d9](https://github.com/aigengame/aseprite-automation/commit/9cac1d9cc8f028301daaff7ee7780e78eb08846a))
* **image:** preserve nonzero Indexed composite masks ([#122](https://github.com/aigengame/aseprite-automation/issues/122)) ([ca5a09d](https://github.com/aigengame/aseprite-automation/commit/ca5a09da3ac0c6c23ae868b88049b2dd4956fd70))
* **image:** read and replace canonical snapshots ([#114](https://github.com/aigengame/aseprite-automation/issues/114)) ([f1ebf9c](https://github.com/aigengame/aseprite-automation/commit/f1ebf9c1ef91fbf9388e8e527614109f39bab509))
* inspect and edit Palette Changes ([#30](https://github.com/aigengame/aseprite-automation/issues/30)) ([#148](https://github.com/aigengame/aseprite-automation/issues/148)) ([b68bdbe](https://github.com/aigengame/aseprite-automation/commit/b68bdbeb2969f227af22fc8de20d220b474292ac))
* **layer:** add exact Layer addressing and creation ([#87](https://github.com/aigengame/aseprite-automation/issues/87)) ([e9f4d8c](https://github.com/aigengame/aseprite-automation/commit/e9f4d8cab8cc326949f5074bb6f79883da7092d8))
* **layer:** convert between Transparent and Background Layers ([#92](https://github.com/aigengame/aseprite-automation/issues/92)) ([f74413f](https://github.com/aigengame/aseprite-automation/commit/f74413f9f73d18dc06b9212544d8e5592d99a4fc))
* **layer:** implement exact Layer mutations ([#89](https://github.com/aigengame/aseprite-automation/issues/89)) ([9ba6413](https://github.com/aigengame/aseprite-automation/commit/9ba64131b4bca7fbb1306bfa179cdf8ca7ab9881))
* **motion:** author bounded Cel position and opacity curves ([#123](https://github.com/aigengame/aseprite-automation/issues/123)) ([9c10165](https://github.com/aigengame/aseprite-automation/commit/9c10165f0cca3f770163eeb2fa926981e994add8))
* native Sprite Color Mode conversion and Dithering ([#33](https://github.com/aigengame/aseprite-automation/issues/33)) ([#150](https://github.com/aigengame/aseprite-automation/issues/150)) ([e8ef4f6](https://github.com/aigengame/aseprite-automation/commit/e8ef4f66b0886ea9a7c624f92aa80830141c9911))
* **paint:** add native Contour and Blur with explicit Gradient gap ([#130](https://github.com/aigengame/aseprite-automation/issues/130)) ([bc57c75](https://github.com/aigengame/aseprite-automation/commit/bc57c757a0d7a162d89b8873984d98193f312102)), closes [#28](https://github.com/aigengame/aseprite-automation/issues/28)
* **paint:** add native Fill, Pencil, and Eraser operations ([#131](https://github.com/aigengame/aseprite-automation/issues/131)) ([d643600](https://github.com/aigengame/aseprite-automation/commit/d643600f3ef699318fe043945eca952ddd4c4dab)), closes [#27](https://github.com/aigengame/aseprite-automation/issues/27)
* **paint:** add native line, rectangle, and ellipse operations ([#127](https://github.com/aigengame/aseprite-automation/issues/127)) ([bc8a761](https://github.com/aigengame/aseprite-automation/commit/bc8a76175484eb515e2b3203f0834997130d988d))
* **paint:** composite raster snapshots through native BlendMode ([#128](https://github.com/aigengame/aseprite-automation/issues/128)) ([f7fda69](https://github.com/aigengame/aseprite-automation/commit/f7fda6961c6443d80baa7caf12236bb8cae5df8c)), closes [#25](https://github.com/aigengame/aseprite-automation/issues/25)
* **paint:** expose native tool capability gaps ([#29](https://github.com/aigengame/aseprite-automation/issues/29)) ([#129](https://github.com/aigengame/aseprite-automation/issues/129)) ([4446b2f](https://github.com/aigengame/aseprite-automation/commit/4446b2faa0d96c87b325c61e13ea0146693f12bd))
* **palette:** import, export, and quantize Palettes ([#153](https://github.com/aigengame/aseprite-automation/issues/153)) ([b80c255](https://github.com/aigengame/aseprite-automation/commit/b80c2554c0b17c2f179de215649db53c1a4a906d))
* **palette:** remap, reorder, and resize palette entries ([#149](https://github.com/aigengame/aseprite-automation/issues/149)) ([89be32d](https://github.com/aigengame/aseprite-automation/commit/89be32d68dea092a422d90cf0ec6eaf24b116712))
* **plan:** support existing Cel property updates ([#119](https://github.com/aigengame/aseprite-automation/issues/119)) ([4c684e2](https://github.com/aigengame/aseprite-automation/commit/4c684e2d29613871d72ebf9ca00c8c200b9f9440))
* **preparation:** prepare and verify frozen rasters ([#173](https://github.com/aigengame/aseprite-automation/issues/173)) ([a66fade](https://github.com/aigengame/aseprite-automation/commit/a66fadeb6463d19dd2696813db72bbbed1e12554))
* **raster:** report evidence-backed native text capability gap ([#172](https://github.com/aigengame/aseprite-automation/issues/172)) ([07ad183](https://github.com/aigengame/aseprite-automation/commit/07ad1833fb56d5dcba062fce6731242c4a03baa8))
* **selection:** author, transform and publish explicit Selection values ([#120](https://github.com/aigengame/aseprite-automation/issues/120)) ([5ca6be7](https://github.com/aigengame/aseprite-automation/commit/5ca6be7e9bab10a0b79b24616938f8ec50bf082a))
* **slice:** inspect complete keys and author bounded slices ([#167](https://github.com/aigengame/aseprite-automation/issues/167)) ([a5c8b84](https://github.com/aigengame/aseprite-automation/commit/a5c8b84958c222fdd57bbc8da5bbeb918bbfdcb5))
* **sprite:** copy, flatten, and validate Sprites ([#17](https://github.com/aigengame/aseprite-automation/issues/17)) ([#90](https://github.com/aigengame/aseprite-automation/issues/90)) ([f6d9760](https://github.com/aigengame/aseprite-automation/commit/f6d976004f7856c6b86e81ecc57771d569aefaf7))
* **sprite:** resize and crop explicit canvas geometry ([#16](https://github.com/aigengame/aseprite-automation/issues/16)) ([c4b223a](https://github.com/aigengame/aseprite-automation/commit/c4b223acaaf89f594c8474b7a15c10a005907252))
* **sprite:** resize and crop explicit canvas geometry ([#16](https://github.com/aigengame/aseprite-automation/issues/16)) ([6f833e5](https://github.com/aigengame/aseprite-automation/commit/6f833e575c094626e7012686e7786b108b081575))
* **tag:** author and inspect stored Tag facts ([#15](https://github.com/aigengame/aseprite-automation/issues/15)) ([#91](https://github.com/aigengame/aseprite-automation/issues/91)) ([0ed4ff3](https://github.com/aigengame/aseprite-automation/commit/0ed4ff3f3fd0a6511f895d3e256283cf935ba6d6))
* **tile:** add keyed Tile lifecycle and placement remapping ([#174](https://github.com/aigengame/aseprite-automation/issues/174)) ([b3c8c31](https://github.com/aigengame/aseprite-automation/commit/b3c8c31b66104558f8f654f8daed0d0a0ed5783c)), closes [#43](https://github.com/aigengame/aseprite-automation/issues/43)
* **tile:** create Tilemap Layers with explicit Tileset intent ([#170](https://github.com/aigengame/aseprite-automation/issues/170)) ([a35b0ba](https://github.com/aigengame/aseprite-automation/commit/a35b0ba7d267033ce63eb9caa7ad9c82febd1c96))
* **tile:** inspect and validate Tilesets and Tilemaps ([#168](https://github.com/aigengame/aseprite-automation/issues/168)) ([bd56f02](https://github.com/aigengame/aseprite-automation/commit/bd56f0277a390ddfb014080c3927a165eab66b32))
* **tilemap:** read and write keyed Tilemap regions ([#177](https://github.com/aigengame/aseprite-automation/issues/177)) ([89bc0e1](https://github.com/aigengame/aseprite-automation/commit/89bc0e147acacf998d909290369e2e16d2ab4ac8))
* **tile:** rebind and remove Tilesets in atomic Plans ([#176](https://github.com/aigengame/aseprite-automation/issues/176)) ([983f695](https://github.com/aigengame/aseprite-automation/commit/983f6955ed4a97bf720a638b3396b340f98e5c08))


### Bug Fixes

* **animation:** close audit and preview review gaps ([d676454](https://github.com/aigengame/aseprite-automation/commit/d676454eff4e4ee04dfb63e43054ed2f0550f080))
* **animation:** verify exact audit coverage and native effective alpha ([ed909c9](https://github.com/aigengame/aseprite-automation/commit/ed909c9b2782476a78ac86bd27208afd410541bf))
* **cel:** avoid shadowing Lua refusal state ([30d417f](https://github.com/aigengame/aseprite-automation/commit/30d417f92b349b8e0b1787bd997570be19f1abee))
* **cel:** report exact relationship mutation scope ([21f0418](https://github.com/aigengame/aseprite-automation/commit/21f041809348b27ac11827232fa7a0c8d7734f2c))
* **cel:** validate relationship preconditions and failure roles ([b4936ad](https://github.com/aigengame/aseprite-automation/commit/b4936ad201637b7b8f3065801b1a9f9d71a3cb78))
* **export:** classify unverified publication identity ([7ce98e5](https://github.com/aigengame/aseprite-automation/commit/7ce98e5bdee677394eb003b1aa994fdf9c2fe9fa))
* **filter:** centralize target and Selection evidence validation ([#166](https://github.com/aigengame/aseprite-automation/issues/166)) ([cac2557](https://github.com/aigengame/aseprite-automation/commit/cac2557f550a295e358e1b9d7ace84b97417e3aa)), closes [#164](https://github.com/aigengame/aseprite-automation/issues/164)
* **sprite:** avoid unregistered Lua Size global ([9eb17bc](https://github.com/aigengame/aseprite-automation/commit/9eb17bc9825c898d80207105a43dc4692a9c17b8))
* **sprite:** report crop effects from Lua kernel ([b2d8a7e](https://github.com/aigengame/aseprite-automation/commit/b2d8a7ef6987563deed311b7a3d1a96f25630bba))
* **sprite:** report only clipped non-reference cel content ([54b5c02](https://github.com/aigengame/aseprite-automation/commit/54b5c02b9fbba7bed72c434004fb9e22ac94d6b9))


### Reverts

* **ci:** restore native E2E policy ([478ae2f](https://github.com/aigengame/aseprite-automation/commit/478ae2f9e0a59d5a9b7f8d23f3176dcc767b1ba3))

## [0.2.0](https://github.com/aigengame/aseprite-automation/compare/v0.1.0...v0.2.0) (2026-09-23)


### Features

* **export:** publish a verified RGB PNG Image Artifact ([#77](https://github.com/aigengame/aseprite-automation/issues/77)) ([39a4e90](https://github.com/aigengame/aseprite-automation/commit/39a4e9042dda627bce3a778e2bcc1cdda19b95a8))
* **paint:** apply and verify canonical pixel patches ([#76](https://github.com/aigengame/aseprite-automation/issues/76)) ([e53bd19](https://github.com/aigengame/aseprite-automation/commit/e53bd194245375cb1873bda2a2a262a47fc17f6e))
* **plan:** execute bounded single-Sprite operation plans ([#79](https://github.com/aigengame/aseprite-automation/issues/79)) ([672b562](https://github.com/aigengame/aseprite-automation/commit/672b56242154a9a61351f0c655dbca40feae9ada))
* **runtime:** enforce Aseprite Lua compatibility ([#74](https://github.com/aigengame/aseprite-automation/issues/74)) ([2bd6747](https://github.com/aigengame/aseprite-automation/commit/2bd6747f619e07d31a298ac2ac4ebba5c7374a2b)), closes [#62](https://github.com/aigengame/aseprite-automation/issues/62)
* **sprite:** create, reopen, and inspect RGB sprites ([#75](https://github.com/aigengame/aseprite-automation/issues/75)) ([a287134](https://github.com/aigengame/aseprite-automation/commit/a28713400e4ef47d30bbafcfede21a397417b845))


### Bug Fixes

* **mutation:** unify Source and Target publication identity ([#84](https://github.com/aigengame/aseprite-automation/issues/84)) ([e77b37e](https://github.com/aigengame/aseprite-automation/commit/e77b37e47a0d9a7672a69c06e5954b6c84030657))
* **paint:** reject source aliases to target entries ([#82](https://github.com/aigengame/aseprite-automation/issues/82)) ([38a9414](https://github.com/aigengame/aseprite-automation/commit/38a94142f4acb186f6ae3349a0f2917c95e6ce44))

## 0.1.0 (2026-09-21)


### ⚠ BREAKING CHANGES

* **cli:** process_start_failed details now use the process_start kind instead of process.
* **failure:** Public Kernel Protocol failures use the kernel_protocol category and current-only Kernel Protocol naming.
* **runtime:** The SPA-owned executable setting is SPA_ASEPRITE_EXECUTABLE instead of ASEPRITE_EXECUTABLE.

### Features

* **cli:** ship installed Aseprite info tracer ([#60](https://github.com/aigengame/aseprite-automation/issues/60)) ([06a43d3](https://github.com/aigengame/aseprite-automation/commit/06a43d35098527ee475fa09a1a135ace1a3fce82))
* **failure:** register and project public Failure Codes ([#66](https://github.com/aigengame/aseprite-automation/issues/66)) ([372ca43](https://github.com/aigengame/aseprite-automation/commit/372ca434fde7bc2cb06fbefffce6c2706894c5e1))


### Bug Fixes

* **cli:** close promotion review contract gaps ([fbe5694](https://github.com/aigengame/aseprite-automation/commit/fbe56945eb6e24c27fd51b2c0ec6504303da9d96))
* **cli:** close promotion review findings ([0358c06](https://github.com/aigengame/aseprite-automation/commit/0358c0684820101579266c9e1a2fdd08f8abb6eb))
* **descriptor:** reject stale result operation defaults ([c0ec82f](https://github.com/aigengame/aseprite-automation/commit/c0ec82fd0080d650eb2acbe131d6966a9c8ee666))
* **release:** keep Release PR lockfile in sync ([#73](https://github.com/aigengame/aseprite-automation/issues/73)) ([39970c7](https://github.com/aigengame/aseprite-automation/commit/39970c70ce8a64afb517145963aa8f0c251c22c3))
* **runtime:** classify unexpandable executable paths ([4e6fa81](https://github.com/aigengame/aseprite-automation/commit/4e6fa8183c201644904bcd079fe39cc39b7b16b0))
* **runtime:** launch Aseprite in macOS agent sandboxes ([#63](https://github.com/aigengame/aseprite-automation/issues/63)) ([89d6703](https://github.com/aigengame/aseprite-automation/commit/89d670301670b8d1f9e19a7e5e921e662403dd0c))
