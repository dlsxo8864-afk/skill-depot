# SPA Architecture

This document presents the current system architecture of Aseprite Automation (`spa`).
It integrates the accepted domain model and architecture decisions into one view for
users and contributors. It describes responsibilities, boundaries, dependencies, and
execution flows without replacing the documents that own individual decisions or
feature contracts.

[`AUTHORITY_MATRIX.md`](AUTHORITY_MATRIX.md) defines the normative sources for every
fact in this integrated view. If this document conflicts with an owning source, update
this view instead of treating it as another decision authority.

> [!IMPORTANT]
> SPA is at the bootstrap stage. The installed CLI exposes `spa info`, `spa version`,
> `spa schema`, Sprite creation, inspection, copy, resize, crop, flatten, and
> validation, Layer addressing and mutation, Frame inspection, authoring, and
> editing, Tag inspection and authoring, Palette Change inspection and Entry edits,
> Color Profile assignment and conversion,
> Cel inspection, lifecycle, placement,
> bounded position/opacity motion,
> and native relationships, Cel-targeted Image resize, crop, canvas-resize, flip, and quarter-turn rotation, canonical Image reads and replacement, bounded Pixel Patch
> application, native Snapshot composition (`spa paint composite`), native Line,
> Rectangle, Ellipse, Contour, and Blur Paint operations, native Brightness/Contrast,
> frozen raster preparation with RGBA/Indexed PNG delivery, verified RGB
> PNG Image Export, verified PNG/JSON Sprite Sheets, animation audit, Frame comparison, and continuity Preview
> export. The module
> ownership below includes both this delivered vertical slice and planned work. Feature
> issues own delivery status, while the installed Surface Manifest reports the callable
> surface of each installation.

Asset Preparation and reusable Bounded Motion Authoring are accepted ownership areas
under ADR-0095. `spa.authoring.document.motion` implements bounded position/opacity authoring over
existing independent Cels, both standalone and in a Plan (#104). `spa.preparation`
implements one frozen raster preparation path (#103). Wizard examples retain their recipe-owned pose and artistic rules;
Asset Delivery reuses the existing export implementations.

The document evolves with the product. An accepted change to the Bounded Context,
module ownership, public contract, execution model, or integration boundary must be
reflected here after its owning artifact changes.

## Architecture at a glance

SPA is an **Aseprite automation toolchain for AI agents**. Its business capability is
equivalent to Aseprite's: it provides agent-facing mechanisms for sprite creation,
editing, inspection, validation, conversion, and export, and develops these functional
capabilities broadly and deeply for agent use.

SPA exposes those capabilities as typed Operations with explicit targets, structured
outcomes, and verifiable Artifacts. It invokes an externally installed Aseprite, which
remains authoritative for native sprite behavior.

```mermaid
flowchart TB
    Callers["Callers<br/>AI agent · CI or local automation · gda Asset Pipeline integration"]

    subgraph SPA[Sprite Automation Bounded Context]
        direction TB
        Access["Access Projection<br/>Agent Skill · MCP Adapter · spa CLI"]
        Access --> App[Application use cases]
        App --> Core[Core and Supporting domain responsibilities]
        App --> Runtime["Aseprite Runtime<br/>Integration"]
        App --> Files["File Adapter and<br/>Artifact Verifiers"]
        Core -. packaged handler binding .-> Kernel[Lua Operation Kernel]

        %% Invisible links stack peer nodes vertically without adding runtime semantics.
        Core ~~~ Runtime
        Runtime ~~~ Files
    end

    Callers --> Access
    Runtime --> Aseprite[External Aseprite]
    Aseprite -->|executes packaged code| Kernel
    Files --> Workspace[Local workspace]
    App --> Outcome["Operation Result or<br/>Failure Envelope"]

    %% Stack external peers so the overview stays narrow on GitHub.
    Aseprite ~~~ Workspace
    Workspace ~~~ Outcome
```

Arrows in this overview show runtime collaboration and output flow, not source-code
dependencies. The [logical module architecture](#logical-module-architecture) defines
the source dependency direction.

The primary working loop is:

```text
discover
    -> inspect existing state when applicable
    -> create or edit
    -> inspect and validate the persisted result
    -> continue editing or export
```

The create/edit and inspect/validate steps repeat as the agent refines an asset.

The `spa` CLI is the first Open Host Service. The Agent Skill and Model
Context Protocol (MCP) adapter project the installed CLI surface instead of defining
parallel behavior. The current delivery plan does not include a standalone REST API or
remote HTTP service. HTTP is not excluded as a future transport: a validated functional
workflow can add bounded Artifact/resource access or MCP transport as another Access
Projection over the same Published Language and Application use cases.

## Architecture drivers

The architecture responds to six product needs:

1. **Aseprite-equivalent business capability.** SPA must make Aseprite creation,
   editing, inspection, validation, conversion, and export practical for agents.
2. **Clear behavior authority.** Aseprite remains authoritative for native objects,
   pixels, Tools, Filters, color, and export behavior. Each packaged Lua handler is the
   authority for its SPA Core Operation Semantics and native mapping.
3. **Explicit agent intent.** An Operation must not depend on active editor objects,
   saved preferences, prompts, or other hidden interactive state.
4. **Machine-readable outcomes.** Inputs, successes, failures, side effects, bounds,
   and installed support must have typed and discoverable representations.
5. **Verifiable persistence.** A process exit is not sufficient evidence. Mutated
   Sprites and exported Artifacts must be staged, inspected, and reported truthfully.
6. **Incremental product growth.** Sprite Authoring is the modeling focus. Accepted
   preparation and delivery needs guide bounded Supporting slices; Generic mechanisms
   grow only when these functional capabilities require them.

These drivers come from the
[umbrella product requirements document (PRD)](https://github.com/aigengame/aseprite-automation/issues/1),
the [Ubiquitous Language and context model](CONTEXT.md), and the
[accepted ADRs](docs/adr/).

## Domain-driven design profile

### One Bounded Context

SPA has one **Sprite Automation Bounded Context**. Explicit raster preparation,
creation, editing, inspection, validation, conversion, and export share the same
agent-facing automation language, with Aseprite as the native semantic authority.
CLI, MCP, Agent Skill, validation, export, runtime
integration, and the Lua Operation Kernel are modules or adapters inside this context;
they are not separate Bounded Contexts.

The system uses Aseprite's public language where Aseprite already names a concept.
SPA adds terms when agent automation needs a distinct public value, lifecycle, or
contract. [`CONTEXT.md`](CONTEXT.md#ubiquitous-language) is the terminology authority.

### Subdomains and investment

| Subdomain | Classification | Responsibility | Investment rule |
| --- | --- | --- | --- |
| Sprite Authoring | Core Domain | Verifiable Sprite and animation creation, editing, composition, observation, and validation, including bounded Frame/Cel motion. | Highest modeling priority; retain static Sprite capabilities and native semantic owners. |
| Asset Preparation | Supporting | Explicit preparation policy, geometry and anchors, Frozen Input and Prepared Raster facts. | Deliver bounded needs from real inputs; compose existing Image and color rules. |
| Asset Delivery | Supporting | Existing export capabilities, declared destination sets, verified Artifacts, and publication outcomes. | Extend formats and consumer needs through gated slices; retain all publication guarantees. |
| Aseprite Runtime Integration | Supporting | Runtime and resource discovery, process execution, Kernel transport, diagnostics, and native integration facts. | Grow from accepted domain capabilities and observed runtime variation. |
| Access Projection | Supporting | CLI presentation, Agent Skill guidance, and MCP projection from one operation surface. | Preserve contract equivalence; do not create a second capability model. |
| Asset Pipeline Integration | Supporting | Maintain the public SPA boundary used by the downstream-owned Anti-Corruption Layer. | Follow the stable integration commitment without adopting experimental pipeline internals. |
| Serialization, filesystem, and utilities | Generic | Domain-neutral mechanics required by accepted Operations. Aseprite process execution and policy remain Runtime Integration. | Use proportionate solutions; no independent platform roadmap. |

This priority is a design constraint. Authentication, authorization, audit history,
distributed consistency, multi-tenancy, and similar service infrastructure do not enter
the design without an accepted functional need and operating evidence.

### Context relationships

```mermaid
flowchart TB
    Aseprite[Aseprite] -->|native language, behavior, formats, and algorithms| SPA[Sprite Automation]

    subgraph Pipeline[gda Asset Pipeline]
        ACL[Asset Pipeline-owned Anti-Corruption Layer]
        Workflow[Pipeline workflow and file roles]
        Workflow -->|sprite request| ACL
        ACL -->|translated result| Workflow
    end

    ACL -->|calls public spa CLI JSON contract| SPA
    SPA -->|Operation Results and verified Artifacts| ACL
    Workflow -->|Godot project inputs| GDA[gda]
    GDA -->|import and runtime evidence| Workflow
```

- **Aseprite is upstream.** SPA shares its native language and delegates native
  behavior through supported non-interactive seams.
- **The Asset Pipeline is downstream.** Its Anti-Corruption Layer translates pipeline
  concepts to the public `spa` CLI JSON contract. Experimental
  pipeline command names and types do not become SPA contracts.
- **gda owns Godot evidence.** SPA can verify a Sprite or exported image, but it does
  not claim Godot import, runtime, gameplay, or player acceptance.
- **Callers own cross-Sprite workflows.** Aggregation, retry, installation, and project
  acceptance remain outside one SPA Operation or Operation Plan.
- **Artists and generation tools supply selected inputs.** SPA can prepare those
  inputs under an accepted contract. Concept selection, missing poses, art direction,
  and final visual acceptance remain caller responsibilities.

The following graph shows workflow data handoff, not source dependencies or a required
execution sequence. A caller can resume from a Frozen Input or saved Sprite and invoke
only the capabilities needed for a revision.

```mermaid
flowchart LR
    Inputs[Selected generated or human raster inputs] --> Preparation
    Recipe[Artwork Recipe] --> Authoring
    subgraph SPA[Sprite Automation Bounded Context]
        Preparation[Asset Preparation] -->|Prepared Raster and anchor facts| Authoring[Sprite Authoring]
        Authoring -->|persisted and verified Sprite| Delivery[Asset Delivery]
    end
    Delivery -->|verified Artifacts| ACL[Downstream ACL]
    ACL --> Godot[gda and Godot consumer]
```

### Selective use of DDD building blocks

SPA uses Domain-Driven Design (DDD) to assign language and responsibility, not to
reproduce a pattern catalog.

| Building block | SPA use |
| --- | --- |
| Ubiquitous Language | Shares Aseprite terms, records explicit SPA extensions, and defines SPA automation terms. |
| Bounded Context | Keeps one coherent Sprite Automation model and public contract. |
| Domain Module | Owns a cohesive feature family and its reason to change across logical layers. |
| Value Object | Represents explicit values such as Color Value, Selection, Coordinate Space, Pixel Region Snapshot, Tile Placement, and Artifact facts. |
| Application use case | Coordinates work that has no natural native Aseprite object owner, such as Operation Plan execution and publication. |
| Open Host Service and Published Language | Exposes the public `spa` CLI JSON contract and its schemas to agents and downstream consumers. |
| Anti-Corruption Layer | Translates different external semantic models. The downstream-owned Asset Pipeline ACL is the established integration boundary; internal SPA modules use shared language and directed contracts. |

SPA does not introduce a database Repository, an event-sourced Aggregate, or a global
event bus. The current product operates on Aseprite documents and local files through
explicit Operations.

## Logical module architecture

The architecture separates logical dependency layers while Domain Modules retain
vertical ownership of their Operations. A Command Group is navigation and does not
define a module boundary.

```mermaid
flowchart TB
    Access["Access Projection<br/>CLI and MCP are sibling inbound adapters<br/>Agent Skill guides the installed surface"]
    Application["Application<br/>Dispatch · Preflight · Plan · Target Commit<br/>Per-module Operation Descriptors"]
    Core["Domain rules<br/>Core and Supporting Domain Modules<br/>Applicable packaged Lua handlers"]
    Ports[Inner-owned ports]
    Outbound["Outbound adapters<br/>Aseprite Adapter · File Adapter<br/>Format-specific Artifact Verifiers"]

    Access -->|invokes| Application
    Application -->|coordinates| Core
    Application -->|calls| Ports
    Outbound -->|implements| Ports
```

Solid arrows show permitted source dependency and inward invocation direction. CLI and
MCP are sibling adapters to the same Descriptor-projected Application contract; neither
has a source dependency on the other. In the initial runtime path, MCP reaches that
contract through the installed CLI subprocess shown below. Within Application, Dispatch
invokes the selected use case, Plan coordinates Domain behavior, and Commit uses
inner-owned ports. Within Outbound, each adapter depends on the applicable inner-owned
port. Domain and Application source never depends on concrete process, filesystem, MCP,
or CLI types.

Runtime calls are distinct from those source dependencies:

```mermaid
flowchart TB
    MCP[MCP Adapter]
    CLI[Installed CLI]
    Application[Application entry point]
    Adapter[Aseprite Adapter]
    Aseprite[Aseprite]
    Kernel["Lua Operation Kernel<br/>packaged handler"]

    MCP -. subprocess .-> CLI
    CLI -. dispatch .-> Application
    Application -. runtime request .-> Adapter
    Adapter -. launches .-> Aseprite
    Aseprite -. invokes .-> Kernel
```

The dashed graph is runtime flow, not source ownership. Each Domain Module owns its
applicable packaged handler source and binding; those handlers carry the module's Core
Operation Semantics inside the shared Lua Operation Kernel. The Aseprite Adapter invokes
the handlers through Aseprite without acquiring their semantics. Bootstrap is the
composition root that alone knows and binds concrete Access, Application, and Outbound
implementations.

Ordinary Core Operation and Core Operation Semantics are the established execution
terms from ADR-0010. They apply to native Operations in Core and Supporting Subdomains;
they do not classify the owning Subdomain. Preparation can also contain wholly
Application-owned use cases whose non-native facts do not need a Lua handler.

The diagram is a responsibility map, not a required directory tree. Physical packages
will follow demonstrated change clusters as vertical slices are implemented.

### Technology profile

The installed CLI uses a replaceable outer stack around stable domain and
public-contract boundaries. [Issue #3](https://github.com/aigengame/aseprite-automation/issues/3)
delivers the bootstrap choices recorded in project metadata and its lockfile; the
Sprite creation and inspection slice extends that same stack.

| Component | Bootstrap choice | Role |
| --- | --- | --- |
| Application runtime | Python 3.13 | Use-case orchestration and adapter coordination. |
| CLI adapter | Typer | Command access and human or machine presentation. |
| Public contracts | Pydantic 2 and JSON Schema | Typed Operation Requests, Operation Results, Failure Envelopes, and discovery schemas. |
| Project and packaging | `uv` | Environments, dependencies, builds, and installed-product tests. |
| Ordinary Core Operations | Packaged Lua handlers | Core Operation Semantics and native mapping executed through Aseprite. The current package contains a fixed runtime probe, shared capability observations, Sprite creation, inspection, native flattening, resize and crop, Layer addressing and mutation, Frame inspection, authoring, and editing, Cel inspection, lifecycle, placement, and native relationships, Cel-targeted Image resize, crop, canvas-resize, flip, and quarter-turn rotation, canonical Image reads and replacement, Tag inspection and authoring, exact Pixel Patch, native Snapshot composition, native Line, Rectangle, Ellipse, Contour, and Blur Paint, animation audit, Frame comparison, continuity Preview, Export Image, and Operation Plan handlers. Sprite copy uses the File Adapter for byte preservation and the packaged inspection handler for verification. |
| Aseprite integration | External `aseprite --batch --script` | Native document, Tool, Filter, color, and export behavior. |
| Private transport | Versioned JSON request and response files | Data exchange through `--script-param`, separate from diagnostics. |
| Agent access | Agent Skill distribution through the Skills CLI and local stdio MCP Adapter with CLI subprocess invocation | Self-contained guidance and equivalent tool projection from the installed surface. |

These choices can change when implementation or distribution evidence requires it.
The Bounded Context, Published Language, and behavior authority do not depend on one
Python framework or packaging tool.

## Module responsibilities

### Domain ownership view

The current view groups Core and Supporting domain rules into cohesive areas. They guide
feature ownership and can become Domain Modules as implementation evidence confirms
their change boundaries. The delivered `spa.authoring.document.sprite` vertical slice owns Sprite creation,
structural inspection, byte-preserving copy, native resize and crop, native flattening,
and bounded validation within Document and Animation; `spa.authoring.document.layer` owns Layer
addressing and mutation;
`spa.authoring.document.frame` owns Frame inspection, authoring, and editing; `spa.authoring.document.tag` owns Tag
inspection and authoring; `spa.authoring.document.cel` owns Cel existence, inspection, and lifecycle,
while `spa.authoring.document.cel_relationship` owns Cel placement, opacity, z-index, and native
copy/link/unlink mutations; `spa.authoring.document.animation` owns declared animation audit,
full-Canvas Frame comparison, and the composed continuity Preview use case.
`spa.authoring.document.slice` owns complete Slice snapshots, exact current
index/unique-name addressing, and whole-Slice authoring. Its Lua `slice_inspect`
module owns native sprite-sheet metadata decoding and is shared by aggregate
Sprite inspection and Slice operations. `slice_support` owns Key coverage,
static-geometry admission, native mutation, and save/reopen preservation checks.
Python owns typed requests/results and staged Target Commit orchestration. Slice
mutation results return the complete reopened address snapshot because native
serialization can reorder Slices; they expose no persistent Slice identity.
Cel Add accepts optional raster Image dimensions or explicit Tile Cell dimensions.
`document/targets.py` owns shared Layer/Cel addresses and Layer target failures.
`document/cel_contracts.py` consumes those addresses and owns shared mutation
requests, Cel facts, and typed rejection translation; ordinary consumers do not
import Tile creation contracts.
`cel_support.lua` owns target selection, existence, and ordinary Image construction.
Standalone and Plan inject the same Tile-owned `tile/cel_add.lua` construction
function for explicit Tilemap requests. That function owns bounded Cell geometry,
Tileset/Grid admission, native TILEMAP Image construction, and packed-zero checks.
It reuses `tile/tilemaps.lua` for Cel geometry and `tile/tilesets.lua` for binding
facts. Add validates its initial state at the Step; the final save/reopen gate
validates the state after all later Steps.
Before Target Commit, creation receipts also reconcile the addressed Tileset and
Grid with the collection at that Step. Plan derives these collections from the
ordered lifecycle receipts and final Sprite inspection; later rebinding or removal
can change bindings and current indexes without invalidating earlier Cel facts.
Initial Cel properties are not compared with their later state.
The Layer-owned `layer_select.lua` Module supplies `current_path` for an already
attached native Layer. Cel, Frame, Sprite inspection, Pixel Patch, and native Paint
reuse this current stack-index fact. Exact name/path/verified-UUID selection remains
separate from that observation; tree traversal and composition keep their own rules.
The Cel-owned `is_regular_transparent` predicate is also used by Layer mutation and
Animation audit where the same eligibility rule applies. Their Group, Background,
Reference, and Tilemap policies remain with each Operation. Python consumers use
`spa.authoring.document.cel_contracts.raise_cel_rejection` for shared failure translation and
supply their own address roles and Frame Ranges. Each handler binding explicitly
includes the Lua resources these dependencies require, including standalone,
capability-probe, and Plan paths.
The shared `sprite_persistence.lua` Module owns native snapshots and their
persisted-fact comparison. It compares Slice collections as complete fact
multisets, including in nested snapshots, while preserving Slice Key order.
Slice mutation reuses this comparison for live postconditions and save/reopen.
Standalone Cel set/copy/link/unlink and Motion use its
`save_verified` Interface to capture live facts, save, close, reopen, observe saved
Layer UUIDs, and compare the captured native document snapshot. The Interface
consumes the live Sprite and returns a reopened Sprite, fresh UUID facts, and
persisted inspection.
It closes its owned Sprite on failure; after success, the caller owns the reopened
Sprite and closes it after its remaining checks. Cel relationship and Motion owners
retain target resolution and operation-specific postconditions. Their handlers retain
protocol responses and whole-invocation editor-state restoration. Application still
validates evidence and coordinates Target Commit. Other handlers retain the existing
snapshot and comparison functions; Plan Steps use live semantic entry points and
the Plan handler saves and verifies once at the end. This first migration does not
change Frame/Tag normalization or expand native persistence support.

Application's standalone Mutation Completion Module (`mutation.prepare_mutation`)
checks Source/Target identity before the caller's runtime probe. Layer edits and
conversions, Frame and Cel lifecycle, Tag mutations, Image transforms and Replace,
and Paint Composite reuse it alongside the existing Cel relationship, Motion,
Slice, Color, Filter, Tile, and Image Import callers.
Entering its scope allocates the staged Sprite path; leaving it always discards
that path. Callers enter after their existing input and capability gates. Each caller
owns native invocation, typed evidence validation, and its
operation-specific postconditions, then explicitly requests `commit`. Completion
rechecks publication identity, publishes through `TargetFiles`, and returns the
existing Target Commit facts. A staged file or a normal scope exit never implies
success or publication. This scope does not participate in Plan finalization, which
retains one final Target Commit and no per-Step persistence.
Sprite creation, Artifact publication, and mutation paths without a commit-time
identity recheck retain their separate completion paths.

The delivered `spa.authoring.raster.image` slice owns Cel-targeted Image resize, crop,
canvas-resize, flip, and quarter-turn rotation with explicit placement policies.
Its fixed Lua Image Resize Transform owns buffer scaling, while Image Canvas
Transform owns exact copy, clipping, and fill. These buffer semantics can be reused
by eligible Tile Bitmap authoring. Image Orientation Transform owns native
whole-Image flip and exact pixel/pivot permutation. The Cel-targeted handlers own
eligibility, complete Linked Cel scope, coherent placement, unchanged document
facts, and staged save/reopen verification. Python validates intent and Kernel
evidence and coordinates the existing Source/Target commit boundary.
`spa.authoring.raster.image_import` owns compatible external PNG insertion into an
explicitly empty Cel slot. The PNG input adapter independently observes encoded
format, Profile metadata, stored indexes, and complete RGBA; it uses Pillow for
pixel decoding. The use case freezes those input bytes and checks the existing
Color Profile identities. Its fixed native handler loads a private copy, reuses
Cel eligibility, the Effective Palette resolver, and Color Profile assignment,
then inserts through `Sprite:newCel`. It checks complete pixels before insertion
and after save/reopen, and compares unrelated document facts through the existing
Profile persistence observations. Python checks the returned evidence against the
decoded input before the shared Target Commit. Preparation policy and conversion
remain with their existing owners; this path introduces no importer registry or
Plan Step. See [the bounded import evidence](docs/evidence/issue-46-raster-import.md).
`spa.authoring.raster.image_snapshot` owns individual
and native composite Image reads plus complete Image replacement. Its Lua helpers
own canonical native pixel reads and Layer Composition over the original tree;
preserve-Indexed composition with a nonzero mask temporarily permutes pixel indexes
and Palette entries in the privately loaded document, then restores them after the
native render. The composite's explicit output choice selects the native render destination, while
individual reads retain stored values. This does not create a second compositor or
invoke Sprite-wide Color Mode conversion.
The application reuses Artifact Files for JSON transport and Target Commit for native
publication. `spa.authoring.raster.paint` owns exact Pixel Patch application.
`spa.authoring.raster.paint_composite` owns Snapshot composition intent, native support gaps, result
validation, and staged publication. Its fixed Lua support constructs the source
through `image_snapshot.lua`, invokes native `Image:drawImage`, and limits coverage
through the same explicit Selection helper as Paint apply. The handler owns Cel
eligibility, Background opacity, Linked Cel invariants, and persisted verification.
For Indexed Normal/255, a scoped temporary Sprite binds the requested Effective
Palette to native Cel-associated `drawImage`; cleanup restores active document state
on success and failure. A separate runtime observation gates this Indexed path.
Image replace and Paint composite share native Snapshot materialization; neither
maintains a second Raster decoder or blend algorithm. `spa.contracts.raster` holds the
shared Color Value, Rectangle, Snapshot, Patch, Selection, and Effective Palette types.
It also checks Paint write counts and unchanged-pixel digests; operation-specific
evidence stays with each owner.
`raster_color.lua` shares native Color Value handling and Palette result facts for
Paint and Image snapshots. It delegates Frame-based Palette selection to the private
`effective_palette.lua` Module owned by Color and Palette. That Module returns the
native Palette and its starting Frame; callers retain index, opacity, applicability,
and failure policies. Frame, Layer, Paint, and Image consumers use the same resolver.
`spa.authoring.color.palette` declares its packaged-resource binding. Each affected handler supplies
that binding explicitly, including Frame reads, Cel mutation, Image snapshots, Plan,
and runtime probes; the runtime does not discover Lua dependencies recursively.
Raster Authoring owns their
pixel and Color Value semantics under ADR-0018; Color and Palette owns Palette and
conversion behavior. The other groupings remain an integrated planning view rather
than a frozen package graph.

| Responsibility area | Owns | Important boundary |
| --- | --- | --- |
| Asset Preparation (Supporting) | Preparation Specification, explicit geometry and Input Anchor treatment, Frozen Input checks, and Prepared Raster facts. | Selects and composes accepted raster/color transformations; import into a native document remains Raster Authoring. Generation and art choices remain external. |
| Document and Animation | Sprite; shared Layer, Frame, and Cel identity, addressing, hierarchy, and existence contracts; feature-declared general Layer/Cel Operations; Tag, Slice, timing, and animation Operations. | It does not claim Tilemap Layer creation and binding or Tilemap Cel/Image content; specialized tile variants depend one-way on the shared contracts. |
| Raster Authoring | Shared Color Value semantics, Image observation and transforms, Pixel Region Snapshot and Pixel Patch exchange, Selection value operations, Paint intent, native Tool invocation, native Filters, external raster import, and evidence-gated text rasterization. | Image, Paint, and Filter remain distinct operation families while sharing one pixel and target authority. |
| Color and Palette | Palette Change and Effective Palette behavior, quantization, Color Mode changes, Color Profile assignment/conversion, and Dithering choices. | Preserves native distinctions and makes result-affecting choices explicit. It does not implement a second color engine. |
| Tile Authoring | Grid, Tileset, Tile, Tile Key, Tilemap, Tile Placement, Tilemap Layer creation and binding, Tilemap Cel/Image content, bounded region exchange, and established Tileset-coupled lifecycle variants. | Reuses shared Layer/Cel contracts without duplicating them; support for other Layer/Cel variants remains with the owning feature issue until delivered. |
| Asset Delivery (Supporting) | Static image, animation, sheet, Tileset, preview, and metadata export contracts with declared destinations and verified Artifacts. | Aseprite renders and encodes; SPA stages, validates, publishes, and reports the complete declared output set. Concept-specific meaning stays with its native owner. |

Document and Animation, Raster Authoring, Color and Palette, and Tile Authoring form
the Sprite Authoring Core. Bounded Motion Authoring belongs to Document and Animation;
the implemented [#104](https://github.com/aigengame/aseprite-automation/issues/104) slice
applies position offsets and opacity keys to existing per-Frame Cels, preserving each
Frame's artwork. It owns explicit sampling, interpolation, rounding, and standalone/Plan
semantics. Further motion modes need their own accepted scope and native evidence.

`spa.preparation` owns `raster prepare`: explicit initial/reproduce intent, a frozen
input identity, geometry and named anchors, and a verified reproduction record.
It admits single-frame 8-bit RGB/RGBA PNG, normalizes to sRGB before binary alpha
and the caller's ordered Palette, and publishes one RGBA or Indexed PNG. Its fixed
Kernel handler composes existing Color Profile, Image crop/resize/canvas, Palette,
Color Mode, and PNG encoding owners. Only binary alpha normalization and opaque
bounds are new native Raster helpers. Python derives geometry and checks complete
native/decoded evidence; it does not resample or map pixels. The input decoder also
verifies the output's representation, sRGB intent, complete Palette, and pixels.
Reproduction compares frozen bytes, explicit choices, runtime versions, geometry,
and decoded content before publication, without a registry or cross-runtime promise.
ICC conversion remains conditional on the Color Profile owner's runtime capability.
The Color Profile owner supplies one exact ICC identity resolver for its own
conversion preflight, Image Import, and Preparation; callers keep their refusal policies.
See [the preparation evidence](docs/evidence/issue-103-raster-preparation.md).

Animation comparison and continuity inspection have a Document and Animation owner;
the Preview Artifact has Asset Delivery export and publication guarantees. The current
`spa.authoring.document.animation` use case composes these responsibilities with existing export support.
Export Image, Animation Preview, and Raster Preparation share `spa.delivery.png_publication`. Its
`staged_png` scope owns the PNG and native RGBA evidence paths, independent decoding,
common native/decoded comparisons, verified digest, Source/destination checks,
publication, and cleanup through inner-owned ports. The File Adapter implements the
filesystem mechanics; the PNG Artifact Verifier decodes bytes independently.
Each caller invokes its own native handler and validates its own native facts model.
It supplies its expected-facts verdict to `verify`, performs any remaining domain
postconditions, then explicitly calls `publish`. Result models and Artifact roles
remain with their callers. Export Image verifies the decoded Color Mode, stored
content, complete Palette, and exact ICC identity before publication. All callers
compare native alpha observations against independently decoded pixels. The scope
adds no native invocation or rendering.
Selection Preview and other Artifact formats retain their existing paths.
Static Image Export extends its existing Descriptor through `export_contracts`,
`export`, and `export_verification`. Its private Lua pipeline resolves one Frame,
Canvas/Rectangle/effective Slice Key, and shared Layer Composition. It then composes
existing Color Profile, Palette import/quantization, Color Mode, and Background
owners in the order defined by ADR-0094. These owners retain their rules and refusals.
The derived Sprite retains effective Background context for native PNG encoding;
`Image:saveAs` alone would lose that context. Source snapshots are compared and editor
state is restored before returning. Palette-file input preparation is shared with Palette
Import; the independent decoder checks the native imported entries. No second
color engine, configurable pipeline, or new Plan Step is introduced.
Sprite Sheet export uses the existing Layer Composition and Color Profile owners to
prepare native per-Frame samples before Aseprite performs layout and encoding.
`spa.delivery.sheet_verification` compares independently decoded PNG/JSON against
those samples for every logical Frame, including shared physical rectangles.
The Delivery use case gates publication on complete-pair verification.
`sheet_publication` owns the fixed pair and auxiliary staging paths,
image-then-metadata order, and partial-publication facts. File mechanics remain with
the same inner-owned Artifact Files port.
The same distinction applies when a domain-specific observation produces an Artifact:
the observed concept retains its semantic owner. No duplicate exporter or verifier is
introduced by the strategic classification.

GIF and PNG sequence have separate Operation Descriptors and runtime gates under
Asset Delivery. `spa.delivery.animation` owns their staging lifecycle, request/Kernel/
decoded comparisons, and Result projection; `animation_contracts.py` contains their
request, observation, and Result DTOs. Both reuse existing Frame/Tag addressing,
Layer Composition, and Color Profile owners. `composition.resolve` supplies shared
selection facts for preflight and rendering instead of a separate exporter selector.
The fixed `kernel/delivery/animation_export_support.lua` resolves playback and the
complete destination names, then renders and encodes through native Aseprite.
`animation_gif.lua` builds a private RGB timeline for native GIF encoding; PNG retains
Source Color Mode, per-Frame Effective Palette, and effective Background context.
These temporary Sprites do not mutate the Source.

The inner-owned `ArtifactSets` port separates file mechanics from semantic verification.
`LocalArtifactSets` reuses `LocalArtifactFiles` for path normalization, Source identity,
byte reads, digest binding and publication. It preflights the complete bounded
set, allocates separate output and evidence directories, enumerates the actual output
set, and publishes in resolved order. `adapters/sequence_png.py` and `adapters/gif.py`
independently decode typed format facts through `contracts/encoded_animation.py`.
The PNG entry points in `adapters/png_input.py` and `adapters/sequence_png.py` use
`adapters/png_decoding.py` for complete structural validation and stored/RGBA pixel
interpretation. That Module retains independent byte checks alongside Pillow's pixel
decoding. Each entry point owns its representation subset, observed-facts projection,
and typed error translation: Input admits 8-bit RGB/Indexed, Artifact also admits
8-bit Grayscale, and Sequence additionally admits 1/2/4-bit Indexed. Palette order,
unused entries, hidden RGB, ICC bytes, and sRGB intent remain observed encoded facts.
The Application compares those observations with native composition, timing, profile,
Palette and cross-file expectations before passing the verified digests to publication.
No decoder defines expected Sprite semantics or repairs encoded bytes.

Image Get, Tile Get, and Tilemap Get share `spa.delivery.snapshot_publication` for
their single JSON Snapshot Artifact. Its `staged_snapshot` scope owns destination
normalization, Source separation, staging, and cleanup. `verify` reads the staged
bytes and records their digest only after the caller's validation succeeds;
`publish` rechecks Source separation and delegates digest-bound publication to the
File Adapter. The scope clears its verification state and discards staging on exit.
Image and Tile retain native invocation, Snapshot types and semantic checks, output
forms, failure mapping, and Artifact result projection. Image still observes staged
bytes before parsing native evidence; Tile checks native evidence and scope first.
Inline and summary reads use no Artifact File Adapter. This bounded lifecycle does
not add a codec, a format registry, or a native invocation.

An Operation that spans modules is coordinated by Application through public contracts.
Module dependencies must remain acyclic, but this document does not freeze a complete
intra-domain dependency graph before implementation supplies real change and reuse
evidence. Each delivered slice records the owner of a shared value or rule and adds a
one-way dependency to that owner rather than copying the knowledge.

For the accepted preparation and authoring direction:

- Preparation use cases depend on the public contracts of the Image and Color/Palette
  capabilities they compose. Those semantic owners do not depend on preparation policy.
- Motion use cases depend on Frame/Cel contracts. Primitive rules do not depend on an
  Artwork Recipe or its wizard-specific choices.
- Delivery use cases consume observation, rendering, and transformation contracts;
  they do not make the underlying native rules depend on output naming or file roles.
- Shared publication and filesystem mechanisms expose inner-owned ports. Cross-owner
  use cases coordinate explicitly; a helper's current file does not justify reciprocal
  module imports.
- Production code never imports an example. An external model adapter can depend on
  SPA contracts; core rules do not import a generation provider or Godot model.

### Physical modules

The source layout makes the existing responsibility boundaries visible. Feature
modules retain vertical ownership; the packages below group related concepts, not
separate contexts or deployment units. The installed Surface Manifest reports
callable Operations.

```text
src/spa/
  __init__.py
  bootstrap.py            # CLI composition and installed entry point
  mcp_bootstrap.py         # optional MCP stdio composition
  access/
    mcp/                  # Manifest tool projection, CLI subprocesses, PNG content
    cli.py                # Descriptor-derived command projection
  application/
    dispatch.py           # dispatch and outcome classification
    mutation.py           # standalone staging, identity recheck, commit, cleanup
    plan.py               # cross-module Plan orchestration
    surface.py            # installed Operation registration and discovery
    failure_registry.py   # assembled Failure Code projection
  contracts/
    public.py, operation.py, ports.py
    mutation.py           # Source/Target identity and Target Commit contracts
    artifact.py           # shared publication/verification failure details
    artifact_set.py       # bounded destination staging and per-path publication states
    encoded_animation.py  # independent PNG/GIF observed format facts
    snapshot.py           # explicit destination for complete JSON Snapshot transport
    digest.py             # one shared native evidence digest binding
    raster.py, rounding.py # shared values and their native bindings
  authoring/
    document/
      sprite.py, layer.py, frame.py, cel.py, cel_relationship.py
      tag.py, animation.py, motion.py
    raster/
      image.py, image_snapshot.py, image_import.py, selection.py
      paint.py, paint_composite.py, paint_native.py
    color/
      palette.py          # Palette reads, Entry edits, sizing, reorder, and remap contracts
      palette_file.py     # native Palette import and ordered-file evidence
      quantization.py     # explicit native Palette generation contract and evidence
      color_mode.py       # Conditional native conversion contract and evidence
      profile.py          # Native Color Profile contracts and ICC input policy
    tile/
      inspection.py, values.py # exact native Tile observations and bounded Snapshot values
      properties.py       # typed projection of selected native Lua property values
      lifecycle.py        # keyed Tile mutations and validated native remapping evidence
  preparation/
    contracts.py          # explicit Preparation Specification, geometry, and reproduction facts
    raster.py             # frozen input admission, native composition, verified Artifact publication
  delivery/
    export.py             # Static export composition and verified publication
    export_contracts.py   # Explicit static PNG choices and native facts
    export_verification.py # Bind decoded PNG to native samples and export choices
    animation.py          # GIF/PNG sequence lifecycles and semantic comparisons
    animation_contracts.py # animation export request, observation, and Result DTOs
    sheet.py, sheet_contracts.py # Sprite Sheet use case and explicit pair contract
    sheet_verification.py # independent sheet evidence comparisons for every logical Frame
    sheet_publication.py  # fixed pair staging, auxiliary cleanup, and publication outcomes
    palette.py            # verified Palette file export and explicit generation composition
    png_publication.py    # staged PNG verification/publication for Export, Preview, Preparation
  adapters/
    aseprite/             # process, resource discovery, and transport
    files.py, png.py       # filesystem mechanics and export PNG verification
    artifact_set.py        # complete set preflight, staging, ordered publication
    sequence_png.py, gif.py # independent encoded animation observations
    png_input.py           # Input/Artifact representation policy, facts and errors
    png_decoding.py        # complete shared PNG structure and pixel interpretation
    icc.py                # ICC byte validation and digest, without color transforms
    palette_file.py       # independent GPL/Indexed PNG observations, not a color engine
  kernel/                 # fixed native semantic handlers and shared owners
    __init__.py
    document/
      sprite/, layer/, frame/, cel/, tag/, animation/
    raster/
      image/, paint/, selection/
      raster_color.lua
    tile/                 # Tileset identity, topology, validation, complete Tile Regions
    color/                # Palette semantics, native Color Mode and Color Profile operations
    preparation/          # fixed composition of existing Raster and Color owners
    delivery/             # native Image, Sheet, Tileset, GIF and PNG sequence Export
    runtime/              # runtime and capability probes
      fixtures/           # real native probe inputs
    plan/                 # single-Sprite Plan execution
    foundation/           # digest and rounding algorithms
```

`authoring/color/color_mode.py` owns Change Color Mode's conditional request and
result contracts. `kernel/color/color_mode.lua` owns complete-Sprite native
conversion, Effective Palette observations, and Dithering Matrix preflight. It
accepts an attached Sprite without owning its publication. The standalone wrapper
and Plan call that same owner, then verify native persistence before Target Commit.
The process adapter supplies the selected installation's data directory as private
invocation context. Matrix pixels and native mapping remain inside Aseprite; later
export composition can reuse this owner on a disposable Sprite.

Package initialization does not register Operations or re-export implementations.
Access calls Application; Application composes feature contracts and inner-owned
ports; outbound adapters implement those ports. The shared `contracts` package
contains only values and contracts already used across owners. Feature-specific
requests, evidence, Descriptors, and use cases stay with their feature. Imports
between feature modules retain a single direction; no runtime lookup or directory
scan replaces the explicit bindings.

The Lua family directories colocate handlers and their supporting semantics.
Native Sprite persistence remains under `kernel/document/sprite`; it does not
acquire Application's Target Commit responsibility. The small `foundation` group
holds existing shared algorithms and does not become an owner for feature policy.
It includes the established Image evidence digest encoding, not a new generic
service. Shared Python contracts do not import feature implementations. Frame
and Paint use the same digest binding; dispatch consumes shared Artifact failure
details without importing the Delivery implementation.

A `PackagedHandler` separates its logical name from its explicit path relative
to `spa.kernel`. A `PackagedResource` maps a semantic script parameter to a
relative packaged path. The runtime uses the logical name for its temporary
workspace and the path for loading. Probe and Plan dependencies remain explicit;
the runtime does not discover resources recursively. The installed-package check
compares all nested Kernel files with source bytes outside the checkout, including
real LFS fixture content. This inventory verifies the distribution and is not an
Operation registry.

Add a module only with a complete functional slice. Tile Authoring owns
`authoring/tile` and `kernel/tile`: Python
publishes typed inspection, explicit Tileset creation/sharing, and Tilemap Cel contracts, and
checks evidence before Artifact or Target publication. Lua resolves native Tilesets,
Tile Keys, Layer bindings, and Tile Cell placements, and constructs explicitly
sized empty Tilemap Cels. The `layer add` Descriptor
remains in Document; its Tilemap variant delegates the cross-Layer/Tileset lifecycle
to Tile Authoring, including exact removal of its own temporary implicit Tileset.
Shared `document/targets.py` and `tile/targets.py` hold addresses and target failures;
reads and mutations consume these contracts without importing each other's use cases.
The native `tile/tilesets.lua` owns exact Tileset resolution and binding facts for
both paths. Tile Authoring reuses shared Sprite save/reopen verification, adds Tile
Image preservation checks, and leaves Target Commit to the existing file adapter.
It depends on Document's shared Layer/Cel contracts and Raster's Pixel Region
Snapshot encoding for Tile bitmaps. `tile/keys.lua` owns one Key projection and exact
lookup for reads and writes. `tile/lifecycle.lua` owns append, missing-Key assignment,
remove, and reorder. It precomputes the complete native index mapping and all affected
Cel Images, moves complete native Tile records, and updates each shared Image once.
Opaque author/plugin Properties stay with native Tile records; the observation JSON
is not a metadata transfer format. A nonzero Tile mapped to Empty becomes packed zero;
other retained placements keep flags, including existing flagged index-0 observations.
The native `MoveTiles` command requires a Tilemap Layer; orphan reorder creates and
removes only its own temporary native context within the mutation transaction.
Public Tile record lifecycle Operations are standalone in this delivery.
`tile/tileset_lifecycle.lua` owns explicit Layer rebinding and unreferenced Tileset
removal. Both standalone and Plan call its live semantics. It resolves used Keys,
Grid intent, and usage-Frame Palette validity before mutation; it does not copy or
reconstruct native Tile metadata. Shared document verification and exact Layer
bindings guard the change and final save/reopen. Python validates typed receipts
and request correspondence; Plan also reconciles the collection between Steps.
Scoped Tileset resize remains deferred in #175 pending native preservation evidence.

`tile/regions.lua` owns keyed Set/Patch/Fill intent, complete bounds checks, and
Indexed compatibility at every affected Cel Frame. It edits a detached Image and
replaces the original once through the native Cel setter, preserving Linked Cels.
It reuses Document's affected-Cel observations, Color and Palette's Effective
Palette resolver, and shared save/reopen verification. `tile/tilemaps.lua` owns
Cel geometry facts consumed by inspection, explicit Cel creation, and region
writes. Python checks returned coverage, sharing, identity, and Palette evidence
before Target Commit. Region Operations are standalone in this delivery.
Cel mutation and Plan retain staging and Target Commit ownership. The existing
Tile probe observes empty-Cel save/reopen
separately from inspection; only explicit Tilemap creation requests require that
capability. Shared JSON Snapshot destination shape lives in `contracts/snapshot.py`,
and the scoped publication lifecycle lives in `delivery/snapshot_publication.py`;
Tile Region values stay in their feature owner. Color and Palette owns the shared Effective
Palette resolver and standalone Palette list/get/set/resize/remap/reorder. Its native module resolves
Frame-based change points, edits only exact existing changes, and checks the full
Palette timeline after shared Sprite persistence completes. This Palette-specific
postcondition includes RGB/Grayscale Entries, which generic document persistence
can otherwise treat as unrelated metadata. Python validates native evidence and
uses shared mutation completion before Target Commit. Unsupported Palette Change
add/remove operations remain evidence-backed Capability Gaps without Descriptors.
The private `palette_images` module resolves per-invocation Cel and Tile Image uses,
including unused Tiles, and supplies Image digests and Tile metadata facts to Palette
checks. It has no persistent registry or Tile authoring policy. Palette transforms
delegate shared replacement to the native Cel/Tile Image setter, which preserves
sharing and updates Tileset persistence caches; raw Image byte writes do not do that.
Palette-change reorder rejects changed Images with uses outside its effective range.
Whole-Sprite remap and reorder include all Indexed Images and the global Transparent
Color Index. Palette resize remains a native capability that Preparation can consume
without importing Preparation's policy into Color and Palette.

`palette_file.lua` imports native Palette colors into an exact existing Change;
Python freezes the input bytes and compares all persisted Entries with independent
file observations. `palette_quantization.lua` owns the native all-Frame generation
and temporary editor state. Its standalone mutation path also verifies unchanged
non-Palette facts and refuses unsafe Indexed candidates. Delivery calls the same
generator on a disposable Sprite and publishes only a Palette Artifact. It uses
the existing Artifact File adapter for staging, identity checks, digest verification,
and publication. GPL and Indexed PNG interpretation stay in the Palette file adapter;
the existing RGB Image PNG verifier retains its separate format policy. No Python
module generates, remaps, or quantizes Palette colors.

Color and Palette also owns `sprite assign-color-profile` and
`sprite convert-color-profile`. `profile.lua` applies the same native operation to a
standalone Sprite or a live Plan Sprite and observes all Cel Images, Palette Changes,
and Tileset Tiles. The same owner admits Convert through a finite directed matrix
and exact ICC input digests. It binds encoded Source bytes, or bytes from the last
live Assign, to the native profile before admission. This policy does not constrain
valid-ICC Assign or infer arbitrary native ICC compatibility. Static Preflight rejects
unlisted Convert target bytes through the same finite `color/profiles/identities.json`
data consumed by Lua; it does not reproduce the Lua source/direction rule. Both hash
actual input bytes. Admitted input identities are independent of the reference files
distributed for probing and tests. The former Apple P3 file remains an admitted
caller-supplied input, while the bundled CC0 P3 reference has a distinct identity.
See [#194 evidence](docs/evidence/issue-194-redistributable-profile.md).
Python reads and freezes input ICC bytes through the file adapter and
validates them through the ICC adapter;
it does not transform colors. The profile-specific persistence check verifies native
profile equality, encoded kind, all stored colors, and the complete Palette timeline.
The bounded encoded-profile reader is shared with Export. Import supplies its own
independently decoded PNG declaration to the same native assignment helper; each
consumer retains its format policy. This preserves encoded None despite Aseprite's batch load default and adds
no general profile or preference service. See the [native evidence](docs/evidence/issue-34-color-profile.md).

Reuse the canonical
Pixel Region Snapshot and Color Value contracts where applicable; do not promote the
wizard's temporary PNG decoder, palette matcher, or batching adapter as a second pixel
authority. Exact preparation formats and dependencies remain feature decisions.

Inspection and Validation stay with the module that owns the inspected concept. They do
not form a horizontal subsystem. Selection authoring stays adjacent to Raster Authoring
while the Selection value can be consumed by other eligible Operations. A future split
requires evidence of a different language and reason to change.

The implemented Selection slice lives in `selection.py`; `raster.py` retains the
canonical value types shared with Paint. `selection_mask.lua` materializes those
values and encodes native coverage. Both Selection operations and Paint consume
that adapter, including Paint in an Operation Plan. `selection_support.lua` owns
native set operations, isolated temporary Sprite work, and binary Image adaptation
for native nearest-neighbor sampling. Python validates wire constraints and
orchestrates existing Artifact staging, independent JSON/PNG verification, and
publication. No persistent editor Selection or second Mask engine is introduced.

Native Filters share target observations, Cel writeback checks, and staged Target
publication in `authoring/raster/filter.py`. Its `FilterTargetObservations` owns
intersection consistency and request-to-evidence target/Selection correspondence for
all seven Filter Operations before Target Commit. Selection checks establish feasible
coverage from the declared facts; live Layer resolution and actual Canvas clipping
remain in the Kernel. Brightness/Contrast and Hue/Saturation
also share their palette-aware application variants. `pixel_filter.py` owns the
fixed-pixel request/evidence subset for Color Curve and Replace Color, without a
public application selector. Each operation keeps its adjustment schema and native
mapping; `hue_saturation.py` owns conditional HSL/HSV, Grayscale, and Alpha forms.
Brightness/Contrast alone adds Manual Tileset Mode and changed-Tile evidence.
`filter_support.lua` owns Filter Cels Target resolution, Channel flags, editor-state
restoration, and stable Layer/Frame observations. `filter_application.lua` owns
Palette application and native transaction setup. Fixed-pixel operations adapt to
that executor internally and omit Palette-mutation fields from public results. Small adjustment modules
map explicit parameters and invoke their respective Aseprite commands; no color
algorithm is duplicated. `filter_run.lua` verifies live/save-close-reopen observations
before Python publishes a Target. Existing Layer, Effective Palette, Selection, and
Sprite persistence modules retain their ownership.

`invert_outline.py` owns the two standalone pixel-only contracts. They reuse
Filter target observations and publication without inheriting the Palette
application request. Their fixed Kernel modules invoke native Invert Color and
Outline. The shared executor accepts a pre-invocation validation callback after
target, Palette, and Selection resolution; Invert uses it to validate stored
Indexes across the selected Canvas (including native zero padding). Outline maps
named neighbors to native Matrix bits and retains its own color-anchor policy.
No generic effect model or Operation Plan eligibility is introduced. Runtime
probes gate the two commands independently, and the Surface Manifest reports
their target and Indexed component limitations.

Native writeback can trim or delete Cels. Hue/Saturation and Despeckle observe surviving
Layer/Frame intersections and reports bounds or absence, including affected links
outside the selected range, without retaining deleted Cel userdata. Hue/Saturation's independent
runtime gate discriminates all four HSL/HSV modes across the five applications.
Color Curve and Replace Color use the same stable Cel observations. Replace Color
counts actual stored-pixel differences per distinct target Image, using Canvas
alignment across native expansion, trimming, or deletion; it does not recreate native matching.
Their independent runtime gates observe RGB, Grayscale, Indexed component, and Index
paths. Hue/Saturation, Color Curve, and Replace Color reject resolved Tilemap pixel
targets; Hue Indexed Palette-only anchors
preserve ordinary, placement, and Tile Images (ADR-0074). This is its current delivery
boundary, not a permanent restriction on future Filter features.

`despeckle.py` owns required window dimensions, edge mode, the pixel-only request,
and its Indexed Channel boundary. It adapts pixel intent to the shared private
application path without importing Palette mutation policy. Native Despeckle owns
neighborhood sampling, median selection, component preservation and RGB Map
quantization, including 1×1 writeback. No SPA median algorithm or no-op shortcut
is introduced.

Convolution is discovery-only in this slice. The Runtime Integration adapter scans
bounded declaration metadata at the prepared invocation's native resource paths.
It never computes coefficients or decides that a declaration is callable. The
Kernel records direct requested/observed Channel probes. The internal
`RuntimeObservation` carries declarations and probes; public `RuntimeFacts` omit
these raw payloads. Raster Authoring owns the Convolution Gap reason. The installed
Surface Manifest reports that SPA does not provide this capability; internal
observations remain available for maintenance. No descriptor, custom convolution
engine, or general resource registry is added.

Native text rasterization is also discovery-only. Raster Authoring owns its public
Capability Gap reason; `surface.py` projects it through `info` and `schema` without
a text Descriptor or schema. The [maintenance note](docs/evidence/issue-47-native-text.md)
explains the native font/theme dependency. Manual text fixtures are not packaged
discovery resources, so discovery does not invoke the unsafe text path.

Brightness/Contrast passes the concrete `filter_tiles.lua` module into the shared
execution path. It owns Manual Tilemap admission, preserved placement/binding/Grid
postconditions, and changed Tile bitmap references. It consumes the existing low-level
Image/reference observations in `palette_images.lua`, without Palette mutation policy.
The shared target resolver admits Tilemaps only when that operation supplies Tile support.
A separate runtime probe observes the four Manual Tilemap pixel applications. The
application passes that private capability fact to the Kernel, which checks actual
resolved targets and the live native Site mode before mutation. Ordinary Image and
Palette-only applications do not require the Tilemap capability (ADR-0074, #152).

Manual Tilemap verification compares canonical native User Data chunks, including their
structural positions and extension mappings, through temporary `saveCopyAs` snapshots.
This preserves observation of arbitrary plugin namespaces and native Property types
that the Lua getters cannot fully enumerate. It does not decode or rewrite Properties.
Before/live comparison runs inside the native transaction; save-close-reopen comparison
runs before Target Commit. Existing full Image observations cover ordinary color Images,
placement Images, Tile bitmaps, and sharing. No topology or metadata repair is performed.

The native Fill, Pencil, Eraser, Line, Rectangle, Ellipse, Contour, and Blur
operations use `paint_native.py` for typed
contracts and publication orchestration. `paint_native_support.lua` owns footprint
partitioning, Selection Application, linked mutation, and persisted evidence.
`native_tool.lua` hides native Tool invocation and its local state restoration.
It uses isolated native working documents to prevent the editor's Cel expansion
from changing the addressed Image. The native pixel result is copied into the
existing shared Image; geometry and unrelated document facts are verified before
publication. Existing Cel, Selection, Color, Palette, and persistence helpers retain
their ownership. Each public Operation has its own handler and runtime gate;
Pencil and Eraser also admit each Freehand Algorithm independently.
Fill keeps the original Canvas and saved Grid in its working Sprite. The native
Magic Wand observes matching coverage through the same flood-fill point shape as
Paint Bucket, including no-op colors or opacity. Shared Selection Application
filters that coverage after matching. Gesture coverage uses a native opaque Brush
pass, while native Eraser owns the actual alpha, index, or color replacement.
Blur keeps the original working Sprite dimensions so native source expansion and
Tiled Mode retain their document boundaries. Its coverage pass uses native Pencil,
which shares Blur's Brush and freehand geometry; only native Blur supplies effect
pixels. Contour delegates the complete ordered gesture, including closure and fill,
to its native tool. The runtime gates independently verify Contour's two algorithms
and Blur's four Tiled Modes. Gradient has no implemented Descriptor or callable
handler while complete headless Gradient Type and Dithering Matrix control remains
unavailable in SPA; installed discovery reports the feature-owned Capability Gap reason.
No new rasterizer or public generic Tool wrapper is introduced. The
[issue #27 evidence](docs/evidence/issue-27-native-paint.md) records the native
assumptions and their verification.

Each Domain Module owns a vertical slice of:

- its domain terms and invariants;
- request, result, and failure contracts;
- Operation Descriptors;
- Application use cases;
- human and machine presentation bindings;
- applicable packaged Lua handler bindings; and
- tests and applicable native integration evidence.

These responsibilities remain logically distinct even when one physical package keeps
them close.

### Operation contract and discovery

Each structured public capability has one **Operation Descriptor**. The descriptor
binds schemas, execution metadata, presentation, and a declared execution definition.
For an Operation that invokes Aseprite, it also declares the required Lua language
profile, minimum `app.apiVersion`, and the Aseprite-provided runtime capabilities that
the Operation actually uses. A complete probe establishes its scripting, file I/O, and
JSON transport prerequisites. It reports native runtime capabilities independently of
those fixed prerequisites. The Application compares the observed Lua language, API
version, and capabilities with the selected Descriptor before it enters an ordinary
Operation execution definition. For Plan, the selected Step Descriptors and mandatory
final Sprite inspection determine the requirements. Shared capability observations and
comparison run inside the single Plan process before its first Step, and Application
maps an incompatibility to the same
typed `runtime_incompatible` failure. Aggregate discovery uses the union of all
currently eligible Step requirements to declare the complete Plan surface supported;
an individual Plan may run with fewer observed capabilities because its execution
gate uses its selected Steps plus final Sprite inspection.
Descriptors are the registration authority; they do not implement native behavior.
Under ADR-0013, the failure contract uses shared registration of each public
Failure Code's meaning, Category, and Details kind. Each Descriptor declares its
Operation's applicable codes and projects their constraints in its failure schema.
Before Descriptor selection, the CLI constructs usage failures from that registration;
aggregate `spa schema` discovery exposes their separate Access-level failure schema.
The Application classifies private runtime evidence for selected Operations; Access
adapters project the same Failure Envelope.

Each standalone Ordinary Core Operation binds one fixed packaged Lua handler. A capability whose
behavior is implemented by an Application use case can have no Kernel binding. An
application-composed capability can order packaged semantic entry points through its
own fixed handler without redefining their semantics. `script run` uses a separate caller-script
path. SPA registration, identity resolution, and Ordinary Core Operation dispatch cannot
use that path to replace, override, rewrite, proxy, or bypass an existing Ordinary Core
Operation. The Application-owned `script.py` use case calls the inner-owned
`CallerScriptInvoker` port in `contracts/caller_script.py`; the Aseprite Adapter
owns exact source transport and process observations. After successful invocation,
Application obtains declared-path facts through the inner-owned `ScriptFileObserver`
contract, implemented by the File Adapter in `adapters/files.py`. The caller-script
invocation port does not use `PackagedHandler` or the Kernel response protocol. The
caller cannot supply an Operation identity or execution metadata. Script output
remains diagnostics under
the validated `spa script run` result or registered failure.

Every Descriptor declares Operation Determinism. `deterministic` and
`native-stochastic` apply to `read`, `mutation`, and `export`; only `script-run` can
declare `caller-defined`. That value states that SPA makes no claim about the caller's
script repeatability or randomness source. All other Execution Kinds prohibit it.

```mermaid
flowchart TB
    Descriptor[Operation Descriptor] --> Request[Operation Request, Operation Result, and Failure Envelope schemas]
    Descriptor --> CLICommand[CLI command]
    Descriptor --> Renderer[Human renderer]
    Descriptor --> Execution[Execution definition]
    Descriptor --> Manifest[Installed Surface Manifest]

    %% Invisible links stack descriptor facets vertically without changing ownership.
    Request ~~~ CLICommand
    CLICommand ~~~ Renderer
    Renderer ~~~ Execution
    Execution ~~~ Manifest

    Execution -->|Ordinary Core Operation| Binding[One packaged Lua handler]
    Execution -->|Application use case| AppPath[Application execution]
    AppPath -. can order Ordinary Core Operations .-> Binding
    Execution -->|caller-owned Lua| ScriptPath[script run adapter path]
    AppPath ~~~ Binding
    Binding ~~~ ScriptPath
    Manifest --> MCPTool[MCP tool projection]
    SkillDocs[Agent Skill guidance] -. teaches .-> CLICommand
    Manifest -. read by the agent following Skill guidance .-> SkillDocs
```

The installed Surface Manifest reports the callable Operations, schemas, execution
metadata, version constraints, and Capability Gaps for one SPA and Aseprite combination.
Callable entries come from Descriptors. Under `AUTHORITY_MATRIX.md`, a Gap can also
report an assessed limitation that prevents a capability from having a Descriptor.
The Manifest reports the selected runtime and applicable SPA support boundaries,
without claiming that every native behavior was retested on that runtime. A Gap does
not register an Operation or promise its future delivery.
An unpublished candidate's Gap projection can be limited to its recorded investigation
scope. Its absence on another release establishes neither callability nor a native
behavior result there; the feature issue retains the investigation status.

### Application orchestration

Application use cases own the order of work around native behavior:

- validate public input and resolve public omission/null semantics;
- select and order packaged capabilities;
- discover a compatible Aseprite runtime;
- coordinate Operation Plan Steps;
- prepare staging paths and explicit destinations;
- classify protocol, process, and verification failures;
- publish a Target Sprite File or exported Artifacts after verification; and
- return one typed outcome for access adapters to project.

Python can perform this orchestration. It cannot duplicate Core Operation Semantics
owned by a packaged Lua handler, substitute for Aseprite's native behavior, or create a
temporary Lua implementation for an Ordinary Core Operation.

### Lua Operation Kernel

The versioned, packaged Lua Operation Kernel is the authority for Core Operation
Semantics executed inside Aseprite. Its handlers:

- resolve live Sprite targets and native side effects;
- enforce document-dependent Preconditions and Postconditions;
- execute supported native transactions, Tools, Filters, color operations, and exports;
- install and restore invocation-local editor, Tool, Filter, and visibility state;
- observe the resulting native state; and
- return a versioned private Kernel response.

Standalone handlers and the Plan handler call the same packaged native semantic entry
points. Standalone handlers save and reopen their Operation output; the Plan handler
keeps one Sprite live and applies one final save-and-reopen gate. A second Python or
generated-Lua behavior path is prohibited. `spa script run` is a separate escape hatch
for exact caller-owned Lua and does not inherit Ordinary Core Operation guarantees.

Cel relationship semantics live in `kernel/document/cel/cel_relationship_support.lua`. The
standalone relationship handler and `cel set` Plan Steps call its live entry point.
`spa.authoring.document.cel_relationship` owns the shared input and evidence contracts; `spa.application.plan`
composes those contracts and reports Step facts before final Plan persistence.

`spa.authoring.document.motion` owns the bounded curve input, per-Cel evidence, and publication use
case. `kernel/document/animation/motion_support.lua` resolves the complete existing target set,
rejects Image links, samples explicit curves with exact rational arithmetic, and
validates all result positions before mutation. Standalone and Plan handlers call
this live entry point. It reuses Cel addressing, Layer eligibility, and document
snapshots; `kernel/foundation/rounding.lua` shares rounding meanings with Image resize.
Offsets use each target's own Step-start position. Later Steps can change earlier
facts; only the final live document is compared with the final reopened file.

### Aseprite Runtime Integration

The Aseprite Adapter owns the external integration mechanics:

- executable and resource discovery;
- host-specific invocation preparation within the adapter;
- collection and transport of the Aseprite version, embedded Lua language version,
  `app.apiVersion`, fixed probe prerequisites, and independently observed runtime
  capabilities;
- `--batch --script` process launch;
- the versioned Kernel Protocol and transport files;
- process exit and bounded diagnostic capture;
- process-environment and transport-file cleanup; and
- process, protocol, and runtime-integration observations required by an Operation.

Process exit and standard output are runtime observations, not the public verdict. The
Application maps those observations to an Operation Result or Failure Envelope.

Invocation preparation keeps the installed executable's canonical path separate from
the path used to start one process. For macOS `.app` CLI invocations, the adapter
creates a temporary non-bundle link to the executable and a link to its `data`
resources. Other installation shapes use the installed executable directly. The
adapter supplies an isolated Aseprite user folder and cleans these temporary paths.
This private mechanism does not change the caller's sandbox, the installed app, or
the File Adapter's ownership of Sprite and Artifact paths. [Issue #61](https://github.com/aigengame/aseprite-automation/issues/61)
defines the targeted restricted profile and its evidence requirements. Tests retain
the executed integration evidence.

### File and Artifact verification integration

The **File Adapter** owns domain-neutral path handling, staging, existence, byte size,
digest, publication, and cleanup. It does not decode a File Format or interpret Sprite
semantics. A format-specific **Artifact Verifier** independently decodes typed observed
facts from staged Artifact bytes; it does not define the expected result. The owning
Domain Module defines the expected format and domain facts, and the Application use case
compares the request, Kernel observations, verifier observations, and applicable
cross-file facts before publication.

These responsibilities support two separate functional boundaries:

- **Sprite Mutation:** prepare a Staged Sprite File and perform one Target Commit after
  the Application obtains persisted native facts from a close-and-reopen cycle in the
  owning Aseprite invocation.
- **Export:** stage the complete declared output set, decode and compare every expected
  file, then publish and report verified Artifacts.

These mechanisms do not create a persistent Artifact registry, backup store, audit
history, or cross-command recovery system.

### Access Projection

- The **CLI** is the first public execution channel for the public `spa` CLI
  JSON contract.
- The **Agent Skill** teaches discovery and the edit-observe-verify-export loop for the
  installed surface. The [SPA Skill](skills/spa/SKILL.md) contains the self-contained instructions that let the
  consuming agent determine applicability from installed schemas and typed outcomes.
- The **MCP Adapter** reads the Surface Manifest, invokes `spa`, and relays equivalent
  requests and outcomes.

[ADR-0096](docs/adr/0096-agent-skill-delivery.md) delegates Skill discovery, installation,
updates, and version management to the Skills CLI. SPA adds no `spa skill` command,
wheel copy of the Skill, or external Skill-to-CLI compatibility checker. The Python
package and native runtime keep their existing installation and execution checks.

The MCP slice uses stdio through the optional `spa-mcp` bootstrap. It invokes the
selected installed CLI for both schema discovery and calls. The SDK owns modern
`2026-07-28` discovery and legacy `2025-11-25` initialization. The adapter adds no
current-Sprite or cross-call session state. [ADR-0097](docs/adr/0097-mcp-cli-projection.md)
records this boundary; [usage](docs/mcp.md) documents installation.

`access/mcp/server.py` maps Manifest Operations to tools. `access/mcp/cli.py` builds the
CLI command, encodes the JSON request, and maps the result to an Outcome or an adapter
error. `access/mcp/process.py` owns subprocess invocation and cancellation cleanup: it
starts the CLI, sends the request, and collects the output. On cancellation, it stops
the owned process tree and waits for the CLI; if the terminate step fails, it kills only
the CLI itself. A cleanup failure does not replace the original error. A POSIX process
group and a Windows Job are its two ownership adapters.
`access/mcp/content.py` checks published outcome schemas and projects PNG Artifact bytes
after size/digest/format verification. These owners have no source dependency on CLI
execution internals, Application or Kernel modules. `mcp_bootstrap.py` selects the
CLI/runtime and wires stdio. A projection failure preserves the completed CLI Result and
reports its own diagnostic. The slice offers no resource browser or HTTP file service.

MCP does not call the Lua Kernel directly and does not own schemas, failure meanings, or
feature taxonomy. A later MCP Streamable HTTP transport or bounded HTTP resource adapter
would be a sibling inbound adapter, not a mandatory `MCP -> REST -> CLI` layer. Every new
access channel must project the same Published Language and cannot become an Operation
semantics authority. Network-facing requirements enter the design only with the
functional slice that creates them.

### Asset Pipeline boundary

SPA owns accepted raster preparation, Aseprite authoring, and asset delivery facts.
The caller or downstream Asset Pipeline owns art-input selection, cross-tool and
cross-Sprite workflow order, mapping SPA Artifact roles to project roles, installation,
retry, and project acceptance. Its Anti-Corruption Layer calls the public `spa` CLI JSON contract and translates the
result into pipeline concepts. This commitment remains stable while the pipeline's
experimental commands and tactical types evolve.

## Public and private contracts

| Contract | Visibility | Authority and purpose |
| --- | --- | --- |
| Published Language | Public | Versioned Operation Request, Operation Result, Failure Envelope, Operation metadata, Artifact, and Surface Manifest schemas. |
| Operation Descriptor | Internal registration, publicly projected | Binds one structured public capability's identity, schemas, metadata, presentation, and declared execution definition. |
| Kernel Protocol | Private | Carries versioned data between Python and the packaged Lua Kernel; it can evolve without becoming a second public API. |
| Operation Result | Public success | Reports verified domain facts and produced Artifacts. |
| Failure Envelope | Public failure | Provides stable Failure Code and Category, typed Details where useful, and human Diagnostics. |
| Surface Manifest | Public discovery | Reports what the installed SPA/Aseprite combination can call and its applicable Capability Gaps. |

Before SPA 1.0, the co-packaged Python and Lua components use only the current Kernel
Protocol version. This private boundary can evolve without historical-version
compatibility machinery; checking the installed Aseprite Lua runtime and scripting
API remains a separate obligation.

These are three independent compatibility axes. The packaged Kernel currently declares
the `Lua 5.4` language profile. Each runtime-backed Descriptor declares its minimum
`app.apiVersion` and required Aseprite-provided capabilities. The Adapter observes the
selected process. A successful probe establishes its transport prerequisites; a
prerequisite failure uses the existing typed process or Kernel failure channel. The
Adapter preserves each independently observed runtime capability rather than requiring
every known capability for every probe. The Application rejects an observed
Lua-language or API-version mismatch, or a capability missing from the selected
Descriptor's requirements, with typed evidence before Operation execution. The private
Kernel Protocol continues to require an exact match with the one version co-packaged in
the same pre-1.0 release.

The Baseline Aseprite definition is `SPA_BASELINE_ASEPRITE_VESION` in
`src/spa/__init__.py`. SPA follows Aseprite's
native version compatibility for other releases without an independent version
allowlist, semantic guarantee, or per-release test matrix. The observed requirements
above gate execution; they do not certify identical native pixels on every release.
Feature delivery and claimed host launch paths still require their own real evidence.

A completed Validation can return an Operation Result with typed Validation Findings.
An invalid request, execution failure, or unmet commit gate returns a Failure Envelope;
a Finding is not a command failure.

Public targeting is operation-specific. SPA does not define a universal Selector,
Locator, query language, or cardinality framework because Aseprite objects have
different identity and lifecycle rules. Each Operation defines exact target fields and
target-count rules, and Operation Results report current address and impact facts.

## Execution flows

### Ordinary Core Operation mutation

```mermaid
flowchart TB
    Request["Caller<br/>Typed Operation Request"]
    Inbound["CLI / inbound adapter<br/>Validate and translate request"]
    Preflight["Application use case<br/>Preflight schemas, paths, limits, and eligibility"]
    Discover["Application and Aseprite Adapter<br/>Discover compatible runtime"]
    Stage["Application and File Adapter<br/>Prepare Staged Sprite File"]
    Invoke["Aseprite Adapter<br/>Invoke bound packaged handler"]
    Resolve["Packaged Lua Kernel in Aseprite<br/>Resolve targets and native side effects"]
    Execute["Packaged Lua Kernel in Aseprite<br/>Execute native transaction and Postconditions"]
    Persist["Packaged Lua Kernel in Aseprite<br/>Save, close, reopen, and observe persisted facts"]
    Evidence["Aseprite Adapter to Application<br/>Return Kernel response, process status, and diagnostics"]
    Verify["Application use case<br/>Validate Kernel response and persisted Postconditions"]
    FileFacts["File Adapter<br/>Validate staged path, bytes, and digest"]
    Commit["Application and File Adapter<br/>Target Commit"]
    Result["Caller<br/>Operation Result"]

    Request --> Inbound
    Inbound --> Preflight
    Preflight --> Discover
    Discover --> Stage
    Stage --> Invoke
    Invoke --> Resolve
    Resolve --> Execute
    Execute --> Persist
    Persist --> Evidence
    Evidence --> Verify
    Verify --> FileFacts
    FileFacts --> Commit
    Commit --> Result
```

Any failure before publication produces a Failure Envelope and no Target Commit.

An Ordinary Core Operation with Execution Kind `mutation` resolves and validates its
complete effective target set before it changes the Sprite. Native Linked Cel or Tileset
effects are included in that scope. Supported changes run inside an Aseprite transaction;
staged replacement protects the declared file target. Save, close, reopen, and persisted
observation occur before the one Aseprite invocation returns.

### Operation Plan

An Operation Plan applies eligible read and mutation Operations to one in-memory Sprite
in one Aseprite invocation and adapter unit of work.

```text
Plan Preflight
    -> selected Step and final inspection capability observation and check
    -> Step 1 Preconditions -> shared semantic entry point -> Step 1 Postconditions
    -> Step 2 Preconditions -> shared semantic entry point -> Step 2 Postconditions
    -> ...
    -> Plan Postconditions
    -> zero commits for a read Plan, or one Target Commit for a mutation Plan
```

A later Step can target an object created by an earlier Step, so live target resolution
occurs immediately before each Step. Only Sprite-bound read and mutation Operations
whose Descriptors declare Plan eligibility can be Steps. Export and `script run` are
not eligible. Cross-Sprite workflow, retry, and partial success remain outside the Plan
model.

### Export publication

```mermaid
flowchart TB
    Request[Explicit Export Destinations] --> Expand[Resolve complete expected output set]
    Expand --> Stage[Map to operation-owned staging]
    Stage --> Native[Aseprite renders and encodes through packaged handlers]
    Native --> Decode[Format-specific Artifact Verifiers decode every staged file]
    Decode --> Compare["Owning Application use case<br/>Compare request, Kernel, decoded, and cross-file facts"]
    Compare --> Publish[Publish validated destinations in deterministic order]
    Publish --> Result[Operation Result with Artifact facts]
    Decode -->|failure| VerifyFailure[Failure Envelope; nothing is published]
    Compare -->|failure| VerifyFailure
    Publish -->|failure before any change| PublishFailure[Publication Failure]
    Publish -->|failure after a path changed| PartialFailure[partial_publication with per-path facts]
```

Static image export uses a fixed private composition order for Layer Composition,
Color Profile, Palette preparation, Color Mode, transparency or Background behavior,
and File Format encoding. Other export families own their own feature contracts. Export
never mutates the Source Sprite.

For GIF and PNG sequence, explicit Frames retain occurrence order and duplicates;
an exactly addressed Tag produces one direction traversal without expanding stored
repeats or nested Tags. PNG names use one bounded native occurrence ordinal, and
all occurrences share the full Canvas. Separate format comparisons preserve PNG
native Color Mode, per-Frame Palette and Background-sensitive mask rules while GIF
uses native RGB visual composition, lossy quantization, binary alpha, centisecond
truncation and an infinite encoded loop. ICC-to-sRGB GIF conversion requires the
Color Profile owner's observed runtime capability. An opaque-to-blank native GIF
that fails independent alpha verification stays in staging and is not published.
The current support matrix and limits are described in the [usage guide](docs/usage.md#export)
and constrained by the installed Operation Descriptors; local native evidence is not
a cross-platform or cross-release promise. These exports are not Plan Steps.

`delivery/tileset.py` coordinates one Tileset atlas and normalized map pair.
`tileset_contracts.py` defines its projection and validates complete Tile coverage,
keyed placement correspondence, and explicit Grid mapping. Tile Authoring retains
Tileset/Tile identity and canonical Tile Region Snapshot ownership; Delivery calls
those Lua helpers directly. The native handler copies Tile Images with `BlendMode.SRC`
into one atlas and uses the existing Image encoder with the selected Frame's Effective
Palette. Color and Palette owns Profile restoration and exact ICC identity.
The PNG adapter shares structural decoding across its existing input subset and the
RGB/Grayscale/Indexed Artifact subset. Delivery compares decoded Tile regions with
original native Tile Image digests and parses the separate JSON against native and
request facts. The File Adapter publishes the validated finite pair in caller order
and records partial publication; it has no Tile or PNG semantics.

Sheet, Tileset, and PNG sequence export share `png_color_space()` in
`kernel/delivery/export_image_support.lua`. It copies the native ColorSpace and
uses the admitted ICC identity as the PNG iCCP keyword. Backend display names can
be empty or invalid PNG keywords. This changes only the output label: it preserves
the ICC payload and Source profile, performs no color conversion, and adds no Image
copy. Each exporter retains its profile admission and independent byte/pixel checks;
Color and Palette remains the owner of profile identity and conversion semantics.

A successful result reports the complete declared output set. When an Export has
several final paths, SPA publishes them in a deterministic order. A failure after a
final path changed returns `partial_publication` with the known state of every declared
destination and whether a published path replaced an existing file. SPA does not return
a successful Artifact set, restore replaced files, remove published files, or promise
filesystem atomicity or a general recovery mechanism. The shared failure contract in
`contracts/artifact.py` uses `existed_before` for each destination's prior existence
and requires `replaced_existing` when its state is `published`. The single failure
registration serves Tileset, Sheet, GIF, and PNG sequence output.
A hard interruption can leave
the final state indeterminate; a later request observes existing paths through its
normal explicit `if_exists` policy.

## Invariants and their owners

| Invariant | Knowledge owner | Execution owner |
| --- | --- | --- |
| Public capability has one registration source. | Operation Descriptor. | Descriptor projection into CLI, MCP, and Surface Manifest; Agent Skill checks against the installed surface. |
| Native object and algorithm behavior follows one upstream authority. | Aseprite public semantics and native behavior. | Aseprite, invoked and observed by a packaged handler. |
| Each Ordinary Core Operation has one Core Operation Semantics authority. | Before delivery, its feature issue owns the exact contract under applicable ADR constraints. After delivery, its Descriptor owns the implemented public contract and binding, while tests and evidence artifacts own executed behavior proof. | Its fixed packaged Lua handler is the sole executable Core Operation Semantics authority; Application only invokes and orchestrates it. |
| Public intent does not depend on hidden editor state. | Owning Operation contract. | Python Preflight plus Kernel target and state handling. |
| Success and failure are disjoint typed outcomes. | Published Language and result/failure decision. | Application outcome mapping and adapters. |
| Inspection success is complete for its normalized scope. | Owning inspection Operation. | Kernel observation and Application limit handling. |
| An Ordinary Core Operation with Execution Kind `mutation` is all-or-nothing for its resolved target set. | Mutation decision and owning Operation. | Kernel transaction, persisted native inspection, Staged Sprite File preparation, and Target Commit. |
| Export success reports a complete verified Artifact set. | Export publication decision and feature contract. | Kernel native export; Artifact Verifier decoding; Application semantic comparison; File Adapter publication. |
| Capability Gaps report current restrictions through one feature-owned reason. | Installed Surface Manifest for installed Capability Gaps; feature issue for planned candidate-gap handling and evidence requirements. | Aseprite Adapter collection of runtime observations; tests and evidence artifacts retain executed proof; Surface Manifest generation reports installed Gaps. |

## Failure, bounds, and trust

SPA assumes a trusted local caller, workspace, packaged Operation set, and Aseprite
installation. It provides functional control appropriate to that environment:

- stable failure codes and typed details;
- Operation Limits expressed in native units such as pixels, Tile Cells, Frames, or
  Plan Steps;
- process timeout and captured-output Execution Guards;
- explicit Source Sprite File, Target Sprite File, in-place intent, overwrite behavior,
  and Export Destination;
- native transactions, staged files, Postconditions, and independent output checks; and
- bounded Diagnostics separated from machine output.

These mechanisms serve sprite Operations. They do not establish authentication,
authorization, multi-tenant isolation, distributed locking, service governance,
persistent provenance services, or generalized recovery. Caller-owned Lua is unrestricted and
does not carry a sandbox claim.

## Architecture evolution

The project develops through evidence-bearing vertical slices. Delivery begins with an
end-to-end CLI slice and then deepens the same architecture across sprite authoring,
observation, validation, delivery, agent access, and Asset Pipeline integration.
Feature issues own the exact scope and explicit dependencies of those slices.
Milestones group phase outcomes, and explicit issue dependencies determine implementation
order.

ADR-0095 adds preparation and reusable motion as bounded follow-up work and reclassifies
existing Delivery. Issue #103 owns the delivered bounded preparation contract. The #104 motion
slice verifies wizard and floating-emblem fixtures through standalone and Plan
execution; its [performance evidence](docs/evidence/issue-104-motion-performance.md)
reports a bounded local workload. Existing
Image observation/import and export issues retain their scope. The examples' measured
persisted-write cost motivates a separate Plan-eligibility slice; an architecture
label alone establishes no speedup. These follow-ups do not add acceptance gates to
the completed implementation scope of either wizard example.

[`AUTHORITY_MATRIX.md`](AUTHORITY_MATRIX.md) defines the update order and the owner of
each changed fact. This document changes after the applicable normative source changes
and labels planned, implemented, and installed facts by their owning source.

A new Bounded Context, service, event mechanism, generic abstraction, or compatibility
layer requires evidence that the current model cannot express an accepted functional
need. Physical packages can change as implementation reveals better cohesion, while
the responsibility and dependency rules remain stable until an accepted decision
changes them.

## Decision map

This map is navigation, not a second decision record.

| Concern | Decisions |
| --- | --- |
| Strategic-context decisions and rationale; current model in `CONTEXT.md` | [ADR-0001](docs/adr/0001-single-sprite-automation-context.md), [ADR-0007](docs/adr/0007-demand-driven-nfrs.md), [ADR-0009](docs/adr/0009-command-groups-and-domain-modules.md), [ADR-0095](docs/adr/0095-asset-preparation-authoring-and-delivery.md) |
| Operation contract, Plan, targets, limits, and outcomes | [ADR-0002](docs/adr/0002-operation-descriptor-authority.md), [ADR-0003](docs/adr/0003-operation-plan-boundary.md), [ADR-0006](docs/adr/0006-operation-targets-and-identity.md), [ADR-0008](docs/adr/0008-operation-owned-bounds.md), [ADR-0013](docs/adr/0013-result-and-failure-contract.md) |
| Agent Skill distribution and self-contained guidance | [ADR-0096](docs/adr/0096-agent-skill-delivery.md) |
| Kernel authority and mutation publication | [ADR-0010](docs/adr/0010-lua-operation-kernel-authority.md), [ADR-0014](docs/adr/0014-mutation-file-semantics.md) |
| Document, animation, color, and selection semantics | [ADR-0021](docs/adr/0021-frame-numbering.md), [ADR-0024](docs/adr/0024-color-values-and-conversion.md), [ADR-0025](docs/adr/0025-coordinate-spaces-and-rectangles.md), [ADR-0028](docs/adr/0028-background-layer-and-cels.md), [ADR-0029](docs/adr/0029-selection-as-explicit-value.md), [ADR-0033](docs/adr/0033-tag-playback-semantics.md), [ADR-0035](docs/adr/0035-palette-time-semantics.md), [ADR-0039](docs/adr/0039-slice-model-and-addressing.md) |
| Raster, Tile, Paint, and Filter semantics | [ADR-0018](docs/adr/0018-raster-authoring-boundary.md), [ADR-0041](docs/adr/0041-tileset-and-tile-identity.md), [ADR-0044](docs/adr/0044-tilemap-and-placement-semantics.md), [ADR-0047](docs/adr/0047-preserve-tile-meaning-across-tileset-lifecycle.md), [ADR-0051](docs/adr/0051-shared-image-resize-transform.md), [ADR-0057](docs/adr/0057-canonical-pixel-region-snapshot.md), [ADR-0060](docs/adr/0060-private-native-tool-invocation.md), [ADR-0066](docs/adr/0066-declare-native-stochastic-operations.md), [ADR-0074](docs/adr/0074-shared-native-filter-semantics.md) |
| Color operations and export publication | [ADR-0085](docs/adr/0085-stage-and-verify-explicit-export-destinations.md), [ADR-0089](docs/adr/0089-native-color-operation-boundaries.md), [ADR-0094](docs/adr/0094-export-image-semantics-and-operation-order.md) |

For product scope, see [PRD #1](https://github.com/aigengame/aseprite-automation/issues/1).
For candidate command territory, see the [command catalog](docs/command-catalog.md).
For phase outcomes, see the
[milestones](https://github.com/aigengame/aseprite-automation/milestones). For feature
contracts, explicit dependencies, and delivery status, see the
[feature issues](https://github.com/aigengame/aseprite-automation/issues).
