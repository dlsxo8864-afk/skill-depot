---
name: weilanx-creator-blackgold-video
description: 「黑金光影风」知识短片一键成片工作流：用户只给一个选题（或者只说「做一期」），就一条龙做完：查一手资料 → 定锚词、写选题与分镜脚本 → 卡 we-never 的拍子写时间表 → 合成音效 → 为选题设计专属画面 → 测试 → 自动抽帧和测响度、自己修 → 直接导出成片 → 代码渲染的 3:4 封面 + 发布文案 + 双语字幕稿，全程不停下来问用户确认。成片是横屏 16:9、约 2 分 18 秒、无口播：近黑底暖色烟雾、一切发光，金粒子聚成标题，霓虹收益矩阵 / 天平 / 对账卡把推理画出来，发光角色在聚光灯下演出模型，底部中英双语字幕，两个爆点踩配乐重拍，片尾停在评论区问题。用户说「黑金风做一期」「黑金光影风」「这期做 XX 博弈 / 悖论 / 效应」「用博弈论讲讲 XX」「做个智猪博弈那样的视频」「一条龙做一期知识视频」时都用这个 skill；只要是用一个模型解释一个反直觉现象（博弈论、经济学、决策、认知偏差、概率、AI 原理）的无口播短片，就用它。
---

# 一个反直觉模型 → 一期黑金光影风成片（一键到底）

> **目录约定**：`materials/` 和 `out/` 按风格分类、风格内从 00 编号。本 skill 的风格目录是 `09-黑金光影风`。下文 `<期>` = 作品 ID（如 `ep36-boxed-pigs`），`<素材目录>` / `<成片目录>` 用 `bash scripts/ep-dir.sh <期> materials|out` 查。

**用户调用这个 skill = 授权你从头做到交付**：成片 mp4、3:4 封面、发布文案、双语字幕稿（md + srt），全部放进 `<成片目录>/`。中途**不问用户确认、不停在 Studio 等预览**，每做完一步用一句话同步进度；要拿主意的地方按本文默认值自己定，最后在交付报告里说明替他定了什么。**不提交 git**，除非用户另外要求（要提交走 `git-commit-cc`）。

只有两种情况才停下来问：① 选题查不到任何一手资料、也没有可替换的相近角度；② 工具连续失败两次（渲染崩溃、导出报错）。

**样片：`ep36-boxed-pigs`（智猪博弈：躺平的小猪吃得更多）。新一期先照它的代码改，不要从空白写**：
`src/episodes/ep36-boxed-pigs/`（`timeline.ts` `Ep36Pigs.tsx` `scenes.tsx` `CoverTall.tsx`）、`tests/episodes/ep36-boxed-pigs.test.ts`、`audio/episodes/ep36-boxed-pigs.mjs`。

动手前读：工程根目录 `CLAUDE.md`、`src/library/README.md`「黑金光影风 blackgold/」一节、`styles/我的风格/黑金光影风/README.md`（配方卡，尤其「出彩的手法」）、本 skill 的四份 `references/`。所有 npm / npx / node 命令前先 `export NODE_OPTIONS=--max-old-space-size=4096`。

## 依赖（开源版说明）

这个一锅出工作流不依赖作者的私人工具：画面、封面、字幕稿、发布文案、QA 脚本都在仓库里。唯一要自己准备的是配乐：

- **配乐**：示例统一用音乐库的 we-never，这是作者已获授权的自用曲目，mp3 不随仓库分发。换成你自己有授权的曲子放进 `public/music/`，在 `audio/music.mjs` 的 `TRACKS` 登记，再用 `weilanx-creator-gilded-video/scripts/beats.py` 重测起音、小节长和重拍，改 `timeline.ts` 的网格，画面会跟着对齐。

## 规格（默认值）

| 项 | 默认 |
|---|---|
| 画面 | 横屏 1920×1080、30fps，黑金光影风（`src/library/blackgold/`），独立组件，不走 `Show` |
| 时长 | 256 拍 + 1 秒 ≈ 2 分 17.5 秒 |
| 口播 | 无。底部双语字幕就是旁白：中文宋体 Black 一行（≤ 18 字，`【】`青 = 术语、`〖〗`红 = 亏 / 零 / 陷阱、`〔〕`金 = 数字 / 锚词），下面一行英文斜体意译 |
| 配乐 | **统一用音乐库 we-never**（已授权），从第 0 秒放，−16 LUFS；整片约 −15.5 LUFS、真峰值 ≤ −1 dBFS |
| 爆点 | 17.45 秒（第 32 拍）金粒子聚成标题；102.52 秒（第 192 拍）锚词砸出 + 术语小字 |
| 结尾 | 重新定义锚词 → 评论区问题放到片尾（大号居中）；**不做下期预告** |
| 交付 | `<成片目录>/<期>.mp4`、`封面-3x4.png`、`发布文案.md`、`字幕稿.md`、`字幕.srt`；素材目录里另有 `文案与卡点.md`（选题与分镜脚本） |

## 0. 选题和期号

- **用户给了选题**：直接用。标题写成「现象 + 反常识」的一句话（≤ 12 字，可带冒号副题），副题用观众的处境说（「躺平的小猪吃得更多」）。
- **用户没给**：从 `materials/09-黑金光影风/选题.md` 挑，⭐ 优先；做完把那一行移进「做过的」，写上目录编号和作品 ID。
- **期号**：别的会话也在加期数，**写第一个文件前**再 `ls src/episodes | tail -3`，取最大号 + 1，作品 ID `epNN-英文短名`；撞号就顺延，不动别人的目录。
- **建目录**：`bash scripts/ep-dir.sh <期> materials --new 09-黑金光影风 <中文短题>`（自动编号，materials 和 out 一起建）。

## 1. 查一手资料（不能跳过）

详见 `references/选题与脚本.md`「事实」一节。论文读到摘要、书读到原文段落（网络副本也行），搜索摘要不算数。每个上画面的数字写进 `timeline.ts` 常量并在测试里断言；**能由规则算出来的数（收益矩阵、概率、均衡）写成函数在测试里复算**（ep36 的 `payoff()` 和纳什均衡检验）。

**标题和事实打架时，片里说准确的话**（ep36：课本数字里小猪和大猪净得一样，片里说「躺着拿 4，自己去按只拿 1」，不说「比大猪多」），并在发布文案内部核对里写明口径。

## 2. 选题与分镜脚本（写进 `<素材目录>/文案与卡点.md`）

结构、句子规则、锚词怎么找，照 `references/选题与脚本.md`：锚词（2～4 字，处境不是术语）、钩子 5 条、章节骨架（固定拍号）、逐句双语字幕、卡点表、事实清单、有意不说的、**本期专属的 3～5 个出彩设计**。ep36 那份就是模板。

## 3. 写 timeline.ts（全片唯一时间表）

照 `src/episodes/ep36-boxed-pigs/timeline.ts` 改：网格（`beatSec` / `fbt` / `fb`）、`HIT` / `HIT2` / `DARK_FROM`（`fr(16.7)`）/ `DARK_FROM2`（`fr(101.75)`）/ `FREEZE = 3` / `DURATION`、实测重音数组、`ANCHOR` / `TERM` / `TITLE` / `TITLE_EN` / `TITLE_SUB`、`CUES: [拍号, 中文 | null, 英文][]`（null 行同一行写 `// 说明`）、`HALF_BEATS`、`SHOTS`（首尾相接、每行 `// 说明`）、事实常量和计算函数、舞台布局常量、`SFX`。

硬规则：**timeline.ts 不能 import 别的 .ts / .tsx**（`qa.mjs` 和 `subtitles.mjs` 用 Node 直接加载它）；画面里每个元素的出场帧必须落在所在镜头的时间范围内。卡点和音效表见 `references/卡点与音效.md`。

## 4. 音频

```sh
sed 's/ep36-boxed-pigs/<期>/g' audio/episodes/ep36-boxed-pigs.mjs > audio/episodes/<期>.mjs   # 再改注释和本期专属音效
node audio/episodes/<期>.mjs
```

本期的动作音（ep36 的拉杆咔哒、食粒落槽、小碎步）按选题换成自己的（ffmpeg `aevalsrc` 合成，峰值压到约 −6 dBFS），通用的 chime / impact / room / riser 保留。

## 5. 画面

详见 `references/画面与镜头.md`。先复用 `src/library/blackgold/`（`stage` 舞台和字幕、`props` 道具、`charts` 模型图、`pen` 动物实验场），再**为这个选题设计 3～5 个只属于它的出彩元素**（用户 2026-10-13 明确要求：不要局限于素材包，要发挥想象力；好用的全部沉淀进素材库）。本期新写的组件下次还能用的，挪进 `src/library/blackgold/` 并补 README 和配方卡。

硬规则：动画是帧号的纯函数，随机只用 `rand(seed)`；素材库不 import `src/episodes/`；不画真实人物肖像和第三方 logo；示意画面标「示意」。

## 6. 注册和测试

- `src/Root.tsx` 在 `<Folder name="09-黑金光影风">` 里、最近一期后面注册 `<Composition id="<期>" …>` 和封面 `<Still id="<期>-cover-tall" … width={1080} height={1440} />`（import 变量名带期号）。
- 测试照 `tests/episodes/ep36-boxed-pigs.test.ts` 改：卡点 ±2 帧、片长、字幕规则（≤ 18 字、都有英文、话说一半以「——」结尾、锚词开头结尾都出现、最后一句是问题）、镜头首尾相接、事实和计算、音效在片长内且文件存在。
- `npm run typecheck && npm test`，全绿才往下走。

## 7. 自动自查（自己修，最多三轮）

```sh
node .claude/skills/weilanx-creator-blackgold-video/scripts/qa.mjs <期>
```

每个镜头切走前一帧 + 两个爆点 −16 / −3 / +2 帧拼成网格，测整片响度和被配乐盖住的音效，产物在 `/tmp/<期>/qa/`。Read 逐张看 `sheet-*.jpg` 和 `hits.jpg`，按 `references/画面与镜头.md` 末尾清单查；改完只重渲改过的镜头：`qa.mjs <期> --frames-only=镜头A,镜头B`，改了音量再跑 `--audio`。另外抽几帧镜头**中段**看动画过程（天平在晃、角色在跑、对账卡在跳）。三轮后的小瑕疵写进交付报告。

## 8. 导出 → 9. 封面、文案、字幕（导出在后台跑的同时做）

```sh
npm run export -- <期>     # 后台跑，约 5 分钟 → <成片目录>/<期>.mp4
```

- 导完 `ffprobe` 看分辨率和时长、`ebur128=peak=true` 看响度，从成片抽 4 帧（17.6、中段、102.7、结尾）拼起来 Read 一眼。
- **封面**：代码渲染（`CoverTall.tsx`，1080×1440），不用 AI 生图；`npx remotion still src/index.ts <期>-cover-tall <素材目录>/封面-3x4.png`，Read 检查。
- **字幕**：`node .claude/skills/weilanx-creator-blackgold-video/scripts/subtitles.mjs <期> <素材目录>` → `字幕稿.md` + `字幕.srt`。
- **发布文案**：`<素材目录>/发布文案.md`。
- 详见 `references/封面与发布.md`。封面、文案、字幕稿、srt 都复制到 `<成片目录>/`。

## 10. 收尾登记

- `styles/我的风格/黑金光影风/README.md` 期数表补一行（用到的组件 + 本期新手法补进「出彩的手法」）；`styles/README.md` 黑金那一行期数补上。
- `materials/09-黑金光影风/README.md`、`out/09-黑金光影风/README.md` 的目录表补一行；`选题.md` 把这题移进「做过的」。
- `public/music/README.md` we-never 那一行补上期号。
- 新组件进 `src/library/blackgold/` 并补 `src/library/README.md`。
- 最后再跑一次 `npm run typecheck && npm test`。

## 11. 交付报告（回复用户）

1. `<成片目录>/` 里的五样东西；成片分辨率、时长、响度、峰值；Studio 地址 `http://localhost:3000/<期>`。
2. 锚词和它出现的位置；分镜表（时间 | 配乐 | 画面 | 讲什么）。
3. 事实来源（全名 + 年份），哪些读到原文、哪些只读到摘要、哪些是自己算的、哪些是示意；标题和事实之间的口径。
4. 本期新设计的出彩元素，以及沉淀进素材库的组件。
5. 替他定了什么（标题改写、期号顺延、锚词）；自查修了什么、剩什么小瑕疵。
6. 听感要他自己确认（你听不到声音，只报数字）。
