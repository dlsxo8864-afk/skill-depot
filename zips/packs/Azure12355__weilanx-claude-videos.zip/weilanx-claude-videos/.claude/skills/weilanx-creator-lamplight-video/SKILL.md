---
name: weilanx-creator-lamplight-video
description: 「灯火史话风」中国古代知识短视频工作流：给一个古代制度、律令、城市生活或冷知识的题（八百里加急、宵禁、过所、打更、军巡铺、科举号舍……），先查一手史料、对着 we-never 的实测硬拍写一份带强钩子的文案与卡点稿给用户确认，再在 weilanx-claude-videos 工程里做成横屏 16:9、约 2 分 18 秒、无口播的视频：暖黑夜色 + 火光 + 米白象形小人，左上角宋体大字逐字写出叙述、关键词按含义上色划线，地形图发光路线、透视城市逐格亮灯、纸卷律文、全屏砸字，镜头和音效全部卡拍；最后 Studio 预览、确认后导出，并做代码渲染的 3:4 封面、发布文案和字幕稿。用户说「做一期中国古代的」「灯火史话风做一期」「像八百里加急那期一样」「讲讲古代的 XX / 古人怎么 XX」「唐朝 / 宋朝 / 清朝的某个规矩」「做一期历史冷知识视频」时都用这个 skill；只要是用画面讲一条古代规矩背后故事的无口播短片，即使没提风格名也用它。
---

# 一条古代规矩 → 一期灯火史话风视频

> **目录约定（2026-10-13 起）**：`materials/` 和 `out/` 按风格分类、风格内从 00 编号，代码里的作品 ID（下文的 `<期>`）不变。下文 `<素材目录>` = `materials/<风格>/<编号-中文短题>/`，`<成片目录>` = `out/` 下同名目录。新一期开工时先建：`bash scripts/ep-dir.sh <期> materials --new <风格目录> <中文短题>`（自动取下一个编号，materials 和 out 一起建）；之后查路径用 `bash scripts/ep-dir.sh <期> materials` / `bash scripts/ep-dir.sh <期> out`。`npm run export -- <期>` 会自动把成片放进 `<成片目录>`。
> 本 skill 的风格目录是 `08-灯火史话风`。

参考样片：`ep28-express-relay`（「八百里加急」到底有多快？2 分 17.5 秒）。用户认可的就是这一期：

- **开场 9 秒打掉一个误会**：「你以为八百里加急，是一匹马一天跑八百里？」→ 第 7、8 拍马倒下、右上「800 里」被红线划掉 → 第 11–16 拍一条路上三座驿站随驿铃亮起 →「那它到底，能跑多快——」收暗 → 17.45 秒标题砸出。
- **按朝代推进，每章一种画面**：纸卷律文（《唐六典》）→ 满地光点（1639 座驿站）→ 地形图路线（安禄山 6 天）→ 唐律纸卷 + 全屏红字「绞」→ 金字牌 → 清朝档位卡 → 十匹马死七匹。
- **配乐回落段 11 下硬拍 = 11 座驿站依次点亮**，北京一站站推到兰州；102.52 秒砸出锚词「奇迹」，结尾重新定义它：「它没有消失，它变成了一句话：八百里加急」+ 评论区问题 + 下期预告。
- **所有数字出自史料原文**，画面底部写出处，测试逐条核对；查不到原文的说法不当成规定讲（「八百里」只是俗称，正式档位最高六百里）。

画面组件在 `src/library/lamplight/`（目录见 `src/library/README.md`「灯火史话风」），风格配方见 `styles/我的风格/灯火史话风/README.md`，风格是从两支参考视频（不进 git）蒸馏出来的。

## 依赖（开源版说明）

- **配乐**：示例统一用音乐库的 we-never，这是作者已获授权的自用曲目，mp3 不随仓库分发。换成你自己有授权的曲子放进 `public/music/`，在 `audio/music.mjs` 的 `TRACKS` 登记，再用 `weilanx-creator-gilded-video/scripts/beats.py` 重测起音、小节长和重拍，改 `timeline.ts` 的网格，画面会跟着对齐。
- **标题**：备选标题的公式编号来自作者的私人 Skill `dbs-xhs-title`，没有就让 Agent 按「≤ 20 字、留悬念不说答案」起。

## 两个停顿点

1. **第 4 步写完文案与卡点稿后停下**，把钩子、逐句文案、卡点表、事实清单发给用户确认（ep28 用户就是在这一步看完说「没问题，开始做视频」）。用户改了就照改。
2. **第 10 步打开 Studio 后停下**，等用户说可以再导出。

其余步骤一口气做完，每步做完用一两句话同步进度。**不提交 git**，除非用户另外要求（要提交走 `git-commit-cc`）。动手前先读工程根目录 `CLAUDE.md`、`src/library/README.md`「灯火史话风」一节、风格配方卡。所有 npm / npx / node 命令前先 `export NODE_OPTIONS=--max-old-space-size=4096`。

## 规格

| 项 | 默认 |
|---|---|
| 画面 | 横屏 1920×1080、30fps，灯火史话风（`src/library/lamplight/`），独立组件，不走 `Show` |
| 时长 | 256 拍 + 1 秒 ≈ 2 分 17.5 秒；用户给了时长按用户的 |
| 口播 | 无。左上角叙述就是字幕：宋体 Black 逐字收拢，`【】`蓝 = 名词 / 制度、`〖〗`红 = 惩罚 / 死亡 / 极限、`〔〕`金 = 速度 / 数量 / 答案 |
| 配乐 | 音乐库 we-never（已授权），从第 0 秒放，−16 LUFS |
| 音效 | `audio/sfx-lamplight.mjs`（马蹄 hoof、大鼓 drum、点火 ignite、驿铃 bell）+ `audio/sfx-tactical.mjs` 的 impact / riser / tick + 共享 whoosh / paper / stamp，约 60 处，全部卡拍 |
| 交付 | 成片 `<成片目录>/<期>.mp4` + 3:4 封面 + 发布文案 + 字幕稿 |

## 0. 定期数和目录

期号取 `src/episodes/` 里最大的下一个，作品 ID `epNN-英文短名`（下面记作 `<期>`）。代码 `src/episodes/<期>/`（`timeline.ts` + `scenes.tsx` + `Ep*.tsx` + `CoverTall.tsx`），音频脚本 `audio/episodes/<期>.mjs`（产物 `public/audio/<期>/` 不进 git），测试 `tests/episodes/<期>.test.ts`，文案、封面、字幕稿放 `<素材目录>/`（不进 git）。

## 1. 选题

详见 `references/选题与史料.md`：好选题 = 一条**人人听过但理解错的说法或规矩** + **能被画出来的模型**（路线、城市、档位、数量）+ **能查到原文的数字**。选题池和做过的题都在那份文档里，片尾预告过的下期优先。

## 2. 查史料（不能跳过）

- 每个要上画面的数字、律文、原话都要读到原文：维基文库（`curl …?action=raw` 拿全文再 grep）、识典古籍、5000yan 这类全文站；学者文章（澎湃、社科院）可以用来找线索和清代数字，标明转引。
- 搜索摘要不算数；只在二手文章里见过的，要么不用，要么画面写「据某某转引」并在核对清单里标出来。
- 干支、里程这类要自己算的，算法写进测试（ep28：甲子 → 庚午 = 6 天）。
- 俗称不当规定讲，各版本数字不一致的取主流本并在核对清单里注明。

## 3. 配乐卡点

详见 `references/叙事与卡点.md`。默认 we-never，网格直接用：`BAR = (102.52 − 17.45) / 40`、`BAR0 = 17.45 − 8·BAR`、一拍 `BAR/4`，实测硬拍表在那份文档里。换曲子先跑：

```sh
uv run --with numpy python .claude/skills/weilanx-creator-lamplight-video/scripts/beat_accents.py public/music/<曲>.mp3 [--bar 小节秒数 --b0 第0拍秒数]
```

跳变 ≥ 10 dB 的「砸点」一拍一个动作，5–6 dB 的强拍放换镜头和关键数字。

## 4. 写文案与卡点稿 → 停下等确认

照 `references/叙事与卡点.md` 的结构写进 `<素材目录>/文案与卡点.md`（ep28 那份就是模板）：配乐硬拍表、5 个钩子、逐句表（拍 | 秒 | 文字 | 画面 | 卡点）、事实清单（说法 | 出处 | 核对情况）、有意不说的、要新做的组件。中文每句不超过 24 字（含数字），锚词 2～4 字。

回复里给用户：钩子 5 条、骨架、事实核对情况（哪些读到原文、哪些是转引）、下一步。**等用户确认。**

## 5. 写 timeline.ts（全片唯一时间表）

照 `src/episodes/ep28-express-relay/timeline.ts`：网格（`beatSec` / `fbt` / `fb`）、`HIT` / `HIT2` / `DARK_FROM`（`fr(16.7)`）/ `DARK_FROM2`（`fr(101.75)`）/ `FREEZE = 3` / `DURATION`；实测重音数组；`CUES: [拍号, 文字 | null, 另起一屏?]`（null 那行写 `// 说明`，字幕稿脚本会读）；`HALF_BEATS`；大字卡文案；`SHOTS`（首尾相接、落在拍点上，每行 `// 说明`）；事实常量（带出处注释）；地图地点和路线（`wiggle`）；`SFX`。

## 6. 音频

`audio/episodes/<期>.mjs`（照 ep28）：`cutMusic({track: 'we-never', start: 0, duration: DURATION, ep, fadeIn: 0.02, fadeOut: 2})`，成功后 `makeTacticalSfx(EP)` + `makeLamplightSfx(EP)`。运行 `node audio/episodes/<期>.mjs`。音量表见 `references/叙事与卡点.md`。

## 7. 画面

详见 `references/画面与镜头.md`：内容 → 组件对照、叙述分屏逻辑、地图镜头、ep28 踩过的坑。先复用 `src/library/lamplight/` 和 `src/episodes/ep28-express-relay/`（`NightRoad` 夜路、`MapView` 地图镜头、`FlowDots`、`darkness`、`panelAt`、`punch`）；本期新写的组件下次还能用就挪进素材库并补 README。

硬规则：动画是帧号的纯函数，随机只用 `rand(seed)`；素材库不 import `src/episodes/`；人物一律米白象形小人、不画真实人物肖像；地形是程序生成的假地形，地点只是示意。

## 8. 注册和测试

- `src/Root.tsx` 注册 `<Composition id="<期>" …>` 和封面 `<Still id="<期>-cover-tall" … width={1080} height={1440} />`。
- 测试照 `tests/episodes/ep28-express-relay.test.ts`：爆点、开场重音、回落段硬拍离实测时间不超过 2 帧；片长；叙述按拍递增、≤ 24 字、话说一半以「——」结尾且另起一屏、锚词出现；镜头首尾相接；事实常量和原文一致、叙述里的数字和常量对得上；音效在片长内、关键拍上有冲击和驿铃、文件存在。
- `npm run typecheck && npm test`。

## 9. 抽帧和音频自查

- 每个镜头 3/4 处一帧，**一次只渲一帧**：
  ```sh
  python3 .claude/skills/weilanx-creator-lamplight-video/scripts/shot_frames.py src/episodes/<期>/timeline.ts > /tmp/<期>/frames.txt
  while read n fr; do npx remotion still src/index.ts <期> /tmp/<期>/$n.jpg --frame=$fr --scale=0.4 --timeout=120000 --log=error; done < /tmp/<期>/frames.txt
  ```
  用 ffmpeg `hstack` / `vstack` 拼成网格看：文字压字、纸卷溢出、地名和右上数字撞车、马的姿势、地图路线出画。改完重渲改过的镜头，至少两轮。
- 两个爆点各看 −16、−3、+2 帧：收暗 → 静止 → 爆发（标题卡和锚词在 +2 帧必须已经亮）。
- 音频：`npx remotion render src/index.ts <期> /tmp/<期>/a.wav --codec=wav`，`ebur128=peak=true` 看整片（约 −15 LUFS）、`volumedetect` 看峰值（≤ −1 dBFS）；超了就找峰值所在的 0.1 秒窗口，通常是「冲击 + 铃 + 蹄 + 配乐重音」叠在同一拍，去掉或压低冲击。驿铃用 1.2–4.5 kHz 频段比前后能量（要高出 10 dB 以上），全频 RMS 会被配乐重音淹掉、量不准。**听不到声音要如实说**，只报数字。

## 10. 预览，等确认再导出

- Studio：`http://localhost:3000/<期>`（没开就后台起 `npx remotion studio src/index.ts --no-open --port 3000`）。
- 回复里给：卡点表（时间 | 配乐 | 画面）、自查改了什么、响度和峰值、需要用户帮忙听 / 核对的地方。
- 用户确认后：`npm run export -- <期>`（后台跑；机器上有别的导出时会慢很多，查进程确认在跑），报告分辨率、时长、响度、峰值，并从成片抽 4～6 个卡点帧核对。无口播的期数 `export.sh` 不出分轨，用户要再单独导配乐和音效。

## 11. 封面、发布文案、字幕稿

详见 `references/封面与发布.md`：

- **封面**：代码渲染（不用 AI 生图，中文一个字不会错、画风和片子一致），照 `src/episodes/ep28-express-relay/CoverTall.tsx`；`npx remotion still src/index.ts <期>-cover-tall <素材目录>/封面-3x4.png`，Read 看一眼再交。
- **字幕稿**：`python3 .claude/skills/weilanx-creator-lamplight-video/scripts/subtitle_doc.py src/episodes/<期>/timeline.ts <素材目录>/字幕稿.md`。
- **发布文案**：`<素材目录>/发布文案.md`，标题和封面一致，备选标题用 `dbs-xhs-title` 的公式（标编号），结构照 ep28。
- 三样都复制到 `<成片目录>/`（以后重新导出时 `export.sh` 会自动从 `<素材目录>/` 带上）。

## 收尾登记

- `styles/我的风格/灯火史话风/README.md` 期数表补一行；`styles/README.md`「我的风格」表期数一栏补上。
- `public/music/README.md` 记这一期用了哪段配乐（实测的新重音也记上）。
- 新组件进 `src/library/lamplight/` 并补 `src/library/README.md`；用过的选题从 `references/选题与史料.md` 的选题池移到「做过的」，新想到的题补进去。
