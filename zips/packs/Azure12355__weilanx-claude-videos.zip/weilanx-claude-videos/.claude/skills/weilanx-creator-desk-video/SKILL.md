---
name: weilanx-creator-desk-video
description: 「暖纸工作台风」口播视频工作流：用户给一个主题（多是「我是怎么用 AI 做 XX 的」「一件事分几步」这类流程拆解），依次写口播稿、复刻音色配音并加速 1.2 倍、转 SRT；或者用户给一段自己录好的真人口播视频，直接转 SRT 并把真人放进左下角出镜小窗做 A-roll / B-roll。在 weilanx-claude-videos 工程里做成横屏 16:9 的口播视频：暖米色点阵纸当工作台（柔光晕 + 漂浮几何），白色窗口卡片和主视觉图形（清单、终端、同心圆、胶片、流程卡）一层层摆上来又滑走，阿里巴巴普惠体粗黑体标题 + 一块朱橙渐变高亮，顶部步骤条随口播推进，右下角像素吉祥物 CC 常驻换表情，字幕在底部；再出 3:4 封面和发布文案，打开 Studio 给用户预览，确认后导出（成片 + 分轨 + 封面 + 字幕稿 + 文案）。用户说「用暖纸风做一期」「做一期流程拆解」「像 dl(4) 那种口播风格做一期」「用工作台风格讲讲 XX」「做一期 XX 分几步」「我录好了口播，用暖纸风做出来」时都用这个 skill。
---

# 一个主题 / 一段真人口播 → 一期暖纸工作台风口播视频

> **目录约定（2026-10-13 起）**：`materials/` 和 `out/` 按风格分类、风格内从 00 编号，代码里的作品 ID（下文的 `<期>`）不变。下文 `<素材目录>` = `materials/<风格>/<编号-中文短题>/`，`<成片目录>` = `out/` 下同名目录。新一期开工时先建：`bash scripts/ep-dir.sh <期> materials --new <风格目录> <中文短题>`（自动取下一个编号，materials 和 out 一起建）；之后查路径用 `bash scripts/ep-dir.sh <期> materials` / `bash scripts/ep-dir.sh <期> out`。`npm run export -- <期>` 会自动把成片放进 `<成片目录>`。
> 本 skill 的风格目录是 `07-暖纸工作台风`。

风格配方：`styles/我的风格/暖纸工作台风/README.md`（从一支参考视频蒸馏，参考视频不进 git）；素材包 `src/library/warm-desk/`；口播骨架 `DeskShow`；最小例子 `src/library/previews/WarmDeskShowDemo.tsx`（Studio 里 `library-warm-desk-show`），全部组件一览 `library-warm-desk`，封面 `library-warm-desk-cover`。**真人出镜的样片是 `ep26-opus-video`**（用户认可的版本：左下角出镜小窗、A/B-roll 交替、每个场景一个主视觉），做真人口播时先读它的 `scenes.tsx` 和 `Ep26OpusVideo.tsx`。

这套风格的灵魂：**一张纸、一条步骤线、一个吉祥物**。观众始终知道「现在讲到第几步」（顶部步骤条），每句口播都有一张卡片在桌上发生变化，结论用粗黑体大字 + 朱橙块砸下来。

用户对画面的要求是**丰富、优雅、有设计感**——只摆一张卡片 + 一行字会被说「太素、太单调」。具体做法见下面「画面质量线」和 `references/画面配方.md`。

按第 0～6 步一口气做完，中途不等用户确认，每步做完用一两句话同步进度；第 6 步打开 Studio 后停下，**用户确认后才导出**；不提交 git，除非用户另外要求。动手前先读工程根目录 `CLAUDE.md`、`src/library/README.md`「暖纸工作台风」一节、风格配方卡。所有 npm / npx / node 命令前先 `export NODE_OPTIONS=--max-old-space-size=4096`。

## 依赖（开源版说明）

这个工作流原本串起了作者的几个私人 Skill，仓库里没有带。换成你自己的工具即可，接口只要求「输入文本 / 音频，输出文件」：

| 步骤 | 作者用的私人 Skill | 换成 |
|---|---|---|
| 写口播稿 | `weilanx-creator-spoken-script` | 自己写，或让 Agent 按「强钩子开头、句子连贯、不用冒号括号」写 |
| 配音 | `weilanx-doubao-voice-clone`（豆包复刻音色） | 任何 TTS 或真人录音，输出 wav / mp3 |
| 字幕 | `weilanx-doubao-voice-srt`（豆包录音识别） | 任何语音识别工具，输出 SRT |
| 标题 | `dbs-xhs-title`（标题公式库） | 自己起标题，或让 Agent 按「≤ 20 字、留悬念」写 |

真人出镜的 `footage/<期>/host.mp4` 不在仓库里，换成你自己的录像。字幕导入、出片、导出这些工程内的步骤都不依赖上面的私人工具。

## 两种来源

| | 配音口播（默认） | 真人口播（用户给了录好的视频） |
|---|---|---|
| 口播 | 第 1～2 步：写稿 → 复刻音色 → 1.2 倍速 | 跳过第 1～2 步，用户的录音就是口播，不加速 |
| 字幕 | 识别加速后的配音 | 识别原录音（`weilanx-doubao-voice-srt`） |
| 画面 | 卡片占满主内容区 | 左下角出镜小窗 `HostCam`：A-roll 放大（人是主角）、B-roll 缩小（卡片是主角） |
| 结构 | 开场钩子 → 摊开过程 → 3～7 步 → 金句 → 关注 | 跟着用户的口播走，同样拆成 开场 / 章节 / 收尾 |

## 规格

| 项 | 默认 |
|---|---|
| 画面 | 横屏 1920×1080、30fps，`DeskShow` 骨架，首帧横版封面 `DeskCoverWide`；`decor` 开背景漂浮几何（避开内容区），`push` 默认 2.5% 场景内缓推 |
| 配色 / 字体 | 唯一强调色朱橙 `#f15a35`（大色块用 `OG` 渐变）；全部阿里巴巴普惠体 3.0（`DF.sans` / `DF.serif` 都指向它，标题 900、字幕 800、卡片 700），本机没装时回落思源黑体 Heavy |
| 时长 | 2～3 分钟（口播 800～1100 字，加速 1.2 倍后）；用户给了时长或录好了视频，按用户的 |
| 结构 | 开场钩子 → 「今天把整个过程摊开」→ 3～7 步，每步一个章节大标题 → 收束金句 → 关注卡 |
| 人声 | **−19 LUFS**（用户嫌 −16 太响），峰值 ≤ −1.5 dBFS |
| 配乐 | `buildBgm` 合成，`light` / `groove` 为主，**`level: 0.05`**、`depth 0.7`，`DeskShowConfig.bgmVolume: 0.85`（人声 + 配乐合计约 −19 LUFS） |
| 音效 | 共享音效：卡片落下 `paper` / `pop`，步骤点亮 `ding`，选择 `click`，打字 `type`，揭晓 `magic`，换章 `whoosh`；**音量 0.16–0.26**，宁轻勿重 |
| 封面 | 3:4 竖版 `DeskCoverTall`（1080×1440，平台单独上传用） |

## 画面质量线（每个场景都要过）

1. **一个主视觉**：每个 B-roll 场景挑一个当主角——信息卡（`props.tsx`：清单、深色终端、表格……）或设计图形（`motifs.tsx`：同心圆、胶片条、图标大卡、流程卡、播放卡、悬念卡、徽章），不要只有一行字。
2. **一句粗黑体标题**带 `kicker` 小眉标（短橙线 + 灰字），关键词 `〔词〕` 橙块刷入 + 星光。
3. **层次**：卡片带 `stack` 叠纸或倾斜 ±2°，主视觉旁边放一个辅助元素（标签、胶片条、播放卡、徽章），背景有柔光和漂浮几何。
4. **动效**：入场都是回弹 + 去模糊（`rise` / `Rise` 已内置），列表从左滑入，图形逐层点亮，挂在 `cw` 的词上；揭晓时 `Sparkle`（放在内容**后面**，DOM 里先画，不然线条压字）。
5. **不编数据**：缩略图、示意画面用风格配色画极简示意，不放假截图、不编时长和播放量。

## 0. 定期数和目录

- 期号取 `src/episodes/` 里最大的下一个，作品 ID `epNN-英文短名`，下面记作 `<期>`。
- 素材 `<素材目录>/`，代码 `src/episodes/<期>/`，音频 `public/audio/<期>/`，配乐脚本 `audio/episodes/<期>.mjs`，测试 `tests/episodes/<期>.test.ts`。
- 选题候选池 `materials/00-公共/选题候选池.md`：开工把那一行改成 🎬，导出后改 ✅ 并填期号。

## 1. 写口播稿（真人口播跳过）

调用 `weilanx-creator-spoken-script` Skill，交代清楚这是「流程拆解」：

- 先抛结果或反差（「你现在看的这条 XX，全是 AI 做的」「我只说了一句话」），再说「今天就把整个过程摊开给你看」。
- 正文按步骤讲，**步骤名 2～3 个字**（会直接上步骤条和章节标题），每步开头一句「第 N 步」；每步讲：做了什么 → 卡在哪 → 怎么解决的。
- 结尾一句能当大字的金句（会用橙块高亮其中一个词），再一句关注引导。
- 存 `<素材目录>/口播稿.txt`（只放能念的正文），回复里贴全文、字数和要核对的事实。

## 2. 配音并加速 1.2 倍（真人口播跳过）

调用 `weilanx-doubao-voice-clone`：

```sh
python3 scripts/voice.py status
python3 scripts/voice.py synthesize --text-file <工程>/<素材目录>/口播稿.txt --output <工程>/<素材目录>/<期>-口播-中文标准版.mp3
ffmpeg -i <素材目录>/<期>-口播-中文标准版.mp3 -filter:a atempo=1.2 -ar 48000 -c:a pcm_s16le <素材目录>/<期>-口播-1.2x.wav
```

## 3. 转 SRT

调用 `weilanx-doubao-voice-srt`：配音口播识别**已加速**的 `<期>-口播-1.2x.wav`（不要再加速）；真人口播直接识别原录音。用口播稿（有的话）校对用字，每行 6～16 字、去标点。输出 `<素材目录>/字幕.srt` 和 `字幕稿.md`（文件名固定，导出时会复制）。识别和稿子对不上的地方记下来，最后提醒用户去听。

## 4. 建工程

详见 `references/工程模板.md`（文件清单 + 每个文件的模板代码，含真人出镜版）和 `references/画面配方.md`（每类口播内容用哪个组件、主视觉怎么选、版式安全区、节奏和音效）。

1. **人声**：`ebur128` 测响度 → `volume=<增益>dB,alimiter=limit=0.8:level=false` 调到 **−19 LUFS**（±0.5）→ 48kHz 立体声 16-bit → `public/audio/<期>/voice.wav`。真人口播从原视频里抽（`-vn`）。
2. **出镜视频（真人口播）**：裁成方形、H.264、去音轨 → `public/footage/<期>/host.mp4`（命令见工程模板）；人声只走 `voice.wav`，小窗静音。
3. **字幕**：`npm run cues -- <素材目录>/字幕.srt src/episodes/<期>/cues.json`；`cues.ts` 里 `VOICE_SECONDS` = 人声时长 + 0.3～0.5 秒，且不短于最后一条字幕结束。
4. **配乐**：`audio/episodes/<期>.mjs` 写段落表调 `buildBgm({…, level: 0.05})`，只跑 `node audio/episodes/<期>.mjs`。
5. **场景表**：`src/episodes/<期>/scenes.tsx` 导出 `DeskScene[]`（真人口播再加 `roll: 'A' | 'B'`），每句或每两句口播一个场景，`from = cf(n) − 6`；动画挂 `cf(n)` / `cw(n, '词')`；步骤场景填 `step`，开场和结尾不填（步骤条只在正文出现）；吉祥物表情 `eyes`、跳一下 `hop`、头顶小反应 `emotes` 跟着口播情绪走；每个场景配音效。每个场景过一遍「画面质量线」。
6. **配置**：`Ep*.tsx` 写 `DeskShowConfig`（`steps`、`cover` 用 `DeskCoverWide` 且 `frames: cf(1) − 5`、`bgmVolume: 0.85`、`decor` 避开内容区）；真人口播加 `overlay`（`HostCam` + `camAt`）、`mascot: {x: 1700, y: 1000, s: 0.75}`。组件接 `mix` 透传给 `DeskShow`（导出分轨要用）。
7. **竖版封面**：`Cover.tsx` 用 `DeskCoverTall`，在 `Root.tsx` 注册 `<期>-cover-tall` 的 Still，渲染到 `<素材目录>/封面-3x4.png`：`npx remotion still src/index.ts <期>-cover-tall <素材目录>/封面-3x4.png`。
8. **注册和测试**：`Root.tsx` 注册 `<Composition id="<期>" … defaultProps={{mix: 'all'}}>`；测试照 `references/工程模板.md`（场景按时间递增、步骤号不越界、字幕在时长内、`cw` 的词都在字幕里、音效名存在；真人口播加「小窗始终在左下角」）；`npm run typecheck && npm test`。

## 5. 抽帧自查

- 第 0 帧（封面）、封面淡出那几帧、每个场景 3/4 处各一帧，关键动画中间态（橙块刷到一半、步骤切换那一帧、星光迸发那一帧）也抽；一次只渲一帧：`npx remotion still src/index.ts <期> /tmp/<期>/x.jpg --frame=N --scale=0.5 --timeout=120000`，逐张看。
- 逐条查 `画面配方.md` 的「自查清单」和上面的「画面质量线」：主视觉有没有、够不够大、星光有没有压字、有没有压到右下角吉祥物区 / 左下角出镜小窗 / 底部字幕区、步骤条是不是跟口播同步、一个画面里是不是只有一种强调色。
- 发现问题就改，改完再抽帧确认。

## 6. 发布文案 + Studio 预览（然后停下）

- 调用 `dbs-xhs-title` 出标题：主标题 1 个 + 备选 2 个，注明公式编号，含标点不超过 20 字。
- 描述：钩子一句 → 步骤清单（每步一句做了什么）→ 观众能拿走的做法 → 话题。存 `<素材目录>/发布文案.md`。
- `lsof -i :3000 -sTCP:LISTEN` 看 Studio 在不在，不在就后台起 `npm run studio`；给 `http://localhost:3000/<期>`。
- 汇报：字数和时长、人声 / 配乐响度、字幕条数、封面路径、标题和备选、场景表（时间 | A/B | 步骤 | 主视觉）、要核对的事实、TTS 可能读错的地方；**听不到声音要如实说**，只报数字，听感请用户确认。**不要导出**。

## 7. 导出（用户确认后）

`npm run export -- <期>` → `<成片目录>/`：成片（分轨重混限幅）、`stems/`、`封面-3x4.png`、`字幕稿.md`、`发布文案.md`。检查 1920×1080、首帧是封面、约 −19 LUFS、峰值低于 −1 dBFS；成片复制一份到 `<素材目录>/`。

## 收尾登记

- 风格配方卡的期数表补一行，`styles/README.md`「我的风格」表期数栏补上。
- 新写的通用组件挪进 `src/library/warm-desk/`（信息卡进 `props.tsx`，设计图形进 `motifs.tsx`）并补 `src/library/README.md`。
