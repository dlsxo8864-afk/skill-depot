---
key: foliage
kind: material
---
# foliage — material learnings

One file per material (keeps the catalog from bloating). Consult this
BEFORE building 'foliage'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — palm frond / leaf green
material.diffuse(color=(0.12,0.34,0.10), roughness 0.8) for fronds/leaves. Single-sided leaflet faces render fine in Cycles (two-sided diffuse shading) so no need to thicken them. For more realism: slight 2-tone (lighter tip), a touch of translucency (backlit leaves), and roughness variation -- TODO. Light outdoors with a warm sun + a blue-ish world_sky (~1.2 strength) for ambient/sky reflection.
- verified_by: _tmp/coconut/coconut_persp.png

## 2026-06-21 — translucent leaf shader (TODO done)
material.foliage(color, roughness, translucency) added to material.py: a Diffuse BSDF mixed with a Translucent BSDF (factor ~translucency 0.3) whose tint is a lighter/warmer green (light through a leaf). Fulfils the v1 TODO. ONLY visible with a BACKLIGHT (sun behind the leaves relative to camera) -- front-lit leaves look the same as plain diffuse. Use 2 tints (darker inner / lighter outer fronds) for crown depth.
- verified_by: _tmp/coconut/coconut_v3_persp.png — backlit fronds glow

## 2026-06-21 — pine/conifer green tint
Conifer needles are DARKER and bluer than palm fronds: material.foliage(color ~(0.06,0.18,0.08) dark lower / (0.10,0.26,0.11) lighter upper), translucency ~0.22-0.28. Two tints (dark lower tiers, lighter upper) for crown depth. Same Diffuse+Translucent shader as the palm; backlight to show translucency.
- verified_by: _tmp/pine/pine_persp.png
