# Material learnings — index

One line per material; open the linked file for the detail.

- [polished steel](polished-steel.md) — metallic 1.0, roughness 0.14, anisotropic 0.7; needs strip-softbox streak + Cycles
- [brass](brass.md) — metallic 1.0, color 0.86/0.68/0.30, roughness 0.28 — guard/ferrule/pommel
- [wood](wood.md) — matte non-metallic; warm brown ~0.34/0.19/0.09, roughness 0.5; standard 3-point (warm key, low fill), NOT the metal rig
- [foliage](foliage.md) — matte green diffuse ~0.12/0.34/0.10, roughness 0.8; single-sided leaflets OK in Cycles
- [bark](bark.md) — material.bark(): Voronoi DISTANCE_TO_EDGE plates+furrows; reddish-brown pine default; reusable trunk material
- [blued steel](blued-steel.md) — dark gun metal: metallic 1.0, ~0.085 grey-blue, roughness 0.4 (blued) / 0.10 rough 0.6 (parkerized)
- [car-paint](car-paint.md) — Principled base+metallic flake+Coat clearcoat; only reads under Cycles + softbox environment to reflect
