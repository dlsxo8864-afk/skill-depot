---
key: brass
kind: material
---
# brass — material learnings

One file per material (keeps the catalog from bloating). Consult this
BEFORE building 'brass'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — brass fittings
Principled: Metallic 1.0, Base Color (0.86,0.68,0.30), Roughness 0.28. Warm gold for guard/ferrules/pommel; reads as a distinct local-contrast accent against the steel blade. Same environment/Cycles requirement as any metal.
- verified_by: _tmp/sword/sword_persp.png
