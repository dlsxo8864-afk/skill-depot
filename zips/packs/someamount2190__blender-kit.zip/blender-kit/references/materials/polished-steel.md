---
key: polished steel
kind: material
---
# polished steel — material learnings

One file per material (keeps the catalog from bloating). Consult this
BEFORE building 'polished steel'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — polished blade steel
Principled: Metallic 1.0, Roughness 0.14, Anisotropic 0.7 (set via compat.principled_set(bsdf, anisotropic=0.7)). Anisotropy stretched ALONG the blade = the signature glint. Metal shows its ENVIRONMENT not just 'light' -> render in Cycles (or EEVEE use_raytracing) and give it a LONG strip-softbox overhead, long axis along the blade, to reflect as a continuous streak. Flat/EEVEE-no-raytrace = dull grey. Grazing camera angle intensifies it (Fresnel).
- verified_by: _tmp/sword/sword_persp.png — continuous specular streak on the blade
