---
key: blued steel
kind: material
---
# blued steel — material learnings

One file per material (keeps the catalog from bloating). Consult this
BEFORE building 'blued steel'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — blued / parkerized gun steel
Firearm metal: BLUED steel = Metallic 1.0, Base Color ~(0.085,0.085,0.095) very dark with a slight blue, Roughness ~0.4 (deep sheen). PARKERIZED = ~(0.10,0.10,0.10), Roughness ~0.6 (matte). Use a DARK metal so it CONTRASTS the warm wood stock (gun-modeling tip: don't make everything one shiny grey). Same Cycles/environment requirement as any metal.
- verified_by: _tmp/m14/m14_persp.png — blued barrel/receiver vs walnut stock
