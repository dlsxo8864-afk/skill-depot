---
key: wood
kind: material
---
# wood — material learnings

One file per material (keeps the catalog from bloating). Consult this
BEFORE building 'wood'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — oak / matte wood
material.wood(color, roughness) added to material.py: Metallic 0, Roughness ~0.5, Specular 0.35. A FLAT base colour reads as wood in a blockout; grain needs a noise/wave texture (TODO). Light it with a standard three-point (warm key ~1.0/0.93/0.82, LOW fill for form) -- matte wood does NOT need the metal strip-softbox studio rig. Note: AgX view transform renders the albedo ~a stop lighter (a mid-brown 0.34/0.19/0.09 reads as honey-oak); pick the albedo darker than the tone you want.
- verified_by: _tmp/chair/chair_persp.png — reads as honey-oak with form

## 2026-06-21 — procedural grain recipe (v2)
material.wood(grain=True, grain_axis='X'|'Y'|'Z', color, color2) builds grain: TexCoord.Generated -> Mapping stretched HARD along grain_axis (~12 across, 0.5 along) -> NOISE texture (Scale 1.6, Detail 6, Roughness 0.65) -> ColorRamp (stops 0.38/0.62) between color and a 0.62x-darker color2 -> Base Color. KEY LESSON: use stretched NOISE for grain, NOT a Wave/BANDS texture -- a regular Wave reads as ribbing/corduroy (tried it: low distortion=stripes, high distortion=busy woven look); stretched noise reads as organic wood streaks. Set grain_axis to each PART's long axis: vertical legs/posts 'Z', seat front-to-back 'Y', horizontal rails 'X' (use 3 material instances). Generated coords keep grain density consistent across parts of different sizes. Flat (grain=False) still fine for quick blockouts.
- verified_by: _tmp/chair/chair_v2_contact.png — seat shows clear front-to-back grain in the top view; legs vertical, rails horizontal
