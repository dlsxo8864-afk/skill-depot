---
key: car-paint
kind: material
---
# car-paint — material learnings

One file per material (keeps the catalog from bloating). Consult this
BEFORE building 'car-paint'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — automotive paint (clearcoat)
material.car_paint: base_color + metallic ~0.3 (flake) + coat=1.0, coat_roughness=0.06 (glossy clearcoat over a slightly-rough base, roughness ~0.18). Like ANY glossy surface it only reads as car paint with an ENVIRONMENT to reflect: Cycles + studio softboxes (world_sky + 3 area lights) gave the deep wet-gloss highlight roll-off across the red body. Flat/no-env or pure EEVEE-no-raytrace = looks like matte plastic. Dark tinted glass (transmission glass, color ~0.05,0.07,0.09) for the greenhouse reads as smoked cabin glass.
- verified_by: _tmp/car/car_detail_persp.png (red sedan, glossy clearcoat highlight)
