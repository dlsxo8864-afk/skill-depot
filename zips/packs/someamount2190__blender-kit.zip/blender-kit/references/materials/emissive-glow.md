---
key: emissive-glow
kind: material
---
# emissive-glow — calibrated bloom (compositor Glare) values

Consult BEFORE dialing `render.enable_glow` — these are measured, not
vibes. Calibration scene: `_tmp/glowcal/calibrate.py` (emission strengths
1..10 + bright-lit white diffuse + chrome false-positive controls, dark
studio ground, Filmic, Cycles 48). Sweep renders `cal_A..D_*.png`
VIEWED 2026-07-06.

## 2026-07-06 — the threshold table (dark/mid studio exposure, Filmic)
| dial set | halo onset | character | use for |
|----------|-----------|-----------|---------|
| th 1.0, strength 1.0, size 0.5 | emission s>=4 | dramatic, wide | hero magic (crystals, cores) |
| th 1.5, strength 1.0, size 0.5 | s>=5 | full but controlled | DEFAULT — mixed emissive scenes |
| th 2.5, strength 0.8, size 0.4 | s>=6 | restrained | hot accents only (lightning s>=6) |
| th 4.0, strength 0.6, size 0.3 | s>=8 | faint whisper | keep-it-subtle passes |

- FALSE-POSITIVE RISK IS LOW at studio exposures: a 500 W-keyed white
  diffuse sphere and a chrome sphere produced NO halo even at th 1.0 —
  Filmic scene-referred highlights stayed under the threshold. Re-verify
  if a scene has a visible sun/sky or specular sun glints.
- Low-strength chips (runes at s 1.5-3, the magegun inlay rule) sit BELOW
  halo onset on every verified dial set — glow will not lift them; that
  is usually what you want (inlays stay inlaid). A th ~0.7 might catch
  s3 — UNVERIFIED, calibrate before relying on it.
- The dial mainly selects the glowing BAND; size sets halo radius;
  strength scales its intensity. Quality 'High' always (set by the
  helper).
- verified_by: _tmp/glowcal/cal_A..D renders (4-point sweep, controls
  clean in all four)

## API gotchas (Blender 5.1.2, probed 2026-07-06)
Scene.node_tree is GONE; compositor = node group on
`scene.compositing_node_group`; `CompositorNodeComposite` undefined —
use NodeGroupOutput + `ng.interface.new_socket("Image", in_out="OUTPUT",
socket_type="NodeSocketColor")`; ALL Glare params are input sockets,
`Type` is a string-enum socket ("Bloom"); outputs are Image/Glare/
Highlights. Full chain lives in `render.enable_glow` — do not hand-build.

## 2026-07-06 — Verification pair: glow shipped on the thunder mace + mage-gun
render.enable_glow verified on both identity-emissive builds: mace (th 1.5, s 0.9, sz 0.45 — mixed s3-s5 emissives) gained hot-core+halo lightning and a haloed tip; mage-gun (th 1.1, s 1.0, sz 0.5 — hero crystal s4/tether s6) gained crystal spill onto the cage struts; NO false halos on brass/steel/stand in either. The calibration table above chose both dials on the first try — zero re-dial rounds, which is the point of calibrating before shipping. Both build scripts now call enable_glow before their renders; their gates re-ran green (glow is post-process — geometry gates unaffected).
- verified_by: _tmp/thundermace + _tmp/magegun re-rendered detail sheets VIEWED 2026-07-06; calibration sweep _tmp/glowcal/cal_A..D
