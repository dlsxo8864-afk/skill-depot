---
key: bark
kind: material
---
# bark — material learnings

One file per material (keeps the catalog from bloating). Consult this
BEFORE building 'bark'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — procedural tree bark
material.bark(plate, furrow, roughness, scale) added to material.py: Object coords -> Mapping (cells stretched vertically, scale_z*0.45 for tall plates) -> Voronoi DISTANCE_TO_EDGE -> ColorRamp (0=furrow dark, 0.14=plate) -> Base Color. Gives plated bark with dark furrow lines. Pine default reddish-brown plate (0.34,0.20,0.12) / dark furrow (0.14,0.07,0.04). LOW payoff on a thin trunk mostly hidden by foliage, but reusable for any exposed trunk; raise scale for finer plates.
- verified_by: _tmp/pine/pine_v3_persp.png (trunk)
