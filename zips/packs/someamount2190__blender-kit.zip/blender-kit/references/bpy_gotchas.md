# bpy gotchas — seeded error catalog

Durable, general bpy failure modes and their fixes. `debug.py` matches against
these signatures. Promote verified, general lessons here from `LEARNINGS.md`;
keep project-specific notes in that project's render log. Dedupe by signature.

| error_signature | symptom (log) | root cause | fix |
|-----------------|---------------|------------|-----|
| `ops_poll_failed` | `Operator … poll() failed, context is incorrect` | `bpy.ops` needs mode/active-object/area context that doesn't exist in `-b` | Build geometry with the data API + `bmesh` (`blendkit.build`); don't use ops for geometry. |
| `principled_socket_renamed` | `KeyError: … key "Specular"/"Emission" not found` | Blender 4.0 renamed Principled sockets (`Specular`→`Specular IOR Level`, `Emission`→`Emission Color`, `Clearcoat`→`Coat Weight`, `Transmission`→`Transmission Weight`) | Never index `bsdf.inputs[<hardcoded>]`. Use `compat.principled_set(bsdf, specular=…, emission_color=…)`. |
| `mesh_op_wrong_mode` | `mesh.* … requires edit mode` / fails in object mode | mesh operator run in the wrong mode | Use `bmesh.ops` on mesh data directly (no mode). |
| `gpu_egl_headless` | `EGL`, `GLX`, `Unable to open display`, `Segmentation fault`, `GPUFrameBuffer` under `-b` | headless box has no GPU/display for Eevee GPU init | Fall back to Cycles CPU: `engine='CYCLES'`, `scene.cycles.device='CPU'`. `render.render_still` does this automatically. |
| `black_render` | render saved but `luminance≈0` | no lights, no world lighting, or camera aimed away | `preflight.check()` before render; add `light.three_point` + `light.world_sky`; verify camera aim. |
| `object_missing_from_render` | object exists but absent in render | `hide_render=True` or not linked to a collection in the active view layer | Link to `scene.collection` (build.py does); set `obj.hide_render=False`; check `obj.users_collection`. |
| `radians_degrees_mixup` | object wildly rotated; euler values like 6.28/3.14 where degrees intended | set radians where you meant degrees (or vice-versa) | Route rotation through `transform.set_rotation_deg` (degrees in). |
| `module_not_found_blendkit` | `ModuleNotFoundError: No module named 'blendkit'` | `scripts/` not on `sys.path` for this run | `sys.path.insert(0, <skill>/scripts)` before `from blendkit import …` (see `new_scene.py`). |
| `stale_bound_box` | inspect/camera-aim wrong right after data-API edits | `obj.bound_box` / `matrix_world` are cached and lag un-flushed edits | Call `bpy.context.view_layer.update()` before reading; `inspect` computes AABBs from mesh verts to avoid this. |
| `blender_exit_0_on_error` | script raised but `run.sh` returned 0 | Blender exits 0 on a `--python` exception by default | Pass `--python-exit-code 1` (run.sh does). |
| `eevee_glass_opaque` | glass/transmission material renders solid black in EEVEE | EEVEE Next (4.2+/5.x) ignores refraction unless `scene.eevee.use_raytracing` is on (default False) | Enable `scene.eevee.use_raytracing` (+ legacy `use_ssr`/`use_ssr_refraction`) when a refractive material exists; set `use_screen_refraction`+`use_raytrace_refraction` on the material. `render` + `material.glass` do this. |
| `flat_shaded_primitives` | spheres/cylinders look faceted (banding) | bmesh primitives default to flat shading | Set `face.smooth=True` (all faces for spheres; sides-only for cylinders/cones). `build` does this for curved primitives. |
| `ortho_blueprint_aspect_clip` | top/blueprint view crops the scene corners | `ortho_scale` maps to the longer render axis; short axis clipped on non-square renders | Size `ortho_scale`/fit-distance from `scene.render.resolution_x/y` so both axes fit; set resolution before framing. `camera.frame_scene*` do this. |
| `autoframe_dwarfs_subject` | the prop is tiny; a big floor fills the frame | auto-framing fit the whole AABB incl. the oversized ground | Exclude floor-like objects from framing bounds (`FLOOR_NAMES`), fall back to all geometry if none remain. `camera._scene_aabb` does this. |

## Mesh topology (quads / n-gons / clean geometry)
- Default primitives are quad-dominant but **cylinders/cones ship n-gon caps**,
  cones/spheres have tris, and abutting caps are hidden interior faces. This is
  FINE for still-render blockouts (Cycles/EEVEE triangulate internally; a flat
  n-gon cap is clean). It only matters for **subdivision / animation / export**.
- Audit with `inspect.topology_report()` — per-object quad/tri/n-gon/double/
  non-manifold counts. Non-manifold edges flag OPEN holes (boundary edges of a
  plane are expected).
- Clean with `build.cleanup(obj)` or a builder's `clean=True`: merges doubles,
  removes n-gons (quads where coplanar via triangulate→join_triangles, tris at
  genuine points), recalc normals. Off by default — opt in when you need it.
- GOTCHA found building this: `bmesh.ops.grid_fill` on a single circular cap loop
  fails silently and leaves the cap an OPEN HOLE. Use triangulate→join_triangles
  instead; the topology audit's non-manifold count catches the holes.

## Notes that bite repeatedly
- **`-b` (background) has no 3D-view context.** Anything that reads
  `context.active_object`, `context.selected_objects`, `context.area`, or a tool
  mode is fragile. Prefer data API + bmesh.
- **Eevee engine id is version-dependent.** `BLENDER_EEVEE` (5.x / 4.3+),
  `BLENDER_EEVEE_NEXT` (4.2). Use `compat.eevee_engine_id()`.
- **`Material.use_nodes` is deprecated for Blender 6.0.** Still works on 5.1;
  watch for the eventual node-by-default change.
- **Image pixels are flat RGBA floats, bottom row first.** Reshape `(h, w, 4)`
  using `image.size`. Render all views at one resolution before stitching.
- **Lengths are meters; `transform` rotation helpers take degrees.** Keep that
  boundary crisp.

## Blender 5.1: compositor is a node group; Composite node is GONE
`Scene.node_tree` no longer exists and `use_nodes` is deprecated — assign a
`CompositorNodeTree` node group to `scene.compositing_node_group`. The
classic `CompositorNodeComposite` output errors ("Node type undefined");
terminate with `NodeGroupOutput` + `ng.interface.new_socket("Image",
in_out="OUTPUT", socket_type="NodeSocketColor")`. Glare node parameters
(Type/Quality/Threshold/Strength/Size/...) are INPUT SOCKETS now, with
Type a string-enum socket ("Bloom"). Probed 2026-07-06; wrapped in
`render.enable_glow` — use it, don't hand-build. (2026-07-06)
