# Pattern learnings — index

One line per pattern; open the linked file for the detail.

- [phyllotaxis](phyllotaxis.md) — golden angle 137.5078deg placement + recursive self-similar branching = GROWN not assembled; use blendkit.phyllotaxis
- [central axis alignment](central-axis-alignment.md) — assembled symmetric objects (sword/bottle/column/tool) build COAXIAL on one centre axis; check inspect.axis_alignment
- [cross-part ratios and alignments](cross-part-ratios-and-alignments.md) — size parts RELATIVE to each other (ratios) + check axis ALIGNMENT vs other parts; inspect.check_ratios / check_alignment

(Construction METHODS moved to `references/techniques/` — patterns = placement/math rules only.)
