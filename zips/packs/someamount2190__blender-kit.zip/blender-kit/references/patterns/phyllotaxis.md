---
key: phyllotaxis
kind: pattern
---
# phyllotaxis — pattern learnings

One file per pattern (keeps the catalog from bloating). Consult this
BEFORE building 'phyllotaxis'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — phyllotaxis + branching math
WHY: evenly-spaced parts (360/N fronds, rigid whorls) read as ASSEMBLED; real plants pack organs by math, which fills space and avoids self-shadowing -> looks GROWN. RULES (Wikipedia Phyllotaxis; Vogel 1979; Lindenmayer L-systems; da Vinci): (1) GOLDEN ANGLE = 360*(1-1/phi^2) = 137.50776deg -- successive organs around a stem diverge by this; it's the irrational limit of Fibonacci divergence fractions 1/2,1/3,2/5,3/8,5/13. (2) VOGEL DISK (sunflower/pinecone face): organ i at r=c*sqrt(i), theta=i*137.5 -> tight spiral packing; spiral counts are adjacent Fibonacci numbers. (3) CYLINDER phyllotaxis: branches/leaves spiral UP a stem at azimuth i*137.5 (replaces rigid whorls). (4) RECURSIVE self-similar BRANCHING (L-system): each branch spawns children at a polar branch_angle ~25-35deg, azimuth stepped by the golden angle, length *= ~1/phi (0.62); a few levels fill space like a real tree -- this is what fixes 'sparse'. (5) da VINCI radius rule: child_radius = parent/sqrt(n_children) (area conserved). CODE: blendkit.phyllotaxis -> GOLDEN_ANGLE_DEG, spiral_azimuths(), vogel_disk(), cylinder_phyllotaxis(), davinci_radius(), and grow(length,depth,children,length_ratio,branch_angle,divergence) which yields the (pos,dir,length,depth) frame of every branch (build a limb at each). All math unit-tested. Use for ANY repeated/branching natural placement (fronds, branches, needles, petals, seeds).
- verified_by: _tmp/test_phyllotaxis.py — ALL_PHYLLO_TESTS_PASSED (golden angle, Vogel, cylinder, grow counts/frames)
