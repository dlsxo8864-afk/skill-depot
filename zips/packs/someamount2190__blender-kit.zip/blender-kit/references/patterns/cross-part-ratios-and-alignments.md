---
key: cross-part ratios and alignments
kind: pattern
---
# cross-part ratios and alignments — pattern learnings

One file per pattern (keeps the catalog from bloating). Consult this
BEFORE building 'cross-part ratios and alignments'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — relational sizing: ratios + alignments
RULE: a part can be correct ALONE but wrong NEXT TO another. So when researching/sizing a multi-part object, capture RELATIONSHIPS, not just absolute dims: (1) RATIOS -- part-to-part size ratios (crossguard ~4x blade width; barrel ~3x receiver; mag-height ~2.7x receiver-height). Counter-check with inspect.check_ratios(specs=[(label, partA, dimA, partB, dimB, expected_ratio), ...]) (dim in x/y/z = bbox extent; tol default 18%). (2) ALIGNMENTS -- which parts must line up on which axis: front+rear sights share the centreline (Y); the barrel group is coaxial (Z); a magazine is centred under the receiver (X). Verify with inspect.check_alignment(specs=[(partA, partB, axis, mode), ...]) where mode = center/min/max, tol default 4mm. Run both at the SHIP gate alongside failure_scan/topology. Also see patterns/central-axis-alignment (coaxial whole-object) -- check_alignment is the part-vs-part version. CLOSE-UP RULE (failures/trusting-the-scan-over-the-eye): a green check is not proof; render TIGHT close-ups of the SEAMS and look.
- verified_by: _tmp/m14 — check_ratios OK (3.00/2.79/0.13) + check_alignment OK (sights/barrel/suppressor/mag on centreline); both would flag a part off-size or off-axis

## 2026-06-21 — the size/position/orientation/symmetry quartet (placement + angle added)
A multi-part model needs FOUR independent counter-checks, each catching errors the others can't (the warship proved it — v1 was symmetric + clean yet every size, the funnel station, were wrong):
- inspect.check_ratios  — SIZE: part extent vs another (barrel/hull-len, turret/beam).
- inspect.check_placement — POSITION: a part's absolute coord on an axis (turret station along the hull); measure the station as a fraction off a scaled reference.
- inspect.check_alignment — SYMMETRY: part-vs-part on an axis (centreline).
- inspect.check_angles — ORIENTATION: a part's LONG axis direction via PCA (barrel elevation, funnel/mast rake, facing); SIGN-AGNOSTIC on the line but rake DIRECTION matters (it once flagged a funnel raked the wrong way — the spec, not the model). Run all four at the ship gate.
- verified_by: _tmp/warship/warship_v2_* (all four checks green after measuring off the reference)
