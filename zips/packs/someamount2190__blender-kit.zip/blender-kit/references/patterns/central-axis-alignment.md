---
key: central axis alignment
kind: pattern
---
# central axis alignment — pattern learnings

One file per pattern (keeps the catalog from bloating). Consult this
BEFORE building 'central axis alignment'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — central axis / coaxial alignment (the design's centre of gravity)
RULE: an assembled object with a clear long axis (sword, bottle, column, lamp, tool, rocket) must have every part CENTRED on ONE common axis (the tang/spine line) -- concentric, equidistant about it. PITFALL: if you rest each part on the FLOOR by its own bottom, parts of DIFFERENT thickness end up with their CENTRELINES at different heights (a thin blade sits low, a fat grip sits high) -> they look misaligned / 'falling low'. FIX: pick a common axis position (e.g. Z = the THICKEST part's half-extent, so the thickest still rests on the floor and nothing dips below it) and set ALL parts' perpendicular coords to it -- the thin parts then sit ABOVE the floor on the axis, which is correct (they share the centreline). CHECK: inspect.axis_alignment(long_axis='Y', tol) -> central axis = median of part centres in the 2 perpendicular axes, plus the volume-weighted centre of gravity; flags any part whose centre is >tol off-axis. Run it for any axially-symmetric assembly.
- verified_by: _tmp/sword — axis_alignment OFF-AXIS (Blade 0.0095 low) -> coaxial Z=0.016 -> ALIGNED (all offset 0.0000)
