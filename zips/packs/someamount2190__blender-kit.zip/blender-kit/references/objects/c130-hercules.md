---
key: c130-hercules
kind: object
---
# c130-hercules — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'c130-hercules'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — C-130H parked: measured stations + high-wing assembly + detail-view framing lessons
STATIONS (c130__takeoff-profile.jpg, x=14.9-frac*29.79; type dims L 29.79 span 40.41 H 11.66): glazing 0.06-0.12L, nose gear 0.12, wing LE 0.36 -> x 4.2, sponson 0.42-0.47, upsweep 0.62, fin LE 0.78, fin tip 11.55-11.66. Nacelles +-4.9/+-9.8, tanks +-7.35, props 4.11m. ASSEMBLY (high-wing): wing loft ZC 5.60 sits ON TOP of the crown (fuselage crown 5.52), root buried in an ENCLOSING fairing (no visible embedded surfaces); constant chord to +-10.5 (PAST the outboard nacelles) then taper; nacelles as scale-BAKED ellipsoid pods hanging to touch the wing bottom; radome = loft continuation + small flush cap, NOT a ball on a pipe (critic: 'suppository face'); flight-deck crown step via loft stations. CRITIC TRIAGE: span 'reads 1.5-1.6' FALSE (gated 1.357 by construction); tires 25pct undersized TRUE (mains r 0.66 = 1.32m); fin sweep airliner-like TRUE (Herc fin = near-straight LE, broad square tip); nose ball-crease TRUE. LOFT RULES: flat-shade coarse airfoil lofts (smooth normals bend backward mid-face on 6-pt sections); NEVER bevel-modifier a thin trailing edge (width > edge thickness = degenerate shells); bake anisotropic sphere scales (4x scale + smooth normals = shading garbage). DETAIL-VIEW FRAMING (the big one, see failures/dark-foreground-undersides-port-view): a LOW camera on the lit-sun side of a HIGH-WING aircraft catches the foreground outer-wing/nacelle UNDERSIDES as huge near-black shapes that NO lamp cures (their light hemisphere is the wing above); frame gear/detail shots from the OTHER quarter or from above the wing plane. ACCEPTED: monochrome ghost-gray, box prop blades, no panel lines, slightly hot exposure.
- verified_by: _tmp/c130/c130_contact.png + c130det_contact.png (all gates green: datum length/fin, span/length 1.357, stab/wing 0.397, symmetry; 1 aviation-critic round + fixes)
