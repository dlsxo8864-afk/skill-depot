---
key: windows 95 pc
kind: object
---
# windows 95 pc — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'windows 95 pc'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — retro PC: proportions + Win95 screen-UI recipe + feature-parts build
PROPORTIONS (1990s 15in CRT, ElectroProps/search): 0.37 W x 0.37 H x 0.40 D m — DEPTH ~= WIDTH (CRTs are DEEP; a shallow box is the #1 retro tell; check_ratios depth/width ~1.0 = 1.08 here). Desktop case 0.43x0.42x0.12 (monitor sits ON it); keyboard 0.46x0.17; mouse ~0.06x0.10; desk 1.2x0.62x0.74. CONSTRUCTION: monitor housing = a box whose BACK half is tapered in (verts y<0 scaled toward centre) -> the classic CRT taper; bevel+smooth for moulded plastic; dark recessed glass; tilt base; front brand/LED/buttons. WIN95 SCREEN UI (the identity, flat EMISSIVE decals stacked ~4mm in front of the glass at a known plane): teal #00807F bg + grey taskbar strip (bottom) + raised Start button at bottom-LEFT with a 4-square red/green/blue/yellow FLAG (the clincher) + 3 desktop icons top-left (glyph+label bar) + a clock panel bottom-right. NOTE camera/viewer at +Y sees +X as image-LEFT, so Start/icons -> +X, clock -> -X. Keyboard = wedge base + a 15x5 key GRID built as ONE bmesh of cubes + a wide spacebar (not a textured slab). Mouse = beveled body + 2 buttons + a CORD tube curving to the case (tapered-limb-tube). PLACEMENT LOGIC (check_placement): monitor centred x=0 at desk back; keyboard front-centre; mouse to the right. 42 meshes, one component, ngons 0. Built strictly via SOP-07 (gate) + feature-parts-first. WEAK: teal renders a bit pale under scene light (emissive 1.1 + area lights); icons are abstract squares.
- verified_by: _tmp/win95/win95_front.png + win95_hero.png + win95_screen.png (reads as a Win95 PC; all checks + gate green)
