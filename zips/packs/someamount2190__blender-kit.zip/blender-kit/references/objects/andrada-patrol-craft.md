---
key: andrada-patrol-craft
kind: object
---
# andrada-patrol-craft — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'andrada-patrol-craft'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Andrada-class (BRP Ruiz fit): stations + the first ship_check-gated build
STATIONS (andrada__ruiz.jpg; 24.4 x 6.1 m, waterline display): house 0.33-0.58L, pilothouse fwd third of house roof ~4.0, mast 0.54L top 9.5 + radome ~5 ON ITS OWN PEDESTAL beside the pole (threading the ball on the mast = 'bead on a toothpick'), fwd M2 pair 0.30L (4.9,+-1.9), aft pair 0.86L, awning x -2.5..-8 z 3.2 W/ VALANCE, 5 portholes z 0.9, sheer 1.62->1.25, boot-top band z 0..0.30 (photo shows it; anchors the stance). HULL: 14-station loft, entry half-angle 22-24 deg, max beam held 46-67pct LOA, transom 86pct beam, STEM SHEAR map on the bow rings for ~29 deg rake (constant-x rings = vertical stem no matter what the docstring says); smooth strakes + 30deg sharp edges keep the chine hard. THE INTERP RULE (engineer's biggest catch): anything placed along the hull (portholes/rails/cleats) MUST derive y from half_beam(x) interpolated off the ST table — my hardcoded porthole formula GREW while the hull narrowed (detachment up to 1.8m; renders showed 'spheres floating off the bow'); the same rule killed the rail dogleg + off-deck stanchion. RAILS: pitch 1.45m, 2 courses, bow/stern closures. M2 sub-build (Gate 2.8): tapered drum pedestal r 0.15/0.10 + base r 0.25 (straight rod = 'toothpick'). PROCESS: first build through the FULL coded pipeline — declared sub-build (preflight-enforced), separate critic AND engineer agents (engineer rejected 6 critic claims vs constants incl. a 'Russian flag' misread — blue-over-red IS the PH ensign — and found 2 bugs no one saw: porthole formula, doors hanging 0.34m off the cabin corner), all artifacts ledger-recorded, ship_check PASS with 2 disclosed deviations. KNOWN GATE BUG (deferred): failure_scan AABB coarseness passed 1.8m-orphaned small parts vs the huge hull AABB — fix inspect threshold next session.
- verified_by: _tmp/andrada/andrada_contact.png + andradadet_contact.png + m2mount_contact.png (all gates green; ship_check PASS)
