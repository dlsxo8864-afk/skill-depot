---
key: human-face-bust
kind: object
---
# human-face-bust — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'human-face-bust'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — stylized human face bust: corrected canon + 4 render-round lessons
CANON THAT SURVIVED THE CRITIC: eye line 0.50H (mid-head rule); EQUAL thirds hairline 0.87H / brow 0.58H / nose base 0.29H / chin 0; mouth 0.19H; chin = 1/3 head width; head W 0.70H D 0.80H; ears span nose-base->brow. FIRST DRAFT ANCHORED THIRDS TOO HIGH (nose 0.43H, mouth 0.29H) -> compressed midface + blank chin runway; the cold-eyes critic caught it instantly — MEASURE the thirds on the render. CONSTRUCTION: skull = lofted horizontal elliptical stations (w/d/centre-offset per station: jaw taper, cheek flare at eye line, occiput, forehead slope) + subsurf 2 applied; SUBSURF SHRINKS THE SURFACE ~3mm INSIDE the loft cage at 16-station density — compensate feature placement or everything sits proud as planks. WHAT READS vs FAILS: nose MUST be one lofted wedge root->tip->nostril-base (box+spheres = plank+clown balls); eyes need LIDS DOMINANT (ball ~60% hidden, ~8mm opening; tight lids = googly balls, huge lids = clamshells) + iris discs yawed ~4deg INWARD (flat discs read wall-eyed without convergence); brows = tapered ellipsoids ON the socket ridge (~0.58-0.60H visual), boxes float as planks; lips = 2 rolls + CORNER pinch spheres (rolls alone never close); neck r ~0.055 (half head width) or giraffe-pipe read. ACCEPTED at this fidelity: unfused-primitive seams, no philtrum/nasolabial/temple secondary forms, waxy uniform skin (no SSS), featureless occiput, dead-vertical gesture, puck ears.
- verified_by: _tmp/human-face-bust/face_contact.png + facedet_contact.png (all gates green: align/ratios/topology/failure_scan; 1 cold-eyes critique round + merged fix round; plan _tmp/human-face-bust_plan.md corrected)
