---
key: mage-staff-gun
kind: object
---
# mage-staff-gun — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'mage-staff-gun'; record new learnings only after a render/inspect
verified them.

## 2026-07-05 — Arcane mage staff/gun: fantasy-prop rules + the structured-critique validation
DESIGN (no real referent — plan documents designed proportions; flintlock photo = gun grammar): 2.25m, focus-crown/barrel/grip-stock three-zone silhouette; crown = prong arcs + glass-shell crystal w/ emissive core + orbit rings + off-axis wisp tethers; octagonal runed barrel; serpentine sidelock; fluted collar; leather grip rings; pommel+ferrule. RULES LEARNED: (1) MAGIC FLOATS need a tether for the connectivity gate BUT the tether must be OFF-AXIS and attach at a facet — an on-axis rod reads 'lollipop impalement' (engineer measured 34mm penetration); two tapering wisps at <=1/4 crystal width sell levitation. (2) OCCLUDED EVIDENCE = the round's big lesson: the lock was fully modeled and correctly flush-mounted (+y flank) but EVERY camera incl. the sub-build's own display shot from -y — a feature with no visible evidence is a readability failure even when the geometry is perfect; stage sub-build displays so the FEATURE faces the camera, and point one assembly detail camera at each flank-mounted feature. (3) Emissive-only crystals read 'mint candy' — glass shell + smaller emissive core gives facets + spill for one material swap (material.glass exists). (4) Emissive chips must be INLAID (flush + dark bezel, strength ~1.5) or they read as glow tape. (5) Palette separation is numeric: three browns within dR 0.03 render as one plastic — separate by value AND roughness bands. (6) Arc-of-members guards/rings: anchor BOTH horns (guard was attached at neither end); rings at 15deg/1.05-overrun read forged vs 30deg 'sausage links' (durable fix = swept-curve generator, KIT-EXTENSION). SOP-09 VALIDATION: first structured critique — 10 items, every claim mechanically checkable, engineer dismissed 2 misreads via measured occlusion/existing parts while KEEPING their percepts as staging fixes; zero literary-parsing overhead vs the ~50pct misread rate of prose critiques.
- verified_by: _tmp/magegun contact sheets (all gates green x3 scripts; ship_check PASS w/ 2 disclosed deviations)
