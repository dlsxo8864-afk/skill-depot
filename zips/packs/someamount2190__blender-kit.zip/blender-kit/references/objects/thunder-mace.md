---
key: thunder-mace
kind: object
---
# thunder-mace — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'thunder-mace'; record new learnings only after a render/inspect
verified them.

## 2026-07-05 — Thunder god's mace: measured mace grammar + storm-effect rules
GRAMMAR (measured off the Cleveland 7-flange mace photo): head+finial 0.26L; double-cusp flange silhouette (widest near top); gilt core ridges between flanges; slim engraved haft ~0.45L; fatter carved grip ~0.27L; fluted onion butt knob. Design deviations documented in plan (6 flanges, storm spike). LIGHTNING AS GEOMETRY (no bloom in kit): 3-segment member zigzags READ as lightning only with (a) taper root->tip (0.0065->0.0028), (b) >=1 fork per span (r 0.0022, dropped ~50deg), (c) per-span width variation from a FIXED table (randomness banned by kit determinism), (d) endpoints computed onto the ACTUAL rotated cusp corner (box center + rotation math: r 0.1899, z+0.3281 — idealized endpoints floated 0.029 off and violated the plan's own tripod-miss check), (e) strength ~5 with deep blue (0.45,0.60,1.0) — s8 clips to white under Filmic and kills the color. FLANGES: converging thin-plate pairs (2x 0.007 @ rz a+-3.5deg) give a wedge + V-crease striking edge for 2x parts and no new topology risk. VERTICAL PROP STAGING: hex drum plinth (6-seg cyls, flat-shaded) + chamfer tier + geometry score marks; warm stone (0.17,0.155,0.14) vs cool floor (0.10,0.105,0.12). HARD KEY at prop scale: 70W area (size 0.45) at ~3m with HDRI 0.25 gives cast shadow + steel reflections; 320W blows the frame to white — exposure has NO gate, VIEW catches it (deviation logged; luminance-bounds check is a kit candidate). Finial rule: coarse uv-spheres (14x10) on polished metal mirror the HDRI as blobs — 28x20 minimum for hero brass.
- verified_by: _tmp/thundermace/thundermace_contact.png + thundermacedet_contact.png (all gates green; ship_check PASS w/ 2 disclosed deviations)
