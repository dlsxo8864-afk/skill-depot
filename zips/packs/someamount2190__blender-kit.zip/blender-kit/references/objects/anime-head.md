---
key: anime head
kind: object
---
# anime head — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'anime head'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — proportions + construction (the read = big eyes + hair + simple face)
PROPORTIONS off refs/anime-head__front.png (head H=2.0, chin z0->crown z2): W/H~0.67; eyes centred ~63% DOWN (below midline -> big forehead for hair); each eye ~1/4 head width, ~1 eye-width apart (eye centres x=+-0.33); nose ~72% down (z~0.5); mouth ~85% (z~0.3); pointed chin. CONSTRUCTION: head = uvsphere scaled (0.66,0.80,1.0), jaw TAPERED below the cheek to a pointed chin (x*=0.26..1.0 via smoothstep), then the FACIAL FRONT FLATTENED toward a y~0.47 plane (see technique flattened-facial-plane) so flat features lie on it instead of protruding off the egg; Subdivision-Surface modifier + smooth = clean skin. EYES (the focus) = a stack of thin ELLIPSE DISCS on the flat face: sclera(white) / iris(teal) / inner-iris(lighter) / pupil(black) / 2 emissive white HIGHLIGHTS, + a bold dark upper LASH bar (roll the outer corner up) + lower lash + brow; each disc yawed ~8deg outward + pitched ~4deg down to follow the face. NOSE = tiny cone; MOUTH = small dark-pink disc. HAIR = a subsurf CROWN SHELL (uvsphere scaled, FACE CUT AWAY by deleting front faces below ~brow) covering the forehead (cut at brow, NOT high, or a bare-forehead gap shows) + pointed bang CLUMPS (flattened tapered spikes, centre parting) + sidelocks + back length. CHECKS: check_ratios(eye:head width ~0.25), check_alignment(both eyes level z; nose/mouth on centre x). Lavender hair, ~39 meshes. LIMITATION: the crown reads a bit helmet-smooth; real anime hair wants more layered overhanging clumps.
- verified_by: _tmp/anime/anime_front.png + anime_hero.png + anime_eye.png (reads as anime girl; ratio+alignment green)
