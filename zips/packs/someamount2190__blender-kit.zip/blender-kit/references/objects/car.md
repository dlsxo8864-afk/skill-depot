---
key: car
kind: object
---
# car — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'car'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — sedan proportions + draft->detail build
HELD BELIEF (m): length 4.7, width 1.82, height 1.45; wheelbase 2.8 (~0.6L); track 1.55; wheel diameter 0.60; ride height ~0.15; greenhouse glass ~28% of height. X=length(front +X), Y=width, Z=up, centred at origin.
BUILD (SOP-06): Pass-0 DRAFT = body + greenhouse + 4 wheels reads as a car in silhouette; lock proportions BEFORE detailing.
- BODY: side-profile polygon in XZ extruded in Y (profile_extrude), width 1.82. Cut WHEEL ARCHES into the profile (dip the lower edge up to ~0.52 over each axle, rocker at z~0.24 between) so wheels show THROUGH the arch openings -> instant 'car' read + stance. cleanup() de-ngons the extrude caps.
- GREENHOUSE: a separate raked glass-band trapezoid (width 1.44 < body so a painted border shows) from windshield base up over the cabin to backlight; a roof box on top. Glass ~0.66 of body height (check_ratios).
- WHEELS: cylinder rotated 90deg X (axle along Y) + a chrome hubcap disc on the OUTER face; r=0.30, wheelbase 2.8 / track 1.55. RATIO wheel:body-height ~0.94.
- DETAIL pass = the FACE: wide headlight lenses + grille + front/rear bumpers + side mirrors. ALL flush/connected; 22 meshes, ONE component.
CHECKS that held: failure_scan CLEAN one-component, topology ngons 0, check_ratios (wheel:body 0.94, greenhouse:body 0.66), check_alignment (4 wheels symmetric x/y/z, greenhouse + lamps + bumpers centred/level).
CAMERA: 3/4 hero direction (1.0,-0.85,0.42); the SIDE ortho is the key car view (silhouette test).
- verified_by: _tmp/car/car_detail_persp.png + car_detail_contact.png + car_face.png (Cycles, all checks green)

## 2026-06-21 — HIGHLY DETAILED pass (HD): what to add + how it read
From the locked sedan, the realism jump came in this order of impact:
1. SMOOTH+BEVEL the body (biggest lever, see pattern smooth-beveled-hardsurface): a faceted low-poly body -> stamped sheet metal with soft highlight roll-off. Did this to body/roof/tyres; NOT to glass (keep crisp) or rim windows.
2. ALLOY WHEELS: a solid metal rim face + 5 dark RECESSED WINDOWS in a ring (the metal between = spokes) + centre hub. Do NOT approximate the rim ring with rotated boxes (checkerboard — see failure box-ring-checkerboard). Wheels are the #1 read after the body.
3. GLASSHOUSE: split the read with a black B-pillar + chrome BELTLINE and ROOF-RAIL trim strips; tumblehome (glass narrower than body) + tinted transmission glass. Top view then shows front/rear side windows split by the pillar.
4. FACE: segment the lamps (main lens + small amber indicator), give the grille horizontal chrome SLATS + a centre badge, add front/rear number plates. Keep all of it BELOW the hood break (see failure part-juts-past-a-body-break).
5. Small parts that sell scale: door SEAM lines (thin dark boxes on the flank) + chrome handles, door mirrors (stalk+housing+glass), dual chrome exhaust tips, fuel cap, cowl wipers, shark-fin antenna.
Total 64 meshes, ONE connected component, ngons 0, all ratios/alignments green. Each small part MUST overlap a neighbour or failure_scan flags it FLOATING (the antenna floated when placed behind the roof's back edge -> reseat onto the roof).
- verified_by: _tmp/car/hd_hero.png + car_hd_contact.png + hd_wheel/face/glass.png (Cycles 200spp, scan CLEAN)
