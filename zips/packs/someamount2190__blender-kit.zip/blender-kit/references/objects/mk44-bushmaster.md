---
key: mk44-bushmaster
kind: object
---
# mk44-bushmaster — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'mk44-bushmaster'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Mk44 30mm on display stand: weapon-prop lessons
LAYOUT (refs mk44__side.jpg CV9030 barrel/brake + mk44__full-gun.jpg AC-130 receiver): overall ~3.4m, barrel+brake ~0.65-0.70 of length (gated); receiver 0.95x0.34x0.34 HORIZONTAL slab — THE PROPORTION RULE: the receiver group must read LONG AND LOW (~3:1 length:height); a tall feeder tower INVERTS it and the critic reads 'three unrelated boxes' (my v1 feeder 0.5 tall > receiver 0.34 = tower; v2 full-length 0.2-deep deck fixed it). CHAIN GUN IDENTITY: chain-drive housing on the flank + motor cylinder — 'the single most distinctive feature of a chain gun' per critic; include from v1 next time. AMMO PATH REALISM SELLS THE PROP: 30x173 rounds at TRUE scale (~0.31m: brass case r 0.023 x 0.19 + slim dark projectile + tip) — correct-scale rounds hidden behind structure still got read as 'beads', so VISIBILITY placement matters as much as scale; feed chute = RECTANGULAR section with alternating link sizes (ribbed ladder read — uniform overlapping boxes read 'garden hose'); ammo can needs seam+latch+handle (4 cheap parts = believability). MUZZLE BRAKE: cylinder ~1.4x barrel OD, rows of RECTANGULAR flush port boxes (oval domes read portholes), and A BORE DISC AT THE FRONT — 'the nose of a gun must terminate in a hole' (disqualifying if absent). BARREL: two-tone (olive jacket + exposed steel front + collar + barrel nut at the receiver junction — the joint is where the eye checks mechanism understanding). STAND: pillars must look load-bearing (0.24 wide + gussets + plate bolts), V-saddle in HARD contact (back plate kills the see-through notch), base extends near the muzzle. FRAMING GOTCHA: frame_scene fits the whole-scene bbox INCLUDING the ground plane — an oversized floor makes the subject 15pct of frame; size the ground to the subject (~2.5x). TRIAGE: barrel-fraction critique lost to the gated datum (5th constants-beat-critics case).
- verified_by: _tmp/mk44/mk44_contact.png + mk44det_contact.png (gates green: total 3.57, barrel frac 0.65, brake:barrel 1.21, axis alignment; 1 weapons-critic round + fix round)
