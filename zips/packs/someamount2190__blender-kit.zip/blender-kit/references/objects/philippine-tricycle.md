---
key: philippine-tricycle
kind: object
---
# philippine-tricycle — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'philippine-tricycle'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Philippine tricycle (Laoag style): assembly + critique lessons
LAYOUT (refs/tricycle__side.jpg, Laoag): sidecar on the bike's LEFT (region-dependent — follow the photo), bike wheelbase 1.25 wheels r 0.30, cab floor z 0.33 y 0.42-1.24, roof z 1.60, overall 2.2 x 1.8. IDENTITY = enclosed decorated cab + fitted shared roof + FOR HIRE board: (1) ROOF must be FITTED (~cab footprint +10cm) with the bike FRONT PROJECTING past it — an oversized flat slab reads 'picnic table' and the top view loses the vehicle (plan silhouette should read L-shaped); posts VERTICAL at cab corners + one stay to the steering head. (2) CAB walls run floor-skirt to window line (~z 1.15) with a ~0.5m entry cutout on the outboard side + sill; nose plate leans TOP-BACK ~38deg and the WINDSHIELD SEATS ON THE NOSE'S TOP EDGE — compute the rotated edge position (top edge = center + half*(-sin, cos)); I parked the windshield 0.3m in front of it ('glass hanging in mid-air'). (3) REAR PANEL = the decor canvas: window + stripe band + plate, EMBEDDED into the face (strips floating 1-2mm proud read as stickers peeling). (4) FENDER ARCS: segment boxes around a wheel must be rotated TANGENT (midangle+90) — rotating by the midangle itself makes them RADIAL: 'spokes piercing the tires, naval mine' (the critique's howler; orbit the wheel once). (5) Bench needs a full base box to the floor (bench-on-air was the first scan catch). Sidecar wheel SKIRTED (upper 2/3 hidden). TRIAGE NOTE: critic missed the existing headlight (chrome-on-chrome) and floor (shadow) — chrome parts need a contrast lens/face to register. ACCEPTED: blank signage/plates, no tire tread, no rider.
- verified_by: _tmp/tricycle/tricycle_contact.png + tricycledet_contact.png (gates green: L/W/H datums, wheel alignment; 1 critic round + fix rounds)

## 2026-07-04 — v2: sub-assembly rebuild
v2 (user-directed division): motorcycle rebuilt as its own gated sub-build (build_bike.py: ring tires/rims, 16 spokes ending at rim, axles bridging swingarm-to-hub, triple clamp + risers, diamond frame + twin subframe rails at shock width, airbox/side-cover masses filling the frame void, tangent fenders + stays) then imported into the assembly via importlib. See techniques/subassembly-first-builds.
- verified_by: _tmp/tricycle/tricycle_contact.png v2 (all gates green)
