---
key: sword
kind: object
---
# sword — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'sword'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — proportions + hilt + build/topology
PROPORTIONS (cm, 6 sources): total ~97; blade ~78 (0.8x total), width 4.5->2.6 base->pre-point, thick ~0.5; crossguard ~19 (4x blade width), ~2 bar; grip ~11 one-handed, ~2.8 thick; wheel pommel ~5.5 dia. HILT (back->blade): pommel (peened/threaded counterweight) | ferrule | grip (wood+leather, wire helix) | guard(quillons) | blade; tang = backbone. BUILD: lens 6-vtx cross-section + PROFILE taper to a point reads as a real blade (constant-width box looks blunt). Lay the sword FLAT -> the ortho-top canonical view is a perfect blueprint. Ferrule collars OVERLAP the grip on purpose (inspect flags it; not a bug). TOPOLOGY: cylinders ship n-gon caps -> build clean=True; custom blade -> build.cleanup() -> 0 n-gons.
- verified_by: _tmp/sword/sword_contact.png (proportions+topology); topology_report ok=True ngons=0

## 2026-06-21 — coaxial alignment fix
DEFECT (caught by inspect.axis_alignment): resting every hilt part on the floor by its own bottom put their CENTRELINES at different Z (blade 0.0025, pommel 0.007, grip 0.014) -> blade & pommel 'fell low' off the grip's axis. FIX: define Z = 0.016 (the thickest part's half-extent = ferrule radius) and centre EVERY part there (guard/grip/ferrules/pommel location z=Z; blade.location.z=Z after make_blade+cleanup). Now all coaxial (axis_alignment offset 0.0000), the thickest part still rests on the floor, nothing below-ground, blade sits on the centreline (slightly above the floor, which is correct). Run axis_alignment(long_axis='Y') on every assembled symmetric object -- see patterns/central-axis-alignment.
- verified_by: _tmp/sword/sword_contact.png — coaxial; axis_alignment ALIGNED, failure_scan CLEAN

## 2026-07-04 — ornate upgrade: fuller + wire wrap + finials + riveted pommel (detail kit)
ORNATE PASS on the verified base (26 parts vs 6): FULLER = detail.panel_groove on the FLAT-lying blade top at z=Z+half_thickness (width 1/3 blade base, depth 0.002, 0.67x blade len from guard face) — groove edges + bevel_sharp make it read; blade bevel must be SUB-MM (0.0006, seg 1) or the 5mm-thick lens clamps chaotically. WIRE WRAP = 12 thin rings (r grip+0.0012, h 0.0024, clean=True) evenly spanning grip between ferrules — reads as wound wire at render distance, embeds keep connectivity CLEAN. QUILLON FINIALS = cones rotated +/-90 about Y at bar tips; verify with check_alignment vs Guard y/z center, NOT the long-axis check. POMMEL = boss + detail.bolt_ring(8, ring at 0.7x pommel r) on the exposed face; face ornaments + finials are legitimately OFF the sword's long axis — exclude from axis_alignment (structural stack only: offsets 0.0000). Ratios held: guard 4.22x blade width, pommel 1.96x grip dia, grip 0.14x blade len.
- verified_by: _tmp/ornate-longsword/sword_contact.png + sworddet_contact.png (all gates green: ratios/axis/topology_gate/failure_scan; per-part close-ups viewed)

## 2026-07-04 — Gate 9.7 harsh-critique round: what made the ornate sword READ
Cold-eyes critique (agent given ONLY renders) + fix round, all verified: (1) ROOT CAUSE of white-washed metal was NOT the shader — light.three_point's fixed 1000W baseline is ~13x overexposed at prop scale (distance 2.2); kit now auto-scales energy by (distance/8)^2 and softbox size by distance/8, which also restored contact shadows. Dark floor (0.045) only works once exposure is right. (2) Flat cylinder boss specular-flashes like a Phillips screw (quad-filled cap seams); cylinder rivets read as modern bolts; cone quillon tips read as cartoon arrow barbs -> DOMED forms fix all three: uv_sphere boss (peen block), bolt_ring(style='dome'), sphere knob finials. (3) Fuller must be TAPER-AWARE: 0.017 groove nearly pierced the narrow far end (109 doubles from boolean+bevel pile-up, caught by topology_gate); 0.015 x 0.60 blade-len keeps 2x-width shoulders. (4) Add DISTAL taper (thickness 0.0025->0.0013) — constant thickness was called out immediately. (5) Frame the fuller as a REGION (detail_views bbox spec), not the whole blade object. (6) Wire wrap: helix lean 3.5deg + seeded y/radius jitter kills the CNC screw-thread read. ACCEPTED defects: no HDRI env (kit has uniform world only), no grind marks/anisotropy (procedural kit), end-on front canonical view, wrap crossovers approximated.
- verified_by: _tmp/ornate-longsword/sword_contact.png + sworddet_contact.png (post-critique round, all gates green)
