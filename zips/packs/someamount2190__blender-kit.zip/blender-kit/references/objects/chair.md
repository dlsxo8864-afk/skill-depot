---
key: chair
kind: object
---
# chair — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'chair'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — proportions + construction + inspect note
PROPORTIONS (cm, 5 sources): seat TOP 45 from floor; seat 42 W x 40 D x 3.5 thick; legs ~4 square; back posts to ~85 total (backrest ~38 above seat); seat may taper ~2-3 narrower at back + slope 5-8deg / recline 0-5deg formal (kept square+upright for blockout). CONSTRUCTION that gives 0 overlaps: 4 legs floor->seat-bottom; seat box; 2 back uprights seat-top->post-top stacked OVER the back legs (leg|seat|upright all just touch, no interpenetration); backrest top-rail + mid-slat span BETWEEN the posts abutting the inner faces. INSPECT NOTE: the rail+slat get FLOATING flags because the vertical-support heuristic can't see LATERAL joints (they're held side-to-side by the posts, nothing directly below) -- intentional joinery, NOT a bug; same judgement class as the sword ferrule overlaps. TOPOLOGY: an all-box chair is pure quads (0 n-gons) -- no clean=True needed.
- verified_by: _tmp/chair/chair_contact.png; topology_report ok=True ngons=0; inspect overlaps=0, 2 intentional lateral-joint floats
