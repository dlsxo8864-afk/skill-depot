---
key: battleship
kind: object
---
# battleship — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'battleship'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — proportions + layout + build order
HELD BELIEF (real: L=270m, beam 33m, L/B~8.0 (USN used 7.96), draft 11m; nine 16in in 3 triple turrets '2-A-1' = two fwd SUPERFIRING + one aft). Scene units: L=12, beam 1.5, waterline z=0. X=length (bow +X), Y=beam, Z=up, EVERYTHING symmetric on Y=0 (check_alignment 'y center'). LAYOUT off the NC recognition drawing: T1 fwd low (x~3), T2 fwd raised ~+0.45 superfiring (x~1.8), T3 aft pointing astern (x~-3.3); stepped TOWER bridge fwd-of-midships (x~0.5) tallest; one raked FUNNEL (x~-1.2); MAINMAST + radar yardarm aft (x~-2.3); ~4 secondary 5in mounts/side at deck edge; stern CATAPULT+CRANE. TURRET = barbette cylinder + overhanging box + 3 barrels (cylinders rotated 90 about Y) whose inner end sits INSIDE the box (else they float). BUILD ORDER: lofted hull (see technique lofted-hull-stations) -> teak deck cap -> turrets -> superstructure (stepped boxes + thin overhang PLATFORMS to break the blockiness) -> secondaries -> AA tubs -> stern aviation -> details (breakwater, flagstaffs). 107 meshes, ONE component. COLOR (HMS Nelson ref): grey topside / black boot-topping at waterline / red anti-fouling below — done by per-face-material-by-height on the hull. CAMERA: bow-quarter hero pulled back (lens~46), and a far broadside (lens~52 @ 17u) for the classic profile; a 12u ship needs the camera FAR or it crops.
- verified_by: _tmp/warship/warship_broadside.png + hero + fwd (superfiring turrets) + contact (plan layout)

## 2026-06-21 — v2 — ratios MEASURED off the reference + placement/angle verified
Fixing v1's eyeballed proportions (user: 'couldn't nail the ratios'). MEASURED off refs/battleship__profile.jpg and encoded as NAMED CONSTANTS tied to L/beam, then verified with the full trio. CORRECTED held belief (L=12, beam=1.5, L/B=8.0): barrel = 0.075*L = 0.90 (v1 1.70, ~1.9x too long); barbette dia = 0.35*beam; gunhouse width = 0.40*beam; funnel dia = 0.22*beam (v1 0.45 — way too fat); FREEBOARD = 0.027*L ~ 0.32 (v1 ~0.08*L — hull was ~1.9x too tall/slab-sided); draft 0.49. STATIONS measured as frac-from-bow then x=6-frac*L: T1 0.205->x3.54, T2 0.29->x2.52, tower 0.44->x0.74, FUNNEL 0.51->x-0.18 (v1 had it at x-1.2, far too aft), mainmast 0.58->x-0.94, T3 0.75->x-2.98, crane 0.90->x-4.8. Funnel + masts rake AFT ~8deg. ALL FOUR CHECKS GREEN: check_ratios (6 specs), check_placement (6 stations, diff<=0.04), check_alignment (symmetry), check_angles (barrels level 0deg, masts vertical, funnel rake aft). 82 meshes, one component, ngons 0. LESSON: a scaled profile+plan reference makes ratios + stations DIRECTLY measurable — measure, don't eyeball; verify size AND position AND orientation, not just symmetry.
- verified_by: _tmp/warship/warship_v2_broadside.png + v2_hero + v2_fwd (sleeker, correct stations); all 4 checks green
