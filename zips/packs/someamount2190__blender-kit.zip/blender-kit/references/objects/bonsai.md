---
key: bonsai
kind: object
---
# bonsai — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'bonsai'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — moyogi proportions + math-driven build
HELD BELIEF (m, from refs/bonsai-informal-upright + bonsaiempire/evergreengardenworks): tree H~0.55; trunk base diameter ~H/5.5 (~0.10) tapering to ~0.02 apex (NEVER uniform); dramatic NEBARI root-buttress ~2x trunk base; first/lowest branch at ~1/3 H, thickest+longest, branches ASCEND + SHORTEN + THIN, ALTERNATE sides, leave the OUTSIDE of trunk curves, never a bar pair, apex ~over the base; shallow oval pot ~0.8H long, gravel/moss soil. NON-UNIFORMITY IS THE POINT (user's ask) and it is MATHEMATICAL: (1) trunk centreline = sinuous path with amplitude DECAYING (1-t)^1.1 and curve frequency RISING toward apex (moyogi 'curves closer near the top'); apex x->0 (over base). (2) nebari roots + branch azimuths by GOLDEN ANGLE (phyllotaxis.spiral_azimuths), not even spacing. (3) taper r=rtip+(rbase-rtip)(1-t)^1.3 + a base flare; forks use da Vinci child r=parent/sqrt(n). (4) foliage PADS = phyllotaxis.vogel_disk packing of squashed blobs -> flat-topped clouds, bigger low / smaller high, with negative space between (pads ON the branch tips so they stay one component). BUILD ORDER: pot+soil -> trunk limb -> nebari roots -> branches(+twigs) -> pads -> apex pad -> central FILL pad (bridges gaps so the canopy reads as a layered mass, not isolated puffs). 55 meshes, ONE component, ngons 0. v1 was too sparse/tall (small pads, long bare trunk) -> v2 bigger denser pads (clumpr > inter-clump spacing) + longer lower branches + fill pad.
- verified_by: _tmp/bonsai/bonsai_hero.png + bonsai_contact.png (front=textbook moyogi, top=golden pad spiral) + nebari/padseam close-ups
