---
key: giraffe
kind: object
---
# giraffe — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'giraffe'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Masai giraffe: photo-measured canon + critique-round lessons
CANON (measured off references/refs/giraffe__side-standing.jpg, H=4.8m): withers 0.58H, belly 0.38H, neck (withers->skull) 0.35H at ~62deg lean, head 0.16H, body length 0.46H, back rakes ~8-9deg withers->croup, tail+switch hangs to ~0.22H. THE TWO SPECIES-DEFINING READS (cold zoologist critic): (1) the neck DIAGONAL sweeping out of a raised WITHERS HUMP — my first loft delivered a 3deg slope when the plan said 8 (station tables drift: MEASURE the built mesh against the plan datum, don't trust the table); without the hump the correctly-proportioned neck reads 'stump'. (2) Coat FIGURE-GROUND: dark patches are the figure, cream seams the (THIN, 1-3cm) ground — wide seams read 'cracked porcelain'; Masai = big jagged patches: voronoi DISTANCE_TO_EDGE scale 3.0 + noise distortion (scale 7, amp 0.5) + ramp 0.012/0.035, patch (0.30,0.155,0.065). CONSTRUCTION: body = station loft; neck/legs/tail = parallel-transport tubes (tapered-limb-tube); mane = tube COMPUTED off the neck surface points+radii (hand-offset mane was swallowed INSIDE the neck — armor-comb failure class again; bury the start point in the body or the cap shows); joints/fetlocks as pale spheres between coat-upper and pale-lower tubes; hind hooves offset back (hock hint); stance believability via per-leg x offsets. World-position (Geometry.Position) Voronoi keeps the pattern CONTINUOUS across separate meshes. GAPS BITE TWICE: lower-leg tubes must END INSIDE the hooves (hoof height changes reopen the float). ACCEPTED: mane base edge-read, stiff no-rig stance, uniform patch tone, clay-matte finish.
- verified_by: _tmp/giraffe/giraffe_contact.png + giraffedet_contact.png (all gates green incl. measured-datum asserts withers/belly; 1 cold-critic round + fix round)
