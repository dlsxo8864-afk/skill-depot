---
key: scorpion-cvrt
kind: object
---
# scorpion-cvrt — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'scorpion-cvrt'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — FV101 Scorpion parked: measured layout + first tracked-vehicle lessons
LAYOUT (scorpion__side.jpg + type dims hull 4.79 x 2.23 x 2.10): FIVE road wheels r 0.29 at 0.68 PITCH (not 0.60 — pitch sets the compact CVR(T) rhythm), FRONT drive sprocket RAISED+SMALLER (r 0.19, z 0.45) with a 9-TOOTH ring — an undifferentiated sprocket gets COUNTED AS A SIXTH WHEEL by any AFV-literate viewer (critic did exactly that; the count was 5 by construction, the READ said 6 — differentiation IS the count); rear idler r 0.22 smooth; track = RIBBON-LOOP technique (trace outer path around sprocket/idler/run incl. raised ends + slight top sag, offset inward 0.085, bridge 4 loops -> solid belt; keep the sponson bottom ABOVE the track top run or the visible top run — a key AFV cue — hides inside the hull). HULL: constant-width box plan-form (taper ONLY at the glacis — double-ended taper reads 'boat'); ONE flat glacis plate bow-lip->deck (a knuckle kills the CVR(T) profile); vertical rear plate. TURRET: footprint <=67pct hull width (mine at 85pct read 'deck-sized'), ring centre 0.58L aft (critic misread 'amidships' off the bustle sprawl — gated station held), 3-ring angular loft, hatches FLAT discs <=4cm proud, smoke dischargers as 4-cup fans ON A BASE PLATE (loose nubs read as ambiguous; the plate sells the bank). GUN: L23 is STUBBY — muzzle ends AT/just past the bow (~0.44 hull lengths of barrel); overlong gun = 'wrong class of vehicle'; canvas collar cylinder at the root + small mantlet (a slab mantlet reads brick-through-wall). WHEELS: 3-part (dark tire ring + green disc + pale hub) — single-tone discs mush together. Fittings seat against the SLOPED cheek faces (interpolate the loft face x/y at the fitting's z — base-ring coordinates strand them: first build had the whole turret group floating 8cm). ACCEPTED: no track teeth/links, no torsion arms, single green, no markings.
- verified_by: _tmp/scorpion/scorpion_contact.png + scorpiondet_contact.png (gates green: L/W 2.15, height datum, symmetry; 1 armour-critic round + fix round)
