---
key: pine tree
kind: object
---
# pine tree — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'pine tree'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — proportions + conifer build technique
PROPORTIONS (m, Britannica+search): height 12-24 (build ~14); STRAIGHT trunk Ø up to ~1 base, tapers to a POINT; conical/pyramidal crown in regular WHORLS (annual tiers); crown spread ~5-7 (bottom branches ~3, shrinking to the top). BUILD: trunk = bmesh rings, taper r=(1-t)^1.4 -> point (NOT leaning like a palm; conifers are straight). CROWN = stacked WHORLS/tiers: at each of ~13 heights place a ring of branches; branch LENGTH decreases linearly with height (conical), MORE branches lower, drooping (elev negative, more droop at the base), azimuth offset per tier + jitter. BRANCH = BOTTLEBRUSH, the key conifer difference vs the palm frond: needles radiate AROUND the twig (tip = cos(a)*nl, fwd, sin(a)*nl for a = k*2pi/around + i*0.7 spiral), NOT a flat planar leaflet row. Pointed LEADER = a few short upright branches at the very top. DENSITY LESSON: v1 (around=5, sparse tiers, strong droop) looked wispy/scraggly; v2 (around=7, segs 18, more+lower branches, gentler droop, wider base) reads as a full pine. Inspect = same as palm: hundreds of intentional crown overlaps, judge by eye. Topology clean (needles=tris, trunk cleaned).
- verified_by: _tmp/pine/pine_contact.png — full conical conifer, tiered whorls, pointed top

## 2026-06-21 — v3 realism upgrades
v2 -> v3 (verified by eye): (1) BREAK THE WHORL BANDING: v2's branches all sat at exact tier heights -> rigid mechanical rings. Add per-branch VERTICAL jitter (zb = zt +/- 0.45) so adjacent tiers blend into a continuous organic crown. (2) BRANCH SWEEP: lateral S-curve on each branch (sweep jittered +/-0.4) so branches CURVE, not straight radial spokes. (3) 3-TINT greens chosen by height (dark lower / mid / light upper) for crown depth. (4) trunk uses material.bark (procedural plates). LIGHTING LESSON (a real mis-step, then fix): a BACK-SIDE sun (angle X=-42) put the camera-facing side in shadow and the dark greens went near-black -- lost the lush form for a subtle rim glow. For a DENSE conifer, a FRONT 3/4 sun (X=+50) + bright sky fill reads lush and green; backlight translucency-glow (which worked on the airy palm) is NOT worth the readability trade on a dense dark tree. Progression: v1 wispy -> v2 full-but-banded -> v3 full+organic.
- verified_by: _tmp/pine/pine_v3_contact.png — lush organic conical pine, un-banded tiers, swept branches

## 2026-06-21 — v4: built with nature's rules (phyllotaxis)
The v1-v3 sparseness/banding came from EVEN spacing (rigid whorls, 360/N). v4 uses blendkit.phyllotaxis: (1) place ~95 main branches via cylinder_phyllotaxis(N, z0, z1) -> a continuous GOLDEN-ANGLE (137.5deg) spiral UP the trunk, length tapering with height (conical) -- removes the mechanical tier banding. (2) each main branch is a small RECURSIVE sub-tree via grow(length, depth=1, children=2, length_ratio=0.5, branch_angle=30): build a make_branch needle-limb at every yielded (pos,dir) frame (orient the +Y limb with dir.to_track_quat('Y','Z')) -> the sub-twigs add the fractal density that fixes 'sparse'. 285 limbs total, still 0 n-gons. RESULT: noticeably fuller and more natural than the even-spaced v3. LESSON: for any repeated/branching natural form, place by phyllotaxis + recursion, NOT even division -- see patterns/phyllotaxis.md.
- verified_by: _tmp/pine/pine_v4_contact.png — continuous golden spiral (top view), full fractal crown
