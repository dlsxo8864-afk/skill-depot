---
key: destroyer-fletcher
kind: object
---
# destroyer-fletcher — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'destroyer-fletcher'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Fletcher-class 1942 waterline: photo-measured stations + detail-density lessons
STATIONS (measured off refs/destroyer-fletcher__broadside-1942.jpg, x=57.4-frac*114.76): G51 0.146 / G52 0.193 / bridge 0.22-0.28 (Mk37 at 0.25) / foremast 0.354 / funnels 0.414+0.538 (rake 10deg aft, fore-aft width ~3.8m — SLIM ROUND FUNNELS ARE THE #1 'generic ship' tell) / TT banks 0.485+0.60 / aft house 0.64-0.72 / G53-55 0.723/0.783/0.848 / DC racks 0.95. Hull: L/B 9.54, flush deck, sheer 4.2->5.85m, waterline loft w/ camber point; stern needs 2 EXTRA fantail stations + small raked transom (a wide flat cap reads 'sawn-off slab'). TRIAGE LESSONS (naval cold critic): critic called the hull '7:1 canoe' — MEASURED 9.53 by construction; when a critique contradicts a gated measured constant, the constant wins (check the render's perspective distortion instead). But critic was RIGHT that: tripod mast legs must be COMPUTED to intersect the raked mast axis (mine missed by 0.65m — 'connects to nothing' is the instant amateur tell; solve the leg rotation from the 3D direction vector, never eyeball); DC drums nest TOUCHING on inclined rails (spaced drums = gear teeth); scale anchors (bollard pairs, capstan, chain run, doors, inclined ladders) are what make 115m read as 115m. SUPER-DETAIL RULE: density is judged at CLOSE range — detail cameras must frame 10-15m spans, and features under ~0.3m need CONTRAST (dark on haze) or they are sub-pixel confetti (armor rivet lesson at ship scale). ACCEPTED: monochrome haze (no deck tone), boxy gunhouses (no sloped shields), no railings/rigging wires, wargame-clean finish.
- verified_by: _tmp/destroyer/destroyer_contact.png + destroyerdet_contact.png (all gates green: measured-datum asserts, beam/LOA 0.105, stations, symmetry; 1 naval-critic round + fix round)
