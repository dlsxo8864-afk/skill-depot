---
key: m14 rifle
kind: object
---
# m14 rifle — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'm14 rifle'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — proportions + multi-part build
PROPORTIONS (m, Wikipedia/GlobalSecurity): overall ~1.12; barrel ~0.56; 7.62mm; 20-rnd magazine; WALNUT stock + BLUED steel. BUILD along +X (muzzle +X, butt -X), bore axis z=0.05. PARTS (10): STOCK = a bmesh SIDE-PROFILE polygon (butt/comb/semi-pistol-grip/forend in XZ) extruded in Y -> one contoured wood piece (cleanup de-ngons the caps); BARREL GROUP coaxial on z=0.05 = barrel/flash-suppressor/gas-cylinder cylinders rotated set_rotation_deg(0,90,0) to lie along X; RECEIVER box; MAGAZINE box hanging below, tilted -6deg, overlapping the receiver bottom so it CONNECTS; front/rear SIGHTS small boxes on barrel/receiver; trigger guard+trigger. All joints OVERLAP so failure_scan is CLEAN (10 parts connected, 0 floating). GUN LESSONS (Polycount/CGMA/80lv): block out the SILHOUETTE first (guns are extremely proportion-sensitive); CONTRAST materials (warm walnut vs dark blued steel -- NOT all one shiny metal). NOTES: (a) a rifle is NOT axially symmetric, so inspect.axis_alignment flags the intentional off-axis mag/stock/sights -- informational only; the barrel GROUP is coaxial by construction (build it that way). (b) when a model hangs below z=0 (the magazine), put the ground there AND pass failure_scan(floor_z=ground_z) or you get false below-ground hits.
- verified_by: _tmp/m14/m14_contact.png — reads as an M14; failure_scan CLEAN (floor_z=-0.12), topology 0 ngons

## 2026-06-21 — draft -> detail multi-pass
Followed SOP-06 (draft-then-detail). The 10-part DRAFT locked proportions/silhouette; then per-part DETAIL passes, each kept connected + checked: FLASH SUPPRESSOR -> make_tube hollow cylinder (open muzzle bore) + a dark top slot box (no boolean -> suggest the slot, hollow the muzzle); FRONT SIGHT -> post + two protective WINGS (boxes flanking, +/-Y); OP-ROD -> the M14 signature, a thin cylinder along the LOWER-RIGHT of the barrel (y=+0.015, z=BORE-0.009); REAR SIGHT -> base + upright + aperture ring (small Y-cylinder); MAGAZINE -> body + wider FLOOR PLATE box at the bottom + front locking LUG; TRIGGER GUARD -> a LOOP from 3 thin bars (front/back/bottom) with the trigger inside (no boolean hole needed); BUTT PLATE (park steel cap) + upper HANDGUARD (walnut over the rear barrel). RESULT: 21 parts, failure_scan CLEAN (all connected, the tube/loop/wings all overlap neighbours), topology 0 n-gons. LIMIT: still mid-detail (boxy up close) -- without boolean/bevel you get readable silhouette detail, not hero surface detail. GOTCHA: call preflight AFTER frame_scene (it needs the camera) or it ABORTs falsely.
- verified_by: _tmp/m14/m14_detail_contact.png + _closeup.png — detailed silhouette; failure_scan CLEAN (21), topology clean

## 2026-06-21 — detail-pass fixes + cross-part validation
Two defects SHIPPED in the first detail pass and missed because a CLEAN failure_scan was trusted over the eye: (1) FLASH SUPPRESSOR detached from the barrel by 5mm -- it passed because it touched the SLOT box on it (pairwise connectivity); the body was 19 parts + a 2-part suppressor island. (2) REAR SIGHT had a void (base+upright stack). FIXES: failure_scan now enforces ONE connected component (union-find, eps 3mm) -> flags the island; suppressor moved to OVERLAP the barrel; rear sight rebuilt as one solid block. NEW VALIDATION recorded for the M14: RATIOS barrel:receiver~3.0, mag-h:receiver-h~2.7, suppressor:barrel~0.13; ALIGNMENTS front/rear sight + barrel + suppressor + mag all on the Y centreline, barrel/suppressor coaxial in Z. ALWAYS render tight close-ups of the SEAMS (muzzle, sight) -- look, don't trust the green check.
- verified_by: _tmp/m14/cu_muzzle.png + cu_rear.png (seams) -> attached + solid; failure_scan/ratio/alignment all OK
