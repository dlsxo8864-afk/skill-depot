# Object learnings — index

One line per object; open the linked file for the detail.

- [sword](sword.md) — one-handed arming sword: proportions, hilt anatomy, lay-flat for blueprint, clean topology
- [chair](chair.md) — wooden dining chair: seat 45cm / 42x40 / ~4cm legs / ~85cm total; all-box = pure quads; backrest cross-members trip the float heuristic (lateral joint)
- [coconut palm](coconut-palm.md) — organic bmesh: tapered leaning trunk + PINNATE fronds (rachis+leaflets, not smooth blades); crown overlaps are intentional
- [pine tree](pine-tree.md) — conifer: straight tapered trunk + CONICAL whorls of drooping BOTTLEBRUSH branches (needles radiate around twig, not flat fronds)
- [m14 rifle](m14-rifle.md) — complex multi-part: bmesh side-profile walnut stock + coaxial blued-steel barrel group + receiver/mag/sights; silhouette-first, contrast materials
- [car](car.md) — sedan: side-profile body w/ wheel arches, glass-band greenhouse + roof, lamps below hood break, flush face details
- [bonsai](bonsai.md) — informal-upright (moyogi): sinuous tapered trunk, golden-angle nebari+branches, da Vinci taper, Vogel-packed foliage pads, shallow pot
- [battleship](battleship.md) — WWII fast battleship (Iowa/NC): L/B~8, 2-A-1 superfiring triple turrets, lofted plan-hull, tower+funnel+mast, grey/boot/red banding
- [anime head](anime-head.md) — stylized anime female head: flattened-face ovoid (subsurf) + layered ellipse-disc eyes + clumped bob hair; proportions off the front grid
- [aircraft carrier](aircraft-carrier.md) — Nimitz CVN: lofted hull + FLAT flight deck that OVERHANGS the hull 1.87x + 9deg angled deck + STARBOARD island + spotted jets; built through the SOP-07 design gate
- [windows 95 pc](windows-95-pc.md) — beige CRT (DEEP, tapered back) + lit Win95 desktop (teal+taskbar+Start w/ 4-colour flag+icons+clock) on a horizontal case + keyboard + mouse + desk; feature parts first
- [human-face-bust](human-face-bust.md) — human head/face proportions + which primitive constructions read vs fail
- [knight-armor](knight-armor.md) — full plate armour: keeled cuirass loft, lames, pauldrons, museum stand; anti-nutcracker rules
- [giraffe](giraffe.md) — giraffe/quadruped: measured canon (withers hump, neck diagonal, Masai coat figure-ground)
- [destroyer-fletcher](destroyer-fletcher.md) — warship destroyer: measured stations, superstructure density rules, naval-critic triage
- [c130-hercules](c130-hercules.md) — C-130H: photo-measured stations, high-wing config rules, foreground-underside camera trap
- [fa50-golden-eagle](fa50-golden-eagle.md) — FA-50/fast-jet: photo-measured stations, store proportions, fighter identity parts
- [scorpion-cvrt](scorpion-cvrt.md) — FV101 Scorpion / tracked AFV: running-gear identity rules, ribbon-loop tracks, turret footprint
- [mk44-bushmaster](mk44-bushmaster.md) — Mk44 Bushmaster II / gun props: receiver-proportion rule, ammo-path realism, ported brake, display stand
- [philippine-tricycle](philippine-tricycle.md) — PH tricycle / bike+sidecar vehicles: cab enclosure rules, fitted roof, tangent fender arcs
- [andrada-patrol-craft](andrada-patrol-craft.md) — Jose Andrada PC / small patrol craft: measured stations, first FULLY-GATED pipeline run
- [rx78-gundam](rx78-gundam.md) — RX-78-2 / humanoid mecha: proportion canon, two-agent triage wins, color-block-as-volumes rule
- [mage-staff-gun](mage-staff-gun.md) — fantasy prop hybrid: SOP-09 first live run, occluded-evidence lesson, magic-float tether pattern
- [thunder-mace](thunder-mace.md) — flanged mace grammar (Cleveland-measured) + lightning-as-geometry language + hard-key numbers
- [ijn-carrier-akagi](ijn-carrier-akagi.md) — IJN carrier grammar (vs USN), coplanar z-fight marking bar, dark-albedo lift, apply_transforms trap
