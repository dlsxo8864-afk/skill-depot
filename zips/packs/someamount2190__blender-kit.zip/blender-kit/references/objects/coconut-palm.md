---
key: coconut palm
kind: object
---
# coconut palm — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'coconut palm'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — proportions + organic build technique
PROPORTIONS (m, 3 sources): height 20-30 (build ~12 trunk + ~4.5 fronds for framing); trunk dia 0.30-0.45 tapering up (+basal swell); crown spread 6.7-10; 25-35 fronds each 4-6 (built 20); leaflets 0.6-0.9; coconut ~0.30. BUILD: TRUNK = bmesh rings lofted along a leaning (x=lean*t^2) tapered centreline with a basal swell, caps cleaned via build.cleanup. FROND = PINNATE, NOT a smooth blade: a central arching rachis (z=L*(rise*sin(0.6pi t) - droop*t^2)) with drooping leaflet TRIANGLES on both sides (tip out +/-X and down) -> feathery. KEY LESSON: a smooth V-blade frond reads as a spiky yucca/aloe; leaflets are what make it read as a COCONUT palm. Arrange ~20 fronds radially: make_frond then set_rotation_deg(0,0,360/N*i), location=crown; 2 tiers (vary length/rise/droop) for a natural crown. Coconuts = uv_sphere cluster just under the crown. INSPECT NOTE: a palm crown yields HUNDREDS of overlaps + many floats (all fronds radiate from ONE point, crown is ~12m up with nothing below) -- ALL intentional organic joins; inspect.scene_report is NOT useful for organic clustered crowns, judge by eye. Topology stays clean (fronds=tris, trunk cleaned, spheres=tri-poles, 0 ngons).
- verified_by: _tmp/coconut/coconut_contact.png — reads as a coconut palm; feathery crown + leaning trunk + palm shadow

## 2026-06-21 — v2 realism upgrades
Pushing v1 -> v2 (each verified by eye): (1) LAYERED CROWN, not a flat radial spray: assign fronds to 3 ELEVATION tiers via set_rotation_deg(elev,0,azimuth) -- inner upright (elev +44, short), mid (+18), outer drooping (elev -6, longer, more droop). The X-tilt (elev) applies before the Z azimuth in Euler XYZ, so it raises/lowers each frond's base -> the coconut 'fountain' shape with depth. (2) FINER leaflets: segs ~26 with thin leaflets swept FORWARD toward the tip and drooping (tip = out 0.6*ll, forward 0.62*ll, down 0.58*ll) -> feathery, not coarse spikes; leaflet length peaks mid-frond. (3) trunk RING SCARS via a small radius wobble per ring (r *= 1 + 0.04*sin(i*1.15)). (4) two frond greens (dark inner / light outer) + a fuller coconut bunch read better. Still airy/see-through (real coconut crowns are somewhat airy, so OK); denser would need more fronds or wider leaflets.
- verified_by: _tmp/coconut/coconut_v2_contact.png — layered fountain crown, feathery leaflets, believable silhouette

## 2026-06-21 — v3 realism upgrades
v2 -> v3 (verified by eye): (1) FROND SWEEP -- give the rachis a lateral S-curve (xc = sweep*sin(0.85*pi*t), sweep jittered +/-0.55, signed) so fronds aren't planar pinwheel spokes; visible in the top view as curved (not straight) fronds. (2) PER-FROND JITTER via a deterministic index hash (_jit(i,salt,lo,hi)) on length/elevation/azimuth/droop/sweep -> organic, not mechanical; deterministic so the render reproduces. (3) BACKLIGHT to reveal leaf translucency: sun from UPPER-BACK (angle_deg X=-48 -> the sun's -Z points -Y & down = light coming from +Y/above THROUGH the leaves toward camera) + world_sky ~1.35 to keep the camera side readable. 28 fronds across 3 elevation tiers. Progression recap: v1 smooth-blade=spiky; v2 pinnate+layered crown; v3 sweep+translucency+jitter.
- verified_by: _tmp/coconut/coconut_v3_contact.png — swept curved fronds + glowing translucent leaflets (top view), believable silhouette
