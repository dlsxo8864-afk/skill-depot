---
key: fa50-golden-eagle
kind: object
---
# fa50-golden-eagle — object learnings

One file per object (keeps the catalog from bloating). Consult this
BEFORE building 'fa50-golden-eagle'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — FA-50 parked+armed: measured stations + fighter-specific rules
STATIONS (fa50__profile.jpg, x=6.57-frac*13.14; dims L 13.14 span 9.45 armed H 4.94): radome 0-0.11L (DARK, flush loft cap), windshield 0.145L, tandem canopy 0.145-0.38L (ONE bubble ~2.9m + aft blend fairing down to the spine — a cliff-edge step reads amateur), LERX chine 0.22-0.49L (make it a WIDE shelf ~0.6m hugging the fuselage, not a thin stub — vestigial LERX = 'older dumber airplane'), intake lip 0.30L under the LERX (inlet face RECESSED + near-black 0.02 + splitter plate), wing root LE 0.49L chord 2.9 sweep 35deg tips +-4.35, stab LE 0.785L with ~4deg ANHEDRAL (rotate the loft object about world X — mesh coords are absolute so origin-at-world rotation IS the anhedral), fin root LE 0.77L fin top 4.90 + tip pod poking FORWARD of the LE (real feature), nozzle: BOAT-TAIL the last loft stations (0.54->0.36) then recessed dark ring + 12-petal crown + turbine disc — a butt-joined cylinder = 'paper towel roll'; ventral strakes (0.95x0.36 canted 22deg) under the tail roots. STORES: AIM-9 = 24:1 pencil (r 0.075 x 3.0), fin groups at 15pct/90pct body length, tail-fin halfspan ~0.3 canards ~0.15, missile TAIL ends at wing tip TE (not level with the stabs — check plan-view overlap); CL tank = scale-baked capsule on a slim pylon. CRITIC TRIAGE: 'wing too far aft/root past mid-fuselage' LOST to the gated 0.49L station (their own prescription); store shapes/nozzle/LERX width were RIGHT. Gear: hubs (light discs) + door plates kill the 'stick and coin' read. LIGHT-RIG SCALING: energy does NOT transfer between subject scales by feel — the C-130 rig at 13m was 26x hot (E/(size^2 d^2)); recompute per scene, Filmic rolloff.
- verified_by: _tmp/fa50/fa50_contact.png + fa50det_contact.png (gates green: datum length/fin-top, span/length 0.66, stab/wing, symmetry; 1 fast-jet critic round + fix round)
