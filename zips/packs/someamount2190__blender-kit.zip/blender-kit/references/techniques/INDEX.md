# Technique learnings — index

One line per technique; open the linked file for the detail.

- [smooth-beveled-hardsurface](smooth-beveled-hardsurface.md) — Bevel modifier (angle-limited) + all-faces-smooth + harden_normals = stamped sheet metal from a blocky mesh
- [side-profile-extrusion](side-profile-extrusion.md) — draw the silhouette as an XZ polygon, extrude in Y to width, cleanup de-ngons the caps; the workhorse for symmetric long objects
- [tapered-limb-tube](tapered-limb-tube.md) — parallel-transport-framed tube of rings along a centreline w/ per-point radius; the workhorse for trunks/branches/roots/horns/pipes
- [foliage-pad-vogel](foliage-pad-vogel.md) — Vogel-disk packed squashed blobs = a flat-topped foliage CLOUD; clumpr must exceed inter-clump spacing or it reads as grapes
- [lofted-hull-stations](lofted-hull-stations.md) — loft a hull/fuselage from per-station cross-sections with VARYING beam (plan shape); side-profile-extrusion's constant width can't do a ship
- [per-face-material-by-height](per-face-material-by-height.md) — assign paint bands (e.g. ship red/boot/grey) by face center z -> waterline banding on ONE mesh, no splitting
- [flattened-facial-plane](flattened-facial-plane.md) — flatten the front of an ovoid toward a plane so FLAT decals/features (anime eyes, a clock face, a screen) lie on it instead of protruding off the curve
- [screen-ui-decals](screen-ui-decals.md) — a readable UI/screen = flat EMISSIVE decal layers stacked just in front of the glass at a known plane; one signature element sells it
- [boolean-bevel-greeble-detail](boolean-bevel-greeble-detail.md) — hard-surface detail: panel grooves, embedded greebles, bolt rings, sharp-edge bevels
- [per-part-detail-verification](per-part-detail-verification.md) — verifying small features: per-part close-up renders + per-part topology gate
- [photoreal-human-mpfb](photoreal-human-mpfb.md) — photoreal human/face/character: MPFB generate + CC0 assets + HDRI + Cycles SSS (SOP-08)
- [lattice-truss-generator](lattice-truss-generator.md) — generated lattice structures (towers/cranes/bridges): spline envelope + truss_bays + member() strut helper
- [subassembly-first-builds](subassembly-first-builds.md) — multi-machine objects (vehicle+trailer, bike+sidecar, gun+mount): build each machine as its OWN gated sub-build, then assemble
- [fitted-gear-on-figures](fitted-gear-on-figures.md) — fitting hard-surface gear to MPFB figures: vertex-band traps, texture-linked recolor no-op, cap anchoring
- [character-degradation](character-degradation.md) — zombie/corpse from the MPFB pipeline: rot node-surgery, mottle chain, exposure-first horror, wound clusters, no-rig lean
- [process-hardening](process-hardening.md) — ledger.finish() named-check verdicts; subject_bbox canonical framing; sample-verified AABB attachment
- [kit-extensions-night2](kit-extensions-night2.md) — torus rings, texture-preserving tint, catenary straps, rune glyphs, eye dials — five extensions verified in one night pass
