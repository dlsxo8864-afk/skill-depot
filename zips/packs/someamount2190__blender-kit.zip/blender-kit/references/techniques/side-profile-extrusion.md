---
key: side-profile-extrusion
kind: technique
---
# side-profile-extrusion — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'side-profile-extrusion'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — build from the side view (sword/rifle stock/car body)
For any object whose IDENTITY is its side silhouette (sword + fuller, rifle stock, car body), don't stack boxes — author the side profile as an ordered list of (x,z) points and extrude it in Y by +-width/2 (one quad per profile edge + two cap n-gons), then build.cleanup() to triangulate+join the caps back to quads (de-ngon). This is exactly where a 2D side ORTHO/blueprint reference pays off: trace the profile points off the image. Cut features straight into the profile loop (a car's WHEEL ARCHES, a fuller's taper) so they're part of the silhouette, not bolted on. Keep point count low; let smooth-beveled-hardsurface round it. profile_extrude() in _tmp/car.py is the reference impl.
- verified_by: _tmp/car/car_hd_contact.png (side profile reads), _tmp/sword + m14 stocks
