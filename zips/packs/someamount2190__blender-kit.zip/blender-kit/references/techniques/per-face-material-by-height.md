---
key: per-face-material-by-height
kind: technique
---
# per-face-material-by-height — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'per-face-material-by-height'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — height-banded materials without cutting the mesh
To paint horizontal bands on a single mesh (ship hull waterline: red below / black boot-topping straddling z=0 / grey topside; or strata, snow-line, tide-marks): append the N band materials to obj.data.materials, then loop obj.data.polygons and set p.material_index by the band p.center.z falls in. No boolean/loop-cut needed; the bands follow the geometry. Caveat: bands are per-FACE so the boundary is as crisp as the mesh is dense there — add a horizontal edge loop at a band line if you need a sharp seam. Used for the hull's grey/boot/red in _tmp/warship.py build_hull().
- verified_by: _tmp/warship/warship_broadside.png (black boot-topping band at waterline, red at bow)
