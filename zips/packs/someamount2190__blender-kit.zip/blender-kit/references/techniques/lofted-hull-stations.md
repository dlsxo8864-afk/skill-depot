---
key: lofted-hull-stations
kind: technique
---
# lofted-hull-stations — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'lofted-hull-stations'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — plan-shaped hull by lofting station rings
side-profile-extrusion gives CONSTANT width -> a barge, not a ship. For a hull/boat/fuselage/airship, LOFT instead: walk stations along the long axis (X); at each station compute half-beam b(x) (plan curve: fine pointed bow b->0, full beam parallel midbody, tapered rounded stern), deck height zd(x) (SHEER: rises toward bow), keel zk(x) (forefoot rises to bow). Build a half cross-section [deck-edge -> topside -> turn-of-bilge -> bilge -> keel-centre] as (y,z); make a full open ring = starboard + mirrored port; connect consecutive station rings with quads; cap bow/stern rings (n-gon -> build.cleanup de-ngons). Leave the TOP open and cover it with a SEPARATE deck strip (port deck-edge to starboard, per station) so the deck can be its own material + slight camber. The open hull top makes topology_report non-manifold (boundary edges) — fine for a still; failure_scan is the real gate. Reference impl: build_hull() in _tmp/warship.py.
- verified_by: _tmp/warship/warship_contact.png (top view: fine bow, full mid, tapered stern)
