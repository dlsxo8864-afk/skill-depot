---
key: process-hardening
kind: technique
---
# process-hardening — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'process-hardening'; record new learnings only after a render/inspect
verified them.

## 2026-07-06 — Three infrastructure fixes: verdict assembly, subject framing, coarse-attachment verification
(1) ledger.finish(out_dir, checks_dict, view_outputs=[...]) assembles the gate verdict from NAMED checks — hand-written 'ok = a and b and c' expressions drift (the Gundam omitted ratios[ok] and recorded green on a failing check). finish() is fail-closed (None/missing 'ok' = FAIL), auto-fails any render carrying an error (the exposure gate rides this), and records WHAT was checked in the ledger so omissions are visible. 4 unit tests; thundermace migrated as live exemplar (GATES_OK, 5 checks named). Migrate builds opportunistically. (2) canonical_views(subject_bbox=...) frames the SUBJECT not the scene AABB — frame_scene fits the whole-scene bounding sphere to the smaller FOV axis, shrinking tall subjects in portrait frames to ~25pct height (soldier ITEM 9); with the explicit bbox the figure fills 55-70pct. Top view stays scene-fit (blueprint semantics). (3) AABB COARSENESS FIX (the disclosed Andrada porthole miss): 'attached' used to mean AABB-separation<=tol to ANY object — but separation to a vastly larger CONTAINING AABB (a hull loft spans the whole ship) is meaningless; a part orphaned 1.8 m inside it measured gap 0. Now: when the only contact is containment in a >50x-volume AABB, attachment must be verified by vertex-subsample distance (<=48 pts/object, supplied by the bpy adapters); unverifiable cases are accepted BUT reported in scene_report['coarse_attachments'] so the ledger sees them. Applied to BOTH paths (inspect_core.find_floating AND failure_scan's union-find — they are separate implementations; the union-find was the gate that actually passed the portholes). 5 unit tests + live A/B: orphan chip inside a hull box flagged, welded fitting not.
- verified_by: design/ 16/16 tests; _tmp/aabbfix COARSE_VERIFY PASS; thundermace GATES_OK exemplar; soldier subject-bbox canonical sheet VIEWED
