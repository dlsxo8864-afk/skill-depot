---
key: smooth-beveled-hardsurface
kind: technique
---
# smooth-beveled-hardsurface — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'smooth-beveled-hardsurface'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — round the creases, keep the panels flat
To get a curved automotive/appliance surface from a blocky bmesh WITHOUT hand-modelling: add a BEVEL modifier with limit_method='ANGLE', angle_limit~28-33deg (so only real creases bevel, not coplanar seams), segments 2-3, width ~0.02, harden_normals=True; then set every polygon use_smooth=True. Coplanar panels stay visually FLAT; only the beveled creases shade as rounded fillets -> reads as stamped metal. Single biggest low-poly->realistic lever. Per-part: body/roof/bumpers YES; flat glass + rim-window insets NO (keep crisp). Modifiers are data-API (obj.modifiers.new), allowed (not bpy.ops). Non-destructive: failure_scan/topology/ngon counts unchanged.
- verified_by: _tmp/car/hd_hero.png (smooth red body, soft highlights)
