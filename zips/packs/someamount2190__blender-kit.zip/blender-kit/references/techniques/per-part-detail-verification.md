---
key: per-part-detail-verification
kind: technique
---
# per-part-detail-verification — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'per-part-detail-verification'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Verify intricacy PER PART: render.detail_views + inspect.topology_gate
A whole-model contact sheet cannot judge a 2cm bolt ring — small features must be verified at their own scale. render.detail_views(parts, out_dir) frames each plan-section-5 feature part with camera.frame_object (85mm long lens, full-scene clip so context stays visible) at high res and stitches a detail contact sheet; gate on each part's error field. inspect.topology_gate(part_names) fails per-part on n-gons/doubles (the defects that break bevels/subdiv on exactly the small parts detail adds). Proof it works: on its first run this pair caught two real kit defects (bevel-collapsed double verts; greebles overlapping each other).
- verified_by: _tmp/detailkit/hatchdet_contact.png (4 per-part close-ups, all gates green)
