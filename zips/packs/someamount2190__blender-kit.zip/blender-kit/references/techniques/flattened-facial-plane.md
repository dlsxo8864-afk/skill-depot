---
key: flattened-facial-plane
kind: technique
---
# flattened-facial-plane — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'flattened-facial-plane'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — carve a flat plane on a curved body for flat features
Flat layered features (anime eyes, a gauge face, a logo, a screen) placed on a curved surface PROTRUDE as plates at the edges and read wrong. Make a FLAT mounting plane on the curved body: for front verts (y>0) in the feature region, pull y toward a target plane FACE_Y, blended by how central the vert is (cx*cz falloff in x and height) so the flatten fades smoothly into the surrounding curvature (no hard rim); subsurf then smooths it. Now flat discs at depth ~FACE_Y sit flush. Place the feature at the KNOWN plane depth (you set FACE_Y) instead of guessing the curved surface depth. Used for the anime face in _tmp/anime.py (FACE_Y=0.47).
- verified_by: _tmp/anime/anime_front.png (eyes lie flush on the flattened face)
