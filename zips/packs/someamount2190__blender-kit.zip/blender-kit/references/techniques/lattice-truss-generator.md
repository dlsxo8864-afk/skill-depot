---
key: lattice-truss-generator
kind: technique
---
# lattice-truss-generator — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'lattice-truss-generator'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Lattice generator: spline envelope, 3-order hierarchy, joint-overlap struts
Built for the Eiffel Tower (1168 members), reusable for any truss structure. CORE: (1) member(p0,p1,th,mat) — box strut with rotation SOLVED from the direction vector (d=Ry(ry)Rx(rx)z-hat -> rx=-asin(dy), ry=atan2(dx/cos rx, dz/cos rx)); length extended th*0.9 so joints OVERLAP (AABB-connected chains); base-level members' extensions dip ~0.5-1.3m below their endpoints — seat the lowest level on PADS tall enough to absorb the dip or failure_scan cries below-ground (bit twice). (2) truss_bays(levels, corner_fn, th_chord, th_secondary, th_tertiary, mat_fn) — per bay: 4 chords + tie ring + FULL X-braces + tertiary mid-tie; corner_fn(z) returns the 4 corners so the same generator does legs (leg-local squares on a curve) and whole-envelope spires. (3) ENVELOPE AS CATMULL-ROM through measured control points — piecewise-LINEAR levels put visible KINKS at the platforms and read 'radio mast' (critique kill #1); the spline + ~15m level spacing gives the continuous curve. HIERARCHY RULE (critique kill #2): >=3 distinct gauges (chords ~4-6x secondary, secondary ~2x tertiary) or the structure reads 'equal-gauge toothpicks/oil derrick'. TRANSPARENCY RULE (kill #3): platforms on open structures = RING decks (4 edge boxes) + OPENWORK girder bands (chords+posts+alternating diags), never solid slabs — 'see the sky through it' is the identity. Constants-beat-critics again: critic measured platform heights off the perspective render (25pct vs true gated 17.8pct). Eiffel specifics in the build: CTRL c(z) official half-widths 53/44.5/37/30/22.5/16.5/13.2/10.6/8.7/7.5/6.6/2.2 at z 0/20/40/57.6/88/115.7/150/185/220/250/276/300; arches ellipse a40 b27 apex 39 + spandrel posts to the band; 3-shade brown darkest at base.
- verified_by: _tmp/eiffel/eiffel_contact.png + eiffeldet_contact.png (v2: continuous curve, open decks, gates green: tip 324, footprint 122.6; 1 architecture-critic round)
