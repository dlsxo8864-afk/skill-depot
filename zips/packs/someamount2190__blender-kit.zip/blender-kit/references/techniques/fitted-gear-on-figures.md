---
key: fitted-gear-on-figures
kind: technique
---
# fitted-gear-on-figures — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'fitted-gear-on-figures'; record new learnings only after a render/inspect
verified them.

## 2026-07-05 — Gear-on-figure fitting: measured-fit rules from the soldier build
Fitting kit-built gear to a generated figure by measuring vertex bands WORKS but has traps, all hit and fixed: (1) VERTEX-DENSITY CENTROID TRAP: a head-band centroid is dragged toward the FACE (face vert density >> scalp) — the helmet reads as a face mask; use bbox midpoints, and for helmets anchor on the SCALP-ONLY band (top 3pct of height). (2) HELMET IS A CAP: dome center belongs ABOVE the crown (head_top + ~0.03 for dome r ~0.125 w/ z-scale 0.88), NOT at head center — center-anchored domes blindfold the figure. Brim lands at the brow; every cm of raise trades brow clearance for rear-skull exposure. (3) A-POSE ARMS POISON TORSO BANDS: waist/chest x-extents at 0.55-0.85H include hands/forearms (a 'belt' computed from such a band was a 1.3m saucer); filter bands to |x-axis| < 0.20-0.22 before taking extents; NEVER patch with a magic shrink factor (the x0.62 chest fudge put cummerbunds floating in the torso-arm air gap). (4) TEXTURE-LINKED RECOLOR NO-OP: writing Base Color default_value does NOTHING when an Image Texture link feeds the socket — and a hits-log that logs the WRITE not the EFFECT is a false positive; unlink-then-set and log the unlink count (all 3 garments here had exactly 1 link). (5) POKE-THROUGH: MPFB delete-group masking is not exposed via add_mhclo_asset; pants child scale 1.025 x/y about origin fixes thigh/hip poke cheaply (figure is axis-symmetric). (6) SLUNG NOT HELD: unrigged figures cannot grip — sling the weapon (4-member over-shoulder polyline via the trap crest at 0.888H reads as a two-point sling; rifle rear face ~1.5cm off the plate). (7) CANONICAL FRAMING MECHANICS (engineer-verified): Ground/Floor names are framing-EXEMPT (camera.FLOOR_NAMES); canonical_views DELETES the active camera and re-frames the scene per view, so a hand-placed hero camera is dead code for evidence — add a 'hero' detail view with an explicit figure bbox instead; the small-figure read comes from frame_scene fitting the bounding SPHERE to the narrow axis of a portrait frame.
- verified_by: _tmp/soldier round-2 contact sheets (rifle+gear sub-builds re-gated, assembly datums green, ship_check PASS w/ 2 disclosed deviations)
