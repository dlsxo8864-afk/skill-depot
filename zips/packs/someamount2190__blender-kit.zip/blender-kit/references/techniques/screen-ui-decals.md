---
key: screen-ui-decals
kind: technique
---
# screen-ui-decals — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'screen-ui-decals'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — build a screen UI from flat emissive decals
To put a recognisable UI/HUD/desktop on a screen (CRT, phone, dashboard, monitor) without textures: stack thin flat EMISSIVE boxes/planes just in front of the dark glass at a KNOWN plane depth (per the anime flat-decal lesson — don't guess the surface, you set the plane). Layer back-to-front: background fill -> bars/panels -> buttons/icons/glyphs, each a small box. Make the BACKGROUND and accents emissive so the screen reads as ON (and self-lights the scene). NAIL THE ONE SIGNATURE ELEMENT — for Win95 it's the 4-colour Start flag; that single motif does more for recognition than pixel accuracy. Mind the viewer/camera side: at camera +Y, +X is image-LEFT, so place left-aligned UI (Start, icons) at +X. Keep decals chunky/legible at the intended distance; don't over-detail.
- verified_by: _tmp/win95/win95_screen.png (teal desktop + taskbar + Start flag + icons read clearly)
