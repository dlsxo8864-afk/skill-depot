---
key: subassembly-first-builds
kind: technique
---
# subassembly-first-builds — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'subassembly-first-builds'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Sub-assembly-first: the tricycle lesson
USER-DIRECTED after the tricycle v1 shipped weak ('did you divide the tasks? motorcycle parts then the sidecar?'). RULE: when an object contains a machine that could be its own build (the motorcycle in a tricycle, the tractor in a tractor-trailer, the gun in a gun+mount), give that machine its OWN build script + OWN canonical/detail renders + OWN gate pass (and critique if budget allows) BEFORE assembly; expose it as a build_X() function and IMPORT it into the assembly script (importlib on the sibling file; __main__-guard the sub-build). The v1 one-pass tricycle got one whole-vehicle critique and its bike was a blob ('bath toy'); the phased rebuild caught per-machine defects the whole-vehicle views hid: axle-less wheels (swingarm at y 0.07 vs hub 0.045 — islands), bars floating without risers, and THE WHEEL RULE: a wheel is a RING — a solid cylinder tire reads as a gray disc no matter what rim/spokes hide inside it; build tire AND rim as tangent arc-segment rings (16/12 segs) so daylight shows through the spokes (spokes end AT the rim, never past — naval-mine bug). Frame voids need filling masses (airbox/side covers) or the tank floats. Assembly then only handles interfaces (sidecar frame to bike frame, shared roof struts).
- verified_by: _tmp/tricycle/bike_contact.png + bikedet_contact.png (phase-1 gates green) then tricycle_contact.png + tricycledet_contact.png (assembly green)
