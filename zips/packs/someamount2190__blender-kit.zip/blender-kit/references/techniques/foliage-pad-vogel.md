---
key: foliage-pad-vogel
kind: technique
---
# foliage-pad-vogel — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'foliage-pad-vogel'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — foliage pads / canopies as packed blob clouds
A foliage pad (bonsai cloud, shrub, tree-crown chunk) = phyllotaxis.vogel_disk(k) packed onto an ellipse (rx,ry), each site a low-poly squashed uv-sphere blob (z*0.62), domed in z (height ~ (1-r^2)) for a flat-ish top, smooth-shaded, ONE bmesh per pad. CRITICAL DENSITY RULE: clump radius must be LARGER than the inter-clump spacing (~rx/sqrt(k)) or the blobs read as separate grapes/cauliflower; overlap => a solid cloud. Centre the pad ON the branch tip so it stays connected (failure_scan one-component). Size pads bigger low / smaller high; add a central FILL pad to bridge gaps so a canopy reads as a layered mass, not isolated puffs (the v1->v2 fix). Vary tint by height (dark low/light high) for depth.
- verified_by: _tmp/bonsai/bonsai_contact.png (top view: dense golden-spiral pad canopy)
