---
key: tapered-limb-tube
kind: technique
---
# tapered-limb-tube — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'tapered-limb-tube'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — organic tapered limb along an arbitrary curve
To build any tapering curved limb (tree trunk/branch/root, vine, horn, hose): take a centreline (list of points) + a radius per point; at each point build a ring of N verts in the plane perpendicular to the local TANGENT, connect consecutive rings with quads, cap the ends, build.cleanup() to de-ngon the caps, then set faces smooth. KEY: frame the rings by PARALLEL TRANSPORT (carry the previous side-vector, re-orthogonalise against the new tangent) — using a fixed up-vector twists/pinches the tube on curves. Tangent at i = normalize(p[i+1]-p[i-1]). This + a centreline function (e.g. decaying-amplitude sinuous for a moyogi trunk) gives controllable organic limbs that a stack of cylinders cannot. Reference impl: limb() in _tmp/bonsai.py.
- verified_by: _tmp/bonsai/bonsai_padseam.png (smooth curved branch leaving trunk, no pinch)
