---
key: kit-extensions-night2
kind: technique
---
# kit-extensions-night2 — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'kit-extensions-night2'; record new learnings only after a render/inspect
verified them.

## 2026-07-06 — Night-2 extension batch: five queued capabilities shipped + one fix-of-the-fix
(1) build.add_torus(major_r, minor_r, segments=48): THE ring primitive — magegun orbit rings rebuilt with it read as forged circles (VIEWED; 12-24 member chains read as sausage links). Axis +Z; euler (0,90,-a) puts the axis in-plane at angle a. (2) material.tint_textured(obj, rgba, fac): MixRGB-MULTIPLY insert before Base Color — recolors textured cloth/skin WITHOUT killing the map (unlink-then-set's flaw); returns tinted-link count, CHECK IT (0 = untextured, fall back to plain set). Verified numerically: texture std survives, hue shifts (center-crop metric — whole-frame means dilute the signal with background, first check false-FAILED on that). (3) build.catenary_points(p0,p1,sag,n): parabolic sag for straps/slings/chains; 8-segment chain rendered + scan-connected. (4) detail.rune_glyph(prefix,i,origin,u_dir,v_dir): 12-glyph deterministic stroke alphabet on a surface frame — thundermace band now shows distinct characters (VIEWED) instead of blank chips; phase 2 (true curve-following scrollwork) still open. (5) PROCEDURAL_EYES is fully parameterized: top-level group inputs include PupilSize, PupilColor, EyeWhiteColor, Iris*Color, OuterLayerRoughness — the humanbody pupil KIT-EXTENSION resolves to plain socket sets, and zombie cataracts should tune EyeWhiteColor/Iris colors instead of wholesale material replacement. FIX-OF-THE-FIX: the AABB coarse-attachment verification switched from vertex-sample distance to EXACT closest_point_on_mesh in failure_scan — vertex sampling false-positived on long low-poly primitives (magegun barrel: 8-seg cylinder has verts only at end rings; a rune chip ON a mid-barrel flat measured 0.2m from the nearest vert and got flagged floating). Acceptance radius = small-part half-diagonal + 2cm. Orphan A/B still PASSES.
- verified_by: magegun + thundermace re-gated & VIEWED; _tmp/helpers TINT PASS/CATENARY PASS/pupil probe log; _tmp/aabbfix COARSE_VERIFY PASS post-fix

## 2026-07-06 — scoping notes: the two extensions that stay queued
- MESH SCULPT (clavicle/rib landmarks, cheek hollows, clothes tearing):
  needs per-vertex displacement along normals masked by anatomical
  regions — the kit has no vertex-group/region infrastructure on MPFB
  meshes yet. Honest path: MPFB targets (TargetService exposes many
  body-detail morph targets beyond the macro 8) — PROBE TargetService
  list first next session; the dial may already exist as a target, which
  would be dials-not-sculpting. Do not hand-displace verts blind.
- PAINTED WOUND/GRIME DECALS: needs UV-aware texture painting
  (bpy.data.images pixel writes mapped through the mesh's UVs at a hit
  point). Feasible headless (closest_point_on_mesh gives the face +
  barycentric UV), ~1 day of careful work: image-pixel compositing +
  seam handling. Geometry wounds (ellipsoid clusters) stay the interim.
- verified_by: scoping only — no code shipped for these two.
