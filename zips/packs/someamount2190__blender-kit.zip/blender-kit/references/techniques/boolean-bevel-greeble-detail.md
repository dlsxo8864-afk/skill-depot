---
key: boolean-bevel-greeble-detail
kind: technique
---
# boolean-bevel-greeble-detail — technique learnings

One file per technique (keeps the catalog from bloating). Consult this
BEFORE building 'boolean-bevel-greeble-detail'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Detail kit (blendkit.detail): booleans + bevel_sharp + embedded greebles/bolts
Intricacy = many SMALL DELIBERATE features on a good base. blendkit.detail gives each as a one-liner: panel_groove (axis-aligned boolean groove; several read as built-from-plates), boolean_cut (clean=True re-quads the n-gon cut faces so topology_gate stays meaningful), greeble_region (seeded + rejection-sampled so greebles never merge into clumps; embedded 25% so connectivity passes), bolt_ring (the 'this part is FASTENED' cue; clean=True de-n-gons caps). ORDER MATTERS: bevel_sharp LAST so boolean edges get beveled; bevel merges its own doubles (clamped segments collapse verts — found by topology_gate on this kit's first build). Embed-attachment overlaps are documented-intentional; cite this entry at Gate 9.
- verified_by: _tmp/detailkit/hatch_contact.png + _tmp/detailkit/build_hatch.py (gates all green, Blender 5.1.2 headless)
