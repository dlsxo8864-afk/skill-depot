# Proportions — research before you build (the WORKFLOW)

WHY: building a recognizable real-world object (a sword, a chair, a car, a
rifle, a streetlight) from your prior is how you get something that "looks
slightly off in scale / edge & point placement." You don't have reliable
metric intuition for real objects. Fix it the same way the rest of this skill
fixes blind spots: get external ground truth first, form an explicit held
belief, build to it, then render + judge.

## Workflow (do this BEFORE geometry, for any representational object)
1. **Find 5–10 references online.** Prefer concrete numbers: maker/spec sheets,
   Wikipedia infoboxes, standards, catalog dimensions. Don't work from one
   source or from memory of one.
1b. **Fetch a 2D VISUAL reference too** (numbers ≠ silhouette). Pull a side
   orthographic / blueprint (best), plus a front/top ortho and a 3/4 photo if
   available, with `scripts/fetch_reference.py --key "<obj>" --url SIDE=<url> …`
   (validates the download is really an image, stores to `references/refs/` +
   the `refs` bucket). Then VIEW each with the Read tool and read silhouette,
   overhangs, and feature x-positions OFF the image — this is what kills the
   "edge & point placement slightly off" error that numbers alone leave. See
   SOP-00 Gate 1.55.
2. **Synthesize a HELD BELIEF** — a small table of the key dimensions/ratios
   (absolute units + ratios to a primary dimension). Note the spread; pick a
   representative value, not an outlier. Cross-check it against the 2D ref.
3. **Record it to the object's OWN file** (see below), so the catalog doesn't
   bloat and the next build loads only what it needs.
4. **Build to the held belief** with blendkit; keep the numbers in the scene
   script as comments so the geometry is auditable against the belief.
5. **Render + inspect + judge by eye.** If the render contradicts the belief,
   the belief (or the build) is wrong — fix and update the entry.

Same anti-poison rule as LEARNINGS: only record a belief you actually sourced;
flag a single-source guess as provisional.

## Where the per-object data lives (NOT in this file)
Object dimensions/anatomy/build learnings live in **one file per object** under
`references/objects/<slug>.md`, indexed by `references/objects/INDEX.md`.
Material/texture learnings live in `references/materials/<slug>.md`
(`references/materials/INDEX.md`). This keeps each catalog from bloating as
learnings accumulate — a build reads the INDEX, then only the relevant entry.

**Routing is mechanical** — don't hand-edit + risk forgetting the index. Use:
```
python scripts/record_learning.py --kind object  --key "sword" \
    --hook "<one-line>" --title "<t>" --body "<learning>" --verified-by "<render>"
python scripts/record_learning.py --kind material --key "polished steel" ...
```
New key → creates the file + adds one index line. Existing key → appends a dated
entry (index line stays single). Record ONLY after a render/inspect verified it.

For what's already catalogued, read `objects/INDEX.md` and `materials/INDEX.md`
(the catalogs grow — don't rely on a list here).
General (not per-object) recipes stay in `references/rendering-metal.md`.
