---
key: rotated-primitive-scale-axis
kind: failure
---
# rotated-primitive-scale-axis — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'rotated-primitive-scale-axis'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — the 'wing eyes' — object scale is in LOCAL (pre-rotation) axes
SYMPTOM: anime eye discs rendered as huge vertical dark 'wings' flanking the face. CAUSE: a Z-axis cylinder has its CIRCLE in the local XY plane (radii on local X and Y) and is thin on local Z. I made a disc face +Y by rotating 90deg about X, then set obj.scale=(rx, 1.0, rz) intending (width, thickness, height). But object SCALE is applied in LOCAL axes BEFORE the rotation, so local Y was the OTHER circle radius (which the X-rotation maps to world Z = height) and I left it at 1.0 -> every disc was 1.0 unit TALL. Correct: scale the two CIRCLE axes (local X,Y) to (width, height) and leave local Z (the thin axis) = 1.0 -> obj.scale=(rx, rz, 1.0). DETECT: only the eye disappeared / went wing-shaped; a side render showed flat plates. RULE: when you scale a primitive you also rotate, reason in the primitive's LOCAL axes at SCALE time (pre-rotation), not the world axes you want at the end; or bake the scale into the bmesh verts before rotating.
- verified_by: _tmp/anime/anime_eye.png (proper ellipse eyes after scale=(rx,rz,1.0))
