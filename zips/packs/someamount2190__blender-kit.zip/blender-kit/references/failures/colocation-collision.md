---
key: colocation-collision
kind: failure
---
# colocation-collision — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'colocation-collision'; record new learnings only after a render/inspect
verified them.

## 2026-07-05 — Co-location collision: two part families placed at identical azimuths/stations
Thunder-mace round 1: rune chips (r 0.074-0.078) and gilt ridges (r 0.072-0.084) were BOTH placed at azimuths k*60+30 on the same core — every emissive chip sat radially inside a ridge, invisible from all cameras. The critic reported 'rune band absent'; the engineer found the collision by comparing the two loops' azimuth formulas. This is a THIRD evidence-failure class after (1) camera-side occlusion (magegun lock) and (2) sub-pixel size (destroyer): the part is present, correctly sized, and unoccluded by staging — it is embedded in a sibling. GUARD: when two decorative families ring the same host part, offset their azimuth formulas (k*60 vs k*60+30) AND check radial bands do not nest; a cheap code check is asserting the two loops' (azimuth, radial-extent) tuples do not overlap. Related: the magegun 'flush inlay + strength 1.5' rule OVER-APPLIED here — inlay assumes an unobstructed face; when the band sits between tall neighbors, chips must sit PROUD (5mm) and hotter (s3.0).
- verified_by: _tmp/thundermace round-2 renders: rune band reads after ridge shorten + proud chips
