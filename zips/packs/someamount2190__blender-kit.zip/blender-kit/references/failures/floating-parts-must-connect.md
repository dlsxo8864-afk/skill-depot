---
key: floating parts must connect
kind: failure
---
# floating parts must connect — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'floating parts must connect'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — strict connectivity rule
RULE (per user + community 'loose/disconnected geometry'): when making ONE model, ALL parts must be CONNECTED -- each part must touch or overlap at least one other part. A visible GAP is a failure even if the part is 'close'. DETECT: inspect.failure_scan(require_connected=True, connect_eps=0.02) -> floating = parts whose AABB is >2 cm from every other part. It correctly passes FACE contact (stacked boxes/chair) and POINT contact (a branch base inside the trunk), and fails any real gap (a part 0.1 m away is flagged). Use require_connected=False only for scenes of deliberately-separate props. FIX a floater: move/extend it to actually meet the parent SURFACE (over-insert slightly, e.g. a branch base at the trunk centreline so it overlaps), not to a phantom near-point. LIMIT: AABB-based -> a floater whose bbox overlaps another's despite a mesh gap can slip; for those, judge by eye / use closer eps.
- verified_by: _tmp/test_failscan.py — CLOSE-but-not-touching flagged; touching/face-contact pass; pine v4 285 parts CLEAN
