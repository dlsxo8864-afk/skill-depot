---
key: gap-fixed-by-stretching-connector
kind: failure
---
# gap-fixed-by-stretching-connector — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'gap-fixed-by-stretching-connector'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — user caught a giraffe: gap-closing direction matters
SYMPTOM (user, one glance: 'why you made a giraffe'): the armor's helmet-to-chest gap was closed by STRETCHING the bevor into an 18.5cm cone -> the figure grew a tapering neck tower and the silhouette read as a giraffe. Three cold critics and two engineers had reviewed adjacent geometry without naming it — a human user saw it instantly. CAUSE: when part A floats above part B, there are two fixes: stretch the connector, or MOVE A DOWN. Stretching a connector changes the silhouette's proportional story (necks, stilts, towers); lowering the upper assembly preserves it. Anatomy connectors (necks, wrists, ankles) have canonical LENGTHS — a bevor is a short throat plate (~10cm), never a cone. DETECT: after any gap-closing fix, re-check the SILHOUETTE read of the whole assembly, not just the closed gap. FIX applied: bevor back to 10cm, entire helmet assembly (dome/visor/slit/lip/rondels/comb/peg/rivets) dropped 7cm as a unit.
- verified_by: _tmp/knight-armor/armor_contact.png post-fix (head sits between the pauldrons; human proportions restored; all gates green)

## 2026-07-04 — round 2 of the giraffe: length was not the root cause — WIDTH RATIO was
The first fix (shorten bevor, drop helmet 7cm) still read GIRAFFE (user round 2 + asked 'did the engineer actually get measurements for the neck?' — answer: NO, nobody derived it from anatomy). MEASURED root cause: helmet half-width 0.094 < neck-cone top 0.098 — the head NEVER FLARED WIDER THAN THE NECK, and 14.5cm of narrowing taper column stood exposed between chest and helmet: a head narrower than its neck IS a giraffe at ANY neck length. THE ANATOMICAL DATUM (should have been in the plan's WHAT): (1) helmet exterior ~0.23-0.26 wide vs neck ~0.13-0.15 — head/neck width ratio ~1.7; (2) chin sits ~4cm above the shoulder line; (3) in armor the helmet SKIRT OVERLAPS DOWN OVER the gorget — zero exposed neck column. Fix: dome r 0.098->0.115 seated at z 1.65 (skirt 1.53, pauldron top 1.51), bevor a 9cm plate tucked INSIDE the helmet silhouette. RULE: junction fixes need the joint's canonical MEASUREMENTS (width ratios + overlap direction), not just gap closure; and silhouette failures are ratio failures more often than length failures.
- verified_by: _tmp/knight-armor/armor_contact.png (head wider than throat, helmet seated between pauldrons; gates green)
