---
key: community baseline checklist
kind: failure
---
# community baseline checklist — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'community baseline checklist'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — community 3D-modeling failure baseline (consult + extend every build)
Sourced from the 3D community (selfcad '11 common mistakes'; sculpteo non-manifold; Blender 5.1 manual Clean Up; womp/medium beginner-mistake guides). RULE: every model build INITIATES failure research -- consult this baseline (references/failures/INDEX.md) AND web-search the community for THIS object's known modeling pitfalls (e.g. 'common mistakes modeling a <X>'), then add any new ones. BASELINE failure modes -> the skill check that catches each: (1) FLOATING / loose / disconnected geometry -> inspect.failure_scan floating (STRICT: must connect, see floating-parts-must-connect). (2) N-GONS / bad topology / poles -> inspect.topology_report + build.cleanup/clean=True. (3) NON-MANIFOLD (holes, edges w/ 3+ faces) -> topology_report nonmanifold_edges. (4) FLIPPED/INCONSISTENT NORMALS -> build.cleanup recalc_face_normals (recalc outside). (5) DUPLICATE/DOUBLE verts -> topology_report doubles / build.cleanup merge. (6) WRONG SCALE (breaks realism instantly) -> research proportions (references/proportions.md) + transform helpers. (7) INTERSECTING geometry -> inspect.scene_report overlaps. (8) DETAIL/SUBDIVIDE TOO EARLY -> SOP greybox-first (P5). (9) UNAPPLIED TRANSFORMS -> transform.apply_transforms before export. SHIP GATE: run inspect.failure_scan (+ topology_report) before calling any build done.
- verified_by: community research 2026-06; mapped each to an existing skill check; failure_scan/topology_report unit-tested
