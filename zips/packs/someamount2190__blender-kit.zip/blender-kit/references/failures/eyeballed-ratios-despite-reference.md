---
key: eyeballed-ratios-despite-reference
kind: failure
---
# eyeballed-ratios-despite-reference — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'eyeballed-ratios-despite-reference'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — had the scaled reference AND check_ratios, still eyeballed -> 'near but off'
SYMPTOM (user feedback on the battleship): 'couldn't nail the ratios but near the original and without ngons'. Concretely: main barrels 0.14*L vs real ~0.074*L (~1.9x too long); barbettes ~0.53*beam vs ~0.33; funnel ~0.45*beam dia vs ~0.30; tower too chunky. CAUSE: I fetched a SCALED profile+plan reference and then sized parts from PRIOR/eyeball anyway. I ran check_alignment (symmetry on Y) but NOT check_ratios — the one tool built to catch this. DETECT: a model that reads as the object but feels 'off' is almost always unmeasured part-to-part ratios (alignment can be perfect while every size is wrong). FIX/RULE: when a scaled ortho/profile/plan reference exists, MEASURE the key spans on it (pixel ratios are fine) and convert to part-to-part RATIOS against a primary dim (barrel/L, turret-width/beam, superstructure-height/L, funnel-dia/beam, freeboard/L); encode them as inspect.check_ratios specs and VERIFY before ship. Gate 1.5 already says record ratios — this is the failure of not DOING it. Alignment != ratio; run BOTH.
- verified_by: user feedback on _tmp/warship (ratios off); reference refs/battleship__profile.jpg was scaled and unmeasured
