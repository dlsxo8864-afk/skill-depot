# Failure learnings — index

One line per failure; open the linked file for the detail.

- [geometry below ground](geometry-below-ground.md) — parts dip below the floor (drooping branches, low-placed props); detect inspect.failure_scan below_ground; cap height or scan+remove
- [disconnected procedural branches](disconnected-procedural-branches.md) — recursive grow() attaches children on a STRAIGHT line but make_branch limbs CURVE -> sub-branches float off the parent
- [skipping inspect on organic models](skipping-inspect-on-organic-models.md) — META: I disabled scene_report on the tree ('overlaps all intentional') and shipped ground-clipping + floating branches
- [community baseline checklist](community-baseline-checklist.md) — BASELINE of common 3D-modeling failures from the community + which skill check covers each; RESEARCH per build
- [floating parts must connect](floating-parts-must-connect.md) — RULE: every part connects (touch/overlap) -- a gap = floating even if 'close'; inspect.failure_scan(require_connected=True)
- [detached sub-assembly passes connectivity](detached-sub-assembly-passes-connectivity.md) — a detached ISLAND (parts touching each other but not the body) passed failure_scan; needs GLOBAL single-component check, not pairwise
- [trusting the scan over the eye](trusting-the-scan-over-the-eye.md) — META: I shipped visible defects because a CLEAN failure_scan let me skip looking closely; a green check is NOT proof -- render tight close-ups of joints
- [part-juts-past-a-body-break](part-juts-past-a-body-break.md) — a face detail placed across a hood/fender break pokes out past the receding surface; keep it on the flat plane below the break, flush in depth
- [box-ring-checkerboard](box-ring-checkerboard.md) — approximating a smooth ring/torus with N rotated boxes makes a chaotic checkerboard; invert to solid-face + recessed windows
- [procedural-texture-scale-vs-object-size](procedural-texture-scale-vs-object-size.md) — a procedural texture tuned for a big object reads as smooth/featureless on a small one — scale the texture to the object
- [waterline-floor-false-positive](waterline-floor-false-positive.md) — failure_scan below_ground flags a ship hull (keel under z=0); the 'floor' of a floating object is its KEEL, not the waterline
- [eyeballed-ratios-despite-reference](eyeballed-ratios-despite-reference.md) — had a scaled ortho reference AND check_ratios, still sized parts from prior/eyeball -> model 'reads right but feels off' (barrels 1.9x too long); MEASURE spans off the image and run check_ratios — alignment != ratio
- [rotated-primitive-scale-axis](rotated-primitive-scale-axis.md) — scaling a rotated primitive on the wrong LOCAL axis (object scale is pre-rotation) -> wildly wrong shape; here flat discs became 1.0-tall strips
- [features-on-far-side-from-camera](features-on-far-side-from-camera.md) — built the face on +Y but cameras sat on -Y -> every 'front' shot was the BACK of the head; isolate the part to diagnose
- [skipped-design-phase](skipped-design-phase.md) — tempted to jump straight to geometry with only proportions researched ('I know what it looks like') -> broken anime head; research the HOW + failure modes and fill the BUILD PLAN first — design_gate/preflight now block
- [feature-parts-as-afterthought-blobs](feature-parts-as-afterthought-blobs.md) — the body/hull eats the design budget while the identity parts (island, aircraft, turret) ship as scattered single-primitive blobs; design feature parts FIRST (plan §5) + place them by a stated rule (check_placement/check_clearance)
- [gap-fixed-by-stretching-connector](gap-fixed-by-stretching-connector.md) — closing a vertical gap by stretching the connecting part = giraffe neck / stilt read
- [dark-foreground-undersides-port-view](dark-foreground-undersides-port-view.md) — huge pure-black shapes in close-up renders = foreground undersides of an overhead surface; diagnose with object-ID emissive pass
- [colocation-collision](colocation-collision.md) — feature invisible: built INSIDE another part at the same stations (worse than camera occlusion)
- [overexposed-renders](overexposed-renders.md) — exposure now GATED: clip-fraction metric (mean-lum can't catch it; Filmic ceiling defeats naive cuts)
