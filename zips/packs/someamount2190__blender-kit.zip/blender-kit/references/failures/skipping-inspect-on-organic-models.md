---
key: skipping inspect on organic models
kind: failure
---
# skipping inspect on organic models — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'skipping inspect on organic models'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — don't throw out ALL checks on organic builds
ROOT MISTAKE: a dense organic crown produces hundreds of INTENTIONAL overlaps + floats, so I skipped inspect.scene_report entirely and 'judged by eye' -- and missed real failures (below-ground, disconnected, lost branches). LESSON: skipping the NOISY overlap/float report is fine, but run the TARGETED inspect.failure_scan (below_ground / isolated / degenerate) which has almost no false positives on organic models. The right move is a narrower check, not NO check. Build the failure checklist into the SOP/preflight for procedural/organic builds.
- verified_by: _tmp/pine/pine_v4 — failure_scan surfaced 23 ground-clips the by-eye pass missed
