---
key: geometry below ground
kind: failure
---
# geometry below ground — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'geometry below ground'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — below-ground geometry
SYMPTOM: geometry pokes through/under the ground plane (pine had 23 branches below z=0). CAUSE: drooping/long elements placed low reach below the floor; no one checks because the full overlap report is noisy/skipped on organic models. DETECT: inspect.failure_scan(floor_z=0) -> below_ground list (min world vertex z < floor). FIX: (a) length-cap by available height: reach ~= length*(sin|elev|+curve); if reach > z - clearance, scale length down; (b) SAFETY NET -- run failure_scan after build and remove/shorten any straggler the estimate missed (the cap is an estimate; the scan is exact). Always run failure_scan before shipping ANY build.
- verified_by: _tmp/pine/pine_v4 — failure_scan went 23 below-ground -> CLEAN after cap + scan-remove
