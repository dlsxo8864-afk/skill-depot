---
key: dark-foreground-undersides-port-view
kind: failure
---
# dark-foreground-undersides-port-view — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'dark-foreground-undersides-port-view'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — Black-shape diagnosis ladder (verified on the C-130 build)
SYMPTOM: large pitch-black shapes in specific close-up views that survive EVERY lighting/material/geometry change; whole-scene views clean. ROOT CAUSE (C-130 case): the detail camera sat low on the port side of a high-wing aircraft; the port OUTER wing panel + OUTBOARD nacelle sat in the FOREGROUND between camera and subject, showing their UNDERSIDES, whose entire light hemisphere is blocked by the wing directly above them (sun/sky/fills all geometrically excluded; ground bounce insufficient). They are not artifacts — they are correctly-rendered unlit foreground surfaces, misread as defects because they project onto the subject. DIAGNOSIS LADDER (in order, each step cheap): (1) suspect stale renders — check mtimes; (2) numeric mesh probe (manifold/normals/material slots/custom split normals); (3) raycast through the black pixels (names the first-hit object, but beware: your NDC guess can hit the neighbor); (4) hide-one-suspect renders (bisect by object); (5) THE DECISIVE TOOL: object-ID emissive pass — assign every mesh a unique hue emission and render the exact failing view; emission bypasses lighting so geometry/visibility questions separate cleanly from light questions, and the failing pixels name their owner; (6) only then reason about light-path geometry (check the actual surface normal vs each lamp's incidence VECTOR — 3 of my 5 added lamps had negative dot products). FALSE THEORIES BURNED (do not repeat): smooth-shading normals, anisotropic-scale normals (real bug, but not this symptom), missing caps, interpenetration occlusion, grazing Fresnel mirror, view-transform crush — each 'fix' changed nothing because the true cause was CAMERA-RELATIVE. FIX: reframe the detail view (subject-first framing; shoot from the quarter that keeps overhead-surface undersides out of frame), not more lamps.
- verified_by: _tmp/c130/probe_id.png (object-ID pass) + c130det_gear.png before/after reframe (black gone from starboard quarter)
