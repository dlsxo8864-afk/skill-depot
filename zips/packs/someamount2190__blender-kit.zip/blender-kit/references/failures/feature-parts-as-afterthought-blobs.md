---
key: feature-parts-as-afterthought-blobs
kind: failure
---
# feature-parts-as-afterthought-blobs — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'feature-parts-as-afterthought-blobs'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — the body ate the design budget; the identity parts were random blobs (architecture fix)
SYMPTOM (user, carrier v1): 'you prioritize the design of the body' — the hull/deck were carefully built but the IDENTITY/FUNCTION parts were afterthoughts: the island was a tapering ziggurat and the aircraft were delta-slab blobs scattered with no logic. The thing a viewer/expert actually looks at was the weakest part. CAUSE: nothing in the architecture forced the FEATURE PARTS to be (a) designed to a real standard and (b) placed by a functional rule; the SOP optimised the mass. FIX (enforced, not exhorted): (1) BUILD PLAN now has a REQUIRED section 5 FEATURE PARTS — identify the identity/function parts, give EACH a real part-breakdown design (not a blob) + a PLACEMENT LOGIC (functional rule); design_gate blocks until it's filled. (2) new inspect.check_clearance(zone, prefixes) enforces placement logic via keep-out zones (e.g. parked aircraft must clear the landing area — it caught a jet on the strip). (3) SOP-06 details FEATURE PARTS FIRST; SKILL.md hard rule 0b. DEMONSTRATED (carrier v2): aircraft = real F/A-18 airframe (nose+fuselage+swept wings+TWIN CANTED tails+intakes+canopy, ~10 parts), island = blocky fore-aft Nimitz tower (bridge window band+radar arrays+funnel+mast+antennas); spotting = jets clear of the landing keep-out, noses outboard (check_clearance OK); island starboard (check_placement). RULE: identify the feature parts FIRST, design them to a real standard, place them by a stated functional logic you VERIFY — the body only supports them.
- verified_by: _tmp/carrier/carrier_hero.png + carrier_island.png + carrier_top.png (designed island + airframes, spotted by logic); check_clearance caught + then cleared the landing-area intruder
