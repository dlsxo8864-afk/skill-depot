---
key: disconnected procedural branches
kind: failure
---
# disconnected procedural branches — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'disconnected procedural branches'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — grow() vs curved limbs = floating sub-branches
SYMPTOM: sub-branches float in space, not touching the branch they grow from (the 'branches not connected to the tree' bug). CAUSE: phyllotaxis.grow() computes child attach points as pos + dir*length*f -- a STRAIGHT line -- but make_branch builds a limb that arches/droops internally, so the child base sits ~0.3 m off the real curved limb. DETECT: failure_scan isolated catches FULLY-detached pieces, but a small gap in a DENSE crown won't trip it (AABB still touches neighbours) -- so this one is mostly eye + this recorded note. FIX: keep limbs used with grow() NEARLY STRAIGHT (make_branch droop ~0.1; the visual droop comes from the branch DIRECTION/elev, not internal curve) AND attach children near the base (child_start ~0.3) where straight ~= curved. (Proper fix if you need curved limbs: sample the actual limb curve for attach points.)
- verified_by: _tmp/pine/pine_v4 — near-straight limbs + child_start 0.3 reconnected the sub-branches
