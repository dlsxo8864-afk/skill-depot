---
key: waterline-floor-false-positive
kind: failure
---
# waterline-floor-false-positive — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'waterline-floor-false-positive'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — a hull is SUPPOSED to be below the water plane
SYMPTOM: failure_scan reported BELOW-GROUND: Hull on a battleship floating on a sea plane at z=0. CAUSE: below_ground defaults floor_z=0; a ship's keel is legitimately ~0.6 below the waterline, so the check mis-fires. This is a category the check can't know on its own: for a FLOATING (or buried, or airborne-with-ground-below) object, z=0 is not the floor. FIX: pass floor_z = the true lowest legit point (the keel, e.g. -0.75) to failure_scan; then real strays below the keel still flag. RULE: failure_scan's floor_z is an assumption (z=0) — override it whenever the scene's datum isn't the ground (waterline, tabletop at a height, terrain). Don't 'fix' the geometry to satisfy a wrong default.
- verified_by: _tmp/warship/warship_broadside.png (hull correctly below waterline; scan CLEAN with floor_z=-0.75)
