---
key: trusting the scan over the eye
kind: failure
---
# trusting the scan over the eye — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'trusting the scan over the eye'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — a clean check is not a substitute for looking
ROOT MISTAKE (user caught it, I didn't): I trusted a CLEAN failure_scan and an auto-framed wide close-up, and shipped a detached suppressor + a rear-sight void. The skill's WHOLE premise is 'don't trust the metric, VIEW it' and I violated it on my own detail pass. LESSON: for any DETAILED / multi-part model, render TIGHT close-ups FRAMED ON THE CONNECTION POINTS (every muzzle/sight/joint), not just a hero/wide shot, and actually scrutinise them. Checks have blind spots (AABB connectivity, miscalibrated eps); the eye is the backstop. SOP-06 Pass-N already says 'render a CLOSE-UP framed on that part' -- DO IT, and look at the seams, not the silhouette. A green failure_scan means 'no detected failure', not 'correct'.
- verified_by: _tmp/m14 — close-ups cu_muzzle.png/cu_rear.png exposed what the CLEAN scan missed
