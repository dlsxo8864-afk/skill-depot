---
key: overexposed-renders
kind: failure
---
# overexposed-renders — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'overexposed-renders'; record new learnings only after a render/inspect
verified them.

## 2026-07-06 — Overexposure gate: clip_fraction in render_still (calibrated twice)
Exposure failures (thundermace 320W key, zombie product-shot flatness, C-130 whites) previously had NO gate — only VIEW caught them. Now render_still/canonical_views/detail_views compute clip_fraction and set error when >0.05, flowing through the render_errs checks every build already gates on (zero build-script changes). CALIBRATION STORY (both steps mandatory for any future image metric): (1) mean luminance was the intuitive metric and is USELESS — shipped-PASS renders legitimately span 0.12-0.86 while blowouts sit inside the band; only 'fraction of blown-white pixels' separates. (2) the naive 0.98 white cut NEVER fires under Filmic — its shoulder asymptotes ~0.9725; a 20x-key blowout measured clip=0.0. Cut recalibrated to min-channel>0.93: deliberate blowout = 0.245-0.36 of frame, ALL healthy builds <=0.026 (incl. glow-heavy mace/magegun), and the C-130's 0.12-0.36 = a real pre-discipline blowout the gate retroactively catches (it predated the exposure lessons). Override: full-frame hero-emissive close-ups legitimately exceed 5pct — pass clip_thresh=None/higher, deliberately. A/B verified: _tmp/lumgate/verify_gate.py (sane 60W error-free; 1200W key -> 'overexposed' error).
- verified_by: _tmp/lumgate A/B GATE_VERIFY PASS + 282-render shipped-set audit (8 flagged, all justified)
