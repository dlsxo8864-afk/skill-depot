---
key: procedural-texture-scale-vs-object-size
kind: failure
---
# procedural-texture-scale-vs-object-size — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'procedural-texture-scale-vs-object-size'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — Voronoi bark looked like putty on a 5cm bonsai trunk
SYMPTOM: the trunk/nebari rendered as smooth pale putty in close-up despite using material.bark (Voronoi plates). CAUSE: bark scale=7 was tuned for a ~1m tree trunk; on a ~5cm bonsai trunk that puts <1 cell across the trunk => no visible plates. Procedural textures using Object/Generated coords have an ABSOLUTE feature size; shrink the object and the features vanish (or on a huge object they turn to noise). DETECT: invisible in the wide/hero shot, obvious in the SEAM close-up (render seams not silhouette). FIX: scale the texture to the object — bumped bark scale 7->28 for the small trunk and the plates/furrows read. RULE: when reusing a procedural material across very different object sizes, re-tune its scale to feature-size/object-size, don't assume the default transfers.
- verified_by: _tmp/bonsai/bonsai_nebari.png before(putty)->after(textured bark plates)
