---
key: skipped-design-phase
kind: failure
---
# skipped-design-phase — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'skipped-design-phase'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — jumped to geometry with no design -> broken anime head (architecture fix)
SYMPTOM: a 3D anime head came out broken (flat hair shards poking out, melty non-concentric eyes, a highlight stuck on the cheek) and I over-claimed it 'reads as anime'. ROOT CAUSE was process, not geometry: I researched only PROPORTIONS (the WHAT) and skipped the CONSTRUCTION METHOD (the HOW — how anime hair/eyes/faces are actually built) and the FAILURE research, and wrote no plan. The architecture ALLOWED it: SKILL.md's 'mandatory loop' started at BUILD; design was demoted to optional prose (Hard rule 0 = proportions only); nothing produced a required artifact or blocked geometry. ARCHITECTURE FIX (so it can't be skipped): (1) DESIGN is now step 0 of the mandatory loop in SKILL.md; (2) Hard rule 0 now demands HOW + FAILURES + a PLAN, not just proportions; (3) new SOP-07 'design-first' with gates D0-D6 producing a filled BUILD PLAN (WHAT/VISUAL/HOW/FAILURES/DECOMPOSE); (4) scripts/plan_build.py scaffolds the plan; (5) blendkit/plan.design_gate() fails-closed on any unfilled section and rides on preflight.check(plan_path=...) which ABORTS the render — verified: unfilled plan -> preflight ok=False. RULE: research the HOW and the FAILURE MODES and commit a plan BEFORE geometry; proportions alone are not design. For a representational/multi-part/character/organic build, scaffold the plan FIRST and thread plan_path through preflight so a regression re-blocks.
- verified_by: plan_build.py --check BLOCK->PASS; blender preflight.check(plan_path=unfilled) ok=False, no plan_path ok=True
