---
key: part-juts-past-a-body-break
kind: failure
---
# part-juts-past-a-body-break — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'part-juts-past-a-body-break'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — lamp protruded past the receding hood (caught by the SEAM close-up, not the scan)
SYMPTOM: a headlight box looked tacked-on like a peg in the front seam close-up, sticking ~0.2m forward of the bodywork above it.
CAUSE: the box spanned the HOOD BREAK. The body front face is vertical only up to z=0.58; above that the hood slopes BACK (x 2.35 -> 1.85). The lamp's top (z 0.625) sat in front of the hood, which had already receded to x~2.16 there, so the lamp poked out. A part is only flush on the plane it's mounted to; if it crosses an edge where the surface turns away, the part stays put and the body recedes behind+past it.
DETECT: failure_scan/topology/alignment were ALL GREEN (it's connected, manifold, on-axis) — they DON'T model surface direction. The tight SEAM close-up (the rule: render seams not silhouette) showed it instantly.
FIX: keep face details (lamps, grille) BELOW the body break, entirely on the vertical/flat plane, and flush in depth (front of part == front of the plane it sits on). Re-check the seam by eye.
- verified_by: _tmp/car/car_face.png before/after (protruding -> flush lens)
