---
key: detached sub-assembly passes connectivity
kind: failure
---
# detached sub-assembly passes connectivity — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'detached sub-assembly passes connectivity'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — connectivity must be ONE component (not 'each part touches something')
WHAT SHIPPED: an M14 flash suppressor visibly DETACHED from the barrel (5mm gap) + a rear-sight void -- and failure_scan said CLEAN. TWO root causes: (1) the connectivity check asked 'does each part touch SOME other part?' -- the suppressor touched the SLOT box I put on it, so the suppressor+slot ISLAND passed even though it touched nothing on the body. Pairwise-neighbour != connected model. FIX: union-find over the AABB-proximity graph -> the model must be ONE connected component; flag every part in a smaller DETACHED island (main = largest by volume). (2) connect_eps was 2cm -> a clearly-visible 5mm gap counted as 'connected'. FIX: default 3mm. DETECTION now: failure_scan flags 'FlashSuppressor, SuppSlot' as FLOATING. GEOMETRY fix: overlap the suppressor onto the barrel; rebuild the rear sight as one solid block. RULE: for assemblies, EVERY part must chain back to the body, and small gaps are gaps.
- verified_by: _tmp/m14 — was CLEAN(false) -> now FLOATING(FlashSuppressor,SuppSlot) -> overlap-fix -> CLEAN(true); cu_muzzle/cu_rear confirm by eye
