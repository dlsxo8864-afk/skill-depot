---
key: box-ring-checkerboard
kind: failure
---
# box-ring-checkerboard — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'box-ring-checkerboard'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — a rotated-box ring is not a torus (rim came out a snowflake)
SYMPTOM: a rim 'ring' built as 20 boxes rotated around the axle (each also rotated 45deg) rendered as a chaotic checkerboard/snowflake, nothing like a smooth alloy lip.
CAUSE: a ring of discrete rotated boxes overlaps itself irregularly; square cross-sections at 45deg interleave into diamonds. Boxes can't tile a smooth circular band.
DETECT: failure_scan/topology were GREEN (it's connected, manifold) — purely a VISUAL defect, caught only by the wheel SEAM close-up.
FIX: don't replicate a curved feature with a box ring. INVERT the problem: build a SOLID metal rim-face cylinder and punch the look you want with a few dark RECESSED WINDOWS (the solid between windows becomes the spokes). General rule: for round detail without booleans, model the POSITIVE solid + a handful of negative-reading insets, not a ring of primitives. If a true ring is needed, use a real radial mesh (cylinder/cone), not boxes.
- verified_by: _tmp/car/hd_wheel.png before (snowflake) -> after (clean 5-spoke alloy)
