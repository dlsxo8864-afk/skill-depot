---
key: features-on-far-side-from-camera
kind: failure
---
# features-on-far-side-from-camera — failure learnings

One file per failure (keeps the catalog from bloating). Consult this
BEFORE building 'features-on-far-side-from-camera'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — rendering the back of the head (camera/feature side mismatch)
SYMPTOM: 'front' renders showed a blank head with dark bits only at the silhouette edges. CAUSE: the face features were placed on +Y but all 4 cameras (and the key light) were at -Y looking +Y -> they see the -Y hemisphere (the BACK); the +Y features faced away and only poked past the silhouette edges. Compounded with the buried/wing eyes it looked like garbage. FIX: put the camera + key light on the SAME side as the features (here +Y). DIAGNOSIS METHOD THAT WORKED: isolate — toggled the hair OFF (a HAIR flag) and rendered just head+eyes; that exposed both the orientation bug and the buried-eye depth at once. RULE: when a render is inexplicably wrong, ISOLATE (render one sub-assembly alone) and sanity-check the camera/feature/light HEMISPHERE before tweaking values.
- verified_by: _tmp/anime/anime_front.png (face visible after moving cameras+lights to +Y)
