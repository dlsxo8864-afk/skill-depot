# Rendering metal & swords — held belief (recipe)

Researched recipe for making metal (esp. blades) read as polished metal. Sources:
TurboSquid "Creating and Rendering Realistic Metal Materials"; ReelMind /
D5Render photoreal-metal guides; Polycount katana metalness thread; search
aggregate. Applied + verified on the arming-sword render (`_tmp/sword/`).

## Material (Principled BSDF)
- **Metallic = 1.0** for raw metal. (Insulators/coatings would be < 1.)
- **Roughness:** polished steel **0.1–0.3** (used 0.14 for the blade); satin/brushed
  0.3–0.5; matte/corroded 0.6+. Brass fittings ~0.28.
- **Vary roughness** for realism (procedural noise): lower+lighter on bulges,
  higher+darker in grooves. (Blockout can skip; a single low value still reads.)
- **Anisotropy** is the signature BLADE glint: set `anisotropic` ~0.5–0.8 so the
  highlight STRETCHES along the blade (light hitting a brushed/honed surface
  reflects as a streak). Ideal control needs a tangent aligned to the blade
  length; the default mesh tangent gets most of the way. (Used 0.7 via
  `compat.principled_set(bsdf, anisotropic=0.7)`.)

## Lighting — metal shows its ENVIRONMENT, not just "light"
A metal surface is mostly a mirror; it looks like whatever it reflects. So you
light the REFLECTIONS:
- **Best:** a studio HDRI (softboxes / large windows) → big, distinct specular
  highlights that emphasize smoothness. (No HDRI file here — build the studio.)
- **Studio rig used (works without an HDRI):**
  - **Key softbox** — a soft AREA light off to one side.
  - **Streak softbox** — a LONG THIN rectangular AREA light overhead, long axis
    ALONG the blade → reflects as a continuous bright streak down the blade =
    the polished-blade money shot. This is the single most important light.
  - **Fill** — large, dim AREA opposite the key (lifts shadow side).
  - **Rim** — small bright AREA behind → lights the edges/point.
- **Render in Cycles** (or EEVEE with `scene.eevee.use_raytracing=True`) so the
  blade actually reflects the softboxes. EEVEE-flat = dull grey metal.
- **Grazing camera angle** intensifies reflections (Fresnel) — shoot a bit low/
  along the blade rather than straight down.

## Known limitation — the "dark dramatic floor" is NOT just dimmer lights
Trying to get bright-blade-on-black-floor with broad softboxes FAILS: large soft
lights illuminate the big floor plane, and Blender's default AgX view transform
lifts even a 0.035-albedo floor to mid-grey; the floor's glossy term also
reflects the bright softboxes. A clean light-gradient studio backdrop is what you
actually get (and it's a legit hero look). For a true dark floor you need a
DIFFERENT recipe, not dimmer lights:
- flag/gobo the lights or use a tight SPOT so the floor gets almost none, or
- switch the view transform to **Standard** (`scene.view_settings.view_transform
  = 'Standard'`) so darks stay dark, or
- composite (mask the subject, darken the bg), or
- make the floor near-pure-black (albedo ~0.01) AND keep all light off it.

## Quick checklist for a metal hero shot
1. Metallic 1.0, roughness 0.1–0.3, anisotropic ~0.7 (blades).
2. Cycles (or EEVEE raytracing on).
3. Long overhead strip softbox along the blade + soft key + dim fill + rim.
4. Grazing-ish camera; frame tight.
5. Render → VIEW → adjust the streak light's position until it runs the blade.
