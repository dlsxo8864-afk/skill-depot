---
key: battleship
kind: reference
---
# battleship — reference learnings

One file per reference (keeps the catalog from bloating). Consult this
BEFORE building 'battleship'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — fetched 2D reference
WWII battleship side profile: North Carolina-class recognition drawing (same 2-A-1 superfiring layout + tower as Iowa); HMS Nelson high-res profile for hull sheer + superstructure/turret/mast anatomy. Build hull via lofted plan-shaped stations against these.
- profile: https://upload.wikimedia.org/wikipedia/commons/7/7e/North_Carolina_class_battleship_recognition_drawings.jpg
  -> references\refs\battleship__profile.jpg
- detail: https://upload.wikimedia.org/wikipedia/commons/a/a7/HMS_Nelson_%281931%29_profile_drawing.png
  -> references\refs\battleship__detail.png
- verified_by: (VIEW the image to verify it is a usable reference)
