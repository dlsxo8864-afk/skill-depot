---
key: giraffe
kind: reference
---
# giraffe — reference learnings

One file per reference (keeps the catalog from bloating). Consult this
BEFORE building 'giraffe'; record new learnings only after a render/inspect
verified them.

## 2026-07-04 — fetched 2D reference
adult giraffe standing/walking profiles for proportion measurement (build plan WHAT)
- side-standing: https://upload.wikimedia.org/wikipedia/commons/9/9e/Giraffe_Mikumi_National_Park.jpg
  -> references\refs\giraffe__side-standing.jpg
- walking-profile: https://upload.wikimedia.org/wikipedia/commons/e/e0/Giraffa_camelopardalis_angolensis.jpg
  -> references\refs\giraffe__walking-profile.jpg
- verified_by: (VIEW the image to verify it is a usable reference)
