# Reference learnings — index

One line per reference; open the linked file for the detail.

- [car sedan](car-sedan.md) — 2D refs: ortho, side
- [bonsai informal-upright](bonsai-informal-upright.md) — 2D refs: moyogi, maple
- [battleship](battleship.md) — 2D refs: profile, detail
- [anime head](anime-head.md) — 2D refs: front
- [aircraft carrier](aircraft-carrier.md) — 2D refs: deck-aerial
- [windows 95 pc](windows-95-pc.md) — 2D refs: setup
- [giraffe](giraffe.md) — 2D refs: side-standing, walking-profile
