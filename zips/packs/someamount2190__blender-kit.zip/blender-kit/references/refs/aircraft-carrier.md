---
key: aircraft carrier
kind: reference
---
# aircraft carrier — reference learnings

One file per reference (keeps the catalog from bloating). Consult this
BEFORE building 'aircraft carrier'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — fetched 2D reference
Nimitz-class CVN high-angle aerial: full flight deck, starboard island, angled landing deck, deck-edge elevators. Photo ref (no clean ortho on Commons); proportions from Wikipedia Nimitz-class (333x77m deck, 9deg angle).
- deck-aerial: https://upload.wikimedia.org/wikipedia/commons/d/db/Crew_of_USS_Abraham_Lincoln_%28CVN-72%29_spelling_out_RIMPAC_2006_on_last_day_of_exercise_060725-N-7981E-170.jpg
  -> references\refs\aircraft-carrier__deck-aerial.jpg
- verified_by: (VIEW the image to verify it is a usable reference)
