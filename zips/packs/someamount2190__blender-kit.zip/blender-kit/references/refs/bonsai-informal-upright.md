---
key: bonsai informal-upright
kind: reference
---
# bonsai informal-upright — reference learnings

One file per reference (keeps the catalog from bloating). Consult this
BEFORE building 'bonsai informal-upright'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — fetched 2D reference
informal-upright (moyogi): ficus retusa museum specimen (trunk taper, nebari, foliage pads); Japanese maple (clean side profile, ramification + pad structure). Build trunk via curved tapered limb against these.
- moyogi: https://upload.wikimedia.org/wikipedia/commons/f/fd/Pescia%2C_museo_del_bonsai%2C_ficus_retusa%2C_stile_moyogi_%28eretto_informale%29%2C_dalla_cina%2C_circa_50_anni.jpg
  -> references\refs\bonsai-informal-upright__moyogi.jpg
- maple: https://upload.wikimedia.org/wikipedia/commons/3/35/Acer_Palmatum_bonsai_2.JPG
  -> references\refs\bonsai-informal-upright__maple.jpg
- verified_by: (VIEW the image to verify it is a usable reference)
