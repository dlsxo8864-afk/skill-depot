---
key: anime head
kind: reference
---
# anime head — reference learnings

One file per reference (keeps the catalog from bloating). Consult this
BEFORE building 'anime head'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — fetched 2D reference
anime face FRONT proportions: eyes below horizontal midline; brows just above eyes; nose halfway between eye-top and chin; mouth slightly above midpoint nose->chin; eyes ~1 eye-width apart; large forehead/cranium. Side rule (from text): nose tip slightly above 1/4 head height from chin.
- front: https://www.animeoutline.com/wp-content/uploads/2023/07/anime_face_facial_features_proportions_drawing.png
  -> references\refs\anime-head__front.png
- verified_by: (VIEW the image to verify it is a usable reference)
