---
key: windows 95 pc
kind: reference
---
# windows 95 pc — reference learnings

One file per reference (keeps the catalog from bloating). Consult this
BEFORE building 'windows 95 pc'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — fetched 2D reference
1990s beige desktop PC setup reference (CRT monitor + keyboard + case). Win95 screen UI from research: teal #00807F, grey taskbar, Start btm-left, clock btm-right, icons top-left. CRT 36x38x40cm (DEEP).
- setup: https://upload.wikimedia.org/wikipedia/commons/2/21/Personalcomputer.jpg
  -> references\refs\windows-95-pc__setup.jpg
- verified_by: (VIEW the image to verify it is a usable reference)
