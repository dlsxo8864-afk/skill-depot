---
key: car sedan
kind: reference
---
# car sedan — reference learnings

One file per reference (keeps the catalog from bloating). Consult this
BEFORE building 'car sedan'; record new learnings only after a render/inspect
verified them.

## 2026-06-21 — fetched 2D reference
sedan proportions ref: Maserati Quattroporte technical drawing (multi-view ortho, 4-door sedan); Porsche 996 silhouette (clean side profile for overhangs/greenhouse rake). Build side-profile-extrusion body against these.
- ortho: https://upload.wikimedia.org/wikipedia/commons/d/da/%22_13_-_ITALY_-_Maserati_Quattroporte_Silhouette_automobile_technical_drawing_size_difference.jpg
  -> references\refs\car-sedan__ortho.jpg
- side: https://upload.wikimedia.org/wikipedia/commons/0/08/Black_Porsche_996_GT3_silhouette.jpg
  -> references\refs\car-sedan__side.jpg
- verified_by: (VIEW the image to verify it is a usable reference)

## 2026-06-21 — VIEWED — usable
Confirmed by eye (Read tool):
- ortho (car-sedan__ortho.jpg): GENUINE side LINE-ORTHO of two Maserati Quattroporte sedans (2003 + 2013) with wheel-centreline guides. Measurable: wheelbase, overhangs, greenhouse rake, beltline. This is the gold reference for sedan side-profile-extrusion.
- side (car-sedan__side.jpg): a clean side PHOTO of a Porsche 996 (a COUPE, not a sedan) — usable for side feel / wheel+greenhouse positions only, not for sedan proportions.
READ vs my build: the Quattroporte is strongly CAB-REARWARD — long hood, greenhouse pushed back, short rear deck. My _tmp/car held-belief put the greenhouse near centre (generic sedan). To match a sport-sedan: lengthen the front hood, shift the glasshouse rearward, shorten the rear overhang. Wheelbase ~0.6*length holds for both.
- verified_by: Read tool view of references/refs/car-sedan__ortho.jpg + __side.jpg
