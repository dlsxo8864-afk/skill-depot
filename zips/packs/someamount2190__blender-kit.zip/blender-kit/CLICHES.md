# CLICHES — defaults to AVOID

Things that *sound* like design wisdom but the canon argues against, or that are
unfalsifiable platitudes. Recorded as AVOID, not adopted. If a source explicitly
debunks something (e.g. naive "leading lines", pop "color psychology"), it lands
here with the citation — so the build does NOT default to it.

Entry format:
```
### <cliche>   (canon: C1/C2/C3 or "platitude")
- source/why: <url + what the source actually says, or why it's untestable>
- instead: <what to do instead, if anything>
```

---

### "A clean top-down layout drawing proves the level works"   (canon: C1)
- source/why: https://book.leveldesignbook.com/process/layout — "Plans aren't magic. A layout drawing cannot tell you if your level works"; "A layout is NOT a level, the player never plays your drawing." A pretty plan tells you nothing about whether the space plays.
- instead: treat the plan as disposable communication; prove the level only by blockout + playtest — i.e. this skill's build → render → inspect loop. Don't over-detail the plan ("don't clutter your layout drawing with unnecessary design features").

### "Dead ends and indirect/inefficient routes are always bad design"   (canon: C1)
- source/why: https://book.leveldesignbook.com/process/layout/flow — "less efficient flow is not necessarily bad"; warns against treating "dead ends, forced indirect routes" as inherently problematic. Efficiency is not the goal; the experience is.
- instead: judge a route against the intended experience (a dead end can hide a reward or force a tense backtrack). Do NOT auto-flag indirectness as an error.

### "More verticality is always better / add vertical interest everywhere"   (canon: C1)
- source/why: https://book.leveldesignbook.com/process/layout/flow — "we advise against too much random verticality" and "urge restraint"; "many game mechanics require spaces that are just big flat floors, and sometimes that's ok."
- instead: add verticality only where a mechanic/experience needs it; a flat floor is a valid, often correct choice.

### "Leading lines guide the player's eye / gaze"   (canon: C1)
- source/why: https://book.leveldesignbook.com/process/blockout/massing/composition — calls leading lines "brain poison" and "bullshit": they misread human gaze, exist automatically in ANY linear-perspective hallway (foreshortening), push designers toward screenshot aesthetics over metrics/encounter design, and "~99%" fail in playtesting (players look elsewhere).
- instead: guide with relevant landmarks (P1/P3), lighting contrast (P-lighting), and actual layout/affordances — not with decorative converging lines.

### "A great screenshot / shot composition proves the level is good"   (canon: C1)
- source/why: same chapter — "spatial composition is much more important than shot composition"; "Screenshots aren't levels": a photo captures one artistic moment and never guarantees the player's camera or behaviour. (Same family as the layout-drawing cliche.)
- instead: judge SPATIAL composition from multiple angles — exactly why `render.canonical_views` shoots persp + front + ortho-top, not one hero frame.

### "If a sightline exists, the player will use it / see through it"   (canon: C1)
- source/why: same chapter — "The existence of a sightline does not mean the player will use it, nor even know it's there."
- instead: don't assume a sightline reads; reinforce intended views with a landmark or light, and verify by rendering from the player's actual eye position.
