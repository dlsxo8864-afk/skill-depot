"""new_scene.py — template for a fresh scene that runs the MANDATORY LOOP.

Copy this, edit the BLOCKOUT section, and run via:
    scripts/run.sh scripts/new_scene.py -- --plan _tmp/<slug>_plan.md
or directly:
    blender -b --python scripts/new_scene.py -- --plan _tmp/<slug>_plan.md

It performs: blockout (data API) -> materials -> lighting -> frame camera ->
preflight (abort if garbage; runs the fail-closed DESIGN GATE when --plan is
given) -> canonical render -> inspect + failure_scan. It does NOT claim
success; it prints the inspect report + render paths for you to view and judge.

Exit codes (audit fix — a failed build must not read as success): non-zero on
preflight abort, render failure, a failing inspect report, or failure_scan
failures. Representational builds MUST pass --plan (SOP-00/SOP-07); omitting
it prints a loud DESIGN GATE SKIPPED warning.
"""

import os
import sys

# --- make blendkit importable (this file lives in <skill>/scripts/) ---------
SCRIPTS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPTS_DIR)

import bpy
from blendkit import build, transform, material, light, camera, render, preflight
from blendkit import inspect as bk_inspect

# output dir for this build's renders + log
OUT_DIR = os.path.join(SCRIPTS_DIR, "..", "renders", "new_scene")
OUT_DIR = os.path.normpath(OUT_DIR)


def clear_scene():
    for obj in list(bpy.data.objects):
        bpy.data.objects.remove(obj, do_unlink=True)


def blockout():
    """EDIT ME. Build geometry with the data API only. Keep objects resting on
    the ground (z bottom at floor) and non-overlapping unless intended."""
    ground = build.add_ground("Ground", size=12, location=(0, 0, 0))
    material.assign(ground, material.concrete())

    a = build.add_box("BoxA", size=(1, 1, 1), location=(-1.5, 0, 0.5))
    material.assign(a, material.plastic("Blue", color=(0.1, 0.3, 0.8, 1)))

    b = build.add_cylinder("Pillar", radius=0.5, height=2.0, location=(1.5, 0, 1.0))
    material.assign(b, material.metal("Steel"))
    return [ground, a, b]


def _parse_args():
    """Args after Blender's `--` separator (or plain argv under system python)."""
    argv = sys.argv
    args = argv[argv.index("--") + 1:] if "--" in argv else argv[1:]
    plan = None
    if "--plan" in args:
        i = args.index("--plan")
        if i + 1 < len(args):
            plan = args[i + 1]
        else:
            print("usage: ... -- --plan <path/to/plan.md>")
            sys.exit(2)
    return plan


def main():
    plan_path = _parse_args()
    clear_scene()
    blockout()

    # lighting
    light.three_point(target=(0, 0, 1), distance=8, height=5)
    light.world_sky(strength=0.4)

    # camera (auto-framed to the whole scene)
    camera.frame_scene(direction=(1, -1.2, 0.6), make_active=True)

    # GATE: preflight — abort before a slow render if the frame is garbage.
    # With --plan this also runs the fail-closed DESIGN GATE (SOP-07).
    if plan_path is None:
        print("WARNING: DESIGN GATE SKIPPED (no --plan given). Only OK for an "
              "abstract/primitive blockout; representational builds MUST pass "
              "--plan _tmp/<slug>_plan.md (SOP-00 Gate 6).")
    pf = preflight.check(plan_path=plan_path)
    print(preflight.format_check(pf))
    if not pf["ok"]:
        print("PREFLIGHT_ABORT — fix the errors above before rendering.")
        return 1

    # render canonical views (Eevee, Cycles-CPU auto-fallback)
    outs = render.canonical_views(OUT_DIR, samples=48, resolution=(640, 480))
    render_errors = [k for k in ("persp", "front", "top")
                     if outs[k].get("error") is not None]
    print("CONTACT_SHEET:", outs["contact_sheet"])
    print("RENDER_LOG:", outs["log"])

    # GATE: inspect spatial sanity + failure scan (run on EVERY build).
    # A representational build (--plan given) is ONE model and must be a single
    # connected assembly; a plan-less abstract blockout is separate props on a
    # stage, so connectivity is not required (per failure_scan's own contract).
    rep = bk_inspect.scene_report(print_it=True)
    scan = bk_inspect.failure_scan(require_connected=(plan_path is not None),
                                   print_it=False)
    print(bk_inspect.format_failures(scan))

    print("INSPECT_OK:", rep["ok"])
    if render_errors:
        print("RENDER_FAILED views: %s — %s" % (
            render_errors, {k: outs[k].get("error") for k in render_errors}))
        return 1
    if not rep["ok"] or not scan["ok"]:
        print("INSPECT_FAILED — fix the flags above (documented-intentional "
              "flags need a references/ citation, SOP-00 Gate 9).")
        return 1
    print("DONE — now VIEW the contact sheet and READ the inspect report. "
          "Do not report 'done' until it visually holds.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
