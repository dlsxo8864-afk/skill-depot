"""fetch_reference.py — download 2D VISUAL references for a model and stash them
in the `refs` bucket, so a build researches the object's LOOK (blueprint /
orthographic / clear photo) alongside its NUMBERS (proportions.md).

Why: numbers alone still yield "edge & point placement slightly off". A side
ORTHO/blueprint pins the silhouette, the DLO (day-light-opening) of the glass,
overhangs, and feature positions far better than a held-belief table. Fetch one,
VIEW it (Read tool), build against it, then record how it was used.

Robust by design (the failure we hit building this): an image host can return a
200 with an HTML error page. So every download is validated by BOTH the
Content-Type header AND the file's magic bytes; an HTML/again-text payload is
rejected and deleted, never silently saved as a `.png`.

Usage:
  python scripts/fetch_reference.py --key "car sedan" \
      --url SIDE=https://.../sedan_side_blueprint.png \
      --url FRONT=https://.../sedan_front.png \
      --note "low 3-box sedan; greenhouse ~28% height; short overhangs"
  # LABEL= prefix is optional; bare URLs get numbered. Saved as
  # references/refs/<slug>__<label>.<ext>; provenance appended to
  # references/refs/<slug>.md (kind=reference). Then VIEW the images.

Pure stdlib (urllib) so it runs under blender's python or system python. Uses a
browser User-Agent (many hosts 403 a default urllib agent).
"""
import argparse
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
REFS = os.path.join(ROOT, "references", "refs")

# magic-byte signatures -> canonical extension (the source of truth, not the URL)
_SIGS = [
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"\xff\xd8\xff", "jpg"),
    (b"GIF87a", "gif"), (b"GIF89a", "gif"),
    (b"RIFF", "webp"),                       # RIFF....WEBP (checked below)
    (b"BM", "bmp"),
]
# Descriptive UA — Wikimedia (and others) throttle/deny generic urllib agents
# with 429; a tool-name + contact UA per their bot policy gets served normally.
# The contact is read from BLENDERKIT_CONTACT (email or URL) so no personal
# address is hardcoded in the repo.
_CONTACT = os.environ.get("BLENDERKIT_CONTACT", "blender-kit-skill/1.0")
_UA = ("blendkit-reference-fetcher/1.0 (educational 3D modeling reference; "
       "contact %s)" % _CONTACT)

# Only remote web fetches: file:// would copy arbitrary LOCAL files into the
# repo, ftp:// and friends are unaudited. Reject everything else loudly.
_ALLOWED_SCHEMES = ("http", "https")
# Hard response-size cap: a 2D reference image should never approach this;
# anything bigger is a mistake (or hostile) and is aborted mid-stream.
_MAX_BYTES = 25 * 1024 * 1024


def slugify(s):
    s = re.sub(r"[^a-z0-9]+", "-", s.strip().lower()).strip("-")
    return s or "unnamed"


def _sniff(data):
    """Return image extension from magic bytes, or None if not a known image."""
    for sig, ext in _SIGS:
        if data.startswith(sig):
            if ext == "webp" and data[8:12] != b"WEBP":
                continue
            return ext
    # SVG is text but a legit vector reference
    head = data[:512].lstrip()
    if head[:5] == b"<?xml" and b"<svg" in data[:2048] or head[:4] == b"<svg":
        return "svg"
    return None


def fetch_one(url, dest_base, timeout=40, retries=2):
    scheme = urllib.parse.urlsplit(url).scheme.lower()
    if scheme not in _ALLOWED_SCHEMES:
        raise ValueError("URL scheme %r not allowed (only %s) — refusing to fetch"
                         % (scheme or "(none)", "/".join(_ALLOWED_SCHEMES)))
    req = urllib.request.Request(url, headers={"User-Agent": _UA, "Accept": "image/*,*/*"})
    for attempt in range(retries + 1):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                ctype = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
                chunks, total = [], 0            # stream-read so the cap aborts early
                while True:
                    chunk = r.read(256 * 1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > _MAX_BYTES:
                        raise ValueError(
                            "response exceeds the %d MB cap — aborted (a 2D "
                            "reference should be far smaller; pick another URL)"
                            % (_MAX_BYTES // (1024 * 1024)))
                    chunks.append(chunk)
                data = b"".join(chunks)
            break
        except urllib.error.HTTPError as e:        # back off on rate-limit/unavailable
            if e.code in (429, 503) and attempt < retries:
                wait = int(e.headers.get("Retry-After") or (2 * (attempt + 1)))
                time.sleep(min(wait, 8))
                continue
            raise
    ext = _sniff(data)
    if ext is None:
        raise ValueError("not an image (Content-Type=%r, %d bytes, starts %r) — "
                         "likely an HTML error page; pick a DIRECT image URL"
                         % (ctype, len(data), data[:16]))
    if ctype and ctype.startswith("text") and ext != "svg":
        raise ValueError("server sent text/* (%s) — rejected" % ctype)
    path = dest_base + "." + ext
    with open(path, "wb") as f:
        f.write(data)
    return path, len(data)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--key", required=True, help="object key, e.g. 'car sedan'")
    ap.add_argument("--url", action="append", default=[], required=True,
                    help="LABEL=URL (label optional); repeat per view")
    ap.add_argument("--note", default="", help="how this reference will be used")
    ap.add_argument("--timeout", type=int, default=40)
    a = ap.parse_args()

    os.makedirs(REFS, exist_ok=True)
    slug = slugify(a.key)
    saved, failed = [], []
    for i, spec in enumerate(a.url, 1):
        if "=" in spec and not spec.split("=", 1)[0].lower().startswith("http"):
            label, url = spec.split("=", 1)
        else:
            label, url = "v%d" % i, spec
        label = slugify(label)
        base = os.path.join(REFS, "%s__%s" % (slug, label))
        try:
            path, n = fetch_one(url, base, a.timeout)
            saved.append((label, url, path, n))
            print("OK   %-8s %6.1f KB  %s" % (label, n / 1024.0, os.path.relpath(path, ROOT)))
        except Exception as e:
            failed.append((label, url, str(e)))
            print("FAIL %-8s %s\n       %s" % (label, url, e), file=sys.stderr)

    if saved:                                # append provenance to the refs bucket
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import record_learning
        body = a.note.strip() + "\n" if a.note.strip() else ""
        body += "\n".join("- %s: %s\n  -> %s" % (lbl, url, os.path.relpath(p, ROOT))
                          for lbl, url, p, _ in saved)
        record_learning.record(
            "reference", a.key,
            hook="2D refs: " + ", ".join(lbl for lbl, *_ in saved),
            title="fetched 2D reference", body=body,
            verified_by="(VIEW the image to verify it is a usable reference)")
        print("recorded provenance -> references/refs/%s.md" % slug)

    print("\n%d saved, %d failed. NOW: open each saved image with the Read tool, "
          "confirm it is a usable ortho/blueprint/clear photo, and build against it."
          % (len(saved), len(failed)))
    # ANY failed URL is a non-zero exit — partial success must not read as
    # success (what saved is kept and summarized above).
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
