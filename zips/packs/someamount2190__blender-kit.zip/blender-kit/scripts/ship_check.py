"""ship_check.py — THE FINAL GATE (Gate 10). A build may not be reported or
sent to the user until this prints `SHIP: PASS`.

    python scripts/ship_check.py --out _tmp/<slug> --plan _tmp/<slug>_plan.md

Fail-closed on the full process ledger:
  design   : plan exists and design_gate passes (re-checked here, pure text)
  subbuilds: every `sub-build:` declared in the plan has a green ledger entry
  renders  : >=2 *_contact.png contact sheets exist in the out dir
  gates    : ledger 'gates' entry recorded ok=True by the build script
  critic   : ledger 'critic' entry whose artifact file still exists (Gate 9.7)
  engineer : ledger 'engineer' entry with labeled triage (Gate 9.7, NOT optional)
  deviations: ledger 'deviations' entry present (list, or the positive claim
              'none') — silent drift is the documented failure mode.

Why: nine builds (2026-07-04) showed prose phases erode while coded gates
hold. This file is the prose converted to code ("gate everything").
"""
import argparse
import glob
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from blendkit import ledger as bk_ledger   # noqa: E402
from blendkit import plan as bk_plan       # noqa: E402


def run(out_dir, plan_path):
    problems = []
    out_dir = os.path.abspath(out_dir)

    # design
    if not plan_path or not os.path.isfile(plan_path):
        problems.append("design: plan file missing (%s)" % plan_path)
    else:
        g = bk_plan.design_gate(plan_path)
        if not g.get("ok"):
            problems.append("design: design_gate FAILED (%s)" %
                            ", ".join(g.get("incomplete", [])) or g.get("reason", ""))

    # sub-builds (Gate 2.8)
    declared = bk_plan.declared_subbuilds(plan_path) if plan_path else []
    for pr in bk_ledger.check_subbuilds(declared, os.path.dirname):
        problems.append("subbuilds: " + pr)

    # renders on disk
    sheets = glob.glob(os.path.join(out_dir, "*_contact.png"))
    if len(sheets) < 2:
        problems.append("renders: need >=2 contact sheets in %s (found %d)"
                        % (out_dir, len(sheets)))

    led = bk_ledger.load(out_dir)

    ent = led.get("gates")
    if not ent:
        problems.append("gates: not recorded — build script must call "
                        "ledger.record_gates(OUT, ok=...) in its gates block")
    elif not ent.get("ok"):
        problems.append("gates: recorded FAILED (%s)" % ent.get("detail", ""))

    ent = led.get("critic")
    if not ent:
        problems.append("critic: Gate 9.7 cold-critique round not recorded "
                        "(scripts/record_phase.py --critic <file>)")
    elif not os.path.isfile(ent.get("file", "")):
        problems.append("critic: recorded artifact missing on disk: %s"
                        % ent.get("file"))

    ent = led.get("engineer")
    if not ent:
        problems.append("engineer: Gate 9.7 ENGINEER pass not recorded — it is "
                        "NOT optional (scripts/record_phase.py --engineer <file>)")
    elif not os.path.isfile(ent.get("file", "")):
        problems.append("engineer: recorded artifact missing on disk: %s"
                        % ent.get("file"))

    if "deviations" not in led:
        problems.append("deviations: disclosure missing — record deviations or "
                        "the positive claim 'none' "
                        "(scripts/record_phase.py --no-deviations)")

    return problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--plan", required=True)
    a = ap.parse_args()
    problems = run(a.out, a.plan)
    if problems:
        print("SHIP: FAIL (%d blocking)" % len(problems))
        for p in problems:
            print("  - " + p)
        return 1
    led = bk_ledger.load(a.out)
    dev = led.get("deviations", {}).get("notes", [])
    print("SHIP: PASS")
    print("  deviations disclosed: %s" % ("; ".join(dev)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
