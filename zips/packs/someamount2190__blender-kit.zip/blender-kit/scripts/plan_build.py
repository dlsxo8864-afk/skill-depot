"""plan_build.py — START HERE for any representational / multi-part / character
/ organic build. Scaffolds the BUILD PLAN you must fill BEFORE writing geometry
(SOP-07), then tells you the design gate is open once it's complete.

  python scripts/plan_build.py "anime head"          # scaffold the plan
  python scripts/plan_build.py "anime head" --check   # check it's filled

The plan lands in _tmp/<slug>_plan.md. Geometry is forbidden until
plan.design_gate() passes (preflight.check(plan_path=...) enforces it before render).
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
from blendkit import plan

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name", help='object, e.g. "anime head"')
    ap.add_argument("--out", default=os.path.join(ROOT, "_tmp"))
    ap.add_argument("--check", action="store_true", help="check the plan is filled")
    ap.add_argument("--overwrite", action="store_true")
    a = ap.parse_args()

    path = plan.plan_path_for(a.name, a.out)
    if a.check:
        rep = plan.design_gate(path)
        print(plan.format_gate(rep, path))
        return 0 if rep["ok"] else 1

    path = plan.scaffold(a.name, a.out, overwrite=a.overwrite)
    print("BUILD PLAN scaffolded -> %s" % path)
    print("Fill sections 1-6 (WHAT / VISUAL / HOW / FAILURES / FEATURE PARTS /")
    print("DECOMPOSE) BEFORE any geometry. Re-check with:"
          "  python scripts/plan_build.py %r --check" % a.name)
    print("HOW (section 3) and FAILURES (section 4) are the steps most often skipped"
          " — do not.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
