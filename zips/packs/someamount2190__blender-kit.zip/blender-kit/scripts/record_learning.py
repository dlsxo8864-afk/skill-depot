"""record_learning.py — route a verified learning to a PER-KEY file + index.

Avoids catalog bloat: instead of appending to one big objects.md / materials.md,
each object or material/texture gets its OWN file under references/<kind>s/, and a
thin INDEX.md lists them (one line + hook). A build loads only the relevant entry.

Same discipline as LEARNINGS.md: record ONLY after a render/inspect verified the
learning; pass --verified-by. Re-recording an existing key APPENDS a dated entry
to that key's file (the index line is written once).

Usage:
  python record_learning.py --kind object   --key "sword" \
      --hook "arming sword: proportions, hilt anatomy, lay-flat for blueprint" \
      --title "proportions + hilt" --body "..." --verified-by "_tmp/sword/..."

  python record_learning.py --kind material --key "polished steel" \
      --hook "metallic 1.0, rough 0.14, anisotropic 0.7, strip-softbox streak" \
      --title "..." --body "..." --verified-by "..."

Pure stdlib; run with system python or blender's python.
"""
import argparse
import datetime
import os
import re
import time

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
# object    = a thing you build (dimensions/anatomy/build order)
# material  = a surface (shader values + the lighting that made it read)
# pattern   = a mathematical/botanical RULE for PLACEMENT (phyllotaxis, ratios,
#             axis alignment) — the WHERE
# technique = a reusable CONSTRUCTION METHOD (how to make geometry: side-profile
#             extrusion, smooth-bevel hardsurface, recessed-window alloy) — the HOW
# reference = a fetched 2D VISUAL reference for an object (blueprint/ortho/photo):
#             source URL, which views, local image path(s), how it was used
# failure   = a known FAILURE MODE (symptom, cause, how to detect, how to fix)
KIND_DIR = {"object": "objects", "material": "materials", "pattern": "patterns",
            "technique": "techniques", "reference": "refs", "failure": "failures"}


def slugify(s):
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "unnamed"


def record(kind, key, hook, title, body, verified_by, date=None):
    if kind not in KIND_DIR:
        raise ValueError("kind must be one of: %s" % ", ".join(sorted(KIND_DIR)))
    date = date or datetime.date.today().isoformat()
    sub = KIND_DIR[kind]
    d = os.path.join(ROOT, "references", sub)
    os.makedirs(d, exist_ok=True)
    slug = slugify(key)
    path = os.path.join(d, slug + ".md")
    index = os.path.join(d, "INDEX.md")
    is_new = not os.path.exists(path)

    entry = ("\n## %s — %s\n%s\n- verified_by: %s\n"
             % (date, title or "(untitled)", body.strip(), verified_by or "(UNVERIFIED — do not trust)"))

    if is_new:
        header = ("---\nkey: %s\nkind: %s\n---\n# %s — %s learnings\n\n"
                  "One file per %s (keeps the catalog from bloating). Consult this\n"
                  "BEFORE building %r; record new learnings only after a render/inspect\n"
                  "verified them.\n" % (key, kind, key, kind, kind, key))
        with open(path, "w", encoding="utf-8") as f:
            f.write(header + entry)
        # add the index line once
        line = "- [%s](%s.md) — %s\n" % (key, slug, hook or "(no hook)")
        lock = _index_lock(index)
        try:
            _ensure_index(index, kind, line, slug)
        finally:
            _index_unlock(lock)
        action = "CREATED"
    else:
        with open(path, "a", encoding="utf-8") as f:
            f.write(entry)
        # back-fill: an existing index line recorded without a hook stays
        # "(no hook)" forever unless a later --hook run repairs it in place.
        if hook:
            lock = _index_lock(index)
            try:
                if _backfill_hook(index, key, slug, hook):
                    print("back-filled index hook for (%s.md)" % slug)
            finally:
                _index_unlock(lock)
        action = "APPENDED"
    return {"action": action, "path": os.path.relpath(path, ROOT),
            "index": os.path.relpath(index, ROOT), "slug": slug}


def _ensure_index(index, kind, line, slug):
    if not os.path.exists(index):
        with open(index, "w", encoding="utf-8") as f:
            f.write("# %s learnings — index\n\n"
                    "One line per %s; open the linked file for the detail.\n\n"
                    % (kind.capitalize(), kind))
    with open(index, "r", encoding="utf-8") as f:
        text = f.read()
    if "(%s.md)" % slug not in text:           # don't duplicate the index line
        with open(index, "a", encoding="utf-8") as f:
            f.write(line)


def _backfill_hook(index, key, slug, hook):
    """Rewrite a stale '(no hook)' index line for `slug` with the real hook.
    Returns True if a line was updated."""
    if not os.path.exists(index):
        return False
    with open(index, "r", encoding="utf-8") as f:
        lines = f.readlines()
    changed = False
    for i, ln in enumerate(lines):
        if "(%s.md)" % slug in ln and "(no hook)" in ln:
            lines[i] = "- [%s](%s.md) — %s\n" % (key, slug, hook)
            changed = True
    if changed:
        with open(index, "w", encoding="utf-8") as f:
            f.writelines(lines)
    return changed


def _index_lock(index, retries=40, delay=0.05, stale_after=5.0):
    """Best-effort lock serializing index read-modify-write across concurrent
    recorders (os.O_CREAT|os.O_EXCL is atomic on Windows and POSIX). A lock
    older than `stale_after` seconds is treated as left by a dead run and
    removed. If the lock can't be taken after `retries`, proceed UNLOCKED with
    a warning — losing an index line beats crashing the learning loop.
    Returns the lock path (remove via _index_unlock) or None."""
    lock = index + ".lock"
    for _ in range(retries):
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            return lock
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock) > stale_after:
                    os.remove(lock)            # stale lock from a dead run
                    continue
            except OSError:
                pass                           # holder removed it; retry
            time.sleep(delay)
        except OSError:
            break                              # unlockable fs; proceed unlocked
    print("WARNING: could not lock %s — updating the index unlocked" % lock)
    return None


def _index_unlock(lock):
    if lock:
        try:
            os.remove(lock)
        except OSError:
            pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", required=True,
                    choices=["object", "material", "pattern", "technique",
                             "reference", "failure"])
    ap.add_argument("--key", required=True)
    ap.add_argument("--hook", default="")
    ap.add_argument("--title", default="")
    ap.add_argument("--body", default="")
    ap.add_argument("--verified-by", dest="verified_by", default="")
    ap.add_argument("--date", default=None)
    a = ap.parse_args()
    r = record(a.kind, a.key, a.hook, a.title, a.body, a.verified_by, a.date)
    print("%s %s  (index: %s)" % (r["action"], r["path"], r["index"]))
