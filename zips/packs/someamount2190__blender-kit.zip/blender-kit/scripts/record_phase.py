"""record_phase.py — record process phases into the build ledger (see
blendkit/ledger.py). Recorders VALIDATE evidence; you cannot record a critic
round without the critic's saved output, or an engineer pass without a
labeled triage.

    python scripts/record_phase.py --out _tmp/<slug> --critic _tmp/<slug>/critique1.md
    python scripts/record_phase.py --out _tmp/<slug> --engineer _tmp/<slug>/triage1.md
    python scripts/record_phase.py --out _tmp/<slug> --deviation "skipped X because Y"
    python scripts/record_phase.py --out _tmp/<slug> --no-deviations
    python scripts/record_phase.py --out _tmp/<slug> --subbuild _tmp/<slug>/build_part.py --ok
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from blendkit import ledger  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--critic")
    ap.add_argument("--engineer")
    ap.add_argument("--deviation", action="append", default=[])
    ap.add_argument("--no-deviations", action="store_true")
    ap.add_argument("--subbuild")
    ap.add_argument("--ok", action="store_true")
    a = ap.parse_args()
    did = []
    try:
        if a.critic:
            e = ledger.record_critic(a.out, a.critic)
            did.append("critic (%d chars)" % e["chars"])
        if a.engineer:
            e = ledger.record_engineer(a.out, a.engineer)
            did.append("engineer (labels: %s)" % ",".join(e["labels"]))
        if a.deviation:
            ledger.record_deviations(a.out, a.deviation)
            did.append("deviations (%d)" % len(a.deviation))
        if a.no_deviations:
            ledger.record_deviations(a.out, [])
            did.append("deviations (none)")
        if a.subbuild:
            ledger.record_subbuild(os.path.dirname(os.path.abspath(a.subbuild)),
                                   a.subbuild, a.ok)
            did.append("subbuild %s ok=%s" % (os.path.basename(a.subbuild), a.ok))
    except ValueError as ex:
        print("RECORD REFUSED: %s" % ex)
        return 1
    if not did:
        print("nothing to record (see --help)")
        return 1
    print("RECORDED: " + "; ".join(did))
    return 0


if __name__ == "__main__":
    sys.exit(main())
