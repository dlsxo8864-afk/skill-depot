"""material.py — version-aware Principled materials built on the node graph.

All socket writes go through compat.principled_set so the same call works on
3.x / 4.x / 5.x despite the 4.0 socket renames.
"""

import bpy

from . import compat


def _new_principled(name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = compat.get_principled(mat)
    if bsdf is None:
        # extremely old/odd build with no principled by default; create one
        nt = mat.node_tree
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
        out = nt.nodes.get("Material Output") or nt.nodes.new("ShaderNodeOutputMaterial")
        nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    return mat, bsdf


def assign(obj, mat):
    """Assign a material as the object's sole material slot."""
    obj.data.materials.clear()
    obj.data.materials.append(mat)
    return mat


def diffuse(name="Diffuse", color=(0.8, 0.8, 0.8, 1.0), roughness=0.5):
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, base_color=color, roughness=roughness, metallic=0.0)
    return mat


def concrete(name="Concrete", color=(0.55, 0.55, 0.53, 1.0)):
    """Rough, non-metallic, slightly noisy-looking surface."""
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, base_color=color, roughness=0.9, metallic=0.0,
                          specular=0.3)
    return mat


def foliage(name="Foliage", color=(0.12, 0.34, 0.10, 1.0), roughness=0.8,
            translucency=0.3):
    """Matte leaf/frond green with optional TRANSLUCENCY so back-lit leaves glow
    (Diffuse + Translucent BSDF mix). translucency=0 -> plain matte. The
    translucent tint is a lighter, warmer green (light passing through a leaf)."""
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    diff = nt.nodes.new("ShaderNodeBsdfDiffuse")
    diff.inputs["Color"].default_value = color
    diff.inputs["Roughness"].default_value = roughness
    if translucency > 0:
        trans = nt.nodes.new("ShaderNodeBsdfTranslucent")
        trans.inputs["Color"].default_value = (
            min(color[0] * 1.5 + 0.05, 1.0), min(color[1] * 1.35 + 0.05, 1.0),
            min(color[2] * 1.2, 1.0), 1.0)
        mix = nt.nodes.new("ShaderNodeMixShader")
        mix.inputs[0].default_value = float(translucency)
        nt.links.new(diff.outputs[0], mix.inputs[1])
        nt.links.new(trans.outputs[0], mix.inputs[2])
        nt.links.new(mix.outputs[0], out.inputs["Surface"])
    else:
        nt.links.new(diff.outputs[0], out.inputs["Surface"])
    return mat


def bark(name="Bark", plate=(0.36, 0.22, 0.13, 1.0), furrow=(0.15, 0.08, 0.04, 1.0),
         roughness=0.9, scale=6.0):
    """Procedural tree bark: Voronoi DISTANCE_TO_EDGE makes dark furrow lines
    between lighter plates (pine/conifer reddish-brown by default). Cells are
    stretched vertically (taller plates). Object coords, so it wraps a trunk."""
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, metallic=0.0, roughness=roughness, specular=0.2)
    base = compat.principled_socket(bsdf, "base_color")
    nt = mat.node_tree
    texco = nt.nodes.new("ShaderNodeTexCoord")
    mapping = nt.nodes.new("ShaderNodeMapping")
    mapping.inputs["Scale"].default_value = (scale, scale, scale * 0.45)  # tall plates
    nt.links.new(texco.outputs["Object"], mapping.inputs["Vector"])
    vor = nt.nodes.new("ShaderNodeTexVoronoi")
    try:
        vor.feature = "DISTANCE_TO_EDGE"
    except Exception:
        print("WARNING: bark(%r): Voronoi DISTANCE_TO_EDGE unavailable on this "
              "build — falling back to F1 cells (blobby, not furrowed)" % name)
    if "Scale" in vor.inputs:
        vor.inputs["Scale"].default_value = 1.0
    nt.links.new(mapping.outputs["Vector"], vor.inputs["Vector"])
    ramp = nt.nodes.new("ShaderNodeValToRGB")
    cr = ramp.color_ramp
    cr.elements[0].position = 0.0
    cr.elements[0].color = furrow
    cr.elements[1].position = 0.14
    cr.elements[1].color = plate
    out_sock = vor.outputs["Distance"] if "Distance" in vor.outputs else vor.outputs[0]
    nt.links.new(out_sock, ramp.inputs["Fac"])
    nt.links.new(ramp.outputs["Color"], base)
    return mat


def metal(name="Metal", color=(0.8, 0.8, 0.82, 1.0), roughness=0.25):
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, base_color=color, metallic=1.0, roughness=roughness)
    return mat


def car_paint(name="CarPaint", color=(0.5, 0.05, 0.05, 1.0), roughness=0.2, metallic=0.3):
    """Automotive paint: a coloured base with metallic flake + a glossy CLEARCOAT
    (Coat). Reads as car paint only with an ENVIRONMENT to reflect (Cycles +
    softboxes), like any glossy surface."""
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, base_color=color, metallic=metallic, roughness=roughness,
                          coat=1.0, coat_roughness=0.06)
    return mat


def plastic(name="Plastic", color=(0.1, 0.3, 0.8, 1.0), roughness=0.35):
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, base_color=color, metallic=0.0, roughness=roughness,
                          specular=0.5)
    return mat


def wood(name="Wood", color=(0.40, 0.24, 0.12, 1.0), roughness=0.55,
         grain=False, grain_axis="Z", color2=None):
    """Matte non-metallic wood. Warm brown default (mid oak/walnut); pass `color`
    for lighter (pine ~0.6,0.45,0.25) or darker (walnut ~0.22,0.13,0.08).

    grain=True builds a PROCEDURAL grain shader (stretched Wave texture ->
    ColorRamp between `color` and a darker `color2`), so it reads as wood not flat
    paint. `grain_axis` ('X'|'Y'|'Z') is the direction the streaks RUN — set it to
    each part's long axis (vertical legs/posts -> 'Z'; a seat front-to-back ->
    'Y'; a horizontal rail -> 'X'). Uses Generated coords so density is consistent
    across parts of different sizes."""
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, metallic=0.0, roughness=roughness, specular=0.35)
    base_sock = compat.principled_socket(bsdf, "base_color")
    if not grain:
        base_sock.default_value = color
        return mat

    if color2 is None:
        color2 = tuple(c * 0.62 for c in color[:3]) + (1.0,)  # subtler grain line
    nt = mat.node_tree
    texco = nt.nodes.new("ShaderNodeTexCoord")
    mapping = nt.nodes.new("ShaderNodeMapping")
    # stretch HARD along grain_axis -> irregular noise reads as long wood streaks
    # (a regular Wave looks like ribbing/corduroy; stretched Noise looks organic)
    stretch = {"X": (0.5, 12.0, 12.0), "Y": (12.0, 0.5, 12.0), "Z": (12.0, 12.0, 0.5)}
    mapping.inputs["Scale"].default_value = stretch.get(grain_axis, stretch["Z"])
    nt.links.new(texco.outputs["Generated"], mapping.inputs["Vector"])
    noise = nt.nodes.new("ShaderNodeTexNoise")
    for k, v in (("Scale", 1.6), ("Detail", 6.0), ("Roughness", 0.65)):
        if k in noise.inputs:
            noise.inputs[k].default_value = v
    nt.links.new(mapping.outputs["Vector"], noise.inputs["Vector"])
    ramp = nt.nodes.new("ShaderNodeValToRGB")                  # ColorRamp
    cr = ramp.color_ramp
    cr.elements[0].position = 0.38
    cr.elements[0].color = color2
    cr.elements[1].position = 0.62
    cr.elements[1].color = color
    nt.links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    nt.links.new(ramp.outputs["Color"], base_sock)
    return mat


def emissive(name="Emissive", color=(1.0, 0.8, 0.4, 1.0), strength=5.0):
    """Self-illuminating material (also lights the scene a little)."""
    mat, bsdf = _new_principled(name)
    applied = compat.principled_set(
        bsdf, base_color=color, emission_color=color, emission_strength=strength)
    if "emission_color" not in applied:
        # very old builds: try the single 'Emission' color socket directly
        em = bsdf.inputs.get("Emission")
        if em is not None:
            em.default_value = color
        else:
            print("WARNING: emissive(%r): no emission socket on this build's "
                  "Principled BSDF — material will not glow" % name)
    return mat


def glass(name="Glass", color=(1.0, 1.0, 1.0, 1.0), roughness=0.0, ior=1.45):
    mat, bsdf = _new_principled(name)
    compat.principled_set(bsdf, base_color=color, roughness=roughness,
                          transmission=1.0, ior=ior, metallic=0.0)
    # Enable refraction on BOTH the legacy SSR flag and the EEVEE-Next raytrace
    # flag (only the one that exists on this build matters). The scene-level
    # raytracing toggle is enabled by the renderer when a refractive mat exists.
    for attr in ("use_screen_refraction", "use_raytrace_refraction"):
        if hasattr(mat, attr):
            setattr(mat, attr, True)
    return mat


def needs_refraction(mat):
    """True if a material requests refraction (so the renderer can enable the
    scene-level raytracing/SSR that EEVEE needs to actually show glass)."""
    for attr in ("use_raytrace_refraction", "use_screen_refraction"):
        if getattr(mat, attr, False):
            return True
    return False


def tint_textured(obj, rgba, fac=0.65, roughness=None):
    """Tint textured materials WITHOUT destroying the texture (2026-07-06).

    The soldier-round recolor (unlink-then-set) kills the weave/skin map.
    This inserts MixRGB(Fac=fac, Color2=rgba) between whatever feeds each
    Principled Base Color and the socket — texture detail survives, hue
    shifts. Returns the number of links tinted; 0 = nothing was textured
    (caller should fall back to a plain set and CHECK the count — silent
    no-ops are how the white-t-shirt bug shipped).
    """
    tinted = 0
    for slot in obj.material_slots:
        m = slot.material
        if m is None or not m.use_nodes:
            continue
        for nd in list(m.node_tree.nodes):
            if nd.type != "BSDF_PRINCIPLED":
                continue
            bc = nd.inputs["Base Color"]
            for lk in list(bc.links):
                mix = m.node_tree.nodes.new("ShaderNodeMixRGB")
                mix.blend_type = "MULTIPLY"
                mix.inputs["Fac"].default_value = fac
                mix.inputs["Color2"].default_value = rgba
                src = lk.from_socket
                m.node_tree.links.remove(lk)
                m.node_tree.links.new(src, mix.inputs["Color1"])
                m.node_tree.links.new(mix.outputs["Color"], bc)
                tinted += 1
            if roughness is not None:
                nd.inputs["Roughness"].default_value = roughness
    return tinted
