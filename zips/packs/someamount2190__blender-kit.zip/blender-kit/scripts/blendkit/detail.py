"""detail.py — the INTRICACY toolkit: boolean cuts, sharp-edge bevels,
seeded greebles, bolt rings.

Everything is data-API/bmesh only (the single exception being modifier
evaluation, which goes through the evaluated depsgraph — no bpy.ops, no
context/mode dependence, headless-safe).

Design intent: intricate models are many SMALL, DELIBERATE features on a
well-proportioned base. This module makes each feature a one-liner so the
budget goes into designing features (plan §5 FEATURE PARTS), not fighting
bmesh. Pair with render.detail_views() (per-part close-ups) and
inspect.topology_gate() (per-part mesh hygiene) to VERIFY the detail you add.

Determinism: every stochastic helper takes a `seed`; the same seed rebuilds
the same greebles (no Date/random-global anywhere).
"""

import math
import random

import bmesh
import bpy

from . import build


# --- modifier application (headless-safe) -----------------------------------

def apply_modifiers(obj):
    """Bake all modifiers into the mesh via the evaluated depsgraph.
    Equivalent to Ctrl+A apply, but with no bpy.ops / context requirement."""
    dg = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(dg)
    new_me = bpy.data.meshes.new_from_object(eval_obj)
    old = obj.data
    obj.modifiers.clear()
    obj.data = new_me
    new_me.name = obj.name + "_mesh"
    if old.users == 0:
        bpy.data.meshes.remove(old)
    return obj


# --- booleans ---------------------------------------------------------------

def _set_solver(mod):
    """Prefer the newest/most robust boolean solver available on this build."""
    for solver in ("MANIFOLD", "EXACT"):
        try:
            mod.solver = solver
            return solver
        except TypeError:
            continue
    return mod.solver  # whatever the build's default is


def boolean_cut(target, cutter, operation="DIFFERENCE", apply=True,
                keep_cutter=False, clean=True):
    """Boolean `operation` of `cutter` into `target` (DIFFERENCE/UNION/INTERSECT).

    apply=True bakes the result immediately (recommended: downstream inspect /
    export sees real geometry, and the cutter can be deleted).
    clean=True runs build.cleanup afterwards — boolean cut faces are n-gons,
    and cleanup re-quads them so inspect.topology_gate() stays meaningful.
    keep_cutter=False deletes the cutter object+mesh after an applied cut."""
    mod = target.modifiers.new(name="__bkcut__", type="BOOLEAN")
    mod.object = cutter
    mod.operation = operation
    _set_solver(mod)
    cutter.hide_render = True
    if not apply:
        return target
    apply_modifiers(target)
    if clean:
        build.cleanup(target)
    if not keep_cutter:
        me = cutter.data
        bpy.data.objects.remove(cutter, do_unlink=True)
        if me.users == 0:
            bpy.data.meshes.remove(me)
    return target


def panel_groove(target, p0, p1, width=0.012, depth=0.015):
    """Cut a straight panel-line groove into a horizontal surface.

    `p0`/`p1` are (x, y, z_surface) endpoints of an AXIS-ALIGNED segment on the
    surface (the dominant axis of p1-p0 is used). The groove is `width` wide
    and reaches `depth` into the surface. Classic hard-surface panel lines:
    several grooves read as built-from-plates instead of one extruded blob."""
    x0, y0, z = p0
    x1, y1, _ = p1
    dx, dy = abs(x1 - x0), abs(y1 - y0)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    if dx >= dy:
        size = (dx + width, width, depth * 2)
    else:
        size = (width, dy + width, depth * 2)
    cutter = build.add_box("__groove_cutter__", size=size, location=(cx, cy, z))
    return boolean_cut(target, cutter, "DIFFERENCE")


# --- bevels ------------------------------------------------------------------

def bevel_sharp(obj, width=0.02, segments=2, angle_deg=30.0):
    """Bevel every edge sharper than `angle_deg` (face-angle test). The cheap
    realism multiplier: real objects have no zero-radius edges, and beveled
    edges catch specular highlights that make detail read at a glance.
    Run AFTER booleans/grooves so the new edges get beveled too."""
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)
    limit = math.radians(angle_deg)
    edges = []
    for e in bm.edges:
        if len(e.link_faces) == 2:
            try:
                if e.calc_face_angle() > limit:
                    edges.append(e)
            except ValueError:
                continue  # degenerate face
    if edges:
        bmesh.ops.bevel(bm, geom=edges, offset=width, offset_type="OFFSET",
                        segments=segments, profile=0.7, affect="EDGES",
                        clamp_overlap=True, loop_slide=True)
        # clamped bevels collapse segments into coincident verts — merge them
        # or the mesh fails inspect.topology_gate on doubles (found by the
        # gate itself on this kit's first verification build). 1e-5 matches
        # build.cleanup's threshold: boolean+bevel interactions leave pairs
        # wider than 1e-6 (found by the gate again on the sword's fuller).
        bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=1e-5)
    bm.to_mesh(me)
    bm.free()
    me.update()
    return obj


# --- greebles ----------------------------------------------------------------

def greeble_region(prefix, center_xy, region_xy, surface_z, count=12, seed=1,
                   size_range=(0.03, 0.12), height_range=(0.015, 0.06),
                   embed_frac=0.25, collection=None):
    """Scatter `count` varied small boxes over a rectangular region of an
    upward-facing surface. Deterministic per `seed`.

    Each greeble is EMBEDDED `embed_frac` of its height into the surface, so
    the connectivity scan sees real attachment (never floats). Greebles are
    machinery-noise: keep them subordinate to designed feature parts (plan §5)
    — a greeble field reads as detail only next to intentional shapes.
    Returns the list of created objects (name them <prefix>_0..n-1)."""
    rng = random.Random(seed)
    cx, cy = center_xy
    rx, ry = region_xy[0] / 2.0, region_xy[1] / 2.0
    out = []
    placed = []  # (x, y, w, d) — greebles must not overlap EACH OTHER
    gap = 0.004  # min clearance between neighbours
    for i in range(count):
        for _try in range(40):  # rejection sampling, deterministic per seed
            w = rng.uniform(*size_range)
            d = rng.uniform(*size_range)
            x = cx + rng.uniform(-1, 1) * max(rx - w / 2.0, 0.0)
            y = cy + rng.uniform(-1, 1) * max(ry - d / 2.0, 0.0)
            if all(abs(x - px) >= (w + pw) / 2.0 + gap
                   or abs(y - py) >= (d + pd) / 2.0 + gap
                   for px, py, pw, pd in placed):
                break
        else:
            continue  # region is full — fewer greebles beats merged clumps
        h = rng.uniform(*height_range)
        z = surface_z + h * (0.5 - embed_frac)
        ob = build.add_box("%s_%d" % (prefix, len(out)), size=(w, d, h),
                           location=(x, y, z), collection=collection)
        placed.append((x, y, w, d))
        out.append(ob)
    if len(out) < count:
        print("greeble_region %r: placed %d/%d (region full at this size range)"
              % (prefix, len(out), count))
    return out


def lame_arc(name, center_xy, r0, z0, r1, z1, arc_deg, yaw_deg=0.0,
             thick=0.004, segs=14, collection=None):
    """A curved PLATE with real edge thickness: an arc strip from (r0,z0) to
    (r1,z1) spanning arc_deg centered on yaw_deg (0 = facing -Y). THE lapped-
    plate vocabulary for armour lames, tassets, knuckle plates, visor lips,
    fender strips — anywhere a thin curved shell must overlap a neighbour
    (promoted from the knight-armor build's engineer pass: full-ring frustums
    read as washers; lapped arc plates read as construction)."""
    import math as _m
    ob, me = build._new_mesh_object(name, collection)
    bm = bmesh.new()
    cx, cy = center_xy
    a0 = _m.radians(yaw_deg - arc_deg / 2.0)
    a1 = _m.radians(yaw_deg + arc_deg / 2.0)
    rows = []
    for rr, zz in ((r0, z0), (r1, z1)):
        out, inn = [], []
        for i in range(segs + 1):
            a = a0 + (a1 - a0) * i / segs
            sx, sy = _m.sin(a), -_m.cos(a)
            out.append(bm.verts.new((cx + rr * sx, cy + rr * sy, zz)))
            inn.append(bm.verts.new((cx + (rr - thick) * sx,
                                     cy + (rr - thick) * sy, zz)))
        rows.append((out, inn))
    (o0, i0), (o1, i1) = rows
    for i in range(segs):
        bm.faces.new((o0[i], o0[i + 1], o1[i + 1], o1[i]))
        bm.faces.new((i1[i], i1[i + 1], i0[i + 1], i0[i]))
        bm.faces.new((o1[i], o1[i + 1], i1[i + 1], i1[i]))
        bm.faces.new((i0[i], i0[i + 1], o0[i + 1], o0[i]))
    bm.faces.new((o0[0], i0[0], i1[0], o1[0]))
    bm.faces.new((o1[segs], i1[segs], i0[segs], o0[segs]))
    bm.normal_update()
    bm.to_mesh(me)
    bm.free()
    me.update()
    build.cleanup(ob)
    for p in ob.data.polygons:
        p.use_smooth = True
    return ob


def fan_plate(name, radius, arc_deg, location, rot_deg=(0, 0, 0),
              dish=0.15, thick=0.004, segs=12, collection=None):
    """A dished sector plate (elbow couter wing, knee poleyn fan, rondel
    variants). Built with local normal +Z, then rotated into place via
    rot_deg. Promoted from the knight-armor engineer pass."""
    import math as _m
    from . import transform as _tf
    ob, me = build._new_mesh_object(name, collection)
    bm = bmesh.new()
    a0 = _m.radians(-arc_deg / 2.0)
    a1 = _m.radians(arc_deg / 2.0)
    for zoff, flip in ((0.0, False), (-thick, True)):
        ctr = bm.verts.new((0, 0, dish * radius + zoff))
        ring = [bm.verts.new((radius * _m.sin(a0 + (a1 - a0) * i / segs),
                              radius * _m.cos(a0 + (a1 - a0) * i / segs), zoff))
                for i in range(segs + 1)]
        for i in range(segs):
            f = (ctr, ring[i], ring[i + 1]) if not flip else (ctr, ring[i + 1], ring[i])
            bm.faces.new(f)
    bm.normal_update()
    bm.to_mesh(me)
    bm.free()
    me.update()
    build.cleanup(ob)
    ob.location = location
    _tf.set_rotation_deg(ob, *rot_deg)
    for p in ob.data.polygons:
        p.use_smooth = True
    return ob


def bolt_ring(prefix, center_xy, ring_radius, surface_z, count=8,
              bolt_radius=0.012, bolt_height=0.014, embed_frac=0.35,
              start_angle_deg=0.0, style="flat", collection=None):
    """A ring of `count` bolt heads around a center on an upward surface — the
    signature 'this part is FASTENED to that part' cue that makes a joint read
    as engineered. Bolts embed into the surface (connectivity-safe).

    style: "flat" = machined cylinder heads (industrial/sci-fi);
           "dome" = half-embedded spheres — peened/riveted heads for forged /
           hand-made objects (a flat cylinder cap reads as a MODERN bolt and
           its quad-filled cap can specular-flash like a screwdriver slot —
           cold-eyes critique finding on the ornate sword).
    Returns the list of bolt objects."""
    out = []
    a0 = math.radians(start_angle_deg)
    for i in range(count):
        a = a0 + 2.0 * math.pi * i / count
        x = center_xy[0] + ring_radius * math.cos(a)
        y = center_xy[1] + ring_radius * math.sin(a)
        if style == "dome":
            ob = build.add_uv_sphere("%s_%d" % (prefix, i), radius=bolt_radius,
                                     segments=16, rings=8,
                                     location=(x, y, surface_z + bolt_radius * 0.25),
                                     collection=collection, clean=True)
        else:
            z = surface_z + bolt_height * (0.5 - embed_frac)
            # clean=True: de-n-gon the caps so bolts pass inspect.topology_gate
            ob = build.add_cylinder("%s_%d" % (prefix, i), radius=bolt_radius,
                                    height=bolt_height, location=(x, y, z),
                                    segments=16, collection=collection, clean=True)
        out.append(ob)
    return out


# ---- 2026-07-06: rune glyph generator (curve-following engraver, phase 1)

#: Stroke alphabet: each glyph = 2-4 strokes in a unit cell (x across the
#: band, y up it), (x0,y0,x1,y1) pairs. Deterministic — glyph i is always
#: the same shape (kit bans randomness); 12 distinct silhouettes.
_GLYPH_STROKES = [
    [(0.1, 0.1, 0.5, 0.9), (0.5, 0.9, 0.9, 0.1)],
    [(0.5, 0.05, 0.5, 0.95), (0.15, 0.5, 0.85, 0.5)],
    [(0.15, 0.1, 0.15, 0.9), (0.15, 0.9, 0.85, 0.5), (0.15, 0.45, 0.7, 0.1)],
    [(0.2, 0.1, 0.8, 0.9), (0.2, 0.9, 0.8, 0.1), (0.5, 0.0, 0.5, 0.35)],
    [(0.15, 0.15, 0.85, 0.15), (0.5, 0.15, 0.5, 0.95), (0.25, 0.6, 0.75, 0.6)],
    [(0.2, 0.1, 0.2, 0.9), (0.8, 0.1, 0.8, 0.9), (0.2, 0.5, 0.8, 0.5)],
    [(0.5, 0.1, 0.15, 0.9), (0.5, 0.1, 0.85, 0.9)],
    [(0.15, 0.1, 0.85, 0.1), (0.85, 0.1, 0.15, 0.9), (0.15, 0.9, 0.85, 0.9)],
    [(0.5, 0.05, 0.5, 0.6), (0.2, 0.95, 0.5, 0.6), (0.8, 0.95, 0.5, 0.6)],
    [(0.2, 0.2, 0.8, 0.2), (0.5, 0.2, 0.5, 0.75), (0.3, 0.95, 0.7, 0.95)],
    [(0.2, 0.1, 0.2, 0.95), (0.2, 0.55, 0.75, 0.9), (0.2, 0.55, 0.75, 0.2)],
    [(0.15, 0.3, 0.85, 0.3), (0.15, 0.7, 0.85, 0.7)],
]


def rune_glyph(name_prefix, index, origin, u_dir, v_dir, cell=(0.03, 0.045),
               stroke_r=0.0035, mat=None, collection=None):
    """One engraved-look glyph as thin stroke cylinders on a surface frame.

    origin = world anchor (glyph cell corner); u_dir/v_dir = unit vectors
    across/up the band (the surface frame — caller derives them from the
    host: e.g. tangent + z for a cylindrical band). Distinct silhouettes
    come from the 12-entry stroke alphabet, index-deterministic.
    Returns the created objects.
    """
    import math as _math
    from . import build as _build
    from . import transform as _transform
    from . import material as _material
    objs = []
    strokes = _GLYPH_STROKES[index % len(_GLYPH_STROKES)]
    cu, cv = cell
    for si, (x0, y0, x1, y1) in enumerate(strokes):
        a = (origin[0] + u_dir[0] * x0 * cu + v_dir[0] * y0 * cv,
             origin[1] + u_dir[1] * x0 * cu + v_dir[1] * y0 * cv,
             origin[2] + u_dir[2] * x0 * cu + v_dir[2] * y0 * cv)
        b = (origin[0] + u_dir[0] * x1 * cu + v_dir[0] * y1 * cv,
             origin[1] + u_dir[1] * x1 * cu + v_dir[1] * y1 * cv,
             origin[2] + u_dir[2] * x1 * cu + v_dir[2] * y1 * cv)
        d = _math.dist(a, b)
        if d < 1e-6:
            continue
        ob = _build.add_cylinder("%s_%d_%d" % (name_prefix, index, si),
                                 radius=stroke_r, height=d * 1.12, segments=6,
                                 location=((a[0] + b[0]) / 2, (a[1] + b[1]) / 2,
                                           (a[2] + b[2]) / 2),
                                 collection=collection, clean=True)
        dx, dy, dz = (b[0] - a[0]) / d, (b[1] - a[1]) / d, (b[2] - a[2]) / d
        rx = -_math.degrees(_math.asin(max(-1.0, min(1.0, dy))))
        cxr = _math.cos(_math.radians(rx))
        ry = _math.degrees(_math.atan2(dx / cxr, dz / cxr)) if abs(cxr) > 1e-6 else 0
        _transform.set_rotation_deg(ob, rx, ry, 0)
        if mat is not None:
            _material.assign(ob, mat)
        objs.append(ob)
    return objs
