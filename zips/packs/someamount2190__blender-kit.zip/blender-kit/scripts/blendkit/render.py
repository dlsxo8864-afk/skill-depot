"""render.py — canonical render views + contact sheet + render log.

Design goals:
  * Always produce a PERSPECTIVE framed view and an ORTHO top "blueprint" view
    so overlaps/alignment are visible from two complementary angles.
  * Default to Eevee; on any render failure (EGL/GPU/segfault/black) fall back
    to Cycles on CPU automatically.
  * Write a contact sheet (all views stitched) so one PNG tells the whole story.
  * Write a plain-text render log capturing engine, timing, fallbacks, outputs.
"""

import os
import time

import bpy
import numpy as np

from . import camera as bk_camera
from . import compat


def _scene_has_refraction(scene):
    """Any object with a material that requests refraction?"""
    from . import material as bk_material
    for obj in scene.objects:
        if obj.type != "MESH":
            continue
        for slot in obj.material_slots:
            if slot.material and bk_material.needs_refraction(slot.material):
                return True
    return False


def _set_engine(scene, engine, samples):
    if engine == "CYCLES":
        compat.ensure_cycles_available()
        scene.render.engine = "CYCLES"
        scene.cycles.device = "CPU"
        scene.cycles.samples = samples
    else:
        scene.render.engine = compat.eevee_engine_id()
        ee = getattr(scene, "eevee", None)
        # EEVEE sampling attr name differs across versions; set what exists
        if ee is not None and hasattr(ee, "taa_render_samples"):
            ee.taa_render_samples = samples
        # EEVEE renders glass/transmission as opaque unless scene raytracing
        # (EEVEE Next) / SSR is on. Enable it only when a refractive material
        # is present, so opaque scenes keep the cheaper path.
        if ee is not None and _scene_has_refraction(scene):
            if hasattr(ee, "use_raytracing"):
                ee.use_raytracing = True       # EEVEE Next (4.2+/5.x)
            if hasattr(ee, "use_ssr"):
                ee.use_ssr = True              # legacy EEVEE
            if hasattr(ee, "use_ssr_refraction"):
                ee.use_ssr_refraction = True


def _mean_luminance(filepath):
    """Mean brightness of a rendered PNG in [0,1], for black-frame detection."""
    img = bpy.data.images.load(filepath, check_existing=False)
    try:
        px = np.array(img.pixels[:], dtype=np.float32)
        if px.size == 0:
            return 0.0
        rgba = px.reshape(-1, 4)
        return float(rgba[:, :3].mean())
    finally:
        bpy.data.images.remove(img)


def _clip_fraction(filepath):
    """Fraction of pixels whose RGB min-channel exceeds 0.93 ("blown white").

    The EXPOSURE gate metric (2026-07-06, empirically calibrated twice):
    (1) mean luminance CANNOT separate bright-but-correct from blown —
    shipped-PASS renders span lum 0.12..0.86 while blowouts sit inside
    that band. (2) A 0.98 cut NEVER fires under Filmic — its shoulder
    asymptotes at ~0.9725, so a 20x-key blowout measured clip=0.0.
    Measured separation at cut 0.93: deliberate blowout 0.245-0.36 of
    frame, healthy builds (incl. glow-heavy mace/magegun) <=0.026,
    C-130's 0.12-0.36 whites = a real pre-discipline blowout the gate
    retroactively catches. Threshold 0.05; full-frame hero-emissive
    close-ups are the legit override case (pass clip_thresh=None or
    higher).
    """
    img = bpy.data.images.load(filepath, check_existing=False)
    try:
        px = np.array(img.pixels[:], dtype=np.float32)
        if px.size == 0:
            return 0.0
        rgb = px.reshape(-1, 4)[:, :3]
        return float((rgb.min(axis=1) > 0.93).mean())
    finally:
        bpy.data.images.remove(img)


def render_still(filepath, scene=None, engine="EEVEE", samples=64,
                 resolution=(640, 480), log=None, black_thresh=0.004,
                 clip_thresh=0.05):
    """Render the active camera to `filepath`. Returns dict with engine used,
    seconds, mean luminance, and whether a fallback happened.

    Audit fix: a black frame is now treated as a FAILURE, as the module header
    always promised — mean luminance below `black_thresh` advances to the next
    engine, and if every engine produces black the result carries a non-None
    `error` ("black_frame ...") so callers that gate on `error` notice. NOTE:
    luminance includes the world background, so a black result usually means
    no lights AND no world — a missing subject on a lit background still needs
    the agent's eyes (see SOP-00 Gate 8)."""
    scene = scene or bpy.context.scene
    d = os.path.dirname(filepath)
    if d:
        os.makedirs(d, exist_ok=True)
    scene.render.resolution_x, scene.render.resolution_y = resolution
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.filepath = filepath

    attempts = [engine]
    if engine != "CYCLES":
        attempts.append("CYCLES")  # deterministic single fallback

    last_err = None
    for eng in attempts:
        _set_engine(scene, eng, samples)
        t0 = time.time()
        try:
            bpy.ops.render.render(write_still=True)
            dt = time.time() - t0
            lum = _mean_luminance(filepath)
            if lum < black_thresh:
                last_err = "black_frame lum=%.4f on %s (no lights? camera aimed at nothing?)" % (lum, eng)
                if log is not None:
                    log.line("render BLACK on %s (lum=%.4f) -> trying fallback" % (eng, lum))
                continue
            info = {"engine": eng, "seconds": round(dt, 2), "luminance": round(lum, 4),
                    "fallback": eng != engine, "path": filepath, "error": None}
            if clip_thresh is not None:
                clip = _clip_fraction(filepath)
                info["clip_fraction"] = round(clip, 4)
                if clip > clip_thresh:
                    info["error"] = ("overexposed: clip_fraction=%.3f > %.3f "
                                     "(large pure-white areas; check key "
                                     "energy — thundermace/zombie class). "
                                     "Deliberate high-key scene? pass "
                                     "clip_thresh=" % (clip, clip_thresh))
                    if log:
                        log.line("render OVEREXPOSED %s clip=%.3f" %
                                 (os.path.basename(filepath), clip))
            if log is not None:
                log.line("render %s -> %s  (%.2fs, lum=%.4f%s)" % (
                    eng, os.path.basename(filepath), dt, lum,
                    ", FALLBACK" if info["fallback"] else ""))
            return info
        except Exception as e:  # EGL/GPU/segfault-recoverable/etc.
            last_err = e
            if log is not None:
                log.line("render FAILED on %s: %s" % (eng, e))
            continue
    return {"engine": None, "error": str(last_err), "path": filepath,
            "fallback": True, "luminance": 0.0}


def contact_sheet(paths, out_path, log=None):
    """Stitch same-size PNGs side by side into one contact-sheet PNG."""
    imgs = []
    h = w = None
    for p in paths:
        im = bpy.data.images.load(p, check_existing=False)
        iw, ih = im.size
        arr = np.array(im.pixels[:], dtype=np.float32).reshape(ih, iw, 4)
        imgs.append(arr)
        bpy.data.images.remove(im)
        h = ih if h is None else max(h, ih)
        w = iw if w is None else w

    if not imgs:
        return None
    gap = 8
    total_w = sum(a.shape[1] for a in imgs) + gap * (len(imgs) - 1)
    sheet = np.zeros((h, total_w, 4), dtype=np.float32)
    sheet[:, :, 3] = 1.0
    x = 0
    for a in imgs:
        ah, aw = a.shape[0], a.shape[1]
        sheet[0:ah, x:x + aw, :] = a
        x += aw + gap

    out = bpy.data.images.new("contact_sheet", width=total_w, height=h, alpha=True)
    out.pixels = sheet.reshape(-1).tolist()
    out.filepath_raw = out_path
    out.file_format = "PNG"
    out.save()
    bpy.data.images.remove(out)
    if log is not None:
        log.line("contact_sheet -> %s (%dx%d, %d views)" % (out_path, total_w, h, len(imgs)))
    return out_path


class RenderLog:
    """Accumulates render-session notes and writes them to a text file."""

    def __init__(self, path):
        self.path = path
        self.lines = []
        os.makedirs(os.path.dirname(path), exist_ok=True)

    def line(self, msg):
        self.lines.append(str(msg))
        print("[renderlog]", msg)

    def section(self, title):
        self.line("\n--- %s ---" % title)

    def save(self):
        with open(self.path, "w", encoding="utf-8") as f:
            f.write("\n".join(self.lines) + "\n")
        return self.path


def canonical_views(out_dir, scene=None, basename="view", samples=64,
                    resolution=(640, 480), engine="EEVEE", log=None,
                    clip_thresh=0.05, subject_bbox=None,
                    front_direction=(0.0, -1.0, 0.15)):
    """Render the two canonical views (framed perspective + ortho top blueprint)
    plus a front-ish perspective, write a contact sheet, and return a dict of
    output paths. Auto-frames cameras from the scene bounds.
    """
    scene = scene or bpy.context.scene
    os.makedirs(out_dir, exist_ok=True)
    owns_log = log is None
    if owns_log:
        log = RenderLog(os.path.join(out_dir, "render.log"))
    log.section("canonical_views engine=%s samples=%d res=%s" % (engine, samples, resolution))

    # Audit fix: reuse/remove prior canonical cameras instead of accumulating
    # persp_cam.001, front_cam.001, ... on every fix-and-re-render loop.
    for nm in ("persp_cam", "front_cam", "top_cam"):
        old = bpy.data.objects.get(nm)
        if old is not None:
            bpy.data.objects.remove(old, do_unlink=True)

    # Set resolution FIRST so the auto-framing cameras compute FOV/ortho_scale
    # against the real render aspect ratio (else the ortho top view clips).
    scene.render.resolution_x, scene.render.resolution_y = resolution

    outputs = {}

    # 1. framed 3/4 perspective. subject_bbox (2026-07-06): frame_scene fits
    # the whole-scene bounding SPHERE to the smaller FOV axis, which shrinks
    # tall subjects in portrait frames (soldier ITEM 9); an explicit subject
    # bbox frames the SUBJECT and lets the scene provide context.
    if subject_bbox is not None:
        persp = bk_camera.frame_object(bbox=subject_bbox, scene=scene,
                                       name="persp_cam", margin=1.12,
                                       lens_mm=50.0,
                                       direction=(1.0, -1.0, 0.6))
    else:
        persp = bk_camera.frame_scene(scene, name="persp_cam",
                                      direction=(1.0, -1.0, 0.6), make_active=True)
    scene.camera = persp
    p1 = os.path.join(out_dir, basename + "_persp.png")
    outputs["persp"] = render_still(p1, scene, engine, samples, resolution, log,
                                    clip_thresh=clip_thresh)

    # 2. front view. front_direction (2026-07-06): the hardcoded (0,-1)
    # gave a PROFILE for +x-facing models since gundam v1 — pass the
    # subject->camera vector that faces the model's true front.
    if subject_bbox is not None:
        front = bk_camera.frame_object(bbox=subject_bbox, scene=scene,
                                       name="front_cam", margin=1.12,
                                       lens_mm=50.0,
                                       direction=front_direction)
    else:
        front = bk_camera.frame_scene(scene, name="front_cam",
                                      direction=front_direction, make_active=True)
    scene.camera = front
    p2 = os.path.join(out_dir, basename + "_front.png")
    outputs["front"] = render_still(p2, scene, engine, samples, resolution, log,
                                    clip_thresh=clip_thresh)

    # 3. ortho top blueprint
    top = bk_camera.frame_scene_ortho_top(scene, name="top_cam", make_active=True)
    scene.camera = top
    p3 = os.path.join(out_dir, basename + "_top.png")
    outputs["top"] = render_still(p3, scene, engine, samples, resolution, log,
                                  clip_thresh=clip_thresh)

    sheet_paths = [outputs[k]["path"] for k in ("persp", "front", "top")
                   if outputs[k].get("error") is None]
    sheet = contact_sheet(sheet_paths, os.path.join(out_dir, basename + "_contact.png"), log)
    outputs["contact_sheet"] = sheet

    if owns_log:
        log.save()
    outputs["log"] = log.path
    return outputs


def detail_views(parts, out_dir, scene=None, basename="detail", samples=64,
                 resolution=(1280, 960), engine="EEVEE", log=None,
                 direction=(1.0, -1.0, 0.7), clip_thresh=0.05):
    """Per-feature-part close-up render loop (intricacy push #1).

    `parts` = list of part specs: an object name, (label, [names...]) for a
    group framed together, (label, {"bbox": ((x0,y0,z0),(x1,y1,z1))}) to
    frame an explicit world-space REGION (a groove, a seam), or a 3-tuple
    (label, names_or_bbox, direction) to override the camera direction for
    that ONE view (armor engineer-pass lesson: lapped plates hang on
    side-facing surfaces — a single global direction can miss every feature).
    Each part gets its own high-res framed render via camera.frame_object,
    then everything is stitched into one detail contact sheet. Judge each
    part INDIVIDUALLY — a 640px whole-model sheet cannot show whether a bolt
    ring or a panel groove actually reads.

    Returns {"<label>": render_info..., "contact_sheet": path|None, "log": path}.
    Any per-part error is carried in that part's info dict — gate on it."""
    scene = scene or bpy.context.scene
    os.makedirs(out_dir, exist_ok=True)
    owns_log = log is None
    if owns_log:
        log = RenderLog(os.path.join(out_dir, "detail_render.log"))
    log.section("detail_views engine=%s samples=%d res=%s parts=%d"
                % (engine, samples, resolution, len(parts)))

    scene.render.resolution_x, scene.render.resolution_y = resolution
    outputs = {}
    for spec in parts:
        view_dir = direction
        if isinstance(spec, (tuple, list)) and len(spec) == 3 \
                and isinstance(spec[0], str):
            label, names, view_dir = spec[0], spec[1], spec[2]
        elif isinstance(spec, (tuple, list)) and len(spec) == 2 \
                and isinstance(spec[0], str):
            label, names = spec[0], spec[1]
        else:
            label, names = str(spec), spec
        try:
            if isinstance(names, dict) and "bbox" in names:
                cam = bk_camera.frame_object(scene=scene, direction=view_dir,
                                             name="detail_cam", make_active=True,
                                             bbox=names["bbox"])
            else:
                cam = bk_camera.frame_object(names, scene=scene, direction=view_dir,
                                             name="detail_cam", make_active=True)
            scene.camera = cam
            p = os.path.join(out_dir, "%s_%s.png" % (basename, label))
            outputs[label] = render_still(p, scene, engine, samples, resolution, log,
                                          clip_thresh=clip_thresh)
        except Exception as e:
            outputs[label] = {"engine": None, "error": str(e), "path": None,
                              "fallback": False, "luminance": 0.0}
            log.line("detail %s FAILED: %s" % (label, e))

    good = [outputs[k]["path"] for k in outputs
            if outputs[k].get("error") is None and outputs[k].get("path")]
    sheet = contact_sheet(good, os.path.join(out_dir, basename + "_contact.png"),
                          log) if good else None
    outputs["contact_sheet"] = sheet
    if owns_log:
        log.save()
    outputs["log"] = log.path
    return outputs


def enable_glow(scene=None, threshold=1.5, strength=1.0, size=0.5, tint=None):
    """Bloom halo around emissive surfaces (compositor Glare, Bloom mode).

    Blender 5.x API (probed 2026-07-06, see references/bpy_gotchas.md):
    the compositor is a node GROUP assigned to scene.compositing_node_group
    (Scene.node_tree is GONE, use_nodes deprecated), the Composite output
    node no longer exists (use NodeGroupOutput + an interface socket), and
    all Glare parameters are INPUT SOCKETS incl. the string-enum 'Type'.
    Chain: RenderLayers -> Glare('Bloom') -> GroupOutput. Idempotent —
    repeat calls just update the dials.

    Defaults are CALIBRATED, not guessed — consult
    references/materials/emissive-glow.md for per-exposure-class values
    before overriding.
    """
    scene = scene or bpy.context.scene
    ng = bpy.data.node_groups.get("BlendkitGlow")
    if ng is None:
        ng = bpy.data.node_groups.new("BlendkitGlow", "CompositorNodeTree")
        ng.interface.new_socket("Image", in_out="OUTPUT",
                                socket_type="NodeSocketColor")
        rl = ng.nodes.new("CompositorNodeRLayers")
        rl.name = "GlowRL"
        gl = ng.nodes.new("CompositorNodeGlare")
        gl.name = "GlowGlare"
        go = ng.nodes.new("NodeGroupOutput")
        go.name = "GlowOut"
        ng.links.new(rl.outputs["Image"], gl.inputs["Image"])
        ng.links.new(gl.outputs["Image"], go.inputs[0])
    gl = ng.nodes["GlowGlare"]
    gl.inputs["Type"].default_value = "Bloom"
    gl.inputs["Quality"].default_value = "High"
    gl.inputs["Threshold"].default_value = threshold
    gl.inputs["Strength"].default_value = strength
    gl.inputs["Size"].default_value = size
    if tint is not None:
        gl.inputs["Tint"].default_value = tint
    scene.compositing_node_group = ng
    scene.render.use_compositing = True
    print("enable_glow: threshold=%.2f strength=%.2f size=%.2f" %
          (threshold, strength, size))
    return ng


def disable_glow(scene=None):
    """Detach the glow compositor group (renders return to raw output)."""
    scene = scene or bpy.context.scene
    scene.compositing_node_group = None
