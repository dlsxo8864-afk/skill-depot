"""inspect_core.py — PURE PYTHON spatial sanity checks. NO bpy import.

This is the part you (the model) are blind to: overlaps, floating objects,
zero-thickness geometry. It runs on plain axis-aligned bounding boxes so it is
trivially unit-testable without Blender.

Input: a list of object dicts:
    {"name": str, "bbox_min": (x,y,z), "bbox_max": (x,y,z)}
(world-space AABBs). inspect.py produces these from a real scene.

All thresholds are in METERS and tunable.
"""

import re as _re

#: built-in ground/floor-plane name pattern: Ground, floor_01, GroundPlane...
#: deliberately does NOT match FloorLamp or Foreground.
_GROUND_PAT = _re.compile(r"^(ground|floor)(?:$|[ _.\-]|plane)", _re.IGNORECASE)


def name_is_ignored(name, ignore=()):
    """Shared ignore-name matcher (audit fix: unifies the exact-vs-substring
    drift across camera framing, failure_scan, axis_alignment and
    scene_report — the substring test silently exempted props like
    'FloorLamp'/'Foreground'; the exact test missed 'GroundPlane').

    True when `name` equals an `ignore` entry case-insensitively, or matches
    the built-in ground-plane pattern."""
    low = str(name).lower()
    for n in ignore or ():
        if low == str(n).lower():
            return True
    return bool(_GROUND_PAT.match(low))


def _aabb_separation(a, b):
    """Largest per-axis gap between two AABBs; 0 when they touch/overlap."""
    sep = 0.0
    for i in range(3):
        g = max(b["bbox_min"][i] - a["bbox_max"][i],
                a["bbox_min"][i] - b["bbox_max"][i])
        sep = max(sep, g)
    return sep


def _dims(o):
    mn, mx = o["bbox_min"], o["bbox_max"]
    return (mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2])


def _overlap_1d(a_min, a_max, b_min, b_max):
    """Signed overlap length on one axis. Positive => intervals interpenetrate."""
    return min(a_max, b_max) - max(a_min, b_min)


def find_overlaps(objects, eps=1e-4):
    """Pairs whose AABBs interpenetrate on ALL three axes by more than `eps`.

    `eps` prevents flagging faces that merely touch (a box sitting ON a floor
    shares a plane but has ~0 overlap, so it is NOT reported).
    """
    out = []
    n = len(objects)
    for i in range(n):
        a = objects[i]
        for j in range(i + 1, n):
            b = objects[j]
            ox = _overlap_1d(a["bbox_min"][0], a["bbox_max"][0], b["bbox_min"][0], b["bbox_max"][0])
            oy = _overlap_1d(a["bbox_min"][1], a["bbox_max"][1], b["bbox_min"][1], b["bbox_max"][1])
            oz = _overlap_1d(a["bbox_min"][2], a["bbox_max"][2], b["bbox_min"][2], b["bbox_max"][2])
            if ox > eps and oy > eps and oz > eps:
                out.append({
                    "a": a["name"],
                    "b": b["name"],
                    "overlap": (round(ox, 5), round(oy, 5), round(oz, 5)),
                    "min_penetration": round(min(ox, oy, oz), 5),
                })
    return out


def find_degenerate(objects, min_thickness=1e-3):
    """Objects with any AABB dimension below `min_thickness` (zero-scale /
    zero-thickness / collapsed geometry)."""
    out = []
    for o in objects:
        dx, dy, dz = _dims(o)
        thin_axes = [ax for ax, d in zip("xyz", (dx, dy, dz)) if d < min_thickness]
        if thin_axes:
            out.append({
                "name": o["name"],
                "dims": (round(dx, 6), round(dy, 6), round(dz, 6)),
                "thin_axes": thin_axes,
            })
    return out


def _xy_overlap(a, b, eps=1e-4):
    ox = _overlap_1d(a["bbox_min"][0], a["bbox_max"][0], b["bbox_min"][0], b["bbox_max"][0])
    oy = _overlap_1d(a["bbox_min"][1], a["bbox_max"][1], b["bbox_min"][1], b["bbox_max"][1])
    return ox > eps and oy > eps


def _aabb_volume(o):
    d = _dims(o)
    return max(d[0], 1e-9) * max(d[1], 1e-9) * max(d[2], 1e-9)


def _contains(big, small, slack=1e-6):
    return all(big["bbox_min"][i] - slack <= small["bbox_min"][i] and
               small["bbox_max"][i] <= big["bbox_max"][i] + slack
               for i in range(3))


def _sample_min_dist(a, b):
    """Min point-to-point distance between the objects' vertex subsamples
    (None when either lacks samples). O(n*m) on <=48-point subsamples."""
    sa, sb = a.get("samples"), b.get("samples")
    if not sa or not sb:
        return None
    best = None
    for pa in sa:
        for pb in sb:
            d = ((pa[0] - pb[0]) ** 2 + (pa[1] - pb[1]) ** 2 +
                 (pa[2] - pb[2]) ** 2) ** 0.5
            if best is None or d < best:
                best = d
    return best


#: An AABB contact only counts as attachment WITHOUT verification when the
#: partner is not vastly larger. The Andrada porthole bug (2026-07-05,
#: disclosed): a part orphaned 1.8 m inside the hull's whole-ship AABB read
#: as "attached" because AABB separation to a huge concave object is
#: meaningless. Above this volume ratio + full containment, attachment must
#: be verified by vertex samples (or is reported in coarse_attachments).
COARSE_VOLUME_RATIO = 50.0


def find_floating(objects, floor_z=None, gap_tol=1e-3, eps=1e-4, ignore=(),
                  coarse_out=None):
    """Objects whose underside floats above whatever supports them.

    An object is NOT floating when it touches/overlaps ANY other object within
    `gap_tol` (full 3D AABB separation — audit fix: the old rule only accepted
    supports whose top lay strictly BELOW A's underside, so a part correctly
    EMBEDDED into its support per the kit's attach-by-overlap doctrine, or a
    bracket attached sideways, was flagged floating with a bogus gap to the
    floor). Otherwise the support is the highest top of any XY-overlapping
    object below A, else `floor_z`, and A floats if its bottom exceeds that by
    more than `gap_tol`.

    `floor_z` defaults to the lowest bbox_min.z across the scene (the ground).
    `ignore` = names to skip from REPORTING (ground/floor names are skipped by
    the built-in pattern; they still act as supports).
    """
    if not objects:
        return []
    if floor_z is None:
        floor_z = min(o["bbox_min"][2] for o in objects)

    out = []
    for a in objects:
        if name_is_ignored(a["name"], ignore):
            continue
        a_bottom = a["bbox_min"][2]
        attached = False
        support = floor_z
        for b in objects:
            if b is a or b["name"] == a["name"]:
                continue
            if _aabb_separation(a, b) <= gap_tol:
                huge = (_aabb_volume(b) > COARSE_VOLUME_RATIO * _aabb_volume(a)
                        and _contains(b, a, slack=gap_tol))
                if huge:
                    d = _sample_min_dist(a, b)
                    if d is None:
                        # cannot verify — legacy accept, but make it VISIBLE
                        if coarse_out is not None:
                            coarse_out.append({"name": a["name"],
                                               "via": b["name"]})
                        attached = True
                        break
                    if d <= max(gap_tol, 0.02):
                        attached = True
                        break
                    continue  # verified NOT attached to the big object
                attached = True
                break
            if b["bbox_max"][2] <= a_bottom + eps and _xy_overlap(a, b, eps):
                support = max(support, b["bbox_max"][2])
        if attached:
            continue
        gap = a_bottom - support
        if gap > gap_tol:
            out.append({
                "name": a["name"],
                "bottom_z": round(a_bottom, 5),
                "support_z": round(support, 5),
                "gap": round(gap, 5),
            })
    return out


def scene_report(objects, floor_z=None, gap_tol=1e-3, min_thickness=1e-3,
                 overlap_eps=1e-4, ignore_floating=()):
    """Run all checks. Returns a dict with the three problem lists and a bool
    `ok` that is True only when every list is empty."""
    overlaps = find_overlaps(objects, eps=overlap_eps)
    coarse = []
    floating = find_floating(objects, floor_z=floor_z, gap_tol=gap_tol,
                             eps=overlap_eps, ignore=ignore_floating,
                             coarse_out=coarse)
    degenerate = find_degenerate(objects, min_thickness=min_thickness)
    return {
        "object_count": len(objects),
        "overlaps": overlaps,
        "floating": floating,
        "coarse_attachments": coarse,
        "degenerate": degenerate,
        "ok": not (overlaps or floating or degenerate),
    }


def format_report(report):
    """Human/agent-readable text summary."""
    lines = []
    lines.append("=== SCENE INSPECTION ===")
    lines.append("objects: %d   status: %s" % (
        report["object_count"], "PASS" if report["ok"] else "FAIL"))

    if report["overlaps"]:
        lines.append("\n[OVERLAPS] %d pair(s) interpenetrate:" % len(report["overlaps"]))
        for o in report["overlaps"]:
            lines.append("  - %s <-> %s  penetration(min)=%sm  xyz_overlap=%s"
                         % (o["a"], o["b"], o["min_penetration"], o["overlap"]))
    else:
        lines.append("\n[OVERLAPS] none")

    if report["floating"]:
        lines.append("\n[FLOATING] %d object(s) hover above support:" % len(report["floating"]))
        for f in report["floating"]:
            lines.append("  - %s  bottom_z=%s support_z=%s gap=%sm"
                         % (f["name"], f["bottom_z"], f["support_z"], f["gap"]))
    else:
        lines.append("\n[FLOATING] none")

    if report["degenerate"]:
        lines.append("\n[DEGENERATE] %d object(s) with near-zero thickness:" % len(report["degenerate"]))
        for d in report["degenerate"]:
            lines.append("  - %s  dims=%s thin_on=%s"
                         % (d["name"], d["dims"], ",".join(d["thin_axes"])))
    else:
        lines.append("\n[DEGENERATE] none")

    return "\n".join(lines)
