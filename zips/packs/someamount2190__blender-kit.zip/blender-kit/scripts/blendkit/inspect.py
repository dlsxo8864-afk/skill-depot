"""inspect.py — thin bpy adapter over inspect_core.

Computes world-space axis-aligned bounding boxes for the mesh objects in a
scene, then defers ALL geometric reasoning to the pure-python inspect_core so
the logic stays testable without Blender.
"""

import math

import bpy
import bmesh
import mathutils

from . import inspect_core


def world_aabb(obj):
    """World-space AABB computed from the mesh vertices (not obj.bound_box).

    bound_box is a lazily-cached value that can be STALE immediately after
    data-API / bmesh edits, which would make inspection silently wrong. Reading
    the vertices directly is always correct for our modifier-free meshes.
    """
    mw = obj.matrix_world
    verts = obj.data.vertices
    if not verts:
        # fall back to bound_box for non-vertex data
        corners = [mw @ mathutils.Vector(c) for c in obj.bound_box]
    else:
        corners = [mw @ v.co for v in verts]
    xs = [c.x for c in corners]
    ys = [c.y for c in corners]
    zs = [c.z for c in corners]
    return (min(xs), min(ys), min(zs)), (max(xs), max(ys), max(zs))


def collect(scene=None, only_meshes=True, include_hidden=False):
    """Build the inspect_core input list from a scene's objects."""
    scene = scene or bpy.context.scene
    # flush pending transforms so matrix_world is current
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    out = []
    for obj in scene.objects:
        if only_meshes and obj.type != "MESH":
            continue
        if not include_hidden and obj.hide_render:
            continue
        mn, mx = world_aabb(obj)
        rec = {"name": obj.name, "bbox_min": mn, "bbox_max": mx}
        # vertex subsample (<=48 pts) lets inspect_core verify attachments
        # to VASTLY larger AABBs (Andrada porthole class) by real distance
        try:
            verts = obj.data.vertices
            if len(verts):
                stride = max(1, len(verts) // 48)
                mw = obj.matrix_world
                rec["samples"] = [tuple(mw @ verts[i].co)
                                  for i in range(0, len(verts), stride)][:48]
        except Exception:
            pass
        out.append(rec)
    return out


_FLAT_NAMES = ("Ground", "Floor")


def _exact_unfloat_wrap(scene, report):
    """Re-verify core-flagged floaters with EXACT closest_point_on_mesh.

    The pure core verifies coarse containment via vertex subsamples, which
    false-positives on low-vert primitives (a box's samples are its 8
    corners — a strip on a face CENTER reads 0.5 m from the nearest sample;
    gundam2 PanelLine3/4 on the tilted skirts, same class as the magegun
    barrel in failure_scan). Any floater within (half_diag + 2 cm) of some
    other mesh's actual SURFACE is un-flagged."""
    import mathutils
    scene = scene or bpy.context.scene
    if not report.get("floating"):
        return report
    keep = []
    for f in report["floating"]:
        ob = scene.objects.get(f["name"]) if scene else None
        if ob is None or ob.type != "MESH":
            keep.append(f)
            continue
        mn, mx = world_aabb(ob)
        center = mathutils.Vector(((mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2,
                                   (mn[2] + mx[2]) / 2))
        half_diag = (sum((mx[k] - mn[k]) ** 2 for k in range(3)) ** 0.5) / 2
        attached = False
        for other in scene.objects:
            if other is ob or other.type != "MESH" or other.hide_render:
                continue
            try:
                inv = other.matrix_world.inverted()
                hit, loc, _n, _i = other.closest_point_on_mesh(inv @ center)
                if hit:
                    d = (other.matrix_world @ loc - center).length
                    if d <= half_diag + 0.02:
                        attached = True
                        break
            except Exception:
                continue
        if not attached:
            keep.append(f)
    report["floating"] = keep
    report["ok"] = not (report.get("overlaps") or keep or
                        report.get("degenerate"))
    return report


def scene_report(scene=None, floor_z=None, gap_tol=1e-3, min_thickness=1e-3,
                 ignore_floating=_FLAT_NAMES, ignore_degenerate=_FLAT_NAMES,
                 print_it=True):
    """Collect AABBs and run inspect_core.scene_report. Prints the formatted
    report (so it lands in the render log) and returns the report dict.

    `ignore_degenerate` drops intentionally-flat objects (a floor plane is
    legitimately zero-thickness) from the degenerate list so they don't read as
    errors. Matching goes through inspect_core.name_is_ignored (case-insensitive
    exact match + the built-in ground/floor-plane pattern). inspect_core itself
    stays general and flags everything.
    """
    objects = collect(scene)
    report = _exact_unfloat_wrap(scene, inspect_core.scene_report(
        objects, floor_z=floor_z, gap_tol=gap_tol, min_thickness=min_thickness,
        ignore_floating=ignore_floating,
    ))
    if ignore_degenerate:
        report["degenerate"] = [
            d for d in report["degenerate"]
            if not inspect_core.name_is_ignored(d["name"], ignore_degenerate)]
        report["ok"] = not (report["overlaps"] or report["floating"] or report["degenerate"])
    if print_it:
        print(inspect_core.format_report(report))
    return report


def player_fit(scene=None, player_name="PlayerRef", print_it=True):
    """Design SOP-05 gate (P4): does the player reference fit? Place a
    1.0x1.8 m box named `player_name` in a passage/doorway; this returns the
    overlaps between it and any other geometry. Empty list == fits.

    Promoted from the design Phase-3 finding: player-fit is the cheapest,
    most objective tactical-design check (uses the skill's own AABB inspect).
    """
    report = scene_report(scene, print_it=False)
    overlaps = [o for o in report["overlaps"] if player_name in (o["a"], o["b"])]
    if print_it:
        if overlaps:
            print("PLAYER FIT: FAIL — %r collides with: %s" % (
                player_name, ", ".join(o["a"] if o["b"] == player_name else o["b"]
                                       for o in overlaps)))
        else:
            print("PLAYER FIT: PASS — %r clears all geometry" % player_name)
    return overlaps


# --- topology audit -------------------------------------------------------

def topology_report(scene=None, only_meshes=True, include_hidden=True,
                    merge_dist=1e-5, print_it=True):
    """Audit mesh hygiene per object: quad/tri/ngon face counts, double verts,
    and non-manifold edges (boundary edges of open meshes like a ground plane
    count as non-manifold — expected). Same 'measure and surface it' ethos as the
    spatial report. `ok` is True when no object has n-gons or double verts.

    Non-manifold edges are counted on the mesh AS-IS (`nonmanifold_edges`);
    `nonmanifold_after_merge` re-counts after a remove_doubles pass on a temp
    bmesh, showing what a cleanup would leave (doubles often fake open edges).

    These matter for SUBDIVISION / ANIMATION / EXPORT, not for still-render
    blockouts. Clean a flagged mesh with build.cleanup(obj) or build's clean=True."""
    scene = scene or bpy.context.scene
    objs = []
    tot = {"quads": 0, "tris": 0, "ngons": 0, "doubles": 0, "nonmanifold": 0}
    for obj in scene.objects:
        if only_meshes and obj.type != "MESH":
            continue
        if not include_hidden and obj.hide_render:
            continue
        me = obj.data
        quads = tris = ngons = 0
        for p in me.polygons:
            n = p.loop_total
            if n == 4:
                quads += 1
            elif n == 3:
                tris += 1
            elif n > 4:
                ngons += 1
        bm = bmesh.new()
        bm.from_mesh(me)
        before = len(bm.verts)
        # count non-manifold BEFORE remove_doubles: the report must describe
        # the mesh as it IS, not a hypothetical cleaned copy
        nonman = sum(1 for e in bm.edges if not e.is_manifold)
        bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=merge_dist)
        doubles = before - len(bm.verts)
        nonman_after = sum(1 for e in bm.edges if not e.is_manifold)
        bm.free()
        rec = {"name": obj.name, "faces": quads + tris + ngons, "quads": quads,
               "tris": tris, "ngons": ngons, "doubles": doubles,
               "nonmanifold_edges": nonman,
               "nonmanifold_after_merge": nonman_after}
        objs.append(rec)
        tot["quads"] += quads
        tot["tris"] += tris
        tot["ngons"] += ngons
        tot["doubles"] += doubles
        tot["nonmanifold"] += nonman

    report = {"objects": objs, "totals": tot,
              "ok": tot["ngons"] == 0 and tot["doubles"] == 0,
              "ngon_objects": [o["name"] for o in objs if o["ngons"]],
              "double_objects": [o["name"] for o in objs if o["doubles"]]}
    if print_it:
        print(format_topology(report))
    return report


def format_topology(report):
    lines = ["=== TOPOLOGY: %s ===" % ("CLEAN" if report["ok"] else "HAS N-GONS/DOUBLES")]
    for o in report["objects"]:
        flag = ""
        if o["ngons"]:
            flag += " <-NGON"
        if o["doubles"]:
            flag += " <-DOUBLES"
        lines.append("  %-16s faces=%-4d quad=%-4d tri=%-4d ngon=%-3d doubles=%-3d nonmanifold=%d%s"
                     % (o["name"], o["faces"], o["quads"], o["tris"], o["ngons"],
                        o["doubles"], o["nonmanifold_edges"], flag))
    t = report["totals"]
    lines.append("  TOTAL  quad=%d tri=%d ngon=%d doubles=%d" % (
        t["quads"], t["tris"], t["ngons"], t["doubles"]))
    if not report["ok"]:
        lines.append("  -> clean with build.cleanup(obj) or build's clean=True "
                     "(only needed for subdiv/animation/export).")
    return "\n".join(lines)


def topology_gate(part_names=None, scene=None, allow_nonmanifold=True,
                  print_it=True):
    """PER-PART mesh-hygiene gate for feature parts (intricacy push #3).

    Whole-scene topology totals hide which PART is dirty; this filters
    topology_report to `part_names` (the plan §5 feature parts; None = every
    mesh) and fails per part on n-gons or double verts — the two defects that
    break bevels, subdivision and export on exactly the small parts detail
    work adds. Non-manifold edges are reported but tolerated by default
    (open-plane parts are legitimate); pass allow_nonmanifold=False for
    watertight requirements.

    Returns {"parts": [...records...], "bad": [names], "ok": bool}."""
    rep = topology_report(scene=scene, print_it=False)
    wanted = None if part_names is None else set(part_names)
    parts = [o for o in rep["objects"]
             if wanted is None or o["name"] in wanted]
    missing = [] if wanted is None else sorted(wanted - {o["name"] for o in parts})
    bad = [o["name"] for o in parts
           if o["ngons"] or o["doubles"]
           or (not allow_nonmanifold and o["nonmanifold_edges"])]
    out = {"parts": parts, "bad": bad, "missing": missing,
           "ok": not bad and not missing}
    if print_it:
        lines = ["=== TOPOLOGY GATE (%d part%s): %s ===" % (
            len(parts), "" if len(parts) == 1 else "s",
            "PASS" if out["ok"] else "FAIL")]
        for o in parts:
            flag = " <-FAIL" if o["name"] in bad else ""
            lines.append("  %-16s ngon=%-3d doubles=%-3d nonmanifold=%d%s"
                         % (o["name"], o["ngons"], o["doubles"],
                            o["nonmanifold_edges"], flag))
        if missing:
            lines.append("  MISSING parts (no such mesh): %s" % ", ".join(missing))
        if bad:
            lines.append("  -> clean with build.cleanup(obj); boolean_cut(clean=True) "
                         "already re-quads cut faces")
        print("\n".join(lines))
    return out


# --- failure scan ---------------------------------------------------------

def _aabb_gap(a_min, a_max, b_min, b_max):
    """Separation distance between two AABBs (0 if they touch/overlap)."""
    g = 0.0
    for k in range(3):
        d = max(b_min[k] - a_max[k], a_min[k] - b_max[k], 0.0)
        g += d * d
    return g ** 0.5


def failure_scan(scene=None, floor_z=0.0, below_tol=0.02, connect_eps=0.003,
                 require_connected=True, ignore=("Ground", "Floor"), print_it=True):
    """Catch the placement FAILURE MODES the design checks miss — run BEFORE
    shipping ANY model (it works even when you skip the noisy overlap report on a
    dense organic build):

      * below_ground — a mesh dips below the floor (z < floor_z - below_tol).
      * floating     — parts NOT in the model's single connected component. The
                       whole model must be ONE connected piece (union-find over
                       the AABB-proximity graph, parts within `connect_eps`=3 mm
                       are joined); any part in a smaller DETACHED ISLAND (parts
                       touching each other but not the body) is floating. A gap >
                       3 mm = detached; "close" is NOT connected. (Set
                       require_connected=False for scenes of separate props.)
                       LIMIT: AABB-based — a part whose bbox overlaps another's
                       despite a real mesh gap can still slip; verify by eye.
      * degenerate   — zero-scale or non-finite transform.

    Returns {below_ground, floating, degenerate, ok}."""
    scene = scene or bpy.context.scene
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    objs = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.hide_render:
            continue
        if inspect_core.name_is_ignored(obj.name, ignore):
            continue
        mn, mx = world_aabb(obj)
        rec = {"name": obj.name, "min": mn, "max": mx, "obj": obj}
        try:
            verts = obj.data.vertices
            if len(verts):
                stride = max(1, len(verts) // 48)
                mw = obj.matrix_world
                rec["samples"] = [tuple(mw @ verts[i].co)
                                  for i in range(0, len(verts), stride)][:48]
        except Exception:
            pass
        objs.append(rec)

    below = [o["name"] for o in objs if o["min"][2] < floor_z - below_tol]

    floating = []
    if require_connected and len(objs) > 1:
        # GLOBAL connectivity: the model must be ONE connected component, not just
        # "every part touches something". A detached SUB-ASSEMBLY (parts touching
        # each other but not the body) is still floating. Union-find over the
        # AABB-proximity graph; flag every part not in the largest component.
        parent = list(range(len(objs)))

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def _vol_of(o):
            return (max(o["max"][0] - o["min"][0], 1e-9) *
                    max(o["max"][1] - o["min"][1], 1e-9) *
                    max(o["max"][2] - o["min"][2], 1e-9))

        def _contains_o(big, small, slack):
            return all(big["min"][k] - slack <= small["min"][k] and
                       small["max"][k] <= big["max"][k] + slack
                       for k in range(3))

        def _edge_ok(a, b):
            """AABB proximity, surface-verified when one AABB is huge and
            CONTAINS the other (Andrada porthole class, 2026-07-06: gap to
            a whole-ship hull AABB is meaningless — an orphan 1.8 m off the
            hull surface still measured gap 0).

            Verification uses EXACT closest_point_on_mesh, not vertex
            samples — vertex distance false-positives on long low-poly
            primitives (magegun barrel: an 8-seg cylinder has verts only
            at its end rings, so a rune chip ON a mid-barrel flat measured
            0.2 m from the nearest vert and got flagged)."""
            if _aabb_gap(a["min"], a["max"], b["min"], b["max"]) > connect_eps:
                return False
            big, small = (a, b) if _vol_of(a) >= _vol_of(b) else (b, a)
            if (_vol_of(big) > inspect_core.COARSE_VOLUME_RATIO * _vol_of(small)
                    and _contains_o(big, small, connect_eps)):
                try:
                    center = tuple((small["min"][k] + small["max"][k]) / 2.0
                                   for k in range(3))
                    import mathutils
                    inv = big["obj"].matrix_world.inverted()
                    hit, loc, _nrm, _idx = big["obj"].closest_point_on_mesh(
                        inv @ mathutils.Vector(center))
                    if hit:
                        wp = big["obj"].matrix_world @ loc
                        d = (wp - mathutils.Vector(center)).length
                        half_diag = (sum((small["max"][k] - small["min"][k]) ** 2
                                         for k in range(3)) ** 0.5) / 2.0
                        return d <= half_diag + max(connect_eps * 10, 0.02)
                except Exception:
                    pass  # cannot verify -> legacy accept
            return True

        for i in range(len(objs)):
            for j in range(i + 1, len(objs)):
                if _edge_ok(objs[i], objs[j]):
                    parent[find(i)] = find(j)
        comps = {}
        for i in range(len(objs)):
            comps.setdefault(find(i), []).append(i)
        if len(comps) > 1:
            def _vol(i):
                o = objs[i]
                return ((o["max"][0] - o["min"][0]) * (o["max"][1] - o["min"][1])
                        * (o["max"][2] - o["min"][2]))
            main = max(comps.values(), key=lambda comp: sum(_vol(i) for i in comp))
            for comp in comps.values():               # the body = the biggest mass
                if comp is not main:
                    floating.extend(objs[i]["name"] for i in comp)

    degenerate = []
    for o in objs:
        sx, sy, sz = o["obj"].scale
        if min(abs(sx), abs(sy), abs(sz)) < 1e-7:
            degenerate.append(o["name"])
        elif not all(math.isfinite(c) for c in o["obj"].location):
            degenerate.append(o["name"])

    report = {"below_ground": below, "floating": floating, "degenerate": degenerate,
              "object_count": len(objs),
              "ok": not (below or floating or degenerate)}
    if print_it:
        print(format_failures(report))
    return report


def format_failures(report):
    lines = ["=== FAILURE SCAN: %s (%d meshes) ===" % (
        "CLEAN" if report["ok"] else "FAILURES", report["object_count"])]

    def _grp(key, label, fix):
        names = report[key]
        if names:
            shown = ", ".join(names[:8]) + (" …(+%d)" % (len(names) - 8) if len(names) > 8 else "")
            lines.append("  %-12s %d: %s" % (label, len(names), shown))
            lines.append("               -> %s" % fix)
    _grp("below_ground", "BELOW-GROUND", "raise/shorten these so geometry stays above floor_z")
    _grp("floating", "FLOATING", "CONNECT to the model — a part must touch/overlap another, "
         "not just be near (attach to the parent SURFACE, not a phantom point)")
    _grp("degenerate", "DEGENERATE", "fix zero-scale / non-finite transform")
    if report["ok"]:
        lines.append("  no below-ground, floating, or degenerate objects")
    return "\n".join(lines)


# --- central-axis (coaxial) alignment -------------------------------------

def axis_alignment(scene=None, long_axis="Y", tol=0.006, ignore=("Ground", "Floor"),
                   print_it=True):
    """DIMENSIONS check: do the parts share ONE central axis (the design's
    'center of gravity' line), or does a part sit OFF that axis?

    A part resting on the floor by its own bottom but with a different thickness
    ends up with its CENTRELINE at a different height than its neighbours (a thin
    blade sits lower than a fat grip). For an assembled symmetric object (sword,
    bottle, column, tool) every part should be CONCENTRIC on the same axis and
    equidistant about it.

    Picks the central axis as the MEDIAN of part centres in the two axes
    perpendicular to `long_axis` (robust to a few stragglers), then flags any
    part whose centre is more than `tol` off that axis. Also reports the
    volume-weighted centre of gravity. Returns {axis_perp_pos, cog, components,
    off_axis, ok}."""
    scene = scene or bpy.context.scene
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    comps = []
    for obj in scene.objects:
        if obj.type != "MESH" or obj.hide_render:
            continue
        if inspect_core.name_is_ignored(obj.name, ignore):
            continue
        mn, mx = world_aabb(obj)
        center = [(mn[k] + mx[k]) / 2.0 for k in range(3)]
        vol = (mx[0] - mn[0]) * (mx[1] - mn[1]) * (mx[2] - mn[2])
        comps.append({"name": obj.name, "center": center, "vol": vol})
    if len(comps) < 2:
        return {"applicable": False, "reasoning": "need >=2 parts", "ok": True}

    ai = {"X": 0, "Y": 1, "Z": 2}[long_axis]
    perp = [k for k in range(3) if k != ai]

    def _median(vals):
        v = sorted(vals)
        n = len(v)
        return v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) / 2.0

    axis_pos = {p: _median([c["center"][p] for c in comps]) for p in perp}
    tv = sum(c["vol"] for c in comps) or 1e-9
    cog = [sum(c["vol"] * c["center"][k] for c in comps) / tv for k in range(3)]

    results, off_axis = [], []
    for c in comps:
        d = math.sqrt(sum((c["center"][p] - axis_pos[p]) ** 2 for p in perp))
        results.append({"name": c["name"], "offset": round(d, 4),
                        "perp": {"XYZ"[p]: round(c["center"][p], 4) for p in perp}})
        if d > tol:
            off_axis.append(c["name"])

    report = {"applicable": True, "long_axis": long_axis,
              "axis_perp_pos": {"XYZ"[p]: round(axis_pos[p], 4) for p in perp},
              "cog": [round(v, 4) for v in cog], "components": results,
              "off_axis": off_axis, "tol": tol, "ok": not off_axis}
    if print_it:
        print(format_alignment(report))
    return report


_AX = {"x": 0, "y": 1, "z": 2}


def _part_aabb(scene, name):
    for obj in scene.objects:
        if obj.name == name and obj.type == "MESH":
            return world_aabb(obj)
    return None


def check_ratios(scene=None, specs=None, tol=0.18, print_it=True):
    """Counter-check a part's SIZE against OTHER parts (a part can be right on its
    own but wrong relative to its neighbour). Each spec is
    (label, partA, dimA, partB, dimB, expected_ratio) where dim in 'x'/'y'/'z' is
    that part's bbox extent on that axis. Flags any |ratio/expected - 1| > tol.

    e.g. ('crossguard:blade', 'Guard','x', 'Blade','x', 4.0) — the crossguard
    should be ~4x the blade width."""
    scene = scene or bpy.context.scene
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    results, bad = [], []
    for sp in (specs or []):
        label, a, ad, b, bd, exp = sp
        ba, bb = _part_aabb(scene, a), _part_aabb(scene, b)
        if ba is None or bb is None:
            results.append({"label": label, "status": "MISSING PART"})
            bad.append(label)
            continue
        exa = ba[1][_AX[ad]] - ba[0][_AX[ad]]
        exb = bb[1][_AX[bd]] - bb[0][_AX[bd]]
        ratio = exa / exb if exb else 0.0
        off = abs(ratio - exp) / exp if exp else 1.0
        ok = off <= tol
        results.append({"label": label, "ratio": round(ratio, 3), "expected": exp,
                        "ok": ok})
        if not ok:
            bad.append(label)
    report = {"ratios": results, "off": bad, "ok": not bad, "tol": tol}
    if print_it:
        print(format_ratios(report))
    return report


def format_ratios(report):
    lines = ["=== RATIO CHECK: %s (tol %.0f%%) ===" % (
        "OK" if report["ok"] else "OFF", report["tol"] * 100)]
    for r in report["ratios"]:
        if "status" in r:
            lines.append("  %-22s %s" % (r["label"], r["status"]))
        else:
            lines.append("  %-22s ratio=%.2f expected=%.2f%s" % (
                r["label"], r["ratio"], r["expected"], "" if r["ok"] else "  <-OFF"))
    return "\n".join(lines)


def check_alignment(scene=None, specs=None, tol=0.004, print_it=True):
    """Check a part is ALIGNED with another on a given axis (x/y/z). Each spec is
    (partA, partB, axis, mode) where mode in 'center'/'min'/'max' picks the bbox
    centre or an edge. Flags |A - B| > tol on that axis.

    e.g. ('FrontSight','RearSight','y','center') — sights share the centreline;
    ('Magazine','Receiver','x','center') — mag centred under the receiver."""
    scene = scene or bpy.context.scene
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    results, bad = [], []
    for sp in (specs or []):
        a, b, axis, mode = sp
        ba, bb = _part_aabb(scene, a), _part_aabb(scene, b)
        if ba is None or bb is None:
            results.append({"pair": "%s~%s" % (a, b), "status": "MISSING PART"})
            bad.append("%s~%s" % (a, b))
            continue
        k = _AX[axis]

        def _pos(box):
            if mode == "min":
                return box[0][k]
            if mode == "max":
                return box[1][k]
            return (box[0][k] + box[1][k]) / 2.0
        diff = abs(_pos(ba) - _pos(bb))
        ok = diff <= tol
        results.append({"pair": "%s~%s" % (a, b), "axis": axis, "mode": mode,
                        "diff": round(diff, 4), "ok": ok})
        if not ok:
            bad.append("%s~%s(%s)" % (a, b, axis))
    report = {"alignments": results, "off": bad, "ok": not bad, "tol": tol}
    if print_it:
        print(format_align_pairs(report))
    return report


def format_align_pairs(report):
    lines = ["=== ALIGNMENT CHECK: %s (tol %.3f) ===" % (
        "OK" if report["ok"] else "MISALIGNED", report["tol"])]
    for r in report["alignments"]:
        if "status" in r:
            lines.append("  %-26s %s" % (r["pair"], r["status"]))
        else:
            lines.append("  %-26s %s-%s diff=%.4f%s" % (
                r["pair"], r["axis"], r["mode"], r["diff"], "" if r["ok"] else "  <-MISALIGNED"))
    return "\n".join(lines)


def _obj_by_name(scene, name):
    for obj in scene.objects:
        if obj.name == name and obj.type == "MESH":
            return obj
    return None


def check_placement(scene=None, specs=None, tol=0.05, print_it=True):
    """PLACEMENT check: is a part at the expected ABSOLUTE position on an axis
    (e.g. a turret at the right station along the hull)? Complements
    check_alignment (part-vs-part) and check_ratios (sizes) — a part can be the
    right size and symmetric yet sit too far forward/aft. Each spec is
    (label, part, axis, expected, [mode]) with axis x/y/z, mode center/min/max
    (default center). Flags |pos - expected| > tol.

    e.g. ('T1 station','T1Box','x', 3.15) — turret 1 centred at x=3.15."""
    scene = scene or bpy.context.scene
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    results, bad = [], []
    for sp in (specs or []):
        label, part, axis, exp = sp[0], sp[1], sp[2], sp[3]
        mode = sp[4] if len(sp) > 4 else "center"
        box = _part_aabb(scene, part)
        if box is None:
            results.append({"label": label, "status": "MISSING PART"})
            bad.append(label)
            continue
        k = _AX[axis]
        pos = (box[0][k] if mode == "min" else box[1][k] if mode == "max"
               else (box[0][k] + box[1][k]) / 2.0)
        diff = abs(pos - exp)
        ok = diff <= tol
        results.append({"label": label, "axis": axis, "pos": round(pos, 3),
                        "expected": exp, "diff": round(diff, 3), "ok": ok})
        if not ok:
            bad.append(label)
    report = {"placements": results, "off": bad, "ok": not bad, "tol": tol}
    if print_it:
        print(format_placement(report))
    return report


def format_placement(report):
    lines = ["=== PLACEMENT CHECK: %s (tol %.3f) ===" % (
        "OK" if report["ok"] else "OFF", report["tol"])]
    for r in report["placements"]:
        if "status" in r:
            lines.append("  %-22s %s" % (r["label"], r["status"]))
        else:
            lines.append("  %-22s %s=%.3f expected=%.3f diff=%.3f%s" % (
                r["label"], r["axis"], r["pos"], r["expected"], r["diff"],
                "" if r["ok"] else "  <-OFF"))
    return "\n".join(lines)


def _principal_axis(obj):
    """Dominant axis (unit vector, world space) of the mesh point cloud via power
    iteration on the covariance matrix — for an elongated part (barrel, mast,
    funnel) this IS its long axis, so it captures rake/elevation that an
    axis-aligned bbox would miss. Returns None for <2 verts."""
    mw = obj.matrix_world
    pts = [mw @ v.co for v in obj.data.vertices]
    n = len(pts)
    if n < 2:
        return None
    cx = sum(p.x for p in pts) / n
    cy = sum(p.y for p in pts) / n
    cz = sum(p.z for p in pts) / n
    cxx = cxy = cxz = cyy = cyz = czz = 0.0
    for p in pts:
        dx, dy, dz = p.x - cx, p.y - cy, p.z - cz
        cxx += dx * dx; cxy += dx * dy; cxz += dx * dz
        cyy += dy * dy; cyz += dy * dz; czz += dz * dz
    C = ((cxx, cxy, cxz), (cxy, cyy, cyz), (cxz, cyz, czz))
    v = [1.0, 0.3, 0.17]                       # seed off the principal axes
    for _ in range(50):
        nv = [C[0][0] * v[0] + C[0][1] * v[1] + C[0][2] * v[2],
              C[1][0] * v[0] + C[1][1] * v[1] + C[1][2] * v[2],
              C[2][0] * v[0] + C[2][1] * v[1] + C[2][2] * v[2]]
        m = math.sqrt(nv[0] ** 2 + nv[1] ** 2 + nv[2] ** 2) or 1e-12
        v = [nv[0] / m, nv[1] / m, nv[2] / m]
    return mathutils.Vector(v)


def check_angles(scene=None, specs=None, tol_deg=6.0, print_it=True):
    """ANGLE check: is a part ORIENTED right (barrel elevation, funnel/mast rake,
    turret facing)? Each spec is (label, part, expected_dir, [tol_deg]) where
    expected_dir=(x,y,z) is the world direction the part's LONG axis should lie
    along (SIGN-AGNOSTIC — (1,0,0) and (-1,0,0) are the same line). Computes the
    part's principal axis (PCA) and flags angle > tol.

    e.g. ('barrels level','T1Bbl',(1,0,0)) horizontal; ('mast vertical','Mainmast',
    (0,0,1)); ('funnel rake','Funnel',(math.sin(r),0,math.cos(r))) raked back."""
    scene = scene or bpy.context.scene
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    results, bad = [], []
    for sp in (specs or []):
        label, part, exp = sp[0], sp[1], sp[2]
        tol = sp[3] if len(sp) > 3 else tol_deg
        obj = _obj_by_name(scene, part)
        if obj is None:
            results.append({"label": label, "status": "MISSING PART"})
            bad.append(label)
            continue
        pa = _principal_axis(obj)
        e = mathutils.Vector(exp)
        if pa is None or e.length < 1e-9:
            results.append({"label": label, "status": "DEGENERATE"})
            bad.append(label)
            continue
        cosang = min(1.0, max(-1.0, abs(pa.dot(e.normalized()))))
        ang = math.degrees(math.acos(cosang))
        ok = ang <= tol
        results.append({"label": label, "angle_deg": round(ang, 2),
                        "tol_deg": tol, "ok": ok})
        if not ok:
            bad.append(label)
    report = {"angles": results, "off": bad, "ok": not bad}
    if print_it:
        print(format_angles(report))
    return report


def check_clearance(scene=None, specs=None, print_it=True):
    """PLACEMENT-LOGIC check: do feature parts respect a functional KEEP-OUT zone
    (e.g. parked aircraft must stay CLEAR of the carrier's landing area; furniture
    clear of a doorway swing; props clear of a player path)? Each spec is
    (label, zone, prefixes) where zone=(cx, cy, half_x, half_y, rot_z_deg) is a
    rectangle in the XY plane (any z) and prefixes is a list of object-name
    prefixes to test. A part VIOLATES if its XY footprint intrudes the zone.
    Flags every intruding part. This enforces that placement follows a RULE, not
    eyeballing."""
    scene = scene or bpy.context.scene
    try:
        bpy.context.view_layer.update()
    except Exception:
        pass
    results, bad = [], []
    for sp in (specs or []):
        label, zone, prefixes = sp[0], sp[1], sp[2]
        cx, cy, hx, hy, rot = zone
        ca, sa = math.cos(math.radians(-rot)), math.sin(math.radians(-rot))
        intruders = []
        for obj in scene.objects:
            if obj.type != "MESH" or obj.hide_render:
                continue
            if not any(obj.name.startswith(p) for p in prefixes):
                continue
            mn, mx = world_aabb(obj)
            # test the part's 4 AABB corners in the zone-local frame (a
            # circumscribed circle false-positives long thin parts by up to
            # half their length)
            hit = False
            for px, py in ((mn[0], mn[1]), (mn[0], mx[1]),
                           (mx[0], mn[1]), (mx[0], mx[1])):
                dx, dy = px - cx, py - cy
                lx = dx * ca - dy * sa                        # into zone-local frame
                ly = dx * sa + dy * ca
                if abs(lx) < hx and abs(ly) < hy:
                    hit = True
                    break
            # corners alone miss a part whose footprint swallows the zone;
            # the zone centre inside the part's AABB catches that case
            if not hit and mn[0] <= cx <= mx[0] and mn[1] <= cy <= mx[1]:
                hit = True
            if hit:
                intruders.append(obj.name)
        ok = not intruders
        results.append({"label": label, "intruders": intruders, "ok": ok})
        if not ok:
            bad.append(label)
    report = {"clearances": results, "off": bad, "ok": not bad}
    if print_it:
        print(format_clearance(report))
    return report


def format_clearance(report):
    lines = ["=== CLEARANCE CHECK: %s ===" % ("OK" if report["ok"] else "INTRUSION")]
    for r in report["clearances"]:
        if r["ok"]:
            lines.append("  %-22s clear" % r["label"])
        else:
            shown = ", ".join(r["intruders"][:8]) + (
                " …(+%d)" % (len(r["intruders"]) - 8) if len(r["intruders"]) > 8 else "")
            lines.append("  %-22s INTRUDERS: %s  <-keep clear" % (r["label"], shown))
    return "\n".join(lines)


def format_angles(report):
    lines = ["=== ANGLE CHECK: %s ===" % ("OK" if report["ok"] else "OFF")]
    for r in report["angles"]:
        if "status" in r:
            lines.append("  %-22s %s" % (r["label"], r["status"]))
        else:
            lines.append("  %-22s off-axis=%.2f deg (tol %.1f)%s" % (
                r["label"], r["angle_deg"], r["tol_deg"], "" if r["ok"] else "  <-OFF"))
    return "\n".join(lines)


def format_alignment(report):
    if not report.get("applicable", True):
        return "=== AXIS ALIGNMENT: n/a (need >=2 parts) ==="
    lines = ["=== AXIS ALIGNMENT (%s-axis): %s ===" % (
        report["long_axis"], "ALIGNED" if report["ok"] else "OFF-AXIS PARTS")]
    lines.append("  central axis at %s ; centre-of-gravity %s ; tol %.3f" % (
        report["axis_perp_pos"], report["cog"], report["tol"]))
    for c in sorted(report["components"], key=lambda r: -r["offset"]):
        flag = "  <-OFF-AXIS" if c["name"] in report["off_axis"] else ""
        lines.append("  %-14s offset=%.4f  perp=%s%s" % (
            c["name"], c["offset"], c["perp"], flag))
    if not report["ok"]:
        lines.append("  -> centre every part on the SAME axis (set the perpendicular "
                     "coords equal); don't rest mismatched-thickness parts on the floor.")
    return "\n".join(lines)
