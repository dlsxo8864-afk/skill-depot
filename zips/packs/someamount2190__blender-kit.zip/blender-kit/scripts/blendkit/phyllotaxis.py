"""phyllotaxis.py — nature's PLACEMENT rules, as code.

Real plants don't space organs evenly; they follow mathematical patterns that
pack tightly and avoid overlap. Building with these makes models read as GROWN,
not assembled. Grounded in: Wikipedia 'Phyllotaxis'; Vogel 1979 spiral model;
Lindenmayer L-systems; da Vinci's branch-area rule. See references/patterns/.

Two layers:
  * PLACEMENT (pure math, no bpy): golden-angle spirals around a stem or on a
    disk — use to scatter leaves/fronds/branches like a real plant.
  * GROWTH (`grow`, uses mathutils): a recursive self-similar branch generator
    (an L-system core) yielding the frame of every branch in a tree.
"""
import math

#: the golden angle = 360 * (1 - 1/phi^2) = 360*(2 - phi). Successive organs in
#: spiral phyllotaxis diverge by this; it is the irrational limit of the
#: Fibonacci divergence fractions (1/2, 1/3, 2/5, 3/8, 5/13, ...).
PHI = (1 + 5 ** 0.5) / 2
GOLDEN_ANGLE_DEG = 360.0 * (2 - PHI)           # 137.50776...
GOLDEN_ANGLE_RAD = math.radians(GOLDEN_ANGLE_DEG)

#: common exact divergence fractions (numerator/denominator are a Fibonacci
#: number and its second successor) -> degrees
DIVERGENCE = {
    "distichous": 180.0, "tristichous": 120.0, "2/5": 144.0,
    "3/8": 135.0, "5/13": 138.46, "golden": GOLDEN_ANGLE_DEG,
}


def fibonacci(k):
    """First k Fibonacci numbers (the spiral counts you see in sunflowers/cones)."""
    seq = [1, 1]
    while len(seq) < k:
        seq.append(seq[-1] + seq[-2])
    return seq[:k]


def spiral_azimuths(n, start=0.0, angle=GOLDEN_ANGLE_DEG):
    """n azimuth angles (deg) for organs placed one after another around a stem,
    each `angle` (default golden) from the last. The natural alternative to an
    even 360/n spacing — no two organs shadow each other."""
    return [(start + i * angle) % 360.0 for i in range(n)]


def vogel_disk(n, scale=1.0, angle=GOLDEN_ANGLE_DEG):
    """Vogel's sunflower model: organ i at r = scale*sqrt(i), theta = i*angle.
    Returns [(x, y)] — the tight spiral packing of a flower head / pinecone face."""
    a = math.radians(angle)
    out = []
    for i in range(n):
        r = scale * math.sqrt(i)
        th = i * a
        out.append((r * math.cos(th), r * math.sin(th)))
    return out


def cylinder_phyllotaxis(n, z0, z1, angle=GOLDEN_ANGLE_DEG, start=0.0, jitter=None):
    """Place n organs spiralling UP a stem from z0 to z1: each at azimuth
    start+i*angle (deg) and a height stepped evenly. Returns [(azimuth_deg, z, t)]
    with t in [0,1] the height fraction (use it to taper branch length etc.).
    `jitter(i)->(daz, dz)` optional deterministic wobble. The natural replacement
    for rigid even 'whorls'."""
    out = []
    for i in range(n):
        t = i / max(1, n - 1)
        az = (start + i * angle) % 360.0
        z = z0 + t * (z1 - z0)
        if jitter is not None:
            daz, dz = jitter(i)
            az = (az + daz) % 360.0
            z += dz
        out.append((az, z, t))
    return out


def davinci_radius(parent_radius, n_children):
    """Leonardo's rule: the cross-sectional area is conserved across a branch
    point, so each of n equal children has radius = parent / sqrt(n)."""
    return parent_radius / math.sqrt(max(1, n_children))


def grow(length, depth, children=3, length_ratio=0.62, branch_angle=32.0,
         divergence=GOLDEN_ANGLE_DEG, child_start=0.35, pos=None, direction=None,
         _seed=0):
    """Recursive self-similar branch layout (L-system core). Yields the FRAME of
    every branch as (pos, direction, length, depth) — pos/direction are
    mathutils.Vectors. The caller builds a limb mesh from pos along direction.

    children: sub-branches per branch; length_ratio: child/parent length (~1/phi
    is natural); branch_angle: polar tilt of a child from its parent (deg);
    divergence: azimuth step between successive children (golden by default ->
    phyllotactic). Self-similar => a few levels fill space the way a real tree does.
    """
    import mathutils
    pos = mathutils.Vector(pos) if pos is not None else mathutils.Vector((0, 0, 0))
    up = (mathutils.Vector(direction) if direction is not None
          else mathutils.Vector((0, 0, 1))).normalized()
    yield (pos, up, length, depth)
    if depth <= 0:
        return
    perp = up.orthogonal().normalized()
    ba = math.radians(branch_angle)
    ga = math.radians(divergence)
    for i in range(children):
        f = child_start + (1 - child_start) * (i / children)   # point along parent
        cpos = pos + up * (length * f)
        side = mathutils.Quaternion(up, ga * (i + _seed)) @ perp  # phyllotactic azimuth
        cdir = (up * math.cos(ba) + side * math.sin(ba)).normalized()
        yield from grow(length * length_ratio, depth - 1, children, length_ratio,
                        branch_angle, divergence, child_start, cpos, cdir, _seed + i + 1)
