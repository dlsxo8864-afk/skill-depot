"""blendkit — deterministic Blender helpers for the blender-kit skill.

Import convention inside a Blender script run with `blender -b --python foo.py`:

    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__)))  # the scripts/ dir
    from blendkit import build, transform, material, light, camera, render, inspect, preflight, compat

All geometry is created with the bpy *data* API + bmesh, never bpy.ops, so it
runs identically in headless/background mode with no context dependency.

Lengths are METERS. Angles passed to transform helpers are DEGREES.
"""

__all__ = [
    "compat",
    "transform",
    "build",
    "material",
    "light",
    "camera",
    "render",
    "preflight",
    "inspect",
    "inspect_core",
    "debug",
    "detail",
    "human",
]

__version__ = "0.1.0"
