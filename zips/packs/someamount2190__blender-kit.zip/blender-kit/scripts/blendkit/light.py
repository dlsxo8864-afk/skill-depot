"""light.py — lighting rigs built with the data API.

three_point() is the safe default for product/blockout shots; sun() for
exterior; world_sky() for ambient fill.
"""

import math

import bpy
import mathutils

from . import transform


def _add_light(name, ltype, energy, location, collection=None):
    data = bpy.data.lights.new(name, type=ltype)
    data.energy = energy
    ob = bpy.data.objects.new(name, data)
    target = collection if collection is not None else bpy.context.scene.collection
    target.objects.link(ob)
    ob.location = location
    return ob


def sun(name="Sun", energy=4.0, angle_deg=(50, 0, 30), collection=None):
    """Directional sun. `angle_deg` is the light's XYZ Euler in degrees."""
    ob = _add_light(name, "SUN", energy, (0, 0, 10), collection)
    transform.set_rotation_deg(ob, *angle_deg)
    return ob


def three_point(target=(0, 0, 0), distance=8.0, height=4.0,
                key_energy=None, fill_energy=None, rim_energy=None,
                collection=None):
    """Classic key/fill/rim rig aimed at `target`. Returns dict of the three
    light objects. `target` may be a 3-tuple or a bpy object.

    Energies default to AUTO-SCALED by (distance/8)^2 from the 1000/300/600 W
    baseline (Gate-9.7 fix: the fixed 1000 W baseline was calibrated for ~8 m
    scenes — at prop scale, distance ~2, it was ~13x overexposed, washing
    metals to white and killing contact shadows). The softbox size scales with
    distance too, so close rigs still cast readable shadows. Pass explicit
    energies to override the auto-scaling."""
    if hasattr(target, "matrix_world"):
        ctr = target.matrix_world.to_translation()
    else:
        ctr = mathutils.Vector(target)

    s = (max(distance, 0.1) / 8.0) ** 2
    if key_energy is None:
        key_energy = 1000.0 * s
    if fill_energy is None:
        fill_energy = 300.0 * s
    if rim_energy is None:
        rim_energy = 600.0 * s

    def area(name, offset, energy):
        ob = _add_light(name, "AREA", energy,
                        (ctr.x + offset[0], ctr.y + offset[1], ctr.z + offset[2]),
                        collection)
        ob.data.size = max(3.0 * (distance / 8.0), 0.25)
        transform.look_at(ob, ctr)
        return ob

    key = area("Key", (distance * 0.7, -distance * 0.7, height), key_energy)
    fill = area("Fill", (-distance * 0.8, -distance * 0.4, height * 0.6), fill_energy)
    rim = area("Rim", (0.0, distance * 0.9, height * 1.2), rim_energy)
    return {"key": key, "fill": fill, "rim": rim}


def world_sky(strength=1.0, color=(0.05, 0.06, 0.08, 1.0)):
    """Flat ambient world light so nothing renders pure black. Returns world."""
    scene = bpy.context.scene
    world = scene.world or bpy.data.worlds.new("World")
    scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg is None:
        bg = world.node_tree.nodes.new("ShaderNodeBackground")
        out = world.node_tree.nodes.get("World Output") or \
            world.node_tree.nodes.new("ShaderNodeOutputWorld")
        world.node_tree.links.new(bg.outputs["Background"], out.inputs["Surface"])
    bg.inputs["Color"].default_value = color
    bg.inputs["Strength"].default_value = strength
    return world
