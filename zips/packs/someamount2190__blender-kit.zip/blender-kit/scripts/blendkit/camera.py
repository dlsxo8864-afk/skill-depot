"""camera.py — cameras + auto-framing.

frame_scene() computes the scene's world AABB and places a camera that fits the
whole thing in view (no clipping, no tiny-subject-in-the-distance), so you don't
have to guess coordinates.
"""

import math

import bpy
import mathutils

from . import inspect as bk_inspect
from . import inspect_core as bk_core
from . import transform


def add_camera(name="Camera", location=(0, -10, 6), look=(0, 0, 0),
               lens_mm=50.0, collection=None, make_active=True):
    data = bpy.data.cameras.new(name)
    data.lens = lens_mm
    ob = bpy.data.objects.new(name, data)
    target = collection if collection is not None else bpy.context.scene.collection
    target.objects.link(ob)
    ob.location = location
    transform.look_at(ob, look)
    if make_active:
        bpy.context.scene.camera = ob
    return ob


#: object name fragments treated as background context, not framing subjects
FLOOR_NAMES = ("Ground", "Floor")


def _scene_aabb(scene, ignore_names=FLOOR_NAMES):
    """AABB of the framing subjects. By default a large floor plane is excluded
    so the camera frames the actual props, not the empty floor. Falls back to
    ALL geometry when excluding would leave nothing (e.g. an empty stage)."""
    objs = bk_inspect.collect(scene)
    if not objs:
        return None
    if ignore_names:
        # audit fix: shared exact-or-ground-pattern matcher (the old substring
        # test silently exempted props like "FloorLamp"/"Foreground")
        subjects = [o for o in objs
                    if not bk_core.name_is_ignored(o["name"], ignore_names)]
        if subjects:
            objs = subjects  # only narrow when subjects remain
    lo = [min(o["bbox_min"][i] for o in objs) for i in range(3)]
    hi = [max(o["bbox_max"][i] for o in objs) for i in range(3)]
    return mathutils.Vector(lo), mathutils.Vector(hi)


def frame_scene(scene=None, name="Camera", direction=(1.0, -1.0, 0.6),
                lens_mm=50.0, margin=1.25, make_active=True, collection=None,
                ignore_names=FLOOR_NAMES):
    """Auto-frame the whole scene. Places a camera along `direction` from the
    scene center, far enough that the bounding sphere fits the field of view
    with `margin` headroom. Sets clip planes to enclose the scene. Returns the
    camera object.
    """
    scene = scene or bpy.context.scene
    bounds = _scene_aabb(scene, ignore_names)
    if bounds is None:
        return add_camera(name, lens_mm=lens_mm, collection=collection,
                          make_active=make_active)
    lo, hi = bounds
    center = (lo + hi) * 0.5
    radius = max((hi - lo).length * 0.5, 1e-3)

    data = bpy.data.cameras.new(name)
    data.lens = lens_mm
    # Fit the bounding SPHERE to the SMALLER of the horizontal/vertical FOV, so a
    # non-square render aspect can't clip the scene top/bottom (or sides). With
    # sensor_fit=AUTO the FOV axis follows the longer render dimension.
    sensor = data.sensor_width  # mm, default 36
    rx = max(scene.render.resolution_x, 1)
    ry = max(scene.render.resolution_y, 1)
    if rx >= ry:
        sensor_x, sensor_y = sensor, sensor * ry / rx
    else:
        sensor_x, sensor_y = sensor * rx / ry, sensor
    half_fov_x = math.atan((sensor_x * 0.5) / lens_mm)
    half_fov_y = math.atan((sensor_y * 0.5) / lens_mm)
    half_fov = min(half_fov_x, half_fov_y)
    dist = (radius * margin) / math.sin(half_fov)

    d = mathutils.Vector(direction)
    if d.length < 1e-9:
        d = mathutils.Vector((0, -1, 0))
    d.normalize()
    cam_loc = center + d * dist

    ob = bpy.data.objects.new(name, data)
    target = collection if collection is not None else scene.collection
    target.objects.link(ob)
    ob.location = cam_loc
    transform.look_at(ob, center)

    # Audit fix: clip planes must enclose everything RENDERED, not just the
    # framing subjects — the ground plane is excluded from framing but is in
    # the frame, and clip planes derived from the subject sphere visibly cut
    # the floor near and far. Use the FULL scene bounds for clipping.
    full = _scene_aabb(scene, ignore_names=None)
    f_lo, f_hi = full if full is not None else (lo, hi)
    f_center = (f_lo + f_hi) * 0.5
    f_radius = max((f_hi - f_lo).length * 0.5, radius)
    d_full = (mathutils.Vector(cam_loc) - f_center).length
    data.clip_start = max(0.01, d_full - f_radius * 1.05)
    data.clip_end = d_full + f_radius * 1.05
    if make_active:
        scene.camera = ob
    return ob


def frame_scene_ortho_top(scene=None, name="BlueprintCam", margin=1.15,
                          make_active=False, collection=None,
                          ignore_names=FLOOR_NAMES):
    """Orthographic top-down 'blueprint' camera that fits the scene footprint."""
    scene = scene or bpy.context.scene
    bounds = _scene_aabb(scene, ignore_names)
    data = bpy.data.cameras.new(name)
    data.type = "ORTHO"
    if bounds is not None:
        lo, hi = bounds
        center = (lo + hi) * 0.5
        fx = max(hi.x - lo.x, 1e-3)
        fy = max(hi.y - lo.y, 1e-3)
        # ortho_scale maps to the LONGER render axis (sensor_fit=AUTO); size it so
        # BOTH footprint axes fit with margin regardless of render aspect ratio,
        # otherwise the blueprint clips the scene on the short axis.
        rx = max(scene.render.resolution_x, 1)
        ry = max(scene.render.resolution_y, 1)
        if rx >= ry:
            ortho = max(fx, fy * rx / ry)
        else:
            ortho = max(fy, fx * ry / rx)
        data.ortho_scale = ortho * margin
        footprint = max(fx, fy)
        cam_z = hi.z + max(footprint, 1.0)
        loc = (center.x, center.y, cam_z)
        # Audit fix: the Blender default clip_end=100 left any scene deeper
        # than ~100m (a 250m ship seen from cam_z ~ 500m) entirely beyond the
        # far plane -> empty "blueprint". Enclose the full scene depth.
        full = _scene_aabb(scene, ignore_names=None)
        low_z = full[0].z if full is not None else lo.z
        data.clip_start = 0.01
        data.clip_end = (cam_z - low_z) * 1.2 + 1.0
    else:
        center = mathutils.Vector((0, 0, 0))
        data.ortho_scale = 10
        loc = (0, 0, 10)
        data.clip_start = 0.01
        data.clip_end = 100.0
    ob = bpy.data.objects.new(name, data)
    target = collection if collection is not None else scene.collection
    target.objects.link(ob)
    ob.location = loc
    transform.look_at(ob, (center.x, center.y, 0))  # straight down
    if make_active:
        scene.camera = ob
    return ob


def frame_object(names=None, scene=None, direction=(1.0, -1.0, 0.7), lens_mm=85.0,
                 margin=1.35, name="detail_cam", make_active=True,
                 collection=None, bbox=None):
    """Close-up camera framed on ONE part (or a group): `names` is an object
    name, an object, or a list of either — the combined AABB is framed.
    Alternatively pass `bbox=((x0,y0,z0),(x1,y1,z1))` to frame an explicit
    world-space REGION (e.g. the fuller groove of a blade, a seam) that is not
    its own object.

    The intricacy-verification counterpart of frame_scene: a whole-model
    contact sheet can't judge a 4 cm bolt ring, so each feature part gets its
    own framed view (see render.detail_views). Long lens (85mm default)
    flattens perspective the way you'd inspect a real part. Clip planes still
    enclose the FULL scene so surrounding context stays visible behind the
    part. Reuses/replaces any camera with the same `name`."""
    scene = scene or bpy.context.scene
    if bbox is not None:
        lo = mathutils.Vector(bbox[0])
        hi = mathutils.Vector(bbox[1])
    else:
        if not isinstance(names, (list, tuple, set)):
            names = [names]
        wanted = {n if isinstance(n, str) else n.name for n in names}
        objs = [o for o in bk_inspect.collect(scene) if o["name"] in wanted]
        if not objs:
            raise ValueError("frame_object: no mesh matches %s" % sorted(wanted))
        lo = mathutils.Vector([min(o["bbox_min"][i] for o in objs) for i in range(3)])
        hi = mathutils.Vector([max(o["bbox_max"][i] for o in objs) for i in range(3)])
    center = (lo + hi) * 0.5
    radius = max((hi - lo).length * 0.5, 1e-3)

    old = bpy.data.objects.get(name)
    if old is not None:
        bpy.data.objects.remove(old, do_unlink=True)

    data = bpy.data.cameras.new(name)
    data.lens = lens_mm
    sensor = data.sensor_width
    rx = max(scene.render.resolution_x, 1)
    ry = max(scene.render.resolution_y, 1)
    if rx >= ry:
        sensor_x, sensor_y = sensor, sensor * ry / rx
    else:
        sensor_x, sensor_y = sensor * rx / ry, sensor
    half_fov = min(math.atan((sensor_x * 0.5) / lens_mm),
                   math.atan((sensor_y * 0.5) / lens_mm))
    dist = (radius * margin) / math.sin(half_fov)

    d = mathutils.Vector(direction)
    if d.length < 1e-9:
        d = mathutils.Vector((0, -1, 0))
    d.normalize()
    cam_loc = center + d * dist

    ob = bpy.data.objects.new(name, data)
    target = collection if collection is not None else scene.collection
    target.objects.link(ob)
    ob.location = cam_loc
    transform.look_at(ob, center)

    full = _scene_aabb(scene, ignore_names=None)
    f_lo, f_hi = full if full is not None else (lo, hi)
    f_center = (f_lo + f_hi) * 0.5
    f_radius = max((f_hi - f_lo).length * 0.5, radius)
    d_full = (mathutils.Vector(cam_loc) - f_center).length
    data.clip_start = max(0.005, dist - radius * margin - radius)
    data.clip_end = d_full + f_radius * 1.05
    if make_active:
        scene.camera = ob
    return ob


def orbit_positions(center=(0, 0, 0), radius=10.0, height=4.0, count=8):
    """Return `count` camera positions evenly spaced on a circle around
    `center`, for turntable-style multi-view rendering."""
    cx, cy, cz = center
    out = []
    for i in range(count):
        a = 2.0 * math.pi * i / count
        out.append((cx + radius * math.cos(a), cy + radius * math.sin(a), cz + height))
    return out
