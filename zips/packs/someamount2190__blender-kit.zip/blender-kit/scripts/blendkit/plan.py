"""plan.py — the DESIGN GATE. Make the design phase un-skippable: a build must
produce a filled BUILD PLAN before any geometry, and `design_gate` rides on
`preflight` (already mandatory before every render) so an incomplete plan ABORTS
the render.

Why this exists: a 3D anime head was attempted by jumping straight to geometry
with only proportions researched — no construction-method ("HOW") research, no
failure research, no plan. It came out broken (flat hair shards, melty eyes).
The loop started at `build`; design was optional prose. This module makes design
a hard gate. See sops/07-design-first.md and references/failures/skipped-design-phase.

  scaffold("anime head") -> writes _tmp/<slug>_plan.md (the form to fill)
  design_gate(plan_path) -> {ok, incomplete}; preflight.check(plan_path=...) fails
                            with a blocking error until every required section is filled.
"""
import os
import re

# sections the plan MUST fill before geometry. 3 (HOW) and 4 (FAILURES) are the
# ones most often skipped — they are mandatory, not optional.
REQUIRED = {
    "1": "WHAT — proportions & ratios (sourced held belief)",
    "2": "VISUAL — reference(s) fetched AND viewed",
    "3": "HOW — construction method per the craft (topology / parts / per-class technique)",
    "4": "FAILURES — common mistakes for THIS object + the check that catches each",
    "5": "FEATURE PARTS — the identity/function parts: real design + placement LOGIC (designed FIRST)",
    "6": "DECOMPOSE — part -> technique -> check (the build plan)",
}
_PLACEHOLDER = re.compile(r"\bTODO\b|\bFIXME\b|<fill[^>]*>|<\.\.\.>|<your", re.I)
_TEMPLATE = """# BUILD PLAN — {name}
<!-- SOP-07. Fill EVERY numbered section below. Geometry is FORBIDDEN until
plan.design_gate() passes (no TODO/<...> left, each section has real content).
preflight.check(plan_path=THIS) aborts the render while this is incomplete. -->

## 1. WHAT — proportions & ratios (sourced held belief)
TODO: 5-10 sourced numbers; key part-to-part RATIOS vs a primary dimension; cite
the sources. (Then verify at ship with inspect.check_ratios / check_placement.)

## 2. VISUAL — reference(s) fetched AND viewed
TODO: run scripts/fetch_reference.py; list references/refs/<slug>.* paths, what
each view shows, and confirm you VIEWED each with the Read tool (not just fetched).

## 3. HOW — construction method (research the CRAFT, not your prior)
TODO: search "how to model a <X> (3d topology / hair / eyes / ...)" AND read
references/techniques/INDEX.md. State the METHOD used by practitioners for this
object CLASS — the part breakdown and the technique for each tricky part. (This
is the step whose absence broke the anime head: e.g. anime hair = strips/cards
that HUG the skull, not flat shards; eyes = eyeball + lid or a flat decal on a
FLAT facial plane, kept concentric.)

## 4. FAILURES — common mistakes + the check that catches each
TODO: read references/failures/INDEX.md AND search "common mistakes modeling a
<X>". List the specific traps for THIS build, each with the guard
(failure_scan / topology / ratio / placement / alignment / angle / seam close-up).

## 5. FEATURE PARTS — identify the identity/function parts; DESIGN them first
TODO: name the parts an expert looks at first — the object's IDENTITY + FUNCTION,
NOT the body/mass (carrier = aircraft + island; tank = turret + gun; cathedral =
spire + facade; pistol = slide + grip). The body exists to SUPPORT these — design
these FIRST and to a HIGHER standard. For EACH feature part give BOTH:
  (a) REAL DESIGN — a part breakdown / detail floor: articulated geometry that
      reads as the actual thing, NOT one primitive or a random blob (e.g. carrier
      jet = nose + fuselage + swept wings + twin tails + intakes + canopy, not a
      delta slab; island = bridge + PriFly + mast + radar arrays + funnel).
  (b) PLACEMENT LOGIC — the functional/doctrinal RULE that fixes WHERE it goes and
      HOW it is oriented (NOT eyeballed/scattered): e.g. aircraft spotted CLEAR of
      the landing area (foul line), along the deck edges, noses outboard; island
      at the starboard deck edge ~58% aft for clearance/visibility.
Verify the logic with inspect.check_placement / check_clearance (keep-out zones),
not just by eye.

## 6. DECOMPOSE — part -> technique -> check (the plan)
TODO: one row per part; feature parts FIRST (highest detail), body parts after.
| part | construction technique (from #3) | placement logic (from #5) | check |
|------|----------------------------------|---------------------------|-------|
| ...  | ...                              | ...                       | ...   |

## 7. OPEN QUESTIONS / risks
(optional — note unknowns, or "none")
"""


def slugify(s):
    return re.sub(r"[^a-z0-9]+", "-", s.strip().lower()).strip("-") or "unnamed"


def plan_path_for(name, out_dir):
    return os.path.join(out_dir, slugify(name) + "_plan.md")


def scaffold(name, out_dir, overwrite=False):
    """Write the plan template for `name` into out_dir; return its path. Starting
    a representational build = run this FIRST, then fill it (SOP-07 D0)."""
    os.makedirs(out_dir, exist_ok=True)
    path = plan_path_for(name, out_dir)
    if os.path.exists(path) and not overwrite:
        return path
    with open(path, "w", encoding="utf-8") as f:
        f.write(_TEMPLATE.format(name=name))
    return path


def _sections(text):
    out, cur, buf = {}, None, []
    for line in text.splitlines():
        m = re.match(r"^##\s+(\d+)\.", line)
        if m:
            if cur is not None:
                out[cur] = "\n".join(buf).strip()
            cur, buf = m.group(1), []
        elif cur is not None:
            buf.append(line)
    if cur is not None:
        out[cur] = "\n".join(buf).strip()
    return out


def design_gate(plan_path, min_chars=40):
    """Return {ok, incomplete, reason}. A section is incomplete if it is missing,
    still holds a TODO/<...> placeholder, or is too short to be real content."""
    if not plan_path or not os.path.exists(plan_path):
        return {"ok": False, "incomplete": list(REQUIRED),
                "reason": "no BUILD PLAN — run plan.scaffold(name, _tmp) and fill it (SOP-07)"}
    with open(plan_path, "r", encoding="utf-8") as f:
        secs = _sections(f.read())
    incomplete = []
    for num in REQUIRED:
        body = secs.get(num, "")
        if not body or _PLACEHOLDER.search(body) or len(body) < min_chars:
            incomplete.append(num)
    return {"ok": not incomplete, "incomplete": incomplete,
            "reason": "" if not incomplete else "sections not filled: "
            + ", ".join("%s (%s)" % (n, REQUIRED[n]) for n in incomplete)}


def format_gate(report, plan_path=""):
    lines = ["=== DESIGN GATE: %s ===" % ("PASS" if report["ok"] else "BLOCK")]
    if report["ok"]:
        lines.append("  build plan complete — geometry allowed")
    else:
        lines.append("  %s" % report["reason"])
        lines.append("  -> %s" % (plan_path or "the build plan"))
        lines.append("  NO GEOMETRY until the plan is filled (SOP-07).")
    return "\n".join(lines)


_SUBBUILD = re.compile(r"^\s*sub-build:\s*(\S+)", re.I | re.M)


def declared_subbuilds(plan_path):
    """Sub-build declarations in the plan (Gate 2.8). Syntax, one per line,
    anywhere in the plan (conventionally section 6):
        sub-build: _tmp/<slug>/build_<part>.py
    Paths are resolved relative to the skill root (two dirs above scripts/)."""
    if not plan_path or not os.path.exists(plan_path):
        return []
    with open(plan_path, "r", encoding="utf-8", errors="replace") as f:
        txt = f.read()
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    out = []
    for m in _SUBBUILD.finditer(txt):
        sp = m.group(1)
        out.append(sp if os.path.isabs(sp) else os.path.join(root, sp))
    return out
