"""preflight.py — cheap checks BEFORE a slow render, so we abort early if the
frame is guaranteed garbage (no light, camera aimed at nothing, NaNs).

check(scene) returns a dict {ok, errors, warnings}. Treat `errors` as blocking.
"""

import math
import os

import bpy
import mathutils

from . import inspect as bk_inspect
from . import inspect_core as bk_core
from . import plan as bk_plan
from . import ledger as bk_ledger

#: skill root = parent of scripts/ (this file lives in scripts/blendkit/)
_SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _resolve_plan_path(plan_path):
    """Audit fix: SOPs pass the relative `_tmp/<slug>_plan.md`, but Blender's
    CWD is wherever the terminal was — a genuinely filled plan then looked
    missing and the gate blocked with a misleading 'no BUILD PLAN'. Resolve
    relative paths against the CWD first, then the skill root."""
    if os.path.isabs(plan_path) or os.path.exists(plan_path):
        return plan_path
    alt = os.path.join(_SKILL_ROOT, plan_path)
    return alt if os.path.exists(alt) else plan_path


def _is_finite_vec(v):
    return all(math.isfinite(c) for c in v)


def _scene_bounds(objects):
    if not objects:
        return None
    mins = [o["bbox_min"] for o in objects]
    maxs = [o["bbox_max"] for o in objects]
    lo = (min(m[0] for m in mins), min(m[1] for m in mins), min(m[2] for m in mins))
    hi = (max(m[0] for m in maxs), max(m[1] for m in maxs), max(m[2] for m in maxs))
    return lo, hi


def check(scene=None, require_light=True, camera_cone_deg=70.0, plan_path=None):
    """Cheap pre-render gate. For a representational / multi-part / character /
    organic build, PASS plan_path=_tmp/<slug>_plan.md — the DESIGN GATE then rides
    here (preflight is already mandatory before every render) and ABORTS the
    render while the BUILD PLAN is incomplete (SOP-07). Omit plan_path only for an
    abstract/primitive blockout that legitimately needs no design phase."""
    scene = scene or bpy.context.scene
    errors = []
    warnings = []

    # 0. DESIGN GATE — no geometry/render until the build plan is filled
    if plan_path is not None:
        plan_path = _resolve_plan_path(plan_path)
        g = bk_plan.design_gate(plan_path)
        if not g["ok"]:
            errors.append("DESIGN GATE: %s -> %s (SOP-07; do not render)"
                          % (g["reason"], plan_path))

    meshes = [o for o in scene.objects if o.type == "MESH" and not o.hide_render]
    lights = [o for o in scene.objects if o.type == "LIGHT" and not o.hide_render]

    # 1. geometry exists
    if not meshes:
        errors.append("No renderable mesh objects in scene.")

    # 2. lights exist (Eevee/Cycles render black without emitters or world light)
    # Audit fix: a nodes-enabled world with Background strength 0 emits nothing
    # — it used to count as "lit" and let a guaranteed-black frame through.
    world_lit = False
    if scene.world is not None and getattr(scene.world, "use_nodes", False):
        world_lit = True
        try:
            bg = scene.world.node_tree.nodes.get("Background")
            if bg is not None and float(bg.inputs["Strength"].default_value) <= 0.0:
                world_lit = False
        except Exception:
            pass  # exotic world graphs: keep the permissive default
    if require_light and not lights and not world_lit:
        errors.append("No lights and no world lighting — render will be black.")

    # 3. NaN / non-finite transforms, and zero scale
    for obj in scene.objects:
        if not _is_finite_vec(obj.location):
            errors.append("Object %r has non-finite location %s" % (obj.name, tuple(obj.location)))
        if obj.type == "MESH":
            sx, sy, sz = obj.scale
            if min(abs(sx), abs(sy), abs(sz)) < 1e-7:
                errors.append("Object %r has a zero scale component %s" % (obj.name, tuple(obj.scale)))

    # 4. camera exists and points at the geometry
    cam = scene.camera
    if cam is None:
        errors.append("scene.camera is not set.")
    else:
        objs = bk_inspect.collect(scene)
        # Audit fix: aim the cone test at the SUBJECT center (ground excluded),
        # matching camera.frame_scene — measuring to the full-AABB center let a
        # camera aimed at empty floor pass and a correctly subject-aimed camera
        # fail when a large centered ground skewed the center.
        subjects = [o for o in objs if not bk_core.name_is_ignored(o["name"], ("Ground", "Floor"))]
        bounds = _scene_bounds(subjects if subjects else objs)
        if bounds:
            lo, hi = bounds
            center = mathutils.Vector((
                (lo[0] + hi[0]) / 2, (lo[1] + hi[1]) / 2, (lo[2] + hi[2]) / 2))
            cam_loc = cam.matrix_world.to_translation()
            forward = (cam.matrix_world.to_3x3() @ mathutils.Vector((0, 0, -1)))
            to_center = center - cam_loc
            if to_center.length < 1e-6:
                warnings.append("Camera is sitting on the scene center.")
            elif forward.length > 1e-9:
                forward.normalize()
                ang = math.degrees(math.acos(
                    max(-1.0, min(1.0, forward.dot(to_center.normalized())))))
                if ang > camera_cone_deg:
                    errors.append(
                        "Camera is not pointing at the geometry (%.0f deg off center; "
                        "limit %.0f)." % (ang, camera_cone_deg))

    if plan_path:
        _sb = bk_plan.declared_subbuilds(plan_path)
        if _sb:
            import os as _os
            _probs = bk_ledger.check_subbuilds(_sb, _os.path.dirname)
            for _pr in _probs:
                errors.append("GATE 2.8 (sub-builds first): " + _pr)

    return {"ok": not errors, "errors": errors, "warnings": warnings}


def format_check(result):
    lines = ["=== PREFLIGHT: %s ===" % ("PASS" if result["ok"] else "ABORT")]
    for e in result["errors"]:
        lines.append("  ERROR   " + e)
    for w in result["warnings"]:
        lines.append("  warning " + w)
    if result["ok"] and not result["warnings"]:
        lines.append("  all checks passed")
    return "\n".join(lines)
