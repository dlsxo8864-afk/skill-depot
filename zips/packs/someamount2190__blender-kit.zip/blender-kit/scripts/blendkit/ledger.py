"""ledger.py — the BUILD LEDGER: fail-closed process accounting.

Why this exists: across nine builds (2026-07-04) the prose-mandated phases
(engineer pass, sub-builds, deviation disclosure) eroded silently while every
code-enforced gate held perfectly. Conclusion (user-directed: "gate
everything"): every process phase must leave a machine-checkable record, and
shipping is gated on the record being complete. Drift is allowed to exist —
it is not allowed to be invisible.

The ledger is a JSON file `build_ledger.json` in the build's output dir.
Phases are recorded via `record(out_dir, phase, data)`; validators live with
the recorders so a phase can only be recorded with real evidence on disk.
`scripts/ship_check.py` is the final gate: it refuses PASS until every
required phase is present (and re-validates the evidence).

Pure python (no bpy) so preflight, CLIs and tests can all use it.
"""
import json
import os
import time

LEDGER_NAME = "build_ledger.json"

# phases ship_check requires for every build; sub-builds add subbuild:<name>
REQUIRED_PHASES = ("gates", "critic", "engineer", "deviations")


def ledger_path(out_dir):
    return os.path.join(out_dir, LEDGER_NAME)


def load(out_dir):
    p = ledger_path(out_dir)
    if not os.path.exists(p):
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def record(out_dir, phase, data=None):
    os.makedirs(out_dir, exist_ok=True)
    led = load(out_dir)
    entry = dict(data or {})
    entry["at"] = time.strftime("%Y-%m-%d %H:%M:%S")
    led[phase] = entry
    with open(ledger_path(out_dir), "w", encoding="utf-8") as f:
        json.dump(led, f, indent=1)
    return entry


def record_gates(out_dir, ok, detail=""):
    """Call from the build script's gates block with the combined verdict."""
    return record(out_dir, "gates", {"ok": bool(ok), "detail": str(detail)[:400]})


def record_subbuild(out_dir, script_path, ok):
    """Call from a SUB-BUILD script after its own gates verdict (Gate 2.8)."""
    name = os.path.basename(script_path)
    return record(out_dir, "subbuild:%s" % name, {"ok": bool(ok)})


def _read(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def record_critic(out_dir, critique_file, min_chars=600, min_claims=3):
    """Records the Gate 9.7 critic round. Requires a real critique artifact
    in the SOP-09 structured format: metaphor stays in PERCEPT lines; every
    item carries a checkable CLAIM and its SEEN-IN evidence. Free-prose
    rhetoric is refused — the engineer triages claims, not literature."""
    if not os.path.isfile(critique_file):
        raise ValueError("critic artifact not found: %s" % critique_file)
    txt = _read(critique_file)
    if len(txt) < min_chars:
        raise ValueError("critic artifact too short (%d chars < %d) — save the "
                         "critic's full verbatim output" % (len(txt), min_chars))
    n_claims = txt.upper().count("CLAIM:")
    n_seen = txt.upper().count("SEEN-IN:")
    if n_claims < min_claims or n_seen < min_claims:
        raise ValueError("critique not in SOP-09 structured form (need >=%d "
                         "CLAIM:/SEEN-IN: pairs; found %d/%d). Re-prompt the "
                         "critic with the sops/09-critique-protocol.md contract."
                         % (min_claims, n_claims, n_seen))
    return record(out_dir, "critic",
                  {"file": os.path.abspath(critique_file), "chars": len(txt),
                   "claims": n_claims})


ENGINEER_LABELS = ("FIX-NOW", "ACCEPT", "MISREAD", "KIT-EXTENSION",
                   "READABILITY", "GEOMETRY-TRUE")


def record_engineer(out_dir, triage_file, min_chars=300, min_labels=2):
    """Records the Gate 9.7 ENGINEER pass. The triage artifact must use the
    engineer vocabulary (item labels), which is what distinguishes a real
    triage from a hand-wave."""
    if not os.path.isfile(triage_file):
        raise ValueError("engineer artifact not found: %s" % triage_file)
    txt = _read(triage_file)
    if len(txt) < min_chars:
        raise ValueError("engineer triage too short (%d chars)" % len(txt))
    used = sorted({lb for lb in ENGINEER_LABELS if lb in txt.upper()})
    if len(used) < min_labels:
        raise ValueError("engineer triage must label items (need >=%d of %s; "
                         "found %s)" % (min_labels, "/".join(ENGINEER_LABELS), used))
    return record(out_dir, "engineer",
                  {"file": os.path.abspath(triage_file), "labels": used})


def record_deviations(out_dir, notes):
    """Mandatory disclosure: notes is a list of deviation strings, or [] /
    ['none'] for a clean run. Recording 'none' is a positive claim."""
    if isinstance(notes, str):
        notes = [notes]
    notes = [n.strip() for n in notes if n and n.strip()]
    return record(out_dir, "deviations", {"notes": notes or ["none"]})


def check_subbuilds(plan_declared, out_dir_of):
    """For preflight/ship_check: every declared sub-build script must exist
    and have a green subbuild ledger entry in its own directory.
    plan_declared: list of script paths (as written in the plan).
    out_dir_of: callable path->dir (usually os.path.dirname).
    Returns list of problem strings (empty = ok)."""
    problems = []
    for sp in plan_declared:
        if not os.path.isfile(sp):
            problems.append("sub-build script missing: %s" % sp)
            continue
        led = load(out_dir_of(sp))
        ent = led.get("subbuild:%s" % os.path.basename(sp))
        if not ent:
            problems.append("sub-build has no green ledger entry (run it to "
                            "green gates first): %s" % sp)
        elif not ent.get("ok"):
            problems.append("sub-build recorded FAILED gates: %s" % sp)
    return problems


def finish(out_dir, checks, view_outputs=None):
    """Assemble the build's gate verdict from NAMED checks — fail-closed.

    Why: the Gundam round proved hand-written verdict expressions drift
    (ratios["ok"] was silently omitted and a failing check recorded
    green). Route every check through here instead of and-ing booleans
    by hand.

    checks: dict name -> bool | dict-with-"ok" (inspect.* results work
    as-is). None or a missing "ok" key counts as FAILED (fail-closed).
    view_outputs: iterable of canonical_views/detail_views dicts; every
    per-view entry carrying an "error" fails a named render check.

    Records the gates phase (listing WHAT was checked, so an omitted
    check is visible in the ledger) and returns (ok, failures).
    """
    failures = []
    names = []
    for name, val in checks.items():
        names.append(name)
        if isinstance(val, dict):
            ok_v = val.get("ok", None)
        else:
            ok_v = val
        if ok_v is not True:
            failures.append("%s=%r" % (name, ok_v))
    if view_outputs:
        for outs in view_outputs:
            for key, view in (outs or {}).items():
                if isinstance(view, dict) and view.get("error"):
                    names.append("render:%s" % key)
                    failures.append("render:%s=%s" % (key, view["error"]))
    ok = not failures
    record_gates(out_dir, ok, "checked[%s]%s" % (
        ",".join(names), "" if ok else " FAILED: " + "; ".join(failures)))
    print("GATES_%s %s" % ("OK" if ok else "FAILED",
                           "; ".join(failures) if failures else
                           "(%d checks)" % len(names)))
    return ok, failures
