"""build.py — primitive + array construction via bmesh / data API ONLY.

No bpy.ops anywhere, so nothing depends on the active object, mode, or 3D-view
context. Every function returns the created bpy object.

Sizes are full extents in METERS (a box size=(2,1,1) is 2 m along X).
`location` is the object origin in world space.

Topology: primitives are quad-dominant but cylinders/cones ship n-gon caps and
cones/spheres have tris — fine for still-render blockouts (the default). For
SUBDIVISION / ANIMATION / EXPORT pass `clean=True` to a builder, or run
`cleanup(obj)` on a custom mesh, to merge doubles, de-n-gon (quads where
coplanar), and recalc normals. Audit any scene with `inspect.topology_report()`.
"""

import bmesh
import bpy

import math


def _new_mesh_object(name, collection=None):
    me = bpy.data.meshes.new(name + "_mesh")
    ob = bpy.data.objects.new(name, me)
    target = collection if collection is not None else bpy.context.scene.collection
    target.objects.link(ob)
    return ob, me


def _dengon(bm, quad_fill=True):
    """Remove n-gons WITHOUT leaving holes: triangulate the n-gons, then (if
    quad_fill) recombine coplanar tris back into quads. Reliable where grid-fill
    on a circular cap is not — flat caps become quads, genuine points stay tris."""
    ngons = [f for f in bm.faces if len(f.verts) > 4]
    if not ngons:
        return
    bmesh.ops.triangulate(bm, faces=ngons)
    if quad_fill:
        bmesh.ops.join_triangles(
            bm, faces=list(bm.faces),
            angle_face_threshold=math.radians(60),
            angle_shape_threshold=math.radians(60),
            cmp_seam=False, cmp_sharp=False, cmp_uvs=False, cmp_materials=False)


def _clean_bm(bm, merge_dist=1e-5, quad_fill=True):
    """Mesh-hygiene pass on a bmesh (OPT-IN; off by default for blockout): merge
    double verts, remove n-gons (quads where coplanar, else tris), recalc normals.
    Matters for subdivision / animation / game export — not for still-render
    blockouts, where an n-gon cap is fine."""
    bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=merge_dist)
    _dengon(bm, quad_fill)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))


def _finish(ob, me, bm, location, smooth=None, clean=False):
    """smooth: None -> flat (boxes/planes); 'all' -> every face smooth
    (spheres); 'sides' -> smooth curved sides but keep flat caps (cylinder/cone),
    detected by the face normal being near-vertical.
    clean: run _clean_bm (merge doubles + de-ngon + recalc normals) before commit."""
    bm.normal_update()
    if clean:
        _clean_bm(bm)
    if smooth == "all":
        for f in bm.faces:
            f.smooth = True
    elif smooth == "sides":
        for f in bm.faces:
            f.smooth = abs(f.normal.z) < 0.99  # cap normals are ~±Z -> stay flat
    bm.to_mesh(me)
    bm.free()
    me.update()
    ob.location = tuple(float(c) for c in location)
    return ob


def cleanup(obj, merge_doubles=True, quad_fill=True, recalc_normals=True,
            merge_dist=1e-5):
    """Run the hygiene pass on an EXISTING mesh object (e.g. a custom bmesh build
    like a sword blade). Merges doubles, removes n-gons (quads where possible),
    recalculates normals. Returns the object."""
    if obj.type != "MESH":
        raise TypeError("cleanup() needs a MESH object, got %r" % obj.type)
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    if merge_doubles:
        bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=merge_dist)
    _dengon(bm, quad_fill)
    if recalc_normals:
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return obj


def add_box(name="Box", size=(1.0, 1.0, 1.0), location=(0.0, 0.0, 0.0),
            collection=None, clean=False):
    """Axis-aligned box. `size` = (x,y,z) full extents in meters. Centered on origin."""
    if isinstance(size, (int, float)):
        size = (size, size, size)
    sx, sy, sz = (float(s) for s in size)
    ob, me = _new_mesh_object(name, collection)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)  # unit cube, verts at +/-0.5
    for v in bm.verts:
        v.co.x *= sx
        v.co.y *= sy
        v.co.z *= sz
    return _finish(ob, me, bm, location, clean=clean)


def add_plane(name="Plane", size=(1.0, 1.0), location=(0.0, 0.0, 0.0),
              collection=None, clean=False):
    """Flat quad in the XY plane (z=0 locally). `size` = (x,y) full extents."""
    if isinstance(size, (int, float)):
        size = (size, size)
    sx, sy = (float(s) for s in size)
    ob, me = _new_mesh_object(name, collection)
    bm = bmesh.new()
    hx, hy = sx / 2.0, sy / 2.0
    vs = [
        bm.verts.new((-hx, -hy, 0.0)),
        bm.verts.new((hx, -hy, 0.0)),
        bm.verts.new((hx, hy, 0.0)),
        bm.verts.new((-hx, hy, 0.0)),
    ]
    bm.faces.new(vs)
    return _finish(ob, me, bm, location, clean=clean)


def add_cylinder(name="Cylinder", radius=0.5, height=1.0, segments=32,
                 location=(0.0, 0.0, 0.0), collection=None, clean=False):
    """Z-up cylinder centered on origin, capped. `clean=True` quad-fills the
    n-gon caps (for subdiv/export); default leaves the n-gon caps (fine for stills)."""
    ob, me = _new_mesh_object(name, collection)
    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm,
        cap_ends=True,
        cap_tris=False,
        segments=int(segments),
        radius1=float(radius),
        radius2=float(radius),
        depth=float(height),
    )
    return _finish(ob, me, bm, location, smooth="sides", clean=clean)


def add_cone(name="Cone", radius=0.5, height=1.0, segments=32,
             location=(0.0, 0.0, 0.0), collection=None, clean=False):
    ob, me = _new_mesh_object(name, collection)
    bm = bmesh.new()
    bmesh.ops.create_cone(
        bm, cap_ends=True, cap_tris=False, segments=int(segments),
        radius1=float(radius), radius2=0.0, depth=float(height),
    )
    return _finish(ob, me, bm, location, smooth="sides", clean=clean)


def add_torus(name="Torus", major_radius=0.5, minor_radius=0.05,
              segments=48, sides=10, location=(0.0, 0.0, 0.0),
              collection=None, clean=False):
    """Swept-circle torus, axis +Z, centered on origin (2026-07-06).

    THE ring primitive: 48+ segments reads as forged metal where a chain
    of 12-24 straight members reads as sausage links (mage-gun ITEM 10 /
    thunder-mace triage — both prescribed a swept curve). Rotate with
    transform.set_rotation_deg to aim the axis; e.g. euler (0, 90, a)
    puts the ring's axis in the XY plane at angle -a from +X.
    """
    import math as _math
    ob, me = _new_mesh_object(name, collection)
    bm = bmesh.new()
    seg = max(12, int(segments))
    sid = max(6, int(sides))
    rings = []
    for i in range(seg):
        a = 2.0 * _math.pi * i / seg
        ca, sa = _math.cos(a), _math.sin(a)
        ring = []
        for j in range(sid):
            b = 2.0 * _math.pi * j / sid
            r = major_radius + minor_radius * _math.cos(b)
            ring.append(bm.verts.new((r * ca, r * sa,
                                      minor_radius * _math.sin(b))))
        rings.append(ring)
    for i in range(seg):
        r0, r1 = rings[i], rings[(i + 1) % seg]
        for j in range(sid):
            bm.faces.new((r0[j], r0[(j + 1) % sid],
                          r1[(j + 1) % sid], r1[j]))
    bm.normal_update()
    return _finish(ob, me, bm, location, smooth="all", clean=clean)


def add_uv_sphere(name="Sphere", radius=0.5, segments=32, rings=16,
                  location=(0.0, 0.0, 0.0), collection=None, clean=False):
    ob, me = _new_mesh_object(name, collection)
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(
        bm, u_segments=int(segments), v_segments=int(rings), radius=float(radius),
    )
    return _finish(ob, me, bm, location, smooth="all", clean=clean)


def add_ground(name="Ground", size=20.0, location=(0.0, 0.0, 0.0),
               collection=None, clean=False):
    """Convenience: a large floor plane at z=location.z. Returns the plane."""
    return add_plane(name, size=(size, size), location=location,
                     collection=collection, clean=clean)


# --- duplication helpers --------------------------------------------------

def grid(obj, count_x=3, count_y=3, spacing=(2.0, 2.0), collection=None,
         name=None, linked=True):
    """Tile copies of `obj` on an XY grid. The original occupies cell (0,0).

    Returns the full list of objects (including the original). `linked=True`
    shares mesh data (cheap); False makes independent meshes.
    """
    sx, sy = (float(s) for s in spacing)
    base = obj.location.copy()
    target = collection if collection is not None else (
        obj.users_collection[0] if obj.users_collection else bpy.context.scene.collection
    )
    out = [obj]
    for ix in range(count_x):
        for iy in range(count_y):
            if ix == 0 and iy == 0:
                continue
            copy = _duplicate(obj, target, linked, name, ix, iy)
            copy.location = (base.x + ix * sx, base.y + iy * sy, base.z)
            out.append(copy)
    return out


def array(obj, count=5, offset=(2.0, 0.0, 0.0), collection=None, name=None, linked=True):
    """Linear array of `count` total objects along `offset`."""
    ox, oy, oz = (float(o) for o in offset)
    base = obj.location.copy()
    target = collection if collection is not None else (
        obj.users_collection[0] if obj.users_collection else bpy.context.scene.collection
    )
    out = [obj]
    for i in range(1, count):
        copy = _duplicate(obj, target, linked, name, i, 0)
        copy.location = (base.x + i * ox, base.y + i * oy, base.z + i * oz)
        out.append(copy)
    return out


def _duplicate(obj, target, linked, name, i, j):
    new_name = (name or obj.name) + "_%d_%d" % (i, j)
    if linked:
        data = obj.data
    else:
        data = obj.data.copy()
    copy = bpy.data.objects.new(new_name, data)
    copy.rotation_euler = obj.rotation_euler.copy()
    copy.scale = obj.scale.copy()
    target.objects.link(copy)
    return copy


def catenary_points(p0, p1, sag, n=8):
    """Points along a hanging-strap curve from p0 to p1 (2026-07-06).

    Straight members read as rigid rods (soldier sling triage). This is a
    parabolic approximation of a catenary — indistinguishable at prop
    scale: interpolate linearly, drop z by sag*4*t*(1-t). Chain the
    returned points with member()-style segments (n=6-10 reads draped).
    """
    pts = []
    for i in range(n + 1):
        t = i / float(n)
        pts.append((p0[0] + (p1[0] - p0[0]) * t,
                    p0[1] + (p1[1] - p0[1]) * t,
                    p0[2] + (p1[2] - p0[2]) * t - sag * 4.0 * t * (1.0 - t)))
    return pts
