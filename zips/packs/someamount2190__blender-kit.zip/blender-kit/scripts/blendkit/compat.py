"""compat.py — version detection + Principled BSDF socket shims.

WHY: Blender renamed many Principled BSDF input sockets in 4.0, and 5.x keeps
the new names. Hard-coding 'Specular' or 'Emission' raises KeyError on 4.0+.
This module resolves a *friendly* key to whatever socket actually exists on
this build, so the same calling code works on 3.x, 4.x and 5.x.

Confirmed on this machine: Blender 5.1.2 uses the new names
('Specular IOR Level', 'Emission Color', 'Coat Weight', ...).
"""

import bpy

# Friendly key -> ordered list of candidate socket names (new name first).
# The first candidate that exists on the node is used.
_PRINCIPLED_ALIASES = {
    "base_color":        ["Base Color"],
    "metallic":          ["Metallic"],
    "roughness":         ["Roughness"],
    "ior":               ["IOR"],
    "alpha":             ["Alpha"],
    "normal":            ["Normal"],
    # renamed in 4.0
    "specular":          ["Specular IOR Level", "Specular"],
    "specular_tint":     ["Specular Tint"],
    "emission_color":    ["Emission Color", "Emission"],
    "emission_strength": ["Emission Strength"],
    "transmission":      ["Transmission Weight", "Transmission"],
    "coat":              ["Coat Weight", "Clearcoat"],
    "coat_roughness":    ["Coat Roughness", "Clearcoat Roughness"],
    "sheen":             ["Sheen Weight", "Sheen"],
    "sheen_tint":        ["Sheen Tint"],
    "subsurface":        ["Subsurface Weight", "Subsurface"],
    "anisotropic":       ["Anisotropic"],
}


def version():
    """Return (major, minor, patch) e.g. (5, 1, 2)."""
    return tuple(bpy.app.version)


def is_at_least(major, minor=0):
    return bpy.app.version[:2] >= (major, minor)


def principled_socket(bsdf, friendly_key):
    """Return the live input socket on `bsdf` for a friendly key, or None.

    `bsdf` is a Principled BSDF node. Raises KeyError if `friendly_key` is
    unknown to this module (programmer error), returns None if no candidate
    socket exists on this Blender build (so callers can skip gracefully).
    """
    if friendly_key not in _PRINCIPLED_ALIASES:
        raise KeyError(
            "Unknown principled friendly key %r. Known: %s"
            % (friendly_key, ", ".join(sorted(_PRINCIPLED_ALIASES)))
        )
    for name in _PRINCIPLED_ALIASES[friendly_key]:
        if name in bsdf.inputs:
            return bsdf.inputs[name]
    return None


def _coerce_value(sock, value):
    """Bridge socket-TYPE changes across versions (e.g. 'Specular Tint' and
    'Sheen Tint' were floats in 3.x, RGBA colors in 4.0+). A bare number aimed
    at an RGBA socket becomes a grey (v, v, v, 1.0); a color aimed at a float
    socket becomes the mean of its RGB channels. Anything else passes through."""
    is_seq = hasattr(value, "__len__") and not isinstance(value, (str, bytes))
    if sock.type == "RGBA" and not is_seq:
        try:
            v = float(value)
        except (TypeError, ValueError):
            return value
        return (v, v, v, 1.0)
    if sock.type == "VALUE" and is_seq:
        rgb = list(value)[:3]
        if rgb:
            return sum(float(c) for c in rgb) / len(rgb)
    return value


def principled_set(bsdf, **kwargs):
    """Set Principled BSDF default_values by friendly key. Returns list of
    keys that were applied (skips keys with no matching socket on this build).

        principled_set(bsdf, base_color=(0.8,0.1,0.1,1), roughness=0.4,
                       specular=0.5, emission_strength=2.0)
    """
    applied = []
    for key, value in kwargs.items():
        sock = principled_socket(bsdf, key)
        if sock is None:
            continue
        sock.default_value = _coerce_value(sock, value)
        applied.append(key)
    return applied


def get_principled(mat):
    """Return the Principled BSDF node of a node-based material, or None."""
    if not mat.use_nodes or mat.node_tree is None:
        return None
    for node in mat.node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            return node
    return None


# --- render engine compat -------------------------------------------------

def eevee_engine_id():
    """Return the Eevee engine identifier valid for this build.

    5.x / 4.3+ : 'BLENDER_EEVEE'  (the new EEVEE; legacy id removed)
    4.2        : 'BLENDER_EEVEE_NEXT'
    <=4.1      : 'BLENDER_EEVEE'
    We probe the actual enum so we never guess wrong.
    """
    items = _engine_enum_ids()
    for candidate in ("BLENDER_EEVEE", "BLENDER_EEVEE_NEXT"):
        if candidate in items:
            return candidate
    # last resort: first non-cycles engine
    for i in items:
        if i != "CYCLES":
            return i
    return "BLENDER_EEVEE"


def _engine_enum_ids():
    prop = bpy.types.RenderSettings.bl_rna.properties["engine"]
    return [e.identifier for e in prop.enum_items]


def ensure_cycles_available():
    """Enable the Cycles addon so engine='CYCLES' is selectable. Returns True
    if Cycles can actually be used (verified by setting+reverting the engine,
    because the engine enum is not always refreshed after the addon loads)."""
    try:
        import addon_utils
        addon_utils.enable("cycles", default_set=True)
    except Exception:
        pass
    sc = bpy.context.scene
    if sc is None:
        return "CYCLES" in _engine_enum_ids()
    prev = sc.render.engine
    try:
        sc.render.engine = "CYCLES"
        ok = sc.render.engine == "CYCLES"
    except Exception:
        ok = False
    finally:
        try:
            sc.render.engine = prev
        except Exception:
            pass
    return ok
