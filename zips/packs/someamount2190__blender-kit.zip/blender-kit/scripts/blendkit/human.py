"""human.py — PHOTOREAL humans via MPFB (MakeHuman Plugin For Blender).

The primitive kit tops out at stylized busts; photoreal needs asset-grade
geometry, photo-based skin data and a physically-serious render stack. This
module wraps MPFB (GPL tool, CC0 assets) + Poly Haven HDRIs (CC0) + Cycles
into blendkit-style calls:

    from blendkit import human
    h = human.generate_human(macro={"gender": 0.3, "age": 0.45},
                             skin="Darthfurby caucasian female",
                             eyes="High-poly", eyebrows="Eyebrow010",
                             eyelashes="Eyelashes01", hair="Bob01")
    human.hdri_world()                       # assets/hdri/*.hdr
    human.portrait(h, out_path, direction=(0.4, -1.0, 0.1))

REQUIREMENTS (one-time, already provisioned on this machine — see SOP-08):
  * MPFB extension installed+enabled (blender --command extension install mpfb)
  * Asset packs unzipped into MPFB's user data dir (system assets + skins01 +
    eyebrows01 + eyelashes01 + hair01, all CC0)
  * An .hdr in <skill>/assets/hdri/

Everything is headless-safe. Renders use Cycles (SSS skin needs it); expect
minutes, not seconds, per frame on CPU.
"""

import os

import bpy
import mathutils

SKILL = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEFAULT_HDRI = os.path.join(SKILL, "assets", "hdri", "studio_small_08_2k.hdr")

_MPFB = "bl_ext.blender_org.mpfb"


def _services():
    import addon_utils
    addon_utils.enable(_MPFB, default_set=True)
    import importlib
    hs = importlib.import_module(_MPFB + ".services.humanservice").HumanService
    asv = importlib.import_module(_MPFB + ".services.assetservice").AssetService
    ts = importlib.import_module(_MPFB + ".services.targetservice").TargetService
    return hs, asv, ts


def asset_path(kind, name_contains, asset_type="mhclo"):
    """Resolve an installed MPFB asset by fuzzy name. Raises with the list of
    available names on a miss (so the agent can pick a real one)."""
    _, AssetService, _ = _services()
    lst = AssetService.get_asset_list(kind, asset_type=asset_type)
    for name, info in lst.items():
        if name_contains.lower() in name.lower():
            return info if isinstance(info, str) else info.get("full_path") or info.get("path")
    raise ValueError("no %s asset matching %r; available: %s"
                     % (kind, name_contains, sorted(lst.keys())))


def generate_human(macro=None, skin=None, eyes="High-poly",
                   eyebrows="Eyebrow010", eyelashes="Eyelashes01", hair=None,
                   skin_type="ENHANCED_SSS", name=None):
    """Generate a parameterized MPFB human and equip skin/eyes/brows/lashes/hair.

    macro: partial dict overlaid on MPFB's defaults — keys gender/age/muscle/
    weight/height/proportions/cupsize/firmness in [0,1] and race={"asian":a,
    "caucasian":c,"african":f} (weights ~sum to 1). Partial dicts are SAFE
    (the KeyError('race') trap is handled by overlaying onto the default).
    skin/eyes/...: fuzzy asset names (None = skip that asset).
    Returns the basemesh object; equipped assets become its children."""
    HumanService, _, TargetService = _services()

    full_macro = TargetService.get_default_macro_info_dict()
    if macro:
        race = macro.pop("race", None)
        full_macro.update(macro)
        if race:
            full_macro["race"].update(race)

    basemesh = HumanService.create_human(feet_on_ground=True,
                                         macro_detail_dict=full_macro)
    if name:
        basemesh.name = name

    if skin:
        HumanService.set_character_skin(
            asset_path("skins", skin, asset_type="mhmat"),
            basemesh, skin_type=skin_type)

    for kind, pick in (("eyes", eyes), ("eyebrows", eyebrows),
                       ("eyelashes", eyelashes), ("hair", hair)):
        if not pick:
            continue
        mat = "PROCEDURAL_EYES" if kind == "eyes" else "MAKESKIN"
        try:
            HumanService.add_mhclo_asset(
                asset_path(kind, pick), basemesh,
                asset_type=kind.capitalize(), material_type=mat,
                set_up_rigging=False)
        except Exception as e:
            if mat == "PROCEDURAL_EYES":  # older asset/material combos
                HumanService.add_mhclo_asset(
                    asset_path(kind, pick), basemesh, asset_type="Eyes",
                    material_type="MAKESKIN", set_up_rigging=False)
            else:
                raise RuntimeError("equipping %s %r failed: %r" % (kind, pick, e))
    return basemesh


def hdri_world(path=None, strength=1.0, scene=None):
    """Environment light from a real HDRI (assets/hdri). Replaces the world."""
    scene = scene or bpy.context.scene
    path = path or DEFAULT_HDRI
    if not os.path.exists(path):
        raise FileNotFoundError("HDRI not found: %s (drop a CC0 .hdr from "
                                "polyhaven.com into assets/hdri/)" % path)
    world = bpy.data.worlds.new("HDRI")
    world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputWorld")
    bg = nt.nodes.new("ShaderNodeBackground")
    env = nt.nodes.new("ShaderNodeTexEnvironment")
    env.image = bpy.data.images.load(path)
    bg.inputs["Strength"].default_value = strength
    nt.links.new(env.outputs["Color"], bg.inputs["Color"])
    nt.links.new(bg.outputs["Background"], out.inputs["Surface"])
    scene.world = world
    return world


def head_bbox(basemesh, height_frac=0.15, half_w=0.11, half_d=0.13):
    """World AABB of the head region (top `height_frac` of the figure).
    Defaults tuned for a tight head-and-shoulders portrait (the sphere-fit
    framing works off the bbox diagonal — an over-deep box reads as a wide
    shot)."""
    zs = [(basemesh.matrix_world @ v.co).z for v in basemesh.data.vertices]
    zmax = max(zs)
    span = (zmax - min(zs)) * height_frac
    return ((-half_w, -half_d, zmax - span), (half_w, half_d, zmax + 0.03))


def key_light(target, energy=70, size=0.8, offset=(0.8, -0.85, 0.35),
              scene=None, name="Key", color=None):
    """Portrait key: soft area light offset from the subject."""
    scene = scene or bpy.context.scene
    data = bpy.data.lights.new(name, "AREA")
    data.energy = energy
    data.size = size
    if color:
        data.color = color
    ob = bpy.data.objects.new(name, data)
    scene.collection.objects.link(ob)
    t = mathutils.Vector(target)
    ob.location = (t.x + offset[0], t.y + offset[1], t.z + offset[2])
    d = t - mathutils.Vector(ob.location)
    ob.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
    return ob


def portrait_lighting(target, scene=None, hdri_strength=0.35):
    """Studio portrait ratio (Gate 9.7 fix: HDRI-only was 'shadowless mush').
    HDRI drops to fill level; a keyed 2:1-4:1 main + a cool rim/kicker behind
    the subject separate the head from the background and give the eyes a
    structured catchlight. Call AFTER hdri_world()."""
    scene = scene or bpy.context.scene
    if scene.world is not None:
        try:
            bg = scene.world.node_tree.nodes.get("Background")
            if bg is not None:
                bg.inputs["Strength"].default_value = hdri_strength
        except Exception:
            pass
    # key well OFF the camera axis (a near-camera key = flat mush)
    key = key_light(target, energy=160, size=0.6, offset=(0.9, -0.5, 0.35),
                    scene=scene, name="Key")
    rim = key_light(target, energy=110, size=0.4, offset=(-0.5, 0.8, 0.45),
                    scene=scene, name="Rim", color=(0.75, 0.85, 1.0))
    return {"key": key, "rim": rim}


#: MPFB v2 skin-group settings that kill the wax read (Gate 9.7 critique #1).
#: Defaults ship with SSS nearly OFF (strength 0.2, radius scale 0.1) and
#: pores at 0.2 — a perfectly even BSDF, the classic CG tell.
SKIN_TUNE = {
    "Pore strength": 0.45,
    "Pore detail": 4.0,
    "SSS strength": 0.6,        # 1.0 went milky/pallid — 0.6 keeps blood in it
    "SSS radius scale": 0.2,
    "SSS radius G": 0.35,       # red-dominant radius (R stays 1.0)
    "SSS radius B": 0.2,
    "Clearcoat": 0.12,          # oil sheen (0.18 read as white film)
    "Clearcoat Roughness": 0.25,
    "Roughness": 0.5,
    "colorMixInStrength": 0.10,  # capillary flush blotch
}
SKIN_TUNE_LIPS = {"Clearcoat": 0.4, "Clearcoat Roughness": 0.15}


def skin_micro_detail(basemesh, overrides=None):
    """Break up the wax (Gate 9.7 critique #1: 'zero specular breakup, flat
    candle-wax SSS'). MPFB's ENHANCED_SSS skin group already EXPOSES the
    needed controls (pores, per-channel SSS radius, clearcoat) — the defaults
    are just dialed to near-zero. This sets SKIN_TUNE on every skin group
    node across the mesh's materials (lips get a glossier clearcoat)."""
    tune = dict(SKIN_TUNE)
    if overrides:
        tune.update(overrides)
    touched = 0
    key_hits = {k: 0 for k in tune}
    for slot in basemesh.material_slots:
        mat = slot.material
        if mat is None or not mat.use_nodes:
            continue
        vals = dict(tune)
        if "lips" in mat.name.lower():
            vals.update(SKIN_TUNE_LIPS)
        for node in mat.node_tree.nodes:
            if node.type != "GROUP":
                continue
            hit = False
            for key, val in vals.items():
                sock = node.inputs.get(key)
                if sock is not None:
                    sock.default_value = val
                    hit = True
                    if key in key_hits:
                        key_hits[key] += 1
            if hit:
                touched += 1
    # a node counts as touched if ANY key lands — per-key hits make a
    # partial no-op (e.g. only Roughness matching) visible to the caller
    missed = sorted(k for k, n in key_hits.items() if n == 0)
    print("skin_micro_detail: tuned %d skin group node(s); per-key hits %s%s"
          % (touched, {k: n for k, n in key_hits.items() if n},
             ("; MISSED KEYS: %s" % ", ".join(missed)) if missed else ""))
    return touched


def portrait(basemesh, out_path, direction=(0.4, -1.0, 0.10), lens_mm=85,
             samples=128, resolution=(900, 1100), fstop=2.8, margin=0.92,
             scene=None, headroom=0.09):
    """Cycles head-and-shoulders portrait: framed on the head bbox, denoised,
    with depth of field focused on the face. Returns the render filepath.

    headroom: PARALLEL camera drop in meters after framing — moves the head
    into the upper third without changing its size (Gate 9.7 fix; extending
    the framing bbox instead just widened the shot into a half-body)."""
    from . import camera as bk_camera
    scene = scene or bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = samples
    scene.cycles.use_denoising = True
    scene.render.resolution_x, scene.render.resolution_y = resolution

    box = head_bbox(basemesh)
    head_z = (box[0][2] + box[1][2]) / 2.0
    cam = bk_camera.frame_object(scene=scene, bbox=box, direction=direction,
                                 lens_mm=lens_mm, margin=margin,
                                 name="portrait_cam")
    cam.location.z -= headroom   # parallel shift: head rises to upper third
    cam.data.dof.use_dof = True
    cam.data.dof.focus_distance = (mathutils.Vector(cam.location)
                                   - mathutils.Vector((0, -0.09, head_z))).length
    cam.data.dof.aperture_fstop = fstop

    d = os.path.dirname(out_path)
    if d:
        os.makedirs(d, exist_ok=True)
    scene.render.filepath = out_path
    scene.render.image_settings.file_format = "PNG"
    bpy.ops.render.render(write_still=True)
    return out_path


def add_rig(basemesh, rig_name="default"):
    """Attach MPFB's builtin skeleton + weights (2026-07-06, headless-OK).

    Returns the armature object. Bone names are MakeHuman-style
    (upperarm01.L, lowerarm01.R, head, ...). Sign convention measured on
    the default rig: upperarm01 local +rz RAISES the .L arm and LOWERS
    the .R arm (mirror-flipped) — pose helpers below encode it.
    """
    HumanService, _, _ = _services()
    HumanService.add_builtin_rig(basemesh, rig_name)
    for o in bpy.data.objects:
        if o.type == "ARMATURE" and o.name.startswith(basemesh.name):
            return o
    arms = [o for o in bpy.data.objects if o.type == "ARMATURE"]
    return arms[-1] if arms else None


def pose_bones(armature, spec):
    """Rotate pose bones from {bone_name: (rx, ry, rz) degrees}. Missing
    bones are reported, not fatal (rig variants differ). Returns misses."""
    import math as _math
    missing = []
    for name, (rx, ry, rz) in spec.items():
        b = armature.pose.bones.get(name)
        if b is None:
            missing.append(name)
            continue
        b.rotation_mode = "XYZ"
        b.rotation_euler = (_math.radians(rx), _math.radians(ry),
                            _math.radians(rz))
    bpy.context.view_layer.update()
    if missing:
        print("pose_bones: missing %s" % missing)
    return missing


#: Verified 2026-07-06: hands land beside the thighs, no wrist crossing.
POSE_RELAXED = {
    "upperarm01.L": (0, 0, -38), "upperarm01.R": (0, 0, 38),
    "lowerarm01.L": (0, 0, -8), "lowerarm01.R": (0, 0, 8),
}


def pose_relaxed(armature):
    """Natural standing pose: arms hang beside the thighs (retires the
    A-pose 'swan-dive arms / jazz hands' accepted limit)."""
    return pose_bones(armature, POSE_RELAXED)
