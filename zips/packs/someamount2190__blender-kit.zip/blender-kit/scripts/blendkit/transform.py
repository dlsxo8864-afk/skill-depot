"""transform.py — meters in, DEGREES in. Routes all rotation through here so
the radians/degrees mixup (the #1 cause of "wildly rotated object") can't happen.

All functions take a bpy object and mutate it in place; they return the object
for chaining.
"""

import math
import bpy
import mathutils


def set_location(obj, x=0.0, y=0.0, z=0.0):
    obj.location = (float(x), float(y), float(z))
    return obj


def set_rotation_deg(obj, rx=0.0, ry=0.0, rz=0.0):
    """Set Euler rotation in DEGREES (XYZ)."""
    obj.rotation_mode = "XYZ"
    obj.rotation_euler = (math.radians(rx), math.radians(ry), math.radians(rz))
    return obj


def set_scale(obj, sx=1.0, sy=None, sz=None):
    """Uniform if only sx given."""
    if sy is None:
        sy = sx
    if sz is None:
        sz = sx
    obj.scale = (float(sx), float(sy), float(sz))
    return obj


def move(obj, dx=0.0, dy=0.0, dz=0.0):
    obj.location = (obj.location.x + dx, obj.location.y + dy, obj.location.z + dz)
    return obj


def look_at(obj, target=(0.0, 0.0, 0.0), up="Y", track="-Z"):
    """Aim an object's local -Z (camera/light convention) at a world point.

    `target` may be a 3-tuple or a bpy object (its world location is used).

    NOTE: writes a WORLD-space-derived rotation into obj.rotation_euler, so it
    is only correct for UNPARENTED objects — a parent's rotation would be
    applied on top of it and skew the aim.
    """
    # matrix_world can be STALE right after a location assignment because the
    # depsgraph hasn't re-evaluated yet; flush so the aim uses the real origin.
    try:
        bpy.context.view_layer.update()
    except Exception:
        print("WARNING: look_at(%r): view_layer.update() failed — aiming from "
              "a possibly stale matrix_world" % obj.name)
    if hasattr(target, "matrix_world"):
        tgt = target.matrix_world.to_translation()
    else:
        tgt = mathutils.Vector(target)
    loc = obj.matrix_world.to_translation()
    direction = tgt - loc
    if direction.length < 1e-9:
        return obj  # degenerate; leave rotation untouched
    obj.rotation_mode = "XYZ"
    obj.rotation_euler = direction.to_track_quat(track, up).to_euler()
    return obj


def apply_transforms(obj, location=True, rotation=True, scale=True):
    """Bake object transform into mesh data WITHOUT bpy.ops (no context needed).

    Equivalent to Object > Apply > All Transforms for a mesh. We compose the
    matrix from only the requested components, bake it into the vertices, then
    reset those components on the object. Works in background mode.
    """
    if obj.type != "MESH":
        raise TypeError("apply_transforms only supports MESH objects, got %r" % obj.type)

    loc, rot, scl = obj.matrix_basis.decompose()
    if rotation and not scale and (
            max(scl.x, scl.y, scl.z) - min(scl.x, scl.y, scl.z) > 1e-6):
        # baking R but leaving a non-uniform S on the object reorders R and S
        # in the world transform (S@R != R@S) — the shape visibly changes.
        print("WARNING: apply_transforms(%r): baking rotation but NOT scale on "
              "a non-uniformly scaled object (scale=%.4g,%.4g,%.4g) changes its "
              "world-space shape — bake scale too, or apply scale first"
              % (obj.name, scl.x, scl.y, scl.z))
    mat_loc = mathutils.Matrix.Translation(loc) if location else mathutils.Matrix.Identity(4)
    mat_rot = rot.to_matrix().to_4x4() if rotation else mathutils.Matrix.Identity(4)
    mat_scl = mathutils.Matrix.Diagonal(scl.to_4d()) if scale else mathutils.Matrix.Identity(4)
    bake = mat_loc @ mat_rot @ mat_scl

    obj.data.transform(bake)

    # Reset the components we baked, keep the ones we didn't.
    new_loc = mathutils.Vector((0, 0, 0)) if location else loc
    new_rot = mathutils.Quaternion() if rotation else rot
    new_scl = mathutils.Vector((1, 1, 1)) if scale else scl
    obj.matrix_basis = (
        mathutils.Matrix.Translation(new_loc)
        @ new_rot.to_matrix().to_4x4()
        @ mathutils.Matrix.Diagonal(new_scl.to_4d())
    )
    obj.data.update()
    return obj
