"""debug.py — capture + classify Blender/bpy failures, map to a fix.

PURE PYTHON (no bpy) so it runs on any log file, in or out of Blender.

Protocol (see sops/03-debug-failure.md):
  1. Read the captured log.
  2. consult_memory() FIRST — search LEARNINGS.md + references/bpy_gotchas.md for
     the error signature. A prior verified fix beats reasoning from scratch.
  3. classify() against built-in signatures -> probable cause + fix.
  4. Apply the mapped fix, retry (bounded, max 2). On continued failure build a
     minimal repro and STOP — surface the log + hypothesis. Never fake success.

CLI:  python debug.py <logfile> [--skill-root DIR]
"""

import os
import re
import sys

# Each signature: (name, compiled regex, probable_cause, fix)
_SIGNATURES = [
    (
        "ops_poll_failed",
        re.compile(r"poll\(\)\s*failed,?\s*context is incorrect", re.I),
        "A bpy.ops operator was called without the right mode/area/active object.",
        "Stop using bpy.ops for this. Build with the data API + bmesh "
        "(blendkit.build), which has no context dependency in -b mode.",
    ),
    (
        "principled_socket_renamed",
        re.compile(
            r"key\s*\"?(Specular|Emission|Transmission|Clearcoat|Sheen|Subsurface)\"?\s*not found"
            r"|KeyError.*'(Specular|Emission|Transmission|Clearcoat|Sheen)'",
            re.I),
        "Principled BSDF socket was renamed in Blender 4.0 (e.g. 'Specular' -> "
        "'Specular IOR Level', 'Emission' -> 'Emission Color').",
        "Never index bsdf.inputs by a hard-coded name. Use "
        "blendkit.compat.principled_set(bsdf, specular=..., emission_color=...) "
        "which resolves whichever socket exists on this build.",
    ),
    (
        "mesh_op_wrong_mode",
        re.compile(r"(mesh\.\w+).*(only.*edit mode|requires.*edit|object mode)", re.I),
        "A mesh operator was run in the wrong mode (object vs edit).",
        "Switch to bmesh (blendkit.build / bmesh.ops) which edits mesh data "
        "directly with no mode requirement.",
    ),
    (
        "gpu_egl_headless",
        re.compile(r"(EGL|GLX|GPU.*not.*found|Unable to open.*display|"
                   r"could not get a list of mounted|libGL|X Error|Segmentation fault|"
                   r"GPUFrameBuffer|createContext)", re.I),
        "Headless GPU/EGL initialization failed (no display / driver) under -b.",
        "Fall back to Cycles on CPU: engine='CYCLES', scene.cycles.device='CPU'. "
        "blendkit.render.render_still already retries with Cycles automatically.",
    ),
    (
        "black_render",
        # Audit fix: the old pattern `0(\.0+)?\b` backtracked to a bare "0" and
        # matched EVERY lum=0.xxxx line (any value < 1.0) -> classifier cried
        # "black frame" on virtually all logs. This matches only lum < ~0.01
        # (0 / 0.0 / 0.00xx) plus render.py's explicit BLACK marker.
        re.compile(r"\blum(inance)?\s*=\s*0(\.0(0\d*)?)?(?![\d.])"
                   r"|render BLACK|black[ _](frame|render)", re.I),
        "Frame rendered black: no lights, no world lighting, or camera aimed "
        "away from geometry.",
        "Run blendkit.preflight.check() before rendering. Add lights "
        "(blendkit.light.three_point) and/or light.world_sky(); verify the "
        "camera with preflight (it checks the aim cone). Note render_still "
        "now fails black frames itself (error='black_frame ...').",
    ),
    (
        "object_missing_from_render",
        re.compile(r"(hide_render|not.*linked.*view layer|not in any collection|"
                   r"object .* not visible)", re.I),
        "Object exists but isn't rendered: hide_render=True or not linked to the "
        "active view layer / a scene collection.",
        "Link the object to scene.collection (build.py does this) and ensure "
        "obj.hide_render = False. Check obj.users_collection is non-empty.",
    ),
    (
        "radians_degrees_mixup",
        re.compile(r"rotation_euler.*(6\.28|3\.14159)|wild(ly)? rotat", re.I),
        "Rotation set in the wrong unit (radians vs degrees).",
        "Route rotation through blendkit.transform.set_rotation_deg(obj, rx, ry, "
        "rz) which converts degrees -> radians for you.",
    ),
    (
        "module_not_found_blendkit",
        re.compile(r"ModuleNotFoundError.*blendkit|No module named 'blendkit'", re.I),
        "The blendkit package isn't on sys.path for this Blender run.",
        "At the top of the script: sys.path.insert(0, <skill>/scripts) BEFORE "
        "'from blendkit import ...'. new_scene.py shows the pattern.",
    ),
    (
        "numpy_pixels_shape",
        re.compile(r"cannot reshape array|operands could not be broadcast", re.I),
        "Image pixel buffer reshaped with the wrong dimensions.",
        "Use image.size (w,h) for reshape(h, w, 4); render all views at one "
        "resolution before building a contact sheet.",
    ),
]


def classify(log_text):
    """Return a list of matched signatures (deduped, in priority order)."""
    out = []
    seen = set()
    for name, rx, cause, fix in _SIGNATURES:
        if rx.search(log_text) and name not in seen:
            seen.add(name)
            out.append({"signature": name, "cause": cause, "fix": fix})
    return out


def extract_error_lines(log_text, context=2):
    """Pull the Traceback / Error lines out of a noisy Blender log."""
    lines = log_text.splitlines()
    keep = []
    for i, ln in enumerate(lines):
        if re.search(r"Traceback|Error|Exception|failed|FAILED|segfault|EGL", ln):
            lo = max(0, i - context)
            hi = min(len(lines), i + context + 1)
            keep.extend(lines[lo:hi])
    # dedupe consecutive
    dedup = []
    for ln in keep:
        if not dedup or dedup[-1] != ln:
            dedup.append(ln)
    return "\n".join(dedup) if dedup else "(no error lines found)"


# --- memory consultation (LEARNINGS.md + bpy_gotchas.md) -------------------

def _skill_root(explicit=None):
    if explicit:
        return explicit
    # this file is <root>/scripts/blendkit/debug.py
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.normpath(os.path.join(here, "..", ".."))


def consult_memory(log_text, skill_root=None):
    """Search LEARNINGS.md and references/bpy_gotchas.md for any of the matched
    signatures (or raw keywords). Returns matching blocks so the model checks
    prior fixes BEFORE reasoning from scratch."""
    root = _skill_root(skill_root)
    matches = classify(log_text)
    keys = [m["signature"] for m in matches]
    # also harvest renamed-socket tokens etc. as loose keys
    for tok in ("Specular", "Emission", "poll()", "EGL", "hide_render"):
        if tok.lower() in log_text.lower():
            keys.append(tok)

    hits = []
    for rel in ("LEARNINGS.md", os.path.join("references", "bpy_gotchas.md")):
        path = os.path.join(root, rel)
        if not os.path.exists(path):
            continue
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        for block in _split_blocks(text):
            for k in keys:
                if k and k.lower() in block.lower():
                    hits.append({"source": rel, "key": k, "block": block.strip()})
                    break
    return hits


def _split_blocks(text):
    """Split a markdown memory file into entry blocks (by '###'/'---' or table rows).

    Audit fix: emit table rows only for blocks NOT already emitted whole —
    previously every table row was returned in addition to its containing
    block, so consult_memory reported duplicate hits."""
    blocks = re.split(r"\n(?=### |\n---+\s*\n|\n## )", text)
    out = []
    for b in blocks:
        rows = [ln for ln in b.splitlines()
                if ln.strip().startswith("|") and ln.count("|") >= 3]
        if rows and len("\n".join(rows)) < len(b) * 0.8:
            # mostly-prose block containing a table: index rows individually
            out.extend(rows)
        out.append(b)
    return out


def report(log_text, skill_root=None):
    """Full classification report as text."""
    lines = ["=== DEBUG CLASSIFICATION ==="]
    errs = extract_error_lines(log_text)
    lines.append("\n[captured error]\n" + errs)

    mem = consult_memory(log_text, skill_root)
    lines.append("\n[memory: LEARNINGS.md + bpy_gotchas.md]")
    if mem:
        for h in mem:
            lines.append("  (%s, key=%s) %s" % (h["source"], h["key"], h["block"][:300]))
    else:
        lines.append("  no prior entry for this signature -- if you solve it, "
                     "RECORD it (verified) in LEARNINGS.md")

    matches = classify(log_text)
    lines.append("\n[classifier]")
    if matches:
        for m in matches:
            lines.append("  signature: %s" % m["signature"])
            lines.append("    cause: %s" % m["cause"])
            lines.append("    fix:   %s" % m["fix"])
    else:
        lines.append("  UNKNOWN signature. Build a minimal repro, isolate, and "
                     "surface the log + your hypothesis. Do not fake success.")
    return "\n".join(lines)


def classify_file(path, skill_root=None):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return report(f.read(), skill_root)


if __name__ == "__main__":
    # The catalog/LEARNINGS may contain non-ASCII (arrows, dashes); the Windows
    # console defaults to cp1252 and would crash on print. Force tolerant UTF-8.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = sys.argv[1:]
    root = None
    if "--skill-root" in args:
        i = args.index("--skill-root")
        if i + 1 >= len(args):
            print("usage: python debug.py <logfile> [--skill-root DIR]")
            sys.exit(2)
        root = args[i + 1]
        args = args[:i] + args[i + 2:]
    if not args:
        print("usage: python debug.py <logfile> [--skill-root DIR]")
        sys.exit(2)
    print(classify_file(args[0], root))
