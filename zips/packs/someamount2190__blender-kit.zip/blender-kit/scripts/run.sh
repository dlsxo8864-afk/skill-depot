#!/usr/bin/env bash
# run.sh — headless Blender wrapper that ALWAYS captures stdout+stderr+returncode
# to logs/<timestamp>.log and NEVER overwrites the script being run.
#
# Usage:
#   BLENDER="/c/Program Files/Blender Foundation/Blender 5.1/blender.exe" \
#     scripts/run.sh scripts/new_scene.py [extra blender args...]
#
# If BLENDER is unset it tries a few known locations. The log path is printed on
# the last line as  LOG=<path>  so callers can feed it to debug.py.
set -u

SKILL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCRIPT="${1:-}"
shift || true

if [ -z "$SCRIPT" ]; then
  echo "usage: run.sh <python_script.py> [blender args...]" >&2
  exit 2
fi

# locate blender
find_blender() {
  if [ -n "${BLENDER:-}" ] && [ -x "${BLENDER}" ]; then echo "$BLENDER"; return; fi
  for c in \
    "/c/Program Files/Blender Foundation/Blender 5.1/blender.exe" \
    "/c/Program Files/Blender Foundation/Blender 4.2/blender.exe" \
    "$(command -v blender 2>/dev/null)" \
    "/Applications/Blender.app/Contents/MacOS/Blender" \
    "/usr/bin/blender" ; do
    if [ -n "$c" ] && [ -x "$c" ]; then echo "$c"; return; fi
  done
  echo ""
}

BLENDER_BIN="$(find_blender)"
if [ -z "$BLENDER_BIN" ]; then
  echo "ERROR: Blender not found. Set BLENDER=/path/to/blender(.exe)" >&2
  exit 3
fi

LOGDIR="$SKILL_ROOT/logs"
mkdir -p "$LOGDIR"
# PID + milliseconds in the name so concurrent runs never truncate each other
TS="$(date +%Y%m%d_%H%M%S)"
MS="$(date +%3N 2>/dev/null)"
case "$MS" in *[!0-9]*|"") MS="000" ;; esac   # BSD date prints a literal 'N'
LOG="$LOGDIR/${TS}_${MS}_$$.log"

{
  echo "# run.sh $(date)"
  echo "# blender: $BLENDER_BIN"
  echo "# script:  $SCRIPT"
  echo "# args:    $*"
  echo "#----------------------------------------------------------------"
} > "$LOG"

# Run blender in background mode, merge stderr into stdout, append to log.
# --python-exit-code makes a script exception return non-zero (Blender exits 0
# by default even when the python raises), so callers/CI see the failure.
"$BLENDER_BIN" -b --python-exit-code 1 --python "$SCRIPT" -- "$@" >> "$LOG" 2>&1
RC=${PIPESTATUS[0]:-$?}

echo "#----------------------------------------------------------------" >> "$LOG"
echo "# returncode: $RC" >> "$LOG"

echo "returncode=$RC"
echo "LOG=$LOG"
exit "$RC"
