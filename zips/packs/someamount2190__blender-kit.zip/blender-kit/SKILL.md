---
name: blender-kit
description: >-
  Reliable 3D work in Blender via bpy. Use whenever a task involves Blender,
  bpy, .blend files, rendering a scene, building/modifying 3D geometry,
  materials, lighting, or cameras from Python. Wraps the model's weak spots
  (spatial blindness, bpy version/context confusion, claiming scenes "look good"
  without rendering) in deterministic code + a build->render->inspect loop +
  a debugging and learning system.
---

# blender-kit

You are spatially blind when writing bpy: you place objects by raw coordinates
and cannot see overlaps, gaps, clipping, or wrong scale. You confuse bpy
versions (sockets renamed in 4.0), misuse `bpy.ops` context in headless mode,
and you tend to claim a scene "looks good" without ever rendering it. This skill
removes those failure modes with code and procedure. **Follow the loop. Do not
trust your mental picture of the scene — render it and look.**

## Environment (this machine)
- Blender: `C:\Program Files\Blender Foundation\Blender 5.1\blender.exe` — **5.1.2**, Python 3.13.
- Eevee (`BLENDER_EEVEE`) renders headless; Cycles-CPU fallback works (auto).
- Principled BSDF uses **4.x+ socket names** (`Specular IOR Level`, `Emission Color`, `Coat Weight`). Never hard-code `Specular`/`Emission` — go through `compat`.
- Run scripts with `scripts/run.sh <script.py>` (captures stdout+stderr+rc to `logs/`).
- Full env procedure + how to install Blender elsewhere: `sops/04-env-verify.md`.

## THE MANDATORY LOOP (never report "done" until all of it has run)
```
DESIGN FIRST (representational / multi-part / character / organic) — SOP-07:
  scaffold the plan:  python scripts/plan_build.py "<object>"
  fill it: WHAT (proportions) + VISUAL (fetch+VIEW ref) + HOW (construction
           method — research the craft, not your prior) + FAILURES (common
           mistakes + the guard) + FEATURE PARTS (identity parts as first-class
           geometry + placement logic) + DECOMPOSE (part -> technique -> check)
           — all SIX plan sections
  -> design_gate must PASS. NO bmesh/geometry until it does.
then SUB-BUILDS first (Gate 2.8, ENFORCED: declare `sub-build: <script>` lines in
  the plan; preflight + ship_check fail-closed until each has green recorded gates; any part that is a machine/organism in its own
  right gets its OWN gated script + viewed renders BEFORE assembly — see
  references/techniques/subassembly-first-builds)
then BUILD (data API + bmesh, NEVER bpy.ops)
  -> preflight.check(plan_path=_tmp/<slug>_plan.md)   [ABORTS if design gate
     incomplete OR no light / camera not aimed / NaN / zero-scale]
  -> render canonical views + inspect.scene_report (+ failure_scan, and the
     check_ratios/placement/alignment/angles quartet for multi-part)
  -> VIEW the PNGs with your image tool AND read the inspect report
  -> fix overlaps / floating / clipping / bad scale / wrong ratios
  -> repeat until it visually holds
  -> FINAL HARSH CRITIQUE (SOP-00 Gate 9.7): attack the passing build as a
     hostile art director — >=3 concrete render-visible defects (material
     read, scale cues, procedural uniformity, feature-part legibility);
     then the ENGINEER PASS: a second subagent maps each critique item to
     concrete kit calls with a feasibility label (FIX-NOW / KIT-EXTENSION /
     ACCEPT); every geometry/proportion fix must be REFERENCE-GROUNDED —
     fetch+VIEW an image AND write the part's dimensions/ratios (into the
     plan + check_ratios) BEFORE implementing (see Gate 9.7; the giraffe-
     neck failure was two rounds of un-referenced fixing); FIX the fix-now
     items, re-render; list accepted defects
  -> Gate 9.7 artifacts ON DISK per sops/09-critique-protocol.md (structured
     PERCEPT/CLAIM critique + labeled engineer triage) and
     recorded: python scripts/record_phase.py --out <dir> --critic <f> --engineer <f>
  -> deviations disclosed (or --no-deviations) — silent drift is the failure mode
  -> python scripts/ship_check.py --out <dir> --plan <plan>  MUST print SHIP: PASS
  -> THEN report, citing the render you looked at AND the ship_check PASS
```
You may not write geometry before the design gate passes, and you may not say a
scene is finished from code alone. "Looks good" requires a PNG you actually
viewed. If you cannot view the render, STOP and say so.

> Why DESIGN is step 0: a 3D anime head was attempted by jumping straight to
> geometry with only proportions researched — no construction-method or failure
> research, no plan — and it came out broken. Researching the WHAT is not enough;
> research the HOW and the FAILURE MODES and commit a plan FIRST. See SOP-07 and
> `references/failures/skipped-design-phase`.

## Hard rules
0. **DESIGN BEFORE GEOMETRY (representational / multi-part / character / organic).**
   Run **SOP-07** first: scaffold + fill the BUILD PLAN — proportions (WHAT) +
   reference (VISUAL, fetch & VIEW) + **construction method (HOW — research the
   craft, not your prior)** + **failure modes** + decomposition (part→technique→
   check). `plan.design_gate()` must PASS; `preflight.check(plan_path=…)` ABORTS
   the render until it does. Researching only proportions is NOT enough — that is
   exactly what broke the anime head. Skip ONLY for an abstract primitive blockout.
0b. **Design the FEATURE PARTS first; place them by LOGIC, not vibes.** Identify
   the identity/function parts — the "business end" (carrier = aircraft + island,
   NOT the hull; tank = turret + gun; cathedral = spire + facade). Give EACH real
   articulated geometry (a part breakdown, never a single blob) AND a functional
   PLACEMENT RULE (aircraft spotted clear of the landing area, noses outboard;
   island at the starboard edge). Verify with `check_placement` / `check_clearance`
   (keep-out zones). The body SUPPORTS the feature parts — do not spend the design
   budget on the mass and scatter the features as afterthoughts. Plan §5; SOP-06.
1. **Geometry/edits: `bpy.data` + `bmesh` only, never `bpy.ops`.** Ops depend on
   mode/active-object/area context that does not exist in `-b`. Use `blendkit.build`.
2. **All rotation through `transform.set_rotation_deg` (DEGREES in).** Stops the
   radians/degrees mixup that flings objects into orbit.
3. **All Principled material writes through `compat.principled_set`.** Version-safe.
4. **Always `preflight.check()` before a render.** Don't burn minutes on a black frame.
5. **Always `inspect.scene_report()` after building.** It sees what you can't.
6. **On any failure: consult `LEARNINGS.md` + `references/bpy_gotchas.md` FIRST,**
   then `debug.py`. Bounded retries (max 2) with the mapped fix, then minimal
   repro + STOP. Never fake success.
7. **Record a new fix in `LEARNINGS.md` only after a render/inspect PASSES**
   (with `verified_by` = which render). An unverified "fix" poisons the catalog.

## Routing — pick the SOP, follow its numbered gates (no gate may be skipped)
| Task | SOP |
|------|-----|
| **FIRST for any real-world/multi-part/character/organic build — design + plan** | `sops/07-design-first.md` |
| Build a new scene from scratch | `sops/00-new-scene.md` |
| Modify an existing .blend | `sops/01-modify-blend.md` |
| Make/adjust a material | `sops/02-material.md` |
| A render/script failed | `sops/03-debug-failure.md` |
| Verify Blender / first run / install elsewhere | `sops/04-env-verify.md` |
| Tactical-level design pass (layout/cover/lighting reads) | `sops/05-tactical-design.md` |
| Anything beyond a simple prop (build draft → detail each part) | `sops/06-draft-then-detail.md` |
| PHOTOREAL human / realistic face or character | `sops/08-photoreal-human.md` |

## The toolkit (`scripts/blendkit/`, import after adding `scripts/` to sys.path)
- `compat`     version detect + Principled socket shim + engine ids + Cycles enable.
- `build`      `add_box/plane/cylinder/cone/uv_sphere/torus/ground`, `grid`, `array`, `catenary_points` (bmesh).
- `transform`  `set_location/rotation_deg/scale`, `look_at`, `apply_transforms` (no ops).
- `material`   `concrete/metal/plastic/emissive/glass/diffuse` (version-aware), `assign`, `tint_textured` (recolor WITHOUT killing the texture — check the returned count).
- `light`      `three_point`, `sun`, `world_sky`.
- `camera`     `frame_scene` (auto-fit), `frame_scene_ortho_top` (blueprint), `frame_object` (per-part close-up), `orbit_positions`.
- `render`     `canonical_views` (persp+front+top + contact sheet + log; `subject_bbox=` frames the SUBJECT for tall figures), `detail_views` (per-part close-ups), `enable_glow` (calibrated bloom — see materials/emissive-glow), Cycles auto-fallback; black frames AND overexposed frames (clip_fraction gate) FAIL.
- `detail`     INTRICACY kit: `panel_groove`/`boolean_cut`, `bevel_sharp` (bevel LAST), `greeble_region`, `bolt_ring`, `rune_glyph` (12-glyph stroke alphabet for engraved bands). See `references/techniques/boolean-bevel-greeble-detail`.
- `human`      PHOTOREAL humans (MPFB + CC0 assets + HDRI + Cycles): `generate_human(macro, skin, hair, ...)`, `hdri_world`, `key_light`, `portrait`. Follow `sops/08-photoreal-human.md` — primitives top out at stylized busts; this is the path past that ceiling.
- `plan`       `scaffold()` the BUILD PLAN + `design_gate()` (SOP-07). Start a build with `scripts/plan_build.py "<object>"`.
- `preflight`  `check(plan_path=…)` cheap pre-render gate; ABORTS on an incomplete design plan too.
- `ledger`     build-ledger recorders + `finish(out_dir, checks, view_outputs)` — assemble the gate verdict from NAMED checks (never hand-and booleans; the Gundam ratios bug).
- `inspect_core` PURE python AABB overlap/float/degenerate detector (unit-testable).
- `inspect`    bpy adapter -> `scene_report()`, `topology_gate([parts])` (PER-PART n-gon/doubles verdicts for feature parts — pair with `render.detail_views`; see `references/techniques/per-part-detail-verification`).
- `debug`      `report()/classify_file()` error classifier consulting memory.

Start a new scene by copying `scripts/new_scene.py` (it already runs the loop).

## References & per-key learning loop
- `references/proportions.md` — the research-first WORKFLOW (5–10 sources → held
  belief → build → render/judge) for representational objects.
- **Per-key learnings (one file per key, so catalogs don't bloat):**
  - `references/objects/<slug>.md` (+ `INDEX.md`) — per-object dimensions/anatomy/
    build learnings. See `INDEX.md` for what's catalogued (the list grows).
  - `references/materials/<slug>.md` (+ `INDEX.md`) — per-material/texture shader +
    lighting learnings. See `INDEX.md` for what's catalogued.
  - `references/patterns/<slug>.md` (+ `INDEX.md`) — mathematical/botanical
    PLACEMENT rules (phyllotaxis/golden-angle, recursive branching). Build natural
    repeated/branching forms with `blendkit.phyllotaxis`, not even spacing.
  - `references/failures/<slug>.md` (+ `INDEX.md`) — known FAILURE MODES
    (community-sourced baseline + per-object). **Every build initiates failure
    research** (SOP-00 Gate 1.6): consult the baseline + search the community.
    **Run `inspect.failure_scan()` before shipping ANY model** — catches
    below-ground, floating (STRICT: a gap fails even if "close" — every part must
    connect), and degenerate geometry.
  - **Consult the INDEX + the relevant entry BEFORE building/texturing**; after a
    pass VERIFIES, route the learning with
    `python scripts/record_learning.py --kind object|material|pattern|technique|reference|failure --key … --verified-by …`
    (creates the file + one index line, or appends a dated entry). Record only
    verified learnings — same anti-poison rule as `LEARNINGS.md`. Construction
    METHODS (how a class of object is built) go under `--kind technique`, NOT
    `pattern` — patterns are placement math, and misfiled techniques have already
    had to be cleaned out of that catalog once (see `references/patterns/INDEX.md`).
- `references/rendering-metal.md` — GENERAL metal recipe (anisotropy, strip-softbox
  streak, Cycles/raytracing; dark-floor caveat). Material-specific deltas → `materials/`.
- `references/bpy_gotchas.md` — seeded bpy failure catalog. `LEARNINGS.md` — bpy
  error fixes (keyed by error_signature).

## Design judgment (grounded, render-verified)
For tactical scenes, follow `sops/05-tactical-design.md`. It is backed by:
- `DESIGN_PRINCIPLES.md` — 7 principles (P1–P7), each canon-cited and proven on a
  violating/adhering render pair with a discriminating metric.
- `CLICHES.md` — debunked defaults to AVOID (leading lines, trusting a
  screenshot/plan, auto-flagging dead-ends, gratuitous verticality).
- `design/CONFLICTS.md` — named tradeoffs + default leans (anchor vs occlusion;
  fairness vs expressive asymmetry).
- `design/metrics.py` — image checks (`summary_for(png)`); they capture ~half of
  "good" and are colour-blind + dark-scene-biased — judge the final read by eye.
Same anti-poison rule as LEARNINGS.md: record a principle only after a render
verified it. Canon C1 (book.leveldesignbook.com) is CC BY-NC-SA — flag if used
commercially.
