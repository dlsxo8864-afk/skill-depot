# LEARNINGS — persistent correction log

Append-only. One entry per solved NEW failure. **Record only AFTER a
render/inspect actually PASSED** — `verified_by` names that render. Never write
a guess; an unverified "fix" poisons the catalog. Dedupe by `error_signature`
(if it's already here or in `references/bpy_gotchas.md`, don't duplicate —
refine the existing entry). Promote durable, general lessons into
`references/bpy_gotchas.md`.

Note: `verified_by` renders live in the local-only `_tmp/` directory, which is
gitignored — on a fresh clone they are absent. Re-run the referenced pass/build
script to regenerate the evidence.

Entry format:
```
### <error_signature>
- date: YYYY-MM-DD
- blender_version: X.Y.Z
- error_signature: <short stable key, matches debug.py / gotchas>
- root_cause: <why it happened>
- fix: <exact change that resolved it>
- verified_by: <render/inspect that PASSED proving the fix>
```

---

### principled_socket_renamed
- date: 2026-06-21
- blender_version: 5.1.2
- error_signature: principled_socket_renamed
- root_cause: Hard-coded the pre-4.0 Principled input name `bsdf.inputs["Specular"]`. Blender 4.0 renamed it to "Specular IOR Level" (and `Emission`→`Emission Color`, etc.), so on 5.1.2 the lookup raises `KeyError: key "Specular" not found`.
- fix: Route all Principled writes through `blendkit.compat.principled_set(bsdf, specular=0.5, ...)`, which tries the new name first and falls back to the old one, setting whichever socket exists on this build.
- verified_by: `_tmp/proof/fixed_specular_contact.png` — material built with `compat.principled_set(specular=...)` rendered with non-zero luminance and a clean `inspect.scene_report` (ok: True). See proof run in the build session.

### eevee_glass_opaque
- date: 2026-06-21
- blender_version: 5.1.2
- error_signature: eevee_glass_opaque
- root_cause: A `material.glass()` (transmission=1, `use_screen_refraction`/`use_raytrace_refraction` on the material) rendered as a solid BLACK sphere in EEVEE. EEVEE Next (4.2+/5.x) ignores material refraction unless scene-level ray tracing is on (`scene.eevee.use_raytracing`, default False).
- fix: `render._set_engine` now enables `scene.eevee.use_raytracing` (and legacy `use_ssr`/`use_ssr_refraction`) whenever a refractive material is present in the scene (`material.needs_refraction`). `material.glass()` sets both the legacy and EEVEE-Next material flags.
- verified_by: dogfood pass `multi_material` after-render — the glass sphere shows clear refraction/lensing (front view) instead of an opaque black sphere.

### flat_shaded_primitives
- date: 2026-06-21
- blender_version: 5.1.2
- error_signature: flat_shaded_primitives
- root_cause: bmesh-built curved primitives (`add_uv_sphere`/`add_cylinder`/`add_cone`) default to FLAT shading, so spheres/cylinders render visibly faceted (concentric banding on a sphere top-down).
- fix: `build._finish` takes a `smooth` mode: `'all'` (sphere -> every face smooth), `'sides'` (cylinder/cone -> smooth the curved sides, keep caps flat via near-±Z normal test). Boxes/planes stay flat.
- verified_by: dogfood pass `harsh_lighting` after-render — the sphere top-down view is a smooth gradient with no faceting.

### ortho_blueprint_aspect_clip
- date: 2026-06-21
- blender_version: 5.1.2
- error_signature: ortho_blueprint_aspect_clip
- root_cause: `frame_scene_ortho_top` set `ortho_scale` from the footprint only. `ortho_scale` maps to the LONGER render axis, so on a non-square render (e.g. 4:3) the short axis was clipped — the blueprint cut off the scene's corners. `frame_scene` (perspective) had the same flaw (fit horizontal FOV, not the smaller vertical one).
- fix: both framing helpers now read `scene.render.resolution_x/y` and size `ortho_scale`/fit-distance so BOTH axes fit with margin; `render.canonical_views` sets the resolution BEFORE building the framing cameras.
- verified_by: dogfood pass `empty_stage` after-render — the top view shows the full square ground centered with margin on all four sides.

### autoframe_dwarfs_subject
- date: 2026-06-21
- blender_version: 5.1.2
- error_signature: autoframe_dwarfs_subject
- root_cause: `frame_scene` fit the entire scene AABB; a large ground plane dominated the bounds so the actual prop occupied a tiny fraction of the frame (a dot in the top view).
- fix: `_scene_aabb` excludes floor-like objects (`FLOOR_NAMES = Ground/Floor`) from the framing bounds, falling back to ALL geometry only when excluding would leave nothing (so an empty stage still frames the ground). Exposed via `ignore_names` on both framing helpers.
- verified_by: dogfood passes `single_prop` (prop now fills frame) and `empty_stage` (ground still framed — no regression).
