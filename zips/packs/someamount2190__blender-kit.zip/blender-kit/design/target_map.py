"""target_map.py — the actual tactical-map blockout for Phase 3 (APPLY).

A single-player tactical compound: a central objective building with a doorway,
an approach with cover, optional landmark, configurable lighting/clutter. A
player reference (1.0x1.8 m) stands in the doorway so P4 (fit) is checkable.

Run:  blender -b --python target_map.py -- <version> '<json_config_overrides>'
Prints SCORE_JSON with per-principle dimension scores + the canonical renders.
Config is passed in (not edited in-file) so every Phase-3 change is explicit and
revertible — same map + same config => same score.
"""
import os, sys, json, math
# derive the skill root from __file__ (same pattern as the pass scripts) —
# audit fix: the hardcoded per-user path broke any other user/clone.
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(SKILL, "scripts"))
sys.path.insert(0, os.path.join(SKILL, "design"))
import bpy
from blendkit import build, transform, material, light, camera, render
from blendkit import inspect as bk_inspect
import metrics as M

DEFAULT = {
    "landmark": False,      # P1/P3 wayfinding anchor
    "passage_width": 0.9,   # P4 fit (player is 1.0 wide)  -> too narrow by default
    "passage_height": 2.0,
    "light_mode": "flat",   # P6  "flat" | "directed"
    "clutter": 28,          # P5 premature greebles
    "value_split": False,   # P5/P3 wall!=floor value
}
PLAYER_W, PLAYER_H = 1.0, 1.8

argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
VERSION = argv[0] if argv else "v0"
CFG = dict(DEFAULT)
if len(argv) > 1 and argv[1].strip():
    CFG.update(json.loads(argv[1]))

OUT = os.path.join(SKILL, "_tmp", "design", "target", VERSION)
os.makedirs(OUT, exist_ok=True)


def _clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for m in list(bpy.data.materials):
        bpy.data.materials.remove(m)


def build_map():
    floor_col = (0.5, 0.5, 0.52, 1) if CFG["value_split"] else (0.5, 0.5, 0.5, 1)
    wall_col = (0.32, 0.32, 0.34, 1) if CFG["value_split"] else (0.5, 0.5, 0.5, 1)
    g = build.add_ground("Ground", size=34, location=(0, 0, 0))
    material.assign(g, material.concrete("Floor", color=floor_col))
    wm = material.concrete("WallMat", color=wall_col)

    # central objective building (4 walls + the doorway in the front/-Y wall)
    bw, bd, bh = 6.0, 6.0, 3.2
    pw, ph = CFG["passage_width"], CFG["passage_height"]
    material.assign(build.add_box("BWallBack", (bw, 0.3, bh), (0, 3, bh / 2)), wm)
    material.assign(build.add_box("BWallL", (0.3, bd, bh), (-3, 0, bh / 2)), wm)
    material.assign(build.add_box("BWallR", (0.3, bd, bh), (3, 0, bh / 2)), wm)
    jamb = (bw / 2 - pw / 2)
    material.assign(build.add_box("DoorL", (jamb, 0.3, bh), (-(pw / 2 + jamb / 2), -3, bh / 2)), wm)
    material.assign(build.add_box("DoorR", (jamb, 0.3, bh), ((pw / 2 + jamb / 2), -3, bh / 2)), wm)
    if ph < bh:
        material.assign(build.add_box("DoorTop", (pw, 0.3, bh - ph), (0, -3, (ph + bh) / 2)), wm)

    # objective inside
    obj = build.add_cylinder("Objective", radius=0.6, height=1.0, location=(0, 0.5, 0.5))
    material.assign(obj, material.emissive("Obj", color=(0.9, 0.8, 0.4, 1), strength=4))

    # approach cover
    cm = material.plastic("Cover", color=(0.55, 0.47, 0.38, 1))
    for i, (x, y) in enumerate([(-4, -7), (3.5, -6), (-2, -10), (5, -9), (0, -8)]):
        material.assign(build.add_box("Cover%d" % i, (1.3, 1.3, 1.2), (x, y, 0.6)), cm)

    # player reference standing in the doorway (P4 fit)
    p = build.add_box("PlayerRef", (PLAYER_W, PLAYER_W, PLAYER_H), (0, -3, PLAYER_H / 2))
    material.assign(p, material.emissive("Player", color=(0.2, 0.8, 1.0, 1), strength=3))

    # optional landmark (P1/P3)
    if CFG["landmark"]:
        t = build.add_cylinder("Landmark", radius=0.8, height=6.5, location=(0, 4, 3.25))
        material.assign(t, material.concrete("LM", color=(0.7, 0.68, 0.64, 1)))
        cap = build.add_uv_sphere("LMTop", radius=0.9, location=(0, 4, 7.0))
        material.assign(cap, material.emissive("LMTop", color=(1.0, 0.55, 0.2, 1), strength=14))

    # premature clutter (P5)
    n = int(CFG["clutter"])
    for i in range(n):
        h = (i * 2654435761) & 0xFFFFFFFF
        x = ((h % 1000) / 1000.0 - 0.5) * 12
        y = (((h // 1000) % 1000) / 1000.0 - 0.5) * 10 - 4
        z = 0.2 + ((h // 1000000) % 200) / 100.0
        s = 0.12 + ((h // 7) % 8) / 100.0
        material.assign(build.add_box("Gr%d" % i, (s, s, s), (x, y, z)), cm)

    # lighting
    if CFG["light_mode"] == "directed":
        light.three_point(target=(0, -3, 1.2), distance=12, height=7)
        light.world_sky(strength=0.35)
    else:  # flat
        light.world_sky(strength=1.1, color=(0.5, 0.5, 0.55, 1))
        light.sun("Flat", energy=1.4, angle_deg=(8, 0, 0))


def score():
    rep = bk_inspect.scene_report(print_it=False)
    player_overlaps = [o for o in rep["overlaps"] if "PlayerRef" in (o["a"], o["b"])]
    # canonical views
    persp = camera.frame_scene(direction=(0.4, -1, 0.4), make_active=True)
    pj = os.path.join(OUT, "%s_persp.png" % VERSION)
    render.render_still(pj, resolution=(560, 420))
    top = camera.frame_scene_ortho_top(make_active=True)
    tj = os.path.join(OUT, "%s_top.png" % VERSION)
    render.render_still(tj, resolution=(480, 480))
    render.contact_sheet([pj, tj], os.path.join(OUT, "%s_pair.png" % VERSION))

    m = M.summary_for(pj)

    def clamp(v):
        return max(0.0, min(1.0, v))
    notes = []
    # P5/P3 readability: less clutter is better (target edge_density <= 0.012).
    # Audit fix: an empty/black frame has edge_density 0 and used to score a
    # PERFECT 1.0 — gate on content presence first.
    if m["mean_luminance"] < 0.02:
        readability = 0.0
        notes.append("readability: no_content (mean_luminance %.4f < 0.02 — "
                     "empty/black frame, edge_density is meaningless)"
                     % m["mean_luminance"])
    else:
        readability = round(clamp(1 - (m["edge_density"] - 0.010) / 0.020), 3)
    dims = {
        "readability": readability,
        # P1/P3 hierarchy/anchor: clear focal. Audit fix: rescaled — a
        # landmark-less scene sits at focal_ratio ~7 and clamp(f/10) gave it 71%
        # credit; calibration pair from CONFLICTS.md: V=7.10 (no anchor) /
        # A=10.14 (anchor), so score (f-6)/6 -> ~0.17 at 7, 1.0 at >=12.
        "hierarchy": round(clamp((m["focal_ratio"] - 6.0) / 6.0), 3),
        # P6 lighting: not flat (target contrast ~ 0.18)
        "lighting": round(clamp(m["contrast"] / 0.18), 3),
        # P4 fit: player clears the doorway (no overlaps)
        "fit": 1.0 if not player_overlaps else 0.0,
        # massing value grouping: a few groups (target entropy ~ 1.8, range 0..3)
        "massing": round(clamp(1 - abs(m["value_entropy"] - 1.8) / 1.8), 3),
    }
    composite = round(sum(dims.values()) / len(dims), 3)
    out = {"version": VERSION, "config": CFG, "dims": dims, "composite": composite,
           "metrics": m, "player_overlaps": len(player_overlaps),
           "pair": os.path.join(OUT, "%s_pair.png" % VERSION)}
    if notes:
        out["notes"] = notes
    print("SCORE_JSON:", json.dumps(out))
    weakest = min(dims, key=dims.get)
    print("WEAKEST:", weakest, dims[weakest])
    return out


if __name__ == "__main__":
    _clear()
    build_map()
    score()
