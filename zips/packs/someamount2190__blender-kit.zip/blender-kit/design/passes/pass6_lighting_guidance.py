"""Pass 6 / Lighting — light/dark contrast guides the player.
Canon C3 (World of Level Design, Magnar Jenssen "Functional Lighting"):
https://www.worldofleveldesign.com/categories/wold-members-tutorials/magnar_jenssen/functional-lighting-magnar-jenssen.php
Claim: "The intensity of the exit-area draws the player in." A brighter goal
reads as the destination; uniform flat lighting gives no directional cue.
Geometry is IDENTICAL (two exits); only the LIGHTING changes.
VIOLATE: flat even lighting -> both exits equal, no cue.
ADHERE:  the intended (right) exit lit brighter -> clear pull.
Expect: balance.dx shifts toward the lit exit; focal_ratio + contrast up in A.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
import bpy
from blendkit import build, material, light, transform


def _room():
    g = build.add_ground("Ground", size=24, location=(0, 0, 0))
    material.assign(g, material.concrete("Floor", color=(0.45, 0.45, 0.47, 1)))
    wm = material.concrete("WallMat", color=(0.5, 0.5, 0.5, 1))
    # back wall at y=3 with two 2 m openings (left ~x=-2.5, right ~x=+2.5)
    for name, x, w in [("JambL", -4.75, 2.5), ("Center", 0, 3.0), ("JambR", 4.75, 2.5)]:
        material.assign(build.add_box(name, (w, 0.3, 3), (x, 3, 1.5)), wm)
    material.assign(build.add_box("LintelL", (2, 0.3, 0.6), (-2.5, 3, 2.7)), wm)
    material.assign(build.add_box("LintelR", (2, 0.3, 0.6), (2.5, 3, 2.7)), wm)
    # side walls so the camera reads an interior
    material.assign(build.add_box("SideL", (0.3, 6, 3), (-6, 0, 1.5)), wm)
    material.assign(build.add_box("SideR", (0.3, 6, 3), (6, 0, 1.5)), wm)


def violate():
    _room()
    # flat, even ambient -> no exit stands out
    light.world_sky(strength=1.3, color=(0.5, 0.5, 0.55, 1))
    s = light.sun("FlatSun", energy=1.2, angle_deg=(5, 0, 0))


def adhere():
    _room()
    light.world_sky(strength=0.25, color=(0.06, 0.07, 0.09, 1))
    # bright pool at the RIGHT exit (the intended path)
    a = bpy.data.lights.new("ExitGlow", type='AREA'); a.energy = 700; a.size = 2.5
    ob = bpy.data.objects.new("ExitGlow", a)
    bpy.context.scene.collection.objects.link(ob)
    ob.location = (2.5, 4.2, 2.6); transform.look_at(ob, (2.5, 2.0, 0.5))
    # faint emissive patch in the right alcove so the opening itself reads bright
    patch = build.add_box("Glow", (1.8, 0.1, 2.0), (2.5, 3.2, 1.2))
    material.assign(patch, material.emissive("ExitMat", color=(1.0, 0.85, 0.6, 1), strength=6))
    # weak key so the room isn't black
    light.sun("Key", energy=0.6, angle_deg=(50, 0, 30))


if __name__ == "__main__":
    run_pair("pass6_lighting", violate, adhere, cam_loc=(0, -6.5, 1.7), cam_look=(0, 3, 1.3), lens=30)
