"""Pass 7 / Balance — symmetry for competitive fairness.
Canon C1: https://book.leveldesignbook.com/process/combat/balance
Claim: "the most straightforward way to balance a map is to use symmetry" — give
each team an equal layout/territory. Caveat: fairness is psychological; symmetry
is the floor, not a guarantee.
VIOLATE: asymmetric arena — one side dense with cover, the other barren (unfair).
ADHERE:  mirror-symmetric arena — both sides identical cover.
Expect: symmetry metric high in A, low in V; balance.dx ~0 in A, left-heavy in V.
Centered camera on the x=0 mirror axis.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
from blendkit import build, material, light


def _common():
    g = build.add_ground("Ground", size=24, location=(0, 0, 0))
    material.assign(g, material.concrete("Floor", color=(0.42, 0.42, 0.44, 1)))
    # SYMMETRIC lighting (even sky + straight-down sun) so luminance symmetry
    # reflects GEOMETRY symmetry, not an off-axis key light (the bug in v1/v2).
    light.world_sky(strength=1.0, color=(0.5, 0.5, 0.55, 1))
    light.sun("TopSun", energy=2.0, angle_deg=(0, 0, 0))
    # central neutral objective on the mirror axis
    obj = build.add_cylinder("Objective", radius=0.7, height=1.0, location=(0, 0, 0.5))
    material.assign(obj, material.emissive("Obj", color=(0.9, 0.8, 0.4, 1), strength=5))


def _cover(name, x, y, cm):
    # taller, larger cover so the asymmetry occupies real frame area
    # layout constants must match pass7/conflict2 — audit finding: drifted
    # copies invalidated the 'same arena' comparison (cover 2.6, ortho_scale 20)
    c = build.add_box(name, (1.6, 1.6, 2.6), (x, y, 1.3))
    material.assign(c, cm)


_LAYOUT = [(5, 1.5), (4, -3), (6.2, -0.5), (3.2, 2.5), (5.2, 4)]


def violate():
    _common()
    cm = material.plastic("Cover", color=(0.6, 0.5, 0.4, 1))
    # tall cover only on the LEFT half -> that team is advantaged, right is barren
    for i, (x, y) in enumerate(_LAYOUT):
        _cover("L%d" % i, -x, y, cm)


def adhere():
    _common()
    cm = material.plastic("Cover", color=(0.6, 0.5, 0.4, 1))
    # mirror the same layout on both halves -> equal territory
    for i, (x, y) in enumerate(_LAYOUT):
        _cover("L%d" % i, -x, y, cm)
        _cover("R%d" % i, x, y, cm)


if __name__ == "__main__":
    # top-down ORTHO 'blueprint' so the x=0 mirror axis maps to image center and
    # luminance symmetry tracks layout symmetry exactly.
    run_pair("pass7_balance", violate, adhere, cam_loc=(0, 0, 22), cam_look=(0, 0, 0),
             ortho=True, ortho_scale=20)
