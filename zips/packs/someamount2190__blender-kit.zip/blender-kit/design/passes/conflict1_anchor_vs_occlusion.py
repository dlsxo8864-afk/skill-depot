"""Conflict 1 — visible anchor (P1/P3) vs occluded sightline (P2).
P1/P3 want a landmark VISIBLE for orientation; P2 wants the path HIDDEN for
suspense. They look mutually exclusive. Hypothesis (resolution): separate them by
SCALE — keep the distant landmark visible (global orientation) while occluding
the IMMEDIATE ground path (local suspense).
VIOLATE (over-occlude, "lost"): tall cross-wall hides EVERYTHING incl. the
distant beacon -> suspense but no anchor.
ADHERE  (resolved): lower cross-wall still hides the ground path around the
corner, but the tall beacon shows ABOVE it -> anchor AND local mystery.
Same camera. Expect: distant beacon focal present in A, absent in V; the near
ground path occluded in BOTH.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
from blendkit import build, material, light


def _common():
    g = build.add_ground("Ground", size=40, location=(0, 10, 0))
    material.assign(g, material.concrete("Floor", color=(0.4, 0.4, 0.42, 1)))
    wm = material.concrete("WallMat", color=(0.5, 0.5, 0.5, 1))
    material.assign(build.add_box("WallL", (0.3, 6, 3), (-1.8, 3, 1.5)), wm)
    material.assign(build.add_box("WallR", (0.3, 6, 3), (1.8, 3, 1.5)), wm)
    # the local reward hidden on the floor around the corner (occluded in both)
    r = build.add_box("Hidden", (1.0, 1.0, 0.6), (0, 7, 0.3))
    material.assign(r, material.emissive("Hidden", color=(0.3, 1.0, 0.4, 1), strength=6))
    # the distant landmark beacon (global orientation anchor)
    t = build.add_cylinder("Beacon", radius=0.7, height=7.0, location=(0, 22, 3.5))
    material.assign(t, material.concrete("BeaconMat", color=(0.7, 0.68, 0.64, 1)))
    cap = build.add_uv_sphere("BeaconTop", radius=0.9, location=(0, 22, 7.6))
    material.assign(cap, material.emissive("BeaconTop", color=(1.0, 0.55, 0.2, 1), strength=16))
    light.sun("Sun", energy=2.0, angle_deg=(55, 0, 20))
    light.world_sky(strength=0.4)
    return wm


def _crosswall(h):
    wm = material.concrete("CrossMat", color=(0.5, 0.5, 0.5, 1))
    material.assign(build.add_box("Cross", (3.6, 0.3, h), (0, 5.5, h / 2)), wm)


def violate():
    _common()
    _crosswall(h=6.0)   # tall: hides the beacon too -> player is lost


def adhere():
    _common()
    _crosswall(h=2.4)   # low: beacon shows above, ground path still hidden


if __name__ == "__main__":
    run_pair("conflict1", violate, adhere, cam_loc=(0, -1.5, 1.6), cam_look=(0, 8, 2.2), lens=32)
