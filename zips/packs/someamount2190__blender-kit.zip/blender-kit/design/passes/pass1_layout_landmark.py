"""Pass 1 / Layout — landmark wayfinding anchor.
Canon C1: https://book.leveldesignbook.com/process/layout
Claim: a distinct landmark gives a wayfinding anchor; a field of interchangeable
forms gives the eye nothing to lock onto.
VIOLATE: 7 identical crates in a ring, no landmark.
ADHERE:  same ring, but one tall lit tower as a unique landmark.
Expect: focal_ratio(A) >> focal_ratio(V); balance offset shifts toward tower.
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
from blendkit import build, material, light


def _ring(n=7, r=4.0):
    pts = []
    for i in range(n):
        a = 2 * math.pi * i / n
        pts.append((r * math.cos(a), r * math.sin(a)))
    return pts


def _common():
    g = build.add_ground("Ground", size=18, location=(0, 0, 0))
    material.assign(g, material.concrete())
    light.three_point(target=(0, 0, 1), distance=14, height=10)
    light.world_sky(strength=0.4)


def violate():
    _common()
    crate_mat = material.plastic("Crate", color=(0.55, 0.45, 0.35, 1))
    for i, (x, y) in enumerate(_ring()):
        c = build.add_box("Crate%d" % i, size=(1.2, 1.2, 1.2), location=(x, y, 0.6))
        material.assign(c, crate_mat)


def adhere():
    _common()
    crate_mat = material.plastic("Crate", color=(0.55, 0.45, 0.35, 1))
    pts = _ring()
    for i, (x, y) in enumerate(pts[1:], start=1):
        c = build.add_box("Crate%d" % i, size=(1.2, 1.2, 1.2), location=(x, y, 0.6))
        material.assign(c, crate_mat)
    # one distinct landmark: a tall, lit tower replacing the first crate slot
    x, y = pts[0]
    tower = build.add_cylinder("Tower", radius=0.9, height=5.0, location=(x, y, 2.5))
    material.assign(tower, material.concrete("TowerMat", color=(0.75, 0.72, 0.68, 1)))
    cap = build.add_uv_sphere("Beacon", radius=0.7, location=(x, y, 5.4))
    material.assign(cap, material.emissive("Beacon", color=(1.0, 0.55, 0.2, 1), strength=14))


if __name__ == "__main__":
    run_pair("pass1_layout", violate, adhere, cam_loc=(11, -11, 8), cam_look=(0, 0, 1.0))
