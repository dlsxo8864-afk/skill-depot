"""Pass 2 / Flow — occluded sightline builds anticipation.
Canon C1: https://book.leveldesignbook.com/process/layout/flow
Claim: a blind corner that hides what's ahead is "more exciting than a straight
clear open path" — the player can't see the reward/threat until they commit.
VIOLATE: straight corridor; the lit end-marker is fully visible from the mouth.
ADHERE:  dogleg corridor; the same marker is occluded around the corner.
Same fixed player-eye camera. Expect: marker visible -> high focal/bright far
region (V); occluded -> marker not in frame, lower far brightness (A).
CAVEAT the source itself gives: this serves a SUSPENSE goal; a flat open path is
fine for other goals. Not a universal good.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
from blendkit import build, material, light


def _common():
    g = build.add_ground("Ground", size=30, location=(0, 0, 0))
    material.assign(g, material.concrete("FloorMat", color=(0.4, 0.4, 0.42, 1)))
    light.sun("Sun", energy=2.5, angle_deg=(55, 0, 25))
    light.world_sky(strength=0.5)


def _wall(name, size, loc, mat):
    w = build.add_box(name, size=size, location=loc)
    material.assign(w, mat)
    return w


def violate():
    _common()
    wm = material.concrete("WallMat", color=(0.55, 0.55, 0.55, 1))
    _wall("WallL", (0.3, 14, 3), (-1.5, 7, 1.5), wm)
    _wall("WallR", (0.3, 14, 3), (1.5, 7, 1.5), wm)
    marker = build.add_box("Marker", size=(1.6, 0.4, 1.6), location=(0, 12, 1.0))
    material.assign(marker, material.emissive("Marker", color=(1.0, 0.35, 0.2, 1), strength=18))


def adhere():
    _common()
    wm = material.concrete("WallMat", color=(0.55, 0.55, 0.55, 1))
    _wall("WallL", (0.3, 7, 3), (-1.5, 3.5, 1.5), wm)     # left, y 0..7
    _wall("WallR", (0.3, 7, 3), (1.5, 3.5, 1.5), wm)      # right, y 0..7
    _wall("WallEnd", (3.3, 0.3, 3), (0, 7, 1.5), wm)      # blocks straight-ahead view
    # path turns right (+X); marker sits around the corner, occluded from the mouth
    _wall("WallFar", (0.3, 6, 3), (5, 6, 1.5), wm)
    marker = build.add_box("Marker", size=(0.4, 1.6, 1.6), location=(4, 6, 1.0))
    material.assign(marker, material.emissive("Marker", color=(1.0, 0.35, 0.2, 1), strength=18))


if __name__ == "__main__":
    # player-eye camera at the corridor mouth, looking down +Y
    run_pair("pass2_flow", violate, adhere, cam_loc=(0, -1.5, 1.6), cam_look=(0, 6, 1.2), lens=35)
