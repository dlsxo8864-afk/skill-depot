"""Pass 4 / Metrics — build to player metrics; the player must FIT.
Canon C1: https://book.leveldesignbook.com/process/blockout/metrics
Rules used: Unity player bbox 1.0 x 1.8 m; doorway 1.25 x 2.5 m; "minimum
hallway width should be at least double the player width."
VIOLATE: doorway 0.8 x 1.5 m -> the 1.0x1.8 player reference clips the jambs and
lintel (inspect reports overlaps).
ADHERE:  doorway 1.4 x 2.4 m -> player fits with clearance (no overlaps).
DISCRIMINATOR: inspect.scene_report overlap count (the skill's own metric), plus
the render showing the player jammed vs clear.
"""
import os, sys, json
# derive the skill root from __file__ (same pattern as the other passes) —
# audit fix: the hardcoded per-user path broke any other user/clone.
SKILL = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(SKILL, "scripts"))
import bpy
from blendkit import build, transform, material, light, camera, render
from blendkit import inspect as bk_inspect

OUT = os.path.join(SKILL, "_tmp", "design", "pass4_metrics")
os.makedirs(OUT, exist_ok=True)
PLAYER_W, PLAYER_H = 1.0, 1.8
WALL_W, WALL_H, WALL_T = 8.0, 3.0, 0.3


def _clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for m in list(bpy.data.materials):
        bpy.data.materials.remove(m)


def build_scene(open_w, open_h):
    g = build.add_ground("Ground", size=20, location=(0, 0, 0))
    material.assign(g, material.concrete())
    wm = material.concrete("WallMat", color=(0.55, 0.55, 0.55, 1))
    lj_w = WALL_W / 2 - open_w / 2
    material.assign(build.add_box("JambL", (lj_w, WALL_T, WALL_H),
                    (-(open_w / 2 + lj_w / 2), 0, WALL_H / 2)), wm)
    material.assign(build.add_box("JambR", (lj_w, WALL_T, WALL_H),
                    ((open_w / 2 + lj_w / 2), 0, WALL_H / 2)), wm)
    if open_h < WALL_H:
        material.assign(build.add_box("Lintel", (open_w, WALL_T, WALL_H - open_h),
                        (0, 0, (open_h + WALL_H) / 2)), wm)
    # the player reference (1.0 x 1.8 m), standing in the doorway
    p = build.add_box("PlayerRef", (PLAYER_W, PLAYER_W, PLAYER_H), (0, 0, PLAYER_H / 2))
    material.assign(p, material.emissive("Player", color=(0.2, 0.8, 1.0, 1), strength=4))
    light.three_point(target=(0, 0, 1.2), distance=9, height=5)
    light.world_sky(strength=0.4)


def run(tag, open_w, open_h):
    _clear()
    build_scene(open_w, open_h)
    # ignore floor for overlap; the doorway frame vs player is what matters
    rep = bk_inspect.scene_report(print_it=False)
    cam = camera.add_camera("cam", location=(0, -6.5, 1.7), look=(0, 0, 1.1),
                            lens_mm=40, make_active=True)
    p = os.path.join(OUT, "pass4_%s.png" % tag)
    info = render.render_still(p, resolution=(420, 380))
    door_overlaps = [o for o in rep["overlaps"] if "PlayerRef" in (o["a"], o["b"])]
    print("RESULT", tag, json.dumps({"opening": [open_w, open_h],
          "player_overlaps": door_overlaps, "overlap_count": len(door_overlaps),
          "render": p, "lum": info["luminance"]}))
    return p


if __name__ == "__main__":
    pv = run("violate", 0.8, 1.5)
    pa = run("adhere", 1.4, 2.4)
    render.contact_sheet([pv, pa], os.path.join(OUT, "pass4_metrics_pair.png"))
    print("PAIR:", os.path.join(OUT, "pass4_metrics_pair.png"))
