"""Pass 3 / Massing+Composition — hierarchy is LOCAL CONTRAST.
Canon C1: https://book.leveldesignbook.com/process/blockout/massing/composition
Claim: "A tall thing only seems special if it is surrounded by short things."
The SAME landmark is held constant; only the neighbours' height changes.
VIOLATE: tall tower among equally-tall towers -> no hierarchy, it blends.
ADHERE:  same tower among short blocks -> it dominates and reads as a landmark.
Expect: focal_ratio + skyline_variation higher in A; tower identical in both.
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
from blendkit import build, material, light


def _common():
    g = build.add_ground("Ground", size=20, location=(0, 0, 0))
    material.assign(g, material.concrete())
    light.three_point(target=(0, 0, 1.5), distance=14, height=9)
    light.world_sky(strength=0.4)


def _tower():
    # the constant "landmark" — identical in both scenes
    t = build.add_cylinder("Tower", radius=0.8, height=3.6, location=(0, 0, 1.8))
    material.assign(t, material.concrete("TowerMat", color=(0.72, 0.7, 0.66, 1)))


def _neighbors(height):
    nm = material.plastic("Block", color=(0.5, 0.45, 0.4, 1))
    for i, (x, y) in enumerate([(-3, -1), (3, -1), (-2.5, 2.5), (2.5, 2.5), (0, -3)]):
        b = build.add_box("Block%d" % i, size=(1.4, 1.4, height), location=(x, y, height / 2))
        material.assign(b, nm)


def violate():
    _common()
    _neighbors(height=3.6)   # neighbours as tall as the tower -> no hierarchy
    _tower()


def adhere():
    _common()
    _neighbors(height=0.8)   # short neighbours -> the tower dominates
    _tower()


if __name__ == "__main__":
    run_pair("pass3_massing", violate, adhere, cam_loc=(9, -9, 3.2), cam_look=(0, 0, 1.6), lens=45)
