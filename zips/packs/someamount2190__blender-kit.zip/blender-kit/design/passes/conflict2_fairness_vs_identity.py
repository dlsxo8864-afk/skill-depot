"""Conflict 2 — expressive asymmetry (P3 hierarchy / P6 light-guidance) vs
symmetry-for-fairness (P7).
P7 demands mirror symmetry so neither team is advantaged; P3/P6 want contrast and
asymmetry for hierarchy, orientation and identity. Pure symmetry is fair but
disorienting ("which side is mine?", "feels artificial" per the source).
Hypothesis (resolution): LAYER them — keep GAMEPLAY geometry mirror-symmetric
(fairness) and put the asymmetry only in the NON-GAMEPLAY cosmetic layer
(per-side colour/landmark identity). The source: symmetry "requires extensive
thoughtful art passing to differentiate the two areas."
VIOLATE: mirrored geometry, both sides IDENTICAL grey -> fair but no identity.
ADHERE:  SAME mirrored geometry, sides tinted blue/orange -> fair AND oriented.
Top-down ortho + flat symmetric light so geometry symmetry is measurable.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
from blendkit import build, material, light

_LAYOUT = [(5, 1.5), (4, -3), (6.2, -0.5), (3.2, 2.5), (5.2, 4)]


def _common():
    g = build.add_ground("Ground", size=24, location=(0, 0, 0))
    material.assign(g, material.concrete("Floor", color=(0.42, 0.42, 0.44, 1)))
    light.world_sky(strength=1.0, color=(0.5, 0.5, 0.55, 1))
    light.sun("TopSun", energy=2.0, angle_deg=(0, 0, 0))


def _cover(name, x, y, cm):
    # layout constants must match pass7/conflict2 — audit finding: drifted
    # copies invalidated the 'same arena' comparison (cover 2.6, ortho_scale 20)
    c = build.add_box(name, (1.6, 1.6, 2.6), (x, y, 1.3))
    material.assign(c, cm)


def violate():
    _common()
    cm = material.plastic("Cover", color=(0.6, 0.6, 0.6, 1))  # identical both sides
    for i, (x, y) in enumerate(_LAYOUT):
        _cover("L%d" % i, -x, y, cm)
        _cover("R%d" % i, x, y, cm)
    # identical neutral beacons -> no side identity
    for s, x in (("L", -8), ("R", 8)):
        b = build.add_cylinder("Beacon%s" % s, radius=0.6, height=3.0, location=(x, 0, 1.5))
        material.assign(b, material.emissive("B%s" % s, color=(0.9, 0.9, 0.9, 1), strength=5))


def adhere():
    _common()
    blue = material.plastic("Blue", color=(0.2, 0.35, 0.85, 1))
    orange = material.plastic("Orange", color=(0.9, 0.45, 0.12, 1))
    # SAME mirrored positions (fairness intact); colour differs per side (identity)
    for i, (x, y) in enumerate(_LAYOUT):
        _cover("L%d" % i, -x, y, blue)
        _cover("R%d" % i, x, y, orange)
    bl = build.add_cylinder("BeaconL", radius=0.6, height=3.0, location=(-8, 0, 1.5))
    material.assign(bl, material.emissive("BL", color=(0.3, 0.5, 1.0, 1), strength=6))
    br = build.add_cylinder("BeaconR", radius=0.6, height=3.0, location=(8, 0, 1.5))
    material.assign(br, material.emissive("BR", color=(1.0, 0.5, 0.15, 1), strength=6))


if __name__ == "__main__":
    run_pair("conflict2", violate, adhere, cam_loc=(0, 0, 22), cam_look=(0, 0, 0),
             ortho=True, ortho_scale=20)
