"""Pass 5 / Blockout — greybox simple shapes BEFORE detail.
Canon C1: https://book.leveldesignbook.com/process/blockout
Claim: detail too early is "a distraction"; blockout reads as a few big shapes.
Premature greebling buries the silhouette/massing you are supposed to be testing.
VIOLATE: the same massing buried under ~50 small greeble boxes (detail too early).
ADHERE:  clean greybox massing, no detail.
Expect: edge_density + value_entropy much higher in V; big shapes readable in A.
Greeble placement is DETERMINISTIC (index hashing) — no RNG.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from dharness import run_pair
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "scripts"))
from blendkit import build, material, light


def _massing():
    gm = material.concrete("Grey", color=(0.55, 0.55, 0.55, 1))
    forms = [
        build.add_box("Base", (5, 4, 1.0), (0, 0, 0.5)),
        build.add_box("Tower", (1.6, 1.6, 4.0), (-1.2, 0.6, 2.0)),
        build.add_box("Wing", (3.0, 1.4, 1.8), (1.4, -0.8, 0.9)),
    ]
    for f in forms:
        material.assign(f, gm)
    return gm


def _common():
    g = build.add_ground("Ground", size=20, location=(0, 0, 0))
    material.assign(g, material.concrete("Floor", color=(0.4, 0.4, 0.42, 1)))
    light.three_point(target=(0, 0, 1.5), distance=14, height=9)
    light.world_sky(strength=0.4)


def violate():
    _common()
    gm = _massing()
    # ~50 deterministic greebles smeared over the forms (premature detail)
    n = 50
    for i in range(n):
        h = (i * 2654435761) & 0xFFFFFFFF  # cheap integer hash -> deterministic
        x = ((h % 1000) / 1000.0 - 0.5) * 5.0
        y = (((h // 1000) % 1000) / 1000.0 - 0.5) * 4.0
        z = 1.0 + ((h // 1000000) % 400) / 100.0
        s = 0.12 + ((h // 7) % 10) / 100.0
        gb = build.add_box("Greeble%d" % i, (s, s, s), (x, y, z))
        material.assign(gb, gm)


def adhere():
    _common()
    _massing()  # clean massing only


if __name__ == "__main__":
    run_pair("pass5_blockout", violate, adhere, cam_loc=(9, -9, 5), cam_look=(0, 0, 1.6), lens=45)
