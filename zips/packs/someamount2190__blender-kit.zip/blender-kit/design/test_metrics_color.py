"""Regression tests for Metric A (colour identity) + Metric B (intent entropy).

Run: blender -b --python design/test_metrics_color.py
(uses Blender's bundled numpy; no Blender scene needed — pure array fixtures).

Fixtures encode the human overrides the reviewer already adjudicated:
  - blue/orange fair arena  -> well separated (and CVD-safe)
  - grey/grey               -> poorly separated (fails in normal vision)
  - red/green               -> separable normally, COLLAPSES under CVD (caught)
  - dark scene + void tag   -> NOT penalized by intent-aware entropy
  - flat/muddy, no void tag -> still scores low (distinguishable from the above)
"""
import os, sys
# metric reasoning strings contain ΔE etc.; on Windows the system-python console
# defaults to cp1252 and printing them raises UnicodeEncodeError — force utf-8.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import metrics as M

H = W = 200
FAILS = []


def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + ("  " + extra if extra else ""))
    if not cond:
        FAILS.append(name)


# ---------------------------------------------------------------- colour math
# Sharma et al. canonical CIEDE2000 vector -> 2.0425
de = M.ciede2000((50, 2.6772, -79.7751), (50, 0.0, -82.7485))
check("ciede2000 reference vector ~2.0425", abs(de - 2.0425) < 0.01, "got %.4f" % de)
# sRGB white -> L~100 ; red -> L~53.24
labw = M._srgb_to_lab_under((1.0, 1.0, 1.0))
labr = M._srgb_to_lab_under((1.0, 0.0, 0.0))
check("sRGB white L~100", abs(labw[0] - 100) < 0.5, "L=%.2f" % labw[0])
check("sRGB red L~53.24", abs(labr[0] - 53.24) < 1.0, "L=%.2f" % labr[0])


def halves(cA, cB):
    img = np.zeros((H, W, 3), dtype=np.float32)
    img[:, :W // 2] = cA
    img[:, W // 2:] = cB
    mA = np.zeros((H, W), bool); mA[:, :W // 2] = True
    mB = np.zeros((H, W), bool); mB[:, W // 2:] = True
    return img, {"A": mA, "B": mB}


# ---------------------------------------------------------------- Metric A
img, reg = halves((0.2, 0.35, 0.85), (0.9, 0.45, 0.12))   # blue vs orange
r = M.color_identity(img, reg)
check("blue/orange separable", r["applicable"] and r["separated"],
      "score=%.1f worst=%s" % (r["score"], r["worst_condition"]))
print("   reasoning:", r["reasoning"])

img, reg = halves((0.6, 0.6, 0.6), (0.6, 0.6, 0.6))       # grey vs grey
r = M.color_identity(img, reg)
check("grey/grey poorly separated", r["applicable"] and not r["separated"]
      and r["worst_condition"] == "normal", "score=%.1f" % r["score"])
print("   reasoning:", r["reasoning"])

img, reg = halves((0.85, 0.12, 0.12), (0.12, 0.65, 0.18))  # red vs green
r = M.color_identity(img, reg)
caught = r["applicable"] and not r["separated"] and r["worst_condition"] in ("deuteranopia", "protanopia")
check("red/green CVD collapse caught", caught,
      "normalΔE=%.1f worstΔE=%.1f (%s)" % (r["normal_delta_e"], r["score"], r["worst_condition"]))
check("red/green WAS separable in normal vision", r["normal_delta_e"] >= 15,
      "normalΔE=%.1f" % r["normal_delta_e"])
# honesty: the palette band must follow the BINDING (worst-case CVD) number, not
# the comfortable normal one — else a thin CVD margin hides behind a fat normal.
check("palette band uses the binding CVD condition, not normal",
      r["palette_worst_condition"] in ("deuteranopia", "protanopia")
      and r["palette_margin"] == "fail",
      "palette binding=%s margin=%s (normal palette was fat)" % (
          r["palette_worst_condition"], r["palette_margin"]))
print("   reasoning:", r["reasoning"])

# no-op-with-warning when no masks
r0 = M.color_identity(img, None)
check("color_identity no-op without masks", r0["applicable"] is False and "warning" in r0)


# -- soft-warning margin bands (two winds: as-rendered + palette) ------------
img, reg = halves((0.2, 0.35, 0.85), (0.9, 0.45, 0.12))    # ΔE00 ~55
r = M.color_identity(img, reg)
check("both margins comfortable (well above warn)",
      r["margin"] == "comfortable" and r["palette_margin"] == "comfortable"
      and r["separated"], "score=%.1f" % r["score"])
# raise the warn line above its score -> BOTH winds thin (still a pass)
r = M.color_identity(img, reg, config={"delta_e_warn": 60.0})
check("as-rendered thin names the LIGHTING wind + owner",
      r["margin"] == "thin" and r["separated"]
      and "AS-RENDERED THIN" in r["reasoning"] and "lighting artist" in r["reasoning"])
check("palette thin names the ART wind + owner",
      r["palette_margin"] == "thin"
      and "PALETTE THIN" in r["reasoning"] and "art direction" in r["reasoning"])
print("   reasoning:", r["reasoning"])
img, reg = halves((0.6, 0.6, 0.6), (0.6, 0.6, 0.6))        # ΔE00 0
r = M.color_identity(img, reg)
check("both margins fail below threshold",
      r["margin"] == "fail" and r["palette_margin"] == "fail" and not r["separated"])


# -- palette vs as-rendered self-diagnosis (the mechanized caveat) -----------
def washed(chromatic_a, chromatic_b, chroma_frac=0.12):
    """Both sides mostly washed near-grey-white, with a chromatic minority that a
    chroma-robust representative can still recover (simulates flat lighting)."""
    img = np.zeros((H, W, 3), dtype=np.float32)
    wash = np.array([0.82, 0.82, 0.84], dtype=np.float32)
    for half, col in (((0, W // 2), chromatic_a), ((W // 2, W), chromatic_b)):
        block = np.tile(wash, (H, half[1] - half[0], 1))
        ncol = int((half[1] - half[0]) * chroma_frac)
        block[:, :ncol] = col            # chromatic minority
        img[:, half[0]:half[1]] = block
    mA = np.zeros((H, W), bool); mA[:, :W // 2] = True
    mB = np.zeros((H, W), bool); mB[:, W // 2:] = True
    return img, {"A": mA, "B": mB}

# chromatic palette (blue/orange) hidden under wash -> "lighting eats identity"
img, reg = washed((0.15, 0.30, 0.85), (0.9, 0.45, 0.10))
r = M.color_identity(img, reg)
check("lighting-eats-identity diagnosed (palette high, as-rendered low)",
      r["diagnosis"] == "lighting_eats_identity"
      and not r["separated"] and r["palette_separated"],
      "as_rendered=%.1f palette=%.1f" % (r["as_rendered_delta_e"], r["palette_delta_e"]))
print("   reasoning:", r["reasoning"])

# genuinely grey palette under the same wash -> "palette failure", NOT lighting
img, reg = washed((0.80, 0.80, 0.82), (0.80, 0.80, 0.82))
r = M.color_identity(img, reg)
check("grey palette diagnosed as palette_failure (not lighting)",
      r["diagnosis"] == "palette_failure" and not r["palette_separated"],
      "palette=%.1f" % r["palette_delta_e"])
print("   reasoning:", r["reasoning"])

# albedo image overrides the chroma proxy with ground-truth palette
litimg, reg = washed((0.15, 0.30, 0.85), (0.9, 0.45, 0.10))
albedo = np.zeros((H, W, 3), dtype=np.float32)
albedo[:, :W // 2] = (0.15, 0.30, 0.85); albedo[:, W // 2:] = (0.9, 0.45, 0.10)
r = M.color_identity(litimg, reg, albedo_img=albedo)
check("albedo image used as palette source", r["palette_source"] == "albedo"
      and r["palette_separated"] and r["diagnosis"] == "lighting_eats_identity")


# ---------------------------------------------------------------- Metric B
# dark tactical scene: small varied focal + big dark void
def dark_void():
    img = np.full((H, W, 3), 0.02, dtype=np.float32)       # void background
    vals = np.tile(np.linspace(0.25, 0.95, 8), (60, 8))[:60, :60]
    focal = np.zeros((H, W), bool); focal[20:80, 20:80] = True
    img[20:80, 20:80] = vals[:60, :60, None]
    void = ~focal
    return img, {"focal": focal, "void": void}


# genuinely flat/muddy: one narrow-value region, no void anywhere
def flat_muddy():
    rng = np.random.RandomState(0)
    img = (0.38 + 0.04 * rng.rand(H, W, 1)).astype(np.float32).repeat(3, axis=2)
    field = np.ones((H, W), bool)
    return img, {"field": field}


img, reg = dark_void()
glob = M.value_entropy(img)                                 # OLD metric
ri = M.value_entropy_intent(img, reg, tags={"void": "intentional_void"})
check("dark scene: global entropy is LOW (old metric would penalize)", glob < 1.0,
      "global=%.2f" % glob)
check("intent-aware: void exempted", "void" in ri["exempted"])
check("intent-aware: dark scene NOT penalized (weighted >> global)",
      ri["weighted_entropy"] > glob + 0.8,
      "weighted=%.2f vs global=%.2f" % (ri["weighted_entropy"], glob))
print("   reasoning:", ri["reasoning"])

img, reg = flat_muddy()
rm = M.value_entropy_intent(img, reg)                       # no tags
check("flat/muddy: still scores LOW (no void intent)", rm["weighted_entropy"] < 1.2,
      "weighted=%.2f" % rm["weighted_entropy"])
print("   reasoning:", rm["reasoning"])
check("dark-void and flat-muddy are DISTINGUISHABLE",
      M.value_entropy_intent(*dark_void(), tags={"void": "intentional_void"})["weighted_entropy"]
      > rm["weighted_entropy"] + 0.5)

# void tag VIOLATED: a busy region wrongly tagged void must be flagged
imgb, regb = dark_void()
imgb[120:180, 120:180] = np.tile(np.linspace(0.1, 0.95, 8), (60, 8))[:60, :60, None]
rv = M.value_entropy_intent(imgb, {"busy": np.ones((H, W), bool)}, tags={"busy": "intentional_void"})
check("void tag VIOLATED is flagged when region is busy", "busy" in rv["flagged"])

# area-proportional weighting: a tiny busy region must NOT swing the aggregate
big = np.zeros((H, W), bool); big[:, :190] = True          # large, flat (low entropy)
tiny = np.zeros((H, W), bool); tiny[:, 190:] = True        # tiny, busy (high entropy)
imgw = np.full((H, W, 3), 0.4, dtype=np.float32)           # big region ~flat
imgw[:, 190:] = np.tile(np.linspace(0.05, 0.95, 10), (H, 1))[:, :10, None]  # tiny busy
area = M.value_entropy_intent(imgw, {"big": big, "tiny": tiny})              # area-weighted (default)
uni = M.value_entropy_intent(imgw, {"big": big, "tiny": tiny},
                             config={"area_weighted": False})                # uniform
check("area-weighted aggregate dominated by the LARGE region",
      area["weighted_entropy"] < uni["weighted_entropy"] - 0.3,
      "area=%.2f uniform=%.2f" % (area["weighted_entropy"], uni["weighted_entropy"]))


# ---------------------------------------------------------------- backward compat
base = M.summary(np.full((H, W, 3), 0.5, dtype=np.float32))
check("summary(img) backward compatible (no new keys)",
      "color_identity" not in base and "value_entropy_intent" not in base)
withreg = M.summary(*halves((0.2, 0.35, 0.85), (0.9, 0.45, 0.12)))
check("summary(img, regions=...) adds new keys",
      "color_identity" in withreg and "value_entropy_intent" in withreg)


# ============================================================================
# BASE LUMINANCE METRICS (audit fix: previously untested). Fixtures are arrays
# in the same convention as load_png output: sRGB, HxWx3, row 0 = TOP.
# ============================================================================

def gray(v, h=H, w=W):
    return np.full((h, w, 3), v, dtype=np.float32)


# ---- balance ---------------------------------------------------------------
b = M.balance(gray(0.0))
check("balance: black frame is degenerate (dx=dy=0)",
      b.get("degenerate") is True and b["dx"] == 0.0 and b["dy"] == 0.0
      and b["offset"] == 0.0, str(b))

img = gray(0.0)
img[80:120, 20:60] = 1.0          # bright square LEFT of center, vertically centered
b = M.balance(img)
check("balance: bright square left-of-center -> dx < 0",
      "degenerate" not in b and b["dx"] < -0.3, "dx=%.3f" % b["dx"])

img = gray(0.0)
img[10:50, 80:120] = 1.0          # bright square in the TOP half (row 0 = top)
b = M.balance(img)
# sign convention (from balance(): cy = luminance-weighted mean ROW index,
# dy = (cy - center)/center; rows count down from the top) -> top-heavy = dy < 0
check("balance: bright square in TOP half -> dy < 0",
      "degenerate" not in b and b["dy"] < -0.3, "dy=%.3f" % b["dy"])

# ---- symmetry --------------------------------------------------------------
grad = np.tile(np.linspace(0.1, 0.4, W // 2, dtype=np.float32), (H, 1))
img = np.zeros((H, W, 3), dtype=np.float32)
img[:, :W // 2] = grad[..., None]
img[:, W // 2:] = grad[:, ::-1][..., None]      # exact mirror
check("symmetry: mirror-identical textured halves ~1.0",
      M.symmetry(img) >= 0.99, "sym=%.3f" % M.symmetry(img))

img2 = img.copy()
img2[:, W // 2:] *= 2.0                          # same structure, right half 2x brighter
s = M.symmetry(img2)
check("symmetry: right half 2x brighter is capped by fairness (<= 0.55, fails 0.95 gate)",
      s <= 0.55 and s < 0.95, "sym=%.3f" % s)

check("symmetry: uniform frame scores 1.0", M.symmetry(gray(0.5)) == 1.0,
      "sym=%.3f" % M.symmetry(gray(0.5)))

img3 = np.zeros((H, W, 3), dtype=np.float32)
img3[:, :W // 2] = grad[..., None]               # left textured
img3[:, W // 2:] = float(grad.mean())            # right flat (same mean)
check("symmetry: textured-vs-flat halves score low (< 0.5)",
      M.symmetry(img3) < 0.5, "sym=%.3f" % M.symmetry(img3))

# ---- value_entropy ---------------------------------------------------------
check("value_entropy: uniform image -> 0.0", M.value_entropy(gray(0.5)) == 0.0)
img = gray(0.2)
img[:, W // 2:] = 0.8                            # two equal value groups
e = M.value_entropy(img)
check("value_entropy: two equal value groups ~1.0 bit", abs(e - 1.0) < 0.01,
      "entropy=%.3f" % e)

# ---- edge_density ----------------------------------------------------------
check("edge_density: uniform image -> 0.0", M.edge_density(gray(0.5)) == 0.0)
img = gray(0.0)
img[:, W // 2:] = 1.0                            # hard vertical step
check("edge_density: hard vertical step > 0", M.edge_density(img) > 0.0,
      "density=%.4f" % M.edge_density(img))

# ---- focal_strength --------------------------------------------------------
img = gray(0.3, 240, 240)                        # 240/12 = 20 px cells
# high-variance checker inside the cell at grid col 10, grid row 1 (top-right)
img[20:40, 200:220] = 0.0
img[20:40:2, 200:220:2] = 1.0
f = M.focal_strength(img)
check("focal_strength: one high-variance cell -> focal_ratio > 3",
      f["focal_ratio"] > 3, "ratio=%.2f" % f["focal_ratio"])
check("focal_strength: focal_xy points at the top-right quadrant",
      f["focal_xy"][0] > 0.5 and f["focal_xy"][1] < 0.5, str(f["focal_xy"]))

# non-divisible size (421x381, neither divisible by 12): must run without error
# AND cover the remainder columns the old h//grid slicing dropped — a bright
# patch entirely inside the last 8 columns must still be found.
img = gray(0.3, 421, 381)
img[100:140, 373:381] = 0.0
img[100:140:2, 373:381:2] = 1.0
f = M.focal_strength(img)
check("focal_strength: 421x381 remainder columns covered (focal in last 8 cols found)",
      f["focal_ratio"] > 3 and f["focal_xy"][0] > 0.9,
      "ratio=%.2f xy=%s" % (f["focal_ratio"], f["focal_xy"]))

# ---- contrast --------------------------------------------------------------
check("contrast: uniform -> 0", M.contrast(gray(0.5)) == 0.0)
img = gray(0.0)
img[:, W // 2:] = 1.0
check("contrast: half black / half white ~0.5", abs(M.contrast(img) - 0.5) < 0.01,
      "contrast=%.4f" % M.contrast(img))


print("\n" + ("ALL_TESTS_PASSED" if not FAILS else "FAILURES: " + ", ".join(FAILS)))
if FAILS:
    # audit fix: rc-checking callers used to see green on failure (print-only)
    sys.exit(1)
