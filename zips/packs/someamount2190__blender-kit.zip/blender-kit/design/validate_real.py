"""Real-frame integration for Metric A: rebuild the conflict2 arenas (the frames
the reviewer adjudicated by eye), render the beauty pass + per-side ID masks, and
run color_identity on actual rendered pixels.

Expect: ADHERE (blue/orange) -> separated; VIOLATE (grey/grey) -> not separated.

Run: blender -b --python design/validate_real.py
"""
import os, sys, json, importlib.util
DSN = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(DSN)
sys.path.insert(0, DSN)
sys.path.insert(0, os.path.join(SKILL, "scripts"))
import bpy
from blendkit import build, material, light, transform
import metrics as M
import regions as R

# import the conflict2 scene builders
spec = importlib.util.spec_from_file_location(
    "conflict2", os.path.join(DSN, "passes", "conflict2_fairness_vs_identity.py"))
c2 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c2)

SIDES = {
    "sideA": ["L0", "L1", "L2", "L3", "L4", "BeaconL"],   # blue in adhere
    "sideB": ["R0", "R1", "R2", "R3", "R4", "BeaconR"],   # orange in adhere
}
RES = (480, 480)
OUT = os.path.join(SKILL, "_tmp", "design", "validate_real")
os.makedirs(OUT, exist_ok=True)
FAILS = []


def _clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for m in list(bpy.data.materials):
        bpy.data.materials.remove(m)


def run(tag, builder):
    _clear()
    builder()
    sc = bpy.context.scene
    cam_data = bpy.data.cameras.new("cam"); cam_data.type = "ORTHO"; cam_data.ortho_scale = 22
    cam = bpy.data.objects.new("cam", cam_data)
    sc.collection.objects.link(cam)
    cam.location = (0, 0, 22); transform.look_at(cam, (0, 0, 0))
    sc.camera = cam
    sc.render.resolution_x, sc.render.resolution_y = RES
    sc.render.image_settings.file_format = "PNG"
    beauty = os.path.join(OUT, "%s_beauty.png" % tag)
    sc.render.filepath = beauty
    bpy.ops.render.render(write_still=True)
    img = M.load_png(beauty)
    masks = R.render_region_masks(sc, SIDES, OUT, res=RES)
    albedo = R.render_albedo(sc, OUT, res=RES)          # true unlit palette pass
    r = M.color_identity(img, masks, albedo_img=albedo)
    print("REAL[%s]:" % tag, json.dumps({k: r[k] for k in (
        "applicable", "separated", "margin", "as_rendered_delta_e", "palette_delta_e",
        "palette_separated", "diagnosis", "side_chroma", "palette_source")}))
    print("   reasoning:", r["reasoning"])
    return r


ra = run("adhere", c2.adhere)
rv = run("violate", c2.violate)

ok1 = ra["applicable"] and ra["separated"]
ok2 = rv["applicable"] and not rv["separated"]
print(("PASS" if ok1 else "FAIL"), "real blue/orange arena separated")
print(("PASS" if ok2 else "FAIL"), "real grey/grey arena NOT separated")
if not ok1:
    FAILS.append("adhere")
if not ok2:
    FAILS.append("violate")
print("\n" + ("REAL_VALIDATION_PASSED" if not FAILS else "FAILURES: " + ",".join(FAILS)))
if FAILS:
    # audit fix: rc-checking callers used to see green on failure (print-only)
    sys.exit(1)
