# Design metric suite — `design/metrics.py`

Image checks on a rendered level frame (`HxWx3` float, sRGB, `[0,1]`). They raise
the floor and make reasoning explicit; they capture ~half of "good". Pure numpy,
no external deps. Loaded via `bpy` (`load_png`) or fed an array directly.

## Runner / interface
- A metric is a function `f(img, ...) -> dict|scalar`.
- `summary(img)` → flat dict of the luminance metrics (UNCHANGED, backward compatible).
- `summary(img, regions=..., tags=..., weights=...)` → the same dict PLUS
  `color_identity` and `value_entropy_intent`. Passing no `regions` adds no keys
  and changes no existing values.
- `summary_for(path, regions=None, tags=None, weights=None)` loads a PNG and calls `summary`.

## Region / side input (REQUIRED for Metric A; optional for Metric B)
The suite has **no side/region info by default**. Metrics that need it take
`regions = {name: HxW bool mask}`. Build masks for a real frame with
`design/regions.render_region_masks(scene, {side: [obj_names...]}, out_dir, res)`
— it renders one occlusion-correct silhouette pass per side (white-emissive on a
black world, others hidden) aligned to the active camera, and restores the scene.
With fewer than 2 masks, Metric A returns `{"applicable": False, "warning": ...}`
rather than guessing.

---

## Metric A — `color_identity(img, regions, albedo_img=None, config=None)`
Are opposing sides visually distinct by COLOUR, including for colourblind players?

- Perceptual distance = **CIEDE2000** (ΔE00), not raw RGB. (sRGB→linear→XYZ→CIELAB,
  D65; ΔE00 verified against Sharma's reference vector = 2.0425.)
- Colourblind pass: simulate **protanopia / deuteranopia / tritanopia**
  (Machado 2009, severity 1.0, applied in linear RGB), recompute ΔE00 under each;
  report the **worst-case** ΔE00 and **name the worst condition**.

**Two separations (self-diagnosing — the lit median can collapse toward grey under
flat light, and that low score is ambiguous):**
- `as_rendered_delta_e` — from the **median** of the lit frame = what the player sees.
- `palette_delta_e` — from a **lighting-robust** representative: the median of
  `albedo_img` if supplied (true unlit base colour, from `regions.render_albedo`,
  which renders under `view_transform='Standard'` so the base colour is not
  tonemapped/desaturated by AgX/Filmic — audit fix),
  else a **chroma-robust** representative (median of pixels whose chroma ≥
  `chroma_recover_frac` of the region's peak — works even when the surviving-chroma
  minority is tiny, unlike a fixed percentile).

**Soft-warning margin bands** (`comfortable >= delta_e_warn` (22) `> thin >=
delta_e_threshold` (15) `> fail`). A band measures VOLATILITY, so it is applied to
the number a downstream change actually MOVES, and the thin-flag names that wind +
its owner. There are TWO winds:
- **`margin`** — bands the **as-rendered** worst-case; moved by a LIGHTING pass
  (darker grade / fog / mood). Thin → "lighting artist, watch before grade lock".
  The real blue/orange arena lands here at 15.9 (0.9 over the fail line).
- **`palette_margin`** — bands the **palette** worst-case; moved by an ART/hue
  tweak ("warm up the orange"), which is upstream of lighting, a different owner
  and clock. Thin → "art direction, watch before art lock".

Both bands use the **binding (worst-case-across-conditions) ΔE00, not the
normal-vision one** — a thin CVD margin must not hide behind a fat normal one. The
thin-flag names the binding condition (e.g. a red/green palette bands its
deuteranopia number, not its comfortable normal separation). `separated` stays a
plain boolean (>= threshold) for backward compatibility.

`diagnosis` (the gap names the fix owner):
| diagnosis | meaning | owner |
|-----------|---------|-------|
| `separated` | distinct as rendered (>= threshold) | — |
| `lighting_eats_identity` | palette distinct, lit render collapses it | lighting/exposure (NOT palette) |
| `palette_failure` | sides share a colour even in albedo | palette |
| `palette_failure_cvd` | palette collapses under a CVD type | palette (colourblind-unsafe) |

Output keys: `applicable, separated` (as-rendered), `margin` + `palette_margin`
(comfortable|thin|fail), `score, worst_condition, worst_pair, per_condition_delta_e,
normal_delta_e, as_rendered_delta_e, palette_delta_e, palette_separated,
palette_worst_condition, palette_source` ("albedo"|"chroma_percentile"),
`side_chroma, diagnosis, threshold, warn_threshold, representative_srgb, reasoning`.

Config `IDENTITY_CONFIG` (override via `config=`):
- `delta_e_threshold` = **15.0** — fail line ("distinct at a glance", above the ~10
  noticeable floor).
- `delta_e_warn` = **22.0** — thin/comfortable boundary (see margin band above).
- `cvd_types`, `min_region_px`=25, `chroma_peak_percentile`=98, `chroma_recover_frac`=0.5.

Verified: a **blue/orange** pair is colourblind-SAFE (worst-case ≈ normal) — passed.
A **red/green** pair separates normally (ΔE00 ~74) but **collapses under deuteranopia
(ΔE00 ~6)** — failed. On the real lit arena, blue/orange shows as-rendered 15.9 vs
**palette 32.6** — separated, but the gap quantifies how much the lighting is eating
side identity.

---

## Metric B — `value_entropy_intent(img, regions, tags=None, weights=None, config=None)`
Region-weighted, intent-aware massing entropy. Does NOT replace `value_entropy`
(kept byte-identical for backward compatibility).

- Per-region luminance-histogram entropy; weighted aggregate.
- A region tagged `intentional_void` / `dramatic_dark` is scored against the
  EXPECTATION of low entropy: low → correct (excluded from the massing penalty);
  unexpectedly HIGH → flagged ("void tag violated").
- Solves the Phase-3 problem where a deliberate dark field dragged global entropy
  down and the reviewer had to override by eye.

Output: `applicable, weighted_entropy, per_region (entropy/tag/px/verdict),
exempted, flagged, reasoning`.

Config `INTENT_CONFIG`: `bins`=8, `void_max_entropy`=1.0 (bits a tagged void may
have), `area_weighted`=True (default non-void weight = region PIXEL COUNT, so a
tiny busy region can't swing the aggregate; set False for uniform, or pass an
explicit `weights={name: w}`), `default_weight`=1.0 (used only when not area
weighted), `void_weight`=0.0 (a satisfied void's contribution),
`void_tags`=`["intentional_void","dramatic_dark"]`.

---

## Tests
- `design/test_metrics_color.py` — synthetic fixtures (deterministic): blue/orange
  separable, grey/grey poor, red/green CVD-collapse caught; dark-void not
  penalized, flat/muddy still low; void-violation flagged; backward compat.
- `design/validate_real.py` — REAL frames: rebuilds the conflict2 arenas, renders
  beauty + ID masks, runs `color_identity`. Blue/orange → separated; grey/grey → not.

Run either with `blender -b --python <file>` (uses Blender's bundled numpy).

## Scope
In scope: these two metrics, tests, config, this doc. **Out of scope:** anything
temporal (pacing/tension) or player-response-bound (occlusion intrigue, landmark
relevance, "is the route fun") — no still-frame metric reaches those; no stubs added.

## Known limitations (carried forward, not silently fixed)
- `value_entropy` (global) still penalizes dark scenes — that's why Metric B
  exists; the old metric is unchanged for compatibility.
- `symmetry` is luminance-based → confounded by off-axis lighting (valid only on
  flat/centered/top-down views).
- **Metric A representatives are GLOBAL per side (median / chroma-robust).** This
  is an aggregate floor: a frame whose sides are separable overall can still be
  locally confusable *where the two sides meet/interleave* (a mixed border, a
  side-A prop sitting in side-B territory). The metric will pass it. For
  local/adjacency checks you'd need per-cell or border-band masks — out of scope
  here; treat the global score as a floor, not a guarantee.
- Lighting desaturation no longer punts to the eye: the `palette_delta_e` vs
  `as_rendered_delta_e` split + `diagnosis` name whether a low score is a palette
  problem or a lighting problem. The albedo pass (`regions.render_albedo`) is
  ground truth — it renders under `view_transform='Standard'` (exposure 0,
  gamma 1), so it is genuinely the unlit base colour, untouched by the scene's
  colour management; the chroma-robust proxy gets most of the way with no extra
  render.

## Threshold provenance (audit)
All luminance-metric thresholds (`edge_density` 0.08 edge cut, `mean_luminance` /
`contrast` / `value_entropy` targets) and the `target_map.py` scoring constants
were calibrated BEFORE the colour-domain fix: `load_png` used to return bpy's
scene-linear pixels while the contract said sRGB, so production renders were
effectively double-linearized when these numbers were tuned. The sRGB contract is
now actually enforced in `load_png` (linear→sRGB encode on load), which shifts
every luminance-derived value on real renders — **re-validate the numeric
thresholds against fresh renders on next use** before trusting a pass/fail near a
line. Two metric semantics also changed per the audit:
- `symmetry` is now `min(structural_correlation, brightness_fairness)` — a
  mirror-identical frame with one half uniformly brighter no longer scores 1.0
  (it is capped by the per-half mean-luminance ratio, so a 2x-brighter half
  scores ~0.5 and fails the ≥0.95 fairness gate); a fully uniform frame now
  scores 1.0 (was 0.5).
- `balance` returns `{"dx": 0, "dy": 0, "offset": 0, "degenerate": true}` on a
  black/near-black frame (mean luminance < 0.005) instead of reporting the
  top-left corner as maximal imbalance — do not chase balance numbers on a
  degenerate frame.
