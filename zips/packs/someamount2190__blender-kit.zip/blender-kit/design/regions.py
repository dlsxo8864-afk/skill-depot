"""regions.py — produce per-side region MASKS for Metric A / B from a Blender
scene. This is the clean mask interface the metric suite lacks by default.

`render_region_masks(scene, side_objects, ...)` renders one silhouette pass per
side (the side's objects as white-emissive on a black world, everything else
hidden) and thresholds it to an HxW boolean mask. The caller then samples the
BEAUTY render at those masks (color_identity) or the luminance (value_entropy_intent).

Why a real render rather than projecting object bounds: it is occlusion-correct
and matches the exact camera/resolution of the beauty frame, so masks line up
pixel-for-pixel. It mutates the scene but restores hide_render / materials /
world afterwards.
"""
import os
import bpy
import numpy as np


def _to_srgb(a):
    """bpy returns pixels scene-linear; metrics thresholds live in sRGB
    (audit fix — keep in sync with metrics._linear_to_srgb)."""
    a = np.clip(a, 0.0, 1.0)
    return np.where(a <= 0.0031308, a * 12.92, 1.055 * (a ** (1.0 / 2.4)) - 0.055)


def _compat():
    import sys as _sys
    _sys.path.insert(0, os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))
    from blendkit import compat
    return compat


class _pinned_view_transform:
    """Context manager: render with view_transform='Standard' (exposure 0,
    gamma 1), restoring afterwards. Audit fix: these ID/albedo passes were
    rendered through the scene's view transform (AgX/Filmic on modern
    defaults), which tonemaps and desaturates the emissive values — 'unlit
    base colour' was false and mask thresholds were coupled to a colour
    management setting nobody controls."""

    def __init__(self, scene):
        self.scene = scene

    def __enter__(self):
        vs = self.scene.view_settings
        self.saved = (vs.view_transform, vs.exposure, vs.gamma, vs.look)
        try:
            vs.view_transform = "Standard"
        except TypeError:  # very old builds
            vs.view_transform = "Default"
        vs.exposure = 0.0
        vs.gamma = 1.0
        try:
            vs.look = "None"
        except TypeError:
            pass
        return self

    def __exit__(self, *exc):
        vs = self.scene.view_settings
        vs.view_transform, vs.exposure, vs.gamma = self.saved[:3]
        try:
            vs.look = self.saved[3]
        except TypeError:
            pass
        return False


def _white_emissive():
    m = bpy.data.materials.new("__id_white__")
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    emi = nt.nodes.new("ShaderNodeEmission")
    emi.inputs["Color"].default_value = (1, 1, 1, 1)
    emi.inputs["Strength"].default_value = 1.0
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    return m


def _load_lum(path):
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        a = np.array(img.pixels[:], dtype=np.float32).reshape(h, w, 4)[::-1]
        a = _to_srgb(a)
        return 0.2126 * a[:, :, 0] + 0.7152 * a[:, :, 1] + 0.0722 * a[:, :, 2]
    finally:
        bpy.data.images.remove(img)


def _load_rgb(path):
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        a = np.array(img.pixels[:], dtype=np.float32).reshape(h, w, 4)[::-1]
        return _to_srgb(a[:, :, :3])
    finally:
        bpy.data.images.remove(img)


def _emissive(color):
    m = bpy.data.materials.new("__albedo__")
    m.use_nodes = True
    nt = m.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    emi = nt.nodes.new("ShaderNodeEmission")
    emi.inputs["Color"].default_value = (color[0], color[1], color[2], 1.0)
    emi.inputs["Strength"].default_value = 1.0
    nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
    return m


def render_albedo(scene, out_dir, res=(480, 480), engine=None):
    """Render the UNLIT albedo frame: every surface emits its Principled base
    colour on a black world (no lights). The lighting-robust 'palette' source for
    color_identity — `color_identity(lit_img, regions, albedo_img=render_albedo(...))`.
    Returns an HxWx3 [0,1] sRGB array aligned to the active camera. Restores the
    scene. Rendered under view_transform='Standard' so the emitted base colour
    survives untouched (audit fix — AgX/Filmic was desaturating the palette).
    """
    compat = _compat()
    if engine is None:
        engine = compat.eevee_engine_id()
    os.makedirs(out_dir, exist_ok=True)
    meshes = [o for o in scene.objects if o.type == "MESH"]
    saved_mats = {o.name: [m for m in o.data.materials] for o in meshes}
    saved_world, saved_engine = scene.world, scene.render.engine
    saved_fp = scene.render.filepath
    saved_res = (scene.render.resolution_x, scene.render.resolution_y)
    black = bpy.data.worlds.new("__alb_black__")
    black.use_nodes = True
    bg = black.node_tree.nodes.get("Background")
    if bg:
        bg.inputs["Color"].default_value = (0, 0, 0, 1)
        bg.inputs["Strength"].default_value = 0.0
    made = []
    try:
        scene.world = black
        scene.render.engine = engine
        scene.render.resolution_x, scene.render.resolution_y = res
        scene.render.image_settings.file_format = "PNG"
        for o in meshes:
            base = (0.5, 0.5, 0.5)
            if o.data.materials and o.data.materials[0]:
                bsdf = compat.get_principled(o.data.materials[0])
                if bsdf is not None:
                    sock = compat.principled_socket(bsdf, "base_color")
                    if sock is not None:
                        base = tuple(sock.default_value)[:3]
            em = _emissive(base)
            made.append(em)
            o.data.materials.clear()
            o.data.materials.append(em)
        p = os.path.join(out_dir, "__albedo.png")
        scene.render.filepath = p
        with _pinned_view_transform(scene):
            bpy.ops.render.render(write_still=True)
        img = _load_rgb(p)
    finally:
        for o in meshes:
            o.data.materials.clear()
            for m in saved_mats[o.name]:
                o.data.materials.append(m)
        scene.world = saved_world
        scene.render.engine = saved_engine
        scene.render.filepath = saved_fp
        scene.render.resolution_x, scene.render.resolution_y = saved_res
        for em in made:
            try:
                bpy.data.materials.remove(em)
            except Exception:
                pass
        try:
            bpy.data.worlds.remove(black)
        except Exception:
            pass
    return img


def render_region_masks(scene, side_objects, out_dir, res=(480, 480),
                        lum_thresh=0.5, engine=None):
    """side_objects = {side_name: [object_name, ...]}. Returns {side_name: HxW
    bool mask}, aligned to a render of the ACTIVE camera at `res`.

    Audit fixes: renders under view_transform='Standard' (mask threshold no
    longer coupled to the scene's colour management), and WARNS on any
    requested name that matches no mesh (a misspelled name used to silently
    shrink the mask and flip color_identity verdicts)."""
    if engine is None:
        engine = _compat().eevee_engine_id()
    os.makedirs(out_dir, exist_ok=True)
    meshes = [o for o in scene.objects if o.type == "MESH"]
    mesh_names = {o.name for o in meshes}
    for side, names in side_objects.items():
        missing = [n for n in names if n not in mesh_names]
        if missing:
            print("WARNING regions.render_region_masks: side %r names match no "
                  "mesh: %s (mask will be smaller than intended)" % (side, missing))
    saved_hide = {o.name: o.hide_render for o in meshes}
    saved_mats = {o.name: [m for m in o.data.materials] for o in meshes}
    saved_world = scene.world
    saved_engine = scene.render.engine
    saved_fp = scene.render.filepath
    saved_res = (scene.render.resolution_x, scene.render.resolution_y)

    black = bpy.data.worlds.new("__id_black__")
    black.use_nodes = True
    bg = black.node_tree.nodes.get("Background")
    if bg:
        bg.inputs["Color"].default_value = (0, 0, 0, 1)
        bg.inputs["Strength"].default_value = 0.0
    white = _white_emissive()

    masks = {}
    try:
        scene.world = black
        scene.render.engine = engine
        scene.render.resolution_x, scene.render.resolution_y = res
        scene.render.image_settings.file_format = "PNG"
        for side, names in side_objects.items():
            nameset = set(names)
            for o in meshes:
                o.hide_render = o.name not in nameset
                if o.name in nameset:
                    o.data.materials.clear()
                    o.data.materials.append(white)
            p = os.path.join(out_dir, "__mask_%s.png" % side)
            scene.render.filepath = p
            with _pinned_view_transform(scene):
                bpy.ops.render.render(write_still=True)
            masks[side] = _load_lum(p) > lum_thresh
            # restore materials for the side objects before the next pass
            for o in meshes:
                if o.name in nameset:
                    o.data.materials.clear()
                    for m in saved_mats[o.name]:
                        o.data.materials.append(m)
    finally:
        for o in meshes:
            o.hide_render = saved_hide[o.name]
            if list(o.data.materials) != saved_mats[o.name]:
                o.data.materials.clear()
                for m in saved_mats[o.name]:
                    o.data.materials.append(m)
        scene.world = saved_world
        scene.render.engine = saved_engine
        scene.render.filepath = saved_fp
        scene.render.resolution_x, scene.render.resolution_y = saved_res
        try:
            bpy.data.materials.remove(white)
        except Exception:
            pass
        try:
            bpy.data.worlds.remove(black)
        except Exception:
            pass
    return masks
