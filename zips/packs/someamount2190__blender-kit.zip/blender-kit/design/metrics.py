"""metrics.py — image checks for design judgment.

Pure-numpy operations on an HxWx3 float image in [0,1]. A render is loaded via
bpy when available (we run inside Blender anyway). These metrics are blunt
instruments: they capture maybe half of "good". They exist to DISCRIMINATE a
violating scene from an adhering one so a principle isn't recorded on vibes —
not to score taste. The human art director owns the other half.
"""

import math

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None


def _require_np():
    if np is None:
        raise ImportError(
            "metrics.py requires numpy (bundled with Blender's python). "
            "Run inside Blender or install numpy.")


def _linear_to_srgb(c):
    """Inverse of _srgb_to_linear: scene-linear -> sRGB display encoding."""
    c = np.clip(np.asarray(c, dtype=np.float32), 0.0, 1.0)
    return np.where(c <= 0.0031308, c * 12.92, 1.055 * (c ** (1.0 / 2.4)) - 0.055)


def load_png(path):
    """Load a PNG to HxWx3 float array in [0,1], in sRGB (display) space.

    Uses bpy (run inside Blender). IMPORTANT (audit fix): bpy returns
    `img.pixels` in SCENE-LINEAR floats — the PNG's sRGB values are linearized
    on load. Every metric and threshold in this module is specified and
    calibrated on sRGB input (see METRICS.md contract), so we encode back to
    sRGB here. Never feed raw `img.pixels` to these metrics."""
    _require_np()
    import bpy
    img = bpy.data.images.load(path, check_existing=False)
    try:
        w, h = img.size
        arr = np.array(img.pixels[:], dtype=np.float32).reshape(h, w, 4)
        # bpy pixels are bottom-row-first; flip to top-row-first for intuition
        arr = arr[::-1]
        return _linear_to_srgb(arr[:, :, :3])
    finally:
        bpy.data.images.remove(img)


def _lum(img):
    _require_np()
    return 0.2126 * img[:, :, 0] + 0.7152 * img[:, :, 1] + 0.0722 * img[:, :, 2]


def mean_luminance(img):
    return float(_lum(img).mean())


def contrast(img):
    """Global value contrast = std of luminance. Flat lighting -> low."""
    return float(_lum(img).std())


def value_entropy(img, bins=8):
    """Shannon entropy (bits) of the luminance histogram. MASSING signal: a
    scene that reads as a few big value groups has LOW entropy; value clutter
    (many competing values) has HIGH entropy.

    LIMITATION (found in design Phase 3): this penalizes deliberately DARK /
    dramatic scenes — a large dark field collapses the histogram to one bin, so
    low entropy can mean 'good dark tactical lighting', NOT 'bad massing'. Do not
    chase this metric on dark scenes; judge massing by eye (see CONFLICTS.md /
    SOP-05 gate 8). The `symmetry` metric is likewise confounded by off-axis
    lighting — only valid under flat/centered/top-down views."""
    lum = _lum(img).ravel()
    hist, _ = np.histogram(lum, bins=bins, range=(0.0, 1.0), density=False)
    p = hist.astype(np.float64)
    p = p[p > 0] / p.sum()
    return float(-(p * np.log2(p)).sum())


def focal_strength(img, grid=12):
    """How much one region stands out. Split into grid*grid cells, take each
    cell's local contrast (std); return max_cell_std / mean_cell_std. A clear
    focal anchor -> high ratio; flat/even -> ~1. Also returns the focal cell
    center in normalized (x, y)."""
    lum = _lum(img)
    h, w = lum.shape
    # array_split covers remainder rows/cols too (audit fix: the old h//grid
    # slicing silently dropped up to grid-1 rows/cols on non-divisible sizes)
    row_edges = np.array_split(np.arange(h), grid)
    col_edges = np.array_split(np.arange(w), grid)
    best, best_xy = 0.0, (0.5, 0.5)
    stds = []
    for ridx in row_edges:
        if ridx.size == 0:
            continue
        for cidx in col_edges:
            if cidx.size == 0:
                continue
            cell = lum[ridx[0]:ridx[-1] + 1, cidx[0]:cidx[-1] + 1]
            s = float(cell.std())
            stds.append(s)
            if s > best:
                best = s
                best_xy = ((cidx[0] + cidx[-1] + 1) / 2.0 / w,
                           (ridx[0] + ridx[-1] + 1) / 2.0 / h)
    mean_s = (sum(stds) / len(stds)) if stds else 1e-6
    ratio = best / mean_s if mean_s > 1e-6 else 0.0
    return {"focal_ratio": round(ratio, 3), "focal_xy": (round(best_xy[0], 3), round(best_xy[1], 3))}


def balance(img, min_mean_lum=0.005):
    """Luminance centroid offset from frame center, normalized to [-1,1] per
    axis. A centered/symmetric composition -> near (0,0); weight piled on one
    side -> large |dx|.

    Audit fix: a black/near-black frame has no meaningful centroid (the old
    code reported the top-left corner = maximal imbalance). Below
    `min_mean_lum` we return neutral with degenerate=True — do not chase
    balance numbers on a frame with no content."""
    lum = _lum(img)
    h, w = lum.shape
    total = lum.sum() + 1e-9
    if float(lum.mean()) < min_mean_lum:
        return {"dx": 0.0, "dy": 0.0, "offset": 0.0, "degenerate": True}
    xs = np.arange(w)[None, :]
    ys = np.arange(h)[:, None]
    cx = float((lum * xs).sum() / total)
    cy = float((lum * ys).sum() / total)
    dx = (cx - (w - 1) / 2) / ((w - 1) / 2)
    dy = (cy - (h - 1) / 2) / ((h - 1) / 2)
    return {"dx": round(dx, 3), "dy": round(dy, 3), "offset": round(math.hypot(dx, dy), 3)}


def _sobel(lum):
    """NOTE (audit): despite the name this is an unnormalized CENTRAL
    DIFFERENCE, not a true Sobel (no smoothing kernel, borders zero, magnitude
    ~4x smaller). The edge_density threshold below is calibrated to THIS
    operator on sRGB input — do not swap in a real Sobel without recalibrating,
    and remember the measure scales with exposure."""
    gx = np.zeros_like(lum)
    gy = np.zeros_like(lum)
    gx[:, 1:-1] = lum[:, 2:] - lum[:, :-2]
    gy[1:-1, :] = lum[2:, :] - lum[:-2, :]
    return np.hypot(gx, gy)


def edge_density(img, thresh=0.08):
    """Fraction of pixels that are strong edges. Reads CLUTTER/detail: a clean
    massing blockout -> low; noisy detail-too-early -> high."""
    mag = _sobel(_lum(img))
    return float((mag > thresh).mean())


def symmetry(img):
    """Bilateral (left-right) symmetry in [0,1]. 1 = mirror-identical halves.
    Competitive fairness leans high; asymmetric variety leans low.

    Audit fix: the score is min(structural, brightness_fairness). Pure
    mean-subtracted correlation is invariant to one half being uniformly
    brighter — exactly the PvP-fairness violation this metric gates (SOP-05
    Gate 4) — so a per-half mean-luminance ratio now caps the score. Two
    uniform (zero-variance) halves are structurally mirror-identical and score
    on fairness alone (the old code returned 0.5 for a flat frame)."""
    lum = _lum(img)
    h, w = lum.shape
    half = w // 2
    left = lum[:, :half]
    right = lum[:, w - half:][:, ::-1]
    lm, rm = float(left.mean()), float(right.mean())
    a = left.ravel() - lm
    b = right.ravel() - rm
    va, vb = float((a * a).sum()), float((b * b).sum())
    if va < 1e-12 and vb < 1e-12:
        structural = 1.0          # both halves uniform: mirror-identical
    elif va < 1e-12 or vb < 1e-12:
        structural = 0.0          # one flat, one textured: maximally unlike
    else:
        corr = float((a * b).sum() / (math.sqrt(va) * math.sqrt(vb)))
        structural = (corr + 1) / 2  # map [-1,1] -> [0,1]
    fairness = (min(lm, rm) + 1e-9) / (max(lm, rm) + 1e-9)
    return round(min(structural, fairness), 3)


def skyline_variation(img, bg_thresh=0.04):
    """Std of the per-column silhouette top edge, normalized by image height.
    A flat, monotone skyline -> low; varied massing/heights -> high. Background
    is taken as the median of the top scanline.

    LIMITATION (audit): only meaningful for SIDE-ON views whose top scanline is
    sky/background. On ortho-top renders (row 0 is floor) and gradient skies
    the number is noise — it is still emitted in summary(); do not chase it
    there."""
    lum = _lum(img)
    h, w = lum.shape
    bg = float(np.median(lum[0, :]))
    tops = []
    for x in range(w):
        col = lum[:, x]
        fg = np.where(np.abs(col - bg) > bg_thresh)[0]
        tops.append(int(fg[0]) if fg.size else h)
    tops = np.array(tops, dtype=np.float32)
    return round(float(tops.std()) / h, 4)


def _summary_base(img):
    """The original luminance-only summary. UNCHANGED — existing callers that
    do `summary(img)` get byte-identical output (the public `summary` below adds
    the new colour/intent metrics only when `regions` are supplied)."""
    return {
        "mean_luminance": round(mean_luminance(img), 4),
        "contrast": round(contrast(img), 4),
        "value_entropy": round(value_entropy(img), 4),
        **focal_strength(img),
        "balance": balance(img),
        "edge_density": round(edge_density(img), 4),
        "symmetry": symmetry(img),
        "skyline_variation": skyline_variation(img),
    }


# ===========================================================================
# COLOUR SCIENCE (pure numpy, no external deps) — supports Metric A.
# sRGB(D65) -> linear -> XYZ -> CIELAB, plus CIEDE2000 and Machado-2009 CVD.
# ===========================================================================

_D65 = None
_RGB2XYZ = None


def _init_colour():
    global _D65, _RGB2XYZ
    if _D65 is None:
        _D65 = np.array([0.95047, 1.0, 1.08883], dtype=np.float64)
        _RGB2XYZ = np.array([
            [0.4124564, 0.3575761, 0.1804375],
            [0.2126729, 0.7151522, 0.0721750],
            [0.0193339, 0.1191920, 0.9503041]], dtype=np.float64)


def _srgb_to_linear(c):
    c = np.asarray(c, dtype=np.float64)
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def _linear_rgb_to_xyz(rgb):
    _init_colour()
    return _RGB2XYZ @ np.asarray(rgb, dtype=np.float64)


def _xyz_to_lab(xyz):
    _init_colour()
    x, y, z = np.asarray(xyz, dtype=np.float64) / _D65
    d = 6.0 / 29.0

    def f(t):
        return np.where(t > d ** 3, np.cbrt(t), t / (3 * d * d) + 4.0 / 29.0)

    fx, fy, fz = f(x), f(y), f(z)
    return np.array([116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)])


# Machado et al. 2009 CVD simulation matrices, severity 1.0, applied in LINEAR RGB.
_CVD_MATRICES = {
    "protanopia": np.array([
        [0.152286, 1.052583, -0.204868],
        [0.114503, 0.786281, 0.099216],
        [-0.003882, -0.048116, 1.051998]], dtype=np.float64),
    "deuteranopia": np.array([
        [0.367322, 0.860646, -0.227968],
        [0.280085, 0.672501, 0.047413],
        [-0.011820, 0.042940, 0.968881]], dtype=np.float64),
    "tritanopia": np.array([
        [1.255528, -0.076749, -0.178779],
        [-0.078411, 0.930809, 0.147602],
        [0.004733, 0.691367, 0.303900]], dtype=np.float64),
}


def _simulate_cvd_linear(linear_rgb, cvd):
    if cvd in (None, "normal"):
        return np.asarray(linear_rgb, dtype=np.float64)
    m = _CVD_MATRICES[cvd]
    return np.clip(m @ np.asarray(linear_rgb, dtype=np.float64), 0.0, 1.0)


def _srgb_to_lab_under(srgb, cvd=None):
    """Representative sRGB colour -> CIELAB, optionally under a CVD simulation."""
    lin = _srgb_to_linear(srgb)
    lin = _simulate_cvd_linear(lin, cvd)
    return _xyz_to_lab(_linear_rgb_to_xyz(lin))


def ciede2000(lab1, lab2):
    """Perceptual colour difference ΔE00 between two CIELAB triples.
    Reference implementation (Sharma et al. 2005). Verified against the
    canonical test vector Lab(50,2.6772,-79.7751)/Lab(50,0,-82.7485)=2.0425."""
    L1, a1, b1 = (float(v) for v in lab1)
    L2, a2, b2 = (float(v) for v in lab2)
    C1 = math.hypot(a1, b1)
    C2 = math.hypot(a2, b2)
    avg_C = (C1 + C2) / 2.0
    G = 0.5 * (1 - math.sqrt(avg_C ** 7 / (avg_C ** 7 + 25 ** 7))) if avg_C > 0 else 0.0
    a1p = (1 + G) * a1
    a2p = (1 + G) * a2
    C1p = math.hypot(a1p, b1)
    C2p = math.hypot(a2p, b2)

    def _hp(ap, b):
        if ap == 0 and b == 0:
            return 0.0
        h = math.degrees(math.atan2(b, ap))
        return h + 360 if h < 0 else h

    h1p = _hp(a1p, b1)
    h2p = _hp(a2p, b2)
    dLp = L2 - L1
    dCp = C2p - C1p
    if C1p * C2p == 0:
        dhp = 0.0
    else:
        dh = h2p - h1p
        if dh > 180:
            dh -= 360
        elif dh < -180:
            dh += 360
        dhp = dh
    dHp = 2 * math.sqrt(C1p * C2p) * math.sin(math.radians(dhp / 2.0))
    avg_Lp = (L1 + L2) / 2.0
    avg_Cp = (C1p + C2p) / 2.0
    if C1p * C2p == 0:
        avg_hp = h1p + h2p
    elif abs(h1p - h2p) > 180:
        # NOTE (audit): Sharma subtracts 360 when h1p+h2p >= 360; we always add.
        # The 360-degree offset cancels in every consumer (T's cosines are
        # 2*pi-periodic; the d_theta Gaussian at 275 deg is ~0 for both values)
        # so this deviation is numerically benign — verified, keep the comment.
        avg_hp = (h1p + h2p + 360) / 2.0
    else:
        avg_hp = (h1p + h2p) / 2.0
    T = (1 - 0.17 * math.cos(math.radians(avg_hp - 30))
         + 0.24 * math.cos(math.radians(2 * avg_hp))
         + 0.32 * math.cos(math.radians(3 * avg_hp + 6))
         - 0.20 * math.cos(math.radians(4 * avg_hp - 63)))
    d_theta = 30 * math.exp(-(((avg_hp - 275) / 25) ** 2))
    Rc = 2 * math.sqrt(avg_Cp ** 7 / (avg_Cp ** 7 + 25 ** 7)) if avg_Cp > 0 else 0.0
    Sl = 1 + (0.015 * (avg_Lp - 50) ** 2) / math.sqrt(20 + (avg_Lp - 50) ** 2)
    Sc = 1 + 0.045 * avg_Cp
    Sh = 1 + 0.015 * avg_Cp * T
    Rt = -math.sin(math.radians(2 * d_theta)) * Rc
    dE = math.sqrt(
        (dLp / Sl) ** 2 + (dCp / Sc) ** 2 + (dHp / Sh) ** 2
        + Rt * (dCp / Sc) * (dHp / Sh))
    return dE


# ===========================================================================
# METRIC A — side / colour identity separation (incl. colourblindness)
# ===========================================================================

#: thresholds & options (override per-call via the `config` arg)
IDENTITY_CONFIG = {
    "delta_e_threshold": 15.0,          # ΔE00 fail line ("distinct at a glance", >~10)
    "delta_e_warn": 22.0,               # below this = thin pass (could break on a
                                        # darker/flatter lighting pass); above = comfortable
    "cvd_types": ["protanopia", "deuteranopia", "tritanopia"],
    "min_region_px": 25,                # below this a region is treated as absent
    # palette proxy (no albedo): recover the colour of pixels whose chroma is at
    # least `chroma_recover_frac` of the region's peak (robust to how SMALL the
    # surviving-chroma minority is — a fixed percentile fails on tiny minorities).
    "chroma_peak_percentile": 98,
    "chroma_recover_frac": 0.5,
}


def _srgb_to_lab_pixels(px):
    """Vectorised sRGB->CIELAB for an (N,3) pixel array."""
    _init_colour()
    lin = _srgb_to_linear(px.astype(np.float64))
    xyz = (lin @ _RGB2XYZ.T) / _D65
    d = 6.0 / 29.0
    f = np.where(xyz > d ** 3, np.cbrt(xyz), xyz / (3 * d * d) + 4.0 / 29.0)
    L = 116 * f[:, 1] - 16
    a = 500 * (f[:, 0] - f[:, 1])
    b = 200 * (f[:, 1] - f[:, 2])
    return np.stack([L, a, b], axis=1)


def _region_repr_median(img, mask):
    px = img[np.asarray(mask, dtype=bool)]
    if px.size == 0:
        return None
    return np.median(px.astype(np.float64), axis=0)


def _region_repr_chroma(img, mask, cfg):
    """Chroma-robust representative: median of the pixels whose chroma is at least
    `chroma_recover_frac` of the region's peak chroma. Recovers the underlying
    palette colour even when flat lighting desaturated the median toward grey,
    and (unlike a fixed percentile) works no matter how small the surviving-chroma
    minority is. For a truly grey region the threshold is ~0, so it returns grey
    (correctly diagnosed as a palette failure). Returns (repr_srgb, chroma)."""
    px = img[np.asarray(mask, dtype=bool)].astype(np.float64)
    if px.shape[0] == 0:
        return None, 0.0
    lab = _srgb_to_lab_pixels(px)
    chroma = np.hypot(lab[:, 1], lab[:, 2])
    peak = float(np.percentile(chroma, cfg["chroma_peak_percentile"]))
    thr = peak * cfg["chroma_recover_frac"]
    sel = px[chroma >= thr]
    if sel.shape[0] == 0:
        sel = px
    rep = np.median(sel, axis=0)
    lab_rep = _srgb_to_lab_under(rep)
    return rep, float(math.hypot(lab_rep[1], lab_rep[2]))


def _chroma_of(srgb):
    lab = _srgb_to_lab_under(srgb)
    return float(math.hypot(lab[1], lab[2]))


def _worstcase_separation(reps, names, cfg):
    """Min pairwise CIEDE2000 across normal + each CVD sim; return worst case."""
    conditions = ["normal"] + list(cfg["cvd_types"])
    pairs = [(names[i], names[j]) for i in range(len(names)) for j in range(i + 1, len(names))]
    per_condition = {}
    worst = {"delta_e": float("inf"), "condition": None, "pair": None}
    for cond in conditions:
        cvd = None if cond == "normal" else cond
        cmin = {"delta_e": float("inf"), "pair": None}
        for (na, nb) in pairs:
            de = ciede2000(_srgb_to_lab_under(reps[na], cvd),
                           _srgb_to_lab_under(reps[nb], cvd))
            if de < cmin["delta_e"]:
                cmin = {"delta_e": de, "pair": (na, nb)}
        per_condition[cond] = round(cmin["delta_e"], 2)
        if cmin["delta_e"] < worst["delta_e"]:
            worst = {"delta_e": cmin["delta_e"], "condition": cond, "pair": cmin["pair"]}
    return worst, per_condition


def color_identity(img, regions=None, albedo_img=None, config=None):
    """Metric A. Are the side regions visually distinct by COLOUR, including for
    colourblind players?

    Reports TWO separations so a low score self-diagnoses instead of punting to
    the eye (per review):
      * as_rendered: worst-case ΔE00 from the median of the LIT frame (what the
        player actually sees).
      * palette: worst-case ΔE00 from a lighting-robust representative — the
        median of `albedo_img` if supplied (true unlit base colour, via
        regions.render_albedo), else a high-chroma percentile of the lit frame.
    Diagnosis from the gap:
      both low            -> real palette failure (sides share a colour)
      palette high, lit low -> lighting is eating side identity (a lighting/
                               exposure fix, different owner than the palette)

    `regions` = {side_name: HxW bool mask}; REQUIRED (>=2). With fewer, returns
    {"applicable": False, warning:...} rather than guessing.
    """
    cfg = dict(IDENTITY_CONFIG)
    if config:
        cfg.update(config)
    names = list(regions) if regions else []
    if len(names) < 2:
        return {"applicable": False,
                "warning": "color_identity needs >=2 side region masks; the suite "
                           "carries no side info by default. Pass regions={name: HxW "
                           "bool mask} (see design/regions.render_region_masks()).",
                "reasoning": "skipped — no side masks provided"}

    rendered_reps, palette_reps, chroma = {}, {}, {}
    palette_source = "albedo" if albedo_img is not None else "chroma_percentile"
    for name in names:
        m = np.asarray(regions[name], dtype=bool)
        if int(m.sum()) < cfg["min_region_px"]:
            return {"applicable": False,
                    "warning": "region %r has too few pixels (%d < %d)" % (
                        name, int(m.sum()), cfg["min_region_px"]),
                    "reasoning": "skipped — empty/too-small region mask"}
        rendered_reps[name] = _region_repr_median(img, m)
        if albedo_img is not None:
            palette_reps[name] = _region_repr_median(albedo_img, m)
            chroma[name] = round(_chroma_of(palette_reps[name]), 1)
        else:
            rep, ch = _region_repr_chroma(img, m, cfg)
            palette_reps[name] = rep
            chroma[name] = round(ch, 1)

    threshold = cfg["delta_e_threshold"]
    warn = cfg["delta_e_warn"]
    r_worst, r_per = _worstcase_separation(rendered_reps, names, cfg)
    p_worst, p_per = _worstcase_separation(palette_reps, names, cfg)
    as_rendered_sep = r_worst["delta_e"] >= threshold
    palette_sep = p_worst["delta_e"] >= threshold

    # Soft-warning bands. Each band measures VOLATILITY on the axis a downstream
    # change can move, so each is banded on the number that change actually moves,
    # and the thin-flag names that wind + its owner:
    #   as-rendered worst-case -> moved by a LIGHTING pass   -> lighting artist
    #   palette    worst-case -> moved by an ART/hue tweak  -> art direction
    # Band the BINDING (worst-case-across-conditions) number for each, not the
    # normal-vision one — a thin CVD margin can hide behind a fat normal one.
    def _band(dE):
        if dE >= warn:
            return "comfortable"
        if dE >= threshold:
            return "thin"
        return "fail"

    margin = _band(r_worst["delta_e"])              # as-rendered
    palette_margin = _band(p_worst["delta_e"])      # palette

    if as_rendered_sep:
        diagnosis = "separated"
        reasoning = ("sides separable as rendered: worst-case ΔE00 %.1f (%s) >= %.0f"
                     % (r_worst["delta_e"], r_worst["condition"], threshold))
    elif palette_sep:
        diagnosis = "lighting_eats_identity"
        reasoning = ("PALETTE is distinct (ΔE00 %.1f) but the LIT render collapses "
                     "it (ΔE00 %.1f < %.0f) — lighting/exposure is eating side "
                     "identity; fix the lighting, not the palette (source=%s, "
                     "side chroma %s)" % (p_worst["delta_e"], r_worst["delta_e"],
                                          threshold, palette_source, chroma))
    elif r_worst["condition"] != "normal":
        diagnosis = "palette_failure_cvd"
        reasoning = ("palette too similar AND collapses under %s (as-rendered ΔE00 "
                     "%.1f, palette ΔE00 %.1f < %.0f) — a real colour-identity "
                     "failure, worst for that CVD type"
                     % (r_worst["condition"], r_worst["delta_e"],
                        p_worst["delta_e"], threshold))
    else:
        diagnosis = "palette_failure"
        reasoning = ("sides share a colour even in the palette (palette ΔE00 %.1f, "
                     "as-rendered ΔE00 %.1f < %.0f) — fix the palette (side chroma "
                     "%s)" % (p_worst["delta_e"], r_worst["delta_e"], threshold, chroma))

    # Thin-margin warnings — one per wind, naming the binding condition + owner.
    warnings = []
    if margin == "thin":
        warnings.append(
            "AS-RENDERED THIN (ΔE00 %.1f, binding %s; only %.1f over the %.0f fail "
            "line): a darker/flatter LIGHTING pass could drop it below — lighting "
            "artist, watch before grade lock"
            % (r_worst["delta_e"], r_worst["condition"],
               r_worst["delta_e"] - threshold, threshold))
    if palette_margin == "thin":
        warnings.append(
            "PALETTE THIN (ΔE00 %.1f, binding %s; only %.1f over the %.0f fail "
            "line): a base-colour/hue tweak could drop it below — art direction, "
            "watch before art lock"
            % (p_worst["delta_e"], p_worst["condition"],
               p_worst["delta_e"] - threshold, threshold))
    if warnings:
        reasoning = reasoning + "  ||  " + "  ;  ".join(warnings)

    return {
        "applicable": True,
        "separated": bool(as_rendered_sep),              # what the player sees
        "margin": margin,                                # comfortable | thin | fail (as-rendered)
        "palette_margin": palette_margin,                # comfortable | thin | fail (palette)
        "score": round(r_worst["delta_e"], 2),           # as-rendered worst-case
        "worst_condition": r_worst["condition"],
        "worst_pair": list(r_worst["pair"]),
        "per_condition_delta_e": r_per,
        "normal_delta_e": r_per["normal"],
        "as_rendered_delta_e": round(r_worst["delta_e"], 2),
        "palette_delta_e": round(p_worst["delta_e"], 2),
        "palette_separated": bool(palette_sep),
        "palette_worst_condition": p_worst["condition"],
        "palette_source": palette_source,
        "side_chroma": chroma,
        "diagnosis": diagnosis,
        "threshold": threshold,
        "warn_threshold": warn,
        "representative_srgb": {n: [round(float(c), 3) for c in rendered_reps[n]] for n in names},
        "reasoning": reasoning,
    }


# ===========================================================================
# METRIC B — intent-aware value entropy (does NOT replace value_entropy)
# ===========================================================================

INTENT_CONFIG = {
    "bins": 8,
    "void_max_entropy": 1.0,    # tagged void regions are EXPECTED <= this (bits)
    "area_weighted": True,      # default non-void weight = region pixel count
    "default_weight": 1.0,      # used only when area_weighted is False
    "void_weight": 0.0,         # weight a satisfied void contributes to aggregate
    "void_tags": ["intentional_void", "dramatic_dark"],
}


def _region_entropy(lum_values, bins):
    if lum_values.size == 0:
        return 0.0
    hist, _ = np.histogram(lum_values, bins=bins, range=(0.0, 1.0))
    p = hist.astype(np.float64)
    if p.sum() == 0:
        return 0.0
    p = p[p > 0] / p.sum()
    return float(-(p * np.log2(p)).sum())


def value_entropy_intent(img, regions=None, tags=None, weights=None, config=None):
    """Metric B. Region-weighted, intent-aware massing entropy.

    Keeps the global `value_entropy` semantics but stops penalizing DELIBERATE
    darkness: a region tagged `intentional_void`/`dramatic_dark` is scored
    against the EXPECTATION that it is low-entropy — low entropy there is correct
    (excluded from the massing aggregate); UNEXPECTEDLY HIGH entropy in a void
    region is the flag. Untagged regions are scored normally and weighted.

    `regions` = {name: HxW bool mask}; `tags` = {name: tag}; `weights` =
    {name: float}. With no regions it falls back to GLOBAL entropy and says so.
    """
    cfg = dict(INTENT_CONFIG)
    if config:
        cfg.update(config)
    tags = tags or {}
    weights = weights or {}
    lum = _lum(img)

    if not regions:
        ent = _region_entropy(lum.ravel(), cfg["bins"])
        return {"applicable": False,
                "weighted_entropy": round(ent, 4),
                "global_entropy": round(ent, 4),
                "per_region": {}, "exempted": [], "flagged": [],
                "warning": "no regions provided; fell back to GLOBAL entropy "
                           "(identical to value_entropy). Pass regions for intent-awareness.",
                "reasoning": "no region/intent info — global entropy used unchanged"}

    per_region = {}
    exempted, flagged = [], []
    num = den = 0.0
    for name, mask in regions.items():
        m = np.asarray(mask, dtype=bool)
        px = int(m.sum())
        ent = _region_entropy(lum[m], cfg["bins"])
        tag = tags.get(name)
        # default weight is AREA-proportional (pixel count) so a tiny busy region
        # can't swing the aggregate; an explicit weights[name] overrides.
        if name in weights:
            w = float(weights[name])
        elif cfg["area_weighted"]:
            w = float(px)
        else:
            w = float(cfg["default_weight"])
        rec = {"entropy": round(ent, 4), "tag": tag, "px": px, "weight": round(w, 1)}
        if tag in cfg["void_tags"]:
            if ent <= cfg["void_max_entropy"]:
                rec["verdict"] = ("void-as-intended: low entropy expected (<= %.2f) "
                                  "and met (%.2f) — excluded from massing penalty"
                                  % (cfg["void_max_entropy"], ent))
                exempted.append(name)
                w = cfg["void_weight"]
            else:
                rec["verdict"] = ("VOID TAG VIOLATED: tagged %s but entropy %.2f > "
                                  "%.2f — region is unexpectedly busy"
                                  % (tag, ent, cfg["void_max_entropy"]))
                flagged.append(name)
        else:
            rec["verdict"] = "scored normally"
        per_region[name] = rec
        num += w * ent
        den += w

    weighted = (num / den) if den > 0 else 0.0
    parts = []
    for n in exempted:
        parts.append("%s tagged void; low entropy expected & met; excluded" % n)
    for n in flagged:
        parts.append("%s tagged void but busy — FLAGGED" % n)
    reasoning = "; ".join(parts) if parts else "all regions scored normally (no intent tags)"
    return {"applicable": True,
            "weighted_entropy": round(weighted, 4),
            "per_region": per_region,
            "exempted": exempted,
            "flagged": flagged,
            "reasoning": reasoning}


def summary(img, regions=None, tags=None, weights=None):
    """Backward compatible: summary(img) returns exactly the original keys.
    When `regions` is provided, ADDS 'color_identity' and 'value_entropy_intent'
    (existing keys/values never change)."""
    out = _summary_base(img)
    if regions is not None:
        out["color_identity"] = color_identity(img, regions)
        out["value_entropy_intent"] = value_entropy_intent(img, regions, tags, weights)
    return out


def summary_for(path, regions=None, tags=None, weights=None):
    return summary(load_png(path), regions=regions, tags=tags, weights=weights)
