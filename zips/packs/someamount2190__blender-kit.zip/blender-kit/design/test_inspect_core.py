"""Tests for inspect_core — incl. the 2026-07-06 AABB-coarseness fix
(Andrada porthole class: orphan inside a vastly larger AABB)."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "scripts"))

from blendkit import inspect_core


def _box(name, mn, mx, samples=None):
    d = {"name": name, "bbox_min": list(mn), "bbox_max": list(mx)}
    if samples is not None:
        d["samples"] = samples
    return d


def test_orphan_inside_huge_aabb_flagged_with_samples():
    # hull-like huge object; porthole orphaned ~1.4m from its nearest
    # sample but fully inside the hull AABB — the disclosed Andrada miss
    hull = _box("Hull", (0, 0, 0), (12, 3, 3),
                samples=[(0.0, 0.0, 0.0), (12.0, 3.0, 3.0), (6.0, 0.0, 1.5)])
    port = _box("Porthole", (6.0, 1.4, 1.4), (6.1, 1.5, 1.5),
                samples=[(6.05, 1.45, 1.45)])
    ground = _box("Ground", (-5, -5, -0.1), (15, 8, 0.0))
    res = inspect_core.find_floating([hull, port, ground])
    assert any(f["name"] == "Porthole" for f in res), res


def test_orphan_inside_huge_aabb_without_samples_reports_coarse():
    hull = _box("Hull", (0, 0, 0), (12, 3, 3))
    port = _box("Porthole", (6.0, 1.4, 1.4), (6.1, 1.5, 1.5))
    ground = _box("Ground", (-5, -5, -0.1), (15, 8, 0.0))
    coarse = []
    res = inspect_core.find_floating([hull, port, ground], coarse_out=coarse)
    assert not any(f["name"] == "Porthole" for f in res)  # legacy accept
    assert any(c["name"] == "Porthole" for c in coarse)   # but visible


def test_true_attachment_to_huge_aabb_passes_with_samples():
    hull = _box("Hull", (0, 0, 0), (12, 3, 3),
                samples=[(6.0, 0.0, 1.5), (6.0, 3.0, 1.5)])
    fitting = _box("Fitting", (5.95, -0.05, 1.4), (6.05, 0.05, 1.6),
                   samples=[(6.0, 0.0, 1.5)])
    ground = _box("Ground", (-5, -5, -0.1), (15, 8, 0.0))
    coarse = []
    res = inspect_core.find_floating([hull, fitting, ground],
                                     coarse_out=coarse)
    assert not any(f["name"] == "Fitting" for f in res)
    assert not coarse


def test_small_neighbor_contact_unaffected():
    a = _box("A", (0, 0, 0), (1, 1, 1))
    b = _box("B", (1.0, 0, 0), (2, 1, 1))
    ground = _box("Ground", (-5, -5, -0.1), (5, 5, 0.0))
    coarse = []
    res = inspect_core.find_floating([a, b, ground], coarse_out=coarse)
    assert not res and not coarse


def test_scene_report_carries_coarse_attachments():
    hull = _box("Hull", (0, 0, 0), (12, 3, 3))
    port = _box("Porthole", (6.0, 1.4, 1.4), (6.1, 1.5, 1.5))
    ground = _box("Ground", (-5, -5, -0.1), (15, 8, 0.0))
    rep = inspect_core.scene_report([hull, port, ground])
    assert "coarse_attachments" in rep
    assert any(c["name"] == "Porthole" for c in rep["coarse_attachments"])
