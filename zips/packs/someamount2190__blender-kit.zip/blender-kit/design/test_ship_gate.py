"""Tests for the build ledger + ship gate (pure python, no bpy).
Run: python -m pytest design/test_ship_gate.py -q
"""
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "scripts"))

from blendkit import ledger, plan  # noqa: E402
import importlib.util  # noqa: E402

_sc_path = os.path.join(os.path.dirname(HERE), "scripts", "ship_check.py")
_spec = importlib.util.spec_from_file_location("ship_check", _sc_path)
ship_check = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ship_check)

PLAN_OK = """# BUILD PLAN — t
## 1. WHAT — proportions & ratios (sourced held belief)
{x}
## 2. VISUAL — reference(s) fetched AND viewed
{x}
## 3. HOW — construction method (research the CRAFT, not your prior)
{x}
## 4. FAILURES — common mistakes + the check that catches each
{x}
## 5. FEATURE PARTS — identity parts DESIGNED FIRST
{x}
## 6. DECOMPOSE — part -> technique -> check
{x}
""".format(x="words " * 20)


def _mkplan(d, extra=""):
    p = os.path.join(d, "t_plan.md")
    with open(p, "w", encoding="utf-8") as f:
        f.write(PLAN_OK + extra)
    return p


def _full_green(d, p):
    ledger.record_gates(d, True)
    cf = os.path.join(d, "crit.md")
    item = ("ITEM %d: t\nPERCEPT: reads odd\nCLAIM: part X is 0.4 off\n"
            "SEEN-IN: persp panel\nSEVERITY: major\nPRESCRIPTION: move it\n")
    open(cf, "w").write("".join(item % i for i in range(4)) + "pad " * 120)
    ledger.record_critic(d, cf)
    ef = os.path.join(d, "triage.md")
    open(ef, "w").write("item 1 FIX-NOW because x. item 2 ACCEPT. " * 12)
    ledger.record_engineer(d, ef)
    ledger.record_deviations(d, [])
    for n in ("a_contact.png", "b_contact.png"):
        open(os.path.join(d, n), "wb").write(b"png")


def test_empty_ledger_fails():
    with tempfile.TemporaryDirectory() as d:
        p = _mkplan(d)
        probs = ship_check.run(d, p)
        joined = " ".join(probs)
        assert "gates" in joined and "critic" in joined
        assert "engineer" in joined and "deviations" in joined


def test_full_ledger_passes():
    with tempfile.TemporaryDirectory() as d:
        p = _mkplan(d)
        _full_green(d, p)
        assert ship_check.run(d, p) == []


def test_critic_requires_real_artifact():
    with tempfile.TemporaryDirectory() as d:
        try:
            ledger.record_critic(d, os.path.join(d, "missing.md"))
            assert False
        except ValueError:
            pass
        short = os.path.join(d, "s.md")
        open(short, "w").write("meh")
        try:
            ledger.record_critic(d, short)
            assert False
        except ValueError:
            pass


def test_engineer_requires_labels():
    with tempfile.TemporaryDirectory() as d:
        f = os.path.join(d, "t.md")
        open(f, "w").write("looks fine to me, no labels here at all " * 20)
        try:
            ledger.record_engineer(d, f)
            assert False
        except ValueError:
            pass


def test_declared_subbuild_blocks_until_green():
    with tempfile.TemporaryDirectory() as d:
        sub = os.path.join(d, "build_part.py")
        open(sub, "w").write("# sub build\n")
        p = _mkplan(d, "\nsub-build: %s\n" % sub)
        _full_green(d, p)
        probs = ship_check.run(d, p)
        assert any("sub-build" in x for x in probs)
        ledger.record_subbuild(d, sub, ok=True)
        assert ship_check.run(d, p) == []


def test_failed_subbuild_stays_blocked():
    with tempfile.TemporaryDirectory() as d:
        sub = os.path.join(d, "build_part.py")
        open(sub, "w").write("# sub\n")
        p = _mkplan(d, "\nsub-build: %s\n" % sub)
        _full_green(d, p)
        ledger.record_subbuild(d, sub, ok=False)
        assert any("FAILED" in x for x in ship_check.run(d, p))



def test_freeprose_critique_refused():
    with tempfile.TemporaryDirectory() as d:
        cf = os.path.join(d, "prose.md")
        open(cf, "w").write("it looks like a picnic table with a toy under it. "
                            "the roof is furniture-grade. " * 30)
        try:
            ledger.record_critic(d, cf)
            assert False, "free-prose critique must be refused (SOP-09)"
        except ValueError as e:
            assert "SOP-09" in str(e) or "structured" in str(e)


def test_finish_all_green():
    with tempfile.TemporaryDirectory() as d:
        ok, fails = ledger.finish(d, {"scan": {"ok": True}, "align": True},
                                  view_outputs=[{"persp": {"error": None}}])
        assert ok and not fails
        assert ledger.load(d)["gates"]["ok"]
        assert "scan" in ledger.load(d)["gates"]["detail"]


def test_finish_dict_check_fails():
    with tempfile.TemporaryDirectory() as d:
        ok, fails = ledger.finish(d, {"scan": {"ok": True},
                                      "ratios": {"ok": False}})
        assert not ok and any("ratios" in f for f in fails)
        assert not ledger.load(d)["gates"]["ok"]


def test_finish_none_is_fail_closed():
    with tempfile.TemporaryDirectory() as d:
        ok, _ = ledger.finish(d, {"scan": None})
        assert not ok


def test_finish_render_error_fails():
    with tempfile.TemporaryDirectory() as d:
        outs = {"persp": {"error": "overexposed: clip"}, "contact_sheet": "x.png"}
        ok, fails = ledger.finish(d, {"scan": True}, view_outputs=[outs])
        assert not ok and any("render:persp" in f for f in fails)
