# CONFLICTS — resolved tradeoffs (Phase 2)

Where two catalog principles fight. Each entry either RESOLVES the conflict on a
render, or NAMES a genuine tradeoff (when X wins, when Y wins) with render
evidence. Never silently pick a side. If a conflict shows a Phase-1 principle was
overstated, the correction is noted here and applied in DESIGN_PRINCIPLES.md.

Note: the pair renders referenced below live in the local-only `_tmp/` directory,
which is gitignored — on a fresh clone they are absent. Re-run the referenced
conflict/pass script to regenerate them.

Entry format:
```
### <Principle A> vs <Principle B>
- forced_by: <scene that makes them collide> — <pair render path>
- resolution / named tradeoff: <when A wins / when B wins>
- art_director_default_lean: <set at the Phase 2 checkpoint>
```

---

### P1/P3 (visible landmark anchor) vs P2 (occluded sightline)
- forced_by: player-eye corridor where the player needs orientation AND the designer wants suspense — `_tmp/design/conflict1/conflict1_pair.png`. V: tall cross-wall hides everything incl. the beacon (lost). A: lower cross-wall reveals the beacon's top above it while the ground path around the corner stays hidden.
- resolution (NOT a true tradeoff): separate by SCALE. Keep the DISTANT landmark visible for global orientation; occlude the IMMEDIATE/local path for moment-to-moment suspense. They only conflict if applied at the same scale. Render: focal_ratio 7.10 (V, focal low on the blocking wall) → 10.14 (A, focal high on the now-visible beacon); the hidden ground reward is occluded in BOTH.
- art_director_default_lean (delegated): RESOLVE by scale — always give a far/high orientation anchor, reserve occlusion for the near path. Only collapse to pure occlusion when "being lost" is the intended experience (horror, maze).

### P3/P6 (expressive asymmetry & contrast for hierarchy/guidance) vs P7 (symmetry for fairness)
- forced_by: a competitive PvP arena that needs BOTH fairness AND side-identity/orientation — `_tmp/design/conflict2/conflict2_pair.png`. V: mirrored layout, identical grey sides (fair, but "which side is mine?"). A: SAME mirrored layout, sides tinted blue/orange.
- resolution + NAMED TRADEOFF: LAYER them. Keep GAMEPLAY geometry mirror-symmetric (fairness) and confine asymmetry to the NON-GAMEPLAY cosmetic layer (per-side colour/landmark/art). Render: symmetry metric 0.999 (V) → 0.997 (A) — fairness essentially UNCHANGED by adding identity. The genuine tradeoff that REMAINS: you may NOT use gameplay-affecting asymmetry (different cover/sightlines per side) in a fair competitive map; in single-player/PvE, gameplay asymmetry + landmarks (P3) + directed light (P6) is fine and preferred.
- METRIC LIMITATION exposed: the luminance metrics are nearly colour-blind — they read BOTH sides as symmetric (0.997) and cannot see the blue/orange identity that is the whole point of A. The value here is only visible to the eye. Concrete proof that "metrics capture maybe half of good."
- art_director_default_lean (delegated): Competitive PvP tactical → symmetric gameplay geometry is non-negotiable; deliver orientation/hierarchy/identity ONLY through cosmetic layers (colour, art, non-blocking light). Single-player/PvE tactical → lean asymmetric: strong landmarks + directed lighting, fairness is not a constraint. Corrects P6: directed light guides in PvE, but in PvP lighting must stay symmetric (used for readability, not to favour one team).
