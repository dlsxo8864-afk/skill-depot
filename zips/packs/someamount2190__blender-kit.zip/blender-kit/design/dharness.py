"""dharness.py — violating/adhering A/B render harness for design passes.

Renders a VIOLATING scene and an ADHERING scene with the SAME fixed camera (so a
metric difference is attributable to the design change, not the framing),
computes metrics for each, stitches a side-by-side pair (LEFT=violating,
RIGHT=adhering), and prints JSON. Nothing is recorded here — the human reads the
pair + the metric delta and decides if the principle is demonstrated.
"""
import os, sys, json

# derive the skill root from __file__ (same pattern as the pass scripts) —
# audit fix: the hardcoded per-user path broke any other user/clone.
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(SKILL, "scripts"))
sys.path.insert(0, os.path.join(SKILL, "design"))

import bpy
from blendkit import build, transform, material, light, camera, render
import metrics as M


def _clear():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for m in list(bpy.data.materials):
        bpy.data.materials.remove(m)


def run_pair(name, build_violating, build_adhering, cam_loc, cam_look=(0, 0, 0.5),
             lens=50, out_dir=None, engine="EEVEE", samples=48, res=(480, 360),
             ortho=False, ortho_scale=None):
    out_dir = out_dir or os.path.join(SKILL, "_tmp", "design", name)
    os.makedirs(out_dir, exist_ok=True)
    log = render.RenderLog(os.path.join(out_dir, "render.log"))
    results = {}
    paths = []
    for tag, fn in (("violate", build_violating), ("adhere", build_adhering)):
        _clear()
        fn()
        # fixed identical camera for both scenes
        cam_data = bpy.data.cameras.new("cam")
        cam_data.lens = lens
        if ortho:
            cam_data.type = "ORTHO"
            cam_data.ortho_scale = ortho_scale or 12
        cam = bpy.data.objects.new("cam", cam_data)
        bpy.context.scene.collection.objects.link(cam)
        cam.location = cam_loc
        transform.look_at(cam, cam_look)
        bpy.context.scene.camera = cam
        p = os.path.join(out_dir, "%s_%s.png" % (name, tag))
        info = render.render_still(p, engine=engine, samples=samples, resolution=res, log=log)
        # audit fix: render_still can FAIL (engine=None, error set, file possibly
        # never written). The old code called summary_for/indexed keys and died
        # with a traceback; now the failure is reported per-scene and we continue.
        if info.get("error") or not os.path.exists(p):
            err = info.get("error") or "render output missing: %s" % p
            results[tag] = {
                "render": {k: info.get(k) for k in ("engine", "luminance", "error")},
                "error": err,
            }
            continue
        paths.append(p)
        m = M.summary_for(p)
        results[tag] = {"render": {k: info[k] for k in ("engine", "luminance", "error")}, "metrics": m}
    if len(paths) == 2:  # both scenes rendered successfully
        render.contact_sheet(paths, os.path.join(out_dir, "%s_pair.png" % name), log)
        results["pair"] = os.path.join(out_dir, "%s_pair.png" % name)
        print("PAIR:", results["pair"])
    else:
        results["pair"] = None
        print("PAIR: skipped (render failure — see per-scene error)")
    log.save()
    print("METRICS_JSON:", json.dumps(results))
    return results
