# blender-kit — Cold Audit Findings & Fix List (2026-07-03)

> **STATUS (2026-07-03, same day): FIXED.** All P0 and P1 items and nearly all P2
> items below were applied and verified: 43/43 metric tests pass (incl. 14 new
> base-metric tests locking the new semantics), headless Blender 5.1.2 smoke
> build passes end-to-end with honest exit codes, the design gate was
> negative-tested (unfilled plan → PREFLIGHT ABORT, exit 1), and the camera
> clip fix was confirmed visually on the contact sheet.
> **Deliberately deferred (with rationale):**
> - #4 partial: render luminance still includes the world background (a lit-sky
>   frame with a missing subject passes automated gates) — documented in
>   render_still's docstring; the SOP "view the PNG" instruction remains the
>   defense. A subject-mask luminance needs design work.
> - #14 partial: Metric A/B (color_identity) still not wired into the generic
>   V/A passes — they require per-scene side definitions which only the arena
>   scenes have; validate_real.py exercises them. Structural, not a bug.
> - #21 partial: renders/new_scene fixed basenames and plan-slug keying can
>   still collide across concurrent builds of the SAME object (log names fixed).
> - #29/#32 cosmetic leftovers: contact_sheet same-size assumption, _clear()
>   copy-paste in design/ — harmless, skipped.
> Threshold recalibration note: all luminance thresholds were calibrated under
> the old double-linearized pixels; METRICS.md now flags them for re-validation
> against fresh renders on next real use.

Three independent cold auditors (Python harness / design metrics / instruction layer), criticals
hand-verified by execution. Line numbers refer to current files.

Overall verdict: instruction layer near-airtight (every documented CLI/symbol verified against
source, several live-executed); color science correct in isolation; but the deterministic safety
layer under the render→inspect doctrine is weaker than its docstrings claim. The skill works
because the SOPs make the agent look at the PNGs — the automation beneath that instruction has
holes.

---

## P0 — Breaks trust in the deterministic layer

1. **[CRITICAL, verified] debug.py:59 — black_render regex matches every normal log.**
   `\blum(inance)?\s*=\s*0(\.0+)?\b` — the optional group backtracks to empty, so `lum=0.2735`,
   `lum=0.9999` all match (verified by execution; only >= 1.0 escapes). The classifier reports
   "black frame / add lights" for virtually any failure, misdirecting the SOP-03 debug loop and
   polluting consult_memory. Fix: parse the number and compare (`float(m.group(1)) < 0.01`), or
   require `lum\s*=\s*0\.0+\b` exactly.

2. **[CRITICAL, verified] metrics.py — color-domain mismatch: thresholds calibrated in sRGB,
   pixels arrive scene-linear.** `load_png` (metrics.py:18-29) returns bpy's scene-linear floats;
   `_srgb_to_lab_pixels`/`_srgb_to_lab_under` (316-326, 231-235) apply `_srgb_to_linear` AGAIN.
   Tests pass because they feed hand-built sRGB arrays; production renders are double-linearized —
   ΔE00 is not perceptual ΔE00, and every luminance threshold (mean_luminance, contrast,
   value_entropy, edge_density) is enforced in a different domain than documented/calibrated.
   Fix: convert linear→sRGB in load_png (or tag the domain and branch); re-validate thresholds.

3. **[CRITICAL] regions.py:65-126 — render_albedo is not albedo.** Renders through the scene's
   view transform (AgX on 4.x/5.x default) — "true unlit base colour" is tonemapped/desaturated;
   palette_delta_e systematically compressed → false "palette_failure" diagnoses. Also
   render_region_masks (:166): white emission through AgX can land near lum_thresh=0.5 → silently
   empty masks. Fix: set view_transform="Standard" (or Raw) + exposure/gamma defaults inside both
   functions, restore after.

4. **render.py:87-106 — documented black-frame → Cycles fallback does not exist.** Luminance is
   computed (:93) and logged but never compared to anything; fallback advances only on exception.
   A black frame returns `{"error": None, "luminance": 0.0}` = success. Compounding:
   `_mean_luminance` averages the whole frame including world background, so a render with the
   subject entirely missing scores healthy (~0.3) — and preflight's "world lit" test accepts
   `world_sky(strength=0.0)`. Fix: act on luminance (threshold → retry/error), and gate on a
   subject-region luminance or at least warn.

5. **new_scene.py — three gate bypasses in the canonical starting script.**
   (a) exits 0 on failed renders and failing inspect (only preflight aborts return 1) — callers
   via run.sh see success; (b) calls `preflight.check()` with NO plan_path — the fail-closed
   design gate (the skill's flagship mechanism) is inert in the very template SOP-00 tells the
   agent to copy; (c) never calls `inspect.failure_scan()` (Gate 9.5 "run on EVERY build").
   Fix: thread plan_path, add failure_scan, return non-zero on render error / inspect fail.

6. **inspect_core.py:98 — find_floating flags parts EMBEDDED into their support as FLOATING.**
   Support requires `b.bbox_max.z <= a_bottom + eps` (strictly below), but the kit's own doctrine
   is attach-by-overlap — a turret sunk 5mm into a deck has no support candidate and is flagged
   floating with a huge gap. Contradicts failure_scan (which handles overlap via signed gap).
   scene_report therefore FAILs correctly-built models. Fix: accept interpenetrating supports
   (signed-gap test like failure_scan's `_aabb_gap <= connect_eps`).

7. **metrics.py:119-131 — the symmetry metric is blind to the unfairness it gates.** Per-half
   mean-subtraction + Pearson normalization make it invariant to per-side brightness: mirror
   geometry with one team's approach lit 2x brighter scores 1.0 — exactly the violation SOP-05
   Gate 4 (PvP fairness) uses `symmetry >= 0.95` to catch. Uniform frame scores 0.5 (fails while
   perfectly symmetric). Fix: add a per-half mean-luminance ratio component (absolute, not
   correlation-based); special-case zero-variance halves.

8. **dharness.py:50-53 — no failure path.** On render failure, render_still returns a dict with
   no "luminance" key and no written file → `summary_for` RuntimeError or KeyError; every pass
   dies with a traceback instead of printing METRICS_JSON with error. Guard both.

9. **camera.py — two clipping defects.** (a) frame_scene_ortho_top never sets clip_start/clip_end
   → any scene deeper than the default 100m far clip renders an EMPTY top view (250m battleship =
   documented use case); (b) frame_scene derives clip planes from the subject-only AABB while the
   ground IS rendered → default template visibly clips the floor near and far ("no clipping"
   docstring false); agents burn iterations "fixing" a camera artifact. Fix: set ortho clip from
   camera distance + scene depth; include rendered ground in clip (not framing) bounds.

10. **SOP-07 / SKILL.md / plan_build.py stdout teach a 5-section plan; plan.py's gate requires 6.**
    No D-step exists for §5 FEATURE PARTS (the section added after the
    feature-parts-as-afterthought-blobs failure); SOP-07:63 says "plan's §5 is your part list"
    (it's §6); plan_build.py prints "sections 1-5". Agent hits a gate BLOCK naming a section it
    was never told to write. Fix: add the FEATURE PARTS D-step, renumber, fix the stdout.

11. **SOP-00 Gates 9/9.5 contradict documented-intentional flags.** "PASS: inspect ok:True" +
    "FLOATING/BELOW-GROUND are NOT judgment calls" vs sword.md ("collars OVERLAP on purpose"),
    chair.md ("2 intentional floats"), waterline-floor-false-positive.md (keel below z=0 is
    correct). Agent either churns "fixing" correct joinery or learns to ignore gates. Fix: add an
    explicit exception clause — "flag may stand if a references/ entry documents it as
    intentional; cite the entry."

## P1 — Correctness & robustness

12. metrics.py:94-101 — balance on a black/near-black frame reports centroid at top-left corner
    (offset 1.414 = max imbalance); return neutral/NA below a luminance floor.
13. target_map.py:124 — readability = 1.0 (perfect) for an empty/black frame (edge_density 0);
    :126 — hierarchy gives a landmark-less scene 0.71 (their own CONFLICTS.md data); focal_ratio
    rewards one firefly/shadow-edge cell. Recalibrate; floor-gate both on content presence.
14. No tests for the 7 operational luminance metrics (balance/symmetry/focal/entropy/edges…) —
    only the color metrics are tested, and those are never wired into any pass (dharness calls
    summary_for without regions → color_identity/value_entropy_intent computed nowhere
    operationally). Also test_metrics_color.py and validate_real.py end with print() — no
    sys.exit(1) on FAILURES, so rc-checking callers see green. Fix all three.
15. regions.py:156-166 — misspelled object names in side_objects are silently ignored (mask
    shrinks, verdicts flip); warn on zero-match names. regions.py:65,130 — hardcoded
    "BLENDER_EEVEE" instead of compat.eevee_engine_id() (breaks on Blender 4.2).
16. Hardcoded `C:\Users\Christian Correa\...` SKILL root in dharness.py:11, pass4:12,
    target_map.py:13 (other passes derive from __file__) — breaks any other user/clone.
17. fetch_reference.py — no URL-scheme allowlist (file:// and ftp:// fetch fine → can copy
    arbitrary local files into the repo), no response size cap (r.read() unbounded), partial
    failure exits 0 (1 of 5 saved = success), personal email hardcoded in UA (MIT repo with a
    public remote). Allowlist http/https, cap size, fix rc, parameterize the contact.
18. preflight.py:41-45 — plan_path resolved relative to Blender's CWD; SOPs pass relative
    `_tmp/<slug>_plan.md` → gate false-BLOCKs ("no BUILD PLAN") when launched from elsewhere.
    Resolve against the skill root. preflight.py:73-91 — camera-aim cone measured to full-AABB
    center (incl. ground) while frame_scene aims at subject-only center → false ABORT/PASS on
    off-center subjects.
19. inspect.py:132-137 — topology_report counts non-manifold edges AFTER remove_doubles on the
    temp bmesh (reports a hypothetical cleaned mesh). Count before, or report both.
20. Inconsistent ignore-name semantics: exact match (find_floating, scene_report) vs substring
    (camera._scene_aabb, failure_scan, axis_alignment) — "FloorLamp"/"Foreground" silently exempt
    from failure_scan; "GroundPlane" flagged degenerate by scene_report. Unify (one helper).
21. Concurrency/collisions: run.sh 1-second log names truncate each other; renders/new_scene
    fixed basenames; plan.py keyed by slug only; record_learning read-then-append index race.
    Salt with PID/timestamp-ms where cheap.

## P2 — Hygiene & polish

22. SKILL.md:132 record_learning kinds missing `technique|reference` (script accepts 6); no SOP
    says how to record a technique — they get misfiled under pattern (already happened once per
    patterns/INDEX.md).
23. failures/INDEX.md — 3 entries "(no hook)" including the two most important post-mortems
    (skipped-design-phase, feature-parts-as-afterthought-blobs); record_learning never back-fills
    hooks. Back-fill; add --hook to the SOP examples.
24. Stale "Seeded:" lists in SKILL.md:119-122 and proportions.md:51 (catalogs now 11 objects /
    7 materials).
25. Evidence paths in tracked files (LEARNINGS.md verified_by, DESIGN_PRINCIPLES.md
    demonstrated_by, CONFLICTS.md pairs) all point into gitignored _tmp/ — dangling on any fresh
    clone. Promote key evidence renders to a tracked evidence/ dir or note the limitation.
26. _tmp/ = 89 MB, 214 files, no cleanup guidance (gitignored, so disk-only). Add a cleanup note
    or script. Render output location never pinned (renders/ vs _tmp/) — document one.
27. material.py:88-91 bark Voronoi DISTANCE_TO_EDGE failure silently degrades to blobby F1;
    :177-182 emissive fallback retries the identical call (dead code). compat.py:25
    specular_tint alias latent type change (float→color in 4.x).
28. metrics.py minor: _sobel is a central difference (name + 0.08 threshold calibrated to it,
    exposure-dependent); focal grid drops remainder rows/cols on non-divisible sizes;
    skyline_variation meaningless on ortho-top renders yet always reported; np=None import guard
    never checked (opaque AttributeError later); CIEDE2000 wraparound mean-hue deviates from
    Sharma but verified numerically benign (comment it).
29. render.py: canonical_views accumulates persp_cam.001... on re-runs (delete or reuse);
    contact_sheet dead var + same-size assumption; makedirs("") edge case. debug.py: --skill-root
    IndexError without value; _split_blocks emits duplicate table-row hits.
30. transform.py: apply_transforms(rotation-only) on non-uniform scale silently changes shape
    (Blender warns; kit doesn't); look_at wrong for parented objects (latent — kit never parents).
31. inspect.py:620-626 check_clearance circumscribed-circle footprint false-positives long thin
    parts by up to half their length (conservative direction; note it or use OBB corners).
32. Pass-script drift: pass7 vs conflict2 "same arena" differs (cover 2.6 vs 2.4, ortho 20 vs 22,
    objective present/absent); target_map re-implements pass5's greeble loop with different
    ranges; _clear() copy-pasted 4x; regions re-implements load_png. Consolidate.

## Verified sound (don't re-audit)

- compat.py alias table covers every call site incl. all 4.0 renames; no hardcoded Principled
  socket names anywhere; eevee_engine_id / ensure_cycles_available probe correctly.
- Exactly one bpy.ops call in the package (render, background-safe); all geometry via bpy.data +
  bmesh; view_layer.update() before matrix_world reads throughout.
- Camera perspective/ortho fit math; failure_scan union-find + signed-gap connectivity;
  phyllotaxis (golden angle, Vogel, da Vinci) all correct.
- CIEDE2000 verified term-by-term vs Sharma (canonical test vector passes); sRGB/XYZ/Lab
  constants correct; Machado CVD matrices applied in the right space; color_identity diagnosis
  table matches METRICS.md exactly.
- run.sh space-safe, --python-exit-code 1, rc propagation; plan.py design gate genuinely
  fail-closed when plan_path is provided; plain-python CLIs avoid bpy imports.
- Learning loop closes mechanically (debug.py re-surfaces LEARNINGS.md + bpy_gotchas — live
  tested); all 6 INDEX files exactly match directory contents; .gitignore correct.
- fetch_reference magic-byte sniffing genuinely rejects HTML-as-image; slugified filenames kill
  path traversal.
