# DESIGN_PRINCIPLES — verified, attributed

Tactical-level design judgment, grounded in canon and proven on a render. **A
principle is recorded ONLY after a violating/adhering render pair demonstrated
it AND a metric discriminated.** No source → not a principle. Can't show it on a
render → discard it (log why in DESIGN_LOG.md). Same anti-poison rule as
LEARNINGS.md: never record an unverified claim.

Note: `demonstrated_by` renders live in the local-only `_tmp/` directory, which
is gitignored — on a fresh clone they are absent. Re-run the referenced pass
script to regenerate the evidence pair.

Canon + license:
- **C1** book.leveldesignbook.com — CC BY-NC-SA 4.0 (paraphrase, attribute, keep
  non-commercial; **flag every C1 entry if ever used commercially**).
- **C2** Unity level-design e-book — paraphrase + cite only.
- **C3** World of Level Design (worldofleveldesign.com) — paraphrase + cite only.

Entry format:
```
### P<n> — <short name>   [chapter]  (canon: C1/C2/C3)
- source: <url>
- principle: <testable statement in my own words>
- demonstrated_by: <pair render path> — <which metric discriminated, V vs A>
- caveat: <when it does NOT apply / overstatement guard>
```

---

### P1 — Landmark as wayfinding anchor   [Layout]  (canon: C1)
- source: https://book.leveldesignbook.com/process/layout ("Name and theme map areas from the beginning"; label landmarks/callouts for player understanding)
- principle: A field of interchangeable forms gives the eye no anchor to orient or call out; a single visually distinct landmark (taller + brighter than its surroundings) creates one clear focal point players can navigate by.
- demonstrated_by: `_tmp/design/pass1_layout/pass1_layout_pair.png` — focal_ratio 5.38 (V, interchangeable crate ring) → 9.80 (A, one lit tower), +82%; symmetry 0.97 → 0.62 (the landmark breaks the uniform read). Confirmed by eye: right image has an instant anchor, left has none.
- caveat: focal_ratio is not 0 for the violating scene (~5.4) — edge crates create local contrast, so the discriminator is the RELATIVE jump + symmetry drop + the eye, not an absolute focal number. One landmark only; competing landmarks would split attention (a Phase-2 tradeoff).

### P2 — Occluded sightline builds anticipation   [Flow]  (canon: C1)
- source: https://book.leveldesignbook.com/process/layout/flow ("you never know 100% what's on the other side. This is more exciting than a straight clear open path")
- principle: A blind corner that hides the path's reward/threat until the player commits creates anticipation; a straight corridor that reveals the endpoint from the mouth spends that tension immediately.
- demonstrated_by: `_tmp/design/pass2_flow/pass2_flow_pair.png` — same player-eye camera. V (straight): lit end-marker fully visible, focal_ratio 14.58 centered on it. A (dogleg): marker occluded behind the corner, focal_ratio 9.35 off-axis. Viewed: the reward is plainly visible left, gone right.
- caveat (the source's own): this serves a SUSPENSE/exploration goal — it is NOT a universal good. The source explicitly warns "the best flow is whatever supports the intended experience design goals"; a flat, open, fully-readable space is correct for many mechanics. Over-occluding = confusion. (Tension here with P1's "give a visible anchor" — a Phase-2 conflict.)

### P3 — Hierarchy is LOCAL CONTRAST (refines P1)   [Massing/Composition]  (canon: C1)
- source: https://book.leveldesignbook.com/process/blockout/massing/composition ("hierarchy depends on local contrast and context. A tall thing only seems special if it is surrounded by short things"; contrast via height/density/orientation/shape; "landmarks have to feel relevant and useful")
- principle: A landmark's dominance is RELATIONAL, not intrinsic. The same tall mass reads as a landmark among short neighbours and disappears among tall ones. Create hierarchy by contrasting one axis (height, spacing, orientation, or shape) against the local surroundings — and the landmark must be relevant/useful, not mere set-dressing.
- demonstrated_by: `_tmp/design/pass3_massing/pass3_massing_pair.png` — IDENTICAL tower in both; only neighbour height changed. V (tall neighbours): tower blends, focal_ratio 4.21. A (short neighbours): tower dominates, focal_ratio 5.85 (+39%). Confirmed by eye: indistinguishable left, clear landmark right.
- caveat: focal_ratio was the discriminator; `skyline_variation` did NOT separate these (0.136→0.113, wrong way) because an all-tall cluster also has a busy silhouette — don't rely on skyline alone for hierarchy. This SUPERSEDES the naive reading of P1: "add a landmark" is insufficient; it must out-contrast its locale.

### P4 — Build to player metrics (the player must fit)   [Metrics]  (canon: C1)
- source: https://book.leveldesignbook.com/process/blockout/metrics (Unity player bbox 1.0×1.8 m; doorway 1.25×2.5 m; "minimum hallway width should be at least double the player width"; stairs 30–35°)
- principle: Openings and passages must clear the player bounding box with margin, sized in absolute units from the start. A doorway narrower than the player width or shorter than player height does not work, no matter how it looks. Min passage width ≥ 2× player width.
- demonstrated_by: `_tmp/design/pass4_metrics/pass4_metrics_pair.png` + inspect — a 1.0×1.8 m player reference in a 0.8×1.5 m door overlaps both jambs AND the lintel (3 overlaps); in a 1.4×2.4 m door, 0 overlaps. The discriminator is the skill's OWN `inspect.scene_report` overlap count (exact), not an image metric.
- caveat: "Metrics are not magic" (source) — fitting is necessary, not sufficient; feel still needs playtest. Numbers are engine-relative (Unity≠Unreal≠Source); this kit works in meters ≈ Unity. This makes player-fit a checkable PREFLIGHT-class gate, not a matter of taste.

### P5 — Greybox simple shapes before detail   [Blockout]  (canon: C1)
- source: https://book.leveldesignbook.com/process/blockout (blockout = "simple 3D shapes, but without any details"; "Sculpting is often a distraction... you'll forget to do any level design"; cheap-to-delete vs expensive finalized art)
- principle: Test the big shapes first with plain massing. Adding small detail/greebles early buries the silhouette you are trying to evaluate and makes iteration expensive. The blockout should read as a few clear masses.
- demonstrated_by: `_tmp/design/pass5_blockout/pass5_blockout_pair.png` — same massing; V smeared with ~50 greebles, A clean. edge_density 0.0229 → 0.0107 (2.1× more clutter in V); focal_ratio 5.16 → 7.43 (detail scatters attention). Viewed: big shapes unreadable left, instantly legible right.
- caveat: this is about TIMING/READABILITY, not "detail is bad" — detail belongs in the art pass once structure is confident. Source also notes wall≠floor value aids readability ("Color and brightness provide important context") — consistent with P3/value grouping, but NOT separately rendered this pass, so not recorded as its own principle.

### P6 — Light/dark contrast guides the player   [Lighting]  (canon: C3)
- source: https://www.worldofleveldesign.com/categories/wold-members-tutorials/magnar_jenssen/functional-lighting-magnar-jenssen.php ("The intensity of the exit-area draws the player in"; functional vs decorative lighting)
- principle: A goal/exit lit brighter than its surroundings reads as the destination and pulls the player toward it. Flat, uniform lighting gives no directional cue, even with identical geometry. Guidance can come from light alone — no layout change needed.
- demonstrated_by: `_tmp/design/pass6_lighting/pass6_lighting_pair.png` — IDENTICAL two-exit room; only lighting changed. V (flat): contrast 0.043, balance.dx 0.000, symmetry 0.999 — both exits equal, no cue. A (right exit lit): contrast 0.173 (4×), balance.dx +0.055 (weight pulls to the lit exit), symmetry 0.655, focal_ratio 4.25→7.15. Viewed: instant pull to the glowing exit.
- caveat: source warns "Don't make the hint too obvious, since that will lessen the feeling of discovery" — over-lighting one path kills exploration. This is the same "focal anchor" outcome as P1/P3 but via a DIFFERENT lever (light, not mass), so it can fight P-balance/fairness in symmetric competitive maps (Phase-2 conflict).
- CORRECTION (Phase 2, conflict2): P6 was stated too universally. Directing the player by lighting one path brighter applies to single-player/PvE. In competitive PvP it must NOT be used to favour one team's approach — lighting stays symmetric and serves readability only (see CONFLICTS.md: P3/P6 vs P7).

### P7 — Symmetry for competitive fairness   [Balance]  (canon: C1)
- source: https://book.leveldesignbook.com/process/combat/balance ("the most straightforward way to balance a map is to use symmetry"; mirror vs radial; "prioritize fairness over balance"; symmetry "feels artificial")
- principle: For two-team PvP, mirror/rotational symmetry gives each team an equal layout/territory — the simplest fairness floor. An arena where one side has more/better cover is inherently unfair.
- demonstrated_by: `_tmp/design/pass7_balance/pass7_balance_pair.png` — top-down ortho, flat symmetric lighting. V (cover on one half): symmetry 0.758. A (mirrored cover): symmetry 0.999. Viewed: one-sided vs balanced.
- caveat: (a) DESIGN caveat from source — symmetry "feels artificial" and fairness is psychological, not mathematical; symmetry is the floor, asymmetric balance is "more realistic" but "really hard to get right". (b) METHOD caveat learned this pass — the `symmetry` metric measures LUMINANCE symmetry, so it is confounded by an off-axis key light (first two attempts read 0.96/0.92 for BOTH because three_point lit one side); it is only valid under flat/symmetric lighting + a centered or top-down view. Directly conflicts with P3 (asymmetry for hierarchy/variety) and P6 (light-guidance breaks symmetry) — Phase-2.

---

## Discarded (covered chapter, not render-demonstrable)
- **Pacing** [https://book.leveldesignbook.com/process/preproduction/pacing] — the source frames pacing as TEMPORAL intensity rhythm (alternate highs/lows, tension→release, teach-test-twist) and explicitly NOT as spatial compression/release. A single still render cannot show intensity-over-time, and a spatial proxy would misattribute to the source. DISCARDED per "demonstrate or discard." Would need an intensity-vs-time curve or a multi-shot sequence to capture — out of scope for still-render + metrics.py.
