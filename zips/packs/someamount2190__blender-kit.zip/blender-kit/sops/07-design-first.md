# SOP 07 — Design first (research the build BEFORE any geometry)

**This runs BEFORE SOP-00/06 for every representational, multi-part, character,
or organic build.** It exists because skipping it broke a 3D anime head: only
proportions were researched, the *construction method* and *failure modes* were
not, geometry was written from prior — result: flat hair shards, melty eyes, a
highlight stuck on the cheek. Researching the WHAT is not enough; you must
research the HOW and the FAILURE MODES and commit a PLAN.

**Hard rule: no `bmesh`/geometry until `plan.design_gate()` PASSES.** The gate
rides on preflight — `preflight.check(plan_path=...)` ABORTS the render while the
plan is incomplete. There is no "I'll plan as I go".

---

### D0 — Scaffold the plan (the first action of the build)
- `python scripts/plan_build.py "<object>"` → writes `_tmp/<slug>_plan.md`.
- **PASS:** the plan file exists and is open in front of you.

### D1 — WHAT: proportions & ratios (sourced) → plan §1
- 5–10 sourced numbers; part-to-part RATIOS + key PLACEMENTS vs a primary
  dimension; cite sources. (Verified at ship by `check_ratios`/`check_placement`.)
- **PASS:** §1 filled with sourced numbers, no placeholder.

### D2 — VISUAL: fetch AND view the reference → plan §2
- `scripts/fetch_reference.py` (Gate 1.55). Prefer ortho/profile/model-sheet;
  a photo is acceptable if no ortho exists. **VIEW each with the Read tool** —
  a download is not a reference until you've looked at it.
- **PASS:** §2 lists the `references/refs/<slug>.*` paths and what you saw.

### D3 — HOW: research the construction method → plan §3  *(the step that was skipped)*
- This is about the CRAFT, not your prior. **Search** "how to model a `<X>` (3D /
  topology / hair / eyes / …)" AND read `references/techniques/INDEX.md`.
- Write the METHOD practitioners use for this object CLASS: the part breakdown and
  the technique for each tricky part. Examples of what this catches:
  - anime hair = strips/cards that **hug the skull**, not flat shards poking out;
  - anime eyes = an eyeball + lid, or a flat decal on a **flat facial plane**,
    kept **concentric** (don't yaw layers until they melt);
  - a hull = lofted stations, not a constant-width extrude.
- **PASS:** §3 names the method per part, grounded in research/the techniques cat.

### D4 — FAILURES: what commonly goes wrong → plan §4  *(also skipped)*
- Read `references/failures/INDEX.md` AND **search** "common mistakes modeling a
  `<X>`". List the specific traps for THIS build, each paired with its guard
  (`failure_scan` / `topology` / `check_ratios` / `check_placement` /
  `check_alignment` / `check_angles` / a seam close-up).
- **PASS:** §4 is a watchlist of trap → guard.

### D5 — FEATURE PARTS: the identity/function parts, designed FIRST → plan §5
- Name the parts an expert looks at first — the object's IDENTITY and FUNCTION
  (carrier = aircraft + island; tank = turret + gun; cathedral = spire + facade),
  NOT the body/mass. For EACH feature part write BOTH:
  (a) a REAL DESIGN — a part breakdown / detail floor: articulated geometry that
      reads as the actual thing, never a single primitive or afterthought blob;
  (b) a PLACEMENT LOGIC — the functional rule that fixes WHERE it goes and HOW
      it is oriented (verified at ship with `check_placement`/`check_clearance`).
  This step exists because a carrier shipped with a careful hull and blob
  aircraft/island: `references/failures/feature-parts-as-afterthought-blobs.md`.
- **PASS:** §5 names each feature part with a real design + a placement rule.

### D6 — DECOMPOSE: part → technique → check → plan §6
- One row per part, feature parts FIRST (highest detail): the part, its
  construction technique (from D3), its placement logic (from D5), and the
  specific check that will prove it. This is the actual build order.
- **PASS:** §6 table covers every major part.

### D7 — Open the gate
- `python scripts/plan_build.py "<object>" --check` (or `plan.design_gate(path)`).
- **PASS:** DESIGN GATE: PASS. Only now write geometry, threading the plan into
  every `preflight.check(plan_path=…)` so a regression re-blocks the render.

---

Then proceed to **SOP-06** (draft → detail) for the build itself, running the
size/position/symmetry/orientation quartet + `failure_scan` + seam close-ups per
part. The plan's §6 is your part list (feature parts first); the plan's §5 gives
each feature part's design + placement rule; the plan's §4 is your watchlist.

Skip SOP-07 ONLY for an abstract/primitive blockout (tactical massing, a few
boxes) that genuinely has no real-world referent — and say so explicitly.
