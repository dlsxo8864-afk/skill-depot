# SOP 06 — Draft → detail (multi-pass refinement)

For anything beyond a simple prop, ONE pass is not enough. Build a DRAFT of the
whole body first, then pick the parts apart and refine each in its own detail
pass — running the SAME processes and checks on every part. (This is the studio
weapon/asset workflow: rough volumes → main shapes → small details.)

Never jump straight to detailing one part on a body whose proportions aren't
locked — you'll just rework it. Lock the silhouette, THEN detail.

---

### Pass 0 — DRAFT the whole body (SOP-00 end to end)
- Research proportions (Gate 1.5) + failure modes (Gate 1.6).
- Block out EVERY major part as a simple primitive at correct proportion, all
  CONNECTED, correct material *contrast* (not final detail).
- Run the full pipeline: preflight → render canonical views → inspect →
  failure_scan → topology → VIEW. Fix proportions/silhouette here, cheaply.
- **PASS:** the draft reads as the object in silhouette; `failure_scan` CLEAN;
  proportions locked. Record the draft (object file) before detailing.

### Decompose — list the parts, prioritise (FEATURE PARTS FIRST)
- The **feature parts** (plan §5 — the identity/function parts: the carrier's
  aircraft + island, the tank's turret, the cathedral's spire) get the FIRST and
  DEEPEST detail passes and REAL articulated geometry — not a blob bolted onto a
  beautiful body. The body is support; do not let it eat the design budget.
- Each feature part is placed by its **placement LOGIC** (the functional rule from
  plan §5), then verified with `check_placement` / `check_clearance` (keep-out
  zones) — never scattered by eye.
- Then the remaining parts, ordered by VISIBILITY / silhouette impact. Don't detail
  everything — stop when the read is good at the intended camera distance.

### Pass N — DETAIL one part (repeat per part)
Treat the part like its own mini-build, running the SAME checks:
1. **Research** the part's real form AND its RELATIONSHIPS to other parts:
   - **Ratios** — size it RELATIVE to neighbours, not just absolutely (a part can
     be right alone but wrong next to another). Record ratios like "crossguard ≈
     4× blade width", "barrel ≈ 3× receiver". Counter-check with
     `inspect.check_ratios`.
   - **Alignments** — which axes this part must line up on vs other parts (sights
     share the centreline Y; the barrel group is coaxial; a mag is centred under
     the receiver). Record them; verify with `inspect.check_alignment`.
2. **Rebuild** that part with detail geometry (bmesh / extra primitives /
   `blendkit.detail` one-liners: `panel_groove`, `boolean_cut`, `bevel_sharp`,
   `greeble_region`, `bolt_ring` — see
   `references/techniques/boolean-bevel-greeble-detail`), REPLACING its draft
   primitive. Keep it CONNECTED to its neighbours (embed-attachment overlaps
   are the documented-intentional kind — cite the technique entry at Gate 9)
   and on its axis if the sub-assembly is symmetric. Bevel LAST so boolean
   edges get caught.
3. **Render a TIGHT CLOSE-UP FRAMED ON THE SEAM** — the actual joint/connection
   to its neighbour (muzzle, sight base, where two parts meet), NOT a wide/hero
   shot. `render.detail_views([(label, [part names]), ...], out_dir)` mechanizes
   this: one framed high-res close-up per feature part plus a detail contact
   sheet (`camera.frame_object` under the hood). AND re-render the whole.
   **RULE: look at the SEAMS, not the silhouette.** A green `failure_scan` is
   "no detected failure", NOT "correct" — the checks have blind spots (AABB
   connectivity); the eye on the close-up is the backstop. (This is how a
   detached suppressor + a sight void once shipped — see
   `references/failures/trusting-the-scan-over-the-eye`.)
4. **Check the part**: `failure_scan` (ONE connected component — no detached
   island; not below ground), `inspect.topology_gate([part names])` (PER-PART
   n-gon/doubles verdicts — whole-scene totals hide which part is dirty; clean
   with `clean=True` / `build.cleanup`), and the SIZE/POSITION/ORIENTATION trio
   vs neighbours — `check_ratios` (size) + `check_placement` (station/position)
   + `check_alignment` (symmetry) + `check_angles` (barrel elevation,
   funnel/mast rake, facing) — then VIEW the seam close-up. Run all four:
   alignment can be perfect while a part is mis-sized, mis-placed, or
   mis-angled.
5. **Record** the part's detail learning (object file) once a render verified it.
- **PASS (per part):** reads up close, stays connected (one component), clean
  topology, correct ratios + alignments, seam verified by eye, doesn't break the
  whole. Then the next part.

### Integrate + final
- After the priority parts are detailed, render the whole body again (hero +
  canonical) and run the full ship gate (`failure_scan`, `topology_report`,
  `axis_alignment` for symmetric assemblies). VIEW it whole.
- Then run the FINAL HARSH CRITIQUE + fix pass (SOP-00 Gate 9.7): attack the
  passing build — >=3 concrete render-visible defects, fix the fix-now items,
  re-render; accepted defects listed in the report. Detail builds especially:
  procedurally perfect spacing/rotation reads CNC-made, not crafted — vary it.
- **PASS:** detailed parts read individually AND the whole still holds together;
  all checks clean; one critique round clean. Report the draft→detail arc
  (before/after) including the critique.

Notes
- A detail pass must not regress the body: if detailing a part pushes it
  below-ground, off-axis, or disconnected, the same checks catch it — fix before
  moving on.
- When a check or critique flags a part you built, the FIX must be
  reference-grounded (SOP-00 Gate 9.7 rule): fetch+VIEW an image of the real
  part AND write its dimensions/ratios into the plan before editing geometry.
  Junction fixes especially need the joint's canonical numbers — width ratios
  and overlap direction, not just gap closure
  (`references/failures/gap-fixed-by-stretching-connector`).
- Boolean cuts ARE available: `blendkit.detail.boolean_cut` / `panel_groove`
  (headless-safe, `clean=True` re-quads the cut faces). Use them for real slots,
  grooves, recesses and vents instead of faking with thin geometry — and run
  `inspect.topology_gate` on the cut part afterwards.
