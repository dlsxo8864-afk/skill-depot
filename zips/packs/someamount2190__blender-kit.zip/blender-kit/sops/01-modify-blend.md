# SOP 01 — Modify an existing .blend

Changing a scene you can't fully see is dangerous. Snapshot, change ONE thing,
render the SAME camera before/after, and diff by eye.

---

### Gate 1 — Environment verified
- `sops/04-env-verify.md`. **PASS:** binary + version known, can view PNGs.

### Gate 2 — Snapshot (non-destructive)
- Copy the .blend to `…/snapshots/<name>_<timestamp>.blend` (filesystem copy or
  `bpy.ops.wm.save_as_mainfile(filepath=..., copy=True)` is acceptable here —
  this is a file op, not geometry).
- **PASS:** snapshot file exists and is non-zero size. Never edit the only copy.

### Gate 3 — BEFORE render (lock the camera)
- Open the file (`bpy.ops.wm.open_mainfile(filepath=...)` is fine — file op).
- If it has a camera, reuse it; else `camera.frame_scene()` and REMEMBER its
  name — every before/after render must use the identical camera + resolution.
- `preflight.check()` then render to `before.png` (single view is fine here).
- **PASS:** `before.png` written and viewed.

### Gate 4 — Make exactly one change
- Apply your edit with the data API / `blendkit` helpers (no `bpy.ops` geometry).
- Change one logical thing at a time so the diff is attributable.
- **PASS:** the change is in code, reproducible.

### Gate 5 — AFTER render (same camera)
- Render to `after.png` with the SAME camera + resolution as `before.png`.
- `inspect.scene_report()`.
- **PASS:** `after.png` written; inspect report read.

### Gate 6 — Before/after diff by eye
- View `before.png` and `after.png` side by side (use `render.contact_sheet`
  to stitch them). Confirm the change is exactly what you intended and nothing
  else moved, clipped, or started overlapping.
- **PASS:** intended change visible; no new OVERLAPS/FLOATING/DEGENERATE vs
  before; nothing unintended shifted.

### Gate 7 — Iterate or commit
- If wrong, revert to the snapshot and return to Gate 4.
- When right, save (file op) and report, citing the before/after contact sheet.
- **PASS:** saved; report cites the PNG you viewed.
