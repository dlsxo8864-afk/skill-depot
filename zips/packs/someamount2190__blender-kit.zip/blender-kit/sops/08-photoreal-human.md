# SOP 08 — Photoreal human (MPFB pipeline)

The primitive kit tops out at stylized busts (see `references/objects/
human-face-bust.md` for that ceiling). PHOTOREAL humans use asset-grade
geometry + photo-based skin + Cycles, integrated behind `blendkit.human`.
Licenses: MPFB is GPL tooling; all asset packs used are CC0; Poly Haven HDRIs
are CC0. Nothing here restricts your renders.

### Gate 0 — Provisioning (one-time per machine; ALREADY DONE on this machine)
- `blender --command extension install mpfb` (enable online access first:
  `bpy.context.preferences.system.use_online_access = True` + save userprefs,
  then `blender --command extension sync`).
- Asset packs (CC0 variants) from
  `https://files2.makehumancommunity.org/asset_packs/<pack>/<pack>_cc0.zip`:
  `makehuman_system_assets` (REQUIRED: eyes/teeth/basemesh materials),
  `skins01`, `eyebrows01`, `eyelashes01`, `hair01`. Unzip ALL into MPFB's
  user data dir (`LocationService.get_user_data()` — on this machine:
  `%APPDATA%\Blender Foundation\Blender\5.1\extensions\.user\blender_org\mpfb\data`).
  Zips are cached in `<skill>/assets/mpfb_packs/`.
- At least one CC0 `.hdr` in `<skill>/assets/hdri/` (polyhaven.com direct URLs
  work with curl).
- **PASS:** `human.asset_path("skins", "")` raises listing 40+ skins (not an
  empty list); `assets/hdri/*.hdr` exists.

### Gate 1 — Character spec (design gate still applies)
- For a SPECIFIC face/character, run SOP-07 first: the plan's WHAT section is
  the macro dict + asset picks; VISUAL is the reference you compare renders
  against. For a generic human, a one-line spec in the build script suffices.
- macro keys (all [0,1]): gender (0=female, 1=male), age (0.5 ≈ 25yo), muscle,
  weight, height, proportions, cupsize, firmness; race = weights dict
  {asian, caucasian, african} (≈sum to 1). PARTIAL dicts are fine —
  `generate_human` overlays them on MPFB defaults (never build the full dict
  by hand; a missing key crashes MPFB internals — learned the hard way).

### Gate 2 — Generate + equip
```python
from blendkit import human
h = human.generate_human(
    macro={"gender": 0.25, "age": 0.45, "race": {"caucasian": 0.8, "asian": 0.2, "african": 0.0}},
    skin="Darthfurby caucasian female",   # human.asset_path lists options on a miss
    eyes="High-poly", eyebrows="Eyebrow010", eyelashes="Eyelashes01",
    hair="Ponytail01")
```
- Pick HAIR that does not occlude the face for portraits (long bangs read
  dramatic but hide the eyes — check the render, not the asset name).
- MPFB humans are unclothed: frame head-and-shoulders for portraits, or equip
  clothes assets (`add_mhclo_asset`, packs available) for full figures.
- **PASS:** no equip errors; scene has basemesh + eyes/brows/lashes/hair meshes.

### Gate 3 — Light + render
```python
human.hdri_world(strength=1.0)
human.key_light(target=(0, 0, head_z))     # head_z from human.head_bbox(h)
human.portrait(h, out_path, direction=(0.4, -1.0, 0.1))
```
- Cycles + SSS: MINUTES per frame on CPU — budget for it; do look-dev at low
  samples (32) and final at 128+.
- **PASS:** render written; luminance sane; you VIEWED it.

### Gate 4 — The usual ship gates, adapted
- `failure_scan` / AABB overlap checks are built for props — on a 19k-vert
  human with fitted assets they produce noise; SKIP them here. The gates that
  matter: **VIEW the render**, then **Gate 9.7 HARSH CRITIQUE** (SOP-00) with
  a cold-eyes subagent given only the render. For photoreal, the critic's bar
  is "what breaks the photo illusion?" — skin response, eye contact, hair
  intersections, grounding, uncanny-valley tells.
- Record verified learnings per key (`--kind object --key <character>` or
  technique entries).

### Known limits (accept + list, don't hide)
- Rig/pose: SOLVED 2026-07-06 — `human.add_rig(h)` + `human.pose_relaxed(arm)`
  or `pose_bones(arm, spec)` (see techniques/photoreal-human-mpfb, sign
  convention measured). Expressions remain future work (`faceservice`/
  `targetservice` expose targets). Fit measurements (helmets, vests, bands)
  must run AFTER posing.
- Hair is mesh-card grooms from the packs, not particle/curve grooms.
- CPU Cycles render times; no GPU assumed.
