# SOP 02 — Material (build + preview)

You cannot judge a material from node values. Render it on a preview sphere and
look. All Principled writes go through `compat` (version-safe sockets).

---

### Gate 1 — Environment verified
- `sops/04-env-verify.md`. **PASS:** can render + view PNGs.

### Gate 2 — Build the node graph
- Start from a `material.*` factory (`concrete/metal/plastic/emissive/glass`) or
  `material.diffuse()`, then tweak via `compat.principled_set(bsdf, ...)`.
- Friendly keys: `base_color, metallic, roughness, specular, ior, alpha,
  emission_color, emission_strength, transmission, coat, sheen, subsurface`.
- **NEVER** `bsdf.inputs['Specular']` — that KeyErrors on 4.0+. If you see that
  error, go to SOP 03 (signature `principled_socket_renamed`).
- **PASS:** material created, no socket KeyError.

### Gate 3 — Preview sphere scene
- Minimal scene: `build.add_uv_sphere(radius=1)`, assign the material,
  `build.add_ground` below it, `light.three_point` + `light.world_sky`,
  `camera.frame_scene`.
- For glass/transmission set the engine appropriately (Eevee needs
  `use_screen_refraction`; Cycles shows it directly).
- **PASS:** preflight passes.

### Gate 4 — Render preview + view
- `render.canonical_views(out_dir)` or a single framed render.
- **PASS:** PNG written with non-zero luminance, and you VIEWED it.

### Gate 5 — Judge + adjust
- Look: is it the intended albedo, roughness, metalness, glow? Metals should
  show reflection/dark diffuse; emissive should visibly glow; concrete should be
  matte. Adjust values and return to Gate 4.
- **PASS:** the rendered look matches intent on your own inspection.

### Gate 6 — Report
- Cite the preview PNG you viewed and the final socket values.
