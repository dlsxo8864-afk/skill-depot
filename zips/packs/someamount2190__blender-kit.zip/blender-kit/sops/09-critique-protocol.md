# SOP-09 — Critique Protocol (Gate 9.7 agent contracts)

Why this exists (2026-07-05, user-directed): free-prose critiques are
metaphor-heavy ("snapped antenna", "lobster bib", "picnic table") and the
engineer must PARSE rhetoric back into geometry before it can verify
anything. Metaphors bundle several claims into one image (the "snapped
antenna" asserted asymmetry FALSE + wrong pitch TRUE + breakage FALSE),
carry rhetorical confidence that is not evidence, and across the first 5
critique rounds roughly HALF of all critic claims died against gated
constants — each one a wasted verification cycle. The percept is data;
the rhetoric is noise. This SOP structures the contract so the percept
survives and the claims become mechanically checkable.
`ledger.record_critic` REFUSES artifacts that don't follow the format.

## The CRITIC contract (cold eyes: renders ONLY, no build info)

The critic prompt MUST require this exact per-item format:

    ITEM <n>: <short title>
    PERCEPT: <what it reads as — metaphor allowed HERE, one line max>
    CLAIM: <the specific checkable assertion: part, property, direction,
            magnitude. Quantities MUST be tagged (eyeballed) unless read
            off an orthographic view. One claim per ITEM — split bundles.>
    SEEN-IN: <which sheet/panel + where in frame>
    SEVERITY: <identity-kill | major | minor>
    PRESCRIPTION: <what correct looks like, with numbers where known>

Rules for the critic:
- One CLAIM per item. "Asymmetric AND wrong angle AND detached" = 3 items.
- Perspective/fisheye views are NOT evidence for proportion claims — say
  "(eyeballed, perspective view)" or use the top/front panel.
- Symmetry claims require checking BOTH sides in a panel where both are
  visible; otherwise write "one side occluded — verify".
- No prescriptions without either a number or "(class prior)".

## The ENGINEER contract (full context: code + plan + gates + renders)

Per ITEM, in order:
1. Map CLAIM -> code lines / gated constant / measured datum.
2. VERDICT: GEOMETRY-TRUE / READABILITY-ONLY / MISREAD (cite the gate or
   constant that decides; the PIPELINE RULE stands: when a claim
   contradicts a gated constant, the constant wins).
3. LABEL: FIX-NOW (with concrete coordinates) / ACCEPT (cite plan section)
   / KIT-EXTENSION.
4. The PERCEPT line is triaged SEPARATELY from the claim: a MISREAD claim
   can still carry a true percept (the "yellow sphere hand" claim was
   false — the percept "the hand region reads confusing" was true and
   worth a readability note). Never discard the percept with the claim.
Output ends with a build order ranked by identity recovery.

## Recording (Gate 10 prerequisites)

    python scripts/record_phase.py --out <dir> --critic <critique.md>
      -> refuses artifacts missing >=3 "CLAIM:" and >=3 "SEEN-IN:" lines
    python scripts/record_phase.py --out <dir> --engineer <triage.md>
      -> refuses triage without the verdict labels (unchanged)

## Evidence base

- Giraffe/armor/destroyer/C-130/FA-50/Scorpion/tricycle/Andrada/Gundam
  rounds: the percept lines produced the best finds of each round (solid
  disc wheels, office-chair silhouette, radio-mast kinks); the unfalsifiable
  bundled claims produced ~50% false positives, all engineer-dismissed via
  constants (L/B 3:1 vs gated 3.95; chest depth "paper-thin" at 63% inside
  the critic's own 60-70% band; "Russian ensign" that was the PH flag).
