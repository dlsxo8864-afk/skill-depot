# SOP 03 — Debug a failure

When a script/render fails or the render looks wrong. Deterministic, bounded.
**Consult memory BEFORE reasoning from scratch. Never fake success.**

---

### Gate 1 — Capture the failure
- You ran via `scripts/run.sh <script.py>`, so the full stdout+stderr+returncode
  are already in `logs/<timestamp>.log`. If you ran Blender directly, re-run
  through `run.sh` so the log exists and the script file is untouched.
- **PASS:** you have the log path. `returncode != 0` OR a wrong-looking render.

### Gate 2 — Consult memory FIRST
- `python scripts/blendkit/debug.py logs/<timestamp>.log`
  (works with system python or `blender -b --python` — it's pure python).
- This prints, in order:
  1. the extracted error lines,
  2. **memory hits** from `LEARNINGS.md` + `references/bpy_gotchas.md` matching
     the signature — a prior VERIFIED fix beats fresh reasoning,
  3. the **classifier** verdict: signature -> probable cause -> fix.
- **PASS:** you have a candidate fix from memory or the classifier.

### Gate 3 — Apply the mapped fix (bounded retries, max 2)
Known signatures and their fixes:
| signature | cause | fix |
|-----------|-------|-----|
| `ops_poll_failed` | `bpy.ops` without context in `-b` | use data API / bmesh (`build`) |
| `principled_socket_renamed` | socket renamed in 4.0 | `compat.principled_set(...)` |
| `mesh_op_wrong_mode` | mesh op in object mode | use bmesh |
| `gpu_egl_headless` | headless GPU/EGL fail | Cycles CPU (auto in `render.render_still`) |
| `black_render` | no light / camera off-target | `preflight.check` + add lights / re-frame |
| `object_missing_from_render` | `hide_render` / not linked | link to collection, `hide_render=False` |
| `radians_degrees_mixup` | wrong rotation unit | `transform.set_rotation_deg` |
| `module_not_found_blendkit` | sys.path missing | insert `scripts/` before import |
- Apply ONE fix, re-run through `run.sh`, re-render+inspect.
- **PASS:** returncode 0 AND render/inspect now pass. Stop after 2 attempts.

### Gate 4 — If still failing: minimal repro, then STOP
- Strip the scene to the smallest script that still reproduces the failure
  (one object, one material, one render). Isolate the offending call.
- Do NOT silently flail or claim success. Surface to the user:
  the minimal repro, the log, and your hypothesis.
- **PASS:** either fixed, or a clean minimal repro + hypothesis handed over.

### Gate 5 — Record the learning (ONLY if verified)
- If you solved a NEW failure AND a render/inspect actually PASSED, append to
  `LEARNINGS.md` (see its header for the format), with
  `verified_by` = the render that proved it. Dedupe by `error_signature`.
- If the lesson is durable+general, also add a row to
  `references/bpy_gotchas.md`. Keep project-specific notes in that project's
  render log.
- **Never** record an unverified guess — it poisons future debugging.
