# SOP 05 — Tactical-level design pass

Apply AFTER the scene builds + inspects clean (SOP 00). These are the durable,
render-verified principles promoted from `DESIGN_PRINCIPLES.md` (canon-grounded,
each proven on a violating/adhering pair). Treat as default gates for tactical
scenes; the full reasoning + render evidence lives in the design catalog. Genuine
tradeoffs are in `design/CONFLICTS.md`; debunked defaults in `CLICHES.md`.

---

### Gate 1 — Greybox before detail (P5)
- Build the big masses with plain materials first. No greebles/sculpting/splines
  until structure is confident.
- **PASS:** the contact sheet reads as a few clear shapes; `edge_density` low
  (≈≤0.012 on a framed persp). High edge density early = detail too soon.

### Gate 2 — Player metrics / fit (P4)  [hard gate]
- Size openings/passages in meters from the start: passage width ≥ 2× player
  width; doorway clears player height (player ≈ 1.0×1.8 m ≈ Unity).
- Drop a 1.0×1.8 m `PlayerRef` box in each key passage and run
  `inspect.player_fit(scene)` (or `inspect.scene_report` and read PlayerRef
  overlaps).
- **PASS:** zero PlayerRef overlaps. Any overlap = the player does not fit — fix
  before anything else (this is the cheapest, most objective failure).

### Gate 3 — Hierarchy = local contrast (P1, P3)
- Give the space ONE relevant landmark that OUT-contrasts its locale on some axis
  (height / spacing / orientation / shape). A tall thing among tall things is not
  a landmark.
- **PASS:** `focal_ratio` clearly higher than a no-landmark version; by eye the
  anchor is obvious from the player's entry view. Don't add competing landmarks.

### Gate 4 — Light for readability + guidance (P6)
- Avoid flat, even lighting. Use light/dark contrast to make the goal read.
- **Single-player/PvE:** light the intended path/exit brighter to guide (don't
  over-do it — kills discovery).
- **Competitive PvP:** keep lighting SYMMETRIC — never light one team's approach
  brighter (fairness). Use light for readability only.
- **PASS:** `contrast` ≈ ≥0.12 on the framed view; the goal reads as brighter
  than its surroundings (PvE) or both sides equal (PvP).

### Gate 5 — Sightlines: anchor far, occlude near (P2 + CONFLICTS)
- Resolve "show a landmark" vs "hide what's ahead" by SCALE: keep a distant/high
  orientation anchor visible while occluding the immediate path for suspense.
- **PASS:** from the player's eye, a far anchor is visible AND the next
  immediate beat is not fully pre-revealed. Pure occlusion only when "being
  lost" is the intended experience.

### Gate 6 — Fairness for competitive maps (P7 + CONFLICTS)
- Two-team PvP: mirror/rotational-symmetric GAMEPLAY geometry. Deliver side
  identity/orientation through COSMETIC layers only (per-side colour/art/
  non-blocking light) — never through gameplay-affecting asymmetry.
- **PASS:** geometry symmetry high under flat/centered check (`symmetry` metric
  ≈ ≥0.95 on a top-down ortho with flat light); sides visually distinguishable.
- (Single-player tactical: skip — lean asymmetric with strong landmarks.)

### Gate 7 — Cliché check (CLICHES.md)
- Each pass, kill one default if present: leading lines, trusting a
  screenshot/plan as proof, auto-flagging dead-ends as bad, gratuitous
  verticality.
- **PASS:** none of the above is load-bearing in the design rationale.

### Gate 8 — Judge by eye (metrics capture ~half)
- View the canonical renders and decide if it READS as intended. Metrics are
  blunt: they are colour-blind (can't see per-side identity), and `value_entropy`
  penalizes deliberately dark/dramatic scenes (low ≠ bad massing). When metric
  and eye disagree on intent, the eye wins — say so explicitly.
- **PASS:** you have stated what the metrics miss and confirmed the read yourself.
