# SOP 00 — New Scene (build from scratch)

Numbered gates. **No gate may be skipped.** Each states what PASS looks like.
Copy `scripts/new_scene.py` as your starting point. Its contract:
- `--plan <path>` (optional): preflight runs the fail-closed design gate against
  that plan and BLOCKS on unfilled sections. **Representational builds MUST pass
  `--plan _tmp/<slug>_plan.md`** (SOP-07). Omitted, it prints a loud
  `WARNING: DESIGN GATE SKIPPED (no --plan given)` — acceptable only for
  abstract/blockout scenes.
- It always runs `inspect.failure_scan()` after `scene_report` (Gates 8 + 9.5).
- It exits non-zero on preflight abort, render failure, a failing inspect
  report, or failure_scan failures — a zero exit means the automated gates
  passed. Gates 1–1.6, 9 (VIEW), 10, and 11 remain yours to do by hand.

---

### Gate 1 — Environment verified
- Run `sops/04-env-verify.md` once per machine/session.
- **PASS:** binary located, version known, one-cube test render produced AND
  viewed. If you cannot view a PNG, STOP — the visual loop is the whole point.

### Gate 1.5 — Research proportions (representational objects only)
- If building a recognizable real-world object (sword, chair, car, rifle, …),
  do NOT guess dimensions from your prior — that yields "slightly off scale /
  edge & point placement" errors.
- **Consult FIRST:** `references/objects/INDEX.md` → if the object has an entry,
  open `references/objects/<slug>.md` and build from it (skip re-research). Also
  check `references/refs/INDEX.md` for a saved 2D reference to build against.
- **If new:** follow `references/proportions.md` — find 5–10 sourced references,
  synthesize a HELD BELIEF, keep the numbers as comments in the scene script.
- **Record the full SIZE / POSITION / ORIENTATION belief, not just absolute
  sizes** (for multi-part objects), and MEASURE it off the 2D reference (Gate
  1.55) — eyeballing yields "reads right but feels off". Capture, as numbers tied
  to a primary dimension (length/beam):
  - **RATIOS** (size): crossguard ≈ 4× blade width; barrel ≈ 0.075× hull length.
  - **PLACEMENTS** (position): each part's station along the hull/axis as a
    fraction (turret 1 ≈ 0.21 of length from the bow).
  - **ALIGNMENTS** (symmetry): which parts share which centreline.
  - **ANGLES** (orientation): barrel elevation, funnel/mast rake, turret facing.
  Verify ALL FOUR at ship — they catch different errors (a part can be the right
  size, symmetric, AND still mis-placed or mis-angled): `inspect.check_ratios`,
  `inspect.check_placement`, `inspect.check_alignment`, `inspect.check_angles`.
- Skip for abstract/blockout-only scenes (tactical massing, primitives).
- **PASS:** a sourced held-belief (from the object file or fresh research) exists,
  or this gate is N/A, before any geometry is placed.

### Gate 1.55 — Fetch a 2D reference (representational objects only)
- Numbers alone still leave the silhouette/feature placement off. Get a VISUAL:
  a **side orthographic / blueprint** is best (pins silhouette, overhangs, glass
  DLO, feature x-positions); a clean **front/top ortho** and one **3/4 photo**
  help too.
- **Fetch + validate + store** with the tool (rejects HTML error pages by magic
  bytes, writes provenance to the `refs` bucket):
  ```
  python scripts/fetch_reference.py --key "<obj>" \
      --url SIDE=<direct-image-url> --url FRONT=<...> --note "<how used>"
  ```
  Find direct image URLs with WebSearch/WebFetch first (a DIRECT `.png/.jpg`,
  not a gallery page). Re-use `references/refs/<slug>.*` if already fetched.
- **VIEW each saved image** (Read tool) and confirm it is actually usable — an
  ortho with no perspective distortion for measuring; a photo only for feel.
  Read proportions/feature positions OFF the image to refine the held belief.
- **PASS:** at least one usable 2D reference is fetched, viewed, and the build is
  set up against it (or N/A for abstract scenes). A photo-only ref is acceptable
  when no ortho exists — say so.

### Gate 1.6 — Research failure points (every build initiates this)
- **Consult the baseline:** read `references/failures/INDEX.md` — the
  community-sourced common-failure baseline (floating/disconnected geometry,
  n-gons, non-manifold, flipped normals, doubles, wrong scale, intersecting,
  detail-too-early, unapplied transforms) and any object-specific entries.
- **Then search the community** for THIS object's known modeling pitfalls
  ("common mistakes modeling a <X>"); add any new failure mode you find via
  `record_learning.py --kind failure`.
- **PASS:** you know the failure modes to avoid for this build (and the checks
  that catch them) before placing geometry.

### Gate 2 — Blockout geometry (data API only)
- Build with `blendkit.build` (`add_box/cylinder/plane/...`, `grid`, `array`).
- Place objects in METERS, to the held-belief numbers when Gate 1.5 applies.
  Keep each object's underside on its support (a box of height h on the floor
  has `location.z = h/2`).
- **NEVER** `bpy.ops.mesh.*` / `bpy.ops.object.*`. **NEVER** set rotation in
  raw radians — use `transform.set_rotation_deg`.
- **PASS:** all intended objects exist; `len(scene.objects)` matches your plan.

#
## Gate 2.8 — SUB-BUILD RULE (do not skip: this is the documented failure mode)
If any DECOMPOSE row is a machine/organism that could be its own build (the
motorcycle in a tricycle, the tractor in a trailer rig, the gun in a mount,
the rider on a horse), it MUST be built as its OWN script with its OWN green
gates and VIEWED renders BEFORE the assembly script is written. Expose it as
a build_X() function; the assembly imports it (importlib on the sibling file,
__main__-guarded). See references/techniques/subassembly-first-builds —
tricycle v1 shipped a 'bath toy' bike because this phase was compressed into
a single whole-object pass whose gates all went green. Green whole-object
gates DO NOT certify sub-machine craft.

## Gate 3 — Materials
- Assign via `material.assign(obj, material.concrete()/metal()/...)`.
- All Principled writes go through `compat.principled_set` (done for you inside
  `material.py`). Do not index `bsdf.inputs['Specular']` directly.
- **PASS:** every visible object has a material slot; no KeyError on sockets.

### Gate 4 — Lighting
- `light.three_point(target=...)` for product/blockout; `light.sun()` exterior.
- Add `light.world_sky(strength=0.3..0.5)` so nothing is pure black.
- **PASS:** at least one light OR world lighting present (preflight enforces).

### Gate 5 — Frame the camera
- `camera.frame_scene(direction=(...))` auto-fits the whole scene; it sets clip
  planes from the bounds so nothing is clipped.
- **PASS:** `scene.camera` is set.

### Gate 6 — Preflight (ABORT gate)
- `preflight.check()` (with `plan_path=_tmp/<slug>_plan.md` for representational
  builds — the design gate re-blocks on a regressed plan); print `format_check`.
- **PASS:** `result["ok"] is True`. On FAIL, fix the listed errors (no light,
  camera not aimed, NaN/zero-scale) and re-run. Do NOT render on a failed preflight.

### Gate 7 — Render canonical views
- `render.canonical_views(out_dir, samples=48, resolution=(640,480))`.
- Produces framed perspective + front + ortho-top "blueprint" + a contact sheet,
  and a `render.log`. Eevee default; Cycles-CPU fallback is automatic.
- **PASS:** contact sheet PNG written; render.log shows non-zero luminance per
  view (a `lum≈0` view means black — go to SOP 03).

### Gate 8 — Inspect
- `inspect.scene_report()` (also printed into the log).
- **PASS:** you have read the report. Note every entry under OVERLAPS / FLOATING
  / DEGENERATE.

### Gate 9 — VIEW + fix (the loop)
- Open the contact sheet (and individual PNGs) with your image tool. Actually
  look: overlaps, gaps/floating, clipping, wrong scale, intersections,
  off-frame objects.
- Cross-check what you see against the inspect report. Fix in code (move/scale/
  reseat objects, re-frame camera), then **return to Gate 6**. For any
  PROPORTION/SHAPE defect (not a mere placement slip), apply the
  REFERENCE-GROUNDED FIXES rule from Gate 9.7 first: fetch+VIEW a reference
  and write down the part's dimensions/ratios before touching the numbers —
  an eyeballed correction to an eyeballed mistake converges on a new mistake.
- **PASS:** inspect report is clean (`ok: True`) AND the render visually holds
  on your own inspection. Only now proceed. SOLE exception: a flag may stand
  ONLY if a `references/` entry documents that exact flag as intentional for
  this object class (e.g. `objects/sword.md` ferrule overlaps) — cite the entry
  in your build notes. No citation → fix the flag.

### Gate 9.5 — Failure scan (SHIP GATE — run on EVERY build)
- `inspect.failure_scan()` — catches the failures the overlap report misses,
  even on dense/organic models where you skip `scene_report`:
  **below_ground**, **floating** (a part not connected — STRICT: a gap fails
  even if "close"; every part must touch/overlap another), **degenerate**.
- Also confirm `inspect.topology_report()` (n-gons/doubles) if heading to
  subdiv/anim/export.
- **PASS:** `failure_scan` is CLEAN (`ok: True`). FLOATING/BELOW-GROUND are NOT
  "judgment calls" — fix them (connect to the parent surface; cap/raise above
  the floor; or scan-and-remove the strays). SOLE exception: a flag may stand
  ONLY if a `references/` entry documents that exact flag as intentional for
  this object class (e.g. `failures/waterline-floor-false-positive.md` — a
  ship's keel is correctly below z=0; `objects/chair.md` intentional floats) —
  cite the entry in your build notes. No citation → fix the flag. Never ship a
  build you have not failure-scanned.

### Gate 9.7 — FINAL HARSH CRITIQUE + fix pass (ship gate for quality)
All green gates prove the build is CORRECT, not that it is GOOD. Before
reporting, attack it:
- Re-view every render (canonical + detail sheets) as a hostile art director
  who assumes the model is WRONG. Produce a written critique of **at least 3
  concrete, render-visible defects**, each with severity (fix-now / accept) and
  the specific fix. Generic praise is a FAILED critique; "nothing wrong" is
  almost always a failed critique on a first pass.
- Critique against the craft, not just the checklist: material response (does
  the metal read as metal, or wash to white? — `references/rendering-metal.md`
  dark-floor caveat), scale cues, silhouette, whether each FEATURE PART actually
  reads at its own scale in the detail sheet, mechanical plausibility of seams,
  uniformity that smells procedural (perfectly even spacing/rotation reads CNC,
  not crafted), and the CLICHES.md list.
- Cold eyes beat warm eyes: if you can spawn a subagent, give it ONLY the
  render paths (no build context) and ask for the 3 worst things about the
  model; fold its findings in.
- **ENGINEER (NOT optional — absorbing this role inline 'to save time' is the documented erosion path; it ran once in 9 builds until this note) PASS (critic -> engineer -> fix):** the critic judges; it does
  not know the toolkit. Feed the critique + the build script + the blendkit
  module list to a SECOND subagent acting as the implementation engineer:
  for each critique item it must return (a) a concrete fix expressed in
  kit calls / parameter changes / new helper functions, (b) a feasibility
  label — FIX-NOW (kit can do it today) / KIT-EXTENSION (small new helper
  makes it possible) / ACCEPT (beyond the kit; say why), and (c) the
  expected visual delta. This closes the gap where a valid critique dies
  because the builder can't see HOW to apply it — and it surfaces cheap
  kit extensions the builder is too close to notice.
- **REFERENCE-GROUNDED FIXES (mandatory for every geometry/proportion
  defect the checks or critic find):** before implementing the fix, the
  engineer (or builder) must obtain for the AFFECTED PART: (1) a VISUAL
  reference — an existing `references/refs/` image or a fresh
  `scripts/fetch_reference.py` fetch, VIEWED with the image tool — and
  (2) SPECIFICATIONS/DIMENSIONS — the part's canonical measurements,
  width/length ratios, anchor heights, and overlap direction, written as
  NUMBERS. The fix must cite both; the numbers go back into the plan's
  WHAT section and become `check_ratios`/`check_alignment` specs where
  expressible. Fixing a flagged part from the critique text alone is how
  the armor grew a giraffe neck TWICE: the first fix shortened a connector
  without the joint's datum (helmet must be ~1.7x wider than the neck,
  chin ~4cm above the shoulder line, helmet skirt overlaps the gorget) —
  see `references/failures/gap-fixed-by-stretching-connector`. A defect
  without a reference-and-numbers trail is not fixed; it is re-guessed.
- FIX the fix-now items (and any cheap kit-extensions worth it), re-render,
  re-view (return to Gate 6). Accepted defects must be LISTED in the report
  with the reason — never silently.
- **PASS:** one full critique round produced no new fix-now defects, and every
  accepted defect is written down.

### Gate 10 — Report
- State what you built, cite the contact sheet path you viewed, and paste the
  final inspect + failure-scan summary. Include the Gate 9.7 critique and its
  accepted-defects list. If anything is still imperfect, say so explicitly —
  never claim "looks good" you did not verify by eye.

### Gate 11 — Record learnings (only what the render/inspect VERIFIED)
- Route per-key learnings (don't bloat one catalog, don't hand-edit the index):
  - object-specific (dimensions/anatomy/build/topology surprises) →
    `python scripts/record_learning.py --kind object --key "<obj>" --verified-by "<render>" …`
  - material/texture-specific (shader values, lighting that made it read) →
    `… --kind material --key "<material>" …`
- Only record what a pass proved; cite the render in `--verified-by`. Skip for
  throwaway/abstract scenes.
- **PASS:** new verified learnings are in their per-key files (or none to record).


## Gate 10 — SHIP CHECK (fail-closed, the last gate; added 2026-07-04 "gate everything")
The build ledger (`build_ledger.json` in the out dir) must be complete before
anything is reported/sent:
1. build script's gates block calls `ledger.record_gates(OUT, ok, detail)`;
   a SUB-BUILD script calls `ledger.record_subbuild(OUT, __file__, ok)` and is
   declared in the plan as `sub-build: _tmp/<slug>/build_<part>.py`
   (preflight Gate 2.8 refuses the assembly until it is green).
2. Gate 9.7 artifacts saved to files and recorded (validated on record;
   BOTH agents prompted per sops/09-critique-protocol.md — the critic must
   use the PERCEPT/CLAIM/SEEN-IN item format or the recorder refuses it):
   `python scripts/record_phase.py --out <dir> --critic <critique.md>`
   `python scripts/record_phase.py --out <dir> --engineer <triage.md>`
   (triage must use the labels FIX-NOW/ACCEPT/MISREAD/... — a hand-wave is refused)
3. Deviation disclosure is mandatory:
   `python scripts/record_phase.py --out <dir> --deviation "<what+why>"` or `--no-deviations`
4. `python scripts/ship_check.py --out <dir> --plan <plan>` prints SHIP: PASS.
Report format: cite the ship_check PASS line including the disclosed deviations.
Why: nine builds of silent phase-erosion (engineer pass ran 1/9) while every
coded gate held. Prose does not bind; this gate does. Tests: design/test_ship_gate.py.

### Emissive glow (optional, calibrated)
Scenes whose identity includes glowing parts (magic, lightning, energy):
`render.enable_glow(...)` before the renders — dials from
`references/materials/emissive-glow.md` (CALIBRATED table; do not guess).
Low-strength inlay chips (s<=3) stay below halo onset by design.
