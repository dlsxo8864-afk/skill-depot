# SOP 04 — Environment verify

Run once per machine/session before any build. The visual loop is the point — if
you can't view a render, everything downstream is guessing.

---

### Gate 1 — Locate the Blender binary
- Known on this machine: `C:\Program Files\Blender Foundation\Blender 5.1\blender.exe`.
- Otherwise search: PATH (`blender`), `C:\Program Files\Blender Foundation\*`,
  `/Applications/Blender.app/Contents/MacOS/Blender`, `/usr/bin/blender`,
  `$LOCALAPPDATA\Programs`.
- **PASS:** a path that runs `blender --version`.
- **If missing — do NOT `pip install bpy`** (that's a module, not the app, and
  can't render headless reliably here). Install the app:
  - Windows: download from blender.org, or `winget install BlenderFoundation.Blender`.
  - macOS: `brew install --cask blender`. Linux: distro package or blender.org tarball.
  Then re-run this gate.

### Gate 2 — Version + Python
- `blender --version`. Note `(major, minor, patch)`.
- **PASS:** version recorded. **4.0+ uses renamed Principled sockets** — always
  go through `compat`. This machine: **5.1.2, Python 3.13**.

### Gate 3 — Engine availability
- Eevee id varies (`BLENDER_EEVEE` on 5.x/4.3+, `BLENDER_EEVEE_NEXT` on 4.2).
  Use `compat.eevee_engine_id()`; never hard-code.
- Confirm Cycles-CPU fallback: `compat.ensure_cycles_available()` -> True.
- **PASS:** Eevee id resolved; Cycles available True.

### Gate 4 — Test render AND VIEW it
- Render one lit cube headless to a PNG, then OPEN it with your image tool.
  (`render.render_still` or the one-cube snippet.)
- **PASS:** you can actually SEE the cube in the PNG. If not — STOP and tell the
  user the visual loop is broken; do not proceed to build scenes you can't check.

### Gate 5 — run.sh smoke
- `BLENDER="<path>" scripts/run.sh scripts/new_scene.py` (set BLENDER on
  non-Windows or non-5.1 installs). Confirm it writes `logs/<ts>.log` and prints
  `returncode=` + `LOG=`.
- **PASS:** log file created; a deliberate error returns non-zero (run.sh passes
  `--python-exit-code 1`).
