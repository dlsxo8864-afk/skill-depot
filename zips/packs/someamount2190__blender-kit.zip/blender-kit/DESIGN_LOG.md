# DESIGN_LOG — per-pass record

Chronological. One block per pass: what was fetched, what was extracted, what the
render showed, what the metric said, and the verdict (RECORDED / DISCARDED /
CLICHE). Discards are first-class — logging why a platitude failed is as valuable
as a verified principle.

---

## Pass 1 — Layout (C1)
- fetched: https://book.leveldesignbook.com/process/layout
- extracted: (a) landmarks/area-naming aid player understanding; (b) debunk: "a layout is NOT a level"; plans can't prove a level works.
- built: pass1_layout_landmark.py — V: 7 identical crates in a ring; A: same ring + one tall lit tower. Same fixed camera.
- render+metric: focal_ratio 5.38→9.80, symmetry 0.97→0.62, skyline_var 0.053→0.125. Viewed pair: right has an obvious anchor, left none.
- verdict: RECORDED P1 (landmark anchor). CLICHE recorded ("a layout drawing proves the level works"). Note: Layout parent chapter is mostly process advice — sightlines/junctions live in Flow (next pass), not here.

## Pass 2 — Flow (C1)
- fetched: https://book.leveldesignbook.com/process/layout/flow
- extracted: (a) occluded sightline / uncertainty is more exciting than a clear straight path; (b) debunk: indirect routes/dead-ends not inherently bad; (c) debunk: restraint on verticality.
- built: pass2_flow_sightline.py — V: straight corridor, lit marker visible; A: dogleg, marker occluded. Same player-eye camera.
- render+metric: focal_ratio 14.58 (centered marker) → 9.35 (off-axis, hidden). Viewed pair: reward visible left, gone right.
- verdict: RECORDED P2 (occluded sightline) WITH the source's own non-universal caveat. 2 CLICHES recorded (dead-ends, verticality). Noted P1↔P2 tension for Phase 2.

## Pass 3 — Massing/Composition (C1)
- fetched: https://book.leveldesignbook.com/process/blockout/massing/composition
- extracted: (a) hierarchy = local contrast (same tower reads or not by context); (b) debunk: leading lines = "brain poison"; (c) debunk: spatial > shot composition, "screenshots aren't levels"; (d) sightline existence ≠ use.
- built: pass3_massing_contrast.py — IDENTICAL tower; V neighbours tall (3.6m), A neighbours short (0.8m). Same camera.
- render+metric: focal_ratio 4.21→5.85 (+39%). skyline_variation did NOT discriminate (0.136→0.113) — logged as a metric limitation. Viewed: tower blends left, dominates right.
- verdict: RECORDED P3 (hierarchy=local contrast), which SUPERSEDES naive P1. 3 CLICHES recorded (leading lines, screenshots/shot-comp, sightline-use).

## Pass 4 — Metrics (C1)
- fetched: https://book.leveldesignbook.com/process/blockout/metrics
- extracted: player 1.0×1.8 m; doorway 1.25×2.5 m; min passage ≥ 2× player width; stairs 30–35°.
- built: pass4_metrics_fit.py — V door 0.8×1.5, A door 1.4×2.4, with a 1.0×1.8 player reference standing in it.
- render+metric: inspect overlap count 3 (jambs+lintel) → 0. Viewed: player jams left, fits right.
- verdict: RECORDED P4 (build to player metrics). Discriminator is the skill's own inspect — exact, PREFLIGHT-class. Note for Phase 4: consider promoting a player-fit check into preflight/SOP.

## Pass 5 — Blockout (C1)
- fetched: https://book.leveldesignbook.com/process/blockout
- extracted: greybox simple shapes before detail; sculpting/splines are beginner distractions; wall≠floor value for readability.
- built: pass5_blockout_detail.py — same massing; V + ~50 deterministic greebles; A clean.
- render+metric: edge_density 0.0229→0.0107 (2.1×); focal_ratio 5.16→7.43. Viewed: buried left, legible right.
- verdict: RECORDED P5 (greybox before detail). Wall/floor value-separation NOT separately rendered → not recorded (demonstrate-or-discard).

## Pass 6 — Lighting (C3, WoLD / Magnar Jenssen)
- fetched: worldofleveldesign.com .../functional-lighting-magnar-jenssen.php
- extracted: light/dark contrast guides; bright exit = destination cue; functional vs decorative; don't over-hint.
- built: pass6_lighting_guidance.py — IDENTICAL two-exit room; V flat ambient, A right exit lit.
- render+metric: contrast 0.043→0.173, balance.dx 0.0→+0.055, symmetry 0.999→0.655, focal 4.25→7.15. Viewed: ambiguous left, clear pull right.
- verdict: RECORDED P6 (light guides). First C3 source. Noted conflict vs fairness (Phase 2).

## Pass 7 — Balance (C1)
- fetched: https://book.leveldesignbook.com/process/combat/balance
- extracted: symmetry (mirror/radial) = fairness floor; "prioritize fairness over balance"; symmetry feels artificial; asymmetric balance is hard.
- built: pass7_balance_symmetry.py — V cover one half, A mirrored both halves.
- attempt 1 (3/4 cam, three_point): symmetry 0.963 vs 0.954 — FAILED to discriminate (cover too small in frame). attempt 2 (bigger cover, closer): 0.955 vs 0.925 — still failed + wrong direction.
- ROOT CAUSE: symmetry metric measures luminance, confounded by off-axis key light. FIX: flat symmetric lighting + top-down ortho. attempt 3: symmetry 0.758 → 0.999 — clean. Viewed: one-sided vs mirrored.
- verdict: RECORDED P7 (symmetry=fairness) with a METHOD caveat on the metric (only valid under flat/centered lighting). Two honest failed attempts logged.

## Pass 8 — Pacing (C1 + C3)
- fetched: https://book.leveldesignbook.com/process/preproduction/pacing (+ WoLD Pete Ellis pacing series found in search)
- extracted: pacing = "order and rhythm of activities and events" over TIME; alternate highs/lows; tension→release; teach-test-twist; variety prevents habituation. Source EXPLICITLY frames it temporally, NOT as spatial compression/release.
- decision: a single still render cannot show intensity-over-time. Building a "spatial compression/release" proxy would MISATTRIBUTE to the source (which rejects that framing) — violates "ground in references, not priors".
- verdict: DISCARDED (chapter covered, no render-demonstrable principle). Not recorded. A future intensity-vs-time-curve or multi-shot-sequence capability could capture it; out of scope for the still-render + metrics.py methodology.

---
## Phase 1 saturation + self-review (art-director role, delegated)
- All 8 target chapters covered: Layout(P1), Flow(P2), Massing/Composition(P3), Metrics(P4), Blockout(P5), Lighting(P6), Balance(P7), Pacing(DISCARDED).
- Catalog: 7 principles, all render-verified with a discriminating metric; 6 cliches; 1 honest discard.
- As delegated art director I ACCEPT the Phase-1 catalog. Note for Phase 2 the live conflicts already surfaced: P1/P3 (anchor) vs P2 (occlusion); P3/P6 (hierarchy/guidance) vs P7 (symmetry/fairness). Proceeding to Phase 2.

---
## Phase 2 — SYNTHESIZE
- Conflict 1 (P1/P3 anchor vs P2 occlusion): forced via player-eye corridor; RESOLVED by scale separation (distant anchor + local occlusion). focal_ratio 7.10→10.14, focal moved wall→beacon. Recorded.
- Conflict 2 (P3/P6 expressive asymmetry vs P7 symmetry-fairness): forced via PvP arena; RESOLVED by layering (symmetric gameplay geometry + cosmetic per-side identity), symmetry 0.999→0.997 (fairness preserved). NAMED the residual tradeoff (no gameplay asymmetry in fair maps). Exposed metric color-blindness ("half of good"). CORRECTED P6 (not universal — PvP lighting stays symmetric).
- saturation: the two highest-frequency genuine pairs resolved/named; P6↔P7 subsumed in conflict 2; remaining pairs (P4, P5) don't genuinely fight. New conflicts would only reproduce these. SATURATED.
- art-director self-review: ACCEPT Phase 2; default leans set in CONFLICTS.md. Proceeding to Phase 3.

---
## Phase 3 — APPLY (target = single-player tactical compound, design/target_map.py)
Scored vs P1–P7 + metrics + inspect each pass; ONE change/pass; before/after viewed; revert if no gain.
- v0 baseline composite 0.447 — weakest fit 0.0 (player overlaps doorframe), lighting/massing flat.
- v1 widen passage 0.9→1.5×2.6 (P4): fit 0.0→1.0, composite 0.647. KEEP. Viewed.
- v2 directed lighting (P6): lighting 0.117→0.771, massing 0.117→0.759 (hierarchy dipped 1.0→0.579 as flat-scene focal inflation vanished); composite 0.802. KEEP. Viewed (form/shadow vs washout).
- v3 add landmark (P1/P3): hierarchy 0.579→1.0 (focal 5.79→12.15); composite 0.862. KEEP. Viewed (clear beacon anchor).
- v4 value_split wall≠floor (P5/P3): massing 0.675→0.670, composite 0.859 — NO gain (albedo washed out by lighting). REVERTED. Viewed (identical to v3).
- v5 reduce clutter 28→4 (kills the premature-detail CLICHE): readability 0.91→0.935; composite 0.867. KEEP. Viewed (clean blockout).
- PLATEAU: massing held 0.675 across v3/v4/v5 despite targeted attempts. Pushing it further = metric-chasing (adding value tiers that don't serve a deliberately dark tactical scene).
- HUMAN-EYE OVERRIDE (delegated art director): the massing metric (value_entropy target ~1.8) penalizes dark/dramatic scenes (big dark field = concentrated histogram), but by eye v5's massing reads as clear big shapes — GOOD. The metric is miscalibrated here, not the design. Final map reads as intended: anchor + player-fit + dramatic readable light + cover rhythm.
- Phase-4 carry-forward: (a) promote P4 player-fit into preflight/SOP; (b) flag the massing metric limitation for recalibration.

---
## Phase 4 — MAINTAIN (regression + promotion)
- trigger: the correctness marathon (dogfood) changed build (smooth shading), material (glass refraction), render/camera (framing, eevee raytracing) before the design validation.
- regression: re-rendered canonical demo scenes P3/P6/P7. Metrics IDENTICAL to recorded (P3 focal 4.21→5.85; P6 contrast 0.043→0.173, symmetry 0.999→0.655; P7 symmetry 0.758→0.999). Deterministic, ZERO drift. All principles re-validate. Nothing pruned, nothing corrected.
- promoted into the build-by-default layer:
  - sops/05-tactical-design.md — P1–P7 as gated checklist (greybox→fit→hierarchy→light→sightlines→fairness→cliche→eye).
  - inspect.player_fit() — P4 player-fit as a code helper (tested: FAIL on narrow door, PASS on wide). Cheapest objective tactical check.
  - metrics.py docstrings — recorded the value_entropy (dark-scene) + symmetry (off-axis-light) limitations so they aren't chased.
  - SKILL.md — routes to SOP 05 + surfaces DESIGN_PRINCIPLES/CLICHES/CONFLICTS + the CC BY-NC-SA flag.
- removed/flagged: nothing removed. FLAGGED metric limitations (massing/symmetry) as judgment-not-metric calls; no principle depends on the broken part of a metric.
- art-director self-review: ACCEPT. Mode complete.
