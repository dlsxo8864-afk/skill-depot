"""Bring-your-own narrator: a user's own command line that writes one WAV per line."""

import json
import struct
import subprocess
import wave
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from bsa import proc as _proc
from bsa import settings
from bsa.narrate import contract, install
from bsa.narrate import run as nrun
from bsa.narrate.contract import NarrationError
from bsa.narrate.custom import generate, log_notes, normalise_take
from bsa.short import Line, Short


@pytest.fixture(autouse=True)
def _uv_on_path(monkeypatch):
    monkeypatch.setattr(install, "uv_path", lambda: Path("uv"))


def tone(seconds: float, rate: int, amp: float = 0.3) -> np.ndarray:
    t = np.arange(int(rate * seconds)) / rate
    return amp * np.sin(2 * np.pi * 220 * t)


def write_pcm(path: Path, samples: np.ndarray, rate: int, channels: int = 1, bits: int = 16) -> None:
    """A WAV by hand: 16/24-bit PCM, or 32-bit float (format tag 3) which the stdlib wave module cannot write."""
    path.parent.mkdir(parents=True, exist_ok=True)
    x = np.repeat(samples[:, None], channels, axis=1) if channels > 1 else samples[:, None]
    if bits == 16:
        data, tag = (x * 32767).astype("<i2").tobytes(), 1
    elif bits == 24:
        ints = (x * 8388607).astype("<i4")
        data, tag = b"".join(ints.tobytes()[i : i + 3] for i in range(0, ints.size * 4, 4)), 1
    else:
        data, tag, bits = x.astype("<f4").tobytes(), 3, 32
    block = channels * bits // 8
    fmt = struct.pack("<HHIIHH", tag, channels, rate, rate * block, block, bits)
    body = b"WAVE" + b"fmt " + struct.pack("<I", len(fmt)) + fmt + b"data" + struct.pack("<I", len(data)) + data
    path.write_bytes(b"RIFF" + struct.pack("<I", len(body)) + body)


def lines(*ids):
    return [Line(id=i, text=f"Text for {i}.", shot="s1") for i in ids]


def fake_run(calls, rate=48000, skip=()):
    """Stands in for subprocess.run: records the args and writes <out>/<id>.wav for each line in --lines."""

    def run(cmd, **kw):
        lines_file = Path(cmd[cmd.index("--lines") + 1])
        out = Path(cmd[cmd.index("--out") + 1])
        items = json.loads(lines_file.read_text(encoding="utf-8"))
        calls.append((cmd, kw, [i["id"] for i in items]))
        for item in items:
            if item["id"] not in skip:
                write_pcm(out / f"{item['id']}.wav", tone(1.0, rate), rate)
        return subprocess.CompletedProcess(cmd, 0, "", "")

    return run


def test_placeholders_filled_per_argument_without_a_shell(tmp_path):
    out = tmp_path / "my folder" / "vo"
    calls = []
    cmd = '"tts tool" speak --lines {lines} --out {out} --seed {seed} --voice {voice} --speed {speed}'
    d = generate(cmd, lines("l01"), out, seed=9, voice="deep one", speed=1.2, run=fake_run(calls))
    args, kw, _ = calls[0]
    assert isinstance(args, list) and not kw.get("shell")
    assert args[0] == "tts tool"
    assert args[args.index("--out") + 1] == str(out) and " " in str(out)
    assert args[args.index("--lines") + 1] == str(out / "lines.json")
    assert args[args.index("--seed") + 1] == "9"
    assert args[args.index("--voice") + 1] == "deep one"
    assert args[args.index("--speed") + 1] == "1.2"
    assert "timeout" not in kw
    assert d == {"l01": 1.0}


def test_takes_in_other_formats_are_normalised_by_generate(tmp_path):
    d = generate("tts --lines {lines} --out {out}", lines("l01"), tmp_path, run=fake_run([], rate=24000))
    assert contract.check_take(tmp_path / "l01.wav") == [] and abs(d["l01"] - 1.0) < 1 / 30


def test_tools_durations_json_is_ignored(tmp_path):
    (tmp_path / "durations.json").write_text('{"l01": 99}', encoding="utf-8")
    d = generate("tts --lines {lines} --out {out}", lines("l01"), tmp_path, run=fake_run([]))
    assert d == {"l01": 1.0}
    assert contract.read_durations(tmp_path, ["l01"]) == {"l01": 1.0}


def test_voice_placeholder_without_a_voice_is_an_error(tmp_path):
    with pytest.raises(NarrationError, match="voice"):
        generate("tts --voice {voice} --lines {lines} --out {out}", lines("l01"), tmp_path, run=fake_run([]))


def test_command_not_found(tmp_path):
    def run(cmd, **kw):
        raise FileNotFoundError(cmd[0])

    with pytest.raises(NarrationError, match=r"nope.*was not found.*put the program that runs it first, e\.g\. python script\.py"):
        generate("nope --lines {lines} --out {out}", lines("l01"), tmp_path, run=run)


def test_nonzero_exit_reports_code_and_last_stderr_line(tmp_path):
    def run(cmd, **kw):
        return subprocess.CompletedProcess(cmd, 3, "", "warming up\nCUDA exploded\n")

    with pytest.raises(NarrationError, match=r"exit 3.*CUDA exploded"):
        generate("tts --lines {lines} --out {out}", lines("l01"), tmp_path, run=run)
    assert "CUDA exploded" in (tmp_path / "narrator.log").read_text(encoding="utf-8")  # kept even on failure


def test_tool_output_is_logged_and_its_warnings_surfaced(tmp_path):
    calls = []
    inner = fake_run(calls)

    def run(cmd, **kw):
        inner(cmd, **kw)
        return subprocess.CompletedProcess(cmd, 0, "[take] paragraph 1 ok\n",
                                           "[take] Fallback to line-by-line for p2\nWARNING: slow\nall good\n")

    generate("tts --lines {lines} --out {out}", lines("l01"), tmp_path, run=run)
    generate("tts --lines {lines} --out {out}", lines("l02"), tmp_path, run=run)  # appended, not replaced
    log = (tmp_path / "narrator.log").read_text(encoding="utf-8")
    assert log.count("paragraph 1 ok") == 2 and "l01" in log and "l02" in log
    notes = log_notes(tmp_path)
    assert notes == ["[take] Fallback to line-by-line for p2", "WARNING: slow"]  # each once, in order
    assert log_notes(tmp_path / "nothing-here") == []


def test_cli_narrate_keeps_the_voice_tools_log(tmp_path):
    import os
    import shutil
    import sys

    root = Path(__file__).resolve().parent.parent
    home, ws = tmp_path / "home", tmp_path / "ws"
    home.mkdir()
    tool = tmp_path / "tool.py"
    tool.write_text(
        "import json, math, struct, sys, wave\n"
        "a = sys.argv\n"
        "items = json.load(open(a[a.index('--lines') + 1], encoding='utf-8'))\n"
        "out = a[a.index('--out') + 1]\n"
        "print('[take] warning: fell back to line-by-line', file=sys.stderr)\n"
        "for it in items:\n"
        "    w = wave.open(out + '/' + it['id'] + '.wav', 'wb'); w.setnchannels(1); w.setsampwidth(2)\n"
        "    w.setframerate(48000)\n"
        "    w.writeframes(b''.join(struct.pack('<h', int(9000 * math.sin(i / 20))) for i in range(48000)))\n"
        "    w.close()\n", encoding="utf-8")  # fmt: skip
    env = {**os.environ, "BSA_HOME": str(home)}

    def cli(*args):
        proc = _proc.run([sys.executable, str(root / "bsa_cli.py"), *map(str, args)], capture_output=True,
                              text=True, env=env, check=False)  # fmt: skip
        assert proc.returncode == 0, proc.stdout + proc.stderr
        return json.loads(proc.stdout)

    cli("settings", "set", "workspace", ws)
    short = Path(cli("new-short", "Pendulum")["short"])
    shutil.copyfile(root / "tests" / "e2e" / "pendulum" / "source" / "short.json", short / "source" / "short.json")
    cli("state", short, "done", "interview")
    for stage in ("story", "storyboard"):
        cli("page", "decide", short, stage, "approve", "--by", "chat")
    cli("settings", "set", "narrator.provider", "custom")
    cli("settings", "set", "narrator.command", f'"{sys.executable}" "{tool}" --lines {{lines}} --out {{out}}')
    cli("settings", "set", "narrator.verify", "false")
    out = cli("narrate", short)
    assert out["status"] == "ok", out
    assert Path(out["voice_log"]) == short / "audio" / "vo" / "narrator.log"
    assert out["voice_log_notes"] == ["[take] warning: fell back to line-by-line"]


def test_missing_wav_names_the_line(tmp_path):
    with pytest.raises(NarrationError, match="l02"):
        generate("tts --lines {lines} --out {out}", lines("l01", "l02"), tmp_path, run=fake_run([], skip={"l02"}))


@pytest.mark.parametrize(
    ("rate", "channels", "bits"), [(24000, 2, 16), (44100, 1, 32), (48000, 1, 24), (22050, 2, 24), (48000, 1, 16)]
)
def test_normalise_take_to_contract(tmp_path, rate, channels, bits):
    p = tmp_path / "a.wav"
    write_pcm(p, tone(1.5, rate), rate, channels, bits)
    normalise_take(p)
    assert contract.check_take(p) == []
    with wave.open(str(p), "rb") as w:
        assert (w.getframerate(), w.getnchannels(), w.getsampwidth()) == (48000, 1, 2)
        assert abs(w.getnframes() / 48000 - 1.5) <= 1 / 30
        peak = np.abs(np.frombuffer(w.readframes(w.getnframes()), dtype="<i2")).max()
    assert 0.25 * 32767 < peak < 0.35 * 32767  # level preserved


def test_normalise_take_rejects_mp3(tmp_path):
    p = tmp_path / "a.wav"
    p.write_bytes(b"ID3\x03\x00\x00\x00\x00\x00\x00" + b"\xff\xfb\x90\x00" * 50)
    with pytest.raises(NarrationError, match="adapter"):
        normalise_take(p)


def test_narrate_missing_wav_is_captions_only_once_takes_kept(tmp_path):
    short = Short(slug="t", title="T", length_s=10, lines=lines("l01", "l02"))
    cfg = {"narrator": {"provider": "custom", "command": "tts --lines {lines} --out {out}", "verify": False}}
    mod = SimpleNamespace(generate=lambda *a, **k: generate(*a, **k, run=fake_run([], skip={"l02"})))
    res = nrun.narrate(tmp_path, short, cfg, custom=mod)
    assert res.status == "captions-only" and res.durations is None
    assert res.message.count("captions only") == 1 and "l02" in res.message
    assert (tmp_path / "audio" / "vo" / "l01.wav").is_file()


def test_regeneration_runs_only_bad_lines_with_seeds_8_then_9(tmp_path):
    short = Short(slug="t", title="T", length_s=10, lines=lines("l01", "l02"))
    cfg = {"narrator": {"provider": "custom", "command": "tts --lines {lines} --out {out} --seed {seed}"}}
    calls = []
    mod = SimpleNamespace(generate=lambda *a, **k: generate(*a, **k, run=fake_run(calls)))

    def verify(lns, out):
        return {x.id: 0.5 if x.id == "l02" else 0.0 for x in lns}

    res = nrun.narrate(tmp_path, short, cfg, custom=mod, local=SimpleNamespace(verify=verify))
    seen = [(c[2], c[0][c[0].index("--seed") + 1]) for c in calls]
    assert seen == [(["l01", "l02"], "7"), (["l02"], "8"), (["l02"], "9")]
    assert res.status == "ok" and "l02" in res.message


def test_resume_speaks_only_missing_lines(tmp_path):
    short = Short(slug="t", title="T", length_s=10, lines=lines("l01", "l02"))
    write_pcm(tmp_path / "audio" / "vo" / "l01.wav", tone(1.0, 48000), 48000)
    cfg = {"narrator": {"provider": "custom", "command": "tts --lines {lines} --out {out}", "verify": False}}
    calls = []
    mod = SimpleNamespace(generate=lambda *a, **k: generate(*a, **k, run=fake_run(calls)))
    res = nrun.narrate(tmp_path, short, cfg, custom=mod)
    assert [c[2] for c in calls] == [["l02"]] and res.status == "ok"


def test_changed_command_clears_takes(tmp_path):
    short = Short(slug="t", title="T", length_s=10, lines=lines("l01"))
    out = tmp_path / "vo"
    a = {"provider": "custom", "command": "toolA --out {out}"}
    nrun.clear_stale_takes(out, short, a)  # records the narrator
    write_pcm(out / "l01.wav", tone(1.0, 48000), 48000)
    assert nrun.clear_stale_takes(out, short, a) == []
    assert nrun.clear_stale_takes(out, short, {**a, "command": "toolB --out {out}"}) == ["l01"]


def test_split_command_keeps_quoted_paths():
    assert settings.split_command('"a b/c" x --o "d e"') == ["a b/c", "x", "--o", "d e"]


def test_tool_cannot_prompt_and_output_decodes_leniently(tmp_path):
    calls = []
    generate("tts --lines {lines} --out {out}", lines("l01"), tmp_path, run=fake_run(calls))
    kw = calls[0][1]
    assert kw["stdin"] == subprocess.DEVNULL and kw["errors"] == "replace"


def test_oserror_starting_the_command_is_plain(tmp_path):
    def run(cmd, **kw):
        raise OSError(193, "%1 is not a valid Win32 application")

    with pytest.raises(NarrationError, match=r"couldn't start voice\.py.*put the program that runs it first"):
        generate("voice.py --lines {lines} --out {out}", lines("l01"), tmp_path, run=run)


def test_impossible_wav_header_is_a_plain_error(tmp_path):
    p = tmp_path / "a.wav"
    write_pcm(p, tone(0.1, 48000), 48000)
    raw = bytearray(p.read_bytes())
    raw[34:36] = (0).to_bytes(2, "little")  # bits per sample = 0
    p.write_bytes(bytes(raw))
    with pytest.raises(NarrationError, match="not a WAV I can read"):
        normalise_take(p)


def test_float_wav_with_nan_and_inf_is_cleaned(tmp_path):
    p = tmp_path / "a.wav"
    x = tone(0.5, 48000)
    x[10], x[11], x[12] = np.nan, np.inf, -np.inf
    write_pcm(p, x, 48000, bits=32)
    normalise_take(p)
    with wave.open(str(p), "rb") as w:
        out = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2")
    assert (out[10], out[11], out[12]) == (0, 32767, -32767)


def test_resampling_keeps_the_head_and_adds_no_pre_echo(tmp_path):
    """FFT resampling is circular: a take loud up to its last sample must not wrap into its silent head, and the
    first 50 ms of the voice must keep their energy."""
    rate, n = 24000, 24000
    t = np.arange(n) / rate
    on, ramp = round(0.2 * rate), round(0.03 * rate)
    x = 0.5 * np.sin(2 * np.pi * 300 * (t - t[-1]) + np.pi / 2)  # loud (+0.5) on the very last sample
    x[:on] = 0.0
    x[on : on + ramp] *= 0.5 - 0.5 * np.cos(np.pi * np.arange(ramp) / ramp)  # a soft onset
    p = tmp_path / "a.wav"
    write_pcm(p, x, rate, bits=32)
    normalise_take(p)
    with wave.open(str(p), "rb") as w:
        assert w.getframerate() == 48000
        y = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(np.float64) / 32768.0
    head = np.abs(y[: round(0.15 * 48000)]).max()
    assert 20 * np.log10(max(head, 1e-9)) < -60, f"head peaks at {20 * np.log10(head):.1f} dBFS"

    def rms_db(v):
        return 10 * np.log10(np.mean(v**2))

    before = rms_db(x[on : on + round(0.05 * rate)])
    after = rms_db(y[round(0.2 * 48000) : round(0.25 * 48000)])
    assert abs(after - before) <= 1.0, (before, after)
    assert contract.leading_silence(p) == pytest.approx(0.2, abs=0.011)  # the wrap read as the voice starting at 0

def test_take_placeholder_is_the_take_id_or_empty(tmp_path):
    from bsa.narrate.custom import TAKE_PLACEHOLDER, takes_supported

    calls = []
    cmd = "tts --lines {lines} --out {out} --take {take}"
    generate(cmd, lines("t01"), tmp_path, run=fake_run(calls), take="t01")
    generate(cmd, lines("l01"), tmp_path, run=fake_run(calls))
    assert [c[0][c[0].index("--take") + 1] for c in calls] == ["t01", ""]
    assert TAKE_PLACEHOLDER == "{take}"
    assert takes_supported(cmd) and not takes_supported("tts --lines {lines} --out {out}") and not takes_supported("")
