"""Is each stage's output still current? The saved timeline, each scene's timeline stamp, each shot's rendered frames
(`.render.json`), the label anchors and the scene checks (`review/checks.json`) carry stamps; a stale one fails with
a plain message saying what to run.

Frames, anchors and checks are stamped per shot with the shot's content fingerprint (bsa.blender.fingerprint: a hash
of everything that shot renders), not with the .blend's save time, so a rebuild that changes one shot leaves every
other shot's frames, anchors and checks current. `blend/short.fingerprints.json` caches the fingerprints of one
saved .blend (by its size and time, the files it reads, and the Blender and render code it was made with) for the
commands that do not open it, with each fingerprint's parts (data per type, animation, code) so a refusal can say
what changed. Only what a stage really reads goes into its stamp: the post text, sound levels and settings never
make frames or checks stale. Pure: no bpy."""

from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path

from bsa.timeline import Span, Timeline, timeline_hash, to_json

TIMELINE_PROP = "bsa_timeline"  # custom property build.py sets on every scene it builds


class StaleError(Exception):
    """An output is from an older timing, build or engine; the message says what to run again."""


# --------------------------------------------------------------------------- timeline


def check_timeline(short_dir: Path, tl: Timeline, key: str = "SHORT") -> str:
    """The hash of source/timeline.json, which must equal the timeline recomputed from short.json and the takes
    (else build.py animated a different timing from the one shots, captions and narration now use). A refusal names
    the command with `key`, what the user types for this short (workspace.short_key)."""
    path = Path(short_dir) / "source" / "timeline.json"
    run = f"run CLI timeline {key}"
    if not path.is_file():
        raise StaleError(f"source/timeline.json is missing: {run}, then rebuild (source/build.py)")
    try:
        saved = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise StaleError(f"source/timeline.json is not valid JSON ({exc}): {run}, then rebuild") from exc
    if saved != json.loads(json.dumps(to_json(tl))):
        raise StaleError(f"timing changed: {run}, then rebuild (source/build.py)")
    return timeline_hash(saved)


def check_scene_stamp(scene_name: str, stamp, want: str) -> None:
    if stamp is None:
        raise StaleError(f"scene {scene_name!r} has no timeline stamp: rebuild with source/build.py (it must set "
                         f'scene["{TIMELINE_PROP}"] = timeline_hash(tl), see 06-build.md)')  # fmt: skip
    if str(stamp) != want:
        raise StaleError(f"the .blend was built for another timing (scene {scene_name!r}): rebuild with "
                         "source/build.py")  # fmt: skip


# --------------------------------------------------------------------------- the scene file

BUILD_CHANGED = "build.py changed since the scene was built: rebuild"


def _local_module(base: Path, name: str, src: Path) -> Path | None:
    """The file module `name` ("p.q") is under `base`: base/p/q.py or base/p/q/__init__.py, if it exists inside
    `src` (stdlib, numpy, bpy and bsa never live there)."""
    parts = [p for p in name.split(".") if p]
    if not parts:
        return None
    for cand in (base.joinpath(*parts[:-1], parts[-1] + ".py"), base.joinpath(*parts, "__init__.py")):
        cand = Path(os.path.normpath(cand))
        try:
            inside = cand.resolve().is_relative_to(src.resolve())
        except OSError:
            continue
        if inside and cand.is_file():
            return cand
    return None


def _prefixes(name: str) -> list[str]:
    parts = name.split(".")
    return [".".join(parts[: i + 1]) for i in range(len(parts))]


def _imports(path: Path, src: Path) -> list[Path]:
    """The local files `path` imports: `import a.b` means a and a.b, `from a.b import c` means a, a.b and a.b.c (c
    may be a module); relative imports resolve against the file's own folder. A file that can't be read or parsed
    imports nothing (it still counts by its time)."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (SyntaxError, OSError, ValueError):  # ValueError: not UTF-8, or a null byte
        return []
    wanted: list[tuple[Path, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            wanted += [(src, n) for alias in node.names for n in _prefixes(alias.name)]
        elif isinstance(node, ast.ImportFrom):
            base = src
            if node.level:  # from . import c / from ..m import c: against the importing file's folder
                base = path.parent
                for _ in range(node.level - 1):
                    base = base.parent
            module = node.module or ""
            wanted += [(base, n) for n in (_prefixes(module) if module else [])]
            wanted += [(base, f"{module}.{alias.name}" if module else alias.name)
                       for alias in node.names if alias.name != "*"]  # fmt: skip
    found = (_local_module(base, name, src) for base, name in wanted)
    return [f for f in found if f is not None]


def build_inputs(short_dir: Path) -> list[Path]:
    """source/build.py and every local script it imports, followed through their imports (a visited set ends
    cycles): the files whose edits make the scene file out of date. build.py first, the rest sorted; [] without
    build.py."""
    src = Path(short_dir) / "source"
    build = src / "build.py"
    if not build.is_file():
        return []
    seen = {build.resolve()}
    out: list[Path] = []
    todo = [build]
    while todo:
        for f in _imports(todo.pop(), src):
            key = f.resolve()
            if key not in seen:
                seen.add(key)
                out.append(f)
                todo.append(f)
    return [build, *sorted(out)]


def stale_build_file(short_dir: Path) -> Path | None:
    """The first of build_inputs edited after blend/short.blend was saved (None when none was, or there is no .blend
    or build.py): the scenes are not what build.py now makes."""
    blend = Path(short_dir) / "blend" / "short.blend"
    try:
        saved = blend.stat().st_mtime_ns
    except OSError:
        return None
    for f in build_inputs(short_dir):
        try:
            if f.stat().st_mtime_ns > saved:
                return f
        except OSError:
            continue
    return None


def build_changed(short_dir: Path) -> bool:
    """build.py, or a script it imports, was edited after blend/short.blend was saved."""
    return stale_build_file(short_dir) is not None


def build_changed_message(short_dir: Path, stale: Path | None = None) -> str:
    """What changed since the scene was built: BUILD_CHANGED for build.py itself, else the imported script. `stale`:
    the file stale_build_file already found (else it is looked for again)."""
    f = stale if stale is not None else stale_build_file(short_dir)
    src = Path(short_dir) / "source"
    if f is None or f == src / "build.py":
        return BUILD_CHANGED
    rel = Path(os.path.relpath(f, src)).as_posix()
    return f"source/{rel} (imported by build.py) changed since the scene was built: rebuild"


def require_current_build(short_dir: Path, command: str) -> None:
    """The final render and edit refuse a scene file older than build.py or a script it imports; `command` names
    which ("the final edit")."""
    if build_changed(short_dir):
        raise StaleError(f"{build_changed_message(short_dir)} (run source/build.py) before {command}")


# --------------------------------------------------------------------------- shot fingerprints

FINGERPRINT_VERSION = 1  # bump when what goes into a fingerprint changes (bsa.blender.fingerprint)
FINGERPRINTS = "short.fingerprints.json"


def blend_stat(short_dir: Path) -> list | None:
    """[size, mtime_ns] of blend/short.blend, or None when there is none."""
    return _file_stat(Path(short_dir) / "blend" / "short.blend")


_blend_stat = blend_stat  # the old name


def _file_stat(path) -> list | None:
    try:
        st = Path(path).stat()
    except OSError:
        return None
    return [st.st_size, st.st_mtime_ns]


_RENDER_CODE = Path(__file__).resolve().parent / "blender" / "scene.py"  # goes into every fingerprint


def fingerprint_code(blender: str | None) -> str:
    """What a fingerprint depends on besides the .blend: FINGERPRINT_VERSION, the Blender version and the render
    presets' code (bsa/blender/scene.py), as bsa.blender.fingerprint hashes them. A cache made under another one
    would differ from a fresh fingerprint, so it is not used."""
    try:
        code = hashlib.sha256(_RENDER_CODE.read_bytes()).hexdigest()[:16]
    except OSError:
        code = "?"
    return f"{FINGERPRINT_VERSION}:{blender}:{code}"


def save_fingerprints(short_dir: Path, tl_hash: str, shots: dict, files: dict | None = None, *, code: str | None = None,
                      parts: dict | None = None, objects: dict | None = None) -> None:  # fmt: skip
    """Cache the fingerprints of blend/short.blend as it is on disk now, for this timing (and `code`,
    fingerprint_code). `parts` ({shot id: {part: hash}}) records what each fingerprint is made of, so a later
    refusal can say which part changed; `objects` ({shot id: {"objects": {name: key}, "rest": key}}) a key per
    object of the shot and one for the rest of it (bsa.blender.fingerprint)."""
    blend = blend_stat(short_dir)
    if blend is None:
        return
    path = Path(short_dir) / "blend" / FINGERPRINTS
    data = {"version": FINGERPRINT_VERSION, "blend": blend, "timeline": tl_hash, "shots": shots,
            "files": files or {}, **({"code": code} if code else {}), **({"parts": parts} if parts else {}),
            **({"objects": objects} if objects is not None else {})}  # fmt: skip
    path.write_text(json.dumps(data, indent=1) + "\n", encoding="utf-8")


def _read_cache(short_dir: Path) -> dict | None:
    try:
        data = json.loads((Path(short_dir) / "blend" / FINGERPRINTS).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def load_fingerprints(short_dir: Path, tl_hash: str, code: str | None = None) -> dict | None:
    """The cached fingerprints ({shot id: fingerprint}) when they are of this very .blend, timing, files and (when
    both say) fingerprint code; else None (compute them in Blender)."""
    data = _read_cache(short_dir)
    if data is None or data.get("version") != FINGERPRINT_VERSION or data.get("timeline") != tl_hash:
        return None
    if data.get("blend") != blend_stat(short_dir) or not isinstance(data.get("shots"), dict):
        return None
    if code is not None and data.get("code") not in (None, code):  # a cache from before the code was recorded holds
        return None
    for path, stat in (data.get("files") or {}).items():
        if _file_stat(path) != stat:
            return None
    return data["shots"]


def load_fingerprint_parts(short_dir: Path, fingerprints: dict | None) -> dict:
    """{shot id: {part: hash}} from the cache, for the shots whose cached fingerprint is the one given; {} for a
    cache from before parts were recorded."""
    data = _read_cache(short_dir) or {}
    shots, parts = data.get("shots"), data.get("parts")
    if not isinstance(shots, dict) or not isinstance(parts, dict):
        return {}
    return {sid: parts[sid] for sid, fp in (fingerprints or {}).items()
            if fp is not None and shots.get(sid) == fp and isinstance(parts.get(sid), dict)}  # fmt: skip


def has_object_keys(short_dir: Path) -> bool:
    """The fingerprint cache records the per-object keys (a cache from before them still loads, but gives the checks
    no object to reuse: compute it again once)."""
    return isinstance((_read_cache(short_dir) or {}).get("objects"), dict)


def load_fingerprint_objects(short_dir: Path, fingerprints: dict | None) -> dict:
    """{shot id: {"objects": {name: key}, "rest": key}} from the cache, for the shots whose cached fingerprint is the
    one given; {} for a cache from before the object keys were recorded."""
    data = _read_cache(short_dir) or {}
    shots, objects = data.get("shots"), data.get("objects")
    if not isinstance(shots, dict) or not isinstance(objects, dict):
        return {}
    return {sid: objects[sid] for sid, fp in (fingerprints or {}).items()
            if fp is not None and shots.get(sid) == fp and isinstance(objects.get(sid), dict)}  # fmt: skip


_PART_WORDS = {"Object": "objects", "Camera": "camera", "Material": "materials", "Mesh": "meshes",
               "World": "world", "Scene": "scene settings", "Image": "images", "VectorFont": "fonts",
               "TextCurve": "text", "Curve": "curves", "Collection": "collections", "Texture": "textures",
               "ParticleSettings": "particles", "Armature": "armatures", "Key": "shape keys",
               "animation": "animation", "drivers": "drivers", "tags": "tags"}  # fmt: skip
RENDER_CODE_CHANGED = "the plugin's render code or Blender version changed"


def changed_parts(old, new) -> list[str] | None:
    """The parts of a fingerprint that differ between two {part: hash} records; None when either is missing."""
    if not isinstance(old, dict) or not isinstance(new, dict) or not old or not new:
        return None
    return sorted(k for k in set(old) | set(new) if old.get(k) != new.get(k))


def _part_word(part: str) -> str:
    kind = part.split(":", 1)[-1]
    if kind in _PART_WORDS:
        return _PART_WORDS[kind]
    if kind.endswith("Light"):
        return "lights"
    if kind.endswith("NodeTree"):
        return "node groups"
    return kind.lower()


def describe_change(shot_id: str, parts: list[str] | None) -> str:
    """"shot s01's camera/objects changed" from changed_parts; a plain "scene content" when unknown."""
    if parts and "code" in parts:
        return f"{RENDER_CODE_CHANGED} (shot {shot_id})"
    words = sorted({_part_word(p) for p in parts or ()})
    if not words:
        return f"shot {shot_id}'s scene content changed"
    return f"shot {shot_id}'s {'/'.join(words)} changed"


# --------------------------------------------------------------------------- label anchors

ANCHORS = "anchors.json"
_ANCHORS_AGAIN = "run BLENDER anchors SHORT"


def anchors_stamp(fingerprints: dict | None, tl_hash: str) -> dict:
    """{"timeline", "shots": {shot id: fingerprint}}: a shot's anchors stay current while its fingerprint does."""
    return {"timeline": tl_hash, "shots": dict(fingerprints or {})}


def _anchors_current(stamp, fingerprints: dict | None, tl_hash: str, shots) -> bool:
    if not isinstance(stamp, dict) or stamp.get("timeline") != tl_hash or not isinstance(stamp.get("shots"), dict):
        return False
    return all(stamp["shots"].get(s) == (fingerprints or {}).get(s) for s in shots)


def read_anchors(short_dir: Path) -> dict | None:
    try:
        data = json.loads((Path(short_dir) / "source" / ANCHORS).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def reusable_anchors(short_dir: Path, fingerprints: dict | None, tl_hash: str) -> dict:
    """{"shots": {shot: {...}}, "heroes": {shot: {...}}} from the existing anchors.json for shots that are unchanged
    (same timing and fingerprint): the anchors are projected again only for the others."""
    data = read_anchors(short_dir) or {}
    out: dict = {"shots": {}, "heroes": {}}
    for key in ("shots", "heroes"):
        entries = data.get(key)
        for shot, entry in entries.items() if isinstance(entries, dict) else ():
            if _anchors_current(data.get("stamp"), fingerprints, tl_hash, [shot]):
                out[key][shot] = entry
    return out


def _read_anchors(short_dir: Path, fingerprints: dict | None, tl_hash: str, shots) -> dict:
    data = read_anchors(short_dir)
    if data is None:
        raise StaleError(f"labels placed near objects need source/{ANCHORS}: {_ANCHORS_AGAIN} (render runs it too)")
    if not _anchors_current(data.get("stamp"), fingerprints, tl_hash, shots):
        raise StaleError(f"source/{ANCHORS} is from an older build or timing: {_ANCHORS_AGAIN}")
    return data


def load_hero_boxes(short_dir: Path, fingerprints: dict | None, tl_hash: str, shot: str) -> dict:
    """source/anchors.json's "heroes" ({shot: {"f0", "boxes": {object: [[x0, y0, x1, y1] or None, ...]}}}, the last
    shot's heroes on screen), which must be from this timing and `shot`'s current fingerprint; {} when it holds none
    (or not a mapping)."""
    heroes = _read_anchors(short_dir, fingerprints, tl_hash, [shot]).get("heroes")
    return heroes if isinstance(heroes, dict) else {}


def load_anchors(short_dir: Path, fingerprints: dict | None, tl_hash: str, need=()) -> dict:
    """source/anchors.json's shots ({shot: {anchor key: {"f0", "points"}}}), which must be from this timing and each
    needed shot's current fingerprint, and hold every (shot id, label text, anchor key) in `need` (the key is the
    object's name for a label without "at": bsa.short.label_anchor)."""
    shots = _read_anchors(short_dir, fingerprints, tl_hash, sorted({s for s, _, _ in need})).get("shots") or {}
    for shot_id, text, name in need:
        if name not in (shots.get(shot_id) or {}):
            raise StaleError(f"no anchors for label {text!r} near {name!r} in shot {shot_id}: {_ANCHORS_AGAIN}")
    return shots


# --------------------------------------------------------------------------- rendered frames


_STAMP_KEYS = ("f0", "f1", "engine", "preset", "fingerprint")  # what decides whether frames are current


def frames_stamp(span: Span, engine: str | None, fingerprint: str | None, preset: str | None = None,
                 parts: dict | None = None) -> dict:  # fmt: skip
    """What a shot's frames were rendered from: its frame range, the engine, the preset and its fingerprint (and,
    as information only, the fingerprint's parts: a later refusal names the part that changed)."""
    stamp = {"f0": span.f0, "f1": span.f1, "engine": engine, "preset": preset, "fingerprint": fingerprint}
    return {**stamp, "parts": parts} if parts else stamp


def read_frames_stamp(folder: Path) -> dict | None:
    try:
        had = json.loads((Path(folder) / ".render.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return had if isinstance(had, dict) else None


def _core(stamp: dict | None) -> dict | None:
    return {k: v for k, v in stamp.items() if k not in ("patched", "parts")} if isinstance(stamp, dict) else None


OLD_FRAMES = "rendered by an older plugin version, before per-shot fingerprints"


def frames_reason(had: dict | None, stamp: dict) -> str | None:
    """Why frames stamped `had` can't be kept for `stamp` ("new range", "engine changed", "fingerprint changed"...),
    or None when they can."""
    had, stamp = _core(had), _core(stamp)
    if had == stamp:
        return None
    if had is None:
        return "not rendered yet"
    if (had.get("f0"), had.get("f1")) != (stamp.get("f0"), stamp.get("f1")):
        return "new range"
    if had.get("engine") != stamp.get("engine"):
        return "engine changed"
    if not had.get("fingerprint"):
        return OLD_FRAMES  # before the preset check: stamps that old have no preset either
    if had.get("preset") != stamp.get("preset"):
        return "preset changed"
    return "fingerprint changed"


def prepare_frames(folder: Path, stamp: dict) -> str | None:
    """Keep frames from an earlier (or interrupted) render of the same shot content and range; clear anything else.
    Returns why the frames were cleared, or None when they were kept."""
    folder = Path(folder)
    had = read_frames_stamp(folder)
    reason = frames_reason(had, stamp)
    if reason is not None:
        for png in folder.glob("*.png"):
            png.unlink()
        folder.mkdir(parents=True, exist_ok=True)
        (folder / ".render.json").write_text(json.dumps(stamp), encoding="utf-8")
    elif stamp.get("parts") and had.get("parts") != stamp["parts"]:  # kept: record the parts it now has
        keep = {"patched": had["patched"]} if had.get("patched") else {}
        (folder / ".render.json").write_text(json.dumps({**stamp, **keep}), encoding="utf-8")
    return reason


def parse_frames(spec: str) -> list[int]:
    """'120-140,200' -> [120, ..., 140, 200]."""
    out: set[int] = set()
    for part in str(spec).replace(" ", "").split(","):
        if not part:
            continue
        lo, sep, hi = part.partition("-")
        try:
            a = int(lo)
            b = int(hi) if sep else a
        except ValueError:
            raise ValueError(f"--frames {spec!r}: use frame numbers and ranges, e.g. 120-140,200") from None
        if b < a:
            raise ValueError(f"--frames {spec!r}: range {part} runs backwards")
        out.update(range(a, b + 1))
    if not out:
        raise ValueError("--frames is empty: give frame numbers or ranges, e.g. 120-140,200")
    return sorted(out)


def frames_spec(frames) -> str:
    """[120, 121, 122, 200] -> '120-122,200'."""
    frames = sorted(set(frames))
    parts, i = [], 0
    while i < len(frames):
        j = i
        while j + 1 < len(frames) and frames[j + 1] == frames[j] + 1:
            j += 1
        parts.append(str(frames[i]) if i == j else f"{frames[i]}-{frames[j]}")
        i = j + 1
    return ",".join(parts)


def redo_frames(folder: Path, span: Span, stamp: dict, frames) -> dict:
    """Delete these frames of one shot so the render makes them again; the shot's other frames stay. The frames on
    disk must be of this range, engine and preset. When only the shot's fingerprint changed (the scene was edited
    since), the other frames stay from the earlier build: the stamp takes the new fingerprint and records the patch
    under "patched" (the caller warns). Returns {"frames": [...], "mixed": bool}."""
    folder = Path(folder)
    bad = [f for f in frames if not span.f0 <= f <= span.f1]
    if bad:
        raise StaleError(f"--frames {frames_spec(bad)} are outside shot {span.id} (frames {span.f0}-{span.f1})")
    had = read_frames_stamp(folder)
    reason = frames_reason(had, stamp)
    if reason not in (None, "fingerprint changed", OLD_FRAMES):
        raise StaleError(f"shot {span.id}'s frames can't be patched ({reason}): render the whole shot "
                         f"(BLENDER render SHORT --preset {stamp.get('preset')} --shot {span.id})")  # fmt: skip
    for f in frames:
        (folder / f"{f:04d}.png").unlink(missing_ok=True)
    patched = (had or {}).get("patched")
    mixed = reason is not None or bool(patched)
    new = dict(stamp)
    if mixed:
        old = patched if isinstance(patched, dict) else {"from": (had or {}).get("fingerprint"), "frames": []}
        new["patched"] = {"from": old.get("from"), "frames": sorted(set(old.get("frames") or []) | set(frames))}
    (folder / ".render.json").write_text(json.dumps(new), encoding="utf-8")
    return {"frames": sorted(frames), "mixed": mixed}


def rendered_frames(folder: Path, span: Span, engine: str | None, fingerprint: str | None, preset: str,
                    parts: dict | None = None) -> list[Path]:  # fmt: skip
    """Exactly frames span.f0..span.f1 of one shot, rendered for this timing, engine and shot content; never
    padded. A None fingerprint (no .blend to fingerprint) skips that part. `parts` (the fingerprint's parts) lets a
    refusal name what changed."""
    folder = Path(folder)
    again = f"run BLENDER render SHORT --preset {preset} again"
    raw = read_frames_stamp(folder)
    had = _core(raw)
    if had is None:
        raise StaleError(f"no {preset} frames for shot {span.id}: run BLENDER render SHORT --preset {preset} first")
    if (had.get("f0"), had.get("f1")) != (span.f0, span.f1):
        raise StaleError(f"shot {span.id}'s {preset} frames are from an older timing (frames {had.get('f0')}-"
                         f"{had.get('f1')}, now {span.f0}-{span.f1}): {again}")  # fmt: skip
    if had.get("engine") != engine:
        raise StaleError(f"shot {span.id}'s {preset} frames were rendered with another engine "
                         f"({had.get('engine')}, now {engine}): {again}")  # fmt: skip
    if fingerprint is not None and not had.get("fingerprint"):
        raise StaleError(f"shot {span.id}'s {preset} frames were {OLD_FRAMES} (nothing in the scene needs to have "
                         f"changed): {again} (once; after that only changed shots render again)")  # fmt: skip
    if fingerprint is not None and had.get("fingerprint") != fingerprint:
        which = changed_parts((raw or {}).get("parts"), parts)
        what = (describe_change(span.id, which) if which is not None
                else f"shot {span.id}'s scene content or animation changed")  # fmt: skip
        raise StaleError(f"{what} since its {preset} frames were rendered (fingerprint changed): {again} (only "
                         "changed shots render again)")  # fmt: skip
    want = [folder / f"{f:04d}.png" for f in range(span.f0, span.f1 + 1)]
    bad = [p.name for p in want if not p.is_file() or p.stat().st_size == 0]
    if bad:
        raise StaleError(f"shot {span.id} is missing {preset} frames or has empty ones ({', '.join(bad[:5])}"
                         f"{', ...' if len(bad) > 5 else ''}): {again} (it resumes)")  # fmt: skip
    extra = sorted(p.name for p in set(folder.glob("*.png")) - set(want))
    if extra:
        raise StaleError(f"shot {span.id} has {preset} frames outside its range ({', '.join(extra[:5])}): {again}")
    return want


# --------------------------------------------------------------------------- scene checks

CHECKS_VERSION = 1  # bump when the scene checks change what they find: every shot is checked again once
_BSA = Path(__file__).resolve().parent
# the code the scene checks' findings come from: the checks, the viewer checks (framing, covered) and the edit's text
# boxes they measure, the framing band they measure against, the framing_call notes (findings, camera), the hard-rule
# words (rules) and the object tags (bake: hero, overlay, may-exit)
# short.py: the near labels' anchors (label_at, label_anchor); kitlayout.py: a kit's card boxes (covered)
_CHECKS_CODE = (_BSA / "blender" / "checks.py", _BSA / "viewer.py", _BSA / "overlays.py", _BSA / "layout.py",
                _BSA / "findings.py", _BSA / "blender" / "camera.py", _BSA / "rules.py",
                _BSA / "blender" / "bake.py", _BSA / "pops.py", _BSA / "blender" / "anchors.py",
                _BSA / "short.py", _BSA / "kitlayout.py")  # fmt: skip


def checks_code() -> str:
    """CHECKS_VERSION plus a hash of the checks' code (_CHECKS_CODE, line endings ignored: a CRLF checkout is the
    same code): any change to it means a full re-check."""
    h = hashlib.sha256()
    for path in _CHECKS_CODE:
        try:
            raw = path.read_bytes()
        except OSError:
            return f"{CHECKS_VERSION}:?"
        h.update(raw.replace(b"\r\n", b"\n") + b"\0")
    return f"{CHECKS_VERSION}:{h.hexdigest()[:16]}"


def _code_current(code) -> bool:
    return code == checks_code()


# the short.json shot fields the scene checks read (bsa.blender.checks: the badge and labels cover the subject or not)
CHECKED_FIELDS = ("scene", "labels", "badge", "wide")


def shot_check_key(fingerprint: str | None, span: Span, shot: dict) -> str:
    """The key stamps used before the check inputs were recorded: a hash of the fingerprint, the frames and the
    whole short.json entry. Still accepted for checks.json files written then (shot_check_inputs "legacy")."""
    text = json.dumps([fingerprint, span.f0, span.f1, shot], sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:32]


def shot_check_inputs(fingerprint: str | None, span: Span, shot: dict, shot_ids=(), parts: dict | None = None,
                      rules: list | None = None, caption_size: int | None = None,
                      objects: dict | None = None) -> dict:  # fmt: skip
    """What one shot's scene checks depend on, and nothing else: its content (fingerprint), its frames, the fields
    of its short.json entry the checks read (CHECKED_FIELDS: not its title, picture or still_at), the shot
    ids (hero tags name them) and, only when a hard rule scans scene names, those rules (bsa.rules.scene_key). Post
    text, sound levels and other settings are not in it. `parts` is information (which part of the fingerprint
    changed), not part of the key, except its "tags" part: the objects' tags (contact, hero...) change what the checks
    find but are not in the fingerprint, since they change no pixel. `caption_size` (bsa.overlays.caption_size: the
    short's style.caption.size) sizes the caption box the covered check measures, so it is in the key too.
    `objects` ({"objects": {name: key}, "rest": key}, load_fingerprint_objects) is information too, recorded under
    "objects" and "rest": which objects of the shot changed."""
    out = {"fingerprint": fingerprint, "frames": [span.f0, span.f1],
           "entry": {k: shot.get(k) for k in CHECKED_FIELDS}, "shot_ids": sorted(shot_ids),
           "parts": dict(parts or {}), "legacy": shot_check_key(fingerprint, span, shot)}  # fmt: skip
    if rules:
        out["rules"] = rules
    if caption_size is not None:
        out["caption_size"] = caption_size
    if parts and parts.get("tags") is not None:
        out["tags"] = parts["tags"]
    if objects:
        out["objects"] = dict(objects.get("objects") or {})
        out["rest"] = objects.get("rest")
    return out


def _input_key(inputs: dict) -> str:
    core = {k: v for k, v in inputs.items() if k not in ("parts", "legacy", "objects", "rest")}
    text = json.dumps(core, sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:32]


def _key(now) -> str:
    return _input_key(now) if isinstance(now, dict) else now


def checks_stamp(tl_hash: str, shots: dict, every: int | None = None) -> dict:
    """{"code", "timeline", "every", "shots": {shot id: key}, "inputs": {shot id: shot_check_inputs}}; `shots`
    maps each shot id to its shot_check_inputs (or a plain key)."""
    inputs = {sid: dict(now) for sid, now in shots.items() if isinstance(now, dict)}
    return {"code": checks_code(), "timeline": tl_hash, "every": every,
            "shots": {sid: _key(now) for sid, now in shots.items()}, **({"inputs": inputs} if inputs else {})}  # fmt: skip


def _shot_current(old: dict, sid: str, now) -> bool:
    keys = old.get("shots") if isinstance(old.get("shots"), dict) else {}
    if sid not in keys:
        return False
    if isinstance(now, dict) and not isinstance(old.get("inputs"), dict):  # a stamp from before the inputs
        return keys[sid] == now.get("legacy")
    return keys[sid] == _key(now)


def _what_changed(old: dict, sid: str, now) -> str:
    """Which input of shot `sid`'s checks changed, in words."""
    return "; ".join(_changes(old, sid, now))


def _changes(old: dict, sid: str, now) -> list[str]:
    """Which inputs of shot `sid`'s checks changed, one phrase each (a change every shot shares, like the hard
    rules or the list of shots, is worded the same for each, so require_checks can say it once)."""
    keys = old.get("shots") if isinstance(old.get("shots"), dict) else {}
    if sid not in keys:
        return [f"shot {sid} is new"]
    if not isinstance(old.get("inputs"), dict) and isinstance(now, dict):
        return [(f"shot {sid} changed (the checks ran on an older plugin version that did not record what they "
                 "depend on, so any change to the shot's content or its short.json entry counts)")]  # fmt: skip
    had = (old.get("inputs") or {}).get(sid) if isinstance(old.get("inputs"), dict) else None
    if not isinstance(had, dict) or not isinstance(now, dict):
        return [f"shot {sid} changed"]
    out = []
    if had.get("fingerprint") != now.get("fingerprint"):
        out.append(describe_change(sid, changed_parts(had.get("parts"), now.get("parts"))))
    if had.get("tags") != now.get("tags"):
        out.append(f"shot {sid}'s tags changed (contact, hero, grounded, overlay or surface)")
    if had.get("frames") != now.get("frames"):
        a, b = had.get("frames") or ["?", "?"], now["frames"]
        out.append(f"shot {sid}'s frames changed ({a[0]}-{a[1]}, now {b[0]}-{b[1]})")
    entry_a, entry_b = had.get("entry") or {}, now.get("entry") or {}
    fields = sorted(k for k in set(entry_a) | set(entry_b) if entry_a.get(k) != entry_b.get(k))
    if fields:
        out.append(f"short.json shot {sid} entry changed (fields: {', '.join(fields)})")
    ids_a, ids_b = set(had.get("shot_ids") or ()), set(now.get("shot_ids") or ())
    if ids_a != ids_b:
        diff = [f"added {', '.join(sorted(ids_b - ids_a))}" if ids_b - ids_a else "",
                f"removed {', '.join(sorted(ids_a - ids_b))}" if ids_a - ids_b else ""]  # fmt: skip
        out.append(f"the shots in short.json changed ({'; '.join(d for d in diff if d)})")
    if had.get("rules") != now.get("rules"):
        out.append("the hard rules the scene names are checked against changed (rules_check, cleared words "
                   "included)")  # fmt: skip
    if had.get("caption_size") != now.get("caption_size"):
        out.append(f"the caption size changed ({had.get('caption_size')}, now {now.get('caption_size')}): the "
                   "captions cover a different part of the frame")  # fmt: skip
    return out or [f"shot {sid} changed"]


def _summarise(changes: dict[str, list[str]], n_shots: int) -> str:
    """Each phrase once, in first-seen order; one that several shots share says which: "(all 7 shots)" or
    "(shots s01, s02)"."""
    seen: dict[str, list[str]] = {}
    for sid, phrases in changes.items():
        for p in phrases:
            seen.setdefault(p, []).append(sid)
    out = []
    for p, sids in seen.items():
        if len(sids) > 1:
            p += f" (all {n_shots} shots)" if len(sids) == n_shots else f" (shots {', '.join(sids)})"
        out.append(p)
    return "; ".join(out)


def read_checks(short_dir: Path) -> dict | None:
    try:
        data = json.loads((Path(short_dir) / "review" / "checks.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def reusable_checks(short_dir: Path, stamp: dict) -> dict[str, list]:
    """{shot id: its findings} from review/checks.json for every shot whose checks still hold for `stamp` (same
    checks code, timing, --every and shot key): `BLENDER check` re-checks only the others. A finding listed once
    for several shots ("shots") goes to each of them; findings the overlap cap held back ("held_back") count too,
    and the row that says how many it held back does not (the cap runs again)."""
    data = read_checks(short_dir) or {}
    old = data.get("stamp")
    if not isinstance(old, dict) or not _code_current(old.get("code")) or stamp.get("code") != checks_code():
        return {}
    if any(old.get(k) != stamp.get(k) for k in ("timeline", "every")):
        return {}
    inputs = stamp.get("inputs") if isinstance(stamp.get("inputs"), dict) else {}
    out: dict[str, list] = {sid: [] for sid, key in (stamp.get("shots") or {}).items()
                            if _shot_current(old, sid, inputs.get(sid, key))}  # fmt: skip
    for f in [*(data.get("findings") or []), *(data.get("held_back") or [])]:
        if not isinstance(f, dict) or "capped" in f:
            continue
        shots = f.get("shots") if isinstance(f.get("shots"), list) else [f.get("shot")]
        for sid in shots:
            if sid in out:
                out[sid].append(f if f.get("shot") == sid else {**f, "shot": sid})
    return out


# the checks of one object alone: their findings hold while that object's key (bsa.blender.fingerprint: its data,
# materials, modifiers, parent chain, what it reads and its motion over the shot) and the rest of the shot (camera,
# lights, world, collections, tags) are unchanged. Every other check is run again on a shot that changed: floating
# (it depends on what holds the object up), contact_parent (it depends on the parents), pops, pop_in, swaps,
# framing, frame_edge, covered, names, hard rules and the camera checks. An overlap belongs to its pair.
OBJECT_CHECKS = ("boolean", "faceted", "normals", "materials", "images", "self_overlap", "self_zfight")
_REUSE_SAME = ("frames", "entry", "shot_ids", "rules", "caption_size", "tags", "rest")


def object_reuse(old: dict, sid: str, now: dict) -> set[str] | None:
    """The names of shot `sid`'s objects whose own checks (OBJECT_CHECKS, and overlaps of two such objects) still
    hold, or None: check the whole shot again. `old` is the stamp of review/checks.json, `now` the shot's
    shot_check_inputs as they are now with the new stamp's {"timeline", "every"} under "_stamp". None unless the
    checks code, the timing and --every are the same, both inputs hold object keys and the rest's key, and nothing
    but object keys changed (frames, short.json entry, shot list, rules, caption size, tags, rest); then the names
    whose key is the same (a new or renamed object has no old key, so it is checked), None when there are none."""
    if not isinstance(old, dict) or not isinstance(now, dict) or old.get("code") != checks_code():
        return None
    new = now.get("_stamp") if isinstance(now.get("_stamp"), dict) else {}
    if any(old.get(k) != new.get(k) for k in ("timeline", "every")):
        return None
    inputs = old.get("inputs") if isinstance(old.get("inputs"), dict) else {}
    had = inputs.get(sid)
    if not isinstance(had, dict) or not isinstance(had.get("objects"), dict) or "rest" not in had:
        return None
    if not isinstance(now.get("objects"), dict) or "rest" not in now or had.get("rest") is None:
        return None
    if any(had.get(k) != now.get(k) for k in _REUSE_SAME):
        return None
    kept = {n for n, k in now["objects"].items() if k is not None and had["objects"].get(n) == k}
    return kept or None


def partial_checks(short_dir: Path, stamp: dict) -> dict[str, tuple[set[str], list[dict]]]:
    """{shot id: (the names object_reuse keeps, the old rows that still hold)} for each shot of `stamp` whose checks
    are not reusable as a whole (reusable_checks) but whose unchanged objects' are: the rows of an OBJECT_CHECKS
    check on a kept object, and of an overlap whose two objects are both kept. The rows come from the findings and
    the ones the overlap cap held back, split per shot as reusable_checks does. A shot whose old overlap rows can't
    say their pair is checked again whole."""
    data = read_checks(short_dir) or {}
    old = data.get("stamp")
    inputs = stamp.get("inputs") if isinstance(stamp.get("inputs"), dict) else {}
    if not isinstance(old, dict) or stamp.get("code") != checks_code() or not inputs:
        return {}
    whole = reusable_checks(short_dir, stamp)
    new = {"timeline": stamp.get("timeline"), "every": stamp.get("every")}
    keep: dict[str, set[str]] = {}
    for sid in stamp.get("shots") or {}:
        if sid in whole or not isinstance(inputs.get(sid), dict):
            continue
        kept = object_reuse(old, sid, {**inputs[sid], "_stamp": new})
        if kept:
            keep[sid] = kept
    out: dict[str, tuple[set[str], list[dict]]] = {sid: (names, []) for sid, names in keep.items()}
    broken: set[str] = set()
    for f in [*(data.get("findings") or []), *(data.get("held_back") or [])]:
        if not isinstance(f, dict) or "capped" in f:
            continue
        shots = f.get("shots") if isinstance(f.get("shots"), list) else [f.get("shot")]
        for sid in shots:
            if sid not in out:
                continue
            names = keep[sid]
            if f.get("check") == "overlap":
                pair = f.get("pair")
                if not isinstance(pair, list | tuple) or len(pair) != 2:
                    broken.add(sid)  # can't tell which pair: the shot is checked again whole
                    continue
                hold = all(isinstance(n, str) and n in names for n in pair)
            else:
                hold = f.get("check") in OBJECT_CHECKS and isinstance(f.get("obj"), str) and f["obj"] in names
            if hold:
                out[sid][1].append(f if f.get("shot") == sid else {**f, "shot": sid})
    return {sid: v for sid, v in out.items() if sid not in broken}


FINAL_MAX_EVERY = 5  # the final needs checks that sampled at least every 5th frame (BLENDER check's default)


def _nth(n: int) -> str:
    return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"


def failed_checks(short_dir: Path, tl_hash: str, shots: dict) -> int:
    """How many errors review/checks.json found on the build and timing as they are now (`shots` as for
    require_checks; any --every): 0 when there are no checks, or they ran on another timing, checks code or shot.
    The preview render warns of these (it still renders): a preview made after the checks failed shows the
    failures to whoever watches it, and the final render refuses until they are fixed."""
    data = read_checks(short_dir) or {}
    stamp = data.get("stamp")
    if not isinstance(stamp, dict) or stamp.get("timeline") != tl_hash or not _code_current(stamp.get("code")):
        return 0
    if not all(_shot_current(stamp, sid, now) for sid, now in shots.items()):
        return 0
    try:
        return max(0, int(data.get("errors") or 0))
    except (TypeError, ValueError):
        return 0


def require_checks(short_dir: Path, tl_hash: str, shots: dict, command: str = "the final render",
                   key: str = "SHORT") -> None:
    """`command` (the final render or edit) needs checks that ran on every shot as it is now (`shots`: {shot id:
    shot_check_inputs}) and on this timing and checks code, sampled every FINAL_MAX_EVERY frames or finer
    (`--every`), and found no errors. A refusal says which input changed, and names the command to run with `key`,
    what the user types for this short (workspace.short_key)."""
    check = f"BLENDER check {key}"
    again = f"run {check} again before {command}"
    data = read_checks(short_dir)
    if data is None:
        raise StaleError(f"the scene checks have not run on this build: run {check} before {command}")
    stamp = data.get("stamp")
    if not isinstance(stamp, dict):
        raise StaleError(f"review/checks.json is from an older plugin version and can't say what it checked, so "
                         f"anything may have changed since the checks ran: {again}")  # fmt: skip
    if stamp.get("timeline") != tl_hash:
        raise StaleError(f"the timing changed since the checks ran (source/timeline.json is not the one they checked): "
                         f"{again} (it re-checks all {len(shots)} shots)")  # fmt: skip
    if not _code_current(stamp.get("code")):
        raise StaleError(f"the checks code changed since the checks ran (the plugin was updated): {again} (it checks "
                         "every shot once)")  # fmt: skip
    every = stamp.get("every")
    if not isinstance(every, int) or isinstance(every, bool):
        raise StaleError(f"the checks can't say how finely they checked (review/checks.json records no --every): "
                         f"{command} needs --every {FINAL_MAX_EVERY} or finer: run {check} --every "
                         f"{FINAL_MAX_EVERY} again")  # fmt: skip
    if every > FINAL_MAX_EVERY:
        raise StaleError(f"the checks ran on every {_nth(every)} frame (--every {every}): {command} needs --every "
                         f"{FINAL_MAX_EVERY} or finer: run {check} --every {FINAL_MAX_EVERY} again")  # fmt: skip
    changed = {sid: _changes(stamp, sid, now) for sid, now in shots.items() if not _shot_current(stamp, sid, now)}
    if changed:
        raise StaleError(f"{_summarise(changed, len(shots))} since the checks ran: {again} (it re-checks only those)")
    n = int(data.get("errors") or 0)
    if n:
        raise StaleError(f"review/checks.json has {n} error(s): fix them and run {check} again before "
                         f"{command}")  # fmt: skip
