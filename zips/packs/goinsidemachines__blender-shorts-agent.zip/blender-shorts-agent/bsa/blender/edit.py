"""The edit: frames, captions, badges, labels, sound and the H.264 + AAC MP4 encode, all in Blender's sequencer.

Text strip geometry: the VSE places text by a normalised anchor (0-1, origin bottom-left), the box grows
`box_margin * render height` pixels around the text on every side, and the text wraps at `wrap_width * width`.
`text_strip_rect` turns a strip's real settings back into a pixel Rect (origin top-left) so callers can check it.
"""

from __future__ import annotations

import sys
from pathlib import Path

import bpy

from bsa.fonts import (  # noqa: F401 - find_font_file, font_dirs re-exported
    caption_font_name,
    cover_font,
    family_of,
    find_font_file,
    font_caches,
    font_dirs,
    font_files,
    font_info_or_none,
    missing_chars,
    resolve,
)
from bsa.layout import H, Rect, W, caption_rect, end_card_band, safe_rect
from bsa.overlays import (  # noqa: F401 - the text sizes, estimates and colours are re-exported for callers
    BADGE_COLOR,
    BADGE_SIZE,
    BOX_COLOR,
    CAPTION_MARGIN,
    CAPTION_SIZE,
    CHAR_W,
    LABEL_SIZE,
    LINE_H,
    NEAR_GAP_PX,
    NEAR_WRAP_PX,
    SMALL_MARGIN,
    STACK_GAP_PX,
    caption_colours,
    caption_size,
    captions,
    corner_stack,
    follow,
    hero_rects,
)
from bsa.overlays import est_lines as _est_lines
from bsa.overlays import est_width as _est_width
from bsa.overlays import hex_colour as _hex_colour  # noqa: F401 - moved to overlays; closing_card imports it here
from bsa.settings import end_card
from bsa.short import Short, label_anchor, label_near, label_text
from bsa.timeline import Timeline, end_card_start

END_SIZE = 72
END_LINE_SIZE = 44
END_GAP_PX = 24  # clear space between the end-card line's box and the @handle box

CH_SOUND, CH_CAPTION, CH_BADGE, CH_LABEL, CH_END = 2, 10, 11, 12, 30

FONT_NOTE_PROP = "bsa_font_fallback"
FONT_USED_PROP = "bsa_font_used"
END_NOTE_PROP = "bsa_end_card_note"
GLYPH_NOTE_PROP = "bsa_glyph_fallbacks"
KIT_CARDS_PROP = "bsa_kit_cards"


def text_strip_rect(strip) -> Rect:
    """Estimated pixel rectangle (origin top-left) a TEXT strip, including its box, covers."""
    size = strip.font_size
    wrap_px = (strip.wrap_width or 1.0) * W
    n = _est_lines(strip.text, size, wrap_px)
    w, h = _est_width(strip.text, size, wrap_px), n * size * LINE_H
    margin = strip.box_margin * H if strip.use_box else 0.0
    ax, ay = strip.location[0] * W, (1.0 - strip.location[1]) * H
    x = {"LEFT": ax, "CENTER": ax - w / 2, "RIGHT": ax - w}[strip.anchor_x]
    y = {"TOP": ay, "CENTER": ay - h / 2, "BOTTOM": ay - h}[strip.anchor_y]
    return Rect(x - margin, y - margin, w + 2 * margin, h + 2 * margin)


def _load_font(name: str | None, cache_dirs: list[Path] | None = None):
    """(font datablock or None, family used or None, note): the style font from a file path, a family name in the
    OS font folders, or a static weight "Family@600" (installed, or downloaded into one of `cache_dirs`, default
    bsa.fonts.font_caches()), else the first installed OS fallback (bsa.fonts.FALLBACKS), else Blender's default
    font. The note says which font is used when the named one (or its weight) is missing."""
    if not name:
        return None, None, None
    path, used, note = resolve(name, cache_dirs=cache_dirs)
    if path is not None:
        try:
            return bpy.data.fonts.load(str(path), check_existing=True), used, note
        except RuntimeError:
            pass
    return None, None, f"font {name!r} could not be loaded, so the text uses Blender's default font"


def font_used(scene) -> str:
    """The font family the edit's text uses ("Blender's default font" when none was found or named)."""
    return scene.get(FONT_USED_PROP) or "Blender's default font"


def font_note(scene) -> str | None:
    """Why the edit used another font than the style named (a missing font or weight), or None."""
    return scene.get(FONT_NOTE_PROP) or None


def kit_cards(scene) -> int:
    """How many card images a brand kit placed in the edit (0 without a kit)."""
    return int(scene.get(KIT_CARDS_PROP, 0))


def glyph_fallbacks(scene) -> list[str]:
    """Texts the style font has no glyphs for, and the font each was drawn in instead (or that none had them)."""
    return [str(x) for x in scene.get(GLYPH_NOTE_PROP, [])]


class _Texts:
    """Adds styled text strips to the sequencer. A text the style font can't fully draw goes in a font that has
    every glyph it needs (bsa.fonts.cover_font: the OS fallbacks, then symbol fonts) instead of showing boxes: a
    text strip has one font, so the fallback covers that strip's whole text."""

    def __init__(self, strips, font, font_path=None):
        self.strips = strips
        self.font = font
        self.font_path = font_path
        self.notes: list[str] = []
        self._files = None

    def _font_for(self, text: str):
        info = font_info_or_none(self.font_path) if self.font_path else None
        miss = missing_chars(text, info) if info else []
        if not miss:
            return self.font
        chars = ", ".join(f"'{c}' (U+{ord(c):04X})" for c in miss)
        if self._files is None:  # list the OS fonts once per edit
            self._files = font_files(font_dirs())
        alt = cover_font(text, self.font_path, files=self._files)
        if alt is not None:
            try:
                font = bpy.data.fonts.load(str(alt), check_existing=True)
                self.notes.append(f"{text!r}: {info['family']} has no {chars}, so this text uses {family_of(alt)}")
                return font
            except RuntimeError:
                pass
        self.notes.append(f"{text!r}: no installed font has {chars}; they show as boxes")
        return self.font

    def add(self, text, f0, f1, channel, size, loc, anchor, margin, color=(1, 1, 1, 1), bold=True, wrap_px=None,
            box=BOX_COLOR, frame=(W, H)):
        """A text strip. `loc` is normalised by `frame` (the render's size: the edit's by default) and the text
        wraps at `wrap_px` (default: the safe width less the box), as a share of the frame's width. `margin` is the
        strip's box_margin as given (Blender takes it as a share of the image width)."""
        s = self.strips.new_effect(f"T_{text[:18]}", "TEXT", channel, f0, length=f1 - f0 + 1)
        s.text = text
        font = self._font_for(text)
        if font is not None:
            s.font = font
        s.font_size = size
        s.use_bold = bold
        s.color = color
        s.location = loc
        s.anchor_x, s.anchor_y = anchor
        s.alignment_x = anchor[0]
        s.wrap_width = (wrap_px if wrap_px is not None else safe_rect().w - 2 * margin * H) / frame[0]
        s.use_shadow = False  # the box gives the contrast
        s.use_box = True
        s.box_color = box
        s.box_margin = margin
        s.box_roundness = 0.4
        s.blend_type = "ALPHA_OVER"
        return s


def _norm(x_px: float, y_px_from_top: float) -> tuple[float, float]:
    return x_px / W, 1.0 - y_px_from_top / H


def _add_shots(short: Short, tl: Timeline, frames_root: Path, strips) -> None:
    spans = {s.id: s for s in tl.shots}
    for shot in short.shots:
        span = spans[shot.id]
        folder = Path(frames_root) / shot.id
        names = [f"{f:04d}.png" for f in range(span.f0, span.f1 + 1)]  # the short's own frame numbers, never padded
        missing = [n for n in names if not (folder / n).is_file() or (folder / n).stat().st_size == 0]
        if missing:
            raise FileNotFoundError(f"shot {shot.id!r} is missing rendered frames in {folder}: {', '.join(missing[:5])}")
        s = strips.new_image(f"Shot {shot.id}", str(folder / names[0]), 1, span.f0, fit_method="FIT")
        for name in names[1:]:
            s.elements.append(name)


def _follow(strip, points: dict, span, captions, fixed=(), placed: dict | None = None, heroes: dict | None = None,
            near: str | None = None) -> None:  # fmt: skip
    """Keyframe a near label's position every frame of its shot (bsa.overlays.follow places it)."""
    for frame, (x, bottom, _) in follow(strip.text, points, span.f0, span.f1, captions, fixed, placed, heroes,
                                        near).items():  # fmt: skip
        strip.location = _norm(x, bottom)
        strip.keyframe_insert("location", frame=frame)


_hero_rects = hero_rects


def _add_overlays(short: Short, tl: Timeline, texts: _Texts, settings: dict, anchors: dict | None = None,
                  label_heroes: dict | None = None) -> None:  # fmt: skip
    """Captions, each shot's badge and stacked labels, and its near labels, where bsa.overlays places them."""
    safe = safe_rect()
    size = caption_size(short)
    cx = safe.x + safe.w / 2
    colour, box = caption_colours(short, settings)
    cards = captions(short, tl)  # near labels keep off the caption bands; none with style.caption.draw false
    for card, (f0, f1, _, _, bottom) in zip(tl.cards if cards else [], cards, strict=True):
        texts.add(card.text, f0, f1, CH_CAPTION, size, _norm(cx, bottom), ("CENTER", "BOTTOM"), CAPTION_MARGIN,
                  color=colour, box=box)  # fmt: skip

    spans = {s.id: s for s in tl.shots}
    for shot in short.shots:
        span = spans[shot.id]
        fixed = []  # the badge and the stacked labels: near labels keep off them
        for kind, text, i, x, y in corner_stack(shot):
            if kind == "badge":
                strip = texts.add(text, span.f0, span.f1, CH_BADGE, BADGE_SIZE, _norm(x, y), ("LEFT", "TOP"),
                                  SMALL_MARGIN, color=BADGE_COLOR)  # fmt: skip
            else:
                strip = texts.add(text, span.f0, span.f1, CH_LABEL + i, LABEL_SIZE, _norm(x, y), ("LEFT", "TOP"),
                                  SMALL_MARGIN, bold=False)  # fmt: skip
            fixed.append(text_strip_rect(strip))
        placed = {}  # {frame: [near label boxes]}: each near label keeps off the ones placed before it
        for i, label in enumerate(shot.labels):
            text, near = label_text(label), label_near(label)
            if not near:
                continue
            points = ((anchors or {}).get(shot.id) or {}).get(label_anchor(label))
            if points is None:
                raise ValueError(f"no anchors for label {text!r} near {near!r} in shot {shot.id}: run BLENDER "
                                 "anchors SHORT")  # fmt: skip
            strip = texts.add(text, span.f0, span.f1, CH_LABEL + i, LABEL_SIZE, (0.5, 0.5), ("CENTER", "BOTTOM"),
                              SMALL_MARGIN, bold=False, wrap_px=NEAR_WRAP_PX)  # fmt: skip
            _follow(strip, points, span, cards, fixed, placed, (label_heroes or {}).get(shot.id), near)


_TEMP_CARD_DIRS: list = []  # the edits' temp card folders without a short folder (tempfile.TemporaryDirectory)


def _add_kit(short: Short, tl: Timeline, seq, k, sdir: Path | None, anchors: dict | None,
             label_heroes: dict | None) -> tuple[int, list[str], Path | None]:  # fmt: skip
    """The brand kit's cards as image strips where bsa.kitlayout puts them, drawn into `sdir`/cards (a temp folder
    without a short folder). Returns (card images placed, notes: the card font's and the layout's, the card font)."""
    import tempfile

    from bsa import cards, kitlayout
    from bsa.blender.cards import add_overlay

    font, note = cards.card_font_and_note(k, font_caches(sdir))
    ov = kitlayout.build(short, tl, k, font, anchors, label_heroes)
    if sdir is not None:
        cache_dir = Path(sdir) / "cards"
    else:  # one temp folder per call, kept until Blender exits (the strips are encoded after this returns)
        _TEMP_CARD_DIRS.append(tempfile.TemporaryDirectory(prefix="bsa-cards-", ignore_cleanup_errors=True))
        cache_dir = Path(_TEMP_CARD_DIRS[-1].name)
    before = {s.name for s in seq.strips_all}
    add_overlay(seq, ov, cache_dir)
    placed = sum(1 for s in seq.strips_all if s.type == "IMAGE" and s.name not in before)
    return placed, [n for n in [note, *ov.notes] if n], font


def _add_end_card(tl: Timeline, texts: _Texts, settings: dict, heroes: dict | None = None, short=None) -> str | None:
    """The end card: the user's @handle (the only identity there ever is), with the end-card line smaller above it
    and an optional second line (the user's site, say) smaller below it, a clear gap between the boxes; without a
    handle the short's own line is the big one. The short's own `end_card` wins over the setting
    (bsa.settings.end_card). From the frame after the last caption to the end (the timeline holds the last shot
    END_CARD_S for it). It goes in the upper third of the safe area, else the caption zone, else the middle, else
    low above the caption zone: the first band that no hero of the last shot and no other mesh on screen covers
    during those frames, else the first no hero covers (the least other mesh), else the least hero (`heroes`: that
    shot's {"f0", "boxes", "scenery"} from anchors.json; "scenery" is {"f0", "boxes": [[box, ...] per frame]}, the
    other meshes). Returns a note when every band covers a hero (the least covered one is used)."""
    card = end_card(settings, short)
    if card["handle"]:
        rows = [(card["text"], False), ("@" + card["handle"], True), (card["second"], False)]
    else:
        rows = [(card["text"], True), (card["second"], False)]
    rows = [(text, big) for text, big in rows if text]
    if not rows:
        return None
    f0 = end_card_start(tl)
    if f0 > tl.n_frames:  # no room after the last line: never cover it
        return None
    safe = safe_rect()
    cx = safe.x + safe.w / 2
    big_i = next(i for i, (_, big) in enumerate(rows) if big) if any(big for _, big in rows) else 0
    strips = [None] * len(rows)

    def add(i, bottom):
        text, big = rows[i]
        size, margin = (END_SIZE, CAPTION_MARGIN) if big else (END_LINE_SIZE, SMALL_MARGIN)
        strips[i] = texts.add(text, f0, tl.n_frames, CH_END + i, size, _norm(cx, bottom - margin * H),
                              ("CENTER", "BOTTOM"), margin, bold=big)  # fmt: skip

    add(big_i, safe.y + safe.h / 3 - 1)  # the main box ends at the upper third
    for i in range(big_i - 1, -1, -1):  # lines above it
        add(i, text_strip_rect(strips[i + 1]).y - END_GAP_PX)
    for i in range(big_i + 1, len(rows)):  # lines below it: their box's top END_GAP_PX under the one above
        text, big = rows[i]
        size, margin = (END_SIZE, CAPTION_MARGIN) if big else (END_LINE_SIZE, SMALL_MARGIN)
        h = _est_lines(text, size, safe.w - 2 * margin * H) * size * LINE_H + 2 * margin * H
        add(i, text_strip_rect(strips[i - 1]).bottom + END_GAP_PX + h)
    rects = [text_strip_rect(s) for s in strips]
    x0, y0 = min(r.x for r in rects), min(r.y for r in rects)
    block = Rect(x0, y0, max(r.right for r in rects) - x0, max(r.bottom for r in rects) - y0)
    boxes = [r for frame in range(f0, tl.n_frames + 1) for r in _hero_rects(heroes, frame)]
    others = []
    scenery = heroes.get("scenery") if isinstance(heroes, dict) else None
    if isinstance(scenery, dict) and isinstance(scenery.get("boxes"), list):
        s0 = int(scenery.get("f0", 1))
        for frame in range(f0, tl.n_frames + 1):
            if 0 <= frame - s0 < len(scenery["boxes"]):
                others += [Rect(b[0], b[1], b[2] - b[0], b[3] - b[1]) for b in scenery["boxes"][frame - s0] or []]
    caption_top = caption_rect(2, CAPTION_SIZE, LINE_H).y - CAPTION_MARGIN * H
    band, dy, area = end_card_band(block, boxes, caption_top, others=others)
    for s in strips:
        s.location[1] -= dy / H
    if area:
        return f"the end card covers a hero in every position; it uses the {band}, which covers the least"
    return None


def end_card_note(scene) -> str | None:
    """Why the end card could not be kept clear of the heroes, or None."""
    return scene.get(END_NOTE_PROP) or None


def _configure_output(scene, out_mp4: Path, preset: str) -> None:
    r = scene.render
    r.resolution_x, r.resolution_y, r.resolution_percentage = W, H, 100
    r.fps, r.fps_base = 30, 1.0
    r.use_sequencer = True
    r.use_compositing = False
    scene.view_settings.view_transform = "Standard"  # frames are already tone-mapped by their own scenes
    scene.view_settings.look = "None"
    if hasattr(r.image_settings, "media_type"):
        r.image_settings.media_type = "VIDEO"
    r.image_settings.file_format = "FFMPEG"
    r.ffmpeg.format, r.ffmpeg.codec = "MPEG4", "H264"
    r.ffmpeg.constant_rate_factor = "PERC_LOSSLESS" if preset == "final" else "MEDIUM"
    r.ffmpeg.ffmpeg_preset = "GOOD"
    r.ffmpeg.audio_codec, r.ffmpeg.audio_bitrate = "AAC", 256
    r.ffmpeg.audio_channels, r.ffmpeg.audio_mixrate = "STEREO", 48000
    r.filepath = str(out_mp4)


def build_edit(
    short: Short,
    tl: Timeline,
    frames_root: Path,
    mix_wav: Path | None,
    out_mp4: Path,
    settings: dict,
    preset: str = "final",
    anchors: dict | None = None,
    hero_boxes: dict | None = None,
    label_heroes: dict | None = None,
    closing: dict | None = None,
):
    """Create the `Edit` scene: shot frames, captions, badges, labels, optional @handle end card, the closing card
    and sound. With a brand kit (bsa.kit.kit_for: brand.style set) the captions, badges and labels are the kit's
    cards (image strips, bsa.kitlayout); without one, today's text strips, unchanged. The end card is text in both.
    `closing` ({"png", "f0", "n_frames"}, bsa.closing.plan) holds the closing card's PNG after the story, from frame
    f0 (the frame after the timeline) for n_frames; the mix already covers them. `anchors`
    ({shot: {object: {"f0", "points"}}}, from source/anchors.json) places labels that are near an object; `hero_boxes`
    (the last shot's {"f0", "boxes", "scenery"} from anchors.json) keeps the end card off its heroes, then off its
    other meshes; `label_heroes` ({shot: {"f0", "boxes"}}) keeps near labels off the other heroes of their shot."""
    old = bpy.data.scenes.get("Edit")
    if old is not None:
        bpy.data.scenes.remove(old)
    scene = bpy.data.scenes.new("Edit")
    scene.frame_start, scene.frame_end = 1, tl.n_frames + (closing["n_frames"] if closing else 0)
    _configure_output(scene, Path(out_mp4), preset)  # first: the image strips fit to this resolution
    seq = scene.sequence_editor_create()
    _add_shots(short, tl, Path(frames_root), seq.strips)
    if closing:
        card = seq.strips.new_image("Closing card", str(closing["png"]), 1, closing["f0"], fit_method="FIT")
        card.frame_final_duration = closing["n_frames"]
    sdir = Path(out_mp4).parent.parent if Path(out_mp4).parent.name == "out" else None  # <short>/out/<slug>.mp4
    from bsa import kit as kit_mod

    k = kit_mod.kit_for(settings, short)
    # without a kit the captions fall back to brand.font (a fresh look gets none); a kit keeps its own card font
    name = short.style.get("font") if k is not None else caption_font_name(short, settings)
    font, used, note = _load_font(name or None, font_caches(sdir))
    if note:
        scene[FONT_NOTE_PROP] = note
    if used:
        scene[FONT_USED_PROP] = used
    texts = _Texts(seq.strips, font, Path(bpy.path.abspath(font.filepath)) if font is not None else None)
    if k is None:  # no brand.style: exactly today's text captions, badges and labels
        _add_overlays(short, tl, texts, settings, anchors, label_heroes)
    else:
        n, notes, card_font = _add_kit(short, tl, seq, k, sdir, anchors, label_heroes)
        scene[KIT_CARDS_PROP] = n
        texts.notes += notes
        if not short.style.get("font") and card_font is not None:  # the end card in the kit's font, as its cards
            try:
                texts.font = bpy.data.fonts.load(str(card_font), check_existing=True)
                texts.font_path = Path(card_font)
                scene[FONT_USED_PROP] = family_of(card_font)
            except RuntimeError:
                pass
    note = _add_end_card(tl, texts, settings, hero_boxes, short)  # today's text strips, with a kit too
    if note:
        scene[END_NOTE_PROP] = note
    if texts.notes:
        scene[GLYPH_NOTE_PROP] = list(dict.fromkeys(texts.notes))
    if mix_wav is not None:
        seq.strips.new_sound("Mix", str(mix_wav), CH_SOUND, 1)
    if mix_wav is None:  # captions-only short: no audio stream at all, not a silent one
        scene.render.ffmpeg.audio_codec = "NONE"
    return scene


def encode(scene, progress=None) -> Path:
    """Render the edit's animation to its MP4 and return the path. `progress(frames done, frames)` is called after
    each frame when given (a failing callback never stops the encode)."""
    total = scene.frame_end - scene.frame_start + 1
    done = [0]

    def _post(sc, *_):
        if sc is not scene:
            return
        done[0] += 1
        try:
            progress(min(done[0], total), total)
        except Exception as exc:  # noqa: BLE001 - status only
            print(f"encode progress: {exc}", file=sys.stderr)

    if progress is not None:
        bpy.app.handlers.render_post.append(_post)
    try:
        bpy.ops.render.render(animation=True, scene=scene.name)
    finally:
        if _post in bpy.app.handlers.render_post:
            bpy.app.handlers.render_post.remove(_post)
    out = Path(bpy.path.abspath(scene.render.filepath))
    if not out.exists() or out.stat().st_size == 0:
        raise RuntimeError(f"encode produced no MP4 at {out}")
    return out


def probe(mp4: Path) -> dict:
    """width, height, fps, frames and has_audio of an MP4, read through Blender (no ffprobe)."""
    clip = bpy.data.movieclips.load(str(mp4))
    try:
        info = {
            "width": int(clip.size[0]),
            "height": int(clip.size[1]),
            "fps": float(clip.fps),
            "frames": int(clip.frame_duration),
        }
    finally:
        bpy.data.movieclips.remove(clip)
    info["has_audio"] = _has_audio(Path(mp4))
    return info


def _has_audio(mp4: Path) -> bool:
    import aud

    try:
        return aud.Sound(str(mp4)).length > 0
    except (RuntimeError, aud.error):
        return False
