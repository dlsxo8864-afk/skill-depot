# Visual QA and Anti-Noise

Syntax correctness is not visual correctness. `pix check` can confirm that an asset is valid while the rendered image still contains weak silhouettes, accidental gaps, noisy clusters, or floating pixels.

## The three-view inspection

Review every new asset in three views:

1. **Native 1x:** confirms readability at the actual authored resolution.
2. **Nearest-neighbor enlargement:** exposes cluster shape, stair-stepping, and isolated pixels. Use an integer scale such as 8x.
3. **Context backgrounds:** inspect transparent assets over both a light and a dark background. Add a checkerboard preview when transparency boundaries matter.

Do not use a smoothed browser or image-editor zoom for pixel-level judgment.

## Component classification

A disconnected component is a group of opaque pixels that does not touch another opaque group horizontally or vertically. Detached components are not automatically wrong, but every one needs a reason.

Classify each component as one of:

- primary subject;
- required detached part, such as a projectile;
- contact or cast shadow;
- requested atmosphere;
- accidental noise.

Delete accidental noise. For logos and icons, default to a single primary component unless the brief requires otherwise.

## Color-cluster review

A color cluster is a connected region of one palette color. Tiny color clusters may be legitimate even when they sit inside the main opaque silhouette—for example, an eye or a highlight. Review clusters of one or two pixels carefully.

Keep a tiny cluster only when it:

- marks a focal feature;
- completes a controlled diagonal or curve;
- communicates material or lighting;
- improves recognition at native resolution.

Remove it when it merely fills empty space, creates visual static, or has no relationship to surrounding forms.

## Decoration policy

Decoration is opt-in, not a default finishing step.

Never add these automatically:

- corner sparkles;
- random stars;
- dust motes;
- floating one-pixel accents;
- arbitrary shine marks outside the silhouette;
- unrelated ground speckles.

When decoration is requested, place it in a separately named group and make its composition deliberate. Prefer a small rhythm of clusters with controlled spacing over uniform randomness.

## Logo and icon gate

Before approving a logo or icon:

1. Remove all atmosphere and decorative particles.
2. Fill the mark as a silhouette and verify recognition.
3. Check that negative spaces stay open at 1x.
4. Inspect every corner and canvas edge for isolated accents.
5. Verify a clean safety margin.
6. Test transparent, light, and dark backgrounds.
7. Run the PNG auditor.
8. Explain any remaining detached component or tiny color cluster.

A logo should not acquire stars or sparkles simply because the canvas has unused space.

## Animation gate

Inspect the animation and every frame independently:

- compare silhouette volume frame to frame;
- identify intentional squash, stretch, and translation;
- detect single-pixel flicker;
- ensure highlights follow the surface and light source;
- verify particles have designed trajectories rather than random positions;
- verify the final frame transitions cleanly to the first.

## Using the PNG auditor

From the skill repository root:

```bash
python3 skills/pixel-art-pix/scripts/audit_png.py output.png
```

Useful options:

```bash
python3 skills/pixel-art-pix/scripts/audit_png.py output.png \
  --max-detached-size 4 \
  --max-color-cluster-size 1 \
  --json
```

The auditor reports:

- opaque connected components;
- small detached components;
- tiny same-color clusters;
- opaque pixels touching canvas edges.

Warnings require visual judgment. Eyes, highlights, and line endings may be valid tiny color clusters. The goal is to force an explicit review, not to erase all single pixels mechanically.

Run the auditor on the **native-resolution PNG**. An 8x render turns one authored pixel into 64 output pixels and hides the metric the audit is designed to measure.

## Anti-pattern comparison

`assets/examples/badge-noisy.pix` deliberately contains floating corner sparkles and disconnected speckles. `assets/examples/badge-clean.pix` removes them while preserving the badge silhouette and interior mark.

| Anti-pattern | Clean correction |
| --- | --- |
| ![Badge with unrequested floating pixels](../assets/previews/badge-noisy-8x.png) | ![Clean compact badge](../assets/previews/badge-clean-8x.png) |

Use the pair to demonstrate that decoration should not be added merely to occupy transparent space.
