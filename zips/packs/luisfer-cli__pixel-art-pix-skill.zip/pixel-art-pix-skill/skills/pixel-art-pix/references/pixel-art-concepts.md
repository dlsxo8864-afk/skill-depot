# Pixel Art Concepts

## Resolution and scale

Pixel art is designed at native resolution. A 16x16 sprite cannot communicate the same amount of information as a 64x64 sprite.

Guidelines:

- 8x8: icon-level silhouettes and symbols.
- 16x16: strong silhouette, one or two identifying features.
- 32x32: readable character/object with secondary details.
- 64x64: material hints, texture, and richer animation poses.

Always design so the asset reads at 1x scale before considering enlarged preview scale.

## Silhouette

The silhouette is the outer readable shape of the sprite. If the sprite is filled black, the viewer should still understand the subject.

Improve silhouettes by:

- using asymmetry where appropriate;
- exaggerating the most recognizable features;
- avoiding flat rectangles unless the subject demands them;
- leaving negative space around important forms.

## Shape language

Use simple geometric forms to communicate character:

- Round shapes: cute, soft, organic, safe.
- Squares/rectangles: sturdy, artificial, heavy.
- Triangles/diagonals: sharp, dangerous, fast.

## Clusters

A cluster is a connected group of same-color pixels. Strong pixel art relies on clear clusters rather than scattered single pixels.

Good clusters:

- describe form;
- reduce noise;
- create intentional edges;
- make highlights and shadows readable.

Avoid random single-pixel speckles. Grit, stars, particles, and texture are opt-in: add them only when the brief requests them or the subject cannot read correctly without them. Empty transparent space does not need decoration.

After rendering, inspect every disconnected opaque component and every one- or two-pixel color cluster. Keep each one only when it has a specific structural, lighting, material, focal, or requested atmospheric purpose.

## Negative space and safety margins

Negative space is part of the design. Preserve it instead of filling it with stars, sparkles, and corner accents.

For logos, icons, and UI assets:

- maintain a consistent transparent margin around the primary mark;
- avoid unrelated components near canvas edges;
- keep holes and interior gaps open at native resolution;
- test the silhouette on both light and dark backgrounds.

## Palette roles

A limited palette is easier to control. Assign roles:

- outline: darkest readable boundary;
- shadow: form and contact darkness;
- base: primary local color;
- highlight: light-facing surface;
- accent: small color used sparingly for attention.

Use hue shifting when possible: shadows can be cooler, highlights warmer, depending on style.

## Contrast and value

Value contrast matters more than hue. Check whether the sprite is readable in grayscale. High contrast should be reserved for focal points such as eyes, weapons, or interactive parts.

## Gradients and ramps

Avoid smooth gradients. Pixel art should use stepped ramps, selective highlights, or dithering.

A ramp is a sequence of colors ordered by value and/or hue:

```txt
outline -> shadow -> base -> highlight
```

Use few steps for small sprites.

## Dithering

Dithering alternates pixels from two colors to imply an intermediate value or texture. Use sparingly on small sprites; too much dithering creates noise.

Common patterns:

- checkerboard: strong texture;
- sparse diagonal: softer transition;
- selective edge dithering: material hint.

## Outlines

Outlines increase readability against varied backgrounds. They can be:

- full dark outline;
- selective outline on shadow side;
- colored outline using darker local colors.

Avoid outlines that consume too much of a tiny sprite.

## Lighting

Choose one light direction and keep it consistent across frames. Common game-sprite lighting comes from upper-left or upper-right.

Use shadows for:

- underside planes;
- occlusion/contact points;
- overlaps between forms.

Use highlights for:

- focal areas;
- glossy materials;
- top-facing planes.

## Materials

Represent materials with minimal cues:

- Metal: high contrast, sharp highlights.
- Cloth: softer contrast, folds as larger clusters.
- Slime/liquid: rounded silhouette, bright specular highlights.
- Wood: warm ramp, sparse directional lines.
- Stone: blocky clusters, low saturation.

## Asset-type discipline

Different assets need different defaults:

- Logos and icons: one compact silhouette, no ambient decoration by default.
- Character sprites: prioritize pose, face, and identifying equipment.
- Object sprites: prioritize material and functional shape.
- Scenes: environmental texture and particles may be appropriate when compositionally controlled.
- Effects: detached particles are expected, but their spacing and trajectories must still be designed rather than random.

## Animation

Readable animation relies on key poses and timing, not many frames.

Principles:

- Idle: subtle breathing/bobbing, 2-4 frames can be enough.
- Walk: contact, passing, contact, passing.
- Attack: anticipation, strike, recovery.
- Impact: exaggerate the hit frame.
- Loops: first and last frames should transition cleanly.

Small sprites need exaggerated motion because details are limited. Review each frame for accidental single-pixel flicker, inconsistent highlights, and particles that jump without a designed trajectory.

## Spritesheets

A spritesheet packs frames into a grid. Keep frame dimensions consistent. Export metadata when possible so engines can locate frames precisely.

Recommended naming:

```txt
idle-1
idle-2
walk-1
walk-2
attack-1
attack-2
```
