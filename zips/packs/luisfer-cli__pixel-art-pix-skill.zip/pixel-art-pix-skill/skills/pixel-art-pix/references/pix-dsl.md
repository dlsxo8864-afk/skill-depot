# pix DSL Reference

`pix` is a deterministic pixel-art renderer for `.pix` files.

Repository:

```txt
https://github.com/luisfer-cli/pix
```

Install:

```bash
cargo install --git https://github.com/luisfer-cli/pix
```

## Core document

A `.pix` file requires a canvas:

```pix
canvas WIDTH HEIGHT
```

Optional global settings:

```pix
background COLOR
strict_palette true
```

If no background is supplied, transparent is used.

## Colors

Supported color expressions:

```pix
transparent
#RRGGBB
#RRGGBBAA
PALETTE_NAME
```

Palette:

```pix
palette {
    O #181425
    G #3fa34d
    L #7bd88f
}
```

With `strict_palette true`, colors used by drawable items should come from the palette.

## Drawable items

Drawable items can be top-level, inside `group`, or inside `frame`.

```pix
pixel X Y COLOR
line X1 Y1 X2 Y2 COLOR
rect X Y W H COLOR
fill X Y COLOR
circle CX CY R COLOR
```

Groups have local coordinates:

```pix
group NAME at X Y {
    rect 0 0 8 8 COLOR
    pixel 2 2 COLOR
}
```

Rendering order is textual. Later items can overwrite earlier pixels. Pixels outside canvas are clipped.

## Frames

Frames define named drawable states:

```pix
frame idle-1 {
    group body at 3 5 {
        rect 0 1 10 5 G
    }
}
```

Render one frame:

```bash
pix render asset.pix --frame idle-1 -o idle-1.png
```

## Animations

Animations reference frames and define FPS:

```pix
animation idle fps 6 {
    idle-1
    idle-2
}
```

Export individual frames:

```bash
pix anim asset.pix -a idle --out-dir frames/
```

Export GIF:

```bash
pix gif asset.pix -a idle -o idle.gif
```

Export spritesheet:

```bash
pix sheet asset.pix -a idle -o idle-sheet.png --json idle-sheet.json --columns 2
```

## Complete example

```pix
canvas 16 16
background transparent
strict_palette true

palette {
    O #181425
    G #3fa34d
    L #7bd88f
}

frame idle-1 {
    group slime at 3 5 {
        rect 0 1 10 5 G
        pixel 2 2 O
        pixel 7 2 O
        circle 5 3 2 L
    }
}

frame idle-2 {
    group slime at 3 6 {
        rect 0 1 10 4 G
        pixel 2 2 O
        pixel 7 2 O
        circle 5 2 2 L
    }
}

animation idle fps 6 {
    idle-1
    idle-2
}
```

Validate the source:

```bash
pix check asset.pix
```

Validation confirms DSL correctness, not visual quality. Render both native and enlarged previews:

```bash
pix render asset.pix -o asset-1x.png
pix render asset.pix -o asset-8x.png --scale 8
```

Inspect the 1x output for readability and the enlarged output for cluster quality, isolated pixels, accidental gaps, and edge stair-stepping. For transparent assets, preview both light and dark backgrounds.

From the skill repository root, audit the native PNG for disconnected components and tiny color clusters:

```bash
python3 skills/pixel-art-pix/scripts/audit_png.py asset-1x.png
```

The audit is a visual-review aid. A reported pupil or specular highlight may be intentional; an unexplained floating sparkle should be removed.
