#!/usr/bin/env python3
"""Audit native-resolution PNG pixel art for disconnected and tiny clusters.

This intentionally has no third-party dependencies. It supports non-interlaced,
8-bit PNG files in grayscale, RGB, indexed, grayscale-alpha, and RGBA formats.
Warnings are review prompts: small eyes and highlights may be intentional.
"""

import argparse
import json
import struct
import sys
import zlib
from collections import deque
from pathlib import Path

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
CHANNELS = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}


def read_chunks(data):
    if not data.startswith(PNG_SIGNATURE):
        raise ValueError("not a PNG file")
    offset = len(PNG_SIGNATURE)
    chunks = []
    while offset + 12 <= len(data):
        length = struct.unpack(">I", data[offset:offset + 4])[0]
        kind = data[offset + 4:offset + 8]
        payload = data[offset + 8:offset + 8 + length]
        if len(payload) != length:
            raise ValueError("truncated PNG chunk")
        chunks.append((kind, payload))
        offset += 12 + length
        if kind == b"IEND":
            break
    return chunks


def closest_predictor(a, b, c):
    estimate = a + b - c
    distances = (abs(estimate - a), abs(estimate - b), abs(estimate - c))
    return (a, b, c)[distances.index(min(distances))]


def unfilter(raw, width, height, bytes_per_pixel):
    stride = width * bytes_per_pixel
    rows = []
    offset = 0
    previous = bytearray(stride)
    for _ in range(height):
        if offset + stride + 1 > len(raw):
            raise ValueError("truncated PNG image data")
        filter_type = raw[offset]
        source = raw[offset + 1:offset + 1 + stride]
        row = bytearray(stride)
        for index, value in enumerate(source):
            left = row[index - bytes_per_pixel] if index >= bytes_per_pixel else 0
            up = previous[index]
            upper_left = previous[index - bytes_per_pixel] if index >= bytes_per_pixel else 0
            if filter_type == 0:
                predictor = 0
            elif filter_type == 1:
                predictor = left
            elif filter_type == 2:
                predictor = up
            elif filter_type == 3:
                predictor = (left + up) // 2
            elif filter_type == 4:
                predictor = closest_predictor(left, up, upper_left)
            else:
                raise ValueError("unsupported PNG filter type: %d" % filter_type)
            row[index] = (value + predictor) & 255
        rows.append(row)
        previous = row
        offset += stride + 1
    return rows


def decode_png(path):
    chunks = read_chunks(Path(path).read_bytes())
    header = next((payload for kind, payload in chunks if kind == b"IHDR"), None)
    if header is None:
        raise ValueError("PNG has no IHDR chunk")
    width, height, bit_depth, color_type, compression, filtering, interlace = struct.unpack(">IIBBBBB", header)
    if bit_depth != 8 or color_type not in CHANNELS or interlace != 0:
        raise ValueError("only non-interlaced 8-bit PNG files are supported")
    if compression != 0 or filtering != 0:
        raise ValueError("unsupported PNG compression or filtering method")

    palette_data = next((payload for kind, payload in chunks if kind == b"PLTE"), b"")
    transparency = next((payload for kind, payload in chunks if kind == b"tRNS"), b"")
    palette = [tuple(palette_data[i:i + 3]) for i in range(0, len(palette_data), 3)]
    compressed = b"".join(payload for kind, payload in chunks if kind == b"IDAT")
    channels = CHANNELS[color_type]
    rows = unfilter(zlib.decompress(compressed), width, height, channels)
    pixels = []

    for row in rows:
        decoded = []
        for x in range(width):
            values = row[x * channels:(x + 1) * channels]
            if color_type == 0:
                rgba = (values[0], values[0], values[0], 255)
            elif color_type == 2:
                rgba = (values[0], values[1], values[2], 255)
            elif color_type == 3:
                index = values[0]
                if index >= len(palette):
                    raise ValueError("palette index outside PLTE")
                alpha = transparency[index] if index < len(transparency) else 255
                rgba = palette[index] + (alpha,)
            elif color_type == 4:
                rgba = (values[0], values[0], values[0], values[1])
            else:
                rgba = tuple(values)
            decoded.append(rgba)
        pixels.append(decoded)
    return width, height, pixels


def find_components(width, height, pixels, same_color=False):
    visited = set()
    components = []
    for y in range(height):
        for x in range(width):
            if (x, y) in visited or pixels[y][x][3] == 0:
                continue
            color = pixels[y][x] if same_color else None
            queue = deque([(x, y)])
            visited.add((x, y))
            points = []
            while queue:
                px, py = queue.popleft()
                points.append((px, py))
                for nx, ny in ((px - 1, py), (px + 1, py), (px, py - 1), (px, py + 1)):
                    if not (0 <= nx < width and 0 <= ny < height) or (nx, ny) in visited:
                        continue
                    neighbor = pixels[ny][nx]
                    if neighbor[3] == 0 or (same_color and neighbor != color):
                        continue
                    visited.add((nx, ny))
                    queue.append((nx, ny))
            components.append({"size": len(points), "origin": list(min(points)), "color": list(color) if color else None})
    return sorted(components, key=lambda item: item["size"], reverse=True)


def audit(path, max_detached_size, max_color_cluster_size):
    width, height, pixels = decode_png(path)
    opaque_components = find_components(width, height, pixels)
    color_clusters = find_components(width, height, pixels, same_color=True)
    detached = [component for component in opaque_components[1:] if component["size"] <= max_detached_size]
    tiny_colors = [component for component in color_clusters if component["size"] <= max_color_cluster_size]
    edge_pixels = []
    for y in range(height):
        for x in range(width):
            if pixels[y][x][3] and (x == 0 or y == 0 or x == width - 1 or y == height - 1):
                edge_pixels.append([x, y])
    warnings = []
    if detached:
        warnings.append("small detached opaque components require review")
    if tiny_colors:
        warnings.append("tiny same-color clusters require review")
    if edge_pixels:
        warnings.append("opaque pixels touch the canvas edge")
    return {
        "path": str(path),
        "width": width,
        "height": height,
        "opaque_components": len(opaque_components),
        "small_detached_components": detached,
        "tiny_color_clusters": tiny_colors,
        "edge_pixel_count": len(edge_pixels),
        "edge_pixel_samples": edge_pixels[:20],
        "warnings": warnings,
    }


def print_report(report):
    print("Pixel-art audit: %s (%dx%d)" % (report["path"], report["width"], report["height"]))
    print("  opaque components: %d" % report["opaque_components"])
    print("  small detached components: %d" % len(report["small_detached_components"]))
    for component in report["small_detached_components"][:20]:
        print("    - size %(size)d at %(origin)s" % component)
    print("  tiny color clusters: %d" % len(report["tiny_color_clusters"]))
    for cluster in report["tiny_color_clusters"][:20]:
        color = "#%02x%02x%02x%02x" % tuple(cluster["color"])
        print("    - size %d at %s, %s" % (cluster["size"], cluster["origin"], color))
    print("  pixels touching canvas edge: %d" % report["edge_pixel_count"])
    if report["warnings"]:
        print("  review required:")
        for warning in report["warnings"]:
            print("    ! %s" % warning)
    else:
        print("  no structural noise warnings")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("png", type=Path, help="native-resolution PNG to audit")
    parser.add_argument("--max-detached-size", type=int, default=4, help="maximum detached component size to report (default: 4)")
    parser.add_argument("--max-color-cluster-size", type=int, default=1, help="maximum same-color cluster size to report (default: 1)")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    parser.add_argument("--fail-on-warnings", action="store_true", help="exit with status 1 when review warnings exist")
    args = parser.parse_args()
    try:
        report = audit(args.png, args.max_detached_size, args.max_color_cluster_size)
    except (OSError, ValueError, zlib.error) as error:
        parser.error(str(error))
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print_report(report)
    return 1 if args.fail_on_warnings and report["warnings"] else 0


if __name__ == "__main__":
    sys.exit(main())
