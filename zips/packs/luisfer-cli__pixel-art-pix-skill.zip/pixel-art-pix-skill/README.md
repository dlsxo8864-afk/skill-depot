# Pixel Art pix Skill

A portable [Agent Skills](https://agentskills.io/) package that teaches compatible coding agents how to reason about pixel art and how to use the [`pix`](https://github.com/luisfer-cli/pix) DSL renderer.

The skill covers pixel-art fundamentals such as silhouettes, clusters, palettes, ramps, dithering, outlines, scale constraints, frames, animations, spritesheets, and GIF export. It also enforces an anti-noise workflow: no automatic sparkles or floating decorative pixels, native-resolution review, asset-specific acceptance criteria, and a deliberate cleanup pass.

## Contents

```txt
skills/pixel-art-pix/
├── SKILL.md
├── references/
│   ├── pixel-art-concepts.md
│   ├── pix-dsl.md
│   └── visual-qa.md
├── scripts/
│   └── audit_png.py
└── assets/
    ├── examples/
    │   ├── badge-clean.pix
    │   ├── badge-noisy.pix
    │   └── slime-idle.pix
    └── previews/
        ├── badge-clean-8x.png
        └── badge-noisy-8x.png
```

## Install in Pi

Install globally:

```bash
pi install git:github.com/luisfer-cli/pixel-art-pix-skill@v0.1.0
```

Try for one session:

```bash
pi -e git:github.com/luisfer-cli/pixel-art-pix-skill@v0.1.0
```

## Use with other agents

This repository follows the Agent Skills directory convention: a skill is a directory containing `SKILL.md` with YAML frontmatter and Markdown instructions.

For other compatible agents, add or copy this folder:

```txt
skills/pixel-art-pix/
```

to the agent's configured skills directory.

## pix dependency

The skill expects the `pix` CLI when rendering or validating assets:

```bash
cargo install --git https://github.com/luisfer-cli/pix
```

## Visual noise audit

The bundled dependency-free Python tool reports detached opaque components, tiny same-color clusters, and pixels touching canvas edges. Run it on a native-resolution render:

```bash
pix render asset.pix -o asset-1x.png
python3 skills/pixel-art-pix/scripts/audit_png.py asset-1x.png
```

Its findings are review prompts rather than unconditional failures: a one-pixel eye may be intentional, while an unexplained floating sparkle should be removed.

Run the script tests with:

```bash
npm test
```

## License

MIT
