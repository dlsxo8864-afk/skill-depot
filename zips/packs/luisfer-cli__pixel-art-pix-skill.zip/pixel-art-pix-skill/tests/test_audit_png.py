#!/usr/bin/env python3
import importlib.util
import struct
import tempfile
import unittest
import zlib
from pathlib import Path
from typing import List, Tuple

Pixel = Tuple[int, int, int, int]
ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "skills/pixel-art-pix/scripts/audit_png.py"
SPEC = importlib.util.spec_from_file_location("audit_png", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
AUDIT_PNG = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(AUDIT_PNG)


def chunk(kind, payload):
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)


def write_rgba_png(path, rows):
    height = len(rows)
    width = len(rows[0])
    raw = b"".join(b"\x00" + b"".join(bytes(pixel) for pixel in row) for row in rows)
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    data = AUDIT_PNG.PNG_SIGNATURE + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    path.write_bytes(data)


class AuditPngTests(unittest.TestCase):
    def test_reports_detached_pixel_and_tiny_color_cluster(self):
        transparent = (0, 0, 0, 0)
        blue = (20, 80, 220, 255)
        yellow = (255, 220, 40, 255)
        rows: List[List[Pixel]] = [[transparent for _ in range(6)] for _ in range(6)]
        for y in range(2, 5):
            for x in range(2, 5):
                rows[y][x] = blue
        rows[3][3] = yellow
        rows[0][0] = yellow
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "noisy.png"
            write_rgba_png(path, rows)
            report = AUDIT_PNG.audit(path, max_detached_size=4, max_color_cluster_size=1)
        self.assertEqual(report["opaque_components"], 2)
        self.assertEqual(len(report["small_detached_components"]), 1)
        self.assertEqual(len(report["tiny_color_clusters"]), 2)
        self.assertEqual(report["edge_pixel_count"], 1)

    def test_clean_connected_asset_has_no_warnings(self):
        transparent = (0, 0, 0, 0)
        blue = (20, 80, 220, 255)
        rows: List[List[Pixel]] = [[transparent for _ in range(6)] for _ in range(6)]
        for y in range(1, 5):
            for x in range(1, 5):
                rows[y][x] = blue
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "clean.png"
            write_rgba_png(path, rows)
            report = AUDIT_PNG.audit(path, max_detached_size=4, max_color_cluster_size=1)
        self.assertEqual(report["opaque_components"], 1)
        self.assertEqual(report["warnings"], [])


if __name__ == "__main__":
    unittest.main()
