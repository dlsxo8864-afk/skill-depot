# Style: neon sign

Glass tubes on a dark brick wall that buzz and flicker on, glow onto the wall, and reflect on a wet floor.

## Signature
| # | Item |
|---|---|
| 1 | A dark brick wall with a wet floor |
| 2 | Words as neon tubes: coloured halo, glow, white-hot core |
| 3 | Tubes flicker and buzz on before they hold steady; unlit tubes show as dark glass |
| 4 | Icons, arrows, and frames bent from tube |
| 5 | Light spilling onto the wall and a reflection in the floor |
| 6 | The buzz: a click on each flicker |

## Look
- **Palette**: wall `#1b1417`; tubes pink `#ff4fa3`, cyan `#3ff0ff`, yellow `#ffe45c`, green `#6bff8a`, orange `#ff8a3d`, violet `#b56bff`. Make the brand colour the main tube.
- **Fonts**: Tilt Neon for Latin; Pretendard (light weights) for Hangul, drawn as strokes.
- **Composition**: one sign per scene, centred or offset like a shop sign; at most three tube colours at once.
