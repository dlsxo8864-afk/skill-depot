/* ============================================================================
   Diorama kernel · one global `Diorama`, no dependency: it draws SVG.

   A diorama is a small world built from blocks (boxes, cylinders, balls,
   cones) on a rounded base, seen through an orthographic isometric camera,
   in a theme. The kernel fakes the 3D the way an illustrator does: every
   solid is projected to the page, its faces are painted flat in a tone
   that depends on where they face, the pieces are painted from the back
   of the scene to the front, the shadows are the solids' outlines thrown
   onto the ground, and the ink, when a theme asks for it, is drawn over
   the top. No WebGL, no three.js, no canvas: a `<svg>` the page can style.
   The kernel gives a figure everything that is the same from one diorama
   to the next: the stage, the camera, the light, the shadows, the fit, the
   loop, the pointer, the themes, the primitives and a few props. The
   figure gives the scene and its motion.

   INDEX · what a figure may call. Do not read below the hash line.

   Diorama.figure(spec)       declare a figure; spec is:
     name      lowercase-hyphen, the file and page name
     size      'hero' | 'card' | 'mini'            (frame and detail budget)
     means     one sentence, ≤140 chars, shown under the stage
     hint      one line, ≤90 chars: what the pointer does ("Hover the boat or the lighthouse"), shown with means
     theme     'toy' (default) | 'soft' | 'mono' | 'line' | 'night' | 'print',
               or { base: 'mono', …overrides } with any of the theme fields:
                 bg          css colour | 'transparent'
                 palette     { …overrides of Diorama.PAL } (also spec.palette)
                 accent      the subject's colour in every theme, and the one colour mono and line keep (default
                             pal.coral). Paint the thing that matters with pal.accent and nothing else with it: a
                             brand hex goes here and nowhere else, and the bench's swatches recolour the subject live.
                             In mono and line a surface keeps it only when its colour is exactly this hex
                 accentFill  0..1 how much of the accent fills an accented surface in line (default .1: a tinted
                             fill inside an accent outline); raise it for a solid brand shape
                 lights      { hemi: [sky, ground, i], sun: [colour, i], fill: [colour, i] | null, ambient: [colour, i] }
                 shadows     true | false: the solids throw their outlines on the ground
                 shadow      0..1 how dark the thrown shadows are (toy .2)
                 tones       [top, lit side, dark side] → every box face takes one of three flat tones instead of the
                             lights (print); round solids keep their bands
                 tone        { paper, ink } → every colour becomes a tint between them (mono), except the accent
                 tint        0..1 how much of the original colour survives the tone (mono: 0, default)
                 edges       true → ink lines on the edges of solids (line, print)
                 stroke      the line colour; strokeWidth in css px (default 1.1)
                 glow        multiplier on emissive (night: 2.6, line: 0)
                 halo        0..1 opacity of the soft shadow the base throws on the page (toy .3, line .16, night .6;
                             0: none). It is what makes the diorama a thing on a table rather than a cut-out
                 wobble      css px of hand tremor on the ink (default 0; 1.2 is a pen, 2.5 a felt tip). Edges bow
                             and overshoot a little at the corners, like a figure drawn by hand. Only where the
                             theme draws ink (line, print, or edges on another theme)
     camera    { az: 45, el: 35.264, pad: 1.08 }    optional, degrees
     tilt      degrees the camera drifts toward the pointer, default 4 (0: none)
     still     seconds into the loop for the reduced-motion frame, default 2
     build({ D, world, pal, ctx, M })  build the scene once; return parts (any object);
                                    parts.hot = [groups the pointer may pick]; give each a .name ('boat'),
                                    the page shows it as a read-out while the pointer is on it
     tick(ctx)                      per frame; ctx.t, ctx.dt, ctx.parts, ctx.pointer, ctx.hover, ctx.pressed,
                                    ctx.active. Set ctx.read = 'truck · at the dock' (≤ 40 chars) to tell the page
                                    what the scene is doing: it shows it as the read-out when the pointer is on nothing

   Diorama.mount(fig, { el, theme, reduced, still })  mount into an element; returns ctx:
     ctx.t ctx.dt         seconds; dt is 0 on the still frame
     ctx.pointer          { x, y (−1..1), inside, down, world: Vector3|null on the ground plane }
     ctx.hover            the group under the pointer among parts.hot, or null
     ctx.pressed          the hot group under the last press (a click or a tap), or null; ctx.pressedAt its second
     ctx.active           the hot group switched on by a press, until it is pressed again or another is pressed, or
                          null: a switch. A press is how touch answers, so give a card or a hero one thing to press
     ctx.read             a line the figure writes in tick, shown as the read-out (see tick)
     ctx.tap(x, y)        press at (x, y) in −1..1, as a visitor would (the look script does)
     ctx.theme ctx.pal    the resolved theme and palette
     ctx.svg ctx.world    the drawing and the scene's root group
     ctx.fit()            refit the camera to the world (call after adding big things)
     ctx.render()         draw one frame
     ctx.step(dt)         advance the clock by hand (the look script does; a figure never needs to)
     ctx.start() ctx.stop() ctx.stillFrame()
     ctx.destroy()        stop everything, remove the drawing

   M (the maths, also Diorama.M and D.M): Vector3 (set, copy, clone, add, sub, multiplyScalar, dot, cross,
     length, normalize, lerp, applyMatrix4, transformDirection), Matrix4, Color. Every group and mesh has
     position, rotation { x, y, z }, scale, visible, name, userData, children, add(), traverse(),
     updateMatrixWorld(), localToWorld(v), getWorldPosition(v), as three.js had them.

   D (per mount toolkit, parent defaults to world):
     D.pal                           the palette in use: bg base ground grass asphalt line water sand ink steel slate mist
                                     paper cloud coral terracotta mustard sage teal plum rose cobalt cobaltSoft safety ok warn
                                     bad flame mint lilac sky wood cardboard skin leaf leafDark leafLight trunk tyre hub lampGlow,
                                     and accent; snow is ground or paper. Materials are cached and shared: clone one
                                     (D.mat(c).clone()) before changing it for a single object
     group.userData.terrain = true   ground other things stand on (a hill, a mountain): look's clash check skips it
     D.group(x, y, z, parent)        a Group placed at x, y, z
     D.box(w, h, d, c, x, y, z, parent, { shadow, mat, r, on })  on: the mesh this is set into the face of (a window
                                     in a wall, a door on a cabinet, a shelf inside a fridge): it paints right after it.
                                     Any mesh takes m.on = other
     D.rbox(w, h, d, c, x, y, z, parent, { r })  a box with rounded edges (drawn as a box; the rounding is the ink's)
     D.cyl(rt, rb, h, c, x, y, z, parent, seg)
     D.cone(r, h, c, x, y, z, parent, seg)
     D.ball(r, c, x, y, z, parent)
     D.dome(r, c, x, y, z, parent)   a half sphere, flat side down
     D.wedge(w, h, d, c, x, y, z, parent)  a gable (triangular prism along x)
     D.slab(w, d, c, x, y, z, parent, { h, r, side })  a rounded plate, the diorama base: c on top, side on the walls.
                                     Zones on it (grass, roads) are boxes that stay r inside its corners, or slabs of their own
     D.torus(r, tube, c, x, y, z, parent)
     D.wheel(r, w, c, x, y, z, parent)  a cylinder on its side, axle along z, so it rolls along x
     D.label(text, w, h, { color, bg, size, weight, font, rot })  a plane with text
     D.mat(c, opts)                  a cached material in the theme (opts: emissive, emissiveIntensity, transparent, opacity)
     props are built for the solid themes: in line, a bush or a rock is an outline with little inside; use a
     shape with flat faces (a box, a cylinder, a cone) when it has to read in line
     D.props.tree(x, z, parent, { r, kind: 'round' | 'pine' | 'tall', color, dark, light, trunk, yaw })
     D.props.bush(x, z, parent, { r, color, light })  three lobes
     D.props.rock(x, z, parent, { r, h, color, yaw })
     D.props.cloud(x, y, z, parent, { r, color })
     D.props.person(x, z, parent, { shirt, hat, skin, yaw })
     D.props.lamp(x, z, parent, { h })
     D.props.crate(x, y, z, parent, { w, h, d, color })
     D.props.pallet(x, y, z, parent, { h, color })  a wooden pallet with a load of height h (0: empty)
     D.props.cone(x, z, parent)      a traffic cone
     D.props.flag(x, z, parent, { h, color })  a pole and a flag; returns { group, pole, cloth }

   Motion (also on Diorama):
     D.clamp(v, a, b)  D.lerp(a, b, t)  D.smooth(t)  D.out(t)  D.inOut(t)
     D.phase(t, period, offset)      0..1 sawtooth
     D.wave(t, period, offset)       −1..1 sine
     D.pulse(t, period, width)       0..1, a bump once per period lasting width·period
     D.spring(k, c)                  { x, v, t, step(dt), set(x) } a damped follow
     D.apart(items, { k, c, stagger })  take a thing apart and put it back: items [{ g, x, y, z }, …], outermost first,
                                     each group moved by its vector times a sprung 0..1, one after another (stagger .06 s;
                                     closing runs the order backwards). { open(bool), step(dt), items }: in tick,
                                     a.open(ctx.hover === rocket); a.step(ctx.dt). Hover shows the inside of a thing
     D.path(points, closed, round)   polyline on the ground, points [[x, z], …], corners rounded by `round` (.5; 0 sharp): { length, at(dist) → { x, z, yaw } }
     D.place(group, path, dist)      put a group on a path, its local +x facing along it (build vehicles nose toward +x)
     D.spin(meshes, dist, r)         roll wheels by distance travelled
     D.stagger(i, from, step)        |i − from| · step
   ============================================================================ */
var Diorama = (function () {
  'use strict';
  var TAU = Math.PI * 2;
  var PAL = {
    bg: '#eceef2', base: '#e1e4ea', ground: '#f4f5f7', grass: '#cfe5cd', asphalt: '#cdd3db', line: '#ffffff', water: '#b9dbe9', sand: '#f0dcb4',
    ink: '#1f2430', steel: '#434a58', slate: '#5e6675', mist: '#8b93a3', paper: '#f8f8f6', cloud: '#e6e7ea',
    coral: '#e8714f', terracotta: '#cf6a4c', mustard: '#e9b949', sage: '#8fbf9f', teal: '#4aa3a0', plum: '#8a6fb8', rose: '#ee8fa6',
    cobalt: '#3b63d8', cobaltSoft: '#e4eafb', safety: '#e9b949', ok: '#3f9f6f', warn: '#c98a1c', bad: '#d4544a',
    flame: '#e8714f', mint: '#5fbfb4', lilac: '#9a85d6', sky: '#bcd9ea',
    wood: '#c89a64', cardboard: '#dcb782', skin: '#f1c7a0', leaf: '#6fc38a', leafDark: '#4f9f6b', leafLight: '#9ad9a6', trunk: '#a07c5b',
    tyre: '#2b2f3a', hub: '#cfd4dc', lampGlow: '#ffe3a0'
  };
  var SIZES = { hero: { aspect: 3 / 2 }, card: { aspect: 4 / 3 }, mini: { aspect: 1 } };
  var THEMES = {
    toy: { bg: '#eceef2', shadows: true, shadow: .18, tint: 1, glow: 1, strokeWidth: 1.1, halo: .3, wobble: 0,
      lights: { hemi: ['#fff8ee', '#9fb0cc', .5], sun: ['#fff3dc', .62], fill: ['#c8dbff', .26], ambient: ['#e0e7f5', .1] } },
    soft: { bg: '#f5f1ea', palette: { base: '#e9e3d9', ground: '#f8f4ed', grass: '#d9e8d2', asphalt: '#ddd7cd', paper: '#fcfaf6', cloud: '#ece7df', water: '#cfe3ea', cobalt: '#6b80c9', safety: '#eac36a', mustard: '#eac36a', flame: '#e98a66', coral: '#e98a66', terracotta: '#d98468', ok: '#6fae8a', mint: '#86c6bd', teal: '#6fb3ae', lilac: '#ab9fd9', plum: '#a08fc6', leaf: '#93cf9e', leafDark: '#73b88a', leafLight: '#b4dfb9' },
      shadows: true, shadow: .14, tint: 1, glow: .8, strokeWidth: 1.1, halo: .24, wobble: 0,
      lights: { hemi: ['#fff9f0', '#cfc5b6', .58], sun: ['#ffe8c6', .46], fill: ['#e9e1ff', .2], ambient: ['#f1ece4', .14] } },
    mono: { bg: '#e9ebf1', tone: { paper: '#ffffff', ink: '#1b2638' }, tint: 0, shadows: true, shadow: .16, glow: .6, strokeWidth: 1.1, halo: .26, wobble: 0,
      lights: { hemi: ['#ffffff', '#b9c0cf', .5], sun: ['#ffffff', .62], fill: ['#dde3f0', .26], ambient: ['#e4e8f0', .1] } },
    line: { bg: '#ffffff', tone: { paper: '#ffffff', ink: '#ffffff' }, tint: 0, edges: true, shadows: false, shadow: 0, stroke: '#1b2638', strokeWidth: 1.1, glow: 0, halo: .16, wobble: 0,
      lights: { hemi: ['#ffffff', '#ffffff', 1], sun: ['#ffffff', 0], fill: null, ambient: ['#ffffff', 0] } },
    print: { bg: '#f6f4ef', palette: { base: '#e6e2d9', ground: '#f9f7f2', paper: '#fbfaf6', cloud: '#eceae3' }, tones: [1, .9, .76], shadows: false, shadow: 0, edges: true, stroke: '#2b2a2f', strokeWidth: .9,
      tint: 1, glow: .3, halo: .26, wobble: 0,
      lights: { hemi: ['#ffffff', '#ffffff', .92], sun: ['#ffffff', .14], fill: null, ambient: ['#ffffff', .04] } },
    night: { bg: '#131726', palette: { base: '#3b4359', ground: '#4b546c', grass: '#3a6353', asphalt: '#555f78', line: '#aab3c8', water: '#2f4f6e', sand: '#8c7a5a', paper: '#5a6480', cloud: '#6b7590', sky: '#ffd98a', ink: '#0d1018', steel: '#232a38', slate: '#343c4e', cobaltSoft: '#3a4a7a', lampGlow: '#ffe3a0', leaf: '#4fae78', leafDark: '#3b9262', leafLight: '#6cc48f' },
      shadows: true, shadow: .3, tint: 1, glow: 2.6, strokeWidth: 1.1, halo: .6, wobble: 0,
      lights: { hemi: ['#7d8fbf', '#1f2435', .85], sun: ['#ffd6a0', .55], fill: ['#4a6ac8', .5], ambient: ['#3a4566', .8] } }
  };
  var figures = [];

  /* ---------- small maths ---------- */
  var clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var smooth = function (t) { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
  var out = function (t) { t = clamp(t, 0, 1); return 1 - Math.pow(1 - t, 3); };
  var inOut = function (t) { t = clamp(t, 0, 1); return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
  var phase = function (t, period, offset) { var p = (t / period + (offset || 0)) % 1; return p < 0 ? p + 1 : p; };
  var wave = function (t, period, offset) { return Math.sin(phase(t, period, offset) * TAU); };
  var pulse = function (t, period, width) { var p = phase(t, period); return p < width ? Math.sin(p / width * Math.PI) : 0; };
  var stagger = function (i, from, step) { return Math.abs(i - from) * step; };
  function spring(k, c) {
    var s = { x: 0, v: 0, t: 0, k: k || 90, c: c || 16 };
    s.step = function (dt) { var h = Math.min(dt, 1 / 30); var a = (s.t - s.x) * s.k - s.v * s.c; s.v += a * h; s.x += s.v * h; return s.x; };
    s.set = function (x) { s.x = s.t = x; s.v = 0; return s; };
    return s;
  }
  function apart(items, o) {
    /* a thing taken apart: every item's group moves along its vector by a sprung 0..1, the first item
       first and the rest one stagger later each; closing runs the order backwards, so the parts that
       left last come home first and nothing passes through anything on the way back */
    o = o || {};
    var A = { target: 0, age: 1e9, dir: 1, stagger: o.stagger == null ? .06 : o.stagger };
    A.items = items.map(function (it) { return { g: it.g, v: [it.x || 0, it.y || 0, it.z || 0], s: spring(o.k || 70, o.c || 15), b: [it.g.position.x, it.g.position.y, it.g.position.z] }; });
    A.open = function (on) { on = on ? 1 : 0; if (on !== A.target) { A.target = on; A.age = 0; A.dir = on ? 1 : -1; } return A; };
    A.step = function (dt) {
      A.age += dt;
      for (var k = 0, n = A.items.length; k < n; k++) {
        var it = A.items[k], rank = A.dir > 0 ? k : n - 1 - k;
        if (A.age >= rank * A.stagger) it.s.t = A.target;
        it.s.step(dt);
        it.g.position.set(it.b[0] + it.v[0] * it.s.x, it.b[1] + it.v[1] * it.s.x, it.b[2] + it.v[2] * it.s.x);
      }
      return A;
    };
    return A;
  }
  function path(points, closed, round) {
    /* a polyline on the ground with its corners rounded (arcs of radius `round`, .5 by default, 0 for sharp),
       so a vehicle turns instead of snapping; at(dist) gives the point and the heading there */
    var pts = points.map(function (p) { return { x: p[0], z: p[1] }; }), n = pts.length, R = round == null ? .5 : round;
    var seg = [], len = 0, i;
    function line(a, b) { var l = Math.hypot(b.x - a.x, b.z - a.z); if (l < 1e-6) return; seg.push({ a: a, b: b, l: l, s: len, yaw: Math.atan2(-(b.z - a.z), b.x - a.x) }); len += l; }
    function arc(c, r, a0, da) { var l = Math.abs(da) * r; if (l < 1e-6) return; seg.push({ c: c, r: r, a0: a0, da: da, l: l, s: len }); len += l; }
    var m = closed ? n : n - 2, cut = [];
    for (i = 0; i < n; i++) cut.push(0);
    var corners = [];
    for (i = 0; i < m; i++) {
      var k = closed ? (i + 1) % n : i + 1, P = pts[k], A = pts[(k - 1 + n) % n], B = pts[(k + 1) % n];
      var u1 = { x: P.x - A.x, z: P.z - A.z }, u2 = { x: B.x - P.x, z: B.z - P.z }, l1 = Math.hypot(u1.x, u1.z), l2 = Math.hypot(u2.x, u2.z);
      if (!l1 || !l2) continue;
      u1.x /= l1; u1.z /= l1; u2.x /= l2; u2.z /= l2;
      var cr = u1.x * u2.z - u1.z * u2.x, dot = clamp(u1.x * u2.x + u1.z * u2.z, -1, 1), th = Math.acos(dot);
      if (R <= 0 || th < .02 || th > Math.PI - .02) continue;
      var r = Math.min(R, .5 * Math.min(l1, l2) / Math.tan(th / 2)), t = r * Math.tan(th / 2), sgn = cr > 0 ? 1 : -1;
      var T1 = { x: P.x - u1.x * t, z: P.z - u1.z * t }, T2 = { x: P.x + u2.x * t, z: P.z + u2.z * t };
      var C = { x: T1.x - u1.z * sgn * r, z: T1.z + u1.x * sgn * r };
      corners[k] = { T1: T1, T2: T2, C: C, r: r, a0: Math.atan2(T1.z - C.z, T1.x - C.x), da: th * sgn };
      cut[k] = t;
    }
    var count = closed ? n : n - 1;
    for (i = 0; i < count; i++) {
      var a = pts[i], b = pts[(i + 1) % n], ca = corners[i], cb = corners[(i + 1) % n];
      if (i === 0 && closed && ca) arc(ca.C, ca.r, ca.a0, ca.da);
      line(ca ? ca.T2 : a, cb ? cb.T1 : b);
      if (cb && !(closed && (i + 1) % n === 0)) arc(cb.C, cb.r, cb.a0, cb.da);
    }
    return {
      length: len, closed: !!closed,
      at: function (d) {
        if (closed) { d = d % len; if (d < 0) d += len; } else d = clamp(d, 0, len);
        for (var i = 0; i < seg.length; i++) {
          var s = seg[i];
          if (d <= s.s + s.l || i === seg.length - 1) {
            var u = s.l ? clamp((d - s.s) / s.l, 0, 1) : 0;
            if (s.c) { var ang = s.a0 + s.da * u, sg = s.da > 0 ? 1 : -1; return { x: s.c.x + s.r * Math.cos(ang), z: s.c.z + s.r * Math.sin(ang), yaw: Math.atan2(-sg * Math.cos(ang), -sg * Math.sin(ang)) }; }
            return { x: lerp(s.a.x, s.b.x, u), z: lerp(s.a.z, s.b.z, u), yaw: s.yaw };
          }
        }
      }
    };
  }
  function place(g, p, d) { var q = p.at(d); g.position.x = q.x; g.position.z = q.z; g.rotation.y = q.yaw; return q; }
  function spin(wheels, dist, r) { var a = dist / (r || .4); for (var i = 0; i < wheels.length; i++) wheels[i].rotation.y = -a; }

  /* ---------- vectors, matrices, colours (the part of three.js a figure touched) ---------- */
  function Vector3(x, y, z) { this.x = x || 0; this.y = y || 0; this.z = z || 0; }
  Vector3.prototype = {
    isVector3: true,
    set: function (x, y, z) { this.x = x; this.y = y; this.z = z; return this; },
    setScalar: function (s) { this.x = this.y = this.z = s; return this; },
    copy: function (v) { this.x = v.x; this.y = v.y; this.z = v.z; return this; },
    clone: function () { return new Vector3(this.x, this.y, this.z); },
    add: function (v) { this.x += v.x; this.y += v.y; this.z += v.z; return this; },
    addVectors: function (a, b) { this.x = a.x + b.x; this.y = a.y + b.y; this.z = a.z + b.z; return this; },
    sub: function (v) { this.x -= v.x; this.y -= v.y; this.z -= v.z; return this; },
    subVectors: function (a, b) { this.x = a.x - b.x; this.y = a.y - b.y; this.z = a.z - b.z; return this; },
    multiplyScalar: function (s) { this.x *= s; this.y *= s; this.z *= s; return this; },
    dot: function (v) { return this.x * v.x + this.y * v.y + this.z * v.z; },
    cross: function (v) { return this.crossVectors(this, v); },
    crossVectors: function (a, b) { var x = a.y * b.z - a.z * b.y, y = a.z * b.x - a.x * b.z, z = a.x * b.y - a.y * b.x; this.x = x; this.y = y; this.z = z; return this; },
    length: function () { return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z); },
    lengthSq: function () { return this.x * this.x + this.y * this.y + this.z * this.z; },
    normalize: function () { var l = this.length() || 1; return this.multiplyScalar(1 / l); },
    distanceTo: function (v) { return Math.hypot(this.x - v.x, this.y - v.y, this.z - v.z); },
    lerp: function (v, t) { this.x += (v.x - this.x) * t; this.y += (v.y - this.y) * t; this.z += (v.z - this.z) * t; return this; },
    applyMatrix4: function (m) { var e = m.elements, x = this.x, y = this.y, z = this.z; this.x = e[0] * x + e[4] * y + e[8] * z + e[12]; this.y = e[1] * x + e[5] * y + e[9] * z + e[13]; this.z = e[2] * x + e[6] * y + e[10] * z + e[14]; return this; },
    transformDirection: function (m) { var e = m.elements, x = this.x, y = this.y, z = this.z; this.x = e[0] * x + e[4] * y + e[8] * z; this.y = e[1] * x + e[5] * y + e[9] * z; this.z = e[2] * x + e[6] * y + e[10] * z; return this.normalize(); },
    setFromMatrixPosition: function (m) { var e = m.elements; this.x = e[12]; this.y = e[13]; this.z = e[14]; return this; },
    toArray: function () { return [this.x, this.y, this.z]; }
  };
  function Euler(x, y, z) { this.x = x || 0; this.y = y || 0; this.z = z || 0; }
  Euler.prototype.set = function (x, y, z) { this.x = x; this.y = y; this.z = z; return this; };
  Euler.prototype.copy = function (e) { this.x = e.x; this.y = e.y; this.z = e.z; return this; };
  function Matrix4() { this.elements = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }
  Matrix4.prototype = {
    isMatrix4: true,
    identity: function () { var e = this.elements; e[0] = 1; e[1] = 0; e[2] = 0; e[3] = 0; e[4] = 0; e[5] = 1; e[6] = 0; e[7] = 0; e[8] = 0; e[9] = 0; e[10] = 1; e[11] = 0; e[12] = 0; e[13] = 0; e[14] = 0; e[15] = 1; return this; },
    copy: function (m) { var a = this.elements, b = m.elements; for (var i = 0; i < 16; i++) a[i] = b[i]; return this; },
    clone: function () { return new Matrix4().copy(this); },
    compose: function (p, r, s) {
      /* three's Euler order XYZ */
      var te = this.elements, a = Math.cos(r.x), b = Math.sin(r.x), c = Math.cos(r.y), d = Math.sin(r.y), e = Math.cos(r.z), f = Math.sin(r.z);
      var ae = a * e, af = a * f, be = b * e, bf = b * f;
      te[0] = c * e * s.x; te[1] = (af + be * d) * s.x; te[2] = (bf - ae * d) * s.x; te[3] = 0;
      te[4] = -c * f * s.y; te[5] = (ae - bf * d) * s.y; te[6] = (be + af * d) * s.y; te[7] = 0;
      te[8] = d * s.z; te[9] = -b * c * s.z; te[10] = a * c * s.z; te[11] = 0;
      te[12] = p.x; te[13] = p.y; te[14] = p.z; te[15] = 1;
      return this;
    },
    multiplyMatrices: function (A, B) {
      var a = A.elements, b = B.elements, t = this.elements, r = new Array(16);
      for (var i = 0; i < 4; i++) for (var j = 0; j < 4; j++) r[j * 4 + i] = a[i] * b[j * 4] + a[4 + i] * b[j * 4 + 1] + a[8 + i] * b[j * 4 + 2] + a[12 + i] * b[j * 4 + 3];
      for (var k = 0; k < 16; k++) t[k] = r[k];
      return this;
    },
    multiply: function (m) { return this.multiplyMatrices(this, m); },
    invert: function () {
      /* an affine inverse: the 3×3 by its adjugate, then the translation */
      var e = this.elements, a = e[0], b = e[4], c = e[8], d = e[1], f = e[5], g = e[9], h = e[2], i = e[6], j = e[10];
      var A = f * j - g * i, B = -(d * j - g * h), C = d * i - f * h, det = a * A + b * B + c * C;
      if (!det) return this.identity();
      var k = 1 / det, r = [A * k, B * k, C * k, -(b * j - c * i) * k, (a * j - c * h) * k, -(a * i - b * h) * k, (b * g - c * f) * k, -(a * g - c * d) * k, (a * f - b * d) * k];
      var tx = e[12], ty = e[13], tz = e[14];
      e[0] = r[0]; e[1] = r[1]; e[2] = r[2]; e[4] = r[3]; e[5] = r[4]; e[6] = r[5]; e[8] = r[6]; e[9] = r[7]; e[10] = r[8];
      e[12] = -(r[0] * tx + r[3] * ty + r[6] * tz); e[13] = -(r[1] * tx + r[4] * ty + r[7] * tz); e[14] = -(r[2] * tx + r[5] * ty + r[8] * tz);
      return this;
    }
  };
  function Color(c, g, b) { this.r = 1; this.g = 1; this.b = 1; if (c !== undefined) this.set(c, g, b); }
  Color.prototype = {
    isColor: true,
    set: function (c, g, b) {
      if (c && c.isColor) { this.r = c.r; this.g = c.g; this.b = c.b; }
      else if (typeof c === 'number' && g === undefined) { this.r = ((c >> 16) & 255) / 255; this.g = ((c >> 8) & 255) / 255; this.b = (c & 255) / 255; }
      else if (typeof c === 'number') { this.r = c; this.g = g; this.b = b; }
      else if (typeof c === 'string') { var s = c.replace('#', ''); if (s.length === 3) s = s[0] + s[0] + s[1] + s[1] + s[2] + s[2]; var n = parseInt(s, 16); this.r = ((n >> 16) & 255) / 255; this.g = ((n >> 8) & 255) / 255; this.b = (n & 255) / 255; }
      return this;
    },
    copy: function (c) { this.r = c.r; this.g = c.g; this.b = c.b; return this; },
    clone: function () { return new Color().copy(this); },
    lerp: function (c, t) { this.r += (c.r - this.r) * t; this.g += (c.g - this.g) * t; this.b += (c.b - this.b) * t; return this; },
    multiplyScalar: function (s) { this.r *= s; this.g *= s; this.b *= s; return this; },
    getHex: function () { return (Math.round(clamp(this.r, 0, 1) * 255) << 16) ^ (Math.round(clamp(this.g, 0, 1) * 255) << 8) ^ Math.round(clamp(this.b, 0, 1) * 255); },
    getHexString: function () { return ('000000' + this.getHex().toString(16)).slice(-6); },
    getStyle: function () { return '#' + this.getHexString(); },
    convertSRGBToLinear: function () { this.r = toLin(this.r); this.g = toLin(this.g); this.b = toLin(this.b); return this; },
    convertLinearToSRGB: function () { this.r = toSRGB(this.r); this.g = toSRGB(this.g); this.b = toSRGB(this.b); return this; }
  };
  function toLin(c) { return c < .04045 ? c * .0773993808 : Math.pow(c * .9478672986 + .0521327014, 2.4); }
  function toSRGB(c) { return c < .0031308 ? c * 12.92 : 1.055 * Math.pow(c, .41666) - .055; }
  function hexOf(c) { return (typeof c === 'string' ? (c.length === 4 ? '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3] : c) : '#' + c.getHexString()).toLowerCase(); }
  function luma(col) { return .2126 * col.r + .7152 * col.g + .0722 * col.b; }
  var M = { Vector3: Vector3, Matrix4: Matrix4, Color: Color, Euler: Euler };

  /* ---------- the scene: groups, meshes, materials ---------- */
  var nextId = 1;
  function Object3D() {
    this.id = nextId++; this.name = ''; this.type = 'Object3D'; this.parent = null; this.children = [];
    this.position = new Vector3(); this.rotation = new Euler(); this.scale = new Vector3(1, 1, 1);
    this.visible = true; this.userData = {}; this.matrix = new Matrix4(); this.matrixWorld = new Matrix4();
    this.castShadow = false; this.receiveShadow = false; this.renderOrder = 0;
  }
  Object3D.prototype = {
    isObject3D: true,
    add: function (o) { if (o.parent) o.parent.remove(o); o.parent = this; this.children.push(o); return this; },
    remove: function (o) { var i = this.children.indexOf(o); if (i >= 0) { this.children.splice(i, 1); o.parent = null; } return this; },
    traverse: function (fn) { fn(this); for (var i = 0; i < this.children.length; i++) this.children[i].traverse(fn); },
    updateMatrix: function () { this.matrix.compose(this.position, this.rotation, this.scale); },
    updateTree: function () {
      this.updateMatrix();
      if (this.parent) this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix); else this.matrixWorld.copy(this.matrix);
      for (var i = 0; i < this.children.length; i++) this.children[i].updateTree();
    },
    updateMatrixWorld: function () { if (this.parent) this.parent.updateWorldMatrix(); this.updateTree(); },
    updateWorldMatrix: function () { var chain = [], o = this; while (o) { chain.unshift(o); o = o.parent; } for (var i = 0; i < chain.length; i++) { chain[i].updateMatrix(); if (chain[i].parent) chain[i].matrixWorld.multiplyMatrices(chain[i].parent.matrixWorld, chain[i].matrix); else chain[i].matrixWorld.copy(chain[i].matrix); } },
    localToWorld: function (v) { return v.applyMatrix4(this.matrixWorld); },
    worldToLocal: function (v) { return v.applyMatrix4(new Matrix4().copy(this.matrixWorld).invert()); },
    getWorldPosition: function (v) { this.updateWorldMatrix(); return (v || new Vector3()).setFromMatrixPosition(this.matrixWorld); }
  };
  function Group() { Object3D.call(this); this.type = 'Group'; }
  Group.prototype = Object.create(Object3D.prototype); Group.prototype.isGroup = true;
  function Mesh(geometry, material) { Object3D.call(this); this.type = 'Mesh'; this.geometry = geometry; this.material = material; this.castShadow = true; this.receiveShadow = true; }
  Mesh.prototype = Object.create(Object3D.prototype); Mesh.prototype.isMesh = true;
  function Material(o) { this.isMaterial = true; this.color = new Color(0xffffff); this.emissive = new Color(0); this.emissiveIntensity = 1; this.transparent = false; this.opacity = 1; this.visible = true; this.userData = {}; this.lit = true; if (o) for (var k in o) { if (this[k] && this[k].isColor) this[k].set(o[k]); else this[k] = o[k]; } }
  Material.prototype.clone = function () { var m = new Material(); for (var k in this) if (k !== 'userData') m[k] = this[k] && this[k].isColor ? this[k].clone() : this[k]; m.userData = JSON.parse(JSON.stringify(this.userData)); return m; };

  /* geometries: a type (named as three named them, for the look script), its parameters and its local bounds */
  function geo(type, p, bb) { p.type = type; p.boundingBox = { min: new Vector3(bb[0], bb[1], bb[2]), max: new Vector3(bb[3], bb[4], bb[5]) }; return p; }

  /* ---------- themes and colour ---------- */
  function resolveTheme(spec, fig) {
    var t = spec || fig.theme || 'toy', base = typeof t === 'string' ? t : (t.base || 'toy');
    var src = THEMES[base] || THEMES.toy, o = {};
    Object.keys(src).forEach(function (k) { o[k] = src[k]; });
    if (typeof t === 'object') Object.keys(t).forEach(function (k) { if (k !== 'base') o[k] = t[k]; });
    o.name = base;
    o.palette = Object.assign({}, src.palette || {}, fig.palette || {}, (typeof t === 'object' && t.palette) || {});
    o.lights = Object.assign({}, src.lights, (typeof t === 'object' && t.lights) || {});
    return o;
  }

  /* ---------- toolkit, one per mount ---------- */
  function toolkit(world, pal, ctx) {
    var MATS = {}, theme = ctx.theme;
    var accent = hexOf(theme.accent || pal.accent || pal.coral), paperC = theme.tone ? new Color(theme.tone.paper) : null, inkC = theme.tone ? new Color(theme.tone.ink) : null;
    /* the colour a surface really gets: toned to paper/ink in mono and line, except the accent */
    function toned(c) {
      var col = new Color(c), isAccent = hexOf(c) === accent;
      if (theme.tone && !isAccent) { var L = luma(col), tint = theme.tint || 0; var t2 = paperC.clone().lerp(inkC, 1 - L); col = t2.lerp(col, tint); }
      if (theme.tone && isAccent && theme.edges) col = paperC.clone().lerp(col, theme.accentFill == null ? .1 : theme.accentFill);
      return col;
    }
    function mat(c, o) {
      if (c && c.isMaterial) return c;
      var k = c + (o ? JSON.stringify(o) : '');
      if (!MATS[k]) {
        var opts = Object.assign({}, o || {}), m = new Material();
        m.color = toned(c); m.src = c; m.accent = hexOf(c) === accent;
        if (opts.emissive) { m.emissive = toned(opts.emissive); m.emissiveIntensity = (opts.emissiveIntensity == null ? 1 : opts.emissiveIntensity) * (theme.glow == null ? 1 : theme.glow); }
        if (opts.transparent) { m.transparent = true; m.opacity = opts.opacity == null ? 1 : opts.opacity; }
        m.userData.glow = theme.glow == null ? 1 : theme.glow;
        MATS[k] = m;
      }
      return MATS[k];
    }
    function mesh(g, c, x, y, z, parent, o) {
      var m = new Mesh(g, mat(c, o && o.mat));
      m.position.set(x || 0, y || 0, z || 0); m.castShadow = !(o && o.shadow === false); m.receiveShadow = true;
      if (o && o.shadow === false) m.userData.mark = true;
      if (o && o.on) m.on = o.on;
      (parent || world).add(m); return m;
    }
    var D = {
      pal: pal, M: M, theme: theme, clamp: clamp, lerp: lerp, smooth: smooth, out: out, inOut: inOut, phase: phase, wave: wave, pulse: pulse,
      spring: spring, apart: apart, path: path, place: place, spin: spin, stagger: stagger, mat: mat,
      group: function (x, y, z, parent) { var g = new Group(); g.position.set(x || 0, y || 0, z || 0); (parent || world).add(g); return g; },
      box: function (w, h, d, c, x, y, z, parent, o) { return mesh(geo('BoxGeometry', { w: w, h: h, d: d, r: o && o.r ? o.r : 0 }, [-w / 2, -h / 2, -d / 2, w / 2, h / 2, d / 2]), c, x, y, z, parent, o); },
      rbox: function (w, h, d, c, x, y, z, parent, o) { o = o || {}; return mesh(geo('BoxGeometry', { w: w, h: h, d: d, r: o.r || Math.min(w, h, d) * .22 }, [-w / 2, -h / 2, -d / 2, w / 2, h / 2, d / 2]), c, x, y, z, parent, o); },
      cyl: function (rt, rb, h, c, x, y, z, parent, seg) { var r = Math.max(rt, rb); return mesh(geo('CylinderGeometry', { rt: rt, rb: rb, h: h, seg: seg || 18 }, [-r, -h / 2, -r, r, h / 2, r]), c, x, y, z, parent); },
      cone: function (r, h, c, x, y, z, parent, seg) { return mesh(geo('ConeGeometry', { r: r, h: h, seg: seg || 18 }, [-r, -h / 2, -r, r, h / 2, r]), c, x, y, z, parent); },
      ball: function (r, c, x, y, z, parent) { return mesh(geo('SphereGeometry', { r: r }, [-r, -r, -r, r, r, r]), c, x, y, z, parent); },
      dome: function (r, c, x, y, z, parent) { return mesh(geo('SphereGeometry', { r: r, dome: true }, [-r, 0, -r, r, r, r]), c, x, y, z, parent); },
      torus: function (r, tube, c, x, y, z, parent) { return mesh(geo('TorusGeometry', { r: r, tube: tube }, [-r - tube, -r - tube, -tube, r + tube, r + tube, tube]), c, x, y, z, parent); },
      wheel: function (r, w, c, x, y, z, parent) { var m = D.cyl(r, r, w, c || pal.tyre, x, y, z, parent, 18); m.rotation.x = Math.PI / 2; return m; },
      wedge: function (w, h, d, c, x, y, z, parent) { return mesh(geo('ExtrudeGeometry', { wedge: true, w: w, h: h, d: d }, [-w / 2, 0, -d / 2, w / 2, h, d / 2]), c, x, y, z, parent); },
      slab: function (w, d, c, x, y, z, parent, o) {
        o = o || {}; var h = o.h || .5, r = o.r == null ? Math.min(w, d) * .06 : o.r;
        var m = mesh(geo('ExtrudeGeometry', { slab: true, w: w, d: d, h: h, r: Math.min(r, w / 2, d / 2) }, [-w / 2, -h, -d / 2, w / 2, 0, d / 2]), c || pal.base, x, y, z, parent, { shadow: false });
        m.userData.slab = true; m.userData.mark = false;
        if (o.side) m.side = mat(o.side);
        if (theme.halo > 0 && o.halo !== false && !ctx.halo) ctx.halo = m;
        return m;
      },
      label: function (text, w, h, o) {
        o = o || {}; var m = mesh(geo('PlaneGeometry', { label: true, w: w, h: h, text: text, color: hexOf(toned(o.color || pal.ink)), bg: o.bg ? hexOf(toned(o.bg)) : null, size: o.size, weight: o.weight || 800, font: o.font || '"Bricolage Grotesque", Figtree, system-ui, sans-serif' }, [-w / 2, -h / 2, -.001, w / 2, h / 2, .001]), o.bg || pal.paper, 0, 0, 0, null, { shadow: false });
        world.remove(m); if (o.rot) { m.rotation.x = o.rot[0] || 0; m.rotation.y = o.rot[1] || 0; m.rotation.z = o.rot[2] || 0; } return m;
      },
      props: {}
    };
    var P = D.props;
    P.tree = function (x, z, parent, o) {
      o = o || {}; var r = o.r || .7, kind = o.kind || 'round', g = D.group(x, 0, z, parent), c = o.color || pal.leaf, dk = o.dark || pal.leafDark, lt = o.light || pal.leafLight;
      g.rotation.y = o.yaw || 0;
      if (kind === 'pine') {
        D.cyl(.08, .12, r * 1.1, o.trunk || pal.trunk, 0, r * .5, 0, g, 8);
        D.cone(r, r * 1.2, dk, 0, r * 1.3, 0, g, 12); D.cone(r * .8, r * 1.1, c, 0, r * 1.95, 0, g, 12); D.cone(r * .55, r * 1, lt, 0, r * 2.6, 0, g, 12);
      } else if (kind === 'tall') {
        D.cyl(.08, .12, r * 1.3, o.trunk || pal.trunk, 0, r * .6, 0, g, 8);
        var e = D.ball(r * .75, c, 0, r * 2.1, 0, g); e.scale.y = 1.7;
        var e2 = D.ball(r * .45, lt, r * .2, r * 2.9, -r * .15, g); e2.scale.y = 1.3;
      } else {
        D.cyl(.1, .14, r * 1.2, o.trunk || pal.trunk, 0, r * .55, 0, g, 8);
        var m = D.ball(r, c, 0, r * 1.5, 0, g); m.scale.y = .9;
        var side = D.ball(r * .68, dk, -r * .5, r * 1.25, r * .35, g); side.scale.y = .85;
        D.ball(r * .55, lt, r * .3, r * 2.05, -r * .15, g);
      }
      return g;
    };
    P.bush = function (x, z, parent, o) {
      o = o || {}; var r = o.r || .4, g = D.group(x, 0, z, parent), c = o.color || pal.leafDark;
      var a = D.ball(r, c, 0, r * .6, 0, g); a.scale.y = .75;
      var b = D.ball(r * .7, o.light || pal.leaf, r * .6, r * .45, r * .25, g); b.scale.y = .75;
      var d = D.ball(r * .55, c, -r * .5, r * .38, -r * .3, g); d.scale.y = .75;
      return g;
    };
    P.rock = function (x, z, parent, o) { o = o || {}; var r = o.r || .4; var m = D.dome(r, o.color || pal.mist, x, 0, z, parent); m.scale.set(1, o.h || .6, .8); m.rotation.y = o.yaw || .6; return m; };
    P.cloud = function (x, y, z, parent, o) {
      o = o || {}; var r = o.r || .8, g = D.group(x, y, z, parent), c = o.color || pal.paper;
      var a = D.ball(r, c, 0, 0, 0, g); a.scale.y = .7; a.castShadow = false;
      var b = D.ball(r * .7, c, r * .9, -r * .1, r * .1, g); b.scale.y = .7; b.castShadow = false;
      var d = D.ball(r * .6, c, -r * .85, -r * .15, -r * .05, g); d.scale.y = .7; d.castShadow = false;
      return g;
    };
    P.person = function (x, z, parent, o) {
      o = o || {}; var g = D.group(x, 0, z, parent); g.rotation.y = o.yaw || 0;
      D.cyl(.17, .21, .5, o.shirt || pal.teal, 0, .27, 0, g, 12);
      D.cyl(.1, .1, .14, pal.ink, -.08, .07, 0, g, 8); D.cyl(.1, .1, .14, pal.ink, .08, .07, 0, g, 8);
      D.ball(.15, o.skin || pal.skin, 0, .68, 0, g);
      if (o.hat !== false) D.dome(.165, o.hat || pal.safety, 0, .72, 0, g);
      return g;
    };
    P.lamp = function (x, z, parent, o) {
      o = o || {}; var h = o.h || 3.2, g = D.group(x, 0, z, parent);
      D.cyl(.06, .08, h, pal.slate, 0, h / 2, 0, g, 8);
      D.box(.7, .13, .28, pal.paper, .25, h, 0, g);
      D.box(.5, .04, .2, pal.lampGlow, .25, h - .08, 0, g, { mat: { emissive: pal.lampGlow, emissiveIntensity: .5 }, shadow: false });
      return g;
    };
    P.crate = function (x, y, z, parent, o) {
      o = o || {}; var w = o.w || .9, h = o.h || .8, d = o.d || .9, g = D.group(x, y, z, parent);
      D.box(w, h, d, o.color || pal.cardboard, 0, h / 2, 0, g);
      D.box(w * .22, .012, d + .01, pal.paper, 0, h + .006, 0, g, { shadow: false });
      D.box(.012, h * .3, d * .32, pal.paper, w / 2 + .005, h * .55, 0, g, { shadow: false });
      return g;
    };
    P.pallet = function (x, y, z, parent, o) {
      o = o || {}; var h = o.h == null ? .9 : o.h, g = D.group(x, y, z, parent);
      D.box(1.1, .08, 1.1, pal.wood, 0, .11, 0, g);
      [-.42, 0, .42].forEach(function (zz) { D.box(1.1, .07, .14, pal.wood, 0, .035, zz, g); });
      if (h > 0) { D.box(1, h, 1, o.color || pal.cardboard, 0, .15 + h / 2, 0, g); D.box(.22, .012, 1.01, pal.paper, 0, .156 + h, 0, g, { shadow: false }); }
      return g;
    };
    P.cone = function (x, z, parent) { var g = D.group(x, 0, z, parent); D.box(.36, .04, .36, pal.flame, 0, .02, 0, g); D.cone(.16, .5, pal.flame, 0, .29, 0, g, 12); D.cyl(.1, .12, .06, pal.paper, 0, .3, 0, g, 12); return g; };
    P.flag = function (x, z, parent, o) {
      o = o || {}; var h = o.h || 2.4, g = D.group(x, 0, z, parent);
      var pole = D.cyl(.04, .05, h, pal.slate, 0, h / 2, 0, g, 8);
      var cloth = D.box(.8, .5, .03, o.color || pal.coral, .42, h - .3, 0, g);
      return { group: g, pole: pole, cloth: cloth };
    };
    return D;
  }

  /* ########################################################################## */

  /* ---------- the drawing: an isometric camera, flat faces, painter's order, SVG ---------- */
  var NS = 'http://www.w3.org/2000/svg';
  function el(tag, attrs, parent) { var e = document.createElementNS(NS, tag); if (attrs) for (var k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; }
  function f2(v) { return Math.round(v * 100) / 100; }
  function hull(pts) {
    /* a 2D convex hull (monotone chain) of [x, y] points */
    if (pts.length < 4) return pts;
    pts = pts.slice().sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
    var cross = function (o, a, b) { return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]); };
    var lower = [], upper = [], i;
    for (i = 0; i < pts.length; i++) { while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], pts[i]) <= 0) lower.pop(); lower.push(pts[i]); }
    for (i = pts.length - 1; i >= 0; i--) { while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], pts[i]) <= 0) upper.pop(); upper.push(pts[i]); }
    lower.pop(); upper.pop(); return lower.concat(upper);
  }
  function poly(pts) { var s = 'M'; for (var i = 0; i < pts.length; i++) s += (i ? 'L' : '') + f2(pts[i][0]) + ' ' + f2(pts[i][1]); return s + 'Z'; }
  function polyline(pts, closed) { var s = 'M'; for (var i = 0; i < pts.length; i++) s += (i ? 'L' : '') + f2(pts[i][0]) + ' ' + f2(pts[i][1]); return closed ? s + 'Z' : s; }

  function Camera() { this.az = 45; this.el = 35.264; this.R = new Vector3(); this.U = new Vector3(); this.F = new Vector3(); this.key = ''; this.set(45, 35.264); }
  Camera.prototype.set = function (azDeg, elDeg) {
    var az = azDeg * Math.PI / 180, e = elDeg * Math.PI / 180;
    this.az = azDeg; this.el = elDeg;
    this.F.set(-Math.sin(az) * Math.cos(e), -Math.sin(e), -Math.cos(az) * Math.cos(e));
    this.R.set(Math.cos(az), 0, -Math.sin(az));
    this.U.crossVectors(this.R, this.F).normalize();
    this.key = f2(azDeg * 10) + '/' + f2(elDeg * 10);
  };
  Camera.prototype.project = function (x, y, z) { return [x * this.R.x + z * this.R.z, -(x * this.U.x + y * this.U.y + z * this.U.z)]; };
  Camera.prototype.depth = function (x, y, z) { return x * this.F.x + y * this.F.y + z * this.F.z; };

  /* the light: a sun from the front-left and above, a cool fill from the back-right (the directions the old look had) */
  var SUN = new Vector3(-.7, 1.5, 1.1).normalize(), FILL = new Vector3(1.2, .6, -.9).normalize();

  function Painter(svg, ctx) {
    var theme = ctx.theme, pal = ctx.pal, cam = ctx.cam, ink = theme.stroke || pal.ink, uid = 'd' + ctx.id;
    var defs = el('defs', null, svg);
    var blur = el('filter', { id: uid + 'blur', x: '-50%', y: '-50%', width: '200%', height: '200%' }, defs);
    var blurFx = el('feGaussianBlur', { stdDeviation: 1 }, blur);
    var clip = el('clipPath', { id: uid + 'ground' }, defs);
    var haloG = el('g', { 'class': 'halo', 'pointer-events': 'none' }, svg);
    var groundG = el('g', { 'class': 'ground' }, svg);
    var shadowG = el('g', { 'class': 'shadows', 'pointer-events': 'none', 'clip-path': 'url(#' + uid + 'ground)' }, svg);
    var sceneG = el('g', { 'class': 'scene' }, svg);
    var L = theme.lights, hemiSky = new Color(L.hemi[0]).convertSRGBToLinear().multiplyScalar(L.hemi[2]), hemiGround = new Color(L.hemi[1]).convertSRGBToLinear().multiplyScalar(L.hemi[2]);
    var sunC = new Color(L.sun[0]).convertSRGBToLinear().multiplyScalar(L.sun[1]), fillC = L.fill ? new Color(L.fill[0]).convertSRGBToLinear().multiplyScalar(L.fill[1]) : null, ambC = new Color(L.ambient[0]).convertSRGBToLinear().multiplyScalar(L.ambient[1]);
    var linCache = {};
    function linear(col) { var k = col.getHexString(); return linCache[k] || (linCache[k] = [toLin(col.r), toLin(col.g), toLin(col.b)]); }
    function shadeKey(m, n) { return m.color.getHexString() + m.emissive.getHexString() + f2(m.emissiveIntensity) + '|' + f2(n[0]) + ',' + f2(n[1]) + ',' + f2(n[2]); }
    var shadeCache = {};
    /* the colour of a face: its albedo lit by the four lights for its normal, or one of the theme's flat tones */
    function shade(m, n) {
      if (!theme.lights || theme.name === 'line') return '#' + m.color.getHexString();
      var k = shadeKey(m, n); if (shadeCache[k]) return shadeCache[k];
      var a = linear(m.color), r, g, b;
      if (theme.tones) {
        var t = n[1] > .7 ? theme.tones[0] : (n[0] * SUN.x + n[1] * SUN.y + n[2] * SUN.z) > 0 ? theme.tones[1] : theme.tones[2];
        var ir = toLin(t); r = a[0] * ir; g = a[1] * ir; b = a[2] * ir;
      } else {
        var up = .5 * n[1] + .5, ds = Math.max(n[0] * SUN.x + n[1] * SUN.y + n[2] * SUN.z, 0), df = fillC ? Math.max(n[0] * FILL.x + n[1] * FILL.y + n[2] * FILL.z, 0) : 0;
        r = a[0] * (ambC.r + hemiGround.r + (hemiSky.r - hemiGround.r) * up + sunC.r * ds + (fillC ? fillC.r * df : 0));
        g = a[1] * (ambC.g + hemiGround.g + (hemiSky.g - hemiGround.g) * up + sunC.g * ds + (fillC ? fillC.g * df : 0));
        b = a[2] * (ambC.b + hemiGround.b + (hemiSky.b - hemiGround.b) * up + sunC.b * ds + (fillC ? fillC.b * df : 0));
      }
      if (m.emissiveIntensity && (m.emissive.r || m.emissive.g || m.emissive.b)) { var e = linear(m.emissive), ei = m.emissiveIntensity; r += e[0] * ei; g += e[1] * ei; b += e[2] * ei; }
      var out = '#' + new Color(toSRGB(clamp(r, 0, 1)), toSRGB(clamp(g, 0, 1)), toSRGB(clamp(b, 0, 1))).getHexString();
      shadeCache[k] = out; return out;
    }
    function strokeOf(m) { return theme.edges ? (m.accent ? '#' + new Color(m.src).getHexString() : ink) : null; }

    var W = []; /* scratch world points */
    function worldPts(local, e) {
      var out = new Array(local.length);
      for (var i = 0; i < local.length; i++) { var p = local[i], x = p[0], y = p[1], z = p[2]; out[i] = [e[0] * x + e[4] * y + e[8] * z + e[12], e[1] * x + e[5] * y + e[9] * z + e[13], e[2] * x + e[6] * y + e[10] * z + e[14]]; }
      return out;
    }
    function normalOf(a, b, c) {
      var ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
      var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, l = Math.hypot(nx, ny, nz) || 1;
      return [-nx / l, -ny / l, -nz / l]; /* the face lists run clockwise seen from outside, so the cross points in; flip it */
    }
    function facing(n) { return n[0] * cam.F.x + n[1] * cam.F.y + n[2] * cam.F.z < -1e-4; }
    function proj(p) { return cam.project(p[0], p[1], p[2]); }

    /* polyhedra: local vertices and faces (indices, counter-clockwise from outside) */
    function boxVerts(g) { var w = g.w / 2, h = g.h / 2, d = g.d / 2; return [[-w, -h, -d], [w, -h, -d], [w, h, -d], [-w, h, -d], [-w, -h, d], [w, -h, d], [w, h, d], [-w, h, d]]; }
    var BOX_FACES = [[1, 5, 6, 2], [4, 0, 3, 7], [3, 2, 6, 7], [4, 5, 1, 0], [5, 4, 7, 6], [0, 1, 2, 3]];
    function wedgeVerts(g) { var w = g.w / 2, d = g.d / 2; return [[-w, 0, -d], [-w, 0, d], [-w, g.h, 0], [w, 0, -d], [w, 0, d], [w, g.h, 0]]; }
    var WEDGE_FACES = [[0, 2, 1], [3, 4, 5], [1, 2, 5, 4], [0, 3, 5, 2], [0, 1, 4, 3]];
    function slabOutline(g) {
      var w = g.w / 2, d = g.d / 2, r = g.r, pts = [], N = 6, k;
      var corner = function (cx, cz, a0) { for (k = 0; k <= N; k++) { var a = a0 + k / N * Math.PI / 2; pts.push([cx + r * Math.cos(a), cz + r * Math.sin(a)]); } };
      corner(w - r, d - r, 0); corner(-w + r, d - r, Math.PI / 2); corner(-w + r, -d + r, Math.PI); corner(w - r, -d + r, 3 * Math.PI / 2);
      return pts;
    }
    function ring(r, y, seg, out) { for (var i = 0; i < seg; i++) { var a = i / seg * TAU; out.push([r * Math.cos(a), y, r * Math.sin(a)]); } return out; }

    /* a drawable: the painted paths of one mesh for this camera and pose */
    function draw(m) {
      var g = m.geometry, e = m.matrixWorld.elements, mt = m.material, d = { faces: [], edges: [], shadow: null, special: null, depth: 0 };
      var fillOf = function (n) { return shade(mt, n); };
      var stroke = strokeOf(mt), wob = theme.wobble || 0;
      if (g.type === 'BoxGeometry' || (g.type === 'ExtrudeGeometry' && g.wedge)) {
        var V = worldPts(g.wedge ? wedgeVerts(g) : boxVerts(g), e), F = g.wedge ? WEDGE_FACES : BOX_FACES, seen = {}, i, j;
        for (i = 0; i < F.length; i++) {
          var f = F[i], n = normalOf(V[f[0]], V[f[1]], V[f[2]]);
          if (!facing(n)) continue;
          var pts = []; for (j = 0; j < f.length; j++) pts.push(proj(V[f[j]]));
          d.faces.push({ d: poly(pts), fill: fillOf(n) });
          if (stroke) for (j = 0; j < f.length; j++) { var a = f[j], b = f[(j + 1) % f.length], key = a < b ? a + '-' + b : b + '-' + a; if (!seen[key]) { seen[key] = 1; d.edges.push([proj(V[a]), proj(V[b])]); } }
        }
        if (m.castShadow) d.shadowPts = V;
        d.depth = depthOf(V); bounds(d, V);
      } else if (g.type === 'CylinderGeometry' || g.type === 'ConeGeometry') {
        var seg = g.seg, top = [], bot = [], h = g.h;
        if (g.type === 'ConeGeometry') { top = [[0, h / 2, 0]]; ring(g.r, -h / 2, seg, bot); } else { ring(g.rt, h / 2, seg, top); ring(g.rb, -h / 2, seg, bot); }
        var T = worldPts(top, e), B = worldPts(bot, e), cone = g.type === 'ConeGeometry', vis = [], bands = [], k;
        for (k = 0; k < seg; k++) {
          var k2 = (k + 1) % seg, t0 = cone ? T[0] : T[k], t1 = cone ? T[0] : T[k2];
          var nb = cone ? normalOf(B[k], B[k2], T[0]) : normalOf(B[k], B[k2], T[k2]);
          vis.push(facing(nb)); bands.push({ pts: cone ? [B[k], B[k2], T[0]] : [B[k], B[k2], t1, t0], n: nb });
        }
        var topN = cone ? null : normalOf(T[0], T[1], T[2]), botN = normalOf(B[0], B[2], B[1]), topVis = topN && facing(topN), botVis = facing(botN);
        if (botVis) d.faces.push({ d: poly(B.map(proj)), fill: fillOf(botN) });
        /* the visible side as one shape with a gradient across its bands, so a round thing shades smoothly like a
           turned part, not in stripes; a run too short to shade, or a side seen from inside, keeps its bands */
        var run = runOf(vis, seg);
        if (run.length >= 3) {
          var sidePts = [], q6, last = (run[run.length - 1] + 1) % seg;
          for (q6 = 0; q6 < run.length; q6++) sidePts.push(proj(B[run[q6]]));
          sidePts.push(proj(B[last]));
          if (cone) sidePts.push(proj(T[0])); else { sidePts.push(proj(T[last])); for (q6 = run.length - 1; q6 >= 0; q6--) sidePts.push(proj(T[run[q6]])); }
          var mid = function (kk) { var bq = B[kk], tq = cone ? T[0] : T[kk]; return proj([(bq[0] + tq[0]) / 2, (bq[1] + tq[1]) / 2, (bq[2] + tq[2]) / 2]); };
          var g0 = mid(run[0]), g1 = mid(last), gx = g1[0] - g0[0], gy = g1[1] - g0[1], gl = gx * gx + gy * gy || 1, stops = [];
          for (q6 = 0; q6 < run.length; q6++) { var pb = bands[run[q6]].pts, bx = 0, by = 0, bz = 0; for (var q7 = 0; q7 < pb.length; q7++) { bx += pb[q7][0]; by += pb[q7][1]; bz += pb[q7][2]; } var bm = proj([bx / pb.length, by / pb.length, bz / pb.length]); stops.push([clamp(((bm[0] - g0[0]) * gx + (bm[1] - g0[1]) * gy) / gl, 0, 1), fillOf(bands[run[q6]].n)]); }
          d.faces.push({ d: poly(sidePts), fill: stops[Math.floor(stops.length / 2)][1], grad: theme.name === 'line' ? null : { x1: g0[0], y1: g0[1], x2: g1[0], y2: g1[1], stops: stops } });
        } else for (k = 0; k < seg; k++) if (vis[k]) d.faces.push({ d: poly(bands[k].pts.map(proj)), fill: fillOf(bands[k].n) });
        if (topVis) d.faces.push({ d: poly(T.map(proj)), fill: fillOf(topN) });
        if (stroke) {
          for (k = 0; k < seg; k++) { var prev = vis[(k - 1 + seg) % seg]; if (vis[k] !== prev) d.edges.push([proj(B[k]), proj(cone ? T[0] : T[k])]); }
          if (topVis && !cone) d.edges.push(T.map(proj).concat([proj(T[0])])); else if (!cone) d.edges.push(rimArc(T, vis, seg));
          if (botVis) d.edges.push(B.map(proj).concat([proj(B[0])])); else d.edges.push(rimArc(B, vis, seg));
        }
        var allPts = T.concat(B); if (m.castShadow) d.shadowPts = allPts; d.depth = depthOf(allPts); bounds(d, allPts);
      } else if (g.type === 'SphereGeometry') {
        var r = g.r, cx = e[12], cy = e[13], cz = e[14];
        /* the ellipse this (scaled) sphere projects to: the 2×3 of camera rows times the matrix's 3×3 */
        var ax = [e[0] * r, e[1] * r, e[2] * r], ay = [e[4] * r, e[5] * r, e[6] * r], az = [e[8] * r, e[9] * r, e[10] * r];
        var R = cam.R, U = cam.U;
        var b00 = ax[0] * R.x + ax[2] * R.z, b01 = ay[0] * R.x + ay[2] * R.z, b02 = az[0] * R.x + az[2] * R.z;
        var b10 = -(ax[0] * U.x + ax[1] * U.y + ax[2] * U.z), b11 = -(ay[0] * U.x + ay[1] * U.y + ay[2] * U.z), b12 = -(az[0] * U.x + az[1] * U.y + az[2] * U.z);
        var c00 = b00 * b00 + b01 * b01 + b02 * b02, c01 = b00 * b10 + b01 * b11 + b02 * b12, c11 = b10 * b10 + b11 * b11 + b12 * b12;
        var tr = c00 + c11, det = c00 * c11 - c01 * c01, disc = Math.sqrt(Math.max(tr * tr / 4 - det, 0)), l1 = tr / 2 + disc, l2 = Math.max(tr / 2 - disc, 1e-9);
        var A = Math.sqrt(l1), Bq = Math.sqrt(l2), phi = Math.abs(c01) < 1e-9 ? (c00 >= c11 ? 0 : Math.PI / 2) : Math.atan2(l1 - c00, c01);
        var c2 = proj([cx, cy, cz]), cs = Math.cos(phi), sn = Math.sin(phi);
        var sp = { cx: c2[0], cy: c2[1], a: A, b: Bq, phi: phi, matrix: [A * cs, A * sn, -Bq * sn, Bq * cs, c2[0], c2[1]] };
        /* the light on the disc: the sun's direction in the unit disc's frame, through the inverse of that matrix */
        var ls = [SUN.x * R.x + SUN.z * R.z, -(SUN.x * U.x + SUN.y * U.y + SUN.z * U.z)], idet = 1 / (sp.matrix[0] * sp.matrix[3] - sp.matrix[1] * sp.matrix[2]);
        var lu = [(sp.matrix[3] * ls[0] - sp.matrix[2] * ls[1]) * idet, (-sp.matrix[1] * ls[0] + sp.matrix[0] * ls[1]) * idet], ll = Math.hypot(lu[0], lu[1]) || 1; lu[0] /= ll; lu[1] /= ll;
        var toward = SUN.x * -cam.F.x + SUN.y * -cam.F.y + SUN.z * -cam.F.z; /* how much the light comes from behind the camera */
        sp.light = lu; sp.toward = toward;
        var mn = [-cam.F.x * .55, .75, -cam.F.z * .55], ml = Math.hypot(mn[0], mn[1], mn[2]); sp.mid = fillOf([mn[0] / ml, mn[1] / ml, mn[2] / ml]);
        sp.dark = fillOf([-SUN.x * .9, -SUN.y * .3 + .1, -SUN.z * .9]); sp.lit = fillOf([SUN.x, SUN.y, SUN.z]);
        if (g.dome) {
          /* the dome's outline: the silhouette's upper arc over the base ring's front arc */
          var upW = [e[4], e[5], e[6]], ul = Math.hypot(upW[0], upW[1], upW[2]) || 1; upW = [upW[0] / ul, upW[1] / ul, upW[2] / ul];
          var base = worldPts(ring(1, 0, 24, []).map(function (p) { return [p[0] * r, 0, p[2] * r]; }), e), outline = [], q;
          var sil = []; for (q = 0; q < 24; q++) { var a0 = q / 24 * TAU; var pu = [Math.cos(a0), Math.sin(a0)]; var wx = sp.matrix[0] * pu[0] + sp.matrix[2] * pu[1], wy = sp.matrix[1] * pu[0] + sp.matrix[3] * pu[1]; sil.push([c2[0] + wx, c2[1] + wy]); }
          /* keep the silhouette points above the base plane (screen-up of the dome's up), and the base points facing the camera */
          var upS = proj([cx + upW[0], cy + upW[1], cz + upW[2]]), upv = [upS[0] - c2[0], upS[1] - c2[1]], upl = Math.hypot(upv[0], upv[1]) || 1; upv[0] /= upl; upv[1] /= upl;
          var basePts = base.map(proj), front = [], backIdx = [];
          for (q = 0; q < 24; q++) { var bw = base[q], fd = (bw[0] - cx) * cam.F.x + (bw[1] - cy) * cam.F.y + (bw[2] - cz) * cam.F.z; (fd < 0 ? front : backIdx).push(q); }
          var silUp = sil.filter(function (p) { return (p[0] - c2[0]) * upv[0] + (p[1] - c2[1]) * upv[1] > -1e-6; });
          outline = hull(silUp.concat(front.map(function (q) { return basePts[q]; })));
          sp.outline = poly(outline); sp.dome = true;
        }
        if (!g.dome) { var ringPts = []; for (var q8 = 0; q8 < 24; q8++) { var a8 = q8 / 24 * TAU, cu = Math.cos(a8), su = Math.sin(a8); ringPts.push([c2[0] + sp.matrix[0] * cu + sp.matrix[2] * su, c2[1] + sp.matrix[1] * cu + sp.matrix[3] * su]); } sp.ring = ringPts;
        }
        d.special = sp;
        if (m.castShadow) { var sh = []; for (var q2 = 0; q2 < 8; q2++) { var aa = q2 / 8 * TAU; sh.push([cx + ax[0] * Math.cos(aa) + az[0] * Math.sin(aa), cy + ax[1] * Math.cos(aa) + az[1] * Math.sin(aa) + (g.dome ? 0 : 0), cz + ax[2] * Math.cos(aa) + az[2] * Math.sin(aa)]); sh.push([cx + ay[0] * Math.cos(aa) + ax[0] * Math.sin(aa), cy + ay[1] * Math.cos(aa) + ax[1] * Math.sin(aa), cz + ay[2] * Math.cos(aa) + ax[2] * Math.sin(aa)]); } d.shadowPts = sh; }
        d.depth = cam.depth(cx, cy, cz);
        var ex = Math.abs(ax[0]) + Math.abs(ay[0]) + Math.abs(az[0]), ey = Math.abs(ax[1]) + Math.abs(ay[1]) + Math.abs(az[1]), ez = Math.abs(ax[2]) + Math.abs(ay[2]) + Math.abs(az[2]);
        d.bb = [cx - ex, cy - (g.dome ? 0 : ey), cz - ez, cx + ex, cy + ey, cz + ez];
        var sx = Math.abs(sp.matrix[0]) + Math.abs(sp.matrix[2]), sy = Math.abs(sp.matrix[1]) + Math.abs(sp.matrix[3]); d.sb = [c2[0] - sx, c2[1] - sy, c2[0] + sx, c2[1] + sy];
      } else if (g.type === 'TorusGeometry') {
        /* the ring in six chunks, each a band as wide as the tube with its own depth, so the half of a handle that is
           behind its body is painted before the body and the half in front after it */
        var N = 24, CH = 6, per = N / CH, ringW = worldPts(ring(g.r, 0, N, []).map(function (p) { return [p[0], p[2], 0]; }), e), rp = ringW.map(proj);
        var tw = g.tube * Math.hypot(e[0], e[1], e[2]), tone = fillOf([-cam.F.x * .5, .8, -cam.F.z * .5]), parts = [], c2, k2, q5;
        for (c2 = 0; c2 < CH; c2++) {
          var pts2 = [], wpts = [], outer = [], inner = [];
          for (k2 = 0; k2 <= per; k2++) { q5 = (c2 * per + k2) % N; pts2.push(rp[q5]); wpts.push(ringW[q5]); }
          for (k2 = 0; k2 < pts2.length; k2++) {
            var pa = pts2[Math.max(k2 - 1, 0)], pb = pts2[Math.min(k2 + 1, pts2.length - 1)], ddx = pb[0] - pa[0], ddy = pb[1] - pa[1], dl = Math.hypot(ddx, ddy) || 1;
            outer.push([pts2[k2][0] - ddy / dl * tw, pts2[k2][1] + ddx / dl * tw]); inner.push([pts2[k2][0] + ddy / dl * tw, pts2[k2][1] - ddx / dl * tw]);
          }
          var part = { faces: [{ d: poly(outer.concat(inner.slice().reverse())), fill: tone }], edges: stroke ? [outer, inner] : [], shadow: null, special: null, depth: depthOf(wpts) };
          if (wob && part.edges.length) part.edges = part.edges.map(function (seg2) { return wobble(seg2, m.id * 7 + c2); });
          if (c2 === 0 && m.castShadow) part.shadowPts = ringW;
          bounds(part, wpts, outer.concat(inner));
          parts.push(part);
        }
        return parts;
      } else if (g.type === 'ExtrudeGeometry' && g.slab) {
        var o = slabOutline(g), n2 = o.length, topL = [], botL = [], q3;
        for (q3 = 0; q3 < n2; q3++) { topL.push([o[q3][0], 0, o[q3][1]]); botL.push([o[q3][0], -g.h, o[q3][1]]); }
        var TW = worldPts(topL, e), BW = worldPts(botL, e), tp = TW.map(proj), tn = normalOf(TW[0], TW[1], TW[2]);
        var side = m.side || mt, visS = [], w2;
        /* the walls: one quad per outline segment, each in its own tone */
        for (q3 = 0; q3 < n2; q3++) { var q4 = (q3 + 1) % n2, ns = normalOf(BW[q3], BW[q4], TW[q4]); var v2 = facing(ns); visS.push(v2); if (v2) d.faces.push({ d: poly([BW[q3], BW[q4], TW[q4], TW[q3]].map(proj)), fill: shade(side, ns) }); }
        d.faces.push({ d: poly(tp), fill: fillOf(tn) });
        d.topPath = poly(tp);
        if (stroke) {
          d.edges.push(tp.concat([tp[0]]));
          d.edges.push(rimArc(BW, visS, n2));
          for (q3 = 0; q3 < n2; q3++) { var pv = visS[(q3 - 1 + n2) % n2]; if (visS[q3] !== pv) d.edges.push([proj(BW[q3]), proj(TW[q3])]); }
        }
        d.ground = true; d.area = g.w * g.d; d.depth = depthOf(TW); bounds(d, TW.concat(BW));
      } else if (g.type === 'PlaneGeometry') {
        var o0 = proj([e[12], e[13], e[14]]), ox = proj([e[12] + e[0], e[13] + e[1], e[14] + e[2]]), oy = proj([e[12] + e[4], e[13] + e[5], e[14] + e[6]]);
        d.special = { label: true, matrix: [ox[0] - o0[0], ox[1] - o0[1], oy[0] - o0[0], oy[1] - o0[1], o0[0], o0[1]], g: g };
        d.depth = cam.depth(e[12], e[13], e[14]);
        var lc = [], lw = g.w / 2, lh = g.h / 2, li; for (li = 0; li < 4; li++) { var ux = li & 1 ? lw : -lw, uy = li & 2 ? lh : -lh; lc.push([e[12] + e[0] * ux + e[4] * uy, e[13] + e[1] * ux + e[5] * uy, e[14] + e[2] * ux + e[6] * uy]); } bounds(d, lc);
      }
      /* ground: thin, low things (zones, roads, water, rails) are painted first, under everything */
      if (!d.ground) { var ab = aabb(m); if (ab.max.y <= .26 && ab.max.y - ab.min.y <= .32 && ab.min.y > -.5) { d.ground = true; d.area = 0; } }
      if (wob && d.edges.length) d.edges = d.edges.map(function (seg2) { return wobble(seg2, m.id); });
      return d;
    }
    /* a drawable's box in the world and on the page, for the painter's order */
    function bounds(d, wpts, spts) {
      var bb = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity], sb = [Infinity, Infinity, -Infinity, -Infinity], i, p;
      for (i = 0; i < wpts.length; i++) { p = wpts[i]; if (p[0] < bb[0]) bb[0] = p[0]; if (p[1] < bb[1]) bb[1] = p[1]; if (p[2] < bb[2]) bb[2] = p[2]; if (p[0] > bb[3]) bb[3] = p[0]; if (p[1] > bb[4]) bb[4] = p[1]; if (p[2] > bb[5]) bb[5] = p[2]; }
      if (!spts) { spts = []; for (i = 0; i < wpts.length; i++) spts.push(proj(wpts[i])); }
      for (i = 0; i < spts.length; i++) { p = spts[i]; if (p[0] < sb[0]) sb[0] = p[0]; if (p[1] < sb[1]) sb[1] = p[1]; if (p[0] > sb[2]) sb[2] = p[0]; if (p[1] > sb[3]) sb[3] = p[1]; }
      d.bb = bb; d.sb = sb;
    }
    function depthOf(pts) { var s = 0; for (var i = 0; i < pts.length; i++) s += cam.depth(pts[i][0], pts[i][1], pts[i][2]); return s / pts.length; }
    function runOf(vis, n) {
      /* the indices of the visible bands, in order, when they form one run with a start (none: all or nothing visible) */
      var start = -1, i; for (i = 0; i < n; i++) if (vis[i] && !vis[(i - 1 + n) % n]) { start = i; break; }
      if (start < 0) return [];
      var out = []; for (i = 0; i < n; i++) { var k = (start + i) % n; if (!vis[k]) break; out.push(k); }
      return out;
    }
    function rimArc(ringW, vis, n) {
      /* the rim of a hidden cap: the bottom points of the visible bands, in order, as one open polyline */
      var start = -1, i; for (i = 0; i < n; i++) if (vis[i] && !vis[(i - 1 + n) % n]) { start = i; break; }
      if (start < 0) return [];
      var pts = []; for (i = 0; i < n; i++) { var k = (start + i) % n; if (!vis[k]) break; pts.push(proj(ringW[k])); if (!vis[(k + 1) % n]) { pts.push(proj(ringW[(k + 1) % n])); break; } }
      return pts;
    }
    var wobAmp = 0;
    function wobble(seg, seed) {
      /* a hand's copy of a line: the whole stroke bowed by a few slow waves (one per forty pixels or so, each with
         its own size and phase), fading to nothing at the ends so lines still meet, and now and then run a little
         past a corner. A ring of many short pieces is one stroke too, so it wavers instead of sawing */
      if (seg.length < 2) return seg;
      var s = (seed * 7919 + 13) % 2147483647 || 1, rnd = function () { s = (s * 16807) % 2147483647; return s / 2147483647 * 2 - 1; };
      var n = seg.length, i, k, Ls = [], Ltot = 0;
      for (i = 0; i < n - 1; i++) { var l = Math.hypot(seg[i + 1][0] - seg[i][0], seg[i + 1][1] - seg[i][1]); Ls.push(l); Ltot += l; }
      if (Ltot < 1e-6) return seg;
      var bows = Math.max(1, Math.min(6, Math.round(Ltot / (wobAmp * 48)))), r1 = rnd(), r2 = rnd() * .6, ph = rnd() * Math.PI, o0 = rnd(), o1 = rnd();
      var w = function (u) { return (Math.sin(u * Math.PI * bows + ph) * r1 + Math.sin(u * Math.PI * 2 * bows + ph * 2) * r2) * Math.sin(u * Math.PI); };
      var out = [seg[0]], acc = 0;
      for (i = 0; i < n - 1; i++) {
        var a = seg[i], b = seg[i + 1], L = Ls[i]; if (L < 1e-6) continue;
        var dx = b[0] - a[0], dy = b[1] - a[1], ux = dx / L, uy = dy / L, px = -uy, py = ux, SUB = Math.max(1, Math.min(8, Math.round(L / (wobAmp * 6))));
        for (k = 1; k <= SUB; k++) {
          var t = k / SUB, ww = w((acc + L * t) / Ltot), over = (t === 1 && i === n - 2 && o1 > .2) ? o1 : 0;
          out.push([a[0] + dx * t + (px * ww + ux * over) * wobAmp, a[1] + dy * t + (py * ww + uy * over) * wobAmp]);
        }
        acc += L;
      }
      if (o0 > .2 && Ls[0] > 1e-6) out[0] = [seg[0][0] - (seg[1][0] - seg[0][0]) / Ls[0] * o0 * wobAmp, seg[0][1] - (seg[1][1] - seg[0][1]) / Ls[0] * o0 * wobAmp];
      return out;
    }

    /* ---------- shadows: a solid's points thrown along the sun onto the ground under it ---------- */
    var grounds = [];
    function groundUnder(x, z) {
      var best = 0, i;
      for (i = 0; i < grounds.length; i++) { var s = grounds[i]; var lx = x - s.cx, lz = z - s.cz; var ux = lx * s.c + lz * s.s, uz = -lx * s.s + lz * s.c; if (Math.abs(ux) <= s.w && Math.abs(uz) <= s.d && s.y > best) best = s.y; }
      return best;
    }
    function shadowPath(pts, cx, cz) {
      var gy = groundUnder(cx, cz), out = [], i;
      for (i = 0; i < pts.length; i++) { var p = pts[i], t = (p[1] - gy) / SUN.y; if (t < 0) t = 0; out.push(proj([p[0] - SUN.x * t, gy + .002, p[2] - SUN.z * t])); }
      return poly(hull(out));
    }

    /* ---------- the frame ---------- */
    var items = {}, recs = {}; /* item: one painted part of a mesh → { g, paths, edge, shadow, special… }; rec: a mesh's cached parts */
    function item(m, k) {
      var id = m.id + '/' + (k || 0), it = items[id];
      if (!it) { it = items[id] = { id: id, m: m, g: el('g'), paths: [], edgeEl: null, shadowEl: null, specialEls: null, d: null, layer: null }; it.g.__mesh = m; }
      return it;
    }
    function setD(path, dStr, fill, strokeC, seamC) {
      if (path.__d !== dStr) { path.setAttribute('d', dStr); path.__d = dStr; }
      if (path.__f !== fill) { path.setAttribute('fill', fill); path.__f = fill; }
      var sc = strokeC || seamC; if (path.__s !== sc) { path.setAttribute('stroke', sc); path.__s = sc; }
    }
    var seamW = theme.edges ? .5 : .7;
    function paint(it, d) {
      var m = it.m, mt = m.material, g = it.g, i, op = mt.transparent ? mt.opacity : 1;
      if (g.__op !== op) { g.setAttribute('opacity', op); g.__op = op; }
      if (d.special) {
        if (!it.specialEls) { while (g.firstChild) g.removeChild(g.firstChild); it.paths = []; it.specialEls = {}; }
        var S = it.specialEls, sp = d.special;
        if (sp.torus) {
          if (!S.p) { S.p = el('path', { fill: 'none', 'stroke-linejoin': 'round' }, g); S.p.__mesh = m; if (theme.edges) { S.o = el('path', { fill: 'none', 'stroke-linejoin': 'round', 'pointer-events': 'none' }, g); } }
          var tw = sp.width;
          if (theme.edges) { S.p.setAttribute('d', sp.d); S.p.setAttribute('stroke', sp.fill); S.p.setAttribute('stroke-width', tw); S.o.setAttribute('d', sp.d); S.o.setAttribute('stroke', strokeOf(mt)); S.o.setAttribute('stroke-width', tw + 2 * ctx.px * (theme.strokeWidth || 1.1)); g.insertBefore(S.o, S.p); }
          else { S.p.setAttribute('d', sp.d); S.p.setAttribute('stroke', sp.fill); S.p.setAttribute('stroke-width', tw); }
        } else if (sp.label) {
          if (!S.g) { S.g = el('g', null, g); var G = sp.g; if (G.bg) S.r = el('rect', { x: -G.w / 2, y: -G.h / 2, width: G.w, height: G.h, fill: G.bg }, S.g); S.t = el('text', { x: 0, y: 0, 'text-anchor': 'middle', 'dominant-baseline': 'central', fill: G.color, 'font-family': G.font, 'font-weight': G.weight, 'font-size': (G.size ? G.size / 256 * G.w : G.h * .6), transform: 'scale(1,-1)' }, S.g); S.t.textContent = G.text; }
          S.g.setAttribute('transform', 'matrix(' + sp.matrix.map(f2).join(' ') + ')');
        } else {
          /* a sphere: the disc in the mid tone, a crescent on the dark side, a cap toward the light; a dome keeps
             what falls inside its outline */
          if (!S.disc) {
            if (sp.dome) { S.clip = el('clipPath', { id: uid + 'c' + m.id }, defs); S.clipPath = el('path', null, S.clip); S.wrap = el('g', { 'clip-path': 'url(#' + uid + 'c' + m.id + ')' }, g); S.hit = el('path', { fill: 'none', 'pointer-events': 'visibleFill' }, g); S.hit.__mesh = m; }
            var host = sp.dome ? S.wrap : g;
            S.tr = el('g', null, host);
            S.disc = el('circle', { r: 1 }, S.tr); S.disc.__mesh = m;
            S.dark = el('path', { 'pointer-events': 'none' }, S.tr); S.cap = el('path', { 'pointer-events': 'none' }, S.tr);
            if (theme.edges) S.ink = el('path', { fill: 'none', 'pointer-events': 'none' }, g);
          }
          S.tr.setAttribute('transform', 'matrix(' + sp.matrix.map(function (v) { return Math.round(v * 1000) / 1000; }).join(' ') + ')');
          var lu = sp.light, k = .55 + .3 * clamp(sp.toward, -1, 1); /* the light from behind the camera pushes the terminator back */
          S.disc.setAttribute('fill', theme.name === 'line' ? sp.mid : sp.mid);
          if (theme.name === 'line' || theme.tones) { S.dark.setAttribute('d', ''); S.cap.setAttribute('d', ''); }
          else { S.dark.setAttribute('d', crescent(lu, k)); S.dark.setAttribute('fill', sp.dark); S.cap.setAttribute('d', cap(lu, .42)); S.cap.setAttribute('fill', sp.lit); }
          if (sp.dome) { S.clipPath.setAttribute('d', sp.outline); S.hit.setAttribute('d', sp.outline); }
          if (S.ink) { var ring2 = sp.dome ? outlinePts(sp.outline) : sp.ring; S.ink.setAttribute('d', wobAmp ? polyline(wobble(ring2.concat([ring2[0]]), m.id), false) : poly(ring2)); S.ink.setAttribute('stroke', strokeOf(mt)); S.ink.setAttribute('stroke-width', f2((theme.strokeWidth || 1.1) * ctx.px)); }
        }
        return;
      }
      var strokeC = strokeOf(mt);
      for (i = 0; i < d.faces.length; i++) {
        var p = it.paths[i];
        if (!p) { p = it.paths[i] = el('path', { 'stroke-linejoin': 'round' }, g); p.__mesh = m; }
        p.setAttribute('stroke-width', f2(seamW * ctx.px));
        if (it.edgeEl && it.edgeEl.parentNode === g) g.insertBefore(p, it.edgeEl);
        setD(p, d.faces[i].d, d.faces[i].fill, theme.edges ? d.faces[i].fill : null, d.faces[i].fill);
        var fg = d.faces[i].grad;
        if (fg) {
          /* a gradient of this face's own, in page units, its stops the tones of the bands it stands for */
          var gid = uid + 'g' + it.id.replace('/', '-') + '-' + i, lg = it.grads && it.grads[i];
          if (!lg) { it.grads = it.grads || {}; lg = it.grads[i] = el('linearGradient', { id: gid, gradientUnits: 'userSpaceOnUse' }, defs); }
          lg.setAttribute('x1', f2(fg.x1)); lg.setAttribute('y1', f2(fg.y1)); lg.setAttribute('x2', f2(fg.x2)); lg.setAttribute('y2', f2(fg.y2));
          while (lg.childNodes.length > fg.stops.length) lg.removeChild(lg.lastChild);
          for (var si = 0; si < fg.stops.length; si++) { var st = lg.childNodes[si] || el('stop', null, lg); st.setAttribute('offset', f2(fg.stops[si][0])); st.setAttribute('stop-color', fg.stops[si][1]); }
          p.setAttribute('fill', 'url(#' + gid + ')'); p.__f = 'url(#' + gid + ')';
        }
      }
      while (it.paths.length > d.faces.length) { var extra = it.paths.pop(); g.removeChild(extra); }
      if (strokeC && d.edges.length) {
        if (!it.edgeEl) { it.edgeEl = el('path', { fill: 'none', 'pointer-events': 'none', 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, g); }
        var ds = ''; for (i = 0; i < d.edges.length; i++) if (d.edges[i].length > 1) ds += polyline(d.edges[i], false);
        if (it.edgeEl.__d !== ds) { it.edgeEl.setAttribute('d', ds); it.edgeEl.__d = ds; }
        it.edgeEl.setAttribute('stroke', strokeC); it.edgeEl.setAttribute('stroke-width', f2((theme.strokeWidth || 1.1) * ctx.px));
        g.appendChild(it.edgeEl);
      } else if (it.edgeEl) { g.removeChild(it.edgeEl); it.edgeEl = null; }
    }
    function outlinePts(dStr) { return dStr.slice(1, -1).split('L').map(function (s) { var q = s.split(' '); return [+q[0], +q[1]]; }); }
    function crescent(lu, k) {
      /* the unit disc minus the same disc shifted toward the light by k: bounded by the far arc of the disc and the
         near arc of the shifted one */
      var cx = lu[0] * k, cy = lu[1] * k, hx = lu[0] * k / 2, hy = lu[1] * k / 2, hc = Math.sqrt(Math.max(1 - k * k / 4, 0)), px = -lu[1], py = lu[0];
      var p1 = [hx + px * hc, hy + py * hc], p2 = [hx - px * hc, hy - py * hc], pts = [], N = 14, i;
      var a1 = Math.atan2(p1[1], p1[0]), a2 = Math.atan2(p2[1], p2[0]), al = Math.atan2(-lu[1], -lu[0]);
      /* the disc's arc from p1 to p2 through the point opposite the light */
      var span = ((a2 - a1) % TAU + TAU) % TAU; if (!angleBetween(al, a1, span)) { span = span - TAU; }
      for (i = 0; i <= N; i++) { var a = a1 + span * i / N; pts.push([Math.cos(a), Math.sin(a)]); }
      var b2 = Math.atan2(p2[1] - cy, p2[0] - cx), b1 = Math.atan2(p1[1] - cy, p1[0] - cx), spanB = ((b1 - b2) % TAU + TAU) % TAU; if (angleBetween(Math.atan2(lu[1], lu[0]), b2, spanB)) spanB -= TAU;
      for (i = 1; i < N; i++) { var bq = b2 + spanB * i / N; pts.push([cx + Math.cos(bq), cy + Math.sin(bq)]); }
      return poly(pts);
    }
    function angleBetween(a, from, span) { var d = ((a - from) % TAU + TAU) % TAU; return span >= 0 ? d <= span : d >= TAU + span; }
    function cap(lu, k) { var cx = lu[0] * k, cy = lu[1] * k, pts = [], N = 16, r = .5; for (var i = 0; i < N; i++) { var a = i / N * TAU; var x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); var l = Math.hypot(x, y); if (l > .985) { x *= .985 / l; y *= .985 / l; } pts.push([x, y]); } return poly(pts); }

    var haloEl = null, clipPaths = [], shadowOn = theme.shadows !== false && theme.shadow > 0;
    var camKeyLast = '';
    var order = { ground: [], scene: [] }, seq = { ground: '', scene: '' };
    this.render = function (world) {
      world.updateTree();
      var list = [], ms = [], i;
      grounds = [];
      world.traverse(function (o) { if (o.isMesh && isVisible(o)) ms.push(o); });
      /* the slabs first, so the shadows know the ground under each thing */
      for (i = 0; i < ms.length; i++) { var m = ms[i]; if (m.geometry.slab) { var e = m.matrixWorld.elements, sx = Math.hypot(e[0], e[1], e[2]) || 1, sz = Math.hypot(e[8], e[9], e[10]) || 1; grounds.push({ cx: e[12], cz: e[14], y: e[13], w: m.geometry.w / 2 * sx, d: m.geometry.d / 2 * sz, c: e[0] / sx, s: e[2] / sx }); } }
      var seen = {};
      for (i = 0; i < ms.length; i++) {
        var mesh = ms[i], mt = mesh.material, rec = recs[mesh.id] || (recs[mesh.id] = { key: null, ds: null });
        var key = cam.key + '|' + mesh.matrixWorld.elements.map(f2).join(',') + '|' + mt.color.getHexString() + mt.emissive.getHexString() + f2(mt.emissiveIntensity) + (mt.transparent ? f2(mt.opacity) : '') + (mesh.side ? mesh.side.color.getHexString() : '') + '|' + wobAmp + '|' + f2(ctx.px * 1000);
        if (rec.key !== key) {
          rec.key = key; var ds = draw(mesh); rec.ds = Array.isArray(ds) ? ds : [ds];
          for (var k = 0; k < rec.ds.length; k++) {
            var it0 = item(mesh, k), d0 = rec.ds[k]; it0.d = d0; paint(it0, d0);
            if (shadowOn && d0.shadowPts && !d0.ground) { if (!it0.shadowEl) it0.shadowEl = el('path', { fill: ink }, shadowG); var sp2 = shadowPath(d0.shadowPts, mesh.matrixWorld.elements[12], mesh.matrixWorld.elements[14]); if (it0.shadowEl.__d !== sp2) { it0.shadowEl.setAttribute('d', sp2); it0.shadowEl.__d = sp2; } }
            else if (it0.shadowEl) { shadowG.removeChild(it0.shadowEl); it0.shadowEl = null; }
          }
        }
        for (var k2 = 0; k2 < rec.ds.length; k2++) { var it = item(mesh, k2); it.layer = it.d.ground ? 'ground' : 'scene'; seen[it.id] = 1; list.push(it); }
      }
      for (var hid in items) if (!seen[hid] && items[hid].shadowEl) { shadowG.removeChild(items[hid].shadowEl); items[hid].shadowEl = null; }
      /* painter's order: the ground layer by area (slabs) then depth, the scene by depth, the far first */
      var ground = list.filter(function (it) { return it.layer === 'ground'; }).sort(function (a, b) { return (b.d.area - a.d.area) || (b.d.depth - a.d.depth); });
      var scene = orderScene(list.filter(function (it) { return it.layer === 'scene'; }));
      arrange(groundG, ground, 'ground'); arrange(sceneG, scene, 'scene');
      /* the shadows land on the slabs only */
      if (shadowOn) { var cp = ''; for (i = 0; i < ground.length; i++) if (ground[i].d.topPath) cp += ground[i].d.topPath; if (clip.__d !== cp) { while (clip.firstChild) clip.removeChild(clip.firstChild); el('path', { d: cp }, clip); clip.__d = cp; } }
      /* the halo under the base */
      if (ctx.halo && theme.halo > 0) {
        var hm = ctx.halo, he = hm.matrixWorld.elements, hg = hm.geometry, ho = slabOutline(hg), hp = [];
        for (i = 0; i < ho.length; i++) hp.push([ho[i][0] + hg.w * .035, -hg.h - .02, ho[i][1] - hg.d * .03]);
        var hd = poly(worldPts(hp, he).map(proj));
        if (!haloEl) { haloEl = el('path', { fill: ink, opacity: theme.halo, filter: 'url(#' + uid + 'blur)' }, haloG); }
        if (haloEl.__d !== hd) { haloEl.setAttribute('d', hd); haloEl.__d = hd; blurFx.setAttribute('stdDeviation', f2(Math.min(hg.w, hg.d) * .11)); }
      }
      /* the ground is not pickable unless it is hot; everything else is */
      for (i = 0; i < list.length; i++) list[i].g.__mesh = list[i].m;
    };
    /* the painter's order of the scene: far first by centre depth; then every pair that overlaps on the page and
       has a plane square to an axis between them paints in the order that plane says (the side the camera is on
       paints later), which is what keeps a counter in front of a tall wall and a window on it; a thing set `on`
       another paints right after it. A depth-first walk over those constraints gives the order; a cycle (two
       things that overlap on the page but not in space) falls back to depth. */
    function orderScene(its) {
      var n = its.length, i, j, p, q;
      its.sort(function (a, b) { return b.d.depth - a.d.depth; });
      var idx = new Array(n); for (i = 0; i < n; i++) idx[i] = i;
      idx.sort(function (a, b) { return its[a].d.sb[0] - its[b].d.sb[0]; });
      var before = new Array(n); for (i = 0; i < n; i++) before[i] = [];
      var fx = cam.F.x, fy = cam.F.y, fz = cam.F.z;
      for (p = 0; p < n; p++) {
        i = idx[p]; var A = its[i], sa = A.d.sb, ab = A.d.bb;
        for (q = p + 1; q < n; q++) {
          j = idx[q]; var B = its[j], sb = B.d.sb;
          if (sb[0] > sa[2]) break;
          if (sb[1] > sa[3] || sb[3] < sa[1] || A.m === B.m || A.m.on === B.m || B.m.on === A.m) continue;
          var bb = B.d.bb, r = sep(ab[0], ab[3], bb[0], bb[3], fx), v = sep(ab[2], ab[5], bb[2], bb[5], fz);
          if (v) { if (r && v !== r) continue; r = v; }
          v = sep(ab[1], ab[4], bb[1], bb[4], fy); if (v) { if (r && v !== r) continue; r = v; }
          if (r === 1) before[j].push(i); else if (r === -1) before[i].push(j);
        }
      }
      var first = {}; for (i = 0; i < n; i++) if (first[its[i].m.id] == null) first[its[i].m.id] = i;
      for (i = 0; i < n; i++) { var on = its[i].m.on; if (on) { var om = on.isMesh ? on : firstMesh(on); if (om && first[om.id] != null) before[i].push(first[om.id]); } }
      var out = [], state = new Uint8Array(n);
      var visit = function (k) { if (state[k]) return; state[k] = 1; var b = before[k]; for (var x = 0; x < b.length; x++) visit(b[x]); out.push(its[k]); };
      for (i = 0; i < n; i++) visit(i);
      return out;
    }
    /* 1 when A lies wholly on the far side of a plane square to this axis, -1 when B does, 0 when neither */
    function sep(a0, a1, b0, b1, f) {
      if (f > -.05 && f < .05) return 0;
      if (a1 <= b0 + .01) return f < 0 ? 1 : -1;
      if (b1 <= a0 + .01) return f < 0 ? -1 : 1;
      return 0;
    }
    function firstMesh(o) { var m = null; o.traverse(function (c) { if (!m && c.isMesh) m = c; }); return m; }
    function isVisible(o) { while (o) { if (!o.visible) return false; o = o.parent; } return true; }
    function arrange(host, its, name) {
      var s = ''; for (var i = 0; i < its.length; i++) s += its[i].m.id + ',';
      if (s === seq[name]) return;
      seq[name] = s;
      var frag = document.createDocumentFragment(); for (var j = 0; j < its.length; j++) frag.appendChild(its[j].g);
      while (host.firstChild) host.removeChild(host.firstChild);
      host.appendChild(frag);
    }
    this.setWobble = function (unitsPerPx) { wobAmp = (theme.wobble || 0) * unitsPerPx; };
    this.shadowOpacity = function () { shadowG.setAttribute('opacity', theme.shadow == null ? .2 : theme.shadow); };
    this.shadowOpacity();
    this.dispose = function () { items = {}; recs = {}; };
  }

  /* ---------- mount ---------- */
  var mountId = 0;
  function mount(fig, opts) {
    opts = opts || {};
    var elHost = opts.el; if (!elHost) throw new Error('Diorama.mount needs { el }.');
    var size = SIZES[fig.size] || SIZES.card;
    var theme = resolveTheme(opts.theme, fig);
    var pal = Object.assign({}, PAL, theme.palette);
    pal.accent = theme.accent || pal.accent || pal.coral;
    var camSpec = Object.assign({ az: 45, el: 35.264, pad: fig.size === 'mini' ? 1.04 : 1.08 }, fig.camera || {});
    var tilt = fig.tilt == null ? 4 : fig.tilt;
    var themeBg = (typeof opts.theme === 'object' && opts.theme.bg) || (typeof fig.theme === 'object' && fig.theme.bg) || null;
    var bg = fig.background || themeBg || (fig.size === 'mini' ? 'transparent' : theme.bg || pal.bg);
    if (bg === 'auto') bg = fig.size === 'mini' ? 'transparent' : theme.bg || pal.bg;
    var reduced = opts.reduced != null ? !!opts.reduced : (typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches);
    var stillAt = opts.still != null ? opts.still : (fig.still == null ? 2 : fig.still);
    var ctx = { id: ++mountId, fig: fig, pal: pal, theme: theme, t: 0, dt: 0, pointer: { x: 0, y: 0, inside: false, down: false, world: null }, hover: null, pressed: null, pressedAt: -1, active: null, read: '', reduced: reduced, parts: null, halo: null, px: 1 };

    var svg = el('svg', { xmlns: NS, 'aria-hidden': 'true' });
    svg.style.display = 'block'; svg.style.width = '100%'; svg.style.height = '100%'; svg.style.touchAction = 'pan-y';
    if (bg !== 'transparent') svg.style.background = bg;
    elHost.appendChild(svg);
    if (!elHost.getAttribute('role')) elHost.setAttribute('role', 'img');
    if (!elHost.getAttribute('aria-label')) elHost.setAttribute('aria-label', (fig.title || fig.name) + (fig.means ? '. ' + fig.means : ''));
    ctx.svg = svg;

    var world = new Group(); world.name = 'world';
    var cam = new Camera(); cam.set(camSpec.az, camSpec.el);
    ctx.world = world; ctx.cam = cam;
    var D = toolkit(world, pal, ctx);
    ctx.D = D;
    var painter = new Painter(svg, ctx);
    ctx.parts = fig.build({ D: D, world: world, pal: pal, ctx: ctx, M: M }) || {};

    /* fit: frame the world's bounds in the camera at rest, then keep the frame */
    var frustum = { l: -1, r: 1, t: -1, b: 1 }, azRest = camSpec.az, elRest = camSpec.el, center = new Vector3();
    function fit() {
      world.updateTree();
      cam.set(azRest, elRest);
      var minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity, bmin = new Vector3(Infinity, Infinity, Infinity), bmax = new Vector3(-Infinity, -Infinity, -Infinity);
      world.traverse(function (o) {
        if (!o.isMesh || o.geometry.label) return;
        var bb = o.geometry.boundingBox, e = o.matrixWorld.elements, v = new Vector3();
        for (var i = 0; i < 8; i++) {
          v.set(i & 1 ? bb.max.x : bb.min.x, i & 2 ? bb.max.y : bb.min.y, i & 4 ? bb.max.z : bb.min.z).applyMatrix4(o.matrixWorld);
          var p = cam.project(v.x, v.y, v.z);
          minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]);
          bmin.x = Math.min(bmin.x, v.x); bmin.y = Math.min(bmin.y, v.y); bmin.z = Math.min(bmin.z, v.z); bmax.x = Math.max(bmax.x, v.x); bmax.y = Math.max(bmax.y, v.y); bmax.z = Math.max(bmax.z, v.z);
        }
      });
      if (minX === Infinity) { minX = -1; maxX = 1; minY = -1; maxY = 1; }
      center.set((bmin.x + bmax.x) / 2, (bmin.y + bmax.y) / 2, (bmin.z + bmax.z) / 2);
      var w = (maxX - minX) * camSpec.pad, h = (maxY - minY) * camSpec.pad, cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
      if (w / h < size.aspect) w = h * size.aspect; else h = w / size.aspect;
      frustum = { l: cx - w / 2, r: cx + w / 2, t: cy - h / 2, b: cy + h / 2, w: w, h: h, cx: cx, cy: cy };
      svg.setAttribute('viewBox', f2(frustum.l) + ' ' + f2(frustum.t) + ' ' + f2(w) + ' ' + f2(h));
      scalePx();
    }
    function scalePx() {
      var cw = elHost.clientWidth || 300; ctx.px = frustum.w / cw; painter.setWobble(ctx.px);
    }
    ctx.fit = fit;
    function resize() {
      var w = elHost.clientWidth || 300, h = Math.round(w / size.aspect);
      svg.style.height = h + 'px';
      if (elHost.style.height === '' || elHost.dataset.dioramaHeight) { elHost.style.height = h + 'px'; elHost.dataset.dioramaHeight = '1'; }
      scalePx();
    }
    fit(); resize();

    /* the camera's drift toward the pointer: the view turns a few degrees, and the frame stays where the fit put it */
    var pSpringX = spring(60, 12), pSpringY = spring(60, 12);
    function tiltCam(dt) {
      pSpringX.t = ctx.pointer.inside ? ctx.pointer.x : 0; pSpringY.t = ctx.pointer.inside ? ctx.pointer.y : 0;
      pSpringX.step(dt); pSpringY.step(dt);
      var az = azRest - pSpringX.x * tilt, e = elRest + pSpringY.x * tilt * .5;
      cam.set(az, e);
      /* keep the world's centre where it was on the page, so the scene turns about itself */
      var c = cam.project(center.x, center.y, center.z), c0 = restCenter;
      svg.setAttribute('viewBox', f2(frustum.l + c[0] - c0[0]) + ' ' + f2(frustum.t + c[1] - c0[1]) + ' ' + f2(frustum.w) + ' ' + f2(frustum.h));
    }
    var restCenter = cam.project(center.x, center.y, center.z);

    /* pointer */
    function at(e) {
      var r = svg.getBoundingClientRect();
      ctx.pointer.x = clamp(((e.clientX - r.left) / r.width) * 2 - 1, -1, 1);
      ctx.pointer.y = clamp(-(((e.clientY - r.top) / r.height) * 2 - 1), -1, 1);
      ctx.pointer.inside = true; ctx.pointer.target = e.target;
    }
    function hotOf(node) {
      var hot = ctx.parts && ctx.parts.hot; if (!hot || !hot.length) return null;
      var m = null; while (node && node !== svg) { if (node.__mesh) { m = node.__mesh; break; } node = node.parentNode; }
      for (var o = m; o; o = o.parent) if (hot.indexOf(o) >= 0) return o;
      return null;
    }
    function updatePointer() {
      if (!ctx.pointer.inside) { ctx.pointer.world = null; ctx.hover = null; return; }
      var vb = svg.viewBox.baseVal, sx = vb.x + (ctx.pointer.x + 1) / 2 * vb.width, sy = vb.y + (1 - ctx.pointer.y) / 2 * vb.height;
      var t = sy * cam.U.y / cam.F.y; /* on the ground plane: p = sx·R − sy·U + t·F with p.y = 0 */
      ctx.pointer.world = new Vector3(sx * cam.R.x - sy * cam.U.x + t * cam.F.x, 0, sx * cam.R.z - sy * cam.U.z + t * cam.F.z);
      if (document.elementFromPoint) ctx.pointer.target = pointerTarget();
      ctx.hover = hotOf(ctx.pointer.target);
    }
    function onMove(e) { at(e); wake(); }
    function onLeave() { ctx.pointer.inside = false; ctx.pointer.down = false; ctx.pointer.world = null; ctx.pointer.target = null; ctx.hover = null; wake(); }
    function press() {
      /* a click or a tap: what is under it is pressed, and switched on until it or another is pressed again */
      updatePointer();
      ctx.pressed = ctx.hover; ctx.pressedAt = ctx.t;
      if (ctx.hover) ctx.active = ctx.active === ctx.hover ? null : ctx.hover;
      wake();
    }
    function onDown(e) { if (e.button != null && e.button !== 0) return; at(e); ctx.pointer.down = true; press(); }
    function onUp(e) { ctx.pointer.down = false; if (e.pointerType === 'touch') onLeave(); else wake(); }
    ctx.tap = function (x, y) {
      ctx.pointer.x = clamp(x, -1, 1); ctx.pointer.y = clamp(y, -1, 1); ctx.pointer.inside = true;
      var r = svg.getBoundingClientRect(); ctx.pointer.target = document.elementFromPoint(r.left + (x + 1) / 2 * r.width, r.top + (1 - y) / 2 * r.height);
      press(); return ctx.pressed;
    };
    ctx.pick = function (x, y) { var r = svg.getBoundingClientRect(); return hotOf(document.elementFromPoint(r.left + (x + 1) / 2 * r.width, r.top + (1 - y) / 2 * r.height)); };
    svg.addEventListener('pointermove', onMove); svg.addEventListener('pointerleave', onLeave); svg.addEventListener('pointercancel', onLeave);
    svg.addEventListener('pointerdown', onDown); svg.addEventListener('pointerup', onUp);

    /* loop: sleeps offscreen and when the tab is hidden; one still frame under reduced motion */
    var running = false, visible = true, raf = 0, last = 0;
    function render() { painter.render(world); }
    function frame(now) {
      raf = 0;
      var dt = last ? Math.min(.05, (now - last) / 1000) : 0; last = now;
      ctx.dt = dt; ctx.t += dt;
      updatePointer();
      if (tilt) tiltCam(dt);
      if (fig.tick) fig.tick(ctx);
      render();
      if (running && visible && !document.hidden) raf = requestAnimationFrame(frame);
      else last = 0;
    }
    function wake() {
      if (reduced) { stillFrame(); return; }
      if (!raf && running && visible && !document.hidden) raf = requestAnimationFrame(frame);
    }
    function stillFrame() {
      ctx.t = stillAt; ctx.dt = 0; updatePointer(); cam.set(azRest, elRest);
      svg.setAttribute('viewBox', f2(frustum.l) + ' ' + f2(frustum.t) + ' ' + f2(frustum.w) + ' ' + f2(frustum.h));
      if (fig.tick) fig.tick(ctx);
      render();
    }
    ctx.render = render;
    ctx.step = function (dt) {
      ctx.dt = dt; ctx.t += dt;
      updatePointer();
      if (tilt) tiltCam(dt);
      if (fig.tick) fig.tick(ctx); return ctx;
    };
    function pointerTarget() { var r = svg.getBoundingClientRect(); return document.elementFromPoint ? document.elementFromPoint(r.left + (ctx.pointer.x + 1) / 2 * r.width, r.top + (1 - ctx.pointer.y) / 2 * r.height) : null; }
    ctx.stillFrame = stillFrame;
    ctx.start = function () { running = true; wake(); return ctx; };
    ctx.stop = function () { running = false; if (raf) cancelAnimationFrame(raf); raf = 0; last = 0; return ctx; };

    var io = typeof IntersectionObserver === 'function' ? new IntersectionObserver(function (es) { visible = es[es.length - 1].isIntersecting; if (visible) wake(); else { last = 0; } }, { threshold: 0 }) : null;
    if (io) io.observe(elHost);
    var ro = typeof ResizeObserver === 'function' ? new ResizeObserver(function () { resize(); wake(); if (reduced) stillFrame(); }) : null;
    if (ro) ro.observe(elHost);
    var onVis = function () { if (!document.hidden) wake(); else last = 0; };
    document.addEventListener('visibilitychange', onVis);

    ctx.destroy = function () {
      ctx.stop(); if (io) io.disconnect(); if (ro) ro.disconnect();
      document.removeEventListener('visibilitychange', onVis);
      svg.removeEventListener('pointermove', onMove); svg.removeEventListener('pointerleave', onLeave); svg.removeEventListener('pointercancel', onLeave);
      svg.removeEventListener('pointerdown', onDown); svg.removeEventListener('pointerup', onUp);
      painter.dispose(); if (svg.parentNode) svg.parentNode.removeChild(svg);
    };

    stillFrame();
    if (!reduced) ctx.start();
    return ctx;
  }

  function figure(spec) {
    if (!spec || !spec.name) throw new Error('Diorama.figure needs a name.');
    if (typeof spec.build !== 'function') throw new Error('Diorama.figure needs build().');
    figures.push(spec); return spec;
  }

  /* for the look script: a mesh's oriented box in world units, and whether a point is under it */
  function obb(m) {
    var bb = m.geometry.boundingBox, e = m.matrixWorld.elements;
    var c = new Vector3((bb.min.x + bb.max.x) / 2, (bb.min.y + bb.max.y) / 2, (bb.min.z + bb.max.z) / 2).applyMatrix4(m.matrixWorld);
    var ax = [new Vector3(e[0], e[1], e[2]), new Vector3(e[4], e[5], e[6]), new Vector3(e[8], e[9], e[10])];
    var ex = [(bb.max.x - bb.min.x) / 2 * ax[0].length(), (bb.max.y - bb.min.y) / 2 * ax[1].length(), (bb.max.z - bb.min.z) / 2 * ax[2].length()];
    ax.forEach(function (a) { a.normalize(); });
    return { c: c, ax: ax, e: ex };
  }
  function aabb(m) {
    var bb = m.geometry.boundingBox, min = new Vector3(Infinity, Infinity, Infinity), max = new Vector3(-Infinity, -Infinity, -Infinity), v = new Vector3();
    for (var i = 0; i < 8; i++) { v.set(i & 1 ? bb.max.x : bb.min.x, i & 2 ? bb.max.y : bb.min.y, i & 4 ? bb.max.z : bb.min.z).applyMatrix4(m.matrixWorld); min.x = Math.min(min.x, v.x); min.y = Math.min(min.y, v.y); min.z = Math.min(min.z, v.z); max.x = Math.max(max.x, v.x); max.y = Math.max(max.y, v.y); max.z = Math.max(max.z, v.z); }
    return { min: min, max: max };
  }

  return { PAL: PAL, SIZES: SIZES, THEMES: THEMES, figures: figures, figure: figure, mount: mount, toolkit: toolkit, resolveTheme: resolveTheme, M: M, obb: obb, aabb: aabb,
    Vector3: Vector3, Matrix4: Matrix4, Color: Color, Group: Group, Mesh: Mesh,
    clamp: clamp, lerp: lerp, smooth: smooth, out: out, inOut: inOut, phase: phase, wave: wave, pulse: pulse, spring: spring, apart: apart, path: path, place: place, spin: spin, stagger: stagger };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = Diorama;
