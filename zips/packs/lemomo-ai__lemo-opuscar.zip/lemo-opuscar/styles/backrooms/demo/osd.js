// Camcorder OSD: custom 5×7 dot-matrix font (REC, battery, timecode, date, character-generator title)
// Drawn on the 720×540 "tape-space" canvas and composited into the signal by the VHS shader (so it also gets chroma bleed and tracking jitter)
const G = {
  '0': '01110 10001 10011 10101 11001 10001 01110', '1': '00100 01100 00100 00100 00100 00100 01110',
  '2': '01110 10001 00001 00010 00100 01000 11111', '3': '11111 00010 00100 00010 00001 10001 01110',
  '4': '00010 00110 01010 10010 11111 00010 00010', '5': '11111 10000 11110 00001 00001 10001 01110',
  '6': '00110 01000 10000 11110 10001 10001 01110', '7': '11111 00001 00010 00100 01000 01000 01000',
  '8': '01110 10001 10001 01110 10001 10001 01110', '9': '01110 10001 10001 01111 00001 00010 01100',
  'A': '01110 10001 10001 11111 10001 10001 10001', 'B': '11110 10001 10001 11110 10001 10001 11110',
  'C': '01110 10001 10000 10000 10000 10001 01110', 'D': '11100 10010 10001 10001 10001 10010 11100',
  'E': '11111 10000 10000 11110 10000 10000 11111', 'F': '11111 10000 10000 11110 10000 10000 10000',
  'G': '01110 10001 10000 10111 10001 10001 01111', 'H': '10001 10001 10001 11111 10001 10001 10001',
  'I': '01110 00100 00100 00100 00100 00100 01110', 'J': '00111 00010 00010 00010 00010 10010 01100',
  'K': '10001 10010 10100 11000 10100 10010 10001', 'L': '10000 10000 10000 10000 10000 10000 11111',
  'M': '10001 11011 10101 10101 10001 10001 10001', 'N': '10001 10001 11001 10101 10011 10001 10001',
  'O': '01110 10001 10001 10001 10001 10001 01110', 'P': '11110 10001 10001 11110 10000 10000 10000',
  'Q': '01110 10001 10001 10001 10101 10010 01101', 'R': '11110 10001 10001 11110 10100 10010 10001',
  'S': '01111 10000 10000 01110 00001 00001 11110', 'T': '11111 00100 00100 00100 00100 00100 00100',
  'U': '10001 10001 10001 10001 10001 10001 01110', 'V': '10001 10001 10001 10001 10001 01010 00100',
  'W': '10001 10001 10001 10101 10101 10101 01010', 'X': '10001 10001 01010 00100 01010 10001 10001',
  'Y': '10001 10001 10001 01010 00100 00100 00100', 'Z': '11111 00001 00010 00100 01000 10000 11111',
  ':': '00000 01100 01100 00000 01100 01100 00000', '.': '00000 00000 00000 00000 00000 01100 01100',
  '-': '00000 00000 00000 11111 00000 00000 00000', '/': '00001 00010 00010 00100 01000 01000 10000',
  '×': '00000 10001 01010 00100 01010 10001 00000', ' ': '00000 00000 00000 00000 00000 00000 00000',
  '(': '00010 00100 01000 01000 01000 00100 00010', ')': '01000 00100 00010 00010 00010 00100 01000',
};
const ROWS = {}; for (const k in G) ROWS[k] = G[k].split(' ');
// s = dot-matrix pixel size; outline = a 1-dot black border (the usual treatment for OSD characters)
export function text(x, str, px, py, s, col = '#f4f4ee', outline = true) {
  const draw = (ox, oy, c) => {
    x.fillStyle = c; let cx = px;
    for (const ch of str) {
      const g = ROWS[ch] || ROWS[' '];
      for (let r = 0; r < 7; r++) for (let q = 0; q < 5; q++) if (g[r][q] === '1') x.fillRect(cx + q * s + ox, py + r * s + oy, s, s);
      cx += 6 * s;
    }
  };
  if (outline) for (const [ox, oy] of [[-1, 0], [1, 0], [0, -1], [0, 1], [1, 1]]) draw(ox * Math.max(1, s * .5), oy * Math.max(1, s * .5), 'rgba(0,0,0,.85)');
  draw(0, 0, col);
  return str.length * 6 * s;
}
export const width = (str, s) => str.length * 6 * s - s;

// Draw one OSD frame. o = {rec, clock, date, bat, batBlink, title:[str,...], titleN (number of visible characters), counter, t}
export function drawOSD(cv, o) {
  const x = cv.getContext('2d'), W = cv.width, H = cv.height;
  x.clearRect(0, 0, W, H);
  if (o.hide) return;
  const s = 3;
  // REC ●
  if (o.rec) {
    x.fillStyle = 'rgba(0,0,0,.85)'; x.beginPath(); x.arc(58, 55, 10, 0, 7); x.fill();
    x.fillStyle = '#e8261c'; x.beginPath(); x.arc(58, 55, 8.5, 0, 7); x.fill();
    text(x, 'REC', 76, 45, s);
  }
  // Battery
  if (o.bat != null && !(o.batBlink && Math.floor(o.t * 2) % 2)) {
    const bx = W - 118, by = 44;
    x.fillStyle = 'rgba(0,0,0,.85)'; x.fillRect(bx - 2, by - 2, 58, 26); x.fillRect(bx + 54, by + 5, 8, 12);
    x.fillStyle = '#f4f4ee'; x.fillRect(bx, by, 54, 22); x.fillRect(bx + 54, by + 7, 5, 8);
    x.fillStyle = '#111'; x.fillRect(bx + 3, by + 3, 48, 16);
    x.fillStyle = o.bat <= 1 ? '#f4f4ee' : '#f4f4ee';
    for (let k = 0; k < o.bat; k++) x.fillRect(bx + 5 + k * 16, by + 5, 12, 12);
  }
  // Timecode + date (bottom right)
  if (o.clock) {
    const w1 = width(o.clock, s), w2 = width(o.date, s);
    text(x, o.clock, W - 50 - w1, H - 92, s);
    text(x, o.date, W - 50 - w2, H - 58, s);
  }
  // Tape counter (bottom left)
  if (o.counter) text(x, o.counter, 48, H - 58, s);
  // Character-generator title: large dot matrix, appearing character by character
  if (o.title) {
    const ts = 6, n = o.titleN ?? 999; let k = 0;
    o.title.forEach((ln, i) => {
      const vis = ln.slice(0, Math.max(0, Math.min(ln.length, n - k))); k += ln.length;
      const w = width(ln, ts);
      text(x, vis, (W - w) / 2, H * .36 + i * 66 - (o.title.length - 1) * 33, ts, '#fbfbf2');
    });
  }
}
