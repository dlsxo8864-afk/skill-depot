// The "negative" for the character art: first compute greyscale on offscreen pixels (R = amber, G = earth), then hand it to term.js, which averages per cell and picks characters from the density table.
// Fully deterministic: the same parameters always give the same picture.
import { W, H, cellsFromImage } from './term.js';

// ---------- Noise ----------
function hash3(x, y, z) { let h = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453; return h - Math.floor(h); }
function vn3(x, y, z) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  const xf = x - xi, yf = y - yi, zf = z - zi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf);
  const L = (a, b, t) => a + (b - a) * t;
  return L(L(L(hash3(xi, yi, zi), hash3(xi + 1, yi, zi), u), L(hash3(xi, yi + 1, zi), hash3(xi + 1, yi + 1, zi), u), v),
    L(L(hash3(xi, yi, zi + 1), hash3(xi + 1, yi, zi + 1), u), L(hash3(xi, yi + 1, zi + 1), hash3(xi + 1, yi + 1, zi + 1), u), v), w);
}
export function fbm3(x, y, z, oct = 5) { let s = 0, a = .5, f = 1, n = 0; for (let i = 0; i < oct; i++) { s += a * vn3(x * f, y * f, z * f); n += a; a *= .5; f *= 2.03; } return s / n; }
const sst = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

// ---------- Earth texture: rough continent outlines (lon/lat polygons) → land mask in equirectangular projection; clouds from noise + vortices ----------
const CONT = [
  // Africa
  [[-6,36],[10,37],[11,33],[20,31],[25,32],[32,31],[34,28],[39,20],[43,12],[51,12],[48,6],[44,2],[40,-10],[40,-16],[35,-24],[33,-29],[27,-34],[20,-35],[18,-30],[15,-27],[12,-18],[13,-12],[9,-2],[9,4],[5,6],[-2,5],[-8,4],[-13,8],[-17,14],[-17,21],[-13,27],[-10,30]],
  [[44,-13],[50,-15],[47,-25],[44,-22]],                                                     // Madagascar
  [[35,28],[39,22],[43,13],[52,16],[59,22],[56,26],[50,30],[48,30],[36,32]],                   // Arabian Peninsula
  [[36,32],[36,37],[40,41],[50,42],[55,45],[62,42],[66,36],[62,26],[57,25],[50,30]],           // Middle East – Central Asia
  [[-9,37],[-2,37],[3,43],[7,44],[9,44],[12,42],[16,38],[18,40],[13,45],[19,42],[22,37],[26,40],[29,41],[30,45],[40,47],[50,48],[60,55],[60,68],[40,68],[30,70],[25,71],[15,68],[8,62],[5,60],[8,58],[10,55],[8,54],[4,52],[2,51],[-2,49],[-5,48],[-1,46],[-2,44],[-9,43]],  // Europe
  [[-5,50],[1,51],[0,53],[-2,56],[-5,58],[-6,56],[-3,54],[-5,52]],                            // Great Britain
  [[-35,-5],[-40,-3],[-50,0],[-60,8],[-72,12],[-78,5],[-80,-3],[-75,-15],[-70,-20],[-70,-35],[-68,-50],[-72,-53],[-65,-55],[-58,-38],[-48,-28],[-40,-22],[-38,-13]],  // South America
  [[-45,60],[-20,70],[-20,82],[-60,82],[-55,70]],                                             // Greenland
  // Asia: one landmass, no borders (the eastern part sits on the night side in this view, but the whole continent is drawn)
  [[60,69],[68,69],[73,72],[80,73],[87,75],[100,77],[105,78],[113,74],[128,73],[140,72],[150,71],[160,70],[170,70],[180,69],[180,65],[178,62],[170,60],[165,60],[163,57],[156,51],[156,57],[152,59],[143,59],[137,54],[141,53],[140,48],[135,43],[131,43],[129,41],[129,35.2],[126.5,34.4],[126,37.5],[125,39.8],[121.5,39],[121,40.8],[118,39],[118.5,38],[122.5,37.4],[119.5,35],[120.5,33],[121.8,31],[122,29.9],[121,28],[119.5,26],[117.5,23.6],[114,22.3],[110.5,21.3],[110,20.3],[109.5,21.5],[108,21.5],[106.5,20],[106,18],[108.8,15],[109.2,12],[107,10.5],[105,8.7],[104.5,10.5],[103,11],[100,13.5],[99.2,10],[100.5,7],[101,6.8],[103.4,4.5],[104,1.3],[102.5,2],[100.3,4],[98.5,8],[98.4,12],[97.6,16.5],[94.5,16],[94,18.5],[92,21],[90,22],[88,21.5],[87,21],[85,19.5],[82,16.5],[80.2,15],[80.2,13],[79.8,10.3],[78,8.2],[77,8.1],[76,10],[74.5,14],[73,18],[72.6,21.2],[70,21],[68.8,23],[67,24.8],[66,25.4],[61.6,25.2],[62,30],[66,36],[62,42],[55,45],[53,47],[50,48],[60,55]],
  [[120.1,23],[120.7,22],[121.6,23.5],[122,25],[121.5,25.3],[120.7,24.5]],                    // Taiwan
  [[108.6,19.2],[109.6,18.2],[110.9,19],[110.6,20.1],[109.5,20],[108.7,19.8]],                // Hainan
  [[79.8,8],[80.1,6],[81.8,6.6],[81.2,8.8],[80.2,9.8]],                                       // Sri Lanka
  [[130.9,31.5],[131.5,33.5],[132.5,35],[135.3,35.7],[136.8,37.3],[139.5,38.3],[140,41],[141.5,40.5],[141,37],[140.8,35.5],[139.8,35],[137,34.5],[135,33.5],[132,33.2]],  // Japan
  [[140,41.5],[141.5,45.4],[145.5,43.4],[143.5,42],[141.2,42.4]],                             // Hokkaido
  [[142,46],[143.5,49],[143,54.3],[142.3,53.5],[142,49]],                                     // Sakhalin
  [[52,71],[56,74],[62,76.5],[68,77],[58,73],[56,70.5]],                                      // Novaya Zemlya
  [[95.3,5.6],[97.5,5.2],[100.5,2],[104,-1],[106,-3],[106,-5.8],[104.5,-5.9],[102,-4],[100,-1],[98.5,1.6]],  // Sumatra
  [[109,1.5],[111,2],[113.5,3.5],[116,6.9],[119,5],[118,1],[117.3,-1],[116,-3.8],[114.5,-3.5],[110.2,-3],[109.5,-1]],  // Borneo
  [[105.3,-6.8],[108,-6.3],[111,-6.5],[114.5,-7.7],[114.4,-8.7],[110,-8.1],[106,-7.4]],       // Java
  [[120,18.5],[122.2,18.5],[122,16],[124,13],[121,13.8],[120.5,15]],                          // Luzon
];
const TW = 720, TH = 360;
let LAND = null, CLOUD = null;
function initEarthTex() {
  const c = document.createElement('canvas'); c.width = TW; c.height = TH;
  const g = c.getContext('2d', { willReadFrequently: true });
  g.fillStyle = '#000'; g.fillRect(0, 0, TW, TH); g.fillStyle = '#fff';
  for (const poly of CONT) { g.beginPath(); poly.forEach(([lo, la], i) => { const x = (lo + 180) * 2, y = (90 - la) * 2; i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.closePath(); g.fill(); }
  // Ice caps
  g.fillRect(0, 0, TW, 10); g.fillRect(0, TH - 26, TW, 26);
  const d = g.getImageData(0, 0, TW, TH).data;
  LAND = new Float32Array(TW * TH); CLOUD = new Float32Array(TW * TH);
  for (let j = 0; j < TH; j++) for (let i = 0; i < TW; i++) {
    const lo = i / TW * Math.PI * 2, la = (.5 - j / TH) * Math.PI;
    const x = Math.cos(la) * Math.cos(lo), y = Math.sin(la), z = Math.cos(la) * Math.sin(lo);
    // add a little ragged edge to the coastlines
    const edge = (fbm3(x * 6 + 3, y * 6, z * 6, 3) - .5) * .5;
    LAND[j * TW + i] = Math.max(0, Math.min(1, d[(j * TW + i) * 4] / 255 + edge * (d[(j * TW + i) * 4] > 20 && d[(j * TW + i) * 4] < 235 ? 1 : 0)));
    // clouds: bands stretched along latitude + a few vortices
    const sw = Math.sin(la * 3) * 1.2;
    const cl = fbm3(x * 2.6 + sw * z, y * 5 + 1, z * 2.6 - sw * x, 5);
    const band = .6 + .4 * Math.cos(la * 6);
    CLOUD[j * TW + i] = sst(.58, .74, cl * (.8 + .25 * band)) * (1 - sst(.9, 1.2, Math.abs(la)));
  }
}
function earthTex(lo, la) {
  let i = Math.floor((((lo + Math.PI) / (Math.PI * 2)) % 1 + 1) % 1 * TW), j = Math.floor((.5 - la / Math.PI) * TH);
  j = Math.max(0, Math.min(TH - 1, j)); i = Math.min(TW - 1, i);
  return [LAND[j * TW + i], CLOUD[j * TW + i]];
}

// Earth surface shading: (nx, ny) inside the unit circle → [brightness, is night side]
export function earthShade(nx, ny, P, Lx = -.66 / 1.0, Ly = -.26, Lz = .7) {
  if (!LAND) initEarthTex();
  const nz = Math.sqrt(Math.max(0, 1 - nx * nx - ny * ny));
  const ct = Math.cos(P.tiltE || 0), st = Math.sin(P.tiltE || 0);
  const vx = nx * ct - ny * st, vy = -(nx * st + ny * ct), vz = nz;
  const la0 = P.lat0, lo0 = P.lon0 + (P.spin || 0);
  const y1 = vy * Math.cos(la0) + vz * Math.sin(la0), z1 = -vy * Math.sin(la0) + vz * Math.cos(la0);
  const la = Math.asin(Math.max(-1, Math.min(1, y1))), lo = lo0 + Math.atan2(vx, z1);
  const [land, cloud] = earthTex(lo, la);
  let alb = .14 + land * .82;
  alb = alb * (1 - cloud * .85) + .5 * cloud * .85;
  const ndl = nx * Lx + ny * Ly + nz * Lz;
  const lit = sst(-.03, .1, ndl);
  let v = alb * (.35 + .65 * Math.max(0, ndl)) * lit;
  v += Math.pow(1 - nz, 3) * .35 * lit;
  return [v, lit < .5 ? 1 : 0];
}

// ---------- Canvas ----------
export class Art {
  constructor(cols, rows, sx = 2, sy = 4) {
    this.cols = cols; this.rows = rows; this.sx = sx; this.sy = sy;
    this.w = cols * sx; this.h = rows * sy;
    this.cv = document.createElement('canvas'); this.cv.width = this.w; this.cv.height = this.h;
    this.g = this.cv.getContext('2d', { willReadFrequently: true });
  }
  clear() { this.g.globalCompositeOperation = 'source-over'; this.g.globalAlpha = 1; this.g.fillStyle = '#000'; this.g.fillRect(0, 0, this.w, this.h); }
  img() { return this.g.getImageData(0, 0, this.w, this.h); }
  put(id) { this.g.putImageData(id, 0, 0); }
  cells() { return cellsFromImage(this.img().data, this.w, this.cols, this.rows, this.sx, this.sy); }
}

// Horizon height (screen pixels): a gentle arc + low distant ridges
export function horizonY(X, P) {
  const u = X / W - .5;
  return P.hy + u * u * P.arc + P.tilt * u - (fbm3(X * .004 + 11, 3, 0, 4) - .5) * P.ridge - Math.max(0, fbm3(X * .0017 + 5, 7, 1, 3) - .52) * P.ridge * 2.4;
}

// Lunar surface + Earth (parameters in screen coordinates), written into Art's pixels: R = amber brightness, G = earth brightness
// P: { hy, arc, tilt, ridge, ex, ey, er, earthMix(0 amber → 1 blue), spin, stars }
export function paintEarthrise(art, P) {
  if (!LAND) initEarthTex();
  const id = art.img(), d = id.data, aw = art.w, ah = art.h;
  const kx = (P.cw || 9) / art.sx, ky = (P.cw || 9) * 2 / art.sy;   // strictly aligned to the character grid
  const hz = new Float32Array(aw);
  for (let x = 0; x < aw; x++) hz[x] = horizonY((x + .5) * kx, P);
  // Light comes from the top left (the sun is off-frame left); the Earth is gibbous with its lit side to the left
  let Lx = -.66, Ly = -.26, Lz = .7; const ln = Math.hypot(Lx, Ly, Lz); Lx /= ln; Ly /= ln; Lz /= ln;
  const craters = P.craters || [];
  for (let y = 0; y < ah; y++) {
    const Y = (y + .5) * ky;
    for (let x = 0; x < aw; x++) {
      const X = (x + .5) * kx, o = (y * aw + x) * 4;
      let amb = 0, ea = 0, night = 0;
      const h = hz[x];
      if (Y < h) {
        // sky: Earth + a few stars
        const nx = (X - P.ex) / P.er, ny = (Y - P.ey) / P.er, r2 = nx * nx + ny * ny;
        if (r2 < 1) {
          const sh = earthShade(nx, ny, P, Lx, Ly, Lz); ea = sh[0]; night = sh[1];
        } else if (r2 < 1.1) {
          const rr = Math.sqrt(r2); ea = sst(1.06, 1.0, rr) * .28 * sst(-.3, .6, (nx * Lx + ny * Ly) / rr);
        }
        if (P.stars && ea === 0) {   // stars: only on one pixel block at a cell's centre, one per cell
          const cw = P.cw || 9, ci = Math.floor(X / cw), cj = Math.floor(Y / (cw * 2)), sh = hash3(ci, cj, 3.3);
          if (sh > .9955) amb = .075 + (sh - .9955) * 12;
        }
      } else {
        // lunar surface: dark-grey base + texture stretched along depth (for perspective), a bright edge along the horizon; craters' left inner walls are in shadow, right inner walls lit by the low sun
        const depth = Math.min(1, (Y - h) / ((P.bottom || H) - h + 1));           // 0 horizon → 1 bottom of frame
        const sc = .25 + depth * 2.2;
        const tex = fbm3(X * .012 / sc, Y * .07 / sc, 1.5, 4);
        let v = (.17 + (tex - .5) * .3) * (.3 + 1.0 * depth);   // darker and sparser far away, brighter and denser up close
        const mare = fbm3(X * .0022 / sc, Y * .012 / sc, 9, 3);         // large dark "maria" (seas) and bright highlands
        v *= .45 + 1.3 * sst(.3, .7, mare);
        v += Math.exp(-(Y - h) / 10) * .3;
        for (const k of craters) {
          const rx = k.r, ry = k.r * k.sq;
          const u = (X - k.x) / rx, w = (Y - k.y) / ry, rr = u * u + w * w;
          if (rr > 1.7) continue;
          const r1 = Math.sqrt(rr);
          if (r1 < 1) {
            // shadow line: cast in from the left rim, most of the bowl's left side is black
            const edge = -Math.sqrt(Math.max(0, 1 - w * w));
            const lit = u > edge + .75 * (1 - .4 * w);
            v = lit ? (.14 + .55 * sst(-.2, 1, u) * (1 - .4 * Math.max(0, w))) * (.55 + .7 * depth) : .0;
          } else {
            // crater rim: the top-left rim faces the light and is brightest, a bright lip on the near (lower) edge, the right side dark
            const rim = sst(1.3, 1.0, r1);
            v += (rim * (u < .2 ? .34 : .08) + rim * Math.max(0, w) * .2) * (.5 + .9 * depth);
            if (u > .3 && r1 < 1.6) v *= 1 - .5 * sst(1.6, 1.05, r1) * sst(.3, .9, u);   // the outer right side falls in the rim's shadow
          }
        }
        amb = Math.max(0, v);
      }
      const m = P.earthMix;
      d[o] = Math.min(255, (amb + ea * (1 - m)) * 255); d[o + 1] = Math.min(255, ea * m * 255); d[o + 2] = night * 255; d[o + 3] = 255;
    }
  }
  art.put(id);
}

// A fixed set of craters (screen coordinates), bigger near, smaller far
export function makeCraters(P, n = 16, seed = 7) {
  let s = seed; const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  const out = [];
  for (let i = 0; i < n; i++) {
    const X = rnd() * W;
    const h = horizonY(X, P);
    const depth = Math.pow(rnd(), .8);
    const Y = h + 14 + depth * ((P.bottom || H) - h);
    const r = 10 + depth * depth * 70 * (.5 + rnd());
    out.push({ x: X, y: Y, r, sq: .22 + depth * .2 });
  }
  // a few large craters in the foreground with clear outlines
  for (const [fx, fd, fr] of [[.2, .88, 250], [.78, .8, 190], [.47, .5, 95]]) {
    const X = fx * W, h = horizonY(X, P);
    out.push({ x: X, y: h + 14 + fd * ((P.bottom || H) - h), r: fr, sq: .26 + fd * .12 });
  }
  return out.sort((a, b) => a.y - b.y);
}
