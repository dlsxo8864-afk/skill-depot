# Setup prompt

Paste everything below the line into Claude Code (desktop app or terminal) on the computer that should
learn the method.

---

I want you to be able to draw and animate 2D game characters in code at high quality, using exactly the
method of my "Ratislav" project. Everything you need is in this public GitHub repository:
https://github.com/matejbrundaek1/sprite-animation-kit

The method: Python draws the character as a puppet of vector parts and poses every frame by numbers.
Automatic checks measure every frame: limbs never stretch, feet never slide, loops close. You look at
close-ups before judging anything. The build exports a sprite sheet with JSON for game engines, GIF
previews, a model sheet and a playable web page. Everything is free and runs locally, with no image
generators and no paid services. I will choose the character and the art style later. Right now, set
yourself up and prove that it works.

1. **Install.**
   - Check that git and Python 3.9 or newer work on this computer. On Windows the Python command is
     usually `py`. If something is missing, tell me in plain words what to install and how.
   - Clone the repository into a folder of your choice. Run its installer from inside that folder:
     `python3 install.py` (on Windows: `py install.py`). The installer does four things:
     - copies two skills into ~/.claude/skills: `cartoon-sprite-animator` and `design-from-21st`;
     - installs the free libraries shapely, PyMuPDF and Pillow;
     - fetches six companion skills from their authors' GitHub repositories:
       `2d-character-rig-animation`, `character-design-continuity`, `animator-traditional`,
       `game-development`, `follow-through-overlapping` and `find-skills`;
     - runs a self-test that must print PASS.
   - If any step fails, find the cause, fix it and run the installer again until every line says ok.
     Never skip the self-test.
2. **Load the method.**
   - Skills are loaded when a session starts. If `cartoon-sprite-animator` is not in your skill list yet,
     tell me to start a new session and paste this prompt again. The installer is safe to repeat.
   - Read the whole `cartoon-sprite-animator` skill, then its `references/animation-standard.md`, then the
     companion skills `2d-character-rig-animation` and `game-development`. These are the rules you follow.
3. **Prove it works.**
   - In a scratch folder, copy the skill's `scripts/drawn` files into `rig/`. Run `rig/build.py --quick`
     and then `rig/look.py closeup idle:0 walk:2 attack:4`. Open the pictures and look at them yourself.
   - Show me the check report and the close-up, and tell me in two sentences what the pipeline makes.
4. **Optional extras.** The original project used these. Tell me if you can't use one.
   - In the Claude desktop app you have two built-in tools:
     - the Artifact tool, to publish the playable demo page privately, with its images as supporting files;
     - a built-in browser, to test the page through a local `python -m http.server`.

     Without them, open the demo page in any browser.
   - Before you design the demo page, use the `design-from-21st` skill. It reads the free 21st.dev
     component catalog through the Firecrawl connector or through the built-in browser. Firecrawl has a
     free plan; I may need to connect it in Claude's connector settings.
5. **Work like this every time I give you a character and a style.**
   - Write a short design brief first and show it to me. It covers the silhouette, two or three
     signature features, a palette of at most 12 named colours, and the proportions.
   - Build the character module from the skill's example and keep its rig contract. Animate idle, walk,
     jump and attack, or whatever I ask for. Use the timings in the animation standard as a starting point.
   - After every change, run `build.py --quick` and then the `look.py` close-ups. Look at the pictures
     before you say anything about quality. The check report must end with `RESULT: PASS`. Fix each
     problem by its cause, using the defect classes in the skill.
   - Finish with the full build: model sheet, GIFs and demo page. Show me the results as pictures.
   - Draw only original characters. "In the style of X" means general traits only, never X's characters,
     names or logos. Use only free tools.
   - Talk to me in Czech, in plain non-technical language. Say plainly what works and what does not.
