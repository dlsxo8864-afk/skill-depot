#!/usr/bin/env python3
"""Install the sprite animation kit for Claude Code on this computer (macOS, Windows or Linux).

    python3 install.py          (Windows: py install.py)

What it does, in order:
  1. copies this kit's skills (skills/*) into ~/.claude/skills, moving any older copy to
     ~/.claude/skills-backup/<date> first;
  2. installs the free Python libraries the drawing code needs (shapely, PyMuPDF, Pillow);
  3. downloads the companion skills straight from their authors' GitHub repositories (needs git);
  4. runs a self-test: renders all 33 frames of the example character and checks that they PASS.

Options: --no-companions (skip 3), --no-test (skip 4), --skills-dir DIR (install somewhere else).
Run it again at any time to update; it is safe to repeat.
"""
import argparse
import datetime
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMPANIONS = [   # (GitHub repository, folder of the skill inside it): fetched from the authors, not copied here
    ("vercel-labs/skills", "skills/find-skills"),
    ("calesthio/generative-media-skills", "skills/production/creative-direction/2d-character-rig-animation"),
    ("calesthio/generative-media-skills", "skills/production/creative-direction/character-design-continuity"),
    ("dylantarre/animation-principles", "skills/03-by-role-persona/animator-traditional"),
    ("dylantarre/animation-principles", "skills/01-by-domain/game-development"),
    ("dylantarre/animation-principles", "skills/11-by-principle-focus/follow-through-overlapping"),
]
IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store", "out", ".git")


def say(msg=""):
    print(msg, flush=True)


def place(src, skills_dir, backup_dir):
    """Copy one skill folder into skills_dir; an existing copy is moved to backup_dir first."""
    dst = skills_dir / src.name
    if dst.exists():
        backup_dir.mkdir(parents=True, exist_ok=True)
        shutil.move(str(dst), str(backup_dir / src.name))
    shutil.copytree(str(src), str(dst), ignore=IGNORE)
    say("  installed  %s" % src.name)


def install_own(skills_dir, backup_dir):
    say("1/4  Skills from this kit -> %s" % skills_dir)
    for src in sorted((HERE / "skills").iterdir()):
        if (src / "SKILL.md").exists():
            place(src, skills_dir, backup_dir)
    return True


def install_libraries():
    say("2/4  Python libraries (free): shapely, PyMuPDF, Pillow")
    base = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-warn-script-location",
            "-q", "-r", str(HERE / "requirements.txt")]
    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    attempts = [base] if in_venv else [base + ["--user"], base + ["--user", "--break-system-packages"]]
    for cmd in attempts:                      # the second try is for Pythons that refuse user installs
        if subprocess.run(cmd).returncode == 0:
            break
    check = subprocess.run([sys.executable, "-c", "import shapely, fitz, PIL; print(shapely.__version__, "
                            "fitz.VersionBind, PIL.__version__)"], capture_output=True, text=True)
    if check.returncode != 0:
        say("  FAILED: the libraries do not import. Error:\n" + check.stderr.strip()[-800:])
        say("  Fix: make sure pip works for %s, then run this installer again." % sys.executable)
        return False
    say("  ok  shapely %s, PyMuPDF %s, Pillow %s" % tuple(check.stdout.split()))
    return True


def install_companions(skills_dir, backup_dir):
    say("3/4  Companion skills from their authors (GitHub)")
    if shutil.which("git") is None:
        say("  FAILED: git is not installed. Install git, or run for each skill:")
        for repo, path in COMPANIONS:
            say("    npx skills add %s@%s -g -y" % (repo, path.rsplit("/", 1)[-1]))
        return False
    ok, tmp = True, Path(tempfile.mkdtemp(prefix="sprite-kit-companions-"))
    try:
        clones = {}
        for repo, path in COMPANIONS:
            if repo not in clones:
                dest = tmp / repo.replace("/", "_")
                run = subprocess.run(["git", "clone", "--depth", "1", "--quiet",
                                      "https://github.com/%s.git" % repo, str(dest)],
                                     capture_output=True, text=True)
                clones[repo] = dest if run.returncode == 0 else None
                if run.returncode != 0:
                    say("  FAILED to download %s: %s" % (repo, run.stderr.strip()[-300:]))
            src = clones[repo] / path if clones[repo] else None
            if src is not None and (src / "SKILL.md").exists():
                place(src, skills_dir, backup_dir)
            else:
                say("  MISSING  %s (from %s) - the author may have moved it; search with find-skills" %
                    (path.rsplit("/", 1)[-1], repo))
                ok = False
    finally:
        shutil.rmtree(str(tmp), ignore_errors=True)
    return ok


def self_test(skills_dir):
    say("4/4  Self-test: render the example character and run its checks (a minute or two)")
    src = skills_dir / "cartoon-sprite-animator" / "scripts" / "drawn"
    tmp = Path(tempfile.mkdtemp(prefix="sprite-kit-test-"))
    shutil.copytree(str(src), str(tmp / "rig"), ignore=IGNORE)
    run = subprocess.run([sys.executable, str(tmp / "rig" / "build.py"), "--quick"],
                         capture_output=True, text=True)
    report = tmp / "out" / "qa" / "report.txt"
    text = report.read_text(encoding="utf-8") if report.exists() else ""
    if run.returncode == 0 and text.rstrip().endswith("RESULT: PASS"):
        say("  PASS  33 frames rendered; limbs, feet and loops check out")
        shutil.rmtree(str(tmp), ignore_errors=True)
        return True
    say("  FAILED. Test folder kept for inspection: %s" % tmp)
    say((run.stdout + run.stderr).strip()[-1500:])
    return False


def main():
    ap = argparse.ArgumentParser(description="Install the sprite animation kit for Claude Code.")
    ap.add_argument("--skills-dir", default=str(Path.home() / ".claude" / "skills"))
    ap.add_argument("--no-companions", action="store_true", help="skip the companion skills")
    ap.add_argument("--no-test", action="store_true", help="skip the self-test")
    a = ap.parse_args()
    if sys.version_info < (3, 9):
        say("Python 3.9 or newer is needed; this is %s." % sys.version.split()[0])
        return 1
    skills_dir = Path(a.skills_dir).expanduser().resolve()
    skills_dir.mkdir(parents=True, exist_ok=True)
    backup_dir = skills_dir.parent / "skills-backup" / datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    results = {"skills": install_own(skills_dir, backup_dir), "libraries": install_libraries()}
    results["companions"] = True if a.no_companions else install_companions(skills_dir, backup_dir)
    if a.no_test:
        results["self-test"] = True
    else:
        results["self-test"] = results["libraries"] and self_test(skills_dir)

    say()
    for step, ok in results.items():
        say("  %-10s %s" % (step, "ok" if ok else "FAILED"))
    if backup_dir.exists():
        say("  older copies of replaced skills: %s" % backup_dir)
    if all(results.values()):
        say("\nDone. Start a new Claude Code session so it loads the new skills, then ask it to read")
        say("the cartoon-sprite-animator skill and its references/animation-standard.md.")
        return 0
    say("\nSome steps failed (see above). Fix the cause and run the installer again.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
