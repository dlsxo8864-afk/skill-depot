# Sprite animation kit for Claude Code

Lets Claude draw an original 2D game character in code and animate it at high quality, entirely with
free, local tools. The character is a puppet of vector parts posed frame by frame. Every frame is
checked automatically: limbs keep their length, planted feet do not slide, and loops close. The build
exports a sprite atlas with Aseprite-style JSON, per-animation strips, GIF previews, a model sheet and a
playable browser demo.

Worked example: Ratislav, a rat swordsman. He has 4 animations and 33 frames, and all automatic checks pass.

![Showreel](examples/showreel.gif)

| Model sheet | Close-up review of hands and face |
| --- | --- |
| ![Model sheet](examples/model_sheet.png) | ![Close-ups](examples/closeup.png) |

## Install

Give Claude Code the prompt in [SETUP-PROMPT.md](SETUP-PROMPT.md). To install by hand instead:

```bash
git clone https://github.com/matejbrundaek1/sprite-animation-kit
cd sprite-animation-kit
python3 install.py        # Windows: py install.py
```

The installer runs four steps:

1. It copies the kit's skills into `~/.claude/skills`, moving any older copies to
   `~/.claude/skills-backup/`.
2. It installs shapely, PyMuPDF and Pillow.
3. It fetches the companion skills from their authors.
4. It runs a self-test that renders all 33 frames and must print PASS.

You need Python 3.9 or newer and git. Start a new Claude Code session afterwards so the skills load.

To update, run `git pull` and then `python3 install.py` again.

## What is inside

| Path | What it is |
| --- | --- |
| `skills/cartoon-sprite-animator/` | The toolkit and the method. |
| `skills/design-from-21st/` | How the demo page was designed: real component patterns from the free 21st.dev catalog, never a generic layout. |
| `install.py`, `requirements.txt` | Cross-platform installer and the three free Python libraries. |
| `examples/` | Output of the worked example. |

The toolkit in `skills/cartoon-sprite-animator/` contains:

- `SKILL.md`: the workflow, both looks, how to change the art style, and the gotchas.
- `references/animation-standard.md`: the twelve principles as checks, game feel, and rules for hands, props, faces and scenery.
- `scripts/drawn/`: the default hand-inked look. It holds:
  - `inkkit` (renderer)
  - character
  - animations
  - painted scenery
  - `build.py` (with `--quick`)
  - `look.py` (close-ups and contact sheets)
- `scripts/`: the sticker look.
- `templates/`: the demo pages.

## Companion skills (installed from their authors, not copied here)

| Skill | Source | Adds |
| --- | --- | --- |
| 2d-character-rig-animation | [calesthio/generative-media-skills](https://github.com/calesthio/generative-media-skills) (MIT) | Rig contract, cycles, defect vocabulary, rig QA |
| character-design-continuity | [calesthio/generative-media-skills](https://github.com/calesthio/generative-media-skills) (MIT) | Character bible and model-sheet discipline for a new design |
| animator-traditional | [dylantarre/animation-principles](https://github.com/dylantarre/animation-principles) (MIT) | The twelve classic principles |
| game-development | [dylantarre/animation-principles](https://github.com/dylantarre/animation-principles) (MIT) | The principles applied to game feel: hit-stop, frame data |
| follow-through-overlapping | [dylantarre/animation-principles](https://github.com/dylantarre/animation-principles) (MIT) | Drag and settle for tails, ears, hair and cloth |
| find-skills | [vercel-labs/skills](https://github.com/vercel-labs/skills) | Searching the public skill catalog for more |

## The method in short

1. Brief first: silhouette, signature features, a palette of at most 12 named colours, proportions.
2. Build a puppet of parts with a fixed rig contract (`Pose`, `draw_pose`, `info`).
3. Draw one pen line around the whole silhouette, and inner lines only where a part really overlaps another.
4. Limbs are rubber-hose curves of fixed length. A planted foot moves at exactly the ground speed.
   Actions are animated pose to pose: anticipation, action, hold, settle.
5. Measure every frame (`build.py --quick`), then look at close-ups (`look.py`) before judging anything.
   Fix each problem by its cause.
6. Use only free tools and only original characters.

## Licence

This kit is MIT-licensed (see `LICENSE`). Companion skills keep their own licences. They are downloaded
from their authors and are not redistributed here.
