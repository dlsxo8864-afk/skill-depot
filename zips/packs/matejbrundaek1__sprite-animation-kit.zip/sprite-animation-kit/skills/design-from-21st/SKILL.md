---
name: design-from-21st
description: Use BEFORE writing any user interface, web page, app screen, landing page, dashboard, form, or visual layout — and before choosing colours, fonts, spacing or component structure. Pulls real, high-quality component patterns from the 21st.dev catalog instead of inventing generic layouts from scratch. Triggers on - build a site, build an app, make a page, design a screen, hero section, pricing table, navbar, dashboard, landing page, form, card, modal, make it look better, improve the design, make it more interesting.
---

# Design from 21st.dev

Matej's standing instruction: **never hand-roll a plain-looking interface.** Every UI you build
should start from a real, well-crafted component pattern from the 21st.dev catalog, then be
adapted to the project. Generic Bootstrap-looking output is a failure, even if it works.

## Step 1 — Check which route is available

Run the check in this order and use the first one that works:

**Route A — the 21st MCP server (best).** If tools from the `21st` MCP server are available in
this session (names like `search`, `get_code`, `get_inspiration`, `generate`, `search_logo`),
use them. Search the catalog for the block you need, retrieve the code, adapt it.
If ToolSearch is present and those tools aren't loaded yet, load them first:
`ToolSearch` with query `select:mcp__21st__search,mcp__21st__get_code,mcp__21st__get_inspiration`.

**Route B — the public catalog over the web (free, no account, VERIFIED WORKING).**
The 21st.dev catalog is fully public, including component source code. **But the pages build
themselves with JavaScript, so `WebFetch` and `curl` return an empty shell — they look like they
worked and give you nothing.** You must use a scraper that renders the page:

Use the Firecrawl scrape tool (`firecrawl_scrape`, load it via ToolSearch if deferred) with:
- `waitFor: 6000` — gives the page time to draw itself
- `maxAge: 0` — forces a fresh copy
- `formats: ["markdown"]` to browse a category, or `formats: ["query"]` with a `queryOptions`
  prompt to pull the code and styling notes off a single component page

Two steps:

1. **Browse a category** — scrape `https://21st.dev/s/<category>` with `formats: ["markdown"]`.
   You get back a list of every component with its author and its direct URL. Category output is
   large (~60k characters); it saves to a file, so grep that file for the component URLs rather
   than reading it whole. Useful categories: `hero`, `pricing-section`, `navbar`, `footer`,
   `feature-sections`, `testimonials`, `cards`, `forms`, `tables`, `dashboard`, `buttons`,
   `modals`, `sidebar`, `calls-to-action`, `faq`, `text-effects`, `backgrounds`, `sign-in`,
   `accordions`, `inputs`, `charts`.

2. **Open 2–3 promising components** — scrape their URLs (they look like
   `https://21st.dev/@author/components/name`). Ask for the source code plus a description of
   the layout, colours and styling approach. The page metadata also carries a written feature
   list for the component, which is often the fastest read.

If Firecrawl is unavailable, the in-app Browser tools (`preview_start` with the URL, then
`get_page_text`) also render the page correctly. Plain `WebFetch` does not — never rely on it
for this site.

**Route C — no network.** Fall back to the design principles below. Say plainly in your reply
that you could not reach the catalog, so Matej knows why the result may be plainer.

## Step 2 — What to actually take from the catalog

Take the *thinking*, not just the markup:

- **Structure** — how the section is composed (asymmetric grids, offset images, layered cards)
- **Rhythm** — the spacing scale, how much air sits around things
- **Type** — the size jump between headline and body, weight contrast, tracking on large text
- **Depth** — gradients, subtle borders, soft shadows, glass, noise, glow
- **Motion** — entrance transitions, hover states, scroll reveals
- **The one interesting move** — good sections almost always have a single unexpected element.
  Find it and keep an equivalent.

## Step 3 — Non-negotiable quality bar

Whatever route you took, the finished UI must clear all of these:

1. **Dark mode and light mode both work.** Define colours as tokens once, redefine only the
   tokens for dark. Never leave a background transparent.
2. **Responsive.** Nothing scrolls sideways on a phone. Tables, code blocks and wide diagrams
   scroll inside their own box.
3. **Real spacing scale.** Pick one scale (4/8/12/16/24/32/48/64) and stick to it. Sections get
   generous vertical padding — cramped is the most common failure.
4. **Type hierarchy with a real jump.** Headlines meaningfully larger and tighter than body
   text. Body text 16px minimum, line length capped around 65–75 characters.
5. **Restrained palette.** One accent colour, used sparingly. Neutrals do the heavy lifting.
6. **Every interactive thing has hover, focus and active states.** Focus rings stay visible —
   keyboard users need them.
7. **Contrast passes.** Body text at least 4.5:1 against its background.
8. **No stock-template smell.** No default blue buttons, no unstyled `<select>`, no centre-
   aligned everything, no lorem ipsum in a deliverable.

## Using this together with the `design` skill (Claude Design canvas)

The design canvas builds **`.dc.html` artboards** — plain web pages. So 21st.dev fits it well,
but at the level of *design*, not copy-paste:

- **What transfers directly:** layout and composition, spacing rhythm, type hierarchy, colour
  treatment, gradients/shadows/glass/glow, the "one interesting move" in each section. This is
  the majority of what makes a design look good.
- **What does not transfer as-is:** the code. Catalog components are React with Tailwind
  classes; artboards are HTML. Rebuild the pattern in the artboard rather than pasting JSX.
  Tailwind utility classes are a fine intermediate step — translate them to real CSS if the
  artboard has no Tailwind available.
- **Order matters:** collect the references *first*, then draw the artboards. Retrofitting a
  bland artboard afterwards means redoing it.

Practical sequence: scrape 2–3 catalog components for the section you need → note the specific
moves worth stealing → build the artboard with those moves → then hand it over so Matej can
nudge it by hand in the canvas editor.

## Step 4 — Report back to Matej in plain words

Tell him which route you used and where the design ideas came from, e.g. "I based the top
section on three hero layouts from the 21st.dev catalog — the offset image and the gradient
edge come from those." One or two sentences. No jargon.

## If the 21st MCP is connected but failing

Free 21st.dev accounts allow unlimited catalog *search* but only about 2 component *installs*
per day, and AI generation needs paid credits. If a tool refuses with a limit or credit error,
say so plainly in one line, switch to Route B, and carry on. Do not stall and do not ask Matej
to buy anything mid-task.
