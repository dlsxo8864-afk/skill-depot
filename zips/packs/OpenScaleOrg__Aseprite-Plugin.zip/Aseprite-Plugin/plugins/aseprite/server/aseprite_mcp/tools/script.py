import os
from ..core import live
from ..core.commands import AsepriteCommand
from .. import mcp

# In live mode the window only redraws when a call returns, so one big script
# shows the whole picture at once. Cap scripts so work arrives in visible steps.
MAX_LIVE_LINES = int(os.getenv("ASEPRITE_LIVE_MAX_LUA_LINES", "40"))


def _code_lines(script: str) -> int:
    return sum(1 for line in script.splitlines()
               if line.strip() and not line.strip().startswith("--"))


@mcp.tool()
async def run_lua_script(script: str, filename: str = "") -> str:
    """Execute arbitrary Aseprite Lua code in batch mode (last resort).

    Reach for a dedicated tool first: draw_rows / read_rows to place and
    read pixels as text, draw_text for numbers and labels, replace_color or
    remap_colors_in_cel_range to recolour, export_animation or export_tag
    for GIFs, compare_frames and get_bounds to measure motion, view_sprite
    to look. Use Lua only for what none of them covers, such as a custom
    procedural effect. The full API is documented at
    https://www.aseprite.org/api/.

    Essentials for batch-mode scripts:
    - When filename is given, it is opened first and available as
      app.activeSprite.
    - Changes are NOT saved automatically; call spr:saveAs(spr.filename)
      at the end if you modified the sprite.
    - print() is the only way to return data; a clean exit does not mean
      your logic succeeded, so print what you need to verify.
    - Coordinates on cel images are cel-local: offset sprite-global
      coordinates by cel.position before getPixel/putPixel.

    Live mode: the user watches the open window, which redraws once per call.
    Draw ONE object or pass per script (at most 40 code lines; longer ones are
    refused), then call again for the next piece, so something new appears
    each step. Never paint a whole scene in one script.

    WARNING: this executes unrestricted code (including io/os access)
    on the host running Aseprite. Only pass scripts you trust.

    Args:
        script: Lua source code to execute
        filename: Optional Aseprite file to open before running
    """
    if not script.strip():
        return "Script cannot be empty"
    if filename and not os.path.exists(filename):
        return f"File {filename} not found"
    lines = _code_lines(script)
    if live.connected() and lines > MAX_LIVE_LINES:
        return (f"Refused: {lines} lines of Lua in one call. The user is watching the "
                "Aseprite window, which only updates between calls. Split this into "
                f"several scripts of at most {MAX_LIVE_LINES} lines, one object or pass "
                "each (e.g. sky, then hills, then the tree), and run them one after another. "
                "Prefer dedicated tools (draw_rows, draw_rectangle_at, ...) where they fit.")

    success, output = AsepriteCommand.execute_lua_script(script, filename or None)
    if success:
        return output if output.strip() else "Script executed (no output printed)"
    return f"Script failed: {output}"
