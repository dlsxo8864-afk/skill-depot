import os
from typing import List, Dict, Any
from ..core.commands import AsepriteCommand, lua_escape
from ..core.lua import FIND_LAYER, NORMALIZE_CEL, PSET
from ..core.colors import parse_hex_color
from .. import mcp


def _parse_hex_color(value: str) -> tuple[int, int, int, int] | None:
    """Parse a hex colour to (r, g, b, a); accepts #RRGGBB and #RRGGBBAA."""
    return parse_hex_color(value)


@mcp.tool()
async def draw_pixels(filename: str, pixels: List[Dict[str, Any]]) -> str:
    """Draw pixels on the canvas with specified colors.

    Args:
        filename: Name of the Aseprite file to modify
        pixels: List of pixel data, each containing:
            {"x": int, "y": int, "color": str}
            where color is a hex code like "#FF0000"
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    script = """
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    app.transaction(function()
        local cel = app.activeCel
        if not cel then
            -- If no active cel, create one
            app.activeLayer = spr.layers[1]
            app.activeFrame = spr.frames[1]
            cel = app.activeCel
            if not cel then
                print("ERROR:No active cel and couldn't create one") return
            end
        end

        local img = cel.image
        local cox = cel.position.x
        local coy = cel.position.y
    """

    # Add pixel drawing commands. Coordinates are sprite-global; we
    # offset into cel-local space because cel.image:putPixel uses
    # cel-local coordinates.
    for pixel in pixels:
        x = pixel.get("x", 0)
        y = pixel.get("y", 0)
        rgb = _parse_hex_color(pixel.get("color", "#000000"))
        if rgb is None:
            return f"Invalid color value: {pixel.get('color')}"
        r, g, b, a = rgb

        script += f"""
        img:putPixel({x} - cox, {y} - coy, Color({r}, {g}, {b}, {a}))
        """

    script += """
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)

    if success:
        return f"Pixels drawn successfully in {filename}"
    else:
        return f"Failed to draw pixels: {output}"

@mcp.tool()
async def draw_line(filename: str, x1: int, y1: int, x2: int, y2: int, color: str = "#000000", thickness: int = 1) -> str:
    """Draw a line on the canvas.

    Args:
        filename: Name of the Aseprite file to modify
        x1: Starting x coordinate
        y1: Starting y coordinate
        x2: Ending x coordinate
        y2: Ending y coordinate
        color: Hex color code (default: "#000000")
        thickness: Line thickness in pixels (default: 1)
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local function put_thick(img, x, y, color, size)
        local r = math.max(0, math.floor(size / 2))
        for oy = -r, r do
            for ox = -r, r do
                img:putPixel(x + ox, y + oy, color)
            end
        end
    end

    local function draw_line(img, x0, y0, x1, y1, color, size)
        local dx = math.abs(x1 - x0)
        local sx = x0 < x1 and 1 or -1
        local dy = -math.abs(y1 - y0)
        local sy = y0 < y1 and 1 or -1
        local err = dx + dy
        while true do
            if size > 1 then
                put_thick(img, x0, y0, color, size)
            else
                img:putPixel(x0, y0, color)
            end
            if x0 == x1 and y0 == y1 then break end
            local e2 = 2 * err
            if e2 >= dy then err = err + dy; x0 = x0 + sx end
            if e2 <= dx then err = err + dx; y0 = y0 + sy end
        end
    end

    app.transaction(function()
        local cel = app.activeCel
        if not cel then
            app.activeLayer = spr.layers[1]
            app.activeFrame = spr.frames[1]
            cel = app.activeCel
            if not cel then
                print("ERROR:No active cel and couldn't create one") return
            end
        end
        local img = cel.image
        local cox = cel.position.x
        local coy = cel.position.y
        local color = Color({r}, {g}, {b}, {a})
        -- Translate sprite-global args into cel-local space so the
        -- inner Bresenham/putPixel helpers do not need to know about
        -- cel.position.
        draw_line(img, {x1} - cox, {y1} - coy, {x2} - cox, {y2} - coy, color, {thickness})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)

    if success:
        return f"Line drawn successfully in {filename}"
    else:
        return f"Failed to draw line: {output}"

@mcp.tool()
async def draw_rectangle(filename: str, x: int, y: int, width: int, height: int, color: str = "#000000", fill: bool = False) -> str:
    """Draw a rectangle on the canvas.

    Args:
        filename: Name of the Aseprite file to modify
        x: Top-left x coordinate
        y: Top-left y coordinate
        width: Width of the rectangle in pixels (must be > 0)
        height: Height of the rectangle in pixels (must be > 0)
        color: Hex color code (default: "#000000")
        fill: Whether to fill the rectangle (default: False)
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if width <= 0 or height <= 0:
        return "Width and height must be > 0"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb

    # app.useTool treats both points as inclusive corners, so the second
    # point sits at (x+width-1, y+height-1) for a width x height rect.
    x2 = x + width - 1
    y2 = y + height - 1

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    app.transaction(function()
        local cel = app.activeCel
        if not cel then
            app.activeLayer = spr.layers[1]
            app.activeFrame = spr.frames[1]
            cel = app.activeCel
            if not cel then
                print("ERROR:No active cel and couldn't create one") return
            end
        end

        local color = Color({r}, {g}, {b}, {a})
        local tool = {'"rectangle"' if not fill else '"filled_rectangle"'}
        app.useTool({{
            tool=tool,
            color=color,
            points={{Point({x}, {y}), Point({x2}, {y2})}}
        }})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)

    if success:
        return f"Rectangle drawn successfully in {filename}"
    else:
        return f"Failed to draw rectangle: {output}"

@mcp.tool()
async def fill_area(filename: str, x: int, y: int, color: str = "#000000") -> str:
    """Fill an area with color using the paint bucket tool.

    Args:
        filename: Name of the Aseprite file to modify
        x: X coordinate to fill from
        y: Y coordinate to fill from
        color: Hex color code (default: "#000000")
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    app.transaction(function()
        local cel = app.activeCel
        if not cel then
            app.activeLayer = spr.layers[1]
            app.activeFrame = spr.frames[1]
            cel = app.activeCel
            if not cel then
                print("ERROR:No active cel and couldn't create one") return
            end
        end

        local color = Color({r}, {g}, {b}, {a})
        app.useTool({{
            tool="paint_bucket",
            color=color,
            points={{Point({x}, {y})}}
        }})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)

    if success:
        return f"Area filled successfully in {filename}"
    else:
        return f"Failed to fill area: {output}"

@mcp.tool()
async def draw_circle(filename: str, center_x: int, center_y: int, radius: int, color: str = "#000000", fill: bool = False) -> str:
    """Draw a circle on the canvas.

    Args:
        filename: Name of the Aseprite file to modify
        center_x: X coordinate of circle center
        center_y: Y coordinate of circle center
        radius: Radius of the circle in pixels
        color: Hex color code (default: "#000000")
        fill: Whether to fill the circle (default: False)
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    app.transaction(function()
        local cel = app.activeCel
        if not cel then
            app.activeLayer = spr.layers[1]
            app.activeFrame = spr.frames[1]
            cel = app.activeCel
            if not cel then
                print("ERROR:No active cel and couldn't create one") return
            end
        end

        local color = Color({r}, {g}, {b}, {a})
        local tool = {'"ellipse"' if not fill else '"filled_ellipse"'}
        app.useTool({{
            tool=tool,
            color=color,
            points={{
                Point({center_x - radius}, {center_y - radius}),
                Point({center_x + radius}, {center_y + radius})
            }}
        }})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)

    if success:
        return f"Circle drawn successfully in {filename}"
    else:
        return f"Failed to draw circle: {output}"

@mcp.tool()
async def draw_pixels_at(
    filename: str,
    layer_name: str,
    frame_index: int,
    pixels: List[Dict[str, Any]],
    create_if_missing: bool = True
) -> str:
    """Draw pixels on a specific layer/frame.

    Args:
        filename: Name of the Aseprite file to modify
        layer_name: Layer name to target
        frame_index: Frame index starting at 1
        pixels: List of pixel data with x/y/color
        create_if_missing: Create cel if it does not exist
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"
    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    {FIND_LAYER}
    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = target:cel(spr.frames[idx])
        if not cel and {create_flag} then
            local img = Image(spr.width, spr.height, spr.colorMode)
            cel = spr:newCel(target, spr.frames[idx], img, Point(0, 0))
        end
        if not cel then return end
        local img = cel.image
        local cox = cel.position.x
        local coy = cel.position.y
    """
    for pixel in pixels:
        x = pixel.get("x", 0)
        y = pixel.get("y", 0)
        rgb = _parse_hex_color(pixel.get("color", "#000000"))
        if rgb is None:
            return f"Invalid color value: {pixel.get('color')}"
        r, g, b, a = rgb
        script += f"""
        img:putPixel({x} - cox, {y} - coy, Color({r}, {g}, {b}, {a}))
        """

    script += """
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Pixels drawn on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to draw pixels: {output}"

@mcp.tool()
async def draw_line_at(
    filename: str,
    layer_name: str,
    frame_index: int,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    color: str = "#000000",
    thickness: int = 1,
    create_if_missing: bool = True
) -> str:
    """Draw a line on a specific layer/frame.

    Args:
        filename (str): The path to the Aseprite file.
        layer_name (str): The name of the layer to draw on.
        frame_index (int): The index of the frame to draw on.
        x1 (int): The x coordinate of the first point of the line.
        y1 (int): The y coordinate of the first point of the line.
        x2 (int): The x coordinate of the second point of the line.
        y2 (int): The y coordinate of the second point of the line.
        color (str, optional): The color to draw the line with. Defaults to "#000000".
        thickness (int, optional): The thickness of the line. Defaults to 1.
        create_if_missing (bool, optional): Whether to create the layer if it doesn't exist. Defaults to True.
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local function put_thick(img, x, y, color, size)
        local r = math.max(0, math.floor(size / 2))
        for oy = -r, r do
            for ox = -r, r do
                img:putPixel(x + ox, y + oy, color)
            end
        end
    end

    local function draw_line(img, x0, y0, x1, y1, color, size)
        local dx = math.abs(x1 - x0)
        local sx = x0 < x1 and 1 or -1
        local dy = -math.abs(y1 - y0)
        local sy = y0 < y1 and 1 or -1
        local err = dx + dy
        while true do
            if size > 1 then
                put_thick(img, x0, y0, color, size)
            else
                img:putPixel(x0, y0, color)
            end
            if x0 == x1 and y0 == y1 then break end
            local e2 = 2 * err
            if e2 >= dy then err = err + dy; x0 = x0 + sx end
            if e2 <= dx then err = err + dx; y0 = y0 + sy end
        end
    end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    {FIND_LAYER}
    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = target:cel(spr.frames[idx])
        if not cel and {create_flag} then
            local img = Image(spr.width, spr.height, spr.colorMode)
            cel = spr:newCel(target, spr.frames[idx], img, Point(0, 0))
        end
        if not cel then return end
        local img = cel.image
        local cox = cel.position.x
        local coy = cel.position.y
        local color = Color({r}, {g}, {b}, {a})
        draw_line(img, {x1} - cox, {y1} - coy, {x2} - cox, {y2} - coy, color, {thickness})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Line drawn on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to draw line: {output}"

@mcp.tool()
async def draw_rectangle_at(
    filename: str,
    layer_name: str,
    frame_index: int,
    x: int,
    y: int,
    width: int,
    height: int,
    color: str = "#000000",
    fill: bool = False,
    create_if_missing: bool = True
) -> str:
    """Draw a rectangle on a specific layer/frame.

    Args:
        filename (str): The path to the Aseprite file.
        layer_name (str): The name of the layer to draw on.
        frame_index (int): The index of the frame to draw on.
        x (int): The x coordinate of the top-left corner of the rectangle.
        y (int): The y coordinate of the top-left corner of the rectangle.
        width (int): The width of the rectangle.
        height (int): The height of the rectangle.
        color (str, optional): The color to draw the rectangle with. Defaults to "#000000".
        fill (bool, optional): Whether to fill the rectangle. Defaults to False.
        create_if_missing (bool, optional): Whether to create the layer if it doesn't exist. Defaults to True.
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if width <= 0 or height <= 0:
        return "Width and height must be > 0"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"
    x2 = x + width - 1
    y2 = y + height - 1

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    {FIND_LAYER}
    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = target:cel(spr.frames[idx])
        if not cel and {create_flag} then
            local img = Image(spr.width, spr.height, spr.colorMode)
            cel = spr:newCel(target, spr.frames[idx], img, Point(0, 0))
        end
        if not cel then return end
        local color = Color({r}, {g}, {b}, {a})
        local tool = {'"rectangle"' if not fill else '"filled_rectangle"'}
        app.useTool({{
            tool=tool,
            color=color,
            points={{Point({x}, {y}), Point({x2}, {y2})}}
        }})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Rectangle drawn on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to draw rectangle: {output}"

@mcp.tool()
async def draw_circle_at(
    filename: str,
    layer_name: str,
    frame_index: int,
    center_x: int,
    center_y: int,
    radius: int,
    color: str = "#000000",
    fill: bool = False,
    create_if_missing: bool = True
) -> str:
    """Draw a circle on a specific layer/frame.

    Args:
        filename (str): The path to the Aseprite file.
        layer_name (str): The name of the layer to draw on.
        frame_index (int): The index of the frame to draw on.
        center_x (int): The x coordinate of the center of the circle.
        center_y (int): The y coordinate of the center of the circle.
        radius (int): The radius of the circle.
        color (str, optional): The color to draw the circle with. Defaults to "#000000".
        fill (bool, optional): Whether to fill the circle. Defaults to False.
        create_if_missing (bool, optional): Whether to create the layer if it doesn't exist. Defaults to True.
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    {FIND_LAYER}
    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = target:cel(spr.frames[idx])
        if not cel and {create_flag} then
            local img = Image(spr.width, spr.height, spr.colorMode)
            cel = spr:newCel(target, spr.frames[idx], img, Point(0, 0))
        end
        if not cel then return end
        local color = Color({r}, {g}, {b}, {a})
        local tool = {'"ellipse"' if not fill else '"filled_ellipse"'}
        app.useTool({{
            tool=tool,
            color=color,
            points={{
                Point({center_x - radius}, {center_y - radius}),
                Point({center_x + radius}, {center_y + radius})
            }}
        }})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Circle drawn on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to draw circle: {output}"

@mcp.tool()
async def fill_area_at(
    filename: str,
    layer_name: str,
    frame_index: int,
    x: int,
    y: int,
    color: str = "#000000",
    create_if_missing: bool = True
) -> str:
    """Fill an area on a specific layer/frame.

    Args:
        filename (str): The path to the Aseprite file.
        layer_name (str): The name of the layer to draw on.
        frame_index (int): The index of the frame to draw on.
        x (int): The x coordinate of the point to start filling from.
        y (int): The y coordinate of the point to start filling from.
        color (str, optional): The color to fill the area with. Defaults to "#000000".
        create_if_missing (bool, optional): Whether to create the layer if it doesn't exist. Defaults to True.
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    {FIND_LAYER}
    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = target:cel(spr.frames[idx])
        if not cel and {create_flag} then
            local img = Image(spr.width, spr.height, spr.colorMode)
            cel = spr:newCel(target, spr.frames[idx], img, Point(0, 0))
        end
        if not cel then return end
        local color = Color({r}, {g}, {b}, {a})
        app.useTool({{
            tool="paint_bucket",
            color=color,
            points={{Point({x}, {y})}}
        }})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Area filled on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to fill area: {output}"

@mcp.tool()
async def draw_polygon(
    filename: str,
    layer_name: str,
    frame_index: int,
    points: List[Dict[str, int]],
    color: str = "#000000",
    fill: bool = False,
    create_if_missing: bool = True
) -> str:
    """Draw a polygon on a specific layer/frame.

    Args:
        filename (str): The path to the Aseprite file.
        layer_name (str): The name of the layer to draw on.
        frame_index (int): The index of the frame to draw on.
        points (List[Dict[str, int]]): The list of points to draw the polygon.
        color (str, optional): The color to draw the polygon with. Defaults to "#000000".
        fill (bool, optional): Whether to fill the polygon. Defaults to False.
        create_if_missing (bool, optional): Whether to create the layer if it doesn't exist. Defaults to True.
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if len(points) < 3:
        return "Polygon requires at least 3 points"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"
    fill_flag = "true" if fill else "false"
    points_lua = ", ".join([f"{{x={p['x']}, y={p['y']}}}" for p in points])

    script = f"""
    {NORMALIZE_CEL}
    {PSET}
    {FIND_LAYER}
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    -- Points are sprite-global; normalize_cel anchors the cel at (0,0)
    -- canvas-sized, so no cel-offset math is needed and pset() bounds-guards.
    local function draw_line(img, x0, y0, x1, y1, color)
        local dx = math.abs(x1 - x0)
        local sx = x0 < x1 and 1 or -1
        local dy = -math.abs(y1 - y0)
        local sy = y0 < y1 and 1 or -1
        local err = dx + dy
        while true do
            pset(img, x0, y0, color)
            if x0 == x1 and y0 == y1 then break end
            local e2 = 2 * err
            if e2 >= dy then err = err + dy; x0 = x0 + sx end
            if e2 <= dx then err = err + dx; y0 = y0 + sy end
        end
    end

    local function fill_polygon(img, pts, color)
        local minY = pts[1].y
        local maxY = pts[1].y
        for i = 2, #pts do
            if pts[i].y < minY then minY = pts[i].y end
            if pts[i].y > maxY then maxY = pts[i].y end
        end
        for y = minY, maxY do
            local nodes = {{}}
            local j = #pts
            for i = 1, #pts do
                local xi, yi = pts[i].x, pts[i].y
                local xj, yj = pts[j].x, pts[j].y
                if (yi < y and yj >= y) or (yj < y and yi >= y) then
                    local x = xi + (y - yi) * (xj - xi) / (yj - yi)
                    table.insert(nodes, x)
                end
                j = i
            end
            table.sort(nodes)
            for k = 1, #nodes, 2 do
                if nodes[k + 1] ~= nil then
                    local x_start = math.floor(nodes[k] + 0.5)
                    local x_end = math.floor(nodes[k + 1] + 0.5)
                    for x = x_start, x_end do
                        pset(img, x, y, color)
                    end
                end
            end
        end
    end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = normalize_cel(spr, target, spr.frames[idx], {create_flag})
        if not cel then return end
        local img = cel.image
        local color = Color({r}, {g}, {b}, {a})
        local pts = {{ {points_lua} }}
        if {fill_flag} then
            fill_polygon(img, pts, color)
        end
        for i = 1, #pts do
            local n = i + 1
            if n > #pts then n = 1 end
            draw_line(img, pts[i].x, pts[i].y, pts[n].x, pts[n].y, color)
        end
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Polygon drawn on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to draw polygon: {output}"

@mcp.tool()
async def draw_path(
    filename: str,
    layer_name: str,
    frame_index: int,
    points: List[Dict[str, int]],
    color: str = "#000000",
    thickness: int = 1,
    create_if_missing: bool = True
) -> str:
    """Draw a path using a polyline on a specific layer/frame.

    Args:
        filename (str): The path to the Aseprite file.
        layer_name (str): The name of the layer to draw on.
        frame_index (int): The index of the frame to draw on.
        points (List[Dict[str, int]]): The points to draw the path with.
        color (str, optional): The color to draw the path with. Defaults to "#000000".
        thickness (int, optional): The thickness of the path. Defaults to 1.
        create_if_missing (bool, optional): Whether to create the layer if it doesn't exist. Defaults to True.
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if len(points) < 2:
        return "Path requires at least 2 points"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"
    points_lua = ", ".join([f"{{x={p['x']}, y={p['y']}}}" for p in points])

    script = f"""
    {NORMALIZE_CEL}
    {PSET}
    {FIND_LAYER}
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local function put_thick(img, x, y, color, size)
        local rad = math.max(0, math.floor(size / 2))
        for oy = -rad, rad do
            for ox = -rad, rad do
                pset(img, x + ox, y + oy, color)
            end
        end
    end

    local function draw_line(img, x0, y0, x1, y1, color, size)
        local dx = math.abs(x1 - x0)
        local sx = x0 < x1 and 1 or -1
        local dy = -math.abs(y1 - y0)
        local sy = y0 < y1 and 1 or -1
        local err = dx + dy
        while true do
            if size > 1 then
                put_thick(img, x0, y0, color, size)
            else
                pset(img, x0, y0, color)
            end
            if x0 == x1 and y0 == y1 then break end
            local e2 = 2 * err
            if e2 >= dy then err = err + dy; x0 = x0 + sx end
            if e2 <= dx then err = err + dx; y0 = y0 + sy end
        end
    end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = normalize_cel(spr, target, spr.frames[idx], {create_flag})
        if not cel then return end
        local img = cel.image
        local color = Color({r}, {g}, {b}, {a})
        local pts = {{ {points_lua} }}
        for i = 1, #pts - 1 do
            draw_line(img, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, color, {thickness})
        end
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Path drawn on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to draw path: {output}"

@mcp.tool()
async def apply_gradient_rect(
    filename: str,
    layer_name: str,
    frame_index: int,
    x: int,
    y: int,
    width: int,
    height: int,
    color_start: str,
    color_end: str,
    horizontal: bool = True,
    create_if_missing: bool = True
) -> str:
    """Apply a linear gradient fill to a rectangle.

    Args:
        filename (str): The path to the Aseprite file.
        layer_name (str): The name of the layer to draw on.
        frame_index (int): The index of the frame to draw on.
        x (int): The x coordinate of the rectangle to draw on.
        y (int): The y coordinate of the rectangle to draw on.
        width (int): The width of the rectangle to draw on.
        height (int): The height of the rectangle to draw on.
        color_start (str): The start color of the gradient.
        color_end (str): The end color of the gradient.
        horizontal (bool, optional): Whether to draw the gradient horizontally. Defaults to True.
        create_if_missing (bool, optional): Whether to create the layer if it doesn't exist. Defaults to True.
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if width <= 0 or height <= 0:
        return "Width and height must be > 0"

    start_rgb = _parse_hex_color(color_start)
    if start_rgb is None:
        return f"Invalid color_start value: {color_start}"
    end_rgb = _parse_hex_color(color_end)
    if end_rgb is None:
        return f"Invalid color_end value: {color_end}"

    sr, sg, sb, sa = start_rgb
    er, eg, eb, ea = end_rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"
    horiz_flag = "true" if horizontal else "false"

    script = f"""
    {NORMALIZE_CEL}
    {PSET}
    {FIND_LAYER}
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = normalize_cel(spr, target, spr.frames[idx], {create_flag})
        if not cel then return end
        local img = cel.image
        local w = {width}
        local h = {height}
        for iy = 0, h - 1 do
            for ix = 0, w - 1 do
                local t = 0
                if {horiz_flag} then
                    t = (w > 1) and (ix / (w - 1)) or 0
                else
                    t = (h > 1) and (iy / (h - 1)) or 0
                end
                local r = math.floor({sr} + ({er} - {sr}) * t + 0.5)
                local g = math.floor({sg} + ({eg} - {sg}) * t + 0.5)
                local b = math.floor({sb} + ({eb} - {sb}) * t + 0.5)
                local a = math.floor({sa} + ({ea} - {sa}) * t + 0.5)
                pset(img, {x} + ix, {y} + iy, Color(r, g, b, a))
            end
        end
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Gradient applied on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to apply gradient: {output}"


@mcp.tool()
async def draw_ellipse_at(
    filename: str,
    layer_name: str,
    frame_index: int,
    center_x: int,
    center_y: int,
    radius_x: int,
    radius_y: int,
    color: str = "#000000",
    fill: bool = False,
    create_if_missing: bool = True
) -> str:
    """Draw an ellipse on a specific layer/frame.

    Args:
        filename: Aseprite file to modify
        layer_name: Layer to draw on
        frame_index: Frame index starting at 1
        center_x: Ellipse center x
        center_y: Ellipse center y
        radius_x: Horizontal radius in pixels
        radius_y: Vertical radius in pixels
        color: Hex color code (default "#000000")
        fill: Fill the ellipse instead of outlining it
        create_if_missing: Create the cel if it does not exist
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if radius_x <= 0 or radius_y <= 0:
        return "radius_x and radius_y must be > 0"

    rgb = _parse_hex_color(color)
    if rgb is None:
        return f"Invalid color value: {color}"
    r, g, b, a = rgb
    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"

    script = f"""
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    {FIND_LAYER}
    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = target:cel(spr.frames[idx])
        if not cel and {create_flag} then
            local img = Image(spr.width, spr.height, spr.colorMode)
            cel = spr:newCel(target, spr.frames[idx], img, Point(0, 0))
        end
        if not cel then return end
        local color = Color({r}, {g}, {b}, {a})
        local tool = {'"filled_ellipse"' if fill else '"ellipse"'}
        app.useTool({{
            tool=tool,
            color=color,
            points={{
                Point({center_x - radius_x}, {center_y - radius_y}),
                Point({center_x + radius_x}, {center_y + radius_y})
            }}
        }})
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """

    success, output = AsepriteCommand.execute_lua_script_checked(script, filename)
    if success:
        return f"Ellipse drawn on '{layer_name}' frame {frame_index} in {filename}"
    return f"Failed to draw ellipse: {output}"


def _runs(pixels: dict[tuple[int, int], tuple]) -> list[tuple[int, int, int, tuple]]:
    """Group pixels into horizontal runs of one colour: (y, x0, x1, rgba)."""
    runs = []
    for (x, y) in sorted(pixels, key=lambda p: (p[1], p[0])):
        c = pixels[(x, y)]
        if runs and runs[-1][0] == y and runs[-1][2] == x - 1 and runs[-1][3] == c:
            runs[-1] = (y, runs[-1][1], x, c)
        else:
            runs.append((y, x, x, c))
    return runs


def _outline_of(pixels: dict[tuple[int, int], tuple], rgba: tuple) -> dict[tuple[int, int], tuple]:
    """1 px outline (sides only) around the opaque pixels, outside the set."""
    edge = {}
    for (px, py), c in pixels.items():
        if c[3] == 0:
            continue
        for n in ((px - 1, py), (px + 1, py), (px, py - 1), (px, py + 1)):
            if n not in pixels:
                edge[n] = rgba
    return edge


def _paint_pixels(filename: str, layer_name: str, frame_index: int,
                  pixels: dict[tuple[int, int], tuple], create_if_missing: bool):
    """Put sprite-global pixels {(x, y): rgba} on a layer/frame in one run.

    Pixels go out as horizontal runs of one colour; off-canvas ones are
    dropped. Returns (success, output) from the checked Lua execution.
    """
    palette = list(dict.fromkeys(pixels.values()))
    index = {c: i + 1 for i, c in enumerate(palette)}
    palette_lua = ", ".join(f"Color({r}, {g}, {b}, {a})" for r, g, b, a in palette)
    runs_lua = ",\n".join(f"{{{ry}, {x0}, {x1}, {index[c]}}}" for ry, x0, x1, c in _runs(pixels))

    safe_layer_name = lua_escape(layer_name)
    create_flag = "true" if create_if_missing else "false"
    script = f"""
    {NORMALIZE_CEL}
    {PSET}
    {FIND_LAYER}
    local spr = app.activeSprite
    if not spr then print("ERROR:No active sprite") return end

    local idx = {frame_index}
    if idx < 1 or idx > #spr.frames then print("ERROR:Frame index out of range") return end

    local target = find_layer(spr, "{safe_layer_name}")
    if not target then print("ERROR:Layer not found") return end

    local palette = {{ {palette_lua} }}
    -- {{y, x_first, x_last, palette index}}, sprite-global
    local runs = {{
{runs_lua}
    }}

    app.transaction(function()
        app.activeLayer = target
        app.activeFrame = spr.frames[idx]
        local cel = normalize_cel(spr, target, spr.frames[idx], {create_flag})
        if not cel then print("ERROR:No cel at that layer/frame") return end
        local img = cel.image
        for _, run in ipairs(runs) do
            local color = palette[run[4]]
            for px = run[2], run[3] do
                pset(img, px, run[1], color)
            end
        end
    end)

    spr:saveAs(spr.filename)
    print("OK")
    """
    return AsepriteCommand.execute_lua_script_checked(script, filename)


@mcp.tool()
async def draw_rows(
    filename: str,
    layer_name: str,
    frame_index: int,
    x: int,
    y: int,
    rows: List[str],
    legend: Dict[str, Any],
    outline: str | None = None,
    create_if_missing: bool = True,
) -> str:
    """Draw pixels from rows of characters, like ASCII art: one character per pixel.

    The compact way to place hand-chosen pixels (faces, hands, animals,
    handles, any detail under ~12 px), far smaller than a pixel list:

        rows=["..KK..",
              ".KSSK.",
              "KSSSSK"],
        legend={"K": "#1A1C2C", "S": "#F4B41B"}

    Row 1 is drawn at y, its first character at x (sprite pixels). "." or a
    character missing from the legend leaves that pixel untouched; map a
    character to "#00000000" to erase. Read existing pixels back in the same
    format with read_rows, edit the strings, and draw them again.

    Args:
        filename: Aseprite file to modify
        layer_name: Layer to draw on
        frame_index: Frame index starting at 1
        x: Left edge of the rows (sprite pixels)
        y: Top edge of the rows (sprite pixels)
        rows: Equal-width strings, top to bottom
        legend: Single character -> hex colour (#RGB, #RRGGBB or #RRGGBBAA)
        outline: Optional hex colour for a 1 px outline around the outside of
            the drawn pixels (sides only, not diagonals), drawn over whatever
            is there, e.g. to separate an object from the scene behind it
        create_if_missing: Create the cel if it does not exist
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if not rows:
        return "Invalid rows: give at least one row"
    width = len(rows[0])
    for i, row in enumerate(rows):
        if len(row) != width:
            return (f"Invalid rows: row {i + 1} is {len(row)} characters wide but row 1 is {width}; "
                    f"all rows must be the same width (row {i + 1}: {row!r})")

    colors = {}
    for ch, value in legend.items():
        if len(ch) != 1:
            return f"Invalid legend key {ch!r}: keys must be single characters"
        if value in (None, ""):
            continue
        rgba = _parse_hex_color(str(value))
        if rgba is None:
            return f"Invalid color value for {ch!r}: {value}"
        colors[ch] = rgba
    outline_rgba = None
    if outline:
        outline_rgba = _parse_hex_color(outline)
        if outline_rgba is None:
            return f"Invalid color value: {outline}"

    pixels, unknown = {}, {}
    for r, row in enumerate(rows):
        for c, ch in enumerate(row):
            if ch in colors:
                pixels[(x + c, y + r)] = colors[ch]
            elif ch not in ". ":
                unknown[ch] = unknown.get(ch, 0) + 1
    if not pixels:
        return "Invalid rows: nothing to draw; every character is '.' or missing from the legend"

    edge = _outline_of(pixels, outline_rgba) if outline_rgba else {}

    success, output = _paint_pixels(filename, layer_name, frame_index, {**pixels, **edge},
                                    create_if_missing)
    if not success:
        return f"Failed to draw rows: {output}"
    text = (f"Drew {len(pixels)} pixels ({width}x{len(rows)} rows at {x},{y})"
            f"{f' and a {len(edge)} px outline' if edge else ''} on '{layer_name}' "
            f"frame {frame_index} in {filename}")
    if unknown:
        listed = ", ".join(f"{ch!r} ({n} px)" for ch, n in unknown.items())
        text += f". Skipped characters missing from the legend: {listed}"
    return text


def _iso_box_faces(x: int, y: int, z: int, w: int, d: int, h: int):
    """Pixels of a 2:1 isometric box: (top, left, right) sets of (x, y).

    (x, y) is the back corner of the floor footprint, the box is raised z px,
    w runs right-down (2 px across, 1 px down per unit), d runs left-down.
    Every edge steps exactly 2-1, the clean isometric line.
    """
    tx, ty = x, y - z - h  # top vertex of the top face (a 2 px cap)
    top = set()
    for k in range(w + d + 1):
        left = tx - 2 * k if k <= d else tx - 2 * d + 2 * (k - d)
        right = tx + 1 + 2 * k if k <= w else tx + 1 + 2 * w - 2 * (k - w)
        top.update((px, ty + k) for px in range(left, right + 1))
    split = tx + 2 * w - 2 * d  # left column of the bottom vertex
    left_face, right_face = set(), set()
    for c in range(tx - 2 * d, split + 1):
        below = ty + d + (c - (tx - 2 * d)) // 2
        left_face.update((c, below + i) for i in range(1, h + 1))
    for c in range(split + 1, tx + 2 * w + 2):
        below = ty + w + d - (c - split) // 2
        right_face.update((c, below + i) for i in range(1, h + 1))
    return top, left_face, right_face


@mcp.tool()
async def draw_iso_box(
    filename: str,
    layer_name: str,
    frame_index: int,
    x: int,
    y: int,
    z: int,
    w: int,
    d: int,
    h: int,
    top: str,
    left: str,
    right: str,
    outline: str = "",
    create_if_missing: bool = True,
) -> str:
    """Draw a solid box in 2:1 isometric projection, with clean 2-1 edges.

    For furniture, crates, walls and floors in isometric scenes. The three
    visible faces get their own colours (light from the top: top lightest,
    one side mid, the other darkest). Small or organic parts on top of a box
    (handles, cats, hands) are drawn with draw_rows instead.

    Coordinates, in sprite pixels:
        (x, y)  back corner of the box's footprint on the floor
        w       length along the right-down axis: each unit is 2 px right, 1 px down
        d       length along the left-down axis: each unit is 2 px left, 1 px down
        h       height in px; z raises the whole box (e.g. a book on a desk)
    Later boxes draw over earlier ones, so draw back to front.

    Args:
        filename: Aseprite file to modify
        layer_name: Layer to draw on
        frame_index: Frame index starting at 1
        x: Back corner x
        y: Back corner y (floor level)
        z: Elevation above the floor in px (0 = on the floor)
        w: Units along the right-down axis (>= 1)
        d: Units along the left-down axis (>= 1)
        h: Height in px (0 = a flat tile)
        top: Hex colour of the top face
        left: Hex colour of the front-left face
        right: Hex colour of the front-right face
        outline: Optional hex colour for a 1 px outline around the box,
            drawn over whatever is there
        create_if_missing: Create the cel if it does not exist
    """
    if not os.path.exists(filename):
        return f"File {filename} not found"
    if w < 1 or d < 1 or h < 0:
        return "w and d must be >= 1 and h >= 0"
    colors = {}
    for name, value in (("top", top), ("left", left), ("right", right), ("outline", outline)):
        if name == "outline" and not value:
            continue
        rgba = _parse_hex_color(value)
        if rgba is None:
            return f"Invalid color value for {name}: {value}"
        colors[name] = rgba

    top_px, left_px, right_px = _iso_box_faces(x, y, z, w, d, h)
    pixels = {p: colors["top"] for p in top_px}
    pixels.update({p: colors["left"] for p in left_px})
    pixels.update({p: colors["right"] for p in right_px})
    edge = _outline_of(pixels, colors["outline"]) if "outline" in colors else {}

    success, output = _paint_pixels(filename, layer_name, frame_index, {**pixels, **edge},
                                    create_if_missing)
    if not success:
        return f"Failed to draw isometric box: {output}"
    xs = [p[0] for p in pixels]
    ys = [p[1] for p in pixels]
    return (f"Isometric box drawn on '{layer_name}' frame {frame_index} in {filename}: "
            f"covers x {min(xs)}-{max(xs)}, y {min(ys)}-{max(ys)}")

