# Native authoring

This is a scene toolkit used by the calling agent, not an image reconstruction model. Native CPU export requires Node20+ and the installed canvas dependency, with no browser, server or CDP. Browser capture remains available. See [runtime support](runtime.md) for capability boundaries.

## Default scene adapter

Scene folder: `scene.js`, optional configuration modules, `delivery.json`. The helper copies it into `scenes/current/` and supplies `engine/`. Import `../../engine/math.js`, `mesh.js`, `pixels.js` as needed; these paths are resolved in the generated output.

For direct 2D drawing start from `assets/pixel-starter/scene/`; for projected geometry use `assets/native-starter/scene/`. Both contain a short design-record template. Their default grids are working examples, not mandatory budgets. Use `PixelPen` for hard native coverage rather than Canvas path fill/stroke. Fractional geometry/pose coordinates are fine; the final cell coverage is deliberately sampled. Turning off `imageSmoothingEnabled` only controls image scaling and does not remove path antialiasing.

```js
export default {
  config,                     // id, title, grid, loop, fps, camera, palette, materials, light
  state(time, options),       // pure deterministic state, including .time
  geometry(state),            // Float32Array: x,y,z,nx,ny,nz,materialIndex for each vertex
  details(ctx,state,zoom,options) // optional native pixel pass; preserve alpha
};
```

Give `config.id` a lowercase ASCII slug starting with a letter, maximum48 characters. Caption/title/labels can use the user's language. For the default renderer choose a positive integer grid/fps and a loop with an integer frame count. Camera uses orthographic azimuth/elevation/span/target. Materials reference ordered palette ramps: at most12 materials and64 ramp entries. `mesh.js` supplies primitives; custom vertices work as well. `finish()` transforms must rotate around origin because normals use the same callback; apply translations while constructing vertices.

Optional material0 `config.field` gives an elliptical meadow: `radii`, optional `angle` in degrees (default0) and `shadow:{center,radii,strength}`. It is a simplified contact field, not shadow mapping. Other footprints can use authored meshes/coverage. PixelPen accents must follow their objects and respect visible surfaces; an unbounded overlay can violate occlusion.

## Scene-owned renderer

Native sprites, geometry and their combinations can also expose `createRenderer(canvas, execution)` instead of `geometry`. This returns an independent object with `canvas`, 2D `ctx`, `draw(time, options)`, `capture(integerScale)`, and idempotent `destroy()`. Draw clears stale pixels, preserves alpha and accepts `opaque`; capture returns base64 PNG. Each mount owns resources and state. The juggler example demonstrates a native character with geometric scenery/shadows; the ox scene uses the default geometry renderer. Both use exactly the same review/export/component path. `execution.backend` is `cpu` for Node export; use `SoftwareRenderer` / `TriangleRaster` from `engine/software.js` for custom geometry, or ordinary Canvas2D native drawing. Node provides `document.createElement("canvas")` and `ImageData`, not a browser DOM or WebGL. Do not import Node-only dependencies from scene modules: the same source must still run in a browser. A custom WebGL renderer without a CPU adapter must report unsupported; do not substitute another scene.

Do not borrow one rig for every species or preload the shipped example as a replacement for the requested story.

Every adapter, including a custom `createRenderer`, must supply `config.id/grid/loop/fps/palette`. Palette is a nonempty list of actual color strings or RGB byte triples, required by the review UI even if the renderer stores colors elsewhere. Use RGB byte triples for standard geometry; custom Canvas renderers may use supported CSS colors (including short hex/named colors), with explicit hex useful for comparing actual pixels. Invalid/missing lists fail before success is reported; authors remain responsible for the renderer's color format. `assets/pixel-starter/scene/scene.js` is a complete CPU/browser portable example; include clear/destroy and integer `capture` behavior when adapting it.

## Delivery metadata

```json
{
  "title":"My scene",
  "caption":"One line about the action.",
  "language":"en",
  "focus":[{"id":"hands","label":"Look closer","rect":[30,80,80,80]}],
  "variants":[{"id":"final","label":"Current design","options":{}}]
}
```

Crops are integer native cells inside the frame. `whole` is reserved. Alternatives must be real; they share time and framing. `language:"en"` uses English controls; omitted language uses Chinese. Export defaults to the first alternative. `--variant id` selects and moves a named alternative to first position so all selected exports agree.

## Run from an installed Skill

Replace `SKILL_ROOT` with its actual absolute path:

```sh
node SKILL_ROOT/scripts/setup.mjs
node SKILL_ROOT/scripts/doctor.mjs --backend cpu
node SKILL_ROOT/scripts/deliver.mjs /absolute/scene --out /absolute/fresh-review --formats preview
node SKILL_ROOT/scripts/serve.mjs /absolute/fresh-review
# Once the user chooses:
node SKILL_ROOT/scripts/deliver.mjs /absolute/scene --out /absolute/fresh-delivery --formats video,gif,component --variant final
```

Fresh output directories prevent stale success. Current bundling supports static relative JavaScript imports, not cycles, dynamic imports or external textures. Preview captures a poster without encoding the whole loop. Video/GIF need ffmpeg (`FFMPEG_PATH` override); GIF duration must be a multiple of50ms. MP4 explicitly composites white before encoding. Generated files/hashes and selected variant appear in `manifest.json`; actual media must be checked before handoff.
