# Blender Product Photoreal Skill

블렌더로 만든 제품 마스터 파일(.blend)을 **실물 사진과 맞는 포토리얼 카탈로그 렌더**로 만드는 에이전트 스킬입니다.
화장품 용기 58종(FRAIJOUR 45종, ROERANCE 13종)을 실사화하면서 겪은 시행착오와 해결법을 하나의 작업 절차로 정리했습니다.

- **룩데브:** 재질 계열별 광학 레시피(불투명 PP, 얇은 필름 튜브, 반투명 병, 투명 PET+액체, 크롬, 파우치)
- **색 보정:** 실물 사진과 렌더를 선형 공간에서 비교하는 폐루프 보정
- **형상 교정:** 사진 카메라 기준 mm 측정 → 정점 수·UV를 유지하는 리맵
- **원인 확인:** 단일 변수 시험(같은 카메라·조명·원고에서 한 가지만 바꿈)
- **검증과 기록:** 저장 → 재열기 verify → 전후 비교 시트 → 모델러용 교정 기록
- **도구:** 반복해서 직접 만들던 측정 도구 5종(`scripts/`)

## 작업 사례

모든 비교는 같은 카메라·같은 조명에서 렌더했습니다. 왼쪽이 실물/카탈로그 사진입니다.

### 1. 크림 용기 돔 형상: 계란형 → 윗면이 평평한 스퀘어클
![jar dome](examples/01_jar_dome_geometry.jpg)
- **증상:** 같은 고도 카메라로 실루엣을 대조하니 돔 상단이 사진보다 2.5~12% 좁음.
- **조치:** 단면을 초타원(n≈2.27)으로 리맵. 정점 수·UV는 그대로, RMS 오차 1.6 → 0.24 mm.
- **핵심:** bbox 비율이 아니라 사진 카메라 기준으로 비교하기.

### 2. 펌프 헤드: 원판 두 개 → 하나로 성형된 헤드
![pump head](examples/02_pump_head.jpg)
- **증상:** 마스터 헤드가 '배럴 + 얇은 누름판' 구조.
- **조치:** 기준 이미지에서 경사 12°, 오리부리 토출구, D컷, 슬릿을 재서 헤드를 새로 만듦. 옛 부품은 지우지 않고 숨긴 채 보존.

### 3. 반투명 토너 병: 유리처럼 맑음/불투명 → 플라스틱 피부 + 어깨 형상
![toner bottle](examples/03_translucent_toner_bottle.jpg)
- **재질:** SSS 중심 + 거친 투과 + 코트, 라이트 테이블 역광 패널.
- **형상:** 어깨가 6.5~9 mm 낮았던 것을 사진 카메라 실루엣(아래 그래프, 녹색 사진 / 빨강 모델)으로 맞춤.

### 4. 젤 튜브: 충전 높이와 프로스트 캡
![gel fill line](examples/04_gel_fill_line_frosted_cap.jpg)
- **충전선:** 사진 높이 20.3% 지점 = 크림프 끝에서 43.5 mm. 내용물 위쪽만 리맵(벽 간격·UV 유지).
- **캡:** 유리 같은 투명 캡을 프로스트로 교체.

### 5. 실링 아이마크가 중간에서 끊김: 광학 경계 진단
![seal eye mark](examples/05_seal_eye_mark.jpg)
![zone overlay](examples/05b_seal_zone_overlay.jpg)
- **원인:** 원고 아이마크(10.1~20.1 mm) 중간인 15 mm에 셰이더 투명도의 계단 경계가 있었음.
  실제 용착은 약 12 mm에서 끝나고, 충전물 위끝은 25.8 mm.
- **방법:** 영역을 렌더 위에 겹쳐 그려 원인을 한눈에 확인.
- **시험(4가지, 전체 해상도):** '20 mm까지 투명 + 20~26 mm 부드러운 전환'만 마크가 이어지고 몸통 픽셀 변화가 0이었음.

### 6. 크림 색: 사진보다 하얀 몸통
![cream colour](examples/06_cream_colour.jpg)
- **확인:** 같은 촬영 세션의 흰 캡(B/R 0.99)으로 사진 화이트밸런스가 중립임을 확인 → 사진의 크림색은 실제 색.
- **조치:** 색조는 젤 색으로, 밝기는 역광 세기(1.2 → 0.6 W)로 따로 맞춤. 결과: 색비 B/R 0.794 vs 사진 0.787.

### 7. 시트마스크 파우치: 실링 엠보와 중앙 필름 굴곡
![pouch seal macro](examples/07_pouch_seal_emboss_macro.jpg)
![pouch full](examples/07b_pouch_full_before_after.jpg)
- **사진 측정(FFT):** 실링 엠보 = 대각 격자 피치 약 0.95 mm, 35°, 띠 폭 약 7.5 mm.
- **조치:** 실링 띠 안에만 얕은 엠보(0.022 mm)를 넣음. 전체 컷에서는 은은하고 사광 매크로에서 보이는 수준.
- **중앙:** 마스터의 규칙적인 물결(줄무늬)을 지우고 불규칙한 부드러운 굴곡으로 교체.

### 8. 투명 PET 미스트: 뒤 라벨 안쪽 그라데이션이 병을 통해 보이게
![mist optics](examples/08_clear_mist_label_optics.jpg)
- **문제:** 엄격한 물리 경로에서는 회색(커스틱 미수렴)이 되고, 공기층이 색을 지움.
- **근사:**
  - 젖은 안쪽 벽, 인덱스 매칭 액체, 병에 결합된 라벨
  - 투명 부품은 그림자·확산 광선에서 제외
  - 병과 액체는 착색하지 않음
- **승인:** 사용자 승인안(바닥 그림자가 약한 대신 그라데이션이 보임).

### 9. 튜브 상단의 '가로로 각진 몰드'
![tube top](examples/09_tube_top_profile.jpg)
- **원인:** 두께 프로파일이 실링 직전 20 mm에서 급히 꺾임(기울기 0.54).
- **조치:** 두께만 매끈한 곡선으로 다시 잡음(끝 기울기 0.22). 정면 폭·인쇄·UV는 그대로.

### 10. 투명 오버캡 안의 흰 헤드가 '끊겨' 보임
![detached head](examples/10_detached_head_coincident_surface.jpg)
- **원인:** 오버캡 안쪽 벽(R10.5)과 흰 펌프 베이스(R10.5)가 같은 면 → 광선이 베이스를 건너뛰어 회색 투명으로 보임.
- **진단:** 오버캡을 숨긴 진단 렌더로 확인.
- **조치:** 베이스에 0.15 mm 유격.
- **도구화:** `scripts/blend_probe.py`가 이런 겹친 면을 4초 만에 찾음.

## 언제 쓰나

이런 요청이면 이 스킬을 씁니다.
- "이 .blend 제품을 실사화해줘 / 사진처럼 보이게 해줘 / 포토리얼 렌더 만들어줘"
- 렌더가 **가짜 같다, CG 같다, 플라스틱 같다, 회색이다, 우윳빛이다, 끊겨 보인다, 너무 반짝인다**
- 실물 사진이나 카탈로그 이미지를 주며 "이것과 맞춰줘"
- 렌더 **검수 결과**(색 차이, 형상 차이, 비침, 경계)에 대응해야 할 때
- 여러 SKU를 **배치로 렌더하거나 이어서 진행**할 때
- 특정 부위만 고칠 때: "튜브 상단이 어색해", "칼라가 인공적이야", "실링에 엠보가 있어"

이럴 때는 맞지 않습니다.
- 제품 모델을 처음부터 만드는 일(이 스킬은 마스터를 받아 다듬음. 큰 위상 변경은 수치로 정리해 모델러에게 넘김)
- 연출·라이프스타일 장면 제작이 목적일 때(기준은 '실물 사진과 같음')

## 어떻게 쓰나

### 설치

Claude Code
```bash
git clone https://github.com/passeth/blender-product-photoreal.git ~/.claude/skills/blender-product-photoreal
```

Aside
```bash
git clone https://github.com/passeth/blender-product-photoreal.git \
  ~/.aside/u/0/skills/user/blender-product-photoreal
```

skills CLI를 지원하는 에이전트
```bash
npx skills add passeth/blender-product-photoreal --skill blender-product-photoreal
```

Claude 앱: [Releases](https://github.com/passeth/blender-product-photoreal/releases)의 `.skill` 파일을 열어 저장합니다.

### 요청 예시

```text
assets/BRAND/SKU001/v001/SKU001_MASTER_v001.blend 를 카탈로그 사진(references/product.jpg)처럼 실사화해줘.
```
```text
이 튜브 렌더 몸통이 사진보다 하얘. 사진/렌더 패치를 재서 색을 얼마나 바꿀지 계산해줘.
```
```text
투명 캡 안 펌프가 회색으로 보여. 원인부터 단일 변수 시험으로 찾아줘.
```
```text
파우치 사진 실링에 미세 엠보가 있어. 사진에서 간격·방향·폭을 재서 반영하고 사광 매크로로 보여줘.
```
```text
검수 결과 받았어: 아이마크가 실링 경계에서 끊겨 보인대. 원고/UV는 건드리지 말고 고쳐줘.
```

### 스킬이 따르는 절차

1. **인테이크:** 마스터 인벤토리(겹친 면, 커스텀 노멀, 남은 스튜디오 오브젝트), 사진 종류 판정, 원고 잉크 색 수, 부품별 광학 계열
2. **기준 스튜디오:** 카메라와 함께 도는 중립 조명 리그, PBR Neutral, 노출 0, 카탈로그 원근 정면 컷
3. **재질:** 계열별 레시피(얇은 필름 = 직통 투과, 두꺼운 반투명 = SSS + 거친 투과, 진한 내용물 = 부피 흡수 …)
4. **색 보정:** 선형 패치 비교, 중립 기준(흰 캡)으로 노출 분리, 설정값은 sRGB로 변환해 저장
5. **형상:** 사진 카메라 기준 mm 측정 → 정점 수·UV를 유지하는 리맵
6. **시험:** 한 번에 한 변수. 옅은 디테일은 전체 해상도로만 판단
7. **최종:** 렌더 → 저장 → 재열기 verify → 전후 시트·매크로 → ①~⑥ 교정 기록

상태는 세 가지로 따로 관리합니다: **기술 verify / 실물 대조 / 사용자 승인**.
렌더가 끝났다고 '완료'가 아닙니다.

### 번들 스크립트

Blender 내장 파이썬(numpy 포함)과 ffmpeg만 있으면 됩니다.

```bash
# 마스터 인벤토리 + 회전체 프로파일 + 겹친 면 검사(투명 부품과 겹친 면은 !!로 표시)
blender -b master.blend --factory-startup --python scripts/blend_probe.py -- probe.json --collection SKU_PRODUCT

# 사진 vs 렌더 색 패치(선형), 흰 기준 대비 비율, 다음 틴트 제안
python scripts/photo_patches.py --photo photo.jpg --render front.png --mask front_alpha.png \
  --patches "0.3,0.33;0.7,0.33;0.3,0.42" --anchor "0.4,0.95;0.6,0.95" --debug-sheet boxes.jpg

# 실루엣 mm 측정: 높이 축척, 중심에서 13 mm 옆 열의 첫 행(칼라 윗면 등)
python scripts/silhouette_mm.py --image photo.jpg --scale height=203 --probe-col 13,-13

# 미세 패턴(엠보·압착골)의 피치와 방향
python scripts/texture_period.py --image photo.jpg --box 251,400,24,420 --px-per-mm 4.23

# 라벨 붙은 비교 시트
python scripts/sheet.py --out sheet.jpg --height 900 --cols 3 "photo=p.jpg@x,y,w,h" "before=a.png" "after=b.png"
```

## 구성

```
SKILL.md                      절차, 기본 원칙, 증상 → 원인 → 첫 시험 표, 공정상의 함정
references/
  optics_recipes.md           재질·광학 레시피(사진 대조를 통과한 값)
  measurement.md              사진 측정법(축척, 원근, 인쇄 위치, 패치, 충전선, 미세 패턴)
  failure_catalogue.md        교정 기록 66건(C01–C55, R01–R11)을 증상별로 묶은 실패 사례집
  pipeline_fj.md              원 프로젝트의 렌더 파이프라인 참조(해당 프로젝트에서만 사용)
scripts/                      blend_probe, photo_patches, silhouette_mm, texture_period, sheet (+ imgio)
examples/                     README 사례 이미지
```

## 요구 사항

- Blender 4.2 이상(검증: Blender 5.2, Cycles OptiX + OIDN)
- ffmpeg / ffprobe
- numpy(Blender 내장 파이썬으로 충분)

## 라이선스

MIT
