"""Pitch and direction of a fine periodic pattern (heat-seal emboss, crimp flutes, knurl, ribs) in a photo patch.

python texture_period.py --image IMG --box x,y,w,h --px-per-mm 4.23 [--channel 1] [--top 6]

Removes the patch's low-frequency shading (box blur), then reports
- FFT peaks: period (mm) and direction (deg, 0 = image x axis) of the strongest components
- autocorrelation peaks: lag distance (mm) and direction - read the diagonal peaks; elongated patches bias the peaks along their
  long axis
Near Nyquist (< 3 px per period) one family of a lattice can be missing: say so and state the assumption (e.g. mirrored diamond).
"""
import argparse, json
import numpy as np
from imgio import load


def detrend(p, k=9):
    pad = np.pad(p, k, mode='reflect')
    c = np.cumsum(np.cumsum(pad, 0), 1)
    s = c[2 * k:, 2 * k:] - c[:-2 * k, 2 * k:] - c[2 * k:, :-2 * k] + c[:-2 * k, :-2 * k]
    blur = s / (2 * k) ** 2
    return p - blur[:p.shape[0], :p.shape[1]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--image', required=True); ap.add_argument('--box', required=True)
    ap.add_argument('--px-per-mm', type=float, required=True); ap.add_argument('--channel', type=int, default=1)
    ap.add_argument('--top', type=int, default=6)
    a = ap.parse_args()
    x, y, w, h = map(int, a.box.split(','))
    p = load(a.image)[y:y + h, x:x + w, a.channel]
    p = detrend(p) * np.hanning(h)[:, None] * np.hanning(w)[None, :]
    N = 256
    F = np.abs(np.fft.fft2(p, s=(N, N))) ** 2
    F[0, 0] = 0
    peaks = []
    order = np.argsort(F.ravel())[::-1]
    for idx in order:
        fy, fx = divmod(idx, N)
        ky = fy if fy < N // 2 else fy - N; kx = fx if fx < N // 2 else fx - N
        if (ky, kx) == (0, 0) or ky < 0 or (ky == 0 and kx < 0):
            continue  # one of each +-k pair
        per_px = N / np.hypot(ky, kx)
        if per_px < 2 or per_px > min(w, h) / 1.5:
            continue
        ang = float(np.degrees(np.arctan2(ky, kx)))
        if any(abs(per_px / a.px_per_mm - q[0]) < 0.03 and abs(ang - q[1]) < 4 for q in peaks):
            continue
        peaks.append((round(per_px / a.px_per_mm, 3), round(ang, 1), round(float(F[fy, fx] / F.max()), 3)))
        if len(peaks) >= a.top:
            break
    ac = np.fft.fftshift(np.real(np.fft.ifft2(np.abs(np.fft.fft2(p, s=(N, N))) ** 2)))
    c = N // 2; ac /= ac[c, c]
    acp = []
    R = int(min(30, min(w, h) // 2))
    cand = [(ac[c + dy, c + dx], dx, dy) for dy in range(0, R) for dx in range(-R, R) if 2 <= np.hypot(dx, dy) <= R and not (dy == 0 and dx < 0)]
    for v, dx, dy in sorted(cand, reverse=True):
        # local maximum only
        if v < ac[c + dy - 1:c + dy + 2, c + dx - 1:c + dx + 2].max() - 1e-9:
            continue
        acp.append(dict(value=round(float(v), 3), lag_mm=round(float(np.hypot(dx, dy)) / a.px_per_mm, 3), angle_deg=round(float(np.degrees(np.arctan2(dy, dx))), 1)))
        if len(acp) >= a.top:
            break
    print(json.dumps(dict(fft_peaks_period_mm_angle_rel=peaks, autocorr_peaks=acp, px_per_period_min=round(min(q[0] for q in peaks) * a.px_per_mm, 2) if peaks else None), indent=1))


if __name__ == '__main__':
    main()
