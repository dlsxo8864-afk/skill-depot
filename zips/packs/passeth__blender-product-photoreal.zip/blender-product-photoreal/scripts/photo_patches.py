"""Photo vs render colour patches in LINEAR light, with an optional neutral anchor and a suggested sRGB-encoded tint.

python photo_patches.py --photo P.jpg --render R.png --mask R_alpha.png [--patches "0.3,0.33;0.7,0.33;0.3,0.42"]
                        [--anchor "0.4,0.95;0.6,0.95"] [--tint 1,1,1] [--size 0.025] [--out result.json] [--photo-alpha]

Patches are (u, v) in the product bbox, (0, 0) = top-left, half-size = size * bbox width. Keep them off text, seams, edges and
highlights - print the boxes once (--debug-sheet out.png) to check.
Outputs per image: mean linear RGB of the patches, chromaticity (G/R, B/R), anchor-relative ratio (body / anchor, per channel).
ratio = photo / render (linear). Suggested tint for an sRGB-encoded multiplier socket (fj ink_tint, colour fields):
  new = l2s(s2l(tint) * ratio). If the anchor ratios already match, the remaining absolute difference is exposure, not material.
Non-linear responses (film veil, backlight glow) need 2 bracketing renders - interpolate the metric you care about.
"""
import argparse, json, subprocess
import numpy as np
from imgio import load, s2l, l2s, product_mask, bbox


def parse_pts(s):
    return [tuple(float(v) for v in p.split(',')) for p in s.split(';') if p.strip()]


def sample(img, mask, pts, size):
    x0, y0, x1, y1 = bbox(mask)
    r = max(3, int(size * (x1 - x0)))
    out, boxes = [], []
    for u, v in pts:
        cx, cy = int(x0 + u * (x1 - x0)), int(y0 + v * (y1 - y0))
        out.append(np.median(s2l(img[cy - r:cy + r, cx - r:cx + r]).reshape(-1, 3), 0))
        boxes.append((cx - r, cy - r, 2 * r, 2 * r))
    return np.array(out), boxes, (x0, y0, x1, y1)


def summary(v):
    m = v.mean(0)
    return dict(lin=m.round(4).tolist(), srgb=l2s(m).round(4).tolist(), G_R=round(m[1] / m[0], 4), B_R=round(m[2] / m[0], 4))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--photo', required=True); ap.add_argument('--render', required=True); ap.add_argument('--mask')
    ap.add_argument('--photo-alpha', action='store_true', help='photo is RGBA with a cut-out alpha')
    ap.add_argument('--patches', default='0.3,0.15;0.7,0.15;0.3,0.35;0.7,0.35')
    ap.add_argument('--anchor', default='')
    ap.add_argument('--tint', default='1,1,1'); ap.add_argument('--size', type=float, default=0.025)
    ap.add_argument('--out'); ap.add_argument('--debug-sheet')
    a = ap.parse_args()
    ph = load(a.photo, rgba=a.photo_alpha)
    pm = product_mask(ph[..., :3], alpha_img=ph[..., 3] if a.photo_alpha else None)
    ph = ph[..., :3]
    rd = load(a.render)
    rm = product_mask(rd, alpha_img=load(a.mask)) if a.mask else product_mask(rd)
    pts = parse_pts(a.patches)
    pv, pboxes, pbb = sample(ph, pm, pts, a.size); rv, rboxes, rbb = sample(rd, rm, pts, a.size)
    res = dict(photo=summary(pv), render=summary(rv), photo_bbox=pbb, render_bbox=rbb,
               bbox_aspect=dict(photo=round((pbb[3] - pbb[1]) / (pbb[2] - pbb[0]), 4), render=round((rbb[3] - rbb[1]) / (rbb[2] - rbb[0]), 4)))
    ratio = pv.mean(0) / rv.mean(0)
    res['ratio_photo_over_render_lin'] = ratio.round(4).tolist()
    t = np.array([float(x) for x in a.tint.split(',')])
    res['tint_in_srgb'] = t.tolist(); res['tint_suggested_srgb'] = l2s(s2l(t) * ratio).round(4).tolist()
    if a.anchor:
        apts = parse_pts(a.anchor)
        pa, _, _ = sample(ph, pm, apts, a.size); ra, _, _ = sample(rd, rm, apts, a.size)
        res['anchor'] = dict(photo=summary(pa), render=summary(ra),
                             photo_body_over_anchor=(pv.mean(0) / pa.mean(0)).round(4).tolist(),
                             render_body_over_anchor=(rv.mean(0) / ra.mean(0)).round(4).tolist())
        res['anchor']['relative_photo_over_render'] = (np.array(res['anchor']['photo_body_over_anchor']) /
                                                       np.array(res['anchor']['render_body_over_anchor'])).round(4).tolist()
    if a.debug_sheet:
        # draw the patch boxes on both images side by side (ffmpeg drawbox)
        def boxes_filter(bs):
            return ','.join(f'drawbox=x={x}:y={y}:w={w}:h={h}:color=red@0.9:t=3' for x, y, w, h in bs)
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', a.photo, '-i', a.render, '-filter_complex',
                        f'[0]{boxes_filter(pboxes)},scale=-1:900[p];[1]{boxes_filter(rboxes)},scale=-1:900[r];[p][r]hstack', a.debug_sheet], check=True)
    print(json.dumps(res, indent=1))
    if a.out:
        json.dump(res, open(a.out, 'w'), indent=1)


if __name__ == '__main__':
    main()
