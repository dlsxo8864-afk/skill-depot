"""Shared image helpers for the bundled scripts (numpy + ffmpeg/ffprobe only, so Blender's bundled python is enough)."""
import subprocess
import numpy as np


def size(path):
    p = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', path],
                       capture_output=True, text=True, check=True).stdout.strip().split(',')
    return int(p[0]), int(p[1])


def load(path, rgba=False):
    """float image in [0,1], shape (h, w, 3|4), sRGB-encoded values."""
    w, h = size(path)
    fmt = 'rgba' if rgba else 'rgb24'
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-f', 'rawvideo', '-pix_fmt', fmt, '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.uint8).reshape(h, w, 4 if rgba else 3).astype(np.float64) / 255


def s2l(a):
    a = np.asarray(a, float)
    return np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)


def l2s(a):
    a = np.clip(np.asarray(a, float), 0, None)
    return np.where(a <= 0.0031308, a * 12.92, 1.055 * a ** (1 / 2.4) - 0.055)


def product_mask(img, mode='nonwhite', alpha_img=None, white=0.95, chroma=0.04):
    """Product mask: from a render alpha image (preferred for renders - their backgrounds are not white) or 'nonwhite' for
    cut-out photos on white (bright neutral pixels = background)."""
    if alpha_img is not None:
        a = alpha_img[..., 0] if alpha_img.ndim == 3 else alpha_img
        return a > 0.5
    mx, mn = img.max(2), img.min(2)
    return (mx < white) | ((mx - mn) > chroma)


def bbox(mask):
    ys, xs = np.where(mask)
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def crop(img, box):
    x, y, w, h = box
    return img[y:y + h, x:x + w]
