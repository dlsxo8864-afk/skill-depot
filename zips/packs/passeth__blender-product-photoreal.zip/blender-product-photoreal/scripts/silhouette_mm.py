"""Silhouette measurements in mm for a photo or a render (same method on both, then compare).

python silhouette_mm.py --image IMG [--mask ALPHA.png] --scale height=203 [--fractions 0.05,0.1,...]
                        [--probe-col 13,-13] [--width-at-mm 30,60,150] [--out res.json]

--scale height=<mm>      product top-to-bottom = <mm> (or width=<mm>@<row_frac>: the width at that row fraction = <mm>)
--probe-col X[,..]       first filled row (from the top) in the column X mm right of the centre (negative = left), reported as
                         mm below the product top. Pick X from the model radii so it hits only the feature you want
                         (e.g. 13 mm: outside an R11.3 overcap, inside an R14.5 collar -> collar top).
--width-at-mm D[,..]     half width (mm) at D mm below the product top.
--fractions              half width at these height fractions (0 = top).
Renders: always pass --mask (render backgrounds are grey gradients, not white). Photos: cut-out on white ('nonwhite').
Close catalogue shots magnify near rims of circles above/below eye level; side tangents are ~orthographic - see measurement.md.
"""
import argparse, json
import numpy as np
from imgio import load, product_mask, bbox


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--image', required=True); ap.add_argument('--mask')
    ap.add_argument('--scale', required=True)
    ap.add_argument('--fractions', default='0.02,0.05,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.98')
    ap.add_argument('--probe-col', default=''); ap.add_argument('--width-at-mm', default='')
    ap.add_argument('--out')
    a = ap.parse_args()
    img = load(a.image)
    m = product_mask(img, alpha_img=load(a.mask)) if a.mask else product_mask(img)
    x0, y0, x1, y1 = bbox(m)
    H = y1 - y0
    rows = {r: np.nonzero(m[r])[0] for r in range(y0, y1)}
    def half_w(r):
        xs = rows.get(r)
        return (xs.max() - xs.min() + 1) / 2 if xs is not None and len(xs) else 0
    kind, val = a.scale.split('=')
    if kind == 'height':
        pxmm = H / float(val)
    else:
        mm, frac = val.split('@')
        pxmm = 2 * half_w(int(y0 + float(frac) * H)) / float(mm)
    top_rows = range(y0, y0 + max(5, H // 20))
    cx = float(np.median([(rows[r].min() + rows[r].max()) / 2 for r in top_rows if r in rows and len(rows[r])]))
    res = dict(image=a.image, bbox=[x0, y0, x1, y1], px_per_mm=round(pxmm, 4), height_mm=round(H / pxmm, 2), centre_x=cx,
               half_width_mm_at_fraction={f: round(half_w(int(y0 + float(f) * (H - 1))) / pxmm, 3) for f in a.fractions.split(',')})
    if a.width_at_mm:
        res['half_width_mm_at_mm'] = {d: round(half_w(int(y0 + float(d) * pxmm)) / pxmm, 3) for d in a.width_at_mm.split(',')}
    if a.probe_col:
        pr = {}
        for xmm in a.probe_col.split(','):
            c = int(round(cx + float(xmm) * pxmm))
            col = np.nonzero(m[y0:y1, c])[0] if 0 <= c < m.shape[1] else []
            pr[xmm] = round(float(col.min()) / pxmm, 3) if len(col) else None
        res['first_filled_mm_below_top'] = pr
    print(json.dumps(res, indent=1))
    if a.out:
        json.dump(res, open(a.out, 'w'), indent=1)


if __name__ == '__main__':
    main()
