"""Labelled comparison sheet (photo | before | after | variants) with ffmpeg.

python sheet.py --out sheet.jpg [--height 900] [--cols 3] [--width 3000] "label=path[@x,y,w,h]" ...

Each item is cropped (optional box in source pixels), scaled to the same height, labelled top-left, laid out in rows of --cols,
then the whole sheet is scaled to --width (if given). Labels are sanitised for drawtext (':' ',' quotes and backslashes break the
filter graph). Keep the same camera/lights for before/after; say so in the label when a crop is magnified ('x5.7').
"""
import argparse, os, subprocess

FONTS = ['C:/Windows/Fonts/arial.ttf', '/System/Library/Fonts/Supplemental/Arial.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']


def safe(t):
    return t.replace('\\', '/').replace(':', ' -').replace("'", '').replace(',', ' ').replace('%', ' pct').replace(';', ' ')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True); ap.add_argument('--height', type=int, default=900)
    ap.add_argument('--cols', type=int, default=0); ap.add_argument('--width', type=int, default=0)
    ap.add_argument('--fontsize', type=int, default=0)
    ap.add_argument('items', nargs='+')
    a = ap.parse_args()
    font = next((f for f in FONTS if os.path.exists(f)), None)
    fs = a.fontsize or max(16, a.height // 28)
    inputs, chains, labels = [], [], []
    for i, it in enumerate(a.items):
        label, _, spec = it.partition('=')
        path, _, box = spec.partition('@')
        inputs += ['-i', path]
        f = []
        if box:
            x, y, w, h = box.split(',')
            f.append(f'crop={w}:{h}:{x}:{y}')
        f.append(f'scale=-2:{a.height}')
        if font:
            ff = font.replace(':', '\\:')
            f.append(f"drawtext=fontfile='{ff}':text='{safe(label)}':x=10:y=10:fontsize={fs}:fontcolor=black:box=1:boxcolor=white@0.85:boxborderw=6")
        chains.append(f'[{i}]' + ','.join(f) + f'[v{i}]')
        labels.append(f'[v{i}]')
    n = len(labels); cols = a.cols or n
    rows = [labels[r:r + cols] for r in range(0, n, cols)]
    parts = chains[:]
    rlabels = []
    for ri, r in enumerate(rows):
        if len(r) < cols and len(rows) > 1:
            # pad a short last row with a blank so vstack gets equal widths
            parts.append(f'color=c=white:s=16x{a.height}[pad{ri}]')
            r = r + [f'[pad{ri}]']
        if len(r) == 1:
            parts.append(f'{r[0]}null[r{ri}]')
        else:
            parts.append(''.join(r) + f'hstack=inputs={len(r)}[r{ri}]')
        rlabels.append(f'[r{ri}]')
    if len(rlabels) == 1:
        last = rlabels[0]
    else:
        # equalise row widths by padding to the widest row
        parts.append(''.join(rlabels) + f'xstack=inputs={len(rlabels)}:layout=' + '|'.join(f'0_{"+".join(["h0"] * k) if k else 0}' for k in range(len(rlabels))) + ':fill=white[all]')
        last = '[all]'
    if a.width:
        parts.append(f'{last}scale={a.width}:-2[out]'); last = '[out]'
    cmd = ['ffmpeg', '-v', 'error', '-y'] + inputs + ['-filter_complex', ';'.join(parts), '-map', last, '-frames:v', '1', a.out]
    subprocess.run(cmd, check=True)
    print('wrote', a.out)


if __name__ == '__main__':
    main()
