"""Inventory a product .blend before look-dev (run INSIDE Blender).

blender -b <file.blend> --factory-startup --python blend_probe.py -- <out.json> [--collection NAME] [--tol-mm 0.03] [--max-pairs 400]

Writes JSON and prints a short report:
- objects: type, parent, collections, hide_render, verts/faces, world bbox (mm), materials, modifiers, custom normals, smooth share,
  UV layers, custom property keys
- materials: preset/property tags, image textures (name, size, channels, alpha mode, path)
- lathe profiles: for meshes that are rotationally symmetric about world Z, the (z, r_min, r_max) rings in mm (ring = unique z)
- coincident surfaces: mesh pairs whose surfaces lie within tol (default 0.03 mm) of each other (points sampled every 0.4 mm along
  edges). 'surface overlap' spans a z range on one radius; 'seam/contact' is a seating ring. Flag '!!' = overlap involving a clear part.
  Intended contacts (label on bottle, liquid wetting a wall) also appear - judge them, don't 'fix' them blindly. A clear/transparent
  part coincident with an opaque part renders the opaque part see-through or grey (rays leaving the clear wall skip the touching
  surface) - e.g. an overcap inner wall exactly on a pump base radius made the spray head look detached.
- objects outside the given collection (leftover studio planes etc.)
"""
import bpy, sys, json, math
import numpy as np
from mathutils.bvhtree import BVHTree

argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
out = argv[0] if argv else 'blend_probe.json'
opt = lambda k, d=None: argv[argv.index(k) + 1] if k in argv else d
COL = opt('--collection')
TOL = float(opt('--tol-mm', 0.03)) * 1e-3
MAXP = int(opt('--max-pairs', 400))
MM = 1e3


def world_co(o):
    me = o.data
    co = np.empty(len(me.vertices) * 3); me.vertices.foreach_get('co', co); co = co.reshape(-1, 3)
    W = np.array(o.matrix_world)
    return co @ W[:3, :3].T + W[:3, 3]


def lathe_profile(co):
    if len(co) < 24:
        return None
    r = np.hypot(co[:, 0], co[:, 1]); z = co[:, 2]
    zk = np.round(z * MM, 2)
    zs, inv, cnt = np.unique(zk, return_inverse=True, return_counts=True)
    if len(zs) > 400 or cnt.max() < 8:
        return None
    # rotational symmetry: within each ring the vertices spread around the axis
    ang = np.arctan2(co[:, 1], co[:, 0])
    spread = np.zeros(len(zs))
    for i in range(len(zs)):
        a = ang[inv == i]
        spread[i] = (a.max() - a.min()) if len(a) > 2 else 0
    if np.median(spread) < 5.5:  # < ~315 deg of coverage -> not a revolve
        return None
    rows = []
    for i, zz in enumerate(zs):
        rr = r[inv == i] * MM
        rows.append([float(zz), round(float(rr.min()), 3), round(float(rr.max()), 3), int(cnt[i])])
    return rows


def main():
    scene_objs = list(bpy.data.objects)
    col_objs = set(o.name for o in bpy.data.collections[COL].all_objects) if COL and COL in bpy.data.collections else None
    res = dict(file=bpy.data.filepath, objects={}, materials={}, images={}, outside_collection=[], coincident=[], lathe={})
    meshes = []
    for o in scene_objs:
        if col_objs is not None and o.name not in col_objs:
            res['outside_collection'].append(o.name)
        d = dict(type=o.type, parent=o.parent.name if o.parent else None, collections=[c.name for c in o.users_collection],
                 hide_render=o.hide_render, props=sorted(o.keys()))
        if o.type == 'MESH':
            me = o.data; co = world_co(o)
            d.update(verts=len(me.vertices), faces=len(me.polygons),
                     bbox_mm=[(co.min(0) * MM).round(3).tolist(), (co.max(0) * MM).round(3).tolist()] if len(co) else None,
                     materials=[m.name if m else None for m in me.materials], modifiers=[(m.type, m.name) for m in o.modifiers],
                     custom_normals=me.has_custom_normals, smooth_share=round(float(np.mean([p.use_smooth for p in me.polygons])), 3) if len(me.polygons) else 0,
                     uv_layers=[u.name for u in me.uv_layers], mesh_users=me.users, mesh_name=me.name)
            prof = lathe_profile(co)
            if prof:
                res['lathe'][o.name] = prof
            if not o.hide_render and (col_objs is None or o.name in col_objs) and len(co):
                meshes.append((o, co))
        res['objects'][o.name] = d
    for m in bpy.data.materials:
        imgs = []
        if m.node_tree:
            for n in m.node_tree.nodes:
                if n.bl_idname == 'ShaderNodeTexImage' and n.image:
                    imgs.append(n.image.name)
        res['materials'][m.name] = dict(users=m.users, images=imgs, props={k: str(m[k])[:80] for k in m.keys()})
    for im in bpy.data.images:
        res['images'][im.name] = dict(size=list(im.size), channels=im.channels, alpha_mode=im.alpha_mode, path=im.filepath, packed=bool(im.packed_file))
    # coincident surfaces: points sampled along A's edges (every 0.4 mm, so long wall quads are covered) vs B's surface (BVH)
    CLEAR = ('clear', 'glass', 'pet', 'overcap', 'transparent', 'liquid', 'film', 'frost')
    is_clear = lambda o: any(k in (m or '').lower() for m in res['objects'][o.name]['materials'] for k in CLEAR)
    edges = {}
    def edge_points(o, lo, hi, step=0.4e-3, cap=40000):
        if o.name not in edges:
            me = o.data
            e = np.empty(len(me.edges) * 2, np.int64); me.edges.foreach_get('vertices', e); edges[o.name] = e.reshape(-1, 2)
        co = dict(meshes)[o]
        e = edges[o.name]
        a, b = co[e[:, 0]], co[e[:, 1]]
        keep = np.all((np.minimum(a, b) <= hi) & (np.maximum(a, b) >= lo), axis=1)
        a, b = a[keep], b[keep]
        L = np.linalg.norm(b - a, axis=1); n = np.clip((L / step).astype(int) + 1, 1, 200)
        pts = np.concatenate([a[i] + (b[i] - a[i]) * np.linspace(0, 1, n[i])[:, None] for i in range(len(a))]) if len(a) else np.zeros((0, 3))
        pts = pts[np.all((pts >= lo) & (pts <= hi), axis=1)]
        if len(pts) > cap:
            pts = pts[np.random.default_rng(1).choice(len(pts), cap, replace=False)]
        return pts
    dg = bpy.context.evaluated_depsgraph_get()
    bvh = {}
    pairs = 0
    for i, (a, ca) in enumerate(meshes):
        for b, cb in meshes[i + 1:]:
            if pairs >= MAXP:
                break
            lo = np.maximum(ca.min(0), cb.min(0)) - TOL; hi = np.minimum(ca.max(0), cb.max(0)) + TOL
            if np.any(lo > hi):
                continue
            pairs += 1
            best = None
            for x, y in ((a, b), (b, a)):
                if y.name not in bvh:
                    bvh[y.name] = BVHTree.FromObject(y, dg)
                pts = edge_points(x, lo, hi)
                hits = [p for p in pts if bvh[y.name].find_nearest(tuple(p), TOL)[0] is not None]
                if len(hits) >= 24 and (best is None or len(hits) > best[2]):
                    best = (x, y, len(hits), np.array(hits))
            if best:
                x, y, nh, h = best
                r = np.hypot(h[:, 0], h[:, 1]) * MM
                zr = [round(float(h[:, 2].min() * MM), 2), round(float(h[:, 2].max() * MM), 2)]
                kind = 'surface overlap' if zr[1] - zr[0] > 0.3 and (r.max() - r.min()) < 0.6 * max(zr[1] - zr[0], 1e-6) + 2 else 'seam/contact'
                res['coincident'].append(dict(a=x.name, b=y.name, kind=kind, clear_involved=bool(is_clear(x) or is_clear(y)),
                                              a_materials=res['objects'][x.name]['materials'], b_materials=res['objects'][y.name]['materials'],
                                              points_within_tol=nh, z_mm=zr, r_mm=[round(float(r.min()), 2), round(float(r.max()), 2)]))
    res['coincident'].sort(key=lambda c: (not c['clear_involved'], c['kind'] != 'surface overlap', -c['points_within_tol']))
    json.dump(res, open(out, 'w', encoding='utf8'), indent=1, ensure_ascii=False)
    print('PROBE objects', len(res['objects']), 'meshes', len(meshes), 'lathe', len(res['lathe']), 'pairs checked', pairs)
    if res['outside_collection']:
        print('PROBE outside collection:', res['outside_collection'][:20])
    for c in res['coincident']:
        flag = '!!' if (c['clear_involved'] and c['kind'] == 'surface overlap') else '  '
        print('PROBE COINCIDENT', flag, c['kind'], '|', c['a'], '<->', c['b'], '| points', c['points_within_tol'], 'z', c['z_mm'], 'r', c['r_mm'])
    for n, o in res['objects'].items():
        if o.get('custom_normals'):
            print('PROBE custom normals:', n)


main()
