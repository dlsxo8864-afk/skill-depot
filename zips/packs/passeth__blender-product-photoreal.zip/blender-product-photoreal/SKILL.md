---
name: blender-product-photoreal
description: Turn Blender product master files (cosmetic bottles, tubes, jars, pumps, droppers, sprays, pouches, cartons) into photoreal catalogue renders that match the real product photo - look-dev, photo-calibrated colour, photo-measured geometry fixes, single-variable tests, save->reopen verify, before/after sheets and correction records for the modeller. Use this whenever the user wants a .blend product made photoreal or "like the photo" (실사화, 포토리얼, 룩데브, 렌더 개선, 사진처럼, 실물처럼), says a render looks fake / CG / plastic / grey / milky / detached / too glossy, sends a product photo to match, relays an inspection (검수) of renders, or asks to set up or continue a batch of product renders - even when they only name a SKU or say "fix this part".
---

# Blender product master -> photoreal render

Distilled from a 45+13 SKU cosmetics project (FRAIJOUR, ROERANCE). Almost every rule below exists because breaking it cost a
re-render. Read the "why" - it tells you when a rule does not apply.

## Ground rules

- **The physical product photo is the colour and shape truth**, not artwork RGB/PANTONE (print is colour-matched on press) and not
  the modeller's estimate. Exceptions: white ink stays fixed white (thin white strokes in photos are contaminated by the base colour);
  staged/retouched photos, CG templates (several SKUs with identical bboxes) and "artwork only" SKUs are not evidence - say
  "photo-unverified" instead of inventing a match.
- **Masters, artwork and the modeller's scripts are read-only.** Work on render copies; every change is a documented, versioned
  edit (`pass00N/`, `v2_snapshot/`) so "before" always exists. A refine keeps vertex count/order and UVs unless it says otherwise.
- **Three separate states per SKU:** technical verify (saved -> reopened -> diffed against the master), photo match (judged by a human
  against the photo), user approval. A green verify is not a photo match; never call a batch "complete" because renders exist.
- **Change one variable at a time** and compare with the same camera, lights, geometry and artwork. Most wasted hours in the project
  came from changing two things and attributing the result to the wrong one.
- **Respect user scope statements** ("keep the look, change only X"): fix only X, put everything else you notice in the report.
- Shared machine: never kill Blender by image name; only your own PIDs. Don't stop running renders to "clean up".

## Workflow

### 0. Intake (before touching materials)
1. Inventory the master: `scripts/blend_probe.py` (objects, bbox, materials, images, UV layers, modifiers, custom normals,
   lathe profiles, **coincident surfaces between transparent and opaque parts**). Note objects outside the product collection
   (leftover studio planes z-fight with the cyc).
2. Classify each reference image: real photo / retouched catalogue / CG template / staged (props, lighting effects) / artwork only.
   Check white balance on a neutral part (a white cap: B/R ~1.0 means neutral; a frosted cap on a coloured fill picks up its colour).
3. Count artwork ink colours (1 colour / white + spot / 3+ colours) - this picks the ink mode (see references/optics_recipes.md).
4. Identify optical families per part: opaque PP, laminate tube, thin translucent film, thick translucent wall, clear PET + liquid,
   frosted cap, chrome/metallised, gel/cream contents, paperboard. Never apply one family's values to another.

### 1. Baseline studio and colour management
Neutral studio with lights parented to a rig that rotates with the camera (light/camera relation fixed per shot), world ~0.12 white,
Khronos PBR Neutral, exposure 0, front camera at catalogue perspective (~250 mm focal, ~0.8 m). Remove the master's own studio.
Per-family exceptions only via per-SKU overrides: chrome needs an environment to reflect (brighter world + black flags/strips);
clear/translucent parts need caustics on and no black flags behind them; light-table products need a body-only backlight panel.

### 2. Materials by family
Use the recipes in `references/optics_recipes.md`. The decisive facts:
- A **refractive** shell (transmission) blocks direct light to whatever is inside -> interiors render grey/dark. Thin walls (tube
  film, overcaps whose interior must show) use **thin-film transparency** (Transparent BSDF straight-through, ink opaque); thick
  translucent walls use SSS + rough transmission + coat; scattering gels are NOT index-matched.
- The diffuse part of a thin film is a white veil: brightens and desaturates what is behind (milky caps, lemon-pale gels).
- Surface-tinted gels tint once per interface regardless of thickness -> back print shows through; dark thick contents need
  **volume absorption** (thickness-dependent).
- Liquid touching a wall: index-match the sides (a 0.3 mm air gap greys translucent bottles); never do this for scattering gels.

### 3. Calibrate colour against the photo (closed loop)
- Measure the same relative patches on photo and render in **linear** light (`scripts/photo_patches.py`). Avoid text, edges, seams.
- Every colour/tint in configs is **sRGB-encoded**: new = l2s(s2l(old) * ratio). Applying linear ratios to sRGB numbers was the
  single most repeated mistake.
- Anchor exposure on a neutral part of the same photo session (a white cap), then match the body *relative* to it. If one photo
  channel is near saturation, match chromaticity (G/R, B/R) not absolute values. Don't push albedo to its ceiling to fake a
  lighting difference - fix the light (fill card, backlight power) instead and record it.
- Response is often non-linear per channel (veil + glow): bracket two strengths, measure, interpolate - 2-3 preview iterations.

### 4. Geometry from the photo
- Measure in the photo's camera, not bbox ratios: near catalogue shots magnify the near rim of circles above/below eye level.
  Use a known dimension as scale (cap diameter, collar width, total height) and cross-check with a second one.
  Methods: `references/measurement.md`, `scripts/silhouette_mm.py`.
- Fix with **remaps of existing vertices** (profile re-mapping on lathe parts, y-only thickness profile on tubes/pouches, z scale
  with UV kept) so artwork stays put and verify can classify the edit. Big topology changes (new pump head, double wall) belong to
  the modeller; send numbers.
- Print position wrong? First decide: UV offset (same layout, shifted), tube length (whole layout compressed/extended), or artwork
  revision. Measure 2+ text rows; uniform offset = UV, uniform scale = length.

### 5. Test, one variable at a time
- Previews (750x1000, 128 spp) for gross look; **full resolution for anything faint** (back print through gel/film, eye marks,
  emboss, micro texture) - the preview denoiser erases faint detail and once made a failed fix look successful.
- Name variants by what changed (`T2_seal_clear23_soft3`), keep them, measure them (patch values, contrast profiles, diff images),
  and build a labelled sheet: photo | before | variants.

### 6. Production, verify, evidence
Render all shots closed (+open), save, **reopen and verify** against the master (topology/UV/geometry hashes; documented refines are
allowed, anything else is "unexpected"). Then before/after sheets with the same camera and lights, macros for every user-named
detail, and a correction record per issue: ① observation ② cause ③ change ④ evidence paths ⑤ builder rule ⑥ remaining uncertainty.

## Symptom -> cause -> first single-variable test
| Symptom | Usual cause | First test |
|---|---|---|
| Part inside a clear cap/bottle is grey/dark | refractive shell blocks direct light; caustics off | thin-film transparency for thin walls / caustics on |
| Clear/frosted part looks milky | diffuse base colour of the thin film (white veil) | lower film diffuse share or tint, not more transmission |
| Translucent bottle grey | 0.3 mm air gap between liquid and wall | index-match liquid sides |
| Back print reads through gel/film | surface-tinted contents; film too clear | volume absorption density (judge at full res) |
| Hard horizontal boundary in a transparency/mask | step function in a shader mask | smoothstep edge / move the boundary to the physical zone |
| Part under a clear cap looks detached / see-through | **coincident surfaces** (clear wall == opaque part radius) | 0.1-0.2 mm clearance; diagnose by hiding the clear part |
| Horizontal "angular moulding" near a tube's top | loft thickness profile with a knee before the seal | y-only smooth thickness profile, flat seal = rib band + seam |
| Regular stripes / waves on a film or pouch | procedural ripple baked into the master mesh | smooth y (Laplacian), add seeded soft irregular lumps |
| Chrome looks like a barrel / CG razor bands | smooth-shaded lathe chamfers; perfect mirror | sharp >30 deg cleanup; then roughness variation, waviness, rounded rims |
| White ink turned the spot colour | single-ink mode on a white+spot artwork | two_tone / texture ink mode by ink count |
| Colour "right" in numbers but wrong by eye | measured on text/edges/background; sRGB vs linear | re-place patches; check maths in linear |
| Dot / pole pinch / swirl on lathe caps | 1 um degenerate pole ring, shared disc normals | merge <4 um, flat-disc normal lock |
| Stripes on the floor | leftover large plane in the master z-fights the cyc | drop objects outside product/reference collections |
| Camera sees a flat product edge-on | azimuth derived from a UV point on a flat panel | give the panel's facing azimuth explicitly |
More cases with numbers and IDs: `references/failure_catalogue.md`.

## Process traps (each cost a re-render)
- Editing a tool or config that a running batch imports: edit a copy, compile, test, atomic `mv`; keep the old one in `_prev/`.
  Never edit a running shell script. Config generators: deep-copy shared dicts before mutating one SKU (a shared override silently
  changed three SKUs mid-batch).
- A verify that "passes" may not run: check it actually opened every file (a SKU-prefix filter skipped a whole brand).
- Re-measure after every change; never assume a scale or position from an earlier step (an eye-mark range written from memory was
  wrong by 9 mm).
- ffmpeg drawtext: a ':' in label text breaks the filter graph - avoid it or escape it.
- Long GPU queues: chain batches (wait for a log marker) instead of running five at once; previews in between are fine.
- When a render job reports "stopped" after a session restart, check the process list and logs before relaunching - it may
  still be running.

## Project toolkit (PRD_mockup)
If you are in the PRD_mockup project, use the existing pipeline instead of rebuilding it: `references/pipeline_fj.md`
(fj_run modes and config keys, fj_lookdev options, refine modules, verify allowances, single-variable harness, batch scripts).

## Bundled scripts (Blender's bundled python with numpy + ffmpeg is enough; `imgio.py` is their shared helper)
`SK` = this skill's folder, `PY` = Blender's bundled python (system python may be missing), `BL` = blender executable.
```
BL -b master.blend --factory-startup --python SK/scripts/blend_probe.py -- probe.json --collection <SKU>_PRODUCT
    # inventory, lathe rings, '!! surface overlap' = clear part coincident with another part (fix with 0.1-0.2 mm clearance)
PY SK/scripts/photo_patches.py --photo photo.jpg --render front.png --mask front_alpha.png \
    --patches "0.3,0.33;0.7,0.33;0.3,0.42" --anchor "0.4,0.95;0.6,0.95" --tint 1,1,1 --debug-sheet boxes.jpg
    # linear patches, G/R B/R, body/anchor ratios, suggested sRGB-encoded tint
PY SK/scripts/silhouette_mm.py --image photo.jpg --scale height=203 --probe-col 13,-13      # same call on the render + --mask
    # px/mm, half widths, first filled row in off-centre columns (feature heights in mm below the top)
PY SK/scripts/texture_period.py --image photo.jpg --box x,y,w,h --px-per-mm 4.23           # emboss / flute pitch and angle
PY SK/scripts/sheet.py --out sheet.jpg --height 900 --cols 3 "photo=p.jpg@x,y,w,h" "before=a.png" "after=b.png"
```
Verified on the project data: the probe found the overcap/pump-base overlap (z 173.5-175.9, r 10.5) that made a spray head look
detached; silhouette gave overcap 28.1 mm (photo) vs 29.5 mm (render); texture gave 0.92-0.99 mm at 35 deg for a pouch seal.
