# Failure catalogue (symptom -> root cause -> what fixed it)

IDs refer to the PRD_mockup correction records (handoffs/CODEX_CORRECTIONS_CLAUDE*.txt): C = FRAIJOUR, R = ROERANCE.
Grouped by where the fault lived. Read the group that matches your symptom.

## Contents
- A. Topology and mesh
- B. Geometry vs photo
- C. Materials and optics
- D. Artwork, ink and UV
- E. Colour calibration
- F. Lighting and studio
- G. Pipeline and process (Claude-side mistakes)

## A. Topology and mesh
- Dot at a dome apex, radial swirl in a cap's inner disc (C01): builder made a 1 um pole ring (256 overlapping verts) and a single-fan
  disc sharing normals with the wall. Fix: merge < 4 um, sharp > 30 deg, lock flat-region normals. Never on printed (UV) meshes.
- Floor stripes (C13): a 200 m 'Plane' left in the master z-fights the cyc. Drop everything outside the product/reference collections.
- Head looks detached / base see-through under a clear overcap (R11): overcap inner wall R10.5 coincident with the pump base R10.5.
  Diagnose by hiding the clear part; fix with 0.15 mm radial clearance. Check coincident surfaces in intake (`blend_probe.py`).
- Regular stripes on a pouch (pass007): procedural ripple in the master; Laplacian-smooth the face (y only) + soft seeded lumps.
- Chrome barrel/fish-eye look (R02): smooth shading interpolated across chamfers; sharp edges + normal lock.

## B. Geometry vs photo
- Egg-shaped dome vs flat-top squircle (C07): re-map the lathe profile at the same parameter t onto a superellipse (n ~2.27), inner
  wall mapped with the same t (thickness kept), vertex count/order/UV unchanged.
- Toner bottle shoulder 6.5-9 mm low, ring floating (C20): profile remap per SKU; "D72 H160" was neck-inclusive.
- Pump head = barrel + plate (C12): rebuilt as one moulded head (12 deg top, beak spout, D-cut, slit); old parts hidden with
  'superseded' tag, not deleted.
- Dropper collar D26 vs photo D22.9 (C27): radial offset with wall kept; protect printed body with an assert.
- Tube length = artwork height assumption (C44): 9 tubes 3-11 mm too long -> crimp_trim with UV kept relative to the shoulder.
- Catalogue layout compressed ~0.89 (R08): uniform z scale, UV unchanged (a crop put the text 16 mm wrong).
- Body silhouette straight taper vs concave flare (R03): a(z)=27.1+6.5*t^2.15 - builder work; send the formula.
- Tube top horizontal "moulded shoulder" (R10): thickness profile knee; Hermite profile from 130 mm below the end to the welded flat
  (7.5 mm), end slope 0.22; front silhouette already matched (0.6 mm) so x untouched.
- Overcap too tall (R11): 10 photos -> -1.6 mm; moved only vertices above the straight wall (seat, wall 0.8, top wall 1.0 kept),
  checked head clearance 4.61 -> 3.01 mm.
- Fill heights (C39, C52): contents ended before the crimp transition (white band) or filled too high (FC004: 25.8 -> 43.5 mm).

## C. Materials and optics
- Grey/dark inside clear parts (C18, C35, C42): refraction blocks direct light + caustics off. Thin walls -> thin-film transparency;
  clear bottles -> caustics on; frosted caps -> transmission 0 + thin + SSS.
- Translucent bottle grey (C22): 0.3 mm air gap; index-match liquid sides.
- Translucent bottles rendered glass-like or opaque (C23, C24): user correction "plastic, not glass"; SSS-dominant + rough transmission
  + coat, backlight panel. Scattering volumes inside refractive walls render grey (rejected).
- Gel tubes grey/brown/khaki (C35): four separate causes (dark diffuse fill, index-matched gel, refractive wall, light-table glow);
  isolate them one by one.
- Lemon-pale saturated gel (C48): film's 38 % white veil; thin 0.62 -> 0.80 for saturated contents.
- Milky clear overcap (C53): diffuse part's bright base colour; thin 0.95 + mid base colour.
- Back print through a clear tube's seal (C50): flutes need diffuse transmission, not only bump.
- Eye mark faint / cut (C54, insp009): seal optical contact -> clearer seal zone; the zone edge must not cut the mark; smoothstep.
- Back print through dark gel (C55): surface tint -> volume absorption density 250; full-res judgement; no re-calibration after.
- Clear PET + duplex label gradient (R01): wetted wall, index-matched liquid, coupled label, shadow/diffuse-invisible clear parts,
  caustics off; approved by the user as option B (weak floor shadow).
- Frosted caps too clear / glassy (C37, C50 add.): transmission 0 + thin 0.5 + SSS 0.5; dense coloured caps thin 0.28.

## D. Artwork, ink and UV
- Ink = artwork RGB/PANTONE (C04): wrong; calibrate ink/base ratio to the photo. White ink fixed (C05).
- Two inks in one texture (C15), grey logo vanished (C36), white logo turned orange (C38): choose the ink mode by ink count.
- Print 8-9 mm too high (C32): bottom offset assumption; measure rows, shift UV.
- Tube print toward the cap (C33/C44): first FJFC002 only (UV shift 7.5 mm); for the others the tube was too long.
- Warm paper white in label rasters (R05): neutralise copies of the raster only with user consent; never edit originals.
- Dieline guides baked into rasters (R04): ask for clean artwork; don't paint over.
- Mirror-reversed text through a clear part (C50): physically correct; never delete legal copy - treat optically.
- Small text pale/thin vs the photo (FJFC005): ink relief ruled out by a full-res single-variable test; suspect dot gain (stroke
  weight) via ink edge thresholds - not yet tested.

## E. Colour calibration
- Albedo pinned at its ceiling (C10): lighting difference absorbed into the material; fix the light (fill card) and lock body to cap.
- Calibration file overwrote config colours it never calibrated (C26): only store roles that were actually calibrated.
- Patches on background/shadow (C30): cut-out reference, explicit bbox.
- Linear ratio applied to sRGB values (C49): FJAP007 collar raspberry, FJEC001 orange, FJFC004 G off; always compute in linear.
- R channel saturated (C51): match hue ratios.
- Cream too white (pass006 v4): photo session neutral (white cap B/R 0.99), so the warm body is real; hue via gel colour x k^0.56,
  brightness via backlight 1.2 -> 0.6 W (body/anchor), not via albedo.
- Pouch green bluer than photo (pass007): texture-mode tint closed loop in two renders (photo/render 1.004/0.997/1.008).

## F. Lighting and studio
- Per-file inspection lights, dark world, AgX contrast, exposure -0.65 (C02): replace with one neutral rig, PBR Neutral, exposure 0.
- Glossy coloured edges too light (C11): black flags.
- Chrome dark (C19): it reflects the environment - brighter world, flag/strips placement; record clipping as a family QC exception.
- Chrome collar clipping white bands are inherent (R02): document as QC exception rather than dimming everything.

## G. Pipeline and process (Claude-side)
- Old node groups with the same names in the master (C25): rename source groups on load so the current library rebuilds.
- Tool edited while a batch imported it: copy -> test -> atomic mv; never edit a running .sh.
- Wrong config launched (KeyError mid-batch): generate and load the config before launching; kills were refused - prevention only.
- Shared override dict mutated three SKUs (FC005 backlight): deep-copy per SKU; diff the generated config against a backup copy
  after every regeneration (`changed: [...]` must list only the intended SKUs).
- Verify silently skipped a brand (SKU prefix filter): check that every expected file was opened.
- Preview denoiser hid a failing fix (C55): faint detail only at full res.
- Eye-mark range written from memory was 9 mm wrong: re-measure from the texture.
- Flat products framed edge-on: UV-point azimuth undefined on flat panels; give the facing azimuth.
- Sealed pouches have no open state: verify only the states that exist.
- ffmpeg drawtext ':' in labels broke sheet generation.
- Session restart reported jobs as "stopped" while the Blender processes kept running: check processes and logs first.
