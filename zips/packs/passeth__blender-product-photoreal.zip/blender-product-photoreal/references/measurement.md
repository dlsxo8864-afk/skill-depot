# Measuring the photo (so fixes are numbers, not impressions)

## Contents
1. Classify the photo first
2. Scale and camera
3. Silhouette and feature heights
4. Print position: UV offset vs tube length vs artwork revision
5. Colour patches, anchors, white balance
6. Fill lines, eye marks, seal zones
7. Fine patterns (emboss, flutes, knurl)
8. Judging faint detail
9. Accuracy to report

## 1. Classify the photo first
- Real cut-out product photo: usable for colour and shape.
- Catalogue template: several SKUs with identical bbox in px although their specs differ -> CG template, not evidence for shape
  (C16).
- Staged / lifestyle (props, gel splashes, metallic look from lighting): material evidence only if 2+ independent images agree (C43).
- Reference that is another SKU's photo (byte-identical file) -> no evidence for this SKU; mark photo-unverified.
- Phone photos from the user: warm, not colour calibrated; good for shape and finish, not for absolute colour.

## 2. Scale and camera
- Scale from a known part: cap or collar diameter from the parts list, total height, body width. Cross-check with a second dimension;
  two scales agreeing within ~1 % means the photo is usable (RRBM: total height 203 mm and collar 29.0 +- 0.3 mm agreed).
- Close catalogue shots (~0.85 m) magnify the near rim of circles: the base ellipse's front edge drops ~5 mm, the cap top's near rim
  rises. Side silhouettes (wall tangents) stay near-orthographic. Compare in the photo's camera (project model edges with a pinhole at
  (0, -D, h)), estimate h from the base ellipse depth and cross-check with a cap seam curvature (C09, C21). A "3 mm too tall cap" was
  once a camera-elevation illusion.
- Render a dedicated `photo_match` shot from that camera for side-by-side checks.

## 3. Silhouette and feature heights
- Per-row width profile from a mask (photo: non-white; render: alpha) -> half-width in mm (`scripts/silhouette_mm.py`).
- Automatic "widest row" style detectors latch onto the wrong feature (shoulder instead of collar, background gradient as product).
  Prefer **geometric probes**: e.g. collar top = first filled row in a column 13 mm off-centre, which lies outside the overcap
  (R11.3) but inside the collar (R14.5). Pick probe columns from the model's radii.
- Render backgrounds are not white: always use the render's alpha mask.
- Measure the same feature in the current render with the same method; act on the difference (photo - render), not on absolute
  numbers. Applied to 10 catalogue photos the overcap read 27.84-28.10 mm vs model 29.6 -> -1.6 mm.

## 4. Print position
Measure 2+ text rows (top of the first line, baseline of the last line, line spacing) in mm from a physical datum (crimp end, shoulder,
base), in the photo's camera.
- All rows shifted by the same amount, same spacing -> UV offset (shift v, keep scale) (C32, C33).
- Spacing scaled uniformly -> the part's length differs from the artwork height (tube "artwork height = tube length" was wrong on 9 of 9
  tubes, 3-11 mm) -> change length, keep UV relative to the right datum (C44); or the catalogue shows the whole layout compressed
  (~0.89): uniform z scale with UV unchanged (R08).
- Rows move independently -> artwork revision; ask, don't move UVs.

## 5. Colour patches, anchors, white balance
- Sample 4-5 patches at the same relative bbox positions in photo and render, in linear light, away from text, seams, edges and
  highlights (`scripts/photo_patches.py`). Show the patch boxes on the image once - patches on the background or on text gave
  nonsense twice (C30, C36).
- White product on white JPG background: make a cut-out reference first (row-wise extent, longest vertical run, shadow trim) or give
  the bbox by hand (C30).
- Exposure anchor: a neutral part in the same photo session (white cap). If the body/anchor ratio already matches, the remaining
  absolute difference is exposure or the photo session, not the material.
- White balance check: neutral caps B/R ~0.97-0.99 -> photo balanced; then a warm body is real colour. A frosted cap over a coloured
  fill is not neutral.
- Saturated channel (photo R >= 0.94): match G/R and B/R, not absolute G (C51).
- Non-linear response (film veil, backlight glow): bracket two strengths, measure, interpolate per target metric; if one channel barely
  responds, don't chase it with albedo (it turns the gel grey-green) - change the light that causes it.

## 6. Fill lines, eye marks, seal zones
- Gel line: vertical colour profile along the tube centre; strong for coloured gels (yellow: clean step), useless for white-in-white
  (say "not measurable"). Express as mm from the crimp end; the render's value from the contents mesh top.
- Map image rows to physical z for overlays: px/mm from the product box, then draw lines for each zone (rib band end, welded flat
  end from the mesh thickness profile, shader mask boundary, artwork element range, fill top). One overlay explained a defect that
  three paragraphs could not (insp009 zone sheet).
- Artwork element ranges: read them from the texture (alpha + hue mask) with the UV rule (here v = 1 - dz/L, residual 6e-8); never
  from memory.

## 7. Fine patterns
- Pitch/angle by FFT of a seal or flute patch plus 2D autocorrelation (`scripts/texture_period.py`). Elongated patches bias the
  autocorrelation along their long axis - read the diagonal peaks.
- Near Nyquist (2-3 px per period) one direction of a diamond lattice may be unresolved: state the assumption.
- Band width: high-frequency energy (|Laplacian|) per mm from each edge; the band ends where energy drops toward the centre level.
  Perspective inflates a band viewed obliquely - measure on a frontal shot (seal: 7.5 mm frontal vs ~10 mm apparent in a 25 deg macro).

## 8. Judging faint detail
Back print through gels/films, eye marks, emboss, small text: judge at full resolution and with numbers (contrast profile along the
feature, diff image restricted to a box, % of pixels changed > 2 %). Previews are only for gross look and colour loops.

## 9. Accuracy to report
1 px at catalogue scale is ~0.2-0.25 mm; JPG photos +-2 px for edges; perspective model +-0.5 mm; artwork-vs-photo layout +-1 %.
Write the uncertainty next to every number you hand to the modeller.
