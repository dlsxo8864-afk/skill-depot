# Optics and material recipes (values that survived photo comparison)

Values are starting points measured on cosmetics catalogue photos (Cycles, OptiX, Khronos PBR Neutral, exposure 0, neutral rig).
Colours in configs are sRGB-encoded. Each block: what it is for, recipe, why, failure that led to it.

## Contents
1. Studio baseline and family overrides
2. Opaque PP / injection plastics
3. Print and ink modes
4. Thin films (tube laminate, translucent tubes, thin overcaps)
5. Thick translucent walls and caps
6. Clear PET bottle + clear liquid + duplex label
7. Contents: gels, creams, dark gels
8. Chrome / metallised parts
9. Pouches and cartons
10. Fine relief: crimp flutes, seal emboss, turned lines

## 1. Studio baseline and family overrides
- Neutral studio, lights parented to a rig rotated to each camera azimuth: KEY softbox az -42 el 42 (0.735 W), TOP el 82 (0.30 W),
  two 5 cm strips az +-118 el 14 (0.154 W), FILL card az +18 el 8 (0.46 W), BG wash behind; world white 0.12; PBR Neutral, exposure 0.
  Front camera ~250 mm focal at catalogue distance (~0.8 m), el ~4 deg.
- Glossy coloured cylinders: two black flags az +-72, el 6, 0.30 m away (edges go dark like the photo) - C11.
- Clear / translucent products: caustics ON, transmission bounces 12-16, NO black flags (they reflect/refract into clear parts) - C18.
- Light-table photos (translucent bottles, gel tubes glow): BACK_TRANS panel behind the body only (az 180, el 4-6, ~0.12x0.13 m,
  0.45-2.4 W, not glossy), sized to miss the clear cap (a panel behind a clear cap clips it). Tune its power when the body is
  uniformly too bright vs a neutral anchor in the same photo (FJFC005: 1.2 -> 0.6 W) - C23, C35.
- Chrome-dominant products: world 0.4-0.55 + black flag behind the camera + 1-2 white vertical strips - C19, R02.
- Per-SKU overrides must be deep-copied before editing one SKU (shared dicts changed three SKUs once).

## 2. Opaque PP / injection plastics (C03)
Single node group with micro-surface: roughness variation +-0.025-0.035 at 6-16 mm, orange peel 0.4-0.6 um at 0.7-1.1 mm,
mould grain 0.15-0.25 um at 60 um. Matte soft R0.46, gloss colour R0.16, satin white R0.30, inner matte R0.36; white PP SSS
weight ~0.14, radius 0.6 mm. Do not apply PP values to PET, glass, metal, laminate or film.

## 3. Print and ink modes (C04, C05, C14, C15, C36, C38)
- Ink colour is a material socket; the artwork alpha gives glyph shape. Calibrate ink/base ratio on the SAME base in photo vs render
  (exposure independent). Put the measurement box on a spot-colour glyph, never over white ink.
- White ink: fixed [0.95, 0.955, 0.96], ink_calibrate off.
- Count inks first: 1 colour -> single ink; white + spot -> two_tone (split by artwork saturation); 3+ colours or grey logos ->
  texture mode (artwork colours, tint only saturated pixels; set the saturation ramp below the artwork's spot saturation, e.g. 0.03-0.08
  for a 0.16-saturation pouch green, or the tint is only partly applied).
- Tube screen print: glossier than the laminate (R0.16 vs 0.36) with ~12 um relief. Full-bleed gravure under matte varnish
  (pouches, cartons): ink roughness ~0.5, relief 0.
- Small text paler/thinner than the photo while the logo matches: NOT the ink relief (tested 12 -> 4 um at full res: identical text
  contrast). Real screen print spreads (dot gain), so strokes are heavier than the artwork alpha; next test = lower the ink edge
  thresholds (edge_low/high 0.32/0.68 -> e.g. 0.2/0.5) as one variable, judged at full res on a text crop. Untested.

## 4. Thin films (C35, C48, C53, C54, insp009)
- Use thin-film transparency (Transparent BSDF straight-through, weight = thin * (1 - ink alpha)) for laminate/film walls and thin
  overcaps whose interior must show. Refractive transmission on such walls blocks direct light -> grey interiors.
- Translucent PE tube over gel: refractive transmission 0, thin 0.62, SSS 0.5, coat 0.3. Saturated (yellow) gels: thin ~0.80 (the
  38 % diffuse veil makes them lemon-pale). White/cream gels: 0.6.
- The non-transmitted share is diffuse in the base colour = a white veil. Milky clear overcaps: thin 0.95 + mid base colour, colour via
  the transmission tint (saturation 0.54 -> 0.65 = photo) - C53.
- Flat welded seal: two films in optical contact are clearer than the body film -> seal zone thin 0.95. Put the boundary where the
  photo shows it (cover the eye mark + empty headspace), with a smoothstep edge (insp009: clear to 20 mm, smooth 20-26 mm); a hard
  step cut the eye mark in half; making all inner surfaces clear changed 30 % of the body pixels (rejected).
- Crimp flutes on clear tubes must scramble the view: diffuse transmission inside the flute band (0.6-0.85, rib-modulated 0.7), or
  back-side legal text reads through the seal.
- Film tint for a clear tube: measure the 4-surface seal against the background, per-surface tint = (photo/background)^(1/4)/thin.

## 5. Thick translucent walls and caps (C22, C23, C29, C37, C42, C51)
- Translucent plastic bottles: SSS 1.0 (2-4 mm mean free path) + rough transmission 0.15-0.5 (R0.28-0.40) + coat 0.6-0.8. They are
  plastic, never glass-like (user correction). Index-match liquid sides to the wall; keep the liquid top surface at its real IOR.
- Frosted cap whose inside should glow white: refractive transmission 0, thin 0.5-0.55, SSS 0.5, R0.40. Dense coloured frosted caps:
  thin 0.28, SSS 0.6. Coloured glossy collars whose inside is not visible: transmission 0, short SSS, coat 0.8.
- A frosted cap on a coloured fill picks up the fill colour in the photo (FC004/005 caps B/R 0.78-0.84 while white caps are 0.99):
  don't use such a cap as the neutral anchor.

## 6. Clear PET bottle + clear liquid + duplex label (R01)
- The gradient printed on the INSIDE face of the rear label is seen through bottle + liquid. A strictly physical path renders it grey
  (caustics don't converge) and an air layer between liquid and wall kills the colour.
- Working approximation (user approved): wetted inner wall (relative IOR 1.1667), index-matched liquid sides, label optically
  coupled to the PET, clear parts invisible to shadow and diffuse rays, caustics OFF. Side effect: the bottle casts almost no floor
  shadow - show it to the user as an option.
- Never tint the bottle or the liquid to imitate the label colour.

## 7. Contents
- Scattering gel: SSS ~4 mm + transmission 0.35, NOT index-matched (that switches the scattering off).
- Cream (open jars): SSS 100 %, scale 0.3 mm, IOR 1.40, R0.24 +-0.06, ripple 5 um at 1.4 mm.
- Dark thick gel seen through a clear tube: principled volume absorption, density ~250 (scatter ~0), absorption colour light brown
  (sRGB 0.6/0.55/0.4). Density 100 + re-calibration looked fine in a 750 px preview but the back print came back at full res;
  re-calibrating after raising absorption brightens the transmission colour and undoes it (C55).
- Fill height comes from each SKU's photo (gel line in mm from the crimp end) - never a shared assumption (C39, C52).

## 8. Chrome / metallised (C17, C19, R02, R11)
- Mirror metal renders its environment: give it something to reflect (world 0.4-0.55, black flag behind the camera, white strips).
- Lathe chrome parts: sharp edges >30 deg + flat-region normal lock, otherwise smooth-shaded chamfers bend the reflection into a
  barrel / fish-eye look.
- "Too artificial" chrome: roughness 0.045 -> 0.06 with variation 0.025 at scale 150, waviness (peel) 8e-7 at 450, fine turned lines
  (0.05 mm pitch, 0.6 um, noise-jittered phase), rims rounded 0.3 mm (bevel modifier, angle limit 25 deg). No scratches.
  A pure black band is the black flag's reflection - changing it is a lighting decision for the user.

## 9. Pouches and cartons (pass007)
- Sheet-mask pouch: laminate with matte overprint varnish (roughness ~0.5), artwork full-bleed (alpha 1 everywhere) -> texture ink
  mode with a photo tint. Welded seal band ~7.5 mm flat on all four edges; centre = soft irregular film undulation.
- Codex-style pouch meshes may carry a regular ripple (~9 mm, 0.36 mm p-p) -> even stripes; smooth y (Laplacian 60 x 0.5) and add
  seeded soft lumps (9 blobs, sigma 12-30 mm, 0.25 mm), zero at the seals.
- Cartons: paperboard roughness ~0.62, no coat; side panels without artwork take the artwork ground colour x the same tint.

## 10. Fine relief (all as shader relief - too fine for the mesh)
- Tube crimp flutes: pitch 1.0 mm (FFT of 10 photos; 0.6 was wrong), band 0.3 to 6-7.6 mm from the crimp end, depth ~0.18 mm, 2 seam
  grooves below the band.
- Pouch heat-seal emboss: diamond dot lattice, pitch ~0.95 mm at +-35 deg, depth ~0.022 mm, only inside the seal band (smoothstep
  mask on the distance to the outline). Subtle in full shots, readable in a raking-light macro. 0.03 mm read as bubbly blobs.
- Tube top profile: thickness should fall smoothly from body to seal (cubic, end slope ~0.22); a knee (slope 0.54 in the last 20 mm,
  bend within 3 mm) reads as a horizontal moulded band.
