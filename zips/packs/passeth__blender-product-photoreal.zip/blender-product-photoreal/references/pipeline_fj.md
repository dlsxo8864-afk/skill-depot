# PRD_mockup toolkit (FJ pipeline) - use it, don't rebuild it

Root: the PRD_mockup project folder (`<PROJECT_ROOT>`). Claude workspace: `<PROJECT_ROOT>/assets/FRAIJOUR/photoreal/CLAUDE/`.
Blender 5.2 (`C:/Program Files/Blender Foundation/Blender 5.2/blender.exe`), Cycles OptiX + OIDN. Python for analysis:
Blender's bundled `5.2/python/bin/python.exe` (numpy) + ffmpeg/ffprobe on PATH. System `python` is not usable.

## Contents
1. Layout and records
2. fj_run.py
3. Config files (sku_config.json, presets, calibration.json)
4. fj_lookdev material spec keys
5. Geometry refine modules
6. fj_verify.py and allowances
7. Single-variable harness
8. Batch scripts, logs, tool updates
9. Other brands (ROERANCE pattern)

## 1. Layout and records
- Masters (read-only): `assets/<BRAND>/<GROUP>/<SKU>/v001/<SKU>_MASTER_v001.blend` (+ `_open.blend`), `textures/`, `references/`.
- Passes: `photoreal/CLAUDE/passNNN/` = `scripts/make_config.py` -> `scripts/sku_config.json` + `presets/presets_overrides.json`;
  per SKU `<SKU>/` = `renders/`, `preview/`, `masks/`, `calibration.json`, `<SKU>_photoreal_<pass>_<state>.blend`, `metrics_*.json`,
  `verify.json`, `vN_snapshot/` (previous version), `compare/` sheets.
- Records: `status.json` (three-state table `fraijour_45_status`), `handoffs/CODEX_CORRECTIONS_CLAUDE*.txt` (①-⑥ records),
  `handoffs/CLAUDE_INSPECTION_NNN_RESPONSE.txt` (answers to Codex inspections), memory notes.
- Shared code: `tools/` (fj_run, fj_verify, refine_*, fj_pouch, measurement helpers) and `pass001/presets/fj_lookdev.py` +
  `presets.json` (base). Frozen toolkit snapshot: `lib/v1.1` (do not edit). Previous tool versions: `tools/_prev/`, `presets/_prev/`.

## 2. fj_run.py
```
blender -b --factory-startup [--python-expr "<sys.path inserts for brand scripts>"] --python tools/fj_run.py -- \
  --pass <passNNN | assets/<BRAND>/photoreal/CLAUDE/passNNN | test pass path> --sku <SKU> \
  --mode render|calibrate|geometry --state closed|open [--preview] [--only shot1,shot2] [--variant before] [--iterations 3]
```
- `render`: build (open master, rename old FJ_ node groups, drop non-product objects, geometry refine, cap pose, cleanup caps,
  materials, studio), render shots (+alpha masks), metrics, save blend. `--preview` = 750x1000, 128 spp, no blend save.
- `calibrate`: closed-loop body/cap/ink colours vs photo patches -> `calibration.json` (only roles it calibrates).
- `geometry`: build only (for probes). `--variant before`: master geometry (refine module's `before_variant` hook only).
- `--only` filters the SKU's shot order; a shot not in the order is silently skipped (add it to `shot_order`).
- Pass path containing `/` is project-relative, otherwise relative to `photoreal/CLAUDE/`.

## 3. Config files
sku_config.json entry (per SKU): `family, collection, root, body, cap, closed_src, open_src, closed_from_open, label_u, logo_u,
photo, photo_mask ('nonwhite'), photo_bbox, resolution [1800,2400], open_stage ('as_is' | 'tube_lying' | staged), ink_role,
cap_open {az,gap,flip}, photo_patches {cap, body[], ink{uv_box}}, materials {<master material name>: spec}, shot_order,
presets_override (deep-merged into presets: studio lights/flags/world, render, materials), geometry_refine {module, function,
params, evidence}, body_reference 'series_white' + photo_white_lin/render_white_lin, label_az_deg + label_pt_mm (flat products),
verify_states ['closed'] (products without an open state)`.
- `cap` is required; closure-less products use `tools/fj_pouch.py` (`no_closure` / `refine_pouch`) to add an empty stand-in.
- Shots (presets 'shots'): front, hero34, detail_print, detail_curve, open_hero, open_cream + generic shots with
  `target: label | axis:<frac> | object:<name> | product | point_mm:x,y,z` and `type: width|fill`, per-shot `light_scale`.
- calibration.json `colors` override material specs at build time; keep `manual_steps` notes and back up before editing.
- make_config.py regenerates the whole pass: after each run diff against a backup and confirm only intended SKUs changed.

## 4. fj_lookdev material spec keys
`role, preset, color (sRGB), color_from <role>, ink (ink preset), ink_color, ink_mode (two_tone | texture), ink_white, ink_tint,
ink_tint_sat [lo,hi], ink_image (corrected raster, same UV), ink_calibrate, ink_translucency, thin_tint, index_match_sides,
volume_color, absorption_color` and relief options (one per material, they all drive 'Relief Height'):
- `crimp_flutes {length_mm, band_mm, period_mm, depth_mm, seams_mm, seam_depth_mm, seam_width_mm, diffuse_transmission,
  diffuse_rib_contrast, seal_clear_mm, seal_thin, seal_soft_mm}`
- `seal_emboss {half_w_mm, z0_mm, z1_mm, seal_mm, soft_mm, pitch_mm, angle_deg, depth_mm, dot}`
- `micro_lines {pitch_mm, depth_mm, jitter, jitter_scale, axis}`
Preset keys (presets 'materials'): roughness, rough_var(_scale), peel_height/scale, grain_height/scale, ior, specular, coat,
coat_roughness, sss_weight/radius/scale, metallic, transmission, thin_transparency, volume_density, volume_anisotropy;
ink presets: ink_roughness, ink_opacity, ink_thickness, edge_low, edge_high, ink_metallic.
New options are added default-off so existing passes render identically.

## 5. Geometry refine modules (all keep vertex count/order; UV unchanged unless noted)
- `refine_tube`: uv_shift_mm (+tube_length_mm), crimp_trim_mm (UV remapped by the master v(z) table), length_mm (uniform z, UV kept),
  top_profile {seal_flat_mm, blend_from_mm, end_slope} (y-only), fill_to_seal {min_half_mm, blend_mm}, fill_top_mm, flipcap_detail
  {D,H,seam_mm,half_mm,arch_mm,segments,open_deg,open_raise_mm}, cap_recess, herb_fragments.
- `fj_pouch.refine_pouch`: surface {smooth_iter, smooth_lambda, fixed_mm, seal_flat {outline, seal_mm, ramp_mm}, lumps {...}}.
- Lathe remaps: refine_round50 (superellipse dome), refine_cham100, refine_toner500 (profile + UV rule), refine_ampoule045,
  refine_pump_d30 (new head; old parts hidden + superseded).
- ROERANCE: `pass001/scripts/rr_optics.py` (optics B + lathe cleanup), `pass002/scripts/rr_neck.py` (optics + overcap lower,
  pump base clearance, collar bevel, diag_hide_overcap for diagnosis only).
Tag every changed object (`fj_geometry_refine`, `fj_replacement`, `fj_superseded`, `fj_uv_shift`, `fj_uv_remap`, `fj_uv_rule`,
`fj_open_pose`, `fj_refine_shift`) or verify will call it unexpected.

## 6. fj_verify.py
`blender -b --factory-startup [--python-expr ...] --python tools/fj_verify.py -- --pass <pass> SKU1 SKU2 ...` -> `<pass>/<SKU>/verify.json`.
Reopens master and saved copy per state, fingerprints the product collection (verts, geo/UV hashes, loc/rot/scale, packing) and
classifies differences: ALLOWED documented profile edit (verts kept, UVs identical), print shift (uniform dv), UV remap / UV rule
(error thresholds), replacement, superseded, surface cleanup (shape deviation < 5 um), cap staging/open pose; everything else
UNEXPECTED. Any SKU present in the pass config is verified (the old 'FJ*' prefix filter skipped ROERANCE).

## 7. Single-variable harness
`photoreal/CLAUDE/insp009_tests/run_variants.py variants.json` (bundled python). Each variant:
`{sku, name, shots, full?, sku_patch{}, preset_patch{}, calibration_patch{}, _variable}` -> copies the pass006 config, deep-merges one
patch, renders into `<harness>/<SKU>/<name>/` with `variant.json`. For other passes copy the harness and point it at that pass, or
build `tests/<name>/` pass folders with a generator script (pass007/tests, ROERANCE pass001/tests, pass002/tests).
Measurement helpers in the project: `insp009_tests/mark_profile.py` (contrast along a printed mark), `pass007/scripts/patch_measure.py`
(tint loop), `ROERANCE .../scripts/rr_photo_measure.py`, `rr_patch_compare.py`.

## 8. Batch scripts, logs, tool updates
Batch script pattern (bash, background):
```
f(){ grep -E "\[FJ\]|Error|Traceback|line [0-9]+" | cut -c1-260 >> "$LOG"; }
until grep -q <PREVIOUS_DONE_MARKER> "$LOG"; do sleep 60; done   # chain behind the job that must finish first
snapshot previous outputs into <SKU>/vN_snapshot (cp -n: never overwrite an existing snapshot)
for st in closed open; do blender ... fj_run.py ... --mode render --state $st | f; done
blender ... fj_verify.py ... | f
echo <DONE_MARKER> >> "$LOG"
```
- The log only shows a SKU's lines when its Blender process exits; check render file times for progress.
- Tool update protocol: `cp tool.py _tool_new.py` -> edit -> `py_compile` -> quick test -> `cp -p tool.py _prev/tool_before_<change>.py`
  -> `mv _tool_new.py tool.py`. Every Blender launch re-reads tools and configs.
- Never edit a running .sh; never stop other people's Blender PIDs; a session restart can drop task handles while processes run.

## 9. Other brands (ROERANCE pattern)
External pass: `--pass assets/ROERANCE/photoreal/CLAUDE/passNNN`, brand hooks on sys.path via `--python-expr`. New versions as new
passes (pass002 = pass001 + only the user-requested changes); keep the previous pass untouched as "before".
