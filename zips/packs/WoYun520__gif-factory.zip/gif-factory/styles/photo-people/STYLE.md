# 真人轻动效

[返回风格库](../README.md) · [查看原尺寸案例](../../examples/public-figures-hd/001.gif)

## 动态案例 · 4 张

<table>
<tr>
<td width="33%" valign="top"><a href="../../examples/public-figures-hd/001.gif"><img src="../../docs/previews/photo-people.gif" alt="马斯克" height="180"></a><br>马斯克</td>
<td width="33%" valign="top"><a href="../../examples/public-figures-hd/002.gif"><img src="../../docs/previews/photo-people-02.gif" alt="Tibo" height="180"></a><br>Tibo</td>
<td width="33%" valign="top"><a href="../../examples/public-figures-hd/003.gif"><img src="../../docs/previews/photo-people-03.gif" alt="Dario Amodei" height="180"></a><br>Dario Amodei</td>
</tr>
<tr>
<td width="33%" valign="top"><a href="../../examples/public-figures-hd/004.gif"><img src="../../docs/previews/photo-people-04.gif" alt="黄仁勋" height="180"></a><br>黄仁勋</td>
</tr>
</table>

## 长什么样

人物长相和照片质感保留，优先清楚的半身形象。

## 怎么动

单个表情或手势配小幅点头、回弹、摇摆，文案固定。

适合：人物反应、个人聊天表情。当前参考尺寸与节奏：512×512，通常约 2 秒。这些是该系列默认值，用户指定尺寸或时长时按请求处理。

## 制作入口

先沿用已认可的角色、画风与动作。阅读[外观与素材要求](../../references/appearance.md#photographic)和[实际制作流程](../../references/light-motion.md)；不要套用另一种画风或用途的导出默认值。

不要自动加美颜；已弃用的比耶自拍方案不是默认模板。轻动效不等于连续演技。

新角色、新动作先做小样；技术检查和用户认可分开记录。高清不等于动作完整，关键状态切换也不等于持续表演。

## 可以直接这样说

> 用这张人物照片做一张真人轻动效 GIF，保留长相和衣服，不加美颜，轻轻点头，文字是“收到”。

## 案例与交付

[现有案例与版本记录](../../GALLERY.md#表情包展厅)。独立 GIF 是最终交付，缩小预览不替代原尺寸文件。检查解码后的实际时长、循环接缝、人物与文字；批量总览按 GIF 的真实帧延时采样。
