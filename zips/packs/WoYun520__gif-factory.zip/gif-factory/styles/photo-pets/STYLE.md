# 宠物拟人

[返回风格库](../README.md) · [查看原尺寸案例](../../examples/pet-corgi/01-fun-and-work/001.gif)

## 动态案例 · 8 张

<table>
<tr>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/01-fun-and-work/001.gif"><img src="../../docs/previews/photo-pets.gif" alt="柯基·整活1" height="180"></a><br>柯基·整活1</td>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/01-fun-and-work/002.gif"><img src="../../docs/previews/photo-pets-02.gif" alt="柯基·整活2" height="180"></a><br>柯基·整活2</td>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/01-fun-and-work/003.gif"><img src="../../docs/previews/photo-pets-03.gif" alt="柯基·整活3" height="180"></a><br>柯基·整活3</td>
</tr>
<tr>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/01-fun-and-work/004.gif"><img src="../../docs/previews/photo-pets-04.gif" alt="柯基·整活4" height="180"></a><br>柯基·整活4</td>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/02-food-and-life/001.gif"><img src="../../docs/previews/photo-pets-05.gif" alt="柯基·生活1" height="180"></a><br>柯基·生活1</td>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/02-food-and-life/002.gif"><img src="../../docs/previews/photo-pets-06.gif" alt="柯基·生活2" height="180"></a><br>柯基·生活2</td>
</tr>
<tr>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/02-food-and-life/003.gif"><img src="../../docs/previews/photo-pets-07.gif" alt="柯基·生活3" height="180"></a><br>柯基·生活3</td>
<td width="33%" valign="top"><a href="../../examples/pet-corgi/02-food-and-life/004.gif"><img src="../../docs/previews/photo-pets-08.gif" alt="柯基·生活4" height="180"></a><br>柯基·生活4</td>
</tr>
</table>

## 长什么样

写实毛发与宠物面部特征，搭配服装、道具或拟人姿态。

## 怎么动

不同姿势各做轻动效，可加小符号和固定文案。

适合：宠物聊天表情、趣味反应。当前参考尺寸与节奏：512×512，通常约 2 秒。这些是该系列默认值，用户指定尺寸或时长时按请求处理。

## 制作入口

先沿用已认可的角色、画风与动作。阅读[外观与素材要求](../../references/appearance.md#photographic)和[实际制作流程](../../references/light-motion.md)；不要套用另一种画风或用途的导出默认值。

这套是写实拟人小样，不承诺任意宠物照片或所有大动作都稳定。

新角色、新动作先做小样；技术检查和用户认可分开记录。高清不等于动作完整，关键状态切换也不等于持续表演。

## 可以直接这样说

> 保留这只宠物的花纹和长相，做一张上班摸鱼的拟人 GIF，配道具和轻动效，先给一张小样。

## 案例与交付

[现有案例与版本记录](../../GALLERY.md#表情包展厅)。独立 GIF 是最终交付，缩小预览不替代原尺寸文件。检查解码后的实际时长、循环接缝、人物与文字；批量总览按 GIF 的真实帧延时采样。
