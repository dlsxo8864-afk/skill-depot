#!/usr/bin/env node
/*
 * export_gif.js — turn CSS-animated Clawd emote cards into seamless looping GIFs.
 *
 * The trick: instead of capturing in real time (which produces jittery,
 * non-looping GIFs), we drive the page over CDP, then for each frame we PAUSE
 * every CSS animation and set its `currentTime` deterministically via
 *   document.getAnimations().forEach(a => { a.pause(); a.currentTime = t; })
 * and screenshot the <svg>. Stepping currentTime from 0 to the loop period in
 * equal increments yields a perfectly seamless loop. Frames are then encoded by
 * ffmpeg with palettegen/paletteuse for crisp, banding-free pixel colors.
 *
 * Usage:
 *   node export_gif.js <page.html> <out-dir> [--fps 20] [--size 240] [--scale 2]
 *                      [--period 2600]   (default per-card loop length in ms)
 *
 * Per-card loop period: by default every card uses --period ms. To tune
 * individual cards (so the loop cuts on a natural beat), edit PERIODS below,
 * keyed by card index. A good period is the LCM-ish of the card's animation
 * durations, or just the hero-motion duration.
 *
 * Requirements:
 *   - Node + puppeteer-core:   npm i puppeteer-core
 *   - A Chrome binary. Set CHROME=/path/to/chrome, or it tries the puppeteer
 *     cache and common locations.
 *   - ffmpeg on PATH.
 *
 * Each card must expose its animation in one <svg>; the script screenshots the
 * Nth <svg> on the page for the Nth GIF. Output: <out-dir>/clawd-<N>.gif (or use
 * the card's data-name attribute if present: <div class="card" data-name="coffee">).
 */
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");

// ---- per-card overrides (index -> loop period in ms). Edit as needed. -------
const PERIODS = {
  // 0: 3400,  // e.g. coffee sip cycle
};

function arg(flag, def) {
  const i = process.argv.indexOf(flag);
  return i >= 0 ? process.argv[i + 1] : def;
}

function findChrome() {
  if (process.env.CHROME && fs.existsSync(process.env.CHROME)) return process.env.CHROME;
  const home = os.homedir();
  const globs = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser",
  ];
  for (const g of globs) if (fs.existsSync(g)) return g;
  // puppeteer cache
  const base = path.join(home, ".cache/puppeteer/chrome");
  if (fs.existsSync(base)) {
    for (const ver of fs.readdirSync(base)) {
      for (const name of ["Google Chrome for Testing", "chrome"]) {
        const hits = require("child_process")
          .execSync(`find "${path.join(base, ver)}" -name "${name}" -type f 2>/dev/null || true`)
          .toString().trim().split("\n").filter(Boolean);
        if (hits.length) return hits[0];
      }
    }
  }
  return null;
}

async function main() {
  const htmlPath = process.argv[2];
  const outDir = process.argv[3];
  if (!htmlPath || !outDir) {
    console.error("usage: node export_gif.js <page.html> <out-dir> [--fps 20] [--size 240] [--scale 2] [--period 2600]");
    process.exit(1);
  }
  const fps = parseInt(arg("--fps", "20"), 10);
  const size = parseInt(arg("--size", "240"), 10);
  const scale = parseFloat(arg("--scale", "2"));
  const defPeriod = parseInt(arg("--period", "2600"), 10);

  const chrome = findChrome();
  if (!chrome) { console.error("No Chrome found; set CHROME=/path/to/chrome"); process.exit(2); }
  let puppeteer;
  try { puppeteer = require("puppeteer-core"); }
  catch { console.error("Missing puppeteer-core. Run: npm i puppeteer-core"); process.exit(2); }

  fs.mkdirSync(outDir, { recursive: true });
  const url = "file://" + path.resolve(htmlPath);
  const browser = await puppeteer.launch({
    executablePath: chrome, headless: "new",
    args: ["--no-sandbox", "--force-device-scale-factor=" + scale],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 1400, height: 1000, deviceScaleFactor: scale });
  await page.goto(url, { waitUntil: "networkidle0" });

  const svgs = await page.$$("svg");
  const names = await page.$$eval(".card", els =>
    els.map(e => e.getAttribute("data-name")));
  console.log(`found ${svgs.length} svg(s)`);

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "clawd-gif-"));

  for (let i = 0; i < svgs.length; i++) {
    const period = PERIODS[i] || defPeriod;
    const nFrames = Math.max(2, Math.round((period / 1000) * fps));
    const frameDir = path.join(tmp, "f" + i);
    fs.mkdirSync(frameDir, { recursive: true });

    for (let f = 0; f < nFrames; f++) {
      const t = (period * f) / nFrames; // ms into the loop
      await page.evaluate((tms) => {
        document.getAnimations().forEach(a => { a.pause(); a.currentTime = tms; });
      }, t);
      const fp = path.join(frameDir, String(f).padStart(4, "0") + ".png");
      await svgs[i].screenshot({ path: fp, omitBackground: false });
    }

    const name = (names[i] || ("clawd-" + i)).replace(/[^\w.-]/g, "_");
    const gifPath = path.join(outDir, name + ".gif");
    const palette = path.join(frameDir, "palette.png");
    const vf = `fps=${fps},scale=${size}:${size}:flags=neighbor`;
    execFileSync("ffmpeg", ["-y", "-i", path.join(frameDir, "%04d.png"),
      "-vf", vf + ",palettegen=stats_mode=full", palette],
      { stdio: "ignore" });
    execFileSync("ffmpeg", ["-y", "-framerate", String(fps),
      "-i", path.join(frameDir, "%04d.png"), "-i", palette,
      "-lavfi", vf + "[x];[x][1:v]paletteuse=dither=bayer",
      "-loop", "0", gifPath], { stdio: "ignore" });
    console.log(`  ${gifPath}  (${nFrames} frames @ ${fps}fps)`);
  }

  await browser.close();
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log("done.");
}

main().catch(e => { console.error(e); process.exit(1); });
