// Generalized transparent-GIF exporter for any Clawd catalog page.
// Usage: node export_transparent_any.js <page.html> <out-dir>
// Names each GIF clawd-<tag>.gif (English .tag text), period = the card's
// longest CSS animation cycle (so the dominant motion loops cleanly).
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFileSync } = require("child_process");
const puppeteer = require("puppeteer-core");

const SRC = "file://" + path.resolve(process.argv[2]);
const OUT = path.resolve(process.argv[3]);
const CHROME = process.env.CHROME ||
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const FPS = 20, SIZE = 240, DPR = 2;

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await puppeteer.launch({
    executablePath: CHROME, headless: "new",
    args: ["--no-sandbox", "--force-device-scale-factor=" + DPR],
  });
  const page = await browser.newPage();
  await page.setViewport({ width: 900, height: 900, deviceScaleFactor: DPR });
  await page.goto(SRC, { waitUntil: "networkidle0" });
  await page.evaluate(() => {
    document.documentElement.style.background = "transparent";
    document.body.style.background = "transparent";
    document.querySelectorAll(".card,.card-view").forEach(e => { e.style.background = "transparent"; });
  });
  const tags = await page.$$eval(".card .tag", els => els.map(e => e.textContent.trim().toLowerCase().replace(/\s+/g, "-")));
  const svgs = await page.$$("svg");
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "clawd-tra-"));

  for (let i = 0; i < svgs.length; i++) {
    const dur = await page.evaluate((idx) => {
      const svg = document.querySelectorAll("svg")[idx];
      let m = 0;
      for (const a of svg.getAnimations({ subtree: true })) {
        const d = a.effect.getComputedTiming().duration;
        if (isFinite(d)) m = Math.max(m, d);
      }
      return m; // ms
    }, i);
    const period = Math.max(1400, Math.ceil(dur));
    const nFrames = Math.max(2, Math.round((period / 1000) * FPS));
    const name = "clawd-" + (tags[i] || ("emote-" + i));
    const fdir = path.join(tmp, name);
    fs.mkdirSync(fdir, { recursive: true });
    for (let f = 0; f < nFrames; f++) {
      const t = (period * f) / nFrames;
      await page.evaluate((tms) => {
        document.getAnimations().forEach(a => { a.pause(); a.currentTime = tms; });
      }, t);
      await svgs[i].screenshot({ path: path.join(fdir, String(f).padStart(4, "0") + ".png"), omitBackground: true });
    }
    const palette = path.join(fdir, "pal.png");
    const sc = `scale=${SIZE}:${SIZE}:flags=neighbor`;
    execFileSync("ffmpeg", ["-y", "-i", path.join(fdir, "%04d.png"),
      "-vf", `${sc},palettegen=reserve_transparent=1:stats_mode=full`, palette], { stdio: "ignore" });
    execFileSync("ffmpeg", ["-y", "-framerate", String(FPS),
      "-i", path.join(fdir, "%04d.png"), "-i", palette,
      "-lavfi", `${sc}[x];[x][1:v]paletteuse=alpha_threshold=128`, "-loop", "0",
      path.join(OUT, name + ".gif")], { stdio: "ignore" });
    console.log(`  ${name}.gif  (period ${period}ms, ${nFrames} frames)`);
  }
  await browser.close();
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log("done ->", OUT);
})();
