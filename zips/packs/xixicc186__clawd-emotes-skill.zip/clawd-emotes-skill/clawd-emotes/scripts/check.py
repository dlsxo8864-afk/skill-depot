#!/usr/bin/env python3
"""
check.py — validate and visually render a Clawd emote catalog page.

Why this exists: pixel-art SVG "lies" in the source — a hat can look attached in
the code but float in the render, feet can detach, a prop can drift off the hand.
The only reliable check is to LOOK at a real browser render. This script does
that headlessly so you never need a flaky live server or browser extension.

What it does:
  1. Well-formedness check on every <svg> block (catches missing spaces between
     attributes like  style="..."x="..."  , unescaped & / < , bad hex, etc.).
  2. Renders the page with a headless Chrome and saves a full screenshot plus
     one crop per card under /tmp/clawd-check/.

Usage:
    python3 check.py path/to/clawd-page.html [--cols N] [--rows N]

Then READ the crops in /tmp/clawd-check/ and check each crab against the five
rules in SKILL.md: hat on head? feet attached? prop connected to hand? face
readable? particles sensible?

Requirements: Python 3, Pillow (pip install pillow), and a Chrome/Chromium
binary. The script searches common locations (incl. the puppeteer cache) and
honors the CHROME env var if set.
"""
import os
import re
import sys
import glob
import shutil
import subprocess
import xml.dom.minidom
from pathlib import Path

OUT = Path("/tmp/clawd-check")


def find_chrome():
    if os.environ.get("CHROME") and Path(os.environ["CHROME"]).exists():
        return os.environ["CHROME"]
    candidates = [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        "/usr/bin/google-chrome",
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
    ]
    # puppeteer's cached "Chrome for Testing" (any version)
    home = str(Path.home())
    candidates += sorted(glob.glob(
        home + "/.cache/puppeteer/chrome/*/chrome-*/**/Google Chrome for Testing",
        recursive=True))
    candidates += sorted(glob.glob(
        home + "/.cache/puppeteer/chrome/*/chrome-*/**/chrome", recursive=True))
    for c in candidates:
        if Path(c).exists():
            return c
    return None


def validate(html_path):
    html = Path(html_path).read_text(encoding="utf-8")
    svgs = re.findall(r"<svg.*?</svg>", html, re.S)
    print(f"found {len(svgs)} <svg> block(s)")
    bad = 0
    for i, s in enumerate(svgs):
        try:
            xml.dom.minidom.parseString(s)
        except Exception as e:
            bad += 1
            print(f"  SVG #{i}: NOT well-formed -> {e}")
    if bad == 0:
        print("  all SVGs well-formed ✓")
    return bad == 0


def render(html_path, chrome, cols, rows):
    OUT.mkdir(parents=True, exist_ok=True)
    full = OUT / "full.png"
    url = Path(html_path).resolve().as_uri()
    win_w, win_h = 1400, max(700, 240 * rows + 220)
    cmd = [
        chrome, "--headless=new", "--disable-gpu", "--hide-scrollbars",
        "--force-device-scale-factor=2",
        f"--window-size={win_w},{win_h}",
        f"--screenshot={full}", url,
    ]
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if not full.exists():
        print("ERROR: render failed (no screenshot produced)")
        return
    print(f"full render -> {full}")
    try:
        from PIL import Image
    except ImportError:
        print("(install Pillow for per-card crops: pip install pillow)")
        return
    im = Image.open(full)
    W, H = im.size
    # crop the card grid into a cols×rows mosaic (approximate; the grid starts
    # ~13% down the page in the standard template).
    top, bottom = 0.12, 0.99
    gh = (bottom - top) / rows
    gw = 1.0 / cols
    n = 0
    for r in range(rows):
        for c in range(cols):
            box = (int(W * c * gw), int(H * (top + r * gh)),
                   int(W * (c + 1) * gw), int(H * (top + (r + 1) * gh)))
            im.crop(box).save(OUT / f"card_{n}.png")
            n += 1
    print(f"saved {n} card crops -> {OUT}/card_*.png  (now READ them)")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        sys.exit(1)
    html_path = args[0]

    def opt(name, default):
        if name in sys.argv:
            return int(sys.argv[sys.argv.index(name) + 1])
        return default
    cols = opt("--cols", 4)
    rows = opt("--rows", 3)

    ok = validate(html_path)
    chrome = find_chrome()
    if not chrome:
        print("No Chrome found. Set CHROME=/path/to/chrome and retry.")
        sys.exit(0 if ok else 2)
    print(f"using chrome: {chrome}")
    render(html_path, chrome, cols, rows)


if __name__ == "__main__":
    main()
