# Prop & hat recipes

A catalog of emotes already built, grouped by the *technique* they use. When you
need a new emote, find the closest technique here and adapt it — don't
re-derive. Coordinates assume the base crab from `anatomy.md`.

## Technique A — held prop in front (foreground), idle hands

The prop is drawn **last** (in front of the body) and the two arms are rotated
inward to "cup" it. Good for objects rested against the chest.

- **Coffee mug** (`cf-`): ceramic `<rect>` x4 y10.4 w7 h3.6, coffee `<ellipse>`
  at the rim, a `q`-curve handle, steam particles above the rim. Hero motion:
  `cf-sip` tilts the whole body back ~7° periodically. Arms rotated ±40° to hold.
- **Rice bowl + chopsticks** (`et-`): bowl as two `<path>` (body + rim) + an
  `<ellipse>` of rice; steam. The left arm props the bowl. See Technique C for
  the chopstick arm.
- **Open book** (`rd-` reading): two page `<path>`s; eyes scan; pages flip.

## Technique B — floating screen the crab faces

A monitor/screen sits **above** the crab on a little stand; a subtle colored
`<rect>` tints the face as "screen glow." The crab's hands hold a controller or
keyboard in front. Reads instantly as "watching/using a screen."

- **Gaming** (`gm-`): monitor frame + inner screen + a tiny game scene (hero
  rect that hops, enemy rect that strafes, coin, ground) + a stand. Controller
  held in front; `gm-glow` flickers on the face.
- **Coding** (`cd-`): a clamshell **laptop in front** (screen faces us) showing
  colored code-line rects + a blinking cursor (`steps(1)` animation). Place the
  laptop's top edge at ~y9.9 so the **eyes peek over** it — that "focused" look
  is the whole charm. Screen-glow tint on the forehead.

Keynote: keep the eyes visible above any screen unless the prop is meant to
cover the face.

## Technique C — tool on a rotating arm (the prop sweeps with the hand)

The prop is nested **inside** the right-arm `<g>`, which pivots at the shoulder
(13,10). The arm's keyframe animation swings the tool. **Keep the angle small
when the tool is long** (see SKILL.md rule 4).

- **Chopsticks feeding** (`et-`): two thin `<rect>` chopsticks + a food morsel,
  nested in the arm, tilted ~−7° so they reach toward the mouth. Feeding =
  `et-feed` gentle −13°→3° dip-and-raise. (The original far-from-pivot −52°→24°
  version detached visually — anchor to the hand, soften the swing.)
- **Paintbrush** (`pt-`): brush handle + a colored bristle `<polygon>` nested in
  the arm; `pt-dab` rotates −32°→−6°. Palette (Technique D) in the other hand.
- **Watering can** (`wt-`): can body + spout (`<path>`) + handle, nested in the
  arm; `wt-tip` tilts −4°→−16°. **Align the spout over the target** — the plant
  must sit directly under the spout with water particles falling onto it, or it
  looks like watering empty air. Keep the flower below eye level so the face
  stays clear.
- **Guitar strum** (`gt-`): the strumming hand is a small `<rect>` in a
  `gt-strum` group over the sound hole, oscillating ±~11°.
- **Microphone** (`sg-` singing): mic nested in a raised right arm reaching to an
  open singing mouth; music notes float.
- **Dumbbell curls** (`ex-` exercise): a dumbbell nested in *each* arm group;
  both curl. Sweatband on the head, sweat-drop particles, a squat bob.
- **Sponge scrub** (`sh-` shower): sponge nested in the arm; `sh-scrub` fast
  rotate-alternate. Shower head + falling water + foam on head + rubber duck.

## Technique D — prop in a static raised/held hand

The prop is held but not swinging — drawn next to a repositioned arm.

- **Palette** (`pt-`): kidney `<ellipse>` + paint-dab `<circle>`s + a thumb-hole
  ellipse, beside the left arm.
- **Camera** (`ph-` photo): camera body covers the upper face (eyes hidden — OK
  here), lens `<circle>`s with a glass highlight, a flash rect that blinks white,
  a flash-burst `<polygon>` star that pops. Both arms grip the sides. Add a tiny
  smile below the camera so there's still expression.

## Technique E — particles only, no held prop (mood/ambient)

- **Listening to music** (`lm-`): headphones (band `<path>` + ear-cup rects) on
  the head; music notes float up.
- **Sleeping** (`sl-`): nightcap (band + droopy `<polygon>` + pom `<circle>`),
  closed-eye `<rect>`s, a nose `sl-bubble` that inflates, `ZZZ` `<text>` rising,
  slow breathe. Add a **bed**: a frame `<rect>` + pillow behind the crab + a
  blanket `<path>` drawn *over* the lower body (foreground). Convert the ground
  shadow to a soft `<ellipse>` under the bed.

## Headwear catalog (all sit with the brim on torso-top y≈6)

- **Birthday party hat** (`bd-`): cone `<polygon>` + tier stripes + pom on top.
- **Santa hat** (`xm-`): red cap `<path>`, white trim `<rect>` at y≈4.6, pom.
- **Witch hat** (`hw-`): cone `<polygon>` apex high in negative y, brim `<rect>`
  at y≈4.5, band.
- **Nightcap** (`sl-`): band `<rect>` y≈4.8 + droopy `<polygon>` + white pom.

If you add a hat and see a gap above the head in the render, the brim isn't
reaching y≈6 — push the hat down (see anatomy.md "Hats").

## Building a whole catalog page

The existing pages each hold one themed set as a responsive grid of cards:
- **Festivals** (10): birthday, spring, mid-autumn, dragon-boat, christmas,
  halloween, new-year, lantern, valentine, qixi.
- **Daily life** (8): listening, gaming, singing, reading, eating, exercise,
  shower, sleeping.
- **Hobbies** (6): coffee, painting, photo, watering, guitar, coding.

Give each card a themed color via the `--glow/--bd/--bg/--tagbg/--tagfg`
variables (anatomy.md), a Chinese name + emoji + a one-line description + a tag.
