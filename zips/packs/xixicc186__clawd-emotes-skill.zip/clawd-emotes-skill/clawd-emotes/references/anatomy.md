# Clawd anatomy — the coordinate bible

Everything below uses one coordinate system. Get this right and the rest is
decoration.

## Canvas

```html
<svg xmlns="http://www.w3.org/2000/svg" viewBox="-15 -25 45 45"> ... </svg>
```

- `viewBox="-15 -25 45 45"` → x runs -15…30, y runs -25…20. The crab sits near
  the middle; the generous margins leave room for tall hats (negative y) and
  props/water below (positive y).
- Rendered at `width:150px; height:150px` in the card. So one SVG unit ≈ 3.3 px.
- Color palette: crab body `#DE886D`; eyes/pupils `#000`; mouth `#7a2230`;
  ground shadow `#000` at `opacity:.5`. Props use their own colors.

## The base crab (paste this, then theme the prefix)

Replace `XX` with a unique 2-letter prefix per emote (see rule 5 in SKILL.md).

```html
<!-- shadow: SEPARATE, stays on the ground -->
<rect class="XX-shad" x="3" y="15" width="9" height="1" fill="#000" opacity=".5"/>
<g class="XX-body">
  <!-- feet: INSIDE the body group so they never detach -->
  <g fill="#DE886D">
    <rect x="3" y="13" width="1" height="2"/><rect x="5" y="13" width="1" height="2"/>
    <rect x="9" y="13" width="1" height="2"/><rect x="11" y="13" width="1" height="2"/>
  </g>
  <!-- torso -->
  <rect x="2" y="6" width="11" height="7" fill="#DE886D"/>
  <!-- arms (left / right). Move/rotate these for "holding" poses -->
  <rect x="0"  y="9" width="2" height="2" fill="#DE886D"/>
  <rect x="13" y="9" width="2" height="2" fill="#DE886D"/>
  <!-- eyes -->
  <g class="XX-eye" fill="#000">
    <rect x="4" y="8" width="1" height="2"/><rect x="10" y="8" width="1" height="2"/>
  </g>
  <!-- optional mouth -->
  <rect x="6.4" y="10.8" width="2.2" height="1" rx=".5" fill="#7a2230"/>
</g>
```

### Landmark coordinates

| Part        | Box (x, y, w, h)        | Notes |
|-------------|-------------------------|-------|
| Torso       | 2, 6, 11, 7             | top edge **y=6** (hat brim target), bottom y=13 |
| Feet (×4)   | x∈{3,5,9,11}, y=13, 1×2 | bottom y=15; inside body group |
| Shadow      | 3, 15, 9, 1             | separate, on the ground |
| Left eye    | 4, 8, 1, 2              | |
| Right eye   | 10, 8, 1, 2             | |
| Left arm    | 0, 9, 2, 2              | shoulder pivot ≈ (2,10) |
| Right arm   | 13, 9, 2, 2             | shoulder pivot ≈ (13,10) |
| Mouth       | 6.4, 10.8, 2.2, 1       | optional; widen/open for singing/eating |
| Head center | (7.5, 9)                | eye-group pivot |
| Body center | (7.5, 13)               | body pivot (feet line) |

## Transform-origins (memorize — wrong pivot = parts fly off)

```css
.XX-body { transform-origin: 7.5px 13px; }   /* rock/bob from the feet */
.XX-shad { transform-origin: 7.5px 15.5px; } /* scale the shadow on the ground */
.XX-eye  { transform-origin: 7.5px 9px; }    /* blink = scaleY about eye line */
.XX-larm { transform-origin: 2px 10px; }     /* left shoulder */
.XX-rarm { transform-origin: 13px 10px; }    /* right shoulder */
.XX-hat  { transform-origin: 7.5px 6px; }    /* hat wobbles from torso-top contact */
```

When you nest a prop inside a rotating arm, the prop inherits the arm's
`transform-origin` (the shoulder). That's usually what you want — the whole
forearm-plus-prop swings as one rigid unit and stays attached to the hand.

## Standard idle animations (give every crab some life)

```css
@keyframes XX-bob    {0%,100%{transform:translateY(0);}      50%{transform:translateY(-.4px);}}
@keyframes XX-shadow {0%,100%{transform:scaleX(1);opacity:.5;}50%{transform:scaleX(.97);opacity:.46;}}
@keyframes XX-blink  {0%,46%,54%,100%{transform:scaleY(1);}  50%{transform:scaleY(.1);}}
```
Apply: `.XX-body{animation:XX-bob 2.6s infinite ease-in-out;}` etc. Pair the body
bob and shadow on the *same duration* so they breathe together. Stagger blink to
a different, non-multiple duration (e.g. 3.2s) so it feels natural.

The "hero motion" replaces or augments the bob — a sip tilts the body back, a
strum rotates the right arm, etc. Keep it to one clear gesture.

## Particles (steam, music notes, sparkles, ZZZ, water)

Spawn 2–3 copies and stagger them with CSS custom properties so they don't pulse
in unison:

```html
<g fill="#fff">
  <rect class="XX-steam" style="--sd:0s;--tx:-1px"   x="5.6" y="8.2" width=".7" height="2.4" rx=".35"/>
  <rect class="XX-steam" style="--sd:-1.2s;--tx:1px" x="8"   y="8.2" width=".7" height="2.4" rx=".35"/>
</g>
```
```css
.XX-steam{opacity:0;animation:XX-steam 2.4s var(--sd,0s) infinite ease-in;}
@keyframes XX-steam{
  0%{opacity:0;transform:translate(0,0) scaleX(1);}
  30%{opacity:.6;}
  100%{opacity:0;transform:translate(var(--tx,1px),-8px) scaleX(.5);}
}
```
`--sd` = negative animation-delay (starts mid-cycle), `--tx` = horizontal drift,
`--d` = per-particle duration. Same idea for notes (`<text>♪`), ZZZ (`<text>Z`),
sparkles (tiny rects), falling water (rects translating +y).

## Per-card theming variables

The shared stylesheet (`assets/card-template.html`) reads CSS variables off each
`.card`, so a card is recolored without touching the SVG:

```html
<div class="card" style="
     --glow:rgba(180,120,70,.2);     /* hover glow */
     --bd:rgba(180,120,70,.5);       /* hover border */
     --bg:linear-gradient(180deg,#140d06,#080808);  /* scene backdrop */
     --tagbg:rgba(180,120,70,.14);   /* tag chip bg */
     --tagfg:#c8915a">               /* tag chip text — must be valid hex! */
```
Pick a hue that matches the activity (warm browns for coffee, green for plants,
blue for night/shower). Double-check `--tagfg` is a real hex (`#4accce`), not a
typo with a stray space — malformed values silently break the chip color.

## Hats / headwear (avoid the "floating hat" bug)

Build the hat so its lowest pixel touches the torso top (**y=6**). Quick check:
find the largest y in the hat's shapes; it should be ≥ ~5.5. If the hat is a
`<polygon>` cone, its base points sit at y≈5–6; a brim `<rect>` sits at y≈5.
Put the hat *after* the head in draw order (on top), inside the body group so it
rides along, and give it `transform-origin:7.5px 6px` if it wobbles.

Examples that work: a Santa hat trim rect at y≈4.6 with the cap body reaching
y≈5; a witch-hat brim rect at y≈4.5; a nightcap band rect at y≈4.8. If you ever
see daylight between the hat and the head in the render, push the hat down.
