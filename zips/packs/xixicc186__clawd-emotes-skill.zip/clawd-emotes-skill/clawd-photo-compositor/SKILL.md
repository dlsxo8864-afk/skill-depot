---
name: clawd-photo-compositor
description: Add the canonical Clawd character to a user-provided photograph by selecting one bundled pose reference and compositing it with the photo through built-in image generation. Use this skill whenever the user asks to put, add, place, hide, hang, sit, stand, sleep, lean, climb, hug, push, pull, or otherwise make Clawd interact with an object in a photo, including requests phrased in Chinese such as “把 Clawd 放进图里”, “让它探头”, “挂在屏幕上”, or “抱住电线”.
---

# Clawd Photo Compositor

Use the bundled pose image as the source of truth for Clawd. Let the prompt describe placement and interaction, not redesign the character.

## Workflow

1. Inspect the user's photograph with `view_image` before editing it.
2. Read `references/pose-index.yaml` and select exactly one pose:
   - Prefer the action explicitly requested by the user.
   - Otherwise match the clearest object, edge, surface, cable, or obstacle in the photograph.
   - Ask only when no reasonable target or interaction can be inferred.
3. Resolve the selected `file` relative to this skill directory and inspect that pose image with `view_image`.
4. Treat the inputs consistently:
   - Image 1: the user's photograph and edit target.
   - Image 2: the selected Clawd character-and-pose reference.
5. Call built-in image generation with both images as references. Pass one Clawd pose only; multiple pose references can cause mixed limbs or duplicate characters.
6. Build a short prompt from the template below. Always include both `prompt_constants.identity_lock` and `prompt_constants.proxy_exclusion` from the pose index. Include the pose entry's `relation_hint` only when the action depends on occlusion or contact.
7. Check the result before accepting it:
   - Clawd remains a flat 2D block graphic even though the surrounding photograph is realistic.
   - Its body silhouette, body aspect ratio, two block hands, four short rectangular legs, and relative part sizes still match Image 2.
   - No gray proxy platform, wall, cylinder, line, box, or reference shadow from Image 2 was copied into the photograph.
   If one check fails, retry once by strengthening only the failed identity or proxy sentence.
8. Return the generated image. Do not add a second character, substitute another pose, or generate a standalone Clawd asset unless the user requested that instead.

## Prompt template

Prefer two short sentences:

```text
以图1为原图，把图2里的Clawd按图2动作放在图一的{target/location}，让它{interaction}；保持图一其他内容不变。{relation_hint}
{identity_lock}
{proxy_exclusion}
```

Translate the same structure when the user writes in another language. Keep the prompt focused on target, action, and necessary contact or occlusion. Do not expand it into a long character specification unless a previous result failed for one specific reason.

## Selection rules

- Use A-series references for ordinary standing views without a physical interaction.
- Use B-series references for contact poses.
- Keep the photograph photorealistic while keeping Clawd visibly flat and graphic. Do not harmonize Clawd into the photo's realistic material or lighting style.
- Allow only uniform whole-character scaling and rotation. Do not independently stretch, compress, widen, narrow, or round the body or limbs.
- Map the gray proxy geometry in a pose reference onto the real object in the photograph. The proxy conveys only pose, contact, and occlusion; it is never an asset to copy into the result.
- Preserve the user's requested target and action even if another scene object could also work.
- For ambiguous placement, choose an area with enough visual space and contrast while keeping the photograph's main subject readable.
- Do not use multi-expression sheets or negative/error examples as image-generation references.

## Prompt discipline

- Keep the user's wording when it already specifies the object and action.
- Keep the identity-lock sentence even when shortening the rest of the prompt; the reference pose alone does not reliably prevent photorealistic restyling or proportion drift.
- Keep the proxy-exclusion sentence even when shortening the rest of the prompt; this is the one negative constraint that every pose-reference composition needs.
- Mention layer order only when it communicates the interaction, such as “body behind the cable, hands in front”.
- Add a scale instruction only when the likely default would be obviously wrong.
- Avoid inventories of colors, facial features, limbs, camera details, and negative constraints: Image 2 already carries those details.
- If a retry is needed, change only the failed relationship, scale, placement, identity lock, or proxy exclusion rather than rewriting the whole prompt.
