import { gsap } from 'gsap'
import { h, set, at } from '../lib/dom'
import { C, rgba } from '../lib/colors'
import { BUBBLE, FOOTER_Y, HEADING_Y, MARGIN, PROMPT, W } from '../layout'
import { typeset } from './bubble'
import { Ruler } from './ruler'
import type { Shell, ShellOptions, ThinkOptions } from './shell'
import type { Sfx } from '../audio/sfx'

type TL = gsap.core.Timeline

// Claude Code 的思考指示器：· ✢ ✳ ✶ ✻ ✽ 来回循环
const SPIN = ['·', '✢', '✳', '✶', '✻', '✽']

/**
 * 终端界面（Claude 系列的外壳）：顶部进度标尺、对话记录里的问题、底部输入框和提示栏。
 * 视觉上对应 Claude Code 的真实界面元素。
 */
export class Terminal implements Shell {
  readonly root: HTMLDivElement
  readonly prompt: HTMLDivElement
  readonly rulerEl: HTMLDivElement
  readonly footerEl: HTMLDivElement
  private readonly ruler: Ruler
  private readonly line: HTMLDivElement
  private readonly cursor: HTMLSpanElement
  private readonly placeholder: HTMLSpanElement
  private readonly footRight: HTMLDivElement
  private headingCur: HTMLElement | null = null
  private footCur: HTMLElement | null = null

  constructor(
    parent: HTMLElement,
    private readonly sfx: Sfx,
    o: ShellOptions,
  ) {
    this.root = h('div', { class: 'chrome' })
    parent.append(this.root)

    // ── 进度标尺 ───────────────────────────────
    this.ruler = new Ruler(o.stops)
    this.rulerEl = this.ruler.el
    this.root.append(this.rulerEl)

    // ── 输入框 ─────────────────────────────────
    this.cursor = h('span', { class: 'cursor', text: ' ' })
    this.placeholder = h('span', { class: 'placeholder', text: o.placeholder ?? '' })
    this.line = h('div', { class: 'prompt-line' }, [h('span', { class: 'gt', text: '>' }), this.cursor, this.placeholder])
    this.prompt = h('div', { class: 'prompt' }, [this.line])
    Object.assign(this.prompt.style, {
      left: `${PROMPT.left}px`,
      top: `${PROMPT.top}px`,
      width: `${PROMPT.right - PROMPT.left}px`,
      height: `${PROMPT.height}px`,
    })
    this.root.append(this.prompt)

    // ── 底部提示栏 ─────────────────────────────
    this.footRight = h('div', { class: 'foot-right' })
    this.footerEl = at(h('div', { class: 'footer' }, [h('span', { text: '? for shortcuts' }), this.footRight]), MARGIN + 22, FOOTER_Y)
    this.footerEl.style.width = `${W - 2 * MARGIN - 44}px`
    this.root.append(this.footerEl)
  }

  /** 光标闪烁：做成贯穿全片的补间，导出视频时也能逐帧复现 */
  blinkCursor(tl: TL, from: number, to: number) {
    const n = Math.max(2, Math.floor((to - from) / 0.53 / 2) * 2)
    tl.to(this.cursor, { opacity: 0, duration: 0.53, ease: 'steps(1)', repeat: n - 1, yoyo: true }, from)
  }

  /** 把进度标尺的标记移到 name 这一站 */
  step(tl: TL, name: string, t: number) {
    return this.ruler.step(tl, name, t)
  }

  /** 在输入框里打出问题并回车，问题随即出现在顶部的对话记录里 */
  ask(tl: TL, question: string, t: number) {
    const q = h('span', { class: 'q' })
    const chars = typeset(question, q)
    this.line.insertBefore(q, this.cursor)
    gsap.set(chars, { display: 'none' })
    set(tl, this.placeholder, { display: 'none' }, t)
    let tt = t + 0.15
    chars.forEach((c, i) => {
      set(tl, c, { display: 'inline' }, tt)
      this.sfx.at(tt, 'key', i)
      const ch = c.textContent ?? ''
      tt += /[一-鿿]/.test(ch) ? 0.062 : /[A-Za-z0-9 ]/.test(ch) ? 0.038 : 0.05
    })
    const submit = tt + 0.32
    this.sfx.at(submit, 'enter')
    tl.fromTo(
      this.prompt,
      { borderColor: C.fg },
      { borderColor: rgba(C.prompt, 0.6), duration: 0.45, ease: 'power1.out', immediateRender: false },
      submit,
    )
    set(tl, q, { display: 'none' }, submit + 0.04)
    set(tl, this.placeholder, { display: 'inline' }, submit + 0.04)
    this.heading(tl, question, submit + 0.04)
    return submit + 0.12
  }

  /** 顶部的 “> 问题” */
  heading(tl: TL, text: string, t: number) {
    const el = at(h('div', { class: 'heading' }), MARGIN, HEADING_Y)
    el.append(h('span', { class: 'heading-gt', text: '> ' }))
    typeset(text, el)
    this.root.append(el)
    gsap.set(el, { autoAlpha: 0 })
    this.clearHeading(tl, t)
    tl.fromTo(el, { autoAlpha: 0, y: 10 }, { autoAlpha: 1, y: 0, duration: 0.35, ease: 'power2.out', immediateRender: false }, t)
    this.headingCur = el
    return el
  }

  clearHeading(tl: TL, t: number) {
    if (this.headingCur) tl.to(this.headingCur, { autoAlpha: 0, duration: 0.2 }, t)
    this.headingCur = null
  }

  /** “✻ Pondering… (esc to interrupt)” */
  think(tl: TL, t: number, dur: number, { verb = 'Pondering' }: ThinkOptions = {}) {
    const glyphs = SPIN.map((g) => h('span', { class: 'spin-glyph', text: g }))
    const spin = h('span', { class: 'spin' }, glyphs)
    const word = h('span', { class: 'think-word', text: `${verb}…` })
    const el = at(h('div', { class: 'thinking' }, [spin, word, h('span', { class: 'think-esc', text: '(esc to interrupt)' })]), BUBBLE.left + 10, BUBBLE.top + 40)
    this.root.append(el)
    gsap.set(el, { autoAlpha: 0 })
    gsap.set(glyphs, { autoAlpha: 0 })
    set(tl, el, { autoAlpha: 1 }, t)
    const frames = [...SPIN.keys(), ...[...SPIN.keys()].reverse()]
    const dt = 0.1
    let prev = -1
    for (let k = 0; k * dt < dur; k++) {
      const gi = frames[k % frames.length]
      if (prev >= 0) set(tl, glyphs[prev], { autoAlpha: 0 }, t + k * dt)
      set(tl, glyphs[gi], { autoAlpha: 1 }, t + k * dt)
      prev = gi
    }
    // 动词上扫过一道高光，和 Claude Code 一样
    tl.fromTo(word, { backgroundPosition: '100% 0' }, { backgroundPosition: '0% 0', duration: dur, ease: 'none', immediateRender: false }, t)
    set(tl, el, { autoAlpha: 0 }, t + dur)
    return t + dur
  }

  footer(tl: TL, text: string, t: number) {
    const el = h('span', { class: 'foot-title', text })
    this.footRight.append(el)
    gsap.set(el, { autoAlpha: 0 })
    if (this.footCur) set(tl, this.footCur, { autoAlpha: 0 }, t)
    set(tl, el, { autoAlpha: 1 }, t)
    this.footCur = el
  }
}
