#!/usr/bin/env python3
"""pixelpass.py - delivery checks for pixel-art sprites, strips and sheets.

Standard library only (Python 3.8+). No network, no image libraries.

Commands
  card     print a starter pass card (JSON)
  audit    read a PNG (+ optional Aseprite-style JSON) and report findings + verdict
  palette  list the colours a sheet really uses (text, .hex or .gpl)
  preview  write an enlarged contact sheet PNG to look at
  atlas    write an Aseprite-style frames JSON for the grid in the card
  recipe   print engine import settings for the card (godot, unity, phaser,
           gamemaker, love, defold, css)

Exit codes for audit: 0 = SHIP / SHIP_WITH_NOTES, 1 = FIX, 2 = BLOCK, 3 = bad input.
"""
import argparse
import json
import math
import os
import struct
import sys
import zlib

PNG_SIG = b"\x89PNG\r\n\x1a\n"


class PassError(Exception):
    """Input that cannot be read or does not make sense."""


# --------------------------------------------------------------------------- PNG

def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    return b if pb <= pc else c


def decode_png(data):
    """Return (width, height, pixels) with pixels a flat list of (r, g, b, a) tuples."""
    if not data.startswith(PNG_SIG):
        raise PassError("not a PNG file (bad signature)")
    pos = 8
    ihdr = None
    palette = []
    trns = None
    idat = []
    while pos + 8 <= len(data):
        length, ctype = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if ctype == b"IHDR":
            ihdr = struct.unpack(">IIBBBBB", body)
        elif ctype == b"PLTE":
            palette = [tuple(body[i:i + 3]) for i in range(0, len(body) - 2, 3)]
        elif ctype == b"tRNS":
            trns = body
        elif ctype == b"IDAT":
            idat.append(body)
        elif ctype == b"IEND":
            break
    if ihdr is None:
        raise PassError("PNG has no IHDR chunk")
    w, h, depth, ctype, _comp, _filt, interlace = ihdr
    if interlace:
        raise PassError("interlaced PNG is not supported; re-save it without interlacing")
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ctype)
    if channels is None:
        raise PassError("unknown PNG colour type %d" % ctype)
    if ctype == 3 and not palette:
        raise PassError("indexed PNG without a palette")
    bits = channels * depth
    stride = (w * bits + 7) // 8
    bpp = max(1, bits // 8)
    try:
        raw = zlib.decompress(b"".join(idat))
    except zlib.error as exc:
        raise PassError("PNG image data is corrupt: %s" % exc)
    if len(raw) < h * (stride + 1):
        raise PassError("PNG image data is truncated")
    rows = []
    prev = bytearray(stride)
    p = 0
    for _ in range(h):
        ftype = raw[p]
        line = bytearray(raw[p + 1:p + 1 + stride])
        p += stride + 1
        if ftype == 1:
            for i in range(bpp, stride):
                line[i] = (line[i] + line[i - bpp]) & 255
        elif ftype == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 255
        elif ftype == 3:
            for i in range(stride):
                left = line[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + ((left + prev[i]) >> 1)) & 255
        elif ftype == 4:
            for i in range(stride):
                left = line[i - bpp] if i >= bpp else 0
                upleft = prev[i - bpp] if i >= bpp else 0
                line[i] = (line[i] + _paeth(left, prev[i], upleft)) & 255
        elif ftype != 0:
            raise PassError("bad PNG filter type %d" % ftype)
        rows.append(line)
        prev = line

    def samples(line):
        if depth == 8:
            return list(line)
        if depth == 16:
            return [line[i] for i in range(0, len(line), 2)]  # high byte
        out = []
        mask = (1 << depth) - 1
        for byte in line:
            for shift in range(8 - depth, -1, -depth):
                out.append((byte >> shift) & mask)
        return out

    scale = 255 // ((1 << depth) - 1) if depth < 8 else 1
    t_gray = t_rgb = None
    if trns is not None and ctype == 0 and len(trns) >= 2:
        t_gray = struct.unpack(">H", trns[:2])[0]
        t_gray = t_gray >> 8 if depth == 16 else t_gray
    if trns is not None and ctype == 2 and len(trns) >= 6:
        t_rgb = struct.unpack(">HHH", trns[:6])
        if depth == 16:
            t_rgb = tuple(v >> 8 for v in t_rgb)
    pixels = []
    for line in rows:
        s = samples(line)
        for x in range(w):
            if ctype == 6:
                r, g, b, a = s[4 * x:4 * x + 4]
            elif ctype == 2:
                r, g, b = s[3 * x:3 * x + 3]
                a = 0 if t_rgb is not None and (r, g, b) == t_rgb else 255
            elif ctype == 4:
                r = g = b = s[2 * x]
                a = s[2 * x + 1]
            elif ctype == 0:
                v = s[x]
                a = 0 if t_gray is not None and v == t_gray else 255
                r = g = b = v * scale
            else:
                idx = s[x]
                if idx >= len(palette):
                    raise PassError("palette index %d out of range" % idx)
                r, g, b = palette[idx]
                a = trns[idx] if trns is not None and idx < len(trns) else 255
            pixels.append((r, g, b, a))
    return w, h, pixels


def encode_png(w, h, pixels):
    """Encode RGBA pixels (flat list of 4-tuples) as a PNG byte string."""
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            raw.extend(bytes(pixels[y * w + x]))

    def chunk(kind, body):
        return (struct.pack(">I", len(body)) + kind + body
                + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF))

    return (PNG_SIG + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))


def read_png(path):
    with open(path, "rb") as fh:
        return decode_png(fh.read())


# --------------------------------------------------------------------------- colour

def parse_hex(text):
    t = text.strip().lstrip("#")
    if len(t) == 3:
        t = "".join(c * 2 for c in t)
    if len(t) not in (6, 8) or any(c not in "0123456789abcdefABCDEF" for c in t):
        raise PassError("not a hex colour: %r" % text)
    return tuple(int(t[i:i + 2], 16) for i in (0, 2, 4))


def to_hex(rgb):
    return "#%02x%02x%02x" % tuple(rgb[:3])


def rel_luminance(rgb):
    def lin(c):
        c = c / 255.0
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(v) for v in rgb[:3])
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(c1, c2):
    l1, l2 = rel_luminance(c1), rel_luminance(c2)
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def colour_distance(c1, c2):
    """Weighted RGB distance (cheap perceptual approximation), 0..~765."""
    rmean = (c1[0] + c2[0]) / 2.0
    dr, dg, db = c1[0] - c2[0], c1[1] - c2[1], c1[2] - c2[2]
    return math.sqrt((2 + rmean / 256) * dr * dr + 4 * dg * dg + (2 + (255 - rmean) / 256) * db * db) / 3.0


def load_palette_file(path):
    """Read .hex (one colour per line), .gpl (GIMP) or a JSON list of hex strings."""
    with open(path, "r", encoding="utf-8") as fh:
        text = fh.read()
    cols = []
    if text.lstrip().startswith("["):
        cols = [parse_hex(c) for c in json.loads(text)]
    else:
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith(("#", "GIMP", "Name:", "Columns:")) and not _looks_hex(line):
                continue
            parts = line.split()
            if len(parts) >= 3 and all(p.isdigit() for p in parts[:3]):
                cols.append(tuple(int(p) for p in parts[:3]))
            elif _looks_hex(parts[0]):
                cols.append(parse_hex(parts[0]))
    if not cols:
        raise PassError("no colours found in palette file %s" % path)
    return cols


def _looks_hex(s):
    t = s.lstrip("#")
    return len(t) in (3, 6, 8) and all(c in "0123456789abcdefABCDEF" for c in t)


# --------------------------------------------------------------------------- card

DEFAULT_CARD = {
    "asset": "hero-run",
    "subject": "character",      # character | effect | prop | tile | ui
    "kind": "loop",              # loop | oneshot | still
    "cell": [32, 32],            # frame size in native pixels
    "margin": 0,
    "spacing": 0,
    "frames": None,              # how many cells are real frames (None = up to the last non-empty one)
    "fps": 12,
    "durations_ms": None,        # per-frame durations; overrides fps
    "tick_hz": 60,
    "pivot": "bottom-center",    # bottom-center | center | top-left | [x, y]
    "ground_anchored": True,     # feet should stay on one row across frames
    "in_place": True,            # body should not wander sideways across frames
    "drift_px": 1,
    "palette_max": 16,
    "palette_file": None,
    "alpha": "binary",           # binary | soft
    "background": "#1d2030",
    "display_scale": 3,
    "engine": "godot",
}

SUBJECTS = ("character", "effect", "prop", "tile", "ui")
KINDS = ("loop", "oneshot", "still")


def load_card(path=None, overrides=None):
    card = dict(DEFAULT_CARD)
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            try:
                card.update(json.load(fh))
            except ValueError as exc:
                raise PassError("card is not valid JSON: %s" % exc)
    for k, v in (overrides or {}).items():
        if v is not None:
            card[k] = v
    if card["subject"] not in SUBJECTS:
        raise PassError("subject must be one of %s" % ", ".join(SUBJECTS))
    if card["kind"] not in KINDS:
        raise PassError("kind must be one of %s" % ", ".join(KINDS))
    cell = card.get("cell")
    if cell is not None:
        if isinstance(cell, str):
            cell = [int(v) for v in cell.lower().split("x")]
        if len(cell) != 2 or min(cell) <= 0:
            raise PassError("cell must be [width, height] with positive numbers")
        card["cell"] = [int(cell[0]), int(cell[1])]
    if card["alpha"] not in ("binary", "soft"):
        raise PassError("alpha must be 'binary' or 'soft'")
    return card


# --------------------------------------------------------------------------- frames

class Frame(object):
    def __init__(self, index, x, y, w, h, pixels, duration=None):
        self.index, self.x, self.y, self.w, self.h = index, x, y, w, h
        self.pixels = pixels  # flat list of (r, g, b, a), fully transparent normalised to (0,0,0,0)
        self.duration = duration

    def at(self, x, y):
        return self.pixels[y * self.w + x]

    def opaque_count(self):
        return sum(1 for p in self.pixels if p[3])

    def bbox(self):
        xs, ys = [], []
        for i, p in enumerate(self.pixels):
            if p[3]:
                xs.append(i % self.w)
                ys.append(i // self.w)
        if not xs:
            return None
        return min(xs), min(ys), max(xs), max(ys)


def _crop(w, pixels, x0, y0, cw, ch):
    out = []
    for y in range(y0, y0 + ch):
        row = pixels[y * w + x0:y * w + x0 + cw]
        out.extend(p if p[3] else (0, 0, 0, 0) for p in row)
    return out


def grid_frames(w, h, pixels, cell, margin=0, spacing=0):
    """Slice a sheet into cells. Returns (frames, misfit) where misfit lists problems."""
    cw, ch = cell
    misfit = []
    span_w, span_h = w - 2 * margin + spacing, h - 2 * margin + spacing
    if span_w % (cw + spacing):
        misfit.append("width %d does not fit %d-px cells (margin %d, spacing %d)" % (w, cw, margin, spacing))
    if span_h % (ch + spacing):
        misfit.append("height %d does not fit %d-px cells (margin %d, spacing %d)" % (h, ch, margin, spacing))
    cols, rows = span_w // (cw + spacing), span_h // (ch + spacing)
    frames = []
    for r in range(rows):
        for c in range(cols):
            x0, y0 = margin + c * (cw + spacing), margin + r * (ch + spacing)
            frames.append(Frame(len(frames), x0, y0, cw, ch, _crop(w, pixels, x0, y0, cw, ch)))
    return frames, misfit


def json_frames(w, h, pixels, meta):
    """Frames from an Aseprite-style export (hash or array). Trimmed frames are restored to source size."""
    raw = meta.get("frames")
    if isinstance(raw, dict):
        items = list(raw.values())
    elif isinstance(raw, list):
        items = raw
    else:
        raise PassError("frames JSON has no 'frames' hash or array")
    frames = []
    for it in items:
        if it.get("rotated"):
            raise PassError("rotated atlas frames are not supported; export without rotation")
        f = it["frame"]
        x0, y0, fw, fh = int(f["x"]), int(f["y"]), int(f["w"]), int(f["h"])
        if x0 < 0 or y0 < 0 or x0 + fw > w or y0 + fh > h:
            raise PassError("frame %d rectangle lies outside the image" % len(frames))
        crop = _crop(w, pixels, x0, y0, fw, fh)
        src = it.get("sourceSize") or {"w": fw, "h": fh}
        sss = it.get("spriteSourceSize") or {"x": 0, "y": 0}
        sw, sh = int(src["w"]), int(src["h"])
        if it.get("trimmed") or (sw, sh) != (fw, fh):
            full = [(0, 0, 0, 0)] * (sw * sh)
            ox, oy = int(sss.get("x", 0)), int(sss.get("y", 0))
            for yy in range(fh):
                for xx in range(fw):
                    tx, ty = ox + xx, oy + yy
                    if 0 <= tx < sw and 0 <= ty < sh:
                        full[ty * sw + tx] = crop[yy * fw + xx]
            crop, fw, fh = full, sw, sh
        frames.append(Frame(len(frames), x0, y0, fw, fh, crop, it.get("duration")))
    return frames


def frame_diff(a, b):
    if (a.w, a.h) != (b.w, b.h):
        return max(len(a.pixels), len(b.pixels))
    return sum(1 for p, q in zip(a.pixels, b.pixels) if p != q)


# --------------------------------------------------------------------------- checks

SEVERITY = {"block": 3, "fix": 2, "warn": 1, "info": 0}

ADVICE = {
    "GRID_MISFIT": "Re-export with a fixed cell size, or set margin/spacing in the card to match the sheet.",
    "FRAME_COUNT": "Make the declared frame count, the JSON frames and the drawn cells agree before import.",
    "EMPTY_FRAME": "Delete the empty cell or draw it; an empty frame in the middle reads as a flicker.",
    "DUP_FRAME": "Merge identical neighbours into one frame with a longer duration (a hold).",
    "UNUSED_CELLS": "Trailing empty cells are fine if the engine is told the real frame count.",
    "EDGE_TOUCH": "Leave at least 1 px of empty border per cell (or use spacing/extrude) so filtering and packing do not bleed.",
    "UPSCALED": "Ship the native-size art and scale in the engine; pre-scaled sheets waste memory and break pixel snapping.",
    "PALETTE_OVER": "Merge near colours and cut ramps until the count fits the budget.",
    "OFF_PALETTE": "Snap these colours to the nearest locked palette entry.",
    "NEAR_TWINS": "Two colours this close look identical at 1x; merge them (usually leftovers from resampling or AI generation).",
    "HALF_ALPHA": "Binary-alpha art should have only 0 or 255 alpha; threshold the soft pixels (often a downscale halo).",
    "SOFT_EDGE": "Semi-transparent pixels on the silhouette edge make a halo on light backgrounds; harden the edge or use a dark outline.",
    "DUST": "Lone pixels with no neighbours: delete them unless they are deliberate sparks.",
    "SPECKLE": "Single odd-coloured pixels inside shapes read as noise; merge them into the surrounding colour cluster.",
    "PIVOT_DRIFT": "The lowest opaque row moves between frames; align the feet to one row or the sprite will bob against the floor.",
    "CENTER_DRIFT": "The body slides sideways between frames; re-centre each frame on the pivot column.",
    "LOOP_DOUBLE": "The last frame repeats the first, so the loop stutters; drop the last frame.",
    "LOOP_SEAM": "The jump from last to first frame is much bigger than any other step; add an in-between or adjust the last frame.",
    "POPS_OFF": "A one-shot effect should end empty (shrink, dither out, fall away) or it vanishes with a pop.",
    "TICK_UNEVEN": "These durations are not whole ticks of the game loop, so frames get uneven screen time; use multiples of the tick.",
    "LOW_READ": "The silhouette edge is close to the background in brightness; add a darker/lighter outline or rim.",
    "TEXTURE_LIMIT": "Sheets over 4096 px on a side fail or get downscaled on many phones; split the sheet.",
    "NON_INTEGER_SCALE": "Non-integer display scale makes pixels uneven sizes; use 2x, 3x, 4x... and letterbox the rest.",
    "STILL_MULTI": "A still asset with several frames: check you picked the right kind in the card.",
}


def _finding(code, severity, message, frames=None, detail=None):
    out = {"code": code, "severity": severity, "message": message, "advice": ADVICE.get(code, "")}
    if frames is not None:
        out["frames"] = frames
    if detail is not None:
        out["detail"] = detail
    return out


def detect_upscale(frames):
    """Largest k >= 2 such that every frame is made of uniform k x k blocks (aligned at the frame origin)."""
    live = [f for f in frames if f.opaque_count()]
    if not live:
        return 1
    w, h = live[0].w, live[0].h
    for k in range(min(16, w, h), 1, -1):
        if w % k or h % k:
            continue
        ok = True
        for f in live:
            px = f.pixels
            for by in range(0, f.h, k):
                for bx in range(0, f.w, k):
                    first = px[by * f.w + bx]
                    for yy in range(by, by + k):
                        row = yy * f.w
                        for xx in range(bx, bx + k):
                            if px[row + xx] != first:
                                ok = False
                                break
                        if not ok:
                            break
                    if not ok:
                        break
                if not ok:
                    break
            if not ok:
                break
        if ok:
            return k
    return 1


def _neighbours(f, x, y, diag=True):
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            if not diag and dx and dy:
                continue
            nx, ny = x + dx, y + dy
            if 0 <= nx < f.w and 0 <= ny < f.h:
                yield f.at(nx, ny)
            else:
                yield None


def frame_stats(f):
    dust = speckle = interior = edge_soft = edge = 0
    spots = []
    edge_colours = []
    for y in range(f.h):
        for x in range(f.w):
            p = f.at(x, y)
            if not p[3]:
                continue
            nb = list(_neighbours(f, x, y))
            opaque_nb = [q for q in nb if q is not None and q[3]]
            if not opaque_nb:
                dust += 1
                continue
            four = list(_neighbours(f, x, y, diag=False))
            if any(q is None or not q[3] for q in four):
                edge += 1
                edge_colours.append(p)
                if p[3] < 255:
                    edge_soft += 1
            if len(opaque_nb) == 8:
                interior += 1
                if all(q != p for q in opaque_nb):
                    # odd one out only if the neighbours mostly agree with each other
                    common = max(opaque_nb.count(q) for q in opaque_nb)
                    if common >= 5:
                        speckle += 1
                        if len(spots) < 5:
                            spots.append([x, y])
    return {"dust": dust, "speckle": speckle, "interior": interior, "edge": edge,
            "edge_soft": edge_soft, "edge_colours": edge_colours, "spots": spots}


def durations_for(card, frames):
    if card.get("durations_ms"):
        d = [float(v) for v in card["durations_ms"]]
        return d
    if frames and all(f.duration is not None for f in frames):
        return [float(f.duration) for f in frames]
    fps = card.get("fps")
    if fps:
        return [1000.0 / float(fps)] * len(frames)
    return []


def audit(w, h, pixels, card, meta=None):
    findings = []
    if meta is not None:
        frames = json_frames(w, h, pixels, meta)
        misfit = []
    elif card.get("cell"):
        frames, misfit = grid_frames(w, h, pixels, card["cell"], card.get("margin", 0), card.get("spacing", 0))
    else:
        frames, misfit = [Frame(0, 0, 0, w, h, _crop(w, pixels, 0, 0, w, h))], []
    for m in misfit:
        findings.append(_finding("GRID_MISFIT", "block", m))
    if not frames:
        raise PassError("no frames found: the cell is larger than the image")

    counts = [f.opaque_count() for f in frames]
    declared = card.get("frames")
    if declared is not None:
        declared = int(declared)
        if declared > len(frames):
            findings.append(_finding("FRAME_COUNT", "block",
                                     "card says %d frames but the sheet has only %d cells" % (declared, len(frames))))
            declared = len(frames)
        extra = [i for i in range(declared, len(frames)) if counts[i]]
        if extra:
            findings.append(_finding("FRAME_COUNT", "block",
                                     "cells beyond the declared %d frames are drawn" % declared, extra))
        used = frames[:declared]
    else:
        last = max([i for i, c in enumerate(counts) if c] or [-1])
        used = frames[:last + 1] if last >= 0 else frames[:1]
        if meta is None and len(frames) - len(used) > 0 and last >= 0:
            findings.append(_finding("UNUSED_CELLS", "info",
                                     "%d trailing empty cell(s) after frame %d" % (len(frames) - len(used), last)))
    n = len(used)
    ucounts = [f.opaque_count() for f in used]

    if card["kind"] == "still" and n > 1:
        findings.append(_finding("STILL_MULTI", "warn", "kind is 'still' but %d frames were found" % n))

    empties = [f.index for f, c in zip(used, ucounts) if c == 0]
    if card["kind"] == "oneshot" and card["subject"] == "effect" and empties and empties[-1] == used[-1].index:
        # an empty final frame is how an effect should end
        empties = empties[:-1]
    if empties:
        findings.append(_finding("EMPTY_FRAME", "fix", "%d empty frame(s) inside the animation" % len(empties), empties))

    dups = [used[i].index for i in range(1, n) if ucounts[i] and frame_diff(used[i - 1], used[i]) == 0]
    if dups:
        findings.append(_finding("DUP_FRAME", "warn", "frame identical to the one before it", dups))

    # edges of each cell
    if card["subject"] != "tile":
        touching = []
        for f in used:
            bb = f.bbox()
            if bb and (bb[0] == 0 or bb[1] == 0 or bb[2] == f.w - 1 or bb[3] == f.h - 1):
                touching.append(f.index)
        if touching:
            findings.append(_finding("EDGE_TOUCH", "warn", "art touches the cell border", touching))

    k = detect_upscale(used)
    if k > 1:
        findings.append(_finding("UPSCALED", "fix",
                                 "every pixel is a %dx%d block; native frame size is %dx%d"
                                 % (k, k, used[0].w // k, used[0].h // k), detail={"factor": k}))

    # palette
    hist = {}
    for f in used:
        for p in f.pixels:
            if p[3]:
                hist[p[:3]] = hist.get(p[:3], 0) + 1
    colours = sorted(hist, key=lambda c: -hist[c])
    pmax = card.get("palette_max")
    if pmax and len(colours) > int(pmax):
        findings.append(_finding("PALETTE_OVER", "fix",
                                 "%d colours used, budget is %d" % (len(colours), int(pmax)),
                                 detail={"colours": len(colours)}))
    if card.get("palette_file"):
        locked = load_palette_file(card["palette_file"])
        off = []
        for c in colours:
            if c not in locked:
                near = min(locked, key=lambda q: colour_distance(c, q))
                off.append({"colour": to_hex(c), "pixels": hist[c], "nearest": to_hex(near),
                            "distance": round(colour_distance(c, near), 1)})
        if off:
            findings.append(_finding("OFF_PALETTE", "block",
                                     "%d colour(s) are not in the locked palette" % len(off), detail=off[:20]))
    twins = []
    if len(colours) <= 256:
        for i in range(len(colours)):
            for j in range(i + 1, len(colours)):
                d = colour_distance(colours[i], colours[j])
                if d < 8:
                    twins.append({"a": to_hex(colours[i]), "b": to_hex(colours[j]), "distance": round(d, 1)})
    if twins:
        findings.append(_finding("NEAR_TWINS", "warn", "%d pair(s) of almost identical colours" % len(twins),
                                 detail=twins[:20]))

    # alpha
    half = sum(1 for f in used for p in f.pixels if 0 < p[3] < 255)
    stats = [frame_stats(f) for f in used]
    if card["alpha"] == "binary" and half:
        findings.append(_finding("HALF_ALPHA", "fix", "%d semi-transparent pixel(s) in binary-alpha art" % half))
    elif card["alpha"] == "soft" and card["subject"] != "effect":
        e_all = sum(s["edge"] for s in stats)
        e_soft = sum(s["edge_soft"] for s in stats)
        if e_all and e_soft / float(e_all) > 0.25:
            findings.append(_finding("SOFT_EDGE", "warn", "%d of %d silhouette-edge pixels are semi-transparent"
                                     % (e_soft, e_all)))

    # clusters
    dust_frames = [(f.index, s["dust"]) for f, s in zip(used, stats) if s["dust"]]
    if dust_frames:
        sev = "info" if card["subject"] == "effect" else "warn"
        findings.append(_finding("DUST", sev, "%d lone pixel(s)" % sum(d for _, d in dust_frames),
                                 [i for i, _ in dust_frames]))
    tot_int = sum(s["interior"] for s in stats)
    tot_sp = sum(s["speckle"] for s in stats)
    if tot_sp >= 4 and tot_int and tot_sp / float(tot_int) > 0.05:
        spots = {str(f.index): s["spots"] for f, s in zip(used, stats) if s["spots"]}
        findings.append(_finding("SPECKLE", "warn", "%d odd-one-out pixel(s) inside shapes (%.1f%% of interior)"
                                 % (tot_sp, 100.0 * tot_sp / tot_int), detail=spots))

    # motion
    boxes = [(f.index, f.bbox()) for f in used]
    boxes = [(i, b) for i, b in boxes if b]
    tol = int(card.get("drift_px", 1))
    if len(boxes) > 1 and card["subject"] in ("character", "prop"):
        if card.get("ground_anchored"):
            bottoms = [b[3] for _, b in boxes]
            if max(bottoms) - min(bottoms) > tol:
                findings.append(_finding("PIVOT_DRIFT", "warn", "lowest opaque row ranges %d..%d"
                                         % (min(bottoms), max(bottoms)),
                                         [i for i, b in boxes if b[3] != max(set(bottoms), key=bottoms.count)]))
        if card.get("in_place"):
            centres = [(b[0] + b[2]) / 2.0 for _, b in boxes]
            if max(centres) - min(centres) > tol + 1:
                findings.append(_finding("CENTER_DRIFT", "warn", "horizontal centre ranges %.1f..%.1f"
                                         % (min(centres), max(centres))))
    if card["kind"] == "loop" and n > 2:
        if frame_diff(used[-1], used[0]) == 0 and ucounts[0]:
            findings.append(_finding("LOOP_DOUBLE", "fix", "last frame equals the first", [used[-1].index]))
        else:
            steps = [frame_diff(used[i - 1], used[i]) for i in range(1, n)]
            steps_sorted = sorted(steps)
            median = steps_sorted[len(steps_sorted) // 2]
            wrap = frame_diff(used[-1], used[0])
            if wrap > 2.5 * max(median, 1) and wrap > max(steps) and wrap >= 8:
                findings.append(_finding("LOOP_SEAM", "warn", "wrap step changes %d px; median step is %d"
                                         % (wrap, median), [used[-1].index, used[0].index]))
    if card["kind"] == "oneshot" and card["subject"] == "effect" and n > 1:
        peak = max(ucounts) or 1
        if ucounts[-1] > 0.02 * peak:
            findings.append(_finding("POPS_OFF", "warn", "last frame still has %d px (peak %d)" % (ucounts[-1], peak),
                                     [used[-1].index]))

    # timing
    durs = durations_for(card, used)
    if durs and card["kind"] != "still" and n > 1:
        tick = 1000.0 / float(card.get("tick_hz") or 60)
        bad = [used[i].index for i, d in enumerate(durs[:n]) if abs(d / tick - round(d / tick)) * tick > 1.0
               or round(d / tick) == 0]
        if bad:
            findings.append(_finding("TICK_UNEVEN", "warn", "%d frame duration(s) are not whole %.2f ms ticks"
                                     % (len(bad), tick), bad, detail={"tick_ms": round(tick, 2),
                                                                      "durations_ms": [round(d, 2) for d in durs[:n]]}))

    # readability against the background
    if card.get("background") and card["subject"] != "tile":
        bg = parse_hex(card["background"])
        edge_cols = [p for s in stats for p in s["edge_colours"] if p[3] >= 128]
        if edge_cols:
            low = sum(1 for p in edge_cols if contrast(p, bg) < 1.5)
            if low / float(len(edge_cols)) > 0.6:
                findings.append(_finding("LOW_READ", "warn", "%d%% of the silhouette edge is within 1.5:1 of %s"
                                         % (round(100.0 * low / len(edge_cols)), card["background"])))

    if max(w, h) > 4096:
        findings.append(_finding("TEXTURE_LIMIT", "warn", "sheet is %dx%d" % (w, h)))
    scale = card.get("display_scale")
    if scale is not None and float(scale) != int(float(scale)):
        findings.append(_finding("NON_INTEGER_SCALE", "fix", "display scale %s" % scale))

    worst = max([SEVERITY[f["severity"]] for f in findings] or [0])
    verdict = {3: "BLOCK", 2: "FIX", 1: "SHIP_WITH_NOTES", 0: "SHIP"}[worst]
    findings.sort(key=lambda f: -SEVERITY[f["severity"]])
    return {
        "asset": card.get("asset"),
        "verdict": verdict,
        "sheet": [w, h],
        "frame_size": [used[0].w, used[0].h],
        "frames": n,
        "colours": len(colours),
        "durations_ms": [round(d, 2) for d in durs[:n]] if durs else [],
        "findings": findings,
    }


def render_report(rep):
    lines = ["Asset: %s" % rep.get("asset"),
             "Verdict: %s" % rep["verdict"],
             "Sheet %dx%d, frame %dx%d, %d frame(s), %d colour(s)" % (
                 rep["sheet"][0], rep["sheet"][1], rep["frame_size"][0], rep["frame_size"][1],
                 rep["frames"], rep["colours"])]
    if not rep["findings"]:
        lines.append("No findings.")
    for f in rep["findings"]:
        where = " frames %s" % f["frames"] if f.get("frames") else ""
        lines.append("- [%s] %s: %s%s" % (f["severity"].upper(), f["code"], f["message"], where))
        if f["advice"]:
            lines.append("    fix: %s" % f["advice"])
    return "\n".join(lines)


# --------------------------------------------------------------------------- preview / palette / atlas / recipe

def preview(frames, scale=4, bg=(29, 32, 48), cols=None, gutter=1, gutter_rgb=(255, 0, 255)):
    """Lay frames out in a grid, each enlarged by an integer scale, with coloured gutters."""
    if not frames:
        raise PassError("nothing to preview")
    fw, fh = max(f.w for f in frames), max(f.h for f in frames)
    cols = cols or min(len(frames), 8)
    rows = (len(frames) + cols - 1) // cols
    W = cols * fw * scale + (cols + 1) * gutter
    H = rows * fh * scale + (rows + 1) * gutter
    out = [tuple(gutter_rgb) + (255,)] * (W * H)
    for i, f in enumerate(frames):
        ox = gutter + (i % cols) * (fw * scale + gutter)
        oy = gutter + (i // cols) * (fh * scale + gutter)
        for y in range(fh * scale):
            for x in range(fw * scale):
                sx, sy = x // scale, y // scale
                p = f.at(sx, sy) if sx < f.w and sy < f.h else (0, 0, 0, 0)
                a = p[3] / 255.0
                c = tuple(int(round(p[j] * a + bg[j] * (1 - a))) for j in range(3))
                out[(oy + y) * W + ox + x] = c + (255,)
    return W, H, out


def palette_rows(frames):
    hist = {}
    for f in frames:
        for p in f.pixels:
            if p[3]:
                hist[p[:3]] = hist.get(p[:3], 0) + 1
    return sorted(hist.items(), key=lambda kv: (rel_luminance(kv[0]), kv[0]))


def atlas_json(card, frames, image_name):
    durs = durations_for(card, frames) or [100.0] * len(frames)
    items = []
    for f, d in zip(frames, durs):
        items.append({"filename": "%s %d" % (card.get("asset") or "frame", f.index),
                      "frame": {"x": f.x, "y": f.y, "w": f.w, "h": f.h},
                      "rotated": False, "trimmed": False,
                      "spriteSourceSize": {"x": 0, "y": 0, "w": f.w, "h": f.h},
                      "sourceSize": {"w": f.w, "h": f.h},
                      "duration": int(round(d))})
    return {"frames": items,
            "meta": {"image": image_name, "format": "RGBA8888", "scale": "1",
                     "frameTags": [{"name": card.get("asset") or "anim", "from": 0, "to": len(frames) - 1,
                                    "direction": "forward"}],
                     "pivot": pivot_point(card)}}


def pivot_point(card):
    cw, ch = card.get("cell") or [0, 0]
    pv = card.get("pivot", "bottom-center")
    if isinstance(pv, list):
        return {"x": pv[0], "y": pv[1]}
    return {"bottom-center": {"x": cw // 2, "y": ch}, "center": {"x": cw // 2, "y": ch // 2},
            "top-left": {"x": 0, "y": 0}}.get(pv, {"x": cw // 2, "y": ch})


ENGINES = ("godot", "unity", "phaser", "gamemaker", "love", "defold", "css")


def recipe(card, engine=None):
    engine = (engine or card.get("engine") or "godot").lower()
    if engine not in ENGINES:
        raise PassError("engine must be one of %s" % ", ".join(ENGINES))
    cw, ch = card.get("cell") or [32, 32]
    fps = card.get("fps") or 12
    pv = pivot_point(card)
    loop = card.get("kind") == "loop"
    scale = card.get("display_scale") or 1
    name = card.get("asset") or "sprite"
    durs = [float(d) for d in (card.get("durations_ms") or [])]
    if durs:
        base = min(durs)
        fps = round(1000.0 / base, 2)
    r = []
    if engine == "godot":
        r += ["Godot 4",
              "- Project Settings > Rendering > Textures > Canvas Textures > Default Texture Filter: Nearest",
              "- Import dock for the PNG: Compress > Mode: Lossless, Mipmaps > Generate: off, then Reimport",
              "- AnimatedSprite2D > SpriteFrames > 'Add frames from sprite sheet': Horizontal/Vertical = sheet grid, size %dx%d" % (cw, ch),
              "- Animation speed: %s FPS, Loop: %s" % (fps, "on" if loop else "off"),
              "- Offset so the pivot (%d, %d) sits on the node origin: offset = (%d, %d) with Centered off"
              % (pv["x"], pv["y"], -pv["x"], -pv["y"]),
              "- Project Settings > Rendering > 2D > Snap 2D Transforms to Pixel: on; window stretch mode 'viewport', scale %s" % scale]
    elif engine == "unity":
        r += ["Unity (2D)",
              "- Texture Type: Sprite (2D and UI); Sprite Mode: Multiple; Pixels Per Unit: %d" % ch,
              "- Filter Mode: Point (no filter); Compression: None; Generate Mip Maps: off",
              "- Sprite Editor > Slice > Grid By Cell Size %dx%d; pivot Custom (%.3f, %.3f) in normalised units"
              % (cw, ch, pv["x"] / float(cw), 1 - pv["y"] / float(ch)),
              "- Animation clip sample rate %s, Loop Time %s" % (fps, "on" if loop else "off"),
              "- Camera: add Pixel Perfect Camera with Assets Pixels Per Unit = %d" % ch]
    elif engine == "phaser":
        r += ["Phaser 3",
              "- Game config: pixelArt: true (nearest filtering, no antialias), roundPixels: true",
              "- this.load.spritesheet('%s', '%s.png', { frameWidth: %d, frameHeight: %d });" % (name, name, cw, ch),
              "- this.anims.create({ key: '%s', frames: this.anims.generateFrameNumbers('%s'), frameRate: %s, repeat: %d });"
              % (name, name, fps, -1 if loop else 0),
              "- sprite.setOrigin(%.3f, %.3f) for the pivot" % (pv["x"] / float(cw), pv["y"] / float(ch)),
              "- Or load the atlas JSON from 'pixelpass.py atlas' with this.load.aseprite(...) to keep per-frame durations"]
    elif engine == "gamemaker":
        r += ["GameMaker",
              "- Import as strip: name the file %s_strip<N>.png or use Image > Convert to Frames with cell %dx%d" % (name, cw, ch),
              "- Sprite origin: Custom (%d, %d)" % (pv["x"], pv["y"]),
              "- Sprite speed: %s frames per second" % fps,
              "- Game Options > Graphics: 'Interpolate colours between pixels' off",
              "- Texture group: no compression; keep a 2 px border so neighbours do not bleed"]
    elif engine == "love":
        r += ["LÖVE",
              "- love.graphics.setDefaultFilter('nearest', 'nearest') before loading images",
              "- quads: love.graphics.newQuad(col*%d, row*%d, %d, %d, image:getDimensions())" % (cw, ch, cw, ch),
              "- draw with ox=%d, oy=%d so the pivot is the position; scale by an integer (%s)" % (pv["x"], pv["y"], scale),
              "- step frames on accumulated dt at %s fps (do not tie it to the display refresh)" % fps]
    elif engine == "defold":
        r += ["Defold",
              "- Tile Source: image = sheet, Tile Width %d, Tile Height %d, add an Animation with fps %s, playback %s"
              % (cw, ch, fps, "Loop Forward" if loop else "Once Forward"),
              "- game.project: graphics > default_texture_min_filter / mag_filter = nearest",
              "- Texture profile without compression for this atlas",
              "- Use a sprite position offset to place the pivot (%d, %d)" % (pv["x"], pv["y"])]
    else:
        r += ["CSS / HTML canvas",
              "- img, canvas { image-rendering: pixelated; }  (scale only by integers: %sx)" % scale,
              "- canvas: ctx.imageSmoothingEnabled = false before drawImage",
              "- CSS sprite: background-size = sheet size x %s, steps(%s) animation, %s"
              % (scale, card.get("frames") or "N", "infinite" if loop else "1 forwards")]
    if durs:
        r.append("- Per-frame durations (ms): %s -> base %s fps with frame multipliers %s"
                 % ([int(d) if d == int(d) else d for d in durs], fps,
                    [round(d / base, 2) for d in durs]))
    return "\n".join(r)


# --------------------------------------------------------------------------- CLI

def _load_inputs(args):
    w, h, pixels = read_png(args.image)
    card = load_card(args.card, {"cell": args.cell})
    meta = None
    if getattr(args, "frames_json", None):
        with open(args.frames_json, "r", encoding="utf-8") as fh:
            meta = json.load(fh)
    return w, h, pixels, card, meta


def _frames_for(w, h, pixels, card, meta):
    if meta is not None:
        return json_frames(w, h, pixels, meta)
    if card.get("cell"):
        frames, _ = grid_frames(w, h, pixels, card["cell"], card.get("margin", 0), card.get("spacing", 0))
        if card.get("frames"):
            frames = frames[:int(card["frames"])]
        return frames
    return [Frame(0, 0, 0, w, h, _crop(w, pixels, 0, 0, w, h))]


def main(argv=None):
    ap = argparse.ArgumentParser(prog="pixelpass.py", description="Delivery checks for pixel-art sprites and sheets.")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("card", help="print a starter pass card")
    for name in ("audit", "palette", "preview", "atlas"):
        p = sub.add_parser(name)
        p.add_argument("image")
        p.add_argument("--card")
        p.add_argument("--cell", help="override cell size, e.g. 32x32")
        p.add_argument("--frames-json", dest="frames_json", help="Aseprite-style JSON export")
        if name == "audit":
            p.add_argument("--json", action="store_true")
        if name == "palette":
            p.add_argument("--format", choices=("text", "hex", "gpl"), default="text")
        if name == "preview":
            p.add_argument("-o", "--out", required=True)
            p.add_argument("--scale", type=int, default=4)
            p.add_argument("--cols", type=int)
        if name == "atlas":
            p.add_argument("-o", "--out")
    p = sub.add_parser("recipe")
    p.add_argument("--card")
    p.add_argument("--engine")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "card":
            print(json.dumps(DEFAULT_CARD, indent=2))
            return 0
        if args.cmd == "recipe":
            print(recipe(load_card(args.card), args.engine))
            return 0
        if args.cmd is None:
            ap.print_help()
            return 3
        w, h, pixels, card, meta = _load_inputs(args)
        if args.cmd == "audit":
            rep = audit(w, h, pixels, card, meta)
            print(json.dumps(rep, indent=2) if args.json else render_report(rep))
            return {"SHIP": 0, "SHIP_WITH_NOTES": 0, "FIX": 1, "BLOCK": 2}[rep["verdict"]]
        frames = _frames_for(w, h, pixels, card, meta)
        if args.cmd == "palette":
            rows = palette_rows(frames)
            if args.format == "hex":
                print("\n".join(to_hex(c)[1:] for c, _ in rows))
            elif args.format == "gpl":
                print("GIMP Palette\nName: %s\nColumns: 8\n#" % (card.get("asset") or "palette"))
                for c, _ in rows:
                    print("%3d %3d %3d\t%s" % (c[0], c[1], c[2], to_hex(c)))
            else:
                for c, n in rows:
                    print("%s\t%d" % (to_hex(c), n))
            return 0
        if args.cmd == "preview":
            if args.scale < 1:
                raise PassError("scale must be a positive integer")
            bg = parse_hex(card.get("background") or "#1d2030")
            W, H, out = preview(frames, args.scale, bg, args.cols)
            with open(args.out, "wb") as fh:
                fh.write(encode_png(W, H, out))
            print("wrote %s (%dx%d, %d frame(s))" % (args.out, W, H, len(frames)))
            return 0
        if args.cmd == "atlas":
            data = atlas_json(card, frames, os.path.basename(args.image))
            text = json.dumps(data, indent=1)
            if args.out:
                with open(args.out, "w", encoding="utf-8") as fh:
                    fh.write(text)
                print("wrote %s (%d frames)" % (args.out, len(frames)))
            else:
                print(text)
            return 0
    except (PassError, OSError, KeyError, ValueError) as exc:
        print("error: %s" % exc, file=sys.stderr)
        return 3
    return 3


if __name__ == "__main__":
    sys.exit(main())
