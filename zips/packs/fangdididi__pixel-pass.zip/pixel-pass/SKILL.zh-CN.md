---
name: pixel-pass
description: 像素美术资源进游戏前的交付关卡，适用于精灵图、动画条、特效序列帧和瓦片集。先写一张验收卡（格子尺寸、帧数、调色板预算、透明规则、节奏、锚点、背景色、目标引擎），再用零依赖脚本审查真实导出的 PNG（网格是否对齐、空帧和重复帧、预先放大的图、颜色超预算或超出锁定调色板、几乎一样的“双胞胎色”、半透明光晕、孤立像素和杂点、脚底和重心漂移、循环首尾重帧与跳变、特效结尾突然消失、帧时长与游戏 tick 不整除、轮廓在背景上看不清），然后看放大的联系表，按严重程度修，最后用精确的最近邻设置导入 Godot、Unity、Phaser、GameMaker、LÖVE、Defold 或网页。当用户说“检查一下我的精灵表”“为什么像素图发糊/抖动/卡顿”“这张像素图能进引擎了吗”“帮我把这张图导入 Godot/Unity”，或 "check my sprite sheet / is this pixel art game-ready" 时使用。
---

# Pixel Pass（像素交付关）

> [English](SKILL.md) | **简体中文**

## 这是什么

像素图的大多数问题不是在画的时候发现的，而是进了游戏以后才冒出来：走路循环每圈卡一下；角色的脚在地面上上下浮动半个像素；编辑器里好好的，进游戏后边缘多了一圈淡灰色光晕；整张图导进去变成一团糊；AI 生成的“像素图”其实藏着 140 种颜色；爆炸特效不是淡出而是“啪”地消失；24 fps 的动画在 60 Hz 的游戏循环里一顿一顿。

Pixel Pass 是“图画完了”和“图进游戏了”之间一道简短、可重复的关卡。它不负责画图，只负责：拿成品导出文件对照一张写好的验收卡，准确指出哪里有问题、在哪一帧，再给出保持像素锐利的引擎导入设置。

1. **验收卡**：这个资源是什么、必须满足哪些规则。
2. **审查**：`scripts/pixelpass.py audit` 读取真实 PNG（有 Aseprite 风格 JSON 时一并读取），给出问题清单和结论：SHIP（可交付）、SHIP_WITH_NOTES（带备注交付）、FIX（需修复）、BLOCK（阻断）。
3. **人眼检查**：在游戏真实背景色上放大的联系表，加一份脚本判断不了的检查清单。
4. **修复循环**：每轮只修一类问题，先修最严重的，每轮修完重新审查。
5. **导入**：针对目标引擎的最近邻过滤、锚点和节奏设置；引擎需要时再生成图集 JSON。
6. **游戏内验证**：在真实缩放下截一张图、按真实速度播放一次，才算完成。

辅助脚本是单个 Python 3 文件，只用标准库。它自己解码 PNG（8/16 位，RGB、RGBA、灰度、带透明的索引色），所以只要智能体能跑 Python 就能用。

## 什么时候用

- 精灵表、动画条或特效序列帧马上要导入 Godot、Unity、Phaser、GameMaker、LÖVE、Defold 或网页 canvas。
- 图来自生图模型、缩小处理、格式转换或外包，你需要确认它是不是真正干净的像素图。
- “精灵发糊”“循环卡一下”“角色在抖”“周围有一圈白边/灰边”“颜色不在调色板里”。
- 游戏节提交或上架构建前，用同一套标准把所有动画资源扫一遍。

不适用：从零开始绘制或制作动画（先用绘图流程画好，再来这里过关）、厚涂或高分辨率 2D 美术、3D 贴图。

## 操作步骤

### 1. 写验收卡

运行 `python3 scripts/pixelpass.py card > card.json`，和美术负责人一起填。每个字段都是一个决定，不是猜测：

| 字段 | 含义 |
|---|---|
| `asset` | 简短名称，用于报告和图集 JSON |
| `subject` | `character`（角色）、`effect`（特效）、`prop`（道具）、`tile`（瓦片）或 `ui`；决定启用哪些检查 |
| `kind` | `loop`（循环）、`oneshot`（单次）或 `still`（静态） |
| `cell` | 原生像素下的帧尺寸，如 `[32, 32]`；图有边距/间隔时再填 `margin`、`spacing` |
| `frames` | 真实帧数；填 `null` 表示用到最后一个有内容的格子为止 |
| `fps` 或 `durations_ms` | 预期节奏；`tick_hz` 是游戏循环频率（通常 60） |
| `pivot` | `bottom-center`、`center`、`top-left` 或 `[x, y]` |
| `ground_anchored`、`in_place`、`drift_px` | 脚底是否应保持在同一行、身体是否应保持居中，以及允许几个像素的晃动 |
| `palette_max`、`palette_file` | 颜色预算；可选的锁定调色板（`.hex`、`.gpl` 或 JSON 列表） |
| `alpha` | `binary`（只有全透明和全不透明）或 `soft`（光、烟、玻璃） |
| `background` | 精灵在游戏里实际出现时的背景色 |
| `display_scale`、`engine` | 游戏中的整数放大倍数和目标引擎 |

负责人答不上来的字段，写明你用的默认值，并在报告里说明。

### 2. 拿到真实导出文件

审查引擎真正要加载的那个文件：编辑器或生成器直接导出的原尺寸 PNG，以及编辑器同时导出的 JSON。不要审查截图、聊天软件压缩过的副本或放大预览图——它们会凭空多出原文件里没有的颜色和软边。

### 3. 运行审查

```sh
python3 scripts/pixelpass.py audit sheet.png --card card.json            # 可读报告
python3 scripts/pixelpass.py audit sheet.png --card card.json --json     # 便于进一步处理
python3 scripts/pixelpass.py audit sheet.png --frames-json sheet.json --card card.json   # Aseprite 风格导出
```

退出码 0 表示 SHIP 或 SHIP_WITH_NOTES，1 表示 FIX，2 表示 BLOCK，3 表示输入无法读取。

检查项：

| 代码 | 严重度 | 含义 |
|---|---|---|
| GRID_MISFIT | block | 图的尺寸无法按声明的格子整除 |
| FRAME_COUNT | block | 声明帧数、JSON 帧数和实际有画的格子对不上 |
| OFF_PALETTE | block | 不在锁定调色板里的颜色，并给出每个颜色最近的合法色 |
| EMPTY_FRAME | fix | 动画中间出现空白帧（看起来像闪烁） |
| UPSCALED | fix | 每个像素都是 k×k 的色块：图被预先放大了，应该按原尺寸交付 |
| PALETTE_OVER | fix | 颜色数超过预算 |
| HALF_ALPHA | fix | 本应只有全透明/不透明的图里出现半透明像素 |
| LOOP_DOUBLE | fix | 最后一帧和第一帧一样，循环时这一帧会出现两次 |
| NON_INTEGER_SCALE | fix | 2.5 这类非整数放大倍数，会让像素大小不均 |
| NEAR_TWINS | warn | 两种几乎一样的颜色，通常是缩放或生成留下的残余 |
| SOFT_EDGE | warn | 软透明模式下，轮廓边缘半透明比例过高（有光晕风险） |
| DUST / SPECKLE | warn | 没有任何邻居的孤立像素，或平涂色块里格格不入的单个像素 |
| EDGE_TOUCH | warn | 图案贴到格子边缘（有渗色和被裁切的风险）；瓦片跳过此项 |
| DUP_FRAME | warn | 与前一帧完全相同的帧；应改为延长时长 |
| PIVOT_DRIFT / CENTER_DRIFT | warn | 脚底所在行或水平中心在帧之间移动 |
| LOOP_SEAM | warn | 末帧回到首帧的跳变远大于其它任何一步 |
| POPS_OFF | warn | 单次特效的最后一帧仍然画得满满的 |
| TICK_UNEVEN | warn | 帧时长不是游戏 tick 的整数倍（60 Hz 下的 24 fps、70 ms 帧） |
| LOW_READ | warn | 大部分轮廓边缘与背景的对比度低于 1.5:1 |
| TEXTURE_LIMIT | warn | 图的某一边超过 4096 像素 |
| UNUSED_CELLS / STILL_MULTI | info / warn | 末尾的空格子，或“静态”资源却有多帧 |

特效是刻意区别对待的：孤立像素就是正常的火星（只记 info，不算 warn），最后一帧为空才是正确的收尾，半透明也是预期之内。

### 4. 用自己的眼睛看

```sh
python3 scripts/pixelpass.py preview sheet.png --card card.json -o preview.png --scale 6
```

用看图工具打开 `preview.png`：所有帧按整数倍放大，铺在验收卡指定的背景色上，用洋红色分隔线隔开。也要看一次 1× 原尺寸。然后检查脚本判断不了的部分：

- **1× 剪影**：只看外形，能不能认出是什么、朝哪个方向？
- **光源统一**：每一帧都从同一侧打光，没有哪一帧光从反方向来。
- **线条**：像素台阶节奏均匀（1-1-1、2-2-2，或刻意的 1-2-1），没有意外的锯齿和双角。
- **像素大小混杂**：旋转或缩放过的部件会留下比正常像素更粗或更细的点。
- **明暗**：没有只会“往每条边压暗”的枕头式阴影；没有两条色阶平行排列造成的条带。
- **体积与一致性**：角色在每一帧里大小、比例和细节保持一致。
- **节奏**：大动作前有预备，有清晰的关键姿势，眼睛需要的地方有停顿。特效要快速亮起、较长时间淡出。

把看到的写下来。脚本通过不等于视觉通过，两者要分开报告。

### 5. 按顺序修

从报告顶部往下修：先 BLOCK，再 FIX，最后 WARN。每轮只修一类问题，修完重新审查，再看一次预览。常见修法：

- GRID_MISFIT / FRAME_COUNT：用固定格子重新导出，或修正卡片里的 `margin`、`spacing`、`frames`。
- UPSCALED：按 1× 导出，放大交给引擎。
- OFF_PALETTE / PALETTE_OVER / NEAR_TWINS：把每个杂色归并到最近的合法色（报告里列出了色对）；`palette` 命令可查看真实用到的颜色。
- HALF_ALPHA：按 50%（或 128）把透明度二值化，关键处的边缘手工重画。
- LOOP_DOUBLE：删掉最后一帧。LOOP_SEAM：加一张中间帧，或把最后一帧往首帧方向挪一半。
- DUP_FRAME：合并成一帧，延长时长。
- TICK_UNEVEN：选 tick 的整数倍作为时长（60 Hz 下：50、83.3、100、116.7、133.3、150 ms……），或 10、12、15、20、30 fps。
- PIVOT_DRIFT / CENTER_DRIFT：平移各帧，让脚底和身体对齐；刻意的弹跳或起跳可以带备注接受。
- LOW_READ：在面向背景的一侧加对比色描边或轮廓光，或使用选择性描边。

警告可以有意接受，但要在验收记录（第 8 步）里写明理由。绝不能通过修改验收卡让问题“消失”。

### 6. 用精确设置导入

```sh
python3 scripts/pixelpass.py recipe --card card.json --engine godot     # 或 unity、phaser、gamemaker、love、defold、css
python3 scripts/pixelpass.py atlas sheet.png --card card.json -o sheet.json
```

`recipe` 输出目标引擎的最近邻过滤、压缩、mipmap、切图、锚点和节奏设置；卡片里有 `durations_ms` 时还会给出每帧时长倍数。`atlas` 生成 Aseprite 风格的帧 JSON（帧矩形、时长、动画标签和锚点），给需要它的引擎和加载器使用。

### 7. 在游戏里验证

在真实场景、真实缩放下截一张图，并按真实速度播放动画。检查：发糊（过滤或压缩没关）、瓦片或帧之间出现细线（渗色；加间隔或外扩边缘）、镜头移动时闪烁（亚像素位置；打开像素对齐）、精灵站错位置（锚点）、以及玩家实际看到的循环或结尾。如果你跑不了游戏，就如实说明，不要声称游戏内检查已通过。

### 8. 验收记录

最后在资源旁边留一份简短记录（例如 `pass.md`）：验收卡、最终结论、每条被接受的警告及理由、视觉检查覆盖了什么、是否做了游戏内验证。有了它，下一个人不用重做一遍也能信任这张图。

## 示例

一个 4 帧的史莱姆跳跃，格子 16×16，验收卡写的是循环、24 fps、深色背景 `#1d2030`、预算 8 色、二值透明（文件在 `examples/`）：

```text
Verdict: FIX
Sheet 64x16, frame 16x16, 4 frame(s), 6 colour(s)
- [FIX] HALF_ALPHA: 4 semi-transparent pixel(s) in binary-alpha art
- [FIX] LOOP_DOUBLE: last frame equals the first frames [3]
- [WARN] NEAR_TWINS: 1 pair(s) of almost identical colours
- [WARN] TICK_UNEVEN: 4 frame duration(s) are not whole 16.67 ms ticks frames [0, 1, 2, 3]
- [WARN] LOW_READ: 100% of the silhouette edge is within 1.5:1 of #1d2030
```

第 1 轮把光晕像素二值化，删掉重复的末帧。第 2 轮把“双胞胎绿”并入身体色，把接近黑色的描边换成能在夜色背景上看清的深青色。第 3 轮把 24 fps 换成 100、100、150 ms（都是整数 tick，落地时稍作停顿）。重新审查结果为 `Verdict: SHIP`，`recipe --engine godot` 给出基准 10 fps、帧倍数 1、1、1.5 的导入设置。

## 小贴士

- 先确定背景色再判断对比度：在草地上清楚的精灵，到地牢里可能直接消失。
- 生图模型的输出很少是真正的像素图：UPSCALED、NEAR_TWINS、HALF_ALPHA、SPECKLE 往往一起出现。先用最近邻缩回真实网格，再吸附到调色板，最后手工清理。
- 停顿用延长时长实现，不要复制帧。图更小，节奏也更真实。
- 每个资源在仓库里配一张卡片；在 CI 里对改动过的 PNG 重新审查，能及时发现退步。
- 瓦片按“可重复的图”来判断：贴边是正常的，接缝最好在预览或引擎里拼 3×3 来看。
- 对某条警告拿不准时，看预览再决定：脚本负责指出，眼睛负责判断。
