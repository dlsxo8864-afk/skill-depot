[English](README.md) | **简体中文**

# Pixel Pass（像素交付关）

**像素精灵图、动画条、特效序列帧和瓦片集进游戏前的交付关卡：先写规则，再审真实 PNG，用眼睛看，按顺序修，最后用让每个像素保持锐利的设置导入引擎。**

像素图通常是在画完之后才出问题。走路循环每圈卡一下，因为最后一帧和第一帧重复了；主角在地面上一起一伏，因为第 3 帧的脚在另一行；浅色背景上出现一圈灰边，因为缩小时留下了半透明的边缘像素；导入后一片模糊，因为过滤和压缩没关；生图模型给的“8-bit 精灵”其实是 4 倍放大图，还有 140 种颜色；24 fps 的动画在 60 Hz 循环里一顿一顿，因为 41.7 ms 等于两个半 tick。

Pixel Pass 是一个智能体技能，在这些问题进游戏之前把它们拦下：

- **先写验收卡。** 格子尺寸、真实帧数、循环还是单次、节奏、锚点、颜色预算或锁定调色板、透明规则、实际出现时的背景色、显示倍数和目标引擎。
- **审查真实导出文件。** 零依赖脚本自己解码 PNG（以及 Aseprite 风格 JSON），给出 20 多项检查、对应帧号和结论：SHIP、SHIP_WITH_NOTES、FIX 或 BLOCK。
- **眼睛说了算。** 在游戏背景色上放大的联系表，加一份代码判断不了的检查清单：剪影、光源方向、线条质量、像素大小混杂、明暗、一致性、节奏。
- **按严重程度修，** 每轮只修一类问题，每轮重新审查，接受的警告要写明理由。
- **导入配方**，覆盖 Godot、Unity、Phaser、GameMaker、LÖVE、Defold 和 CSS/canvas：最近邻过滤、关闭压缩与 mipmap、切图、锚点、fps 和每帧时长倍数。另附图集 JSON 生成。
- **游戏内验证**：真实缩放、真实速度下确认后才算完成。

## 功能

| | |
|---|---|
| 自带 PNG 解码 | 8/16 位 RGB、RGBA、灰度、灰度+透明、带 tRNS 的索引色；支持全部五种行过滤 |
| 多种取帧方式 | 带边距和间隔的固定网格、横向动画条、Aseprite hash 或 array JSON（裁切帧自动还原） |
| 结构检查 | 网格对齐、声明帧数与实际帧数、空帧、重复帧、未用格子、贴格子边缘 |
| 像素检查 | 预先放大（k×k 色块）、颜色预算、锁定调色板及最近合法色、双胞胎色、二值透明违规、软边、孤立像素、色块内杂点 |
| 动作检查 | 脚底行漂移、水平中心漂移、循环首尾重帧、循环跳变、单次特效结尾突然消失 |
| 节奏检查 | 不是游戏 tick 整数倍的帧时长（如 60 Hz 下的 24 fps 或 70 ms） |
| 可读性检查 | 轮廓边缘与声明背景色的对比度 |
| 按类型区别对待 | 特效允许火星、半透明和空白末帧；瓦片允许贴边 |
| 工具 | `preview` 联系表 PNG、`palette`（文本、.hex、.gpl）、`atlas` JSON、按引擎输出 `recipe` |
| 零依赖 | Python 3.8+，仅标准库，不联网；83 个测试 |

## 安装

技能就是一个根目录带 `SKILL.md` 的文件夹，克隆到智能体读取技能的位置即可：

```sh
# Claude Code（个人）
git clone https://github.com/fangdididi/pixel-pass ~/.claude/skills/pixel-pass
# Claude Code（单个项目）
git clone https://github.com/fangdididi/pixel-pass .claude/skills/pixel-pass
# Codex CLI
git clone https://github.com/fangdididi/pixel-pass ~/.codex/skills/pixel-pass
# Cursor 及其他智能体：把文件夹放进 rules/skills 目录，
# 或让智能体直接读取 SKILL.md（英文）或 SKILL.zh-CN.md（中文）。
```

如果目标文件夹已存在，先看看里面是什么再决定是否覆盖。

## 使用

直接用自然语言提出需求：

```text
导入 Godot 之前帮我检查 assets/hero_run.png：格子 32x32，8 帧，循环，12 fps。
Check this slime sheet: it looks blurry in Unity and stutters every loop.
```

也可以自己运行辅助脚本：

```sh
python3 scripts/pixelpass.py card > card.json                       # 填写验收卡
python3 scripts/pixelpass.py audit sheet.png --card card.json       # 退出码 0 可交付，1 需修，2 阻断，3 输入错误
python3 scripts/pixelpass.py audit sheet.png --frames-json sheet.json --card card.json --json
python3 scripts/pixelpass.py preview sheet.png --card card.json -o preview.png --scale 6
python3 scripts/pixelpass.py palette sheet.png --card card.json --format gpl > used.gpl
python3 scripts/pixelpass.py recipe --card card.json --engine unity
python3 scripts/pixelpass.py atlas sheet.png --card card.json -o sheet.json
python3 -m unittest discover -s tests                               # 运行测试
```

## 示例

`examples/slime-hop.png`：4 帧 16×16，循环，24 fps，深色夜景背景，预算 8 色，二值透明。

```text
Verdict: FIX
Sheet 64x16, frame 16x16, 4 frame(s), 6 colour(s)
- [FIX] HALF_ALPHA: 4 semi-transparent pixel(s) in binary-alpha art
- [FIX] LOOP_DOUBLE: last frame equals the first frames [3]
- [WARN] NEAR_TWINS: 1 pair(s) of almost identical colours
- [WARN] TICK_UNEVEN: 4 frame duration(s) are not whole 16.67 ms ticks frames [0, 1, 2, 3]
- [WARN] LOW_READ: 100% of the silhouette edge is within 1.5:1 of #1d2030
```

修了三轮（二值化光晕并删掉重复帧；合并双胞胎绿色，把描边换成夜里也看得清的深青色；帧时长改为 100/100/150 ms）之后，`examples/slime-hop-fixed.png` 审查结果为 `Verdict: SHIP`，Godot 配方最后一行是：

```text
- Per-frame durations (ms): [100, 100, 150] -> base 10.0 fps with frame multipliers [1.0, 1.0, 1.5]
```

## 它不做什么

- 不画图、不做动画、不重绘。它告诉你修什么、在哪里修。
- 脚本通过不等于视觉通过，也不等于游戏内通过。技能把三者分开报告，绝不把其中一个当成另一个。
- 启发式检查（杂点、跳变、可读性）只指出可能的问题；有意为之的选择可以写明理由后接受。

## 文件结构

```text
pixel-pass/
├── SKILL.md                  # 技能说明（英文）
├── SKILL.zh-CN.md            # 技能说明（中文）
├── README.md
├── README.zh-CN.md
├── LICENSE                   # MIT
├── scripts/
│   └── pixelpass.py          # card / audit / preview / palette / atlas / recipe
├── tests/
│   └── test_pixelpass.py     # 83 个测试
└── examples/
    ├── card.json             # 问题版的验收卡
    ├── slime-hop.png         # 有问题的 4 帧循环
    ├── report.txt            # 它的审查报告
    ├── slime-hop-preview.png # 放大的联系表
    ├── card-fixed.json       # 使用逐帧时长的验收卡
    ├── slime-hop-fixed.png   # 修复后的 3 帧循环
    ├── report-fixed.txt      # SHIP
    └── slime-hop-fixed.json  # 图集 JSON
```

## 许可证

MIT © fangdididi
