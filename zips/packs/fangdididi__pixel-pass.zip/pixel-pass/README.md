**English** | [简体中文](README.zh-CN.md)

# Pixel Pass

**A delivery gate for pixel-art sprites, animation strips, effect sheets and tilesets: write the rules, audit the real PNG, look, fix in order, and import with settings that keep every pixel sharp.**

Pixel art usually breaks after it is drawn. The walk cycle hiccups once per loop because the last frame repeats the first. The hero bobs against the floor because the feet sit on a different row in frame 3. A grey halo appears on a light background because a downscale left semi-transparent edge pixels. The sheet imports blurry because filtering and compression were left on. An "8-bit" sprite from an image model turns out to be a 4× upscale with 140 colours. A 24 fps animation judders on a 60 Hz loop because 41.7 ms is two and a half ticks.

Pixel Pass is an agent skill that catches all of that before it reaches the game:

- **Pass card first.** Cell size, real frame count, loop or one-shot, timing, pivot, colour budget or locked palette, alpha rule, the background it will be seen on, display scale and engine.
- **Audit the real export.** A zero-dependency script reads the PNG itself (and Aseprite-style JSON) and reports 20+ checks with frame numbers and a verdict: SHIP, SHIP_WITH_NOTES, FIX or BLOCK.
- **Eyes stay in charge.** An enlarged contact sheet on the game's background, plus a short checklist for what code cannot judge: silhouette, light direction, line quality, mixed pixel sizes, shading, identity, timing.
- **Fix in severity order,** one class of problem per round, re-audit each time, accepted warnings written down with a reason.
- **Import recipes** for Godot, Unity, Phaser, GameMaker, LÖVE, Defold and CSS/canvas: nearest filtering, no compression or mipmaps, slicing, pivot, fps and per-frame duration multipliers. Plus an atlas JSON writer.
- **In-game proof** at real scale and real speed before anything is called done.

## Features

| | |
|---|---|
| Own PNG decoder | 8/16-bit RGB, RGBA, grey, grey+alpha, indexed with tRNS; all five row filters |
| Frames from anywhere | fixed grid with margin and spacing, horizontal strips, Aseprite hash or array JSON (trimmed frames restored) |
| Structure checks | grid fit, declared vs drawn frame count, empty frames, duplicate frames, unused cells, cell-border contact |
| Pixel checks | pre-scaled art (k×k blocks), colour budget, locked palette with nearest legal colour, near-twin colours, binary-alpha violations, soft edges, lone pixels, speckle inside shapes |
| Motion checks | feet-row drift, horizontal centre drift, loop double-frame, loop seam, one-shot effects that pop off |
| Timing check | durations that are not whole game ticks (e.g. 24 fps or 70 ms on 60 Hz) |
| Readability check | silhouette edge contrast against the declared background |
| Subject-aware | effects allow sparks, soft alpha and an empty final frame; tiles may touch their borders |
| Tools | `preview` contact sheet PNG, `palette` (text, .hex, .gpl), `atlas` JSON, `recipe` per engine |
| Zero dependencies | Python 3.8+, standard library only, no network; 83 tests |

## Install

The skill is a folder with `SKILL.md` at its root. Clone it where your agent looks for skills:

```sh
# Claude Code (personal)
git clone https://github.com/fangdididi/pixel-pass ~/.claude/skills/pixel-pass
# Claude Code (one project)
git clone https://github.com/fangdididi/pixel-pass .claude/skills/pixel-pass
# Codex CLI
git clone https://github.com/fangdididi/pixel-pass ~/.codex/skills/pixel-pass
# Cursor and other agents: put the folder in your rules/skills directory,
# or point the agent at SKILL.md (English) or SKILL.zh-CN.md (Chinese).
```

If the target folder already exists, look inside before overwriting it.

## Usage

Ask in plain words:

```text
Check assets/hero_run.png before I import it into Godot. 32x32 cells, 8 frames, loop, 12 fps.
这张史莱姆精灵表放进 Unity 后发糊还一顿一顿的，帮我查一下问题在哪。
```

Or run the helper yourself:

```sh
python3 scripts/pixelpass.py card > card.json                       # fill it in
python3 scripts/pixelpass.py audit sheet.png --card card.json       # exit 0 ship, 1 fix, 2 block, 3 bad input
python3 scripts/pixelpass.py audit sheet.png --frames-json sheet.json --card card.json --json
python3 scripts/pixelpass.py preview sheet.png --card card.json -o preview.png --scale 6
python3 scripts/pixelpass.py palette sheet.png --card card.json --format gpl > used.gpl
python3 scripts/pixelpass.py recipe --card card.json --engine unity
python3 scripts/pixelpass.py atlas sheet.png --card card.json -o sheet.json
python3 -m unittest discover -s tests                               # run the tests
```

## Example

`examples/slime-hop.png`: four 16×16 frames, loop at 24 fps on a dark night background, budget 8 colours, binary alpha.

```text
Verdict: FIX
Sheet 64x16, frame 16x16, 4 frame(s), 6 colour(s)
- [FIX] HALF_ALPHA: 4 semi-transparent pixel(s) in binary-alpha art
- [FIX] LOOP_DOUBLE: last frame equals the first frames [3]
- [WARN] NEAR_TWINS: 1 pair(s) of almost identical colours
- [WARN] TICK_UNEVEN: 4 frame duration(s) are not whole 16.67 ms ticks frames [0, 1, 2, 3]
- [WARN] LOW_READ: 100% of the silhouette edge is within 1.5:1 of #1d2030
```

After three rounds (threshold the halo and drop the repeated frame; merge the near-twin green and switch to a dark-teal outline that reads at night; time the frames at 100/100/150 ms), `examples/slime-hop-fixed.png` audits as `Verdict: SHIP`, and the Godot recipe ends with:

```text
- Per-frame durations (ms): [100, 100, 150] -> base 10.0 fps with frame multipliers [1.0, 1.0, 1.5]
```

## What it does not do

- It does not draw, animate or repaint. It tells you what to fix and where.
- A script pass is not a visual pass, and neither is an in-game pass. The skill reports all three separately and never upgrades one into another.
- Heuristics (speckle, seam, readability) point at likely problems; deliberate choices can be accepted with a written reason.

## File structure

```text
pixel-pass/
├── SKILL.md                  # the skill (English)
├── SKILL.zh-CN.md            # the skill (Chinese)
├── README.md
├── README.zh-CN.md
├── LICENSE                   # MIT
├── scripts/
│   └── pixelpass.py          # card / audit / preview / palette / atlas / recipe
├── tests/
│   └── test_pixelpass.py     # 83 tests
└── examples/
    ├── card.json             # pass card for the broken sheet
    ├── slime-hop.png         # 4-frame loop with problems
    ├── report.txt            # its audit
    ├── slime-hop-preview.png # enlarged contact sheet
    ├── card-fixed.json       # card with per-frame durations
    ├── slime-hop-fixed.png   # 3-frame loop after the fixes
    ├── report-fixed.txt      # SHIP
    └── slime-hop-fixed.json  # atlas JSON
```

## License

MIT © fangdididi
