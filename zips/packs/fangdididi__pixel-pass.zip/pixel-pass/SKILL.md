---
name: pixel-pass
description: Delivery gate for pixel-art sprites, animation strips, effect sheets and tilesets on their way into a game. Write a pass card (cell size, frame count, palette budget, alpha rule, timing, pivot, background, engine), audit the real exported PNG with a zero-dependency script (grid fit, empty/duplicate frames, pre-scaled art, palette over budget or off a locked palette, near-twin colours, soft alpha halos, lone and speckle pixels, feet and centre drift, loop double-frames and seams, effects that pop off, durations that do not fit the game tick, silhouettes that vanish on the background), look at an enlarged contact sheet, fix in severity order, then import with exact nearest-neighbour settings for Godot, Unity, Phaser, GameMaker, LÖVE, Defold or CSS. Use when someone says "check my sprite sheet", "why does my sprite look blurry / jitter / stutter", "is this pixel art ready for the engine", "import this sheet into Godot/Unity", or "检查像素图 / 精灵表 / 帧动画能不能进游戏".
---

# Pixel Pass

> **English** | [简体中文](SKILL.zh-CN.md)

## What this is

Most pixel-art problems are not discovered while drawing. They show up later, inside the game: a walk cycle that hiccups once per loop, a hero who bobs half a pixel against the floor, a faint grey halo around a sprite that looked fine in the editor, a sheet that imports as a blurry smear, an AI-generated sprite that secretly has 140 colours, an explosion that blinks out instead of fading, a 24 fps animation that judders on a 60 Hz game loop.

Pixel Pass is the short, repeatable gate between "the art is drawn" and "the art is in the game". It does not draw anything. It checks a finished export against a written card, shows you exactly what is wrong and where, and hands over the engine import settings that keep pixels sharp.

1. **Pass card**: what the asset is and the rules it must meet.
2. **Audit**: `scripts/pixelpass.py audit` reads the real PNG (and Aseprite-style JSON if there is one) and returns findings with a verdict: SHIP, SHIP_WITH_NOTES, FIX or BLOCK.
3. **Eyes**: an enlarged contact sheet on the game's own background, plus a checklist for the things a script cannot judge.
4. **Fix loop**: one class of problem per round, worst severity first, re-audit after each round.
5. **Import**: exact nearest-neighbour settings, pivot and timing for the target engine, and an atlas JSON when the engine wants one.
6. **In-game proof**: one screenshot at the real scale and one playback at real speed before calling it done.

The helper is a single Python 3 file, standard library only. It decodes PNG itself (8/16-bit, RGB, RGBA, grey, indexed with transparency), so it runs anywhere an agent has Python.

## When to use it

- A sprite sheet, animation strip or effect sheet is about to go into Godot, Unity, Phaser, GameMaker, LÖVE, Defold or a web canvas.
- Art came from an image model, a downscale, a converter or a contractor, and you need to know whether it is really clean pixel art.
- "My sprite looks blurry", "the loop stutters", "the character jitters", "there is a white/grey outline around it", "the colours are off-palette".
- Before a jam submission or a store build, to sweep every animated asset the same way.

Not for: drawing or animating from scratch (use a drawing workflow first, then come here), painterly or high-resolution 2D art, 3D textures.

## Step by step

### 1. Write the pass card

Run `python3 scripts/pixelpass.py card > card.json` and fill it in with the person who owns the art. Every field is a decision, not a guess:

| field | meaning |
|---|---|
| `asset` | a short name, used in reports and atlas JSON |
| `subject` | `character`, `effect`, `prop`, `tile` or `ui`; changes which checks apply |
| `kind` | `loop`, `oneshot` or `still` |
| `cell` | frame size in native pixels, e.g. `[32, 32]`; `margin` and `spacing` if the sheet has gutters |
| `frames` | the real frame count; leave `null` to use everything up to the last drawn cell |
| `fps` or `durations_ms` | the intended timing; `tick_hz` is the game loop rate (usually 60) |
| `pivot` | `bottom-center`, `center`, `top-left` or `[x, y]` |
| `ground_anchored`, `in_place`, `drift_px` | whether feet should stay on one row and the body should stay centred, and how many pixels of wobble are allowed |
| `palette_max`, `palette_file` | colour budget, and optionally a locked palette (`.hex`, `.gpl` or JSON list) |
| `alpha` | `binary` (only fully clear or fully solid) or `soft` (glows, smoke, glass) |
| `background` | the colour the sprite will actually be seen on |
| `display_scale`, `engine` | the integer zoom in the game and the target engine |

If the owner cannot answer a field, write down the default you used and say so in the report.

### 2. Get the real export

Audit the file the engine will load: the native-size PNG straight from the editor or generator, plus its JSON if the editor writes one. Never audit a screenshot, a chat-compressed copy or an enlarged preview; they invent colours and soft edges that are not in the real file.

### 3. Run the audit

```sh
python3 scripts/pixelpass.py audit sheet.png --card card.json            # readable report
python3 scripts/pixelpass.py audit sheet.png --card card.json --json     # for further processing
python3 scripts/pixelpass.py audit sheet.png --frames-json sheet.json --card card.json   # Aseprite-style export
```

Exit code 0 means SHIP or SHIP_WITH_NOTES, 1 means FIX, 2 means BLOCK, 3 means the input could not be read.

What it checks:

| code | severity | what it means |
|---|---|---|
| GRID_MISFIT | block | the sheet size does not divide into the declared cells |
| FRAME_COUNT | block | declared frames, JSON frames and drawn cells disagree |
| OFF_PALETTE | block | colours that are not in the locked palette, each with its nearest legal colour |
| EMPTY_FRAME | fix | a blank frame inside the animation (reads as a flicker) |
| UPSCALED | fix | every pixel is a k×k block: the art was pre-scaled and should ship at native size |
| PALETTE_OVER | fix | more colours than the budget |
| HALF_ALPHA | fix | semi-transparent pixels in art that should be binary-alpha |
| LOOP_DOUBLE | fix | the last frame repeats the first, so the loop shows it twice |
| NON_INTEGER_SCALE | fix | a display scale like 2.5 that makes pixels uneven |
| NEAR_TWINS | warn | two colours almost identical, usually resampling or generation leftovers |
| SOFT_EDGE | warn | in soft-alpha art, too much of the silhouette edge is translucent (halo risk) |
| DUST / SPECKLE | warn | lone pixels with no neighbours, or odd-one-out pixels inside flat shapes |
| EDGE_TOUCH | warn | art touches the cell border (bleeding and clipping risk); skipped for tiles |
| DUP_FRAME | warn | a frame identical to the one before it; use a longer duration instead |
| PIVOT_DRIFT / CENTER_DRIFT | warn | the feet row or the horizontal centre moves between frames |
| LOOP_SEAM | warn | the wrap from last to first frame is a much bigger jump than any other step |
| POPS_OFF | warn | a one-shot effect whose last frame is still mostly drawn |
| TICK_UNEVEN | warn | a frame duration that is not a whole number of game ticks (24 fps on 60 Hz, 70 ms frames) |
| LOW_READ | warn | most of the silhouette edge is within 1.5:1 contrast of the background |
| TEXTURE_LIMIT | warn | a sheet over 4096 px on one side |
| UNUSED_CELLS / STILL_MULTI | info / warn | trailing blank cells, or several frames on a "still" asset |

Effects are treated differently on purpose: lone pixels are normal sparks (info, not warn), an empty last frame is the correct ending, and soft alpha is expected.

### 4. Look with your own eyes

```sh
python3 scripts/pixelpass.py preview sheet.png --card card.json -o preview.png --scale 6
```

Open `preview.png` with your image viewer. It lays the frames out on the card's background with magenta gutters, enlarged by an integer factor. Also look once at 1× scale. Then check what the script cannot:

- **Silhouette at 1×**: can you tell what it is and which way it faces from the shape alone?
- **One light direction** across every frame; no frame lit from the other side.
- **Lines**: runs step evenly (1-1-1, 2-2-2, 1-2-1 by design), no accidental jaggies or doubled corners.
- **Mixed pixel sizes**: a rotated or scaled part leaves fat or thin pixels next to normal ones.
- **Shading**: no "pillow" shading that just darkens toward every edge; no banding where two ramps run in parallel lines.
- **Volume and identity**: the character keeps the same size, proportions and details in every frame.
- **Timing**: anticipation before big moves, a clear key pose, a hold where the eye needs it. For effects: a fast bright start and a longer fade.

Write down what you saw. A script pass is not a visual pass; report both separately.

### 5. Fix in order

Work from the top of the report down: BLOCK, then FIX, then WARN. Fix one class of problem per round, re-run the audit, and look at the preview again. Typical fixes:

- GRID_MISFIT / FRAME_COUNT: re-export with a fixed cell, or correct `margin`, `spacing` and `frames` in the card.
- UPSCALED: export at 1×; let the engine scale.
- OFF_PALETTE / PALETTE_OVER / NEAR_TWINS: snap each stray colour to its nearest legal colour (the report lists the pairs); `palette` shows what is really used.
- HALF_ALPHA: threshold alpha at 50% (or 128) and repaint the edge by hand where it matters.
- LOOP_DOUBLE: drop the last frame. LOOP_SEAM: add an in-between or move the last frame halfway back toward the first.
- DUP_FRAME: merge into one frame with a longer duration.
- TICK_UNEVEN: pick durations that are whole ticks (at 60 Hz: 50, 83.3, 100, 116.7, 133.3, 150 ms...), or 10, 12, 15, 20, 30 fps.
- PIVOT_DRIFT / CENTER_DRIFT: shift the frames so the feet and the body line up; a deliberate bounce or jump can be accepted with a note.
- LOW_READ: add a contrasting outline or rim on the side that faces the background, or a selective outline.

A warning may be accepted on purpose. Write the reason next to it in the pass ledger (step 8). Never "fix" a finding by changing the card to make it disappear.

### 6. Import with exact settings

```sh
python3 scripts/pixelpass.py recipe --card card.json --engine godot     # or unity, phaser, gamemaker, love, defold, css
python3 scripts/pixelpass.py atlas sheet.png --card card.json -o sheet.json
```

`recipe` prints the nearest-neighbour filter, compression, mipmap, slicing, pivot and timing settings for the engine, including per-frame duration multipliers when the card has `durations_ms`. `atlas` writes an Aseprite-style frames JSON (frame rects, durations, a frame tag and the pivot) for engines and loaders that read one.

### 7. Prove it in the game

Take one screenshot of the asset in the real scene at the real scale and play the animation at real speed. Check for: blur (a filter or compression was left on), thin lines between tiles or frames (bleeding; add spacing or extrude), shimmering while the camera moves (sub-pixel positions; turn on pixel snapping), the sprite standing in the wrong place (pivot), and the loop or ending as the player will see it. If you cannot run the game, say so; do not claim the in-game check passed.

### 8. Pass ledger

Close with a short record next to the asset (for example `pass.md`): the card, the final verdict, each accepted warning with its reason, what the visual check covered, and whether the in-game proof was done. This is what lets the next person trust the sheet without redoing the work.

## Example

A four-frame slime hop, 16×16 cells, card says loop at 24 fps on a dark `#1d2030` background, budget 8 colours, binary alpha (files in `examples/`):

```text
Verdict: FIX
Sheet 64x16, frame 16x16, 4 frame(s), 6 colour(s)
- [FIX] HALF_ALPHA: 4 semi-transparent pixel(s) in binary-alpha art
- [FIX] LOOP_DOUBLE: last frame equals the first frames [3]
- [WARN] NEAR_TWINS: 1 pair(s) of almost identical colours
- [WARN] TICK_UNEVEN: 4 frame duration(s) are not whole 16.67 ms ticks frames [0, 1, 2, 3]
- [WARN] LOW_READ: 100% of the silhouette edge is within 1.5:1 of #1d2030
```

Round 1 thresholds the halo pixels and drops the repeated last frame. Round 2 merges the near-twin green into the body colour and swaps the near-black outline for a dark teal that reads on the night background. Round 3 replaces 24 fps with durations of 100, 100 and 150 ms (whole ticks, with a short hold on the landing). The re-audit says `Verdict: SHIP`, and `recipe --engine godot` gives the import settings with a base of 10 fps and frame multipliers 1, 1, 1.5.

## Tips

- Decide the background before judging contrast; a sprite that reads on grass can vanish in a dungeon.
- Image-model output is rarely true pixel art: expect UPSCALED, NEAR_TWINS, HALF_ALPHA and SPECKLE together. Downscale to the real grid with nearest-neighbour, then snap to a palette, then clean by hand.
- A hold is a longer duration, not a copied frame. It keeps sheets small and timing honest.
- Keep one card per asset in the repo; re-running the audit in CI on changed PNGs catches regressions.
- Tiles are judged as repeating images: border contact is expected, and seams are best checked by viewing a 3×3 repeat in the preview or engine.
- When in doubt about a warning, look at the preview and decide; the script points, your eyes judge.
