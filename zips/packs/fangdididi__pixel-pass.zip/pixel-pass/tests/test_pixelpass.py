import io
import json
import os
import struct
import sys
import tempfile
import unittest
import zlib
from contextlib import redirect_stdout, redirect_stderr

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "scripts"))
import pixelpass as pp  # noqa: E402

T = (0, 0, 0, 0)
K = (20, 16, 30, 255)     # outline
G = (90, 200, 120, 255)   # body
L = (190, 250, 200, 255)  # highlight
R = (220, 60, 60, 255)


def sprite(rows, legend=None):
    legend = legend or {".": T, "k": K, "g": G, "l": L, "r": R}
    return [legend[c] for row in rows for c in row], len(rows[0]), len(rows)


def sheet(frames_rows, legend=None):
    """Lay frames (list of row lists) side by side into one strip."""
    fw, fh = len(frames_rows[0][0]), len(frames_rows[0])
    w, h = fw * len(frames_rows), fh
    px = [T] * (w * h)
    for i, rows in enumerate(frames_rows):
        p, _, _ = sprite(rows, legend)
        for y in range(fh):
            for x in range(fw):
                px[y * w + i * fw + x] = p[y * fw + x]
    return w, h, px


BLOB = [
    "........",
    "..kkkk..",
    ".kgglgk.",
    ".kggggk.",
    ".kggggk.",
    "..kkkk..",
    "........",
    "........",
]
BLOB2 = [
    "........",
    "........",
    ".kkkkkk.",
    "kgggglgk",
    "kggggggk",
    ".kkkkkk.",
    "........",
    "........",
]
BLOB3 = [
    "........",
    "..kkkk..",
    "..kglk..",
    ".kggggk.",
    ".kggggk.",
    "..kkkk..",
    "........",
    "........",
]
EMPTY = ["........"] * 8


def write(path, data, mode="w"):
    with open(path, mode) as fh:
        fh.write(data)


def read(path):
    with open(path) as fh:
        return fh.read()


def card(**kw):
    c = pp.load_card(None, {})
    c.update({"cell": [8, 8], "background": "#ffffff", "palette_max": 16, "fps": 15})
    c.update(kw)
    return c


def codes(rep):
    return [f["code"] for f in rep["findings"]]


def png_chunk(kind, body):
    return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF)


def make_png(w, h, ctype, depth, rows_bytes, plte=None, trns=None, filters=None, interlace=0):
    raw = b""
    for i, r in enumerate(rows_bytes):
        raw += bytes([filters[i] if filters else 0]) + r
    out = pp.PNG_SIG + png_chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, depth, ctype, 0, 0, interlace))
    if plte:
        out += png_chunk(b"PLTE", plte)
    if trns:
        out += png_chunk(b"tRNS", trns)
    return out + png_chunk(b"IDAT", zlib.compress(raw)) + png_chunk(b"IEND", b"")


class PngTests(unittest.TestCase):
    def test_roundtrip_rgba(self):
        px = [(1, 2, 3, 4), (250, 0, 10, 255), (0, 0, 0, 0), (9, 9, 9, 128)]
        w, h, back = pp.decode_png(pp.encode_png(2, 2, px))
        self.assertEqual((w, h), (2, 2))
        self.assertEqual(back, px)

    def test_bad_signature(self):
        with self.assertRaises(pp.PassError):
            pp.decode_png(b"GIF89a....")

    def test_rgb_with_trns_colour_key(self):
        data = make_png(2, 1, 2, 8, [bytes([255, 0, 255, 10, 20, 30])], trns=struct.pack(">HHH", 255, 0, 255))
        _, _, px = pp.decode_png(data)
        self.assertEqual(px[0][3], 0)
        self.assertEqual(px[1], (10, 20, 30, 255))

    def test_indexed_with_alpha(self):
        plte = bytes([0, 0, 0, 255, 0, 0])
        data = make_png(2, 1, 3, 8, [bytes([0, 1])], plte=plte, trns=bytes([0]))
        _, _, px = pp.decode_png(data)
        self.assertEqual(px, [(0, 0, 0, 0), (255, 0, 0, 255)])

    def test_indexed_4bit(self):
        plte = bytes([0, 0, 0, 10, 20, 30, 40, 50, 60])
        data = make_png(3, 1, 3, 4, [bytes([0x12, 0x00])], plte=plte)
        _, _, px = pp.decode_png(data)
        self.assertEqual(px, [(10, 20, 30, 255), (40, 50, 60, 255), (0, 0, 0, 255)])

    def test_gray_1bit(self):
        data = make_png(4, 1, 0, 1, [bytes([0b10100000])])
        _, _, px = pp.decode_png(data)
        self.assertEqual([p[0] for p in px], [255, 0, 255, 0])

    def test_gray_alpha(self):
        data = make_png(1, 1, 4, 8, [bytes([100, 50])])
        _, _, px = pp.decode_png(data)
        self.assertEqual(px, [(100, 100, 100, 50)])

    def test_16bit_rgba_takes_high_byte(self):
        data = make_png(1, 1, 6, 16, [bytes([200, 1, 100, 2, 50, 3, 255, 255])])
        _, _, px = pp.decode_png(data)
        self.assertEqual(px, [(200, 100, 50, 255)])

    def test_filters_sub_up_avg_paeth(self):
        # two rows of RGBA, second row uses each filter in turn; check against plain encoding
        row0 = bytes([10, 20, 30, 255, 40, 50, 60, 255])
        row1 = bytes([12, 22, 32, 255, 44, 54, 64, 255])
        plain = make_png(2, 2, 6, 8, [row0, row1])
        _, _, ref = pp.decode_png(plain)
        # Sub on row0
        sub = bytes(row0[:4]) + bytes((row0[i] - row0[i - 4]) & 255 for i in range(4, 8))
        up = bytes((row1[i] - row0[i]) & 255 for i in range(8))
        avg = bytes((row1[i] - (((row1[i - 4] if i >= 4 else 0) + row0[i]) >> 1)) & 255 for i in range(8))
        def paeth_row(cur, prev):
            out = []
            for i in range(8):
                a = cur[i - 4] if i >= 4 else 0
                c = prev[i - 4] if i >= 4 else 0
                out.append((cur[i] - pp._paeth(a, prev[i], c)) & 255)
            return bytes(out)
        for f1, r1 in ((2, up), (3, avg), (4, paeth_row(row1, row0))):
            data = make_png(2, 2, 6, 8, [sub, r1], filters=[1, f1])
            _, _, px = pp.decode_png(data)
            self.assertEqual(px, ref, "filter %d" % f1)

    def test_interlaced_rejected(self):
        data = make_png(1, 1, 6, 8, [bytes(4)], interlace=1)
        with self.assertRaises(pp.PassError):
            pp.decode_png(data)

    def test_truncated(self):
        data = pp.PNG_SIG + png_chunk(b"IHDR", struct.pack(">IIBBBBB", 4, 4, 8, 6, 0, 0, 0)) + \
            png_chunk(b"IDAT", zlib.compress(b"\x00\x00")) + png_chunk(b"IEND", b"")
        with self.assertRaises(pp.PassError):
            pp.decode_png(data)


class ColourTests(unittest.TestCase):
    def test_parse_hex_short_and_long(self):
        self.assertEqual(pp.parse_hex("#fff"), (255, 255, 255))
        self.assertEqual(pp.parse_hex("1d2030"), (29, 32, 48))

    def test_parse_hex_bad(self):
        with self.assertRaises(pp.PassError):
            pp.parse_hex("#ggg")

    def test_contrast_black_white(self):
        self.assertAlmostEqual(pp.contrast((0, 0, 0), (255, 255, 255)), 21.0, places=1)

    def test_distance_zero_and_order(self):
        self.assertEqual(pp.colour_distance((5, 5, 5), (5, 5, 5)), 0)
        self.assertLess(pp.colour_distance((100, 100, 100), (102, 101, 100)),
                        pp.colour_distance((100, 100, 100), (180, 100, 100)))

    def test_palette_file_formats(self):
        d = tempfile.mkdtemp()
        hexf = os.path.join(d, "p.hex")
        write(hexf, "ff0000\n#00ff00\n\n")
        gpl = os.path.join(d, "p.gpl")
        write(gpl, "GIMP Palette\nName: x\nColumns: 4\n#\n  0   0 255\tblue\n")
        js = os.path.join(d, "p.json")
        write(js, '["#123456"]')
        self.assertEqual(pp.load_palette_file(hexf), [(255, 0, 0), (0, 255, 0)])
        self.assertEqual(pp.load_palette_file(gpl), [(0, 0, 255)])
        self.assertEqual(pp.load_palette_file(js), [(0x12, 0x34, 0x56)])

    def test_empty_palette_file(self):
        d = tempfile.mkdtemp()
        f = os.path.join(d, "e.hex")
        write(f, "GIMP Palette\n")
        with self.assertRaises(pp.PassError):
            pp.load_palette_file(f)


class CardTests(unittest.TestCase):
    def test_defaults(self):
        c = pp.load_card()
        self.assertEqual(c["cell"], [32, 32])
        self.assertEqual(c["alpha"], "binary")

    def test_cell_string_override(self):
        self.assertEqual(pp.load_card(None, {"cell": "16x24"})["cell"], [16, 24])

    def test_bad_subject(self):
        with self.assertRaises(pp.PassError):
            pp.load_card(None, {"subject": "dragon"})

    def test_bad_kind(self):
        with self.assertRaises(pp.PassError):
            pp.load_card(None, {"kind": "pingpong"})

    def test_bad_alpha(self):
        with self.assertRaises(pp.PassError):
            pp.load_card(None, {"alpha": "maybe"})

    def test_card_file_merges(self):
        d = tempfile.mkdtemp()
        f = os.path.join(d, "c.json")
        write(f, json.dumps({"asset": "x", "cell": [8, 8]}))
        c = pp.load_card(f)
        self.assertEqual((c["asset"], c["cell"], c["fps"]), ("x", [8, 8], 12))


class GridTests(unittest.TestCase):
    def test_grid_fits(self):
        w, h, px = sheet([BLOB, BLOB2])
        frames, misfit = pp.grid_frames(w, h, px, [8, 8])
        self.assertEqual((len(frames), misfit), (2, []))
        self.assertEqual(frames[1].x, 8)

    def test_grid_misfit(self):
        w, h, px = sheet([BLOB, BLOB2])
        _, misfit = pp.grid_frames(w, h, px, [6, 8])
        self.assertTrue(misfit)

    def test_grid_margin_spacing(self):
        frames, misfit = pp.grid_frames(2 * 1 + 8 * 2 + 1, 2 + 8, [T] * (19 * 10), [8, 8], margin=1, spacing=1)
        self.assertEqual((len(frames), misfit), (2, []))
        self.assertEqual(frames[1].x, 10)

    def test_audit_misfit_blocks(self):
        w, h, px = sheet([BLOB, BLOB2])
        rep = pp.audit(w, h, px, card(cell=[6, 8]))
        self.assertEqual(rep["verdict"], "BLOCK")
        self.assertIn("GRID_MISFIT", codes(rep))

    def test_cell_bigger_than_image(self):
        w, h, px = sheet([BLOB])
        with self.assertRaises(pp.PassError):
            pp.audit(w, h, px, card(cell=[16, 16]))


class FrameCountTests(unittest.TestCase):
    def test_trailing_empty_cells_info(self):
        w, h, px = sheet([BLOB, BLOB3, EMPTY, EMPTY])
        rep = pp.audit(w, h, px, card(kind="loop"))
        self.assertEqual(rep["frames"], 2)
        self.assertIn("UNUSED_CELLS", codes(rep))

    def test_declared_more_than_cells(self):
        w, h, px = sheet([BLOB, BLOB3])
        rep = pp.audit(w, h, px, card(frames=5))
        self.assertIn("FRAME_COUNT", codes(rep))
        self.assertEqual(rep["verdict"], "BLOCK")

    def test_drawn_beyond_declared(self):
        w, h, px = sheet([BLOB, BLOB3, BLOB])
        rep = pp.audit(w, h, px, card(frames=2))
        self.assertIn("FRAME_COUNT", codes(rep))

    def test_empty_frame_inside(self):
        w, h, px = sheet([BLOB, EMPTY, BLOB3])
        rep = pp.audit(w, h, px, card())
        f = [x for x in rep["findings"] if x["code"] == "EMPTY_FRAME"][0]
        self.assertEqual(f["frames"], [1])

    def test_effect_may_end_empty(self):
        w, h, px = sheet([BLOB, BLOB2, EMPTY])
        rep = pp.audit(w, h, px, card(subject="effect", kind="oneshot", frames=3))
        self.assertNotIn("EMPTY_FRAME", codes(rep))
        self.assertNotIn("POPS_OFF", codes(rep))

    def test_dup_frame(self):
        w, h, px = sheet([BLOB, BLOB, BLOB3])
        rep = pp.audit(w, h, px, card(kind="oneshot"))
        self.assertIn("DUP_FRAME", codes(rep))

    def test_still_multi(self):
        w, h, px = sheet([BLOB, BLOB3])
        self.assertIn("STILL_MULTI", codes(pp.audit(w, h, px, card(kind="still"))))


class PixelTests(unittest.TestCase):
    def test_clean_still_ships(self):
        w, h, px = sheet([BLOB])
        rep = pp.audit(w, h, px, card(kind="still"))
        self.assertEqual(rep["verdict"], "SHIP", rep["findings"])

    def test_edge_touch(self):
        w, h, px = sheet([BLOB2])
        rep = pp.audit(w, h, px, card(kind="still"))
        self.assertIn("EDGE_TOUCH", codes(rep))

    def test_edge_touch_ignored_for_tiles(self):
        w, h, px = sheet([BLOB2])
        rep = pp.audit(w, h, px, card(kind="still", subject="tile"))
        self.assertNotIn("EDGE_TOUCH", codes(rep))

    def test_upscaled_detected(self):
        p, _, _ = sprite(BLOB)
        big = []
        for y in range(16):
            for x in range(16):
                big.append(p[(y // 2) * 8 + x // 2])
        rep = pp.audit(16, 16, big, card(kind="still", cell=[16, 16]))
        f = [x for x in rep["findings"] if x["code"] == "UPSCALED"][0]
        self.assertEqual(f["detail"]["factor"], 2)

    def test_native_not_upscaled(self):
        w, h, px = sheet([BLOB])
        self.assertEqual(pp.detect_upscale(pp.grid_frames(w, h, px, [8, 8])[0]), 1)

    def test_palette_over(self):
        w, h, px = sheet([BLOB])
        rep = pp.audit(w, h, px, card(kind="still", palette_max=2))
        self.assertIn("PALETTE_OVER", codes(rep))

    def test_off_palette_blocks(self):
        d = tempfile.mkdtemp()
        f = os.path.join(d, "p.hex")
        write(f, "14101e\n5ac878\n")
        w, h, px = sheet([BLOB])
        rep = pp.audit(w, h, px, card(kind="still", palette_file=f))
        off = [x for x in rep["findings"] if x["code"] == "OFF_PALETTE"][0]
        self.assertEqual(off["detail"][0]["colour"], "#befac8")
        self.assertEqual(rep["verdict"], "BLOCK")

    def test_near_twins(self):
        legend = {".": T, "k": K, "g": G, "l": (92, 201, 121, 255), "r": R}
        w, h, px = sheet([BLOB], legend)
        self.assertIn("NEAR_TWINS", codes(pp.audit(w, h, px, card(kind="still"))))

    def test_half_alpha_binary(self):
        legend = {".": T, "k": (20, 16, 30, 140), "g": G, "l": L}
        w, h, px = sheet([BLOB], legend)
        rep = pp.audit(w, h, px, card(kind="still"))
        self.assertIn("HALF_ALPHA", codes(rep))
        self.assertEqual(rep["verdict"], "FIX")

    def test_soft_edge_warn_in_soft_mode(self):
        legend = {".": T, "k": (20, 16, 30, 140), "g": G, "l": L}
        w, h, px = sheet([BLOB], legend)
        rep = pp.audit(w, h, px, card(kind="still", alpha="soft"))
        self.assertIn("SOFT_EDGE", codes(rep))
        self.assertNotIn("HALF_ALPHA", codes(rep))

    def test_dust_warn_for_character_info_for_effect(self):
        rows = list(BLOB)
        rows[7] = "......r."
        w, h, px = sheet([rows])
        d1 = [x for x in pp.audit(w, h, px, card(kind="still"))["findings"] if x["code"] == "DUST"][0]
        d2 = [x for x in pp.audit(w, h, px, card(kind="still", subject="effect"))["findings"] if x["code"] == "DUST"][0]
        self.assertEqual((d1["severity"], d2["severity"]), ("warn", "info"))

    def test_speckle(self):
        rows = ["kkkkkkkk"] + ["kggggggk"] * 6 + ["kkkkkkkk"]
        rows = [list(r) for r in rows]
        for (x, y) in ((2, 2), (5, 2), (2, 5), (5, 5)):
            rows[y][x] = "l"
        rows = ["".join(r) for r in rows]
        w, h, px = sheet([rows])
        rep = pp.audit(w, h, px, card(kind="still", subject="tile"))
        self.assertIn("SPECKLE", codes(rep))

    def test_dither_is_not_speckle(self):
        rows = ["kkkkkkkk"] + [("k" + ("gl" * 4)[i % 2:i % 2 + 6] + "k") for i in range(6)] + ["kkkkkkkk"]
        w, h, px = sheet([rows])
        rep = pp.audit(w, h, px, card(kind="still", subject="tile"))
        self.assertNotIn("SPECKLE", codes(rep))

    def test_low_read_on_dark_background(self):
        w, h, px = sheet([BLOB])
        rep = pp.audit(w, h, px, card(kind="still", background="#140f1d"))
        self.assertIn("LOW_READ", codes(rep))
        rep2 = pp.audit(w, h, px, card(kind="still", background="#ffffff"))
        self.assertNotIn("LOW_READ", codes(rep2))

    def test_non_integer_scale(self):
        w, h, px = sheet([BLOB])
        self.assertIn("NON_INTEGER_SCALE", codes(pp.audit(w, h, px, card(kind="still", display_scale=2.5))))

    def test_texture_limit(self):
        px = [T] * (4100 * 1)
        rep = pp.audit(4100, 1, px, card(kind="still", cell=None))
        self.assertIn("TEXTURE_LIMIT", codes(rep))


class MotionTests(unittest.TestCase):
    def test_pivot_drift(self):
        low = ["........"] + BLOB[:7]
        w, h, px = sheet([BLOB, low, BLOB3])
        rep = pp.audit(w, h, px, card(drift_px=0))
        self.assertIn("PIVOT_DRIFT", codes(rep))

    def test_pivot_drift_off_when_not_anchored(self):
        low = ["........"] + BLOB[:7]
        w, h, px = sheet([BLOB, low, BLOB3])
        rep = pp.audit(w, h, px, card(drift_px=0, ground_anchored=False))
        self.assertNotIn("PIVOT_DRIFT", codes(rep))

    def test_center_drift(self):
        shifted = ["." + r[:-1] for r in BLOB]
        shifted2 = [".." + r[:-2] for r in BLOB]
        w, h, px = sheet([BLOB, shifted, shifted2])
        self.assertIn("CENTER_DRIFT", codes(pp.audit(w, h, px, card(drift_px=0))))

    def test_loop_double(self):
        w, h, px = sheet([BLOB, BLOB3, BLOB2, BLOB])
        rep = pp.audit(w, h, px, card(kind="loop"))
        f = [x for x in rep["findings"] if x["code"] == "LOOP_DOUBLE"][0]
        self.assertEqual(f["frames"], [3])

    def test_loop_seam(self):
        a = BLOB
        b = ["." + r[:-1] for r in BLOB]
        c = [".." + r[:-2] for r in BLOB]
        d = ["..." + r[:-3] for r in BLOB]
        w, h, px = sheet([a, a[:], b, b[:], c, d])
        # make consecutive identical frames different by one pixel to avoid DUP noise
        rep = pp.audit(w, h, px, card(kind="loop", in_place=False))
        self.assertIn("LOOP_SEAM", codes(rep))

    def test_smooth_loop_no_seam(self):
        w, h, px = sheet([BLOB, BLOB3, BLOB, BLOB3])
        rep = pp.audit(w, h, px, card(kind="loop"))
        self.assertNotIn("LOOP_SEAM", codes(rep))

    def test_pops_off(self):
        w, h, px = sheet([BLOB, BLOB2, BLOB3])
        rep = pp.audit(w, h, px, card(subject="effect", kind="oneshot"))
        self.assertIn("POPS_OFF", codes(rep))


class TimingTests(unittest.TestCase):
    def test_24fps_on_60hz_uneven(self):
        w, h, px = sheet([BLOB, BLOB3])
        rep = pp.audit(w, h, px, card(fps=24))
        self.assertIn("TICK_UNEVEN", codes(rep))

    def test_12fps_even(self):
        w, h, px = sheet([BLOB, BLOB3])
        self.assertNotIn("TICK_UNEVEN", codes(pp.audit(w, h, px, card(fps=12))))

    def test_durations_override(self):
        w, h, px = sheet([BLOB, BLOB3])
        rep = pp.audit(w, h, px, card(durations_ms=[100, 70]))
        f = [x for x in rep["findings"] if x["code"] == "TICK_UNEVEN"][0]
        self.assertEqual(f["frames"], [1])

    def test_durations_from_json_frames(self):
        w, h, px = sheet([BLOB, BLOB3])
        meta = {"frames": [{"frame": {"x": 0, "y": 0, "w": 8, "h": 8}, "duration": 100},
                           {"frame": {"x": 8, "y": 0, "w": 8, "h": 8}, "duration": 70}]}
        rep = pp.audit(w, h, px, card(fps=None), meta)
        self.assertEqual(rep["durations_ms"], [100.0, 70.0])
        self.assertIn("TICK_UNEVEN", codes(rep))


class JsonFrameTests(unittest.TestCase):
    def test_hash_format(self):
        w, h, px = sheet([BLOB, BLOB3])
        meta = {"frames": {"a 0": {"frame": {"x": 0, "y": 0, "w": 8, "h": 8}},
                           "a 1": {"frame": {"x": 8, "y": 0, "w": 8, "h": 8}}}}
        self.assertEqual(len(pp.json_frames(w, h, px, meta)), 2)

    def test_trimmed_restored(self):
        w, h, px = sheet([BLOB])
        meta = {"frames": [{"frame": {"x": 1, "y": 1, "w": 6, "h": 5}, "trimmed": True,
                            "spriteSourceSize": {"x": 1, "y": 1, "w": 6, "h": 5}, "sourceSize": {"w": 8, "h": 8}}]}
        f = pp.json_frames(w, h, px, meta)[0]
        self.assertEqual((f.w, f.h), (8, 8))
        self.assertEqual(f.pixels, pp.grid_frames(w, h, px, [8, 8])[0][0].pixels)

    def test_rotated_rejected(self):
        meta = {"frames": [{"frame": {"x": 0, "y": 0, "w": 8, "h": 8}, "rotated": True}]}
        with self.assertRaises(pp.PassError):
            pp.json_frames(8, 8, [T] * 64, meta)

    def test_out_of_bounds(self):
        meta = {"frames": [{"frame": {"x": 4, "y": 0, "w": 8, "h": 8}}]}
        with self.assertRaises(pp.PassError):
            pp.json_frames(8, 8, [T] * 64, meta)

    def test_missing_frames_key(self):
        with self.assertRaises(pp.PassError):
            pp.json_frames(8, 8, [T] * 64, {"meta": {}})


class OutputTests(unittest.TestCase):
    def test_preview_size_and_pixels(self):
        w, h, px = sheet([BLOB, BLOB3])
        frames, _ = pp.grid_frames(w, h, px, [8, 8])
        W, H, out = pp.preview(frames, scale=3, bg=(255, 255, 255))
        self.assertEqual((W, H), (2 * 24 + 3, 24 + 2))
        self.assertEqual(out[0], (255, 0, 255, 255))           # gutter
        self.assertEqual(out[1 * W + 1], (255, 255, 255, 255))  # transparent -> background
        # outline pixel at native (2,1) -> scaled (6..8, 3..5) + gutter 1
        self.assertEqual(out[(1 + 3) * W + 1 + 6], K)

    def test_preview_wraps_columns(self):
        w, h, px = sheet([BLOB, BLOB3, BLOB2])
        frames, _ = pp.grid_frames(w, h, px, [8, 8])
        W, H, _ = pp.preview(frames, scale=1, cols=2)
        self.assertEqual((W, H), (2 * 8 + 3, 2 * 8 + 3))

    def test_palette_rows_sorted_dark_to_light(self):
        w, h, px = sheet([BLOB])
        rows = pp.palette_rows(pp.grid_frames(w, h, px, [8, 8])[0])
        self.assertEqual([c for c, _ in rows], [K[:3], G[:3], L[:3]])

    def test_atlas_json(self):
        w, h, px = sheet([BLOB, BLOB3])
        frames, _ = pp.grid_frames(w, h, px, [8, 8])
        data = pp.atlas_json(card(asset="slime", fps=10), frames, "slime.png")
        self.assertEqual(len(data["frames"]), 2)
        self.assertEqual(data["frames"][1]["frame"]["x"], 8)
        self.assertEqual(data["frames"][0]["duration"], 100)
        self.assertEqual(data["meta"]["pivot"], {"x": 4, "y": 8})

    def test_recipe_engines(self):
        c = card(asset="slime", fps=10)
        for e in pp.ENGINES:
            text = pp.recipe(c, e)
            self.assertTrue(text)
        self.assertIn("Filter Mode: Point", pp.recipe(c, "unity"))
        self.assertIn("pixelArt: true", pp.recipe(c, "phaser"))
        self.assertIn("nearest", pp.recipe(c, "love"))

    def test_recipe_unknown_engine(self):
        with self.assertRaises(pp.PassError):
            pp.recipe(card(), "flash")

    def test_report_text(self):
        w, h, px = sheet([BLOB, BLOB3, BLOB2, BLOB])
        text = pp.render_report(pp.audit(w, h, px, card(asset="slime")))
        self.assertIn("Verdict: FIX", text)
        self.assertIn("LOOP_DOUBLE", text)
        self.assertIn("fix:", text)


class CliTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        w, h, px = sheet([BLOB, BLOB3, BLOB2, BLOB])
        self.png = os.path.join(self.d, "s.png")
        write(self.png, pp.encode_png(w, h, px), "wb")
        self.card = os.path.join(self.d, "card.json")
        write(self.card, json.dumps({"asset": "slime", "cell": [8, 8], "background": "#ffffff", "fps": 12}))

    def run_cli(self, *argv):
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = pp.main(list(argv))
        return code, out.getvalue(), err.getvalue()

    def test_card_prints_json(self):
        code, out, _ = self.run_cli("card")
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(out)["subject"], "character")

    def test_audit_exit_code_fix(self):
        code, out, _ = self.run_cli("audit", self.png, "--card", self.card)
        self.assertEqual(code, 1)
        self.assertIn("LOOP_DOUBLE", out)

    def test_audit_json(self):
        code, out, _ = self.run_cli("audit", self.png, "--card", self.card, "--json")
        self.assertEqual(json.loads(out)["verdict"], "FIX")

    def test_audit_block_exit_2(self):
        code, _, _ = self.run_cli("audit", self.png, "--card", self.card, "--cell", "6x8")
        self.assertEqual(code, 2)

    def test_missing_file_exit_3(self):
        code, _, err = self.run_cli("audit", os.path.join(self.d, "nope.png"))
        self.assertEqual(code, 3)
        self.assertIn("error", err)

    def test_preview_writes_png(self):
        out_png = os.path.join(self.d, "p.png")
        code, out, _ = self.run_cli("preview", self.png, "--card", self.card, "-o", out_png, "--scale", "2")
        self.assertEqual(code, 0)
        w, h, _ = pp.read_png(out_png)
        self.assertEqual((w, h), (4 * 16 + 5, 16 + 2))

    def test_palette_gpl(self):
        code, out, _ = self.run_cli("palette", self.png, "--card", self.card, "--format", "gpl")
        self.assertEqual(code, 0)
        self.assertTrue(out.startswith("GIMP Palette"))

    def test_atlas_to_file(self):
        f = os.path.join(self.d, "a.json")
        code, _, _ = self.run_cli("atlas", self.png, "--card", self.card, "-o", f)
        self.assertEqual(code, 0)
        self.assertEqual(len(json.loads(read(f))["frames"]), 4)

    def test_recipe_cli(self):
        code, out, _ = self.run_cli("recipe", "--card", self.card, "--engine", "godot")
        self.assertEqual(code, 0)
        self.assertIn("Nearest", out)


if __name__ == "__main__":
    unittest.main()
