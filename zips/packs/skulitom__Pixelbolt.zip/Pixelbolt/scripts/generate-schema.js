import { writeFile } from 'node:fs/promises';
import { DITHER_PATTERNS, EASINGS } from '../src/craft.js';
import { FLUID_KINDS, FLUID_FIELDS, FLUID_WALLS } from '../src/fluid.js';
import { FX_EVENTS, SPRITE_PIXELS, EMITTER_DEPTHS, EDGE_SIDES } from '../src/fx.js';
import { SHAPE_KINDS, LAYER_DEPTHS } from '../src/shapes.js';
import { NORMAL_DIRECTIONS } from '../src/authoring.js';
const NORMAL_KEYS = Object.keys(NORMAL_DIRECTIONS);
const int = (minimum, maximum, description) => ({ type: 'integer', minimum, maximum, ...(description ? { description } : {}) });
const num = (minimum, maximum, description) => ({ type: 'number', minimum, maximum, ...(description ? { description } : {}) });
const bool = { type: 'boolean' }, color = { type: 'string', description: 'Palette name, transparent, or #RGB/#RGBA/#RRGGBB/#RRGGBBAA.' };
const id = { type: 'string', pattern: '^[a-zA-Z][a-zA-Z0-9_-]{0,63}$', description: 'Portable name: do not use Windows device names (CON, PRN, AUX, NUL, COM1–9, LPT1–9). Frame/animation names must be unique ignoring case.' };
const object = (properties, required = []) => ({ type: 'object', properties, required, additionalProperties: false });
const ref = name => ({ $ref: `#/$defs/${name}` });
const array = (items, maxItems = 2048) => ({ type: 'array', items, maxItems });
const xy = { x: int(-4096, 4096), y: int(-4096, 4096) };
// Shapes and dither or shade regions may overhang the canvas: up to 512 pixels, or twice the side of a larger still.
const wh = { w: int(1, 8192, 'At most 512, or twice the canvas width on a still wider than 256.'), h: int(1, 8192, 'At most 512, or twice the canvas height on a still taller than 256.') };
// A rewrite region stays inside the canvas; it runs to the canvas edge by default.
const region = { w: int(1, 4096, 'Default: to the canvas edge. The region stays inside the canvas.'), h: int(1, 4096, 'Default: to the canvas edge. The region stays inside the canvas.') };
// One frame may be a still larger than 256 pixels a side; a recipe with several frames may not.
const side = int(1, 4096, '1–256 pixels; a still (a recipe with exactly one frame) may be up to 4096, within 4,194,304 pixels in all.');
// The row an operation stands on, in a layer with sort "ground".
const ground = int(-4096, 4096, 'In a layer with sort "ground": the row this stands on, which orders the drawing far to near. Default: the lowest row it draws (a line\'s lower end). Text needs it.');
const point = { ...array(int(-4096, 4096), 2), minItems: 2, description: '[x, y] in unscaled canvas pixels; the top-left corner of that pixel.' };
const transform = { scale: int(1, 16), flipX: bool, flipY: bool, rotate: { enum: [0, 90, 180, 270] } };
const remap = { type: 'object', propertyNames: { minLength: 1, maxLength: 1 }, additionalProperties: color, description: 'Recolor grid characters for this operation only: character → palette name or colour.' };
const operation = (op, properties, required = []) => object({ op: { const: op }, ...properties }, ['op', ...required]);
const hex = '^(transparent|#([a-fA-F0-9]{3,4}|[a-fA-F0-9]{6}|[a-fA-F0-9]{8}))$';
// An opaque colour: #RGB or #RRGGBB, or with a full alpha.
const opaqueHex = '^#([a-fA-F0-9]{3}[fF]?|[a-fA-F0-9]{6}([fF]{2})?)$';
const pairOf = item => ({ ...array(item, 2), minItems: 2 });
const ruleRows = { ...array({ type: 'string', minLength: 1, maxLength: 8 }, 8), minItems: 1, description: 'Equal-width rows of palette keys; dot or space matches anything (match) or keeps the pixel (replace); the empty character stands for transparent.' };
const ease = { enum: EASINGS, description: 'linear (default), hold (jump at the end), in, out, inOut, overshoot or bounce.' };
const names64 = { ...array({ type: 'string', minLength: 1 }, 64), minItems: 1 };
// Tilemap legends are shared by scene tilemaps (frames and animations) and the recipe tilemap operation (symbols and
// autotile templates); `kinds` are the singular names, each also with a plural for variants.
const legend = (kinds, describe) => {
  const draws = Object.fromEntries(kinds.flatMap(kind => [[kind, { type: 'string', description: describe[kind] }], [`${kind}s`, { ...names64, description: `Variants of ${kind}, picked by cell position (seeded when the tilemap has a seed).` }]]));
  const shared = { ...draws, weights: { ...array(int(1, 1000), 64), minItems: 1, description: 'One whole-number weight per variant name; heavier names are picked more often.' },
    autotile: { enum: ['blob', 'cardinal', 'corner'], description: 'Pick by neighbour mask: 47-value blob, 16-value cardinal, or 16-value corner (a tile where four cells meet, half a cell up and left; {corners} in a name becomes those four cells\' characters, for a layered set, and its variants with no tile there are left out).' }, match: { type: 'string', minLength: 1, description: 'Characters counted as the same terrain for the mask; default: this character.' } };
  const rule = object({ ...shared,
    where: { ...array({ type: 'string', minLength: 3, maxLength: 3 }, 3), minItems: 3, description: '3×3 characters centred on the cell. A dot matches anything, the tilemap\'s empty character matches empty cells (and cells beyond the map), a class matches its members, any other character matches itself.' },
    chance: num(0, 1, 'Seeded probability that a matching rule draws.'), offset: { ...pairOf(int(-8, 8)), description: '[columns, rows] to draw into another cell; it draws over that cell\'s own tiles.' },
    stop: { type: 'boolean', description: 'When this rule draws, skip the rest of the cell\'s rules.' } });
  return { type: 'object', propertyNames: { minLength: 1, maxLength: 1 }, description: 'Map characters to what they draw. Dot and space are empty cells.', additionalProperties: { oneOf: [
    { type: 'string', description: describe[kinds[0]] },
    object(shared),
    { ...object({ rules: { ...array(rule, 32), minItems: 1, description: 'Every rule that matches draws, in order, until one with stop draws.' } }, ['rules']) },
    { type: 'null', description: 'Context cell: never drawn, but it counts for other entries\' match and for rules.' }] } };
};
const tilemapFields = {
  rows: { ...array({ type: 'string', minLength: 1, maxLength: 256 }, 256), minItems: 1 },
  outside: { enum: ['empty', 'match'], description: 'Cells beyond the map: empty (default), or matching every mask and rule pattern.' },
  empty: { type: 'string', minLength: 1, maxLength: 1, description: 'A character, not a legend key, that stands for empty cells in rule patterns.' },
  classes: { type: 'object', propertyNames: { minLength: 1, maxLength: 1 }, additionalProperties: { type: 'string', minLength: 1, maxLength: 64 }, description: 'Characters that stand for several map characters in rule patterns, e.g. {"#": "WV"}; include the empty character to match empty cells too.' },
  seed: int(0, 2147483647, 'Reshuffles variant picks and rule chances, which are seeded by cell position; default 0.'),
  layout: { enum: ['square', 'iso'], description: 'square (default): cells side by side, each drawing from its top-left. iso: a 2:1 diamond grid (even tile sizes such as [32, 16]), drawn back to front, cell [x, y] at [(x - y + rows - 1) * w/2, (x + y) * h/2]; each drawing stands on its diamond, bottoms aligned and centred across, so a block taller than the tile rises above its cell.' }
};
const densityFields = {
  density: { oneOf: [num(0, 1), pairOf(num(0, 1))], description: 'Share of pixels changed, 0–1, or [from, to] ramping along direction.' },
  direction: { enum: ['down', 'up', 'right', 'left', 'radial'], description: 'Ramp direction for a [from, to] density; radial runs from the centre to the edge.' },
  pattern: { oneOf: [{ enum: DITHER_PATTERNS }, { ...array({ ...array(int(0, 255), 16), minItems: 1 }, 16), minItems: 1, description: 'Rows of ranks from 0 to cells − 1; low ranks turn on first, and a highest rank n gives n + 1 levels, so [[0, 1], [1, 0]] is a checkerboard at 0.5.' }], description: 'bayer4 by default. noise is seeded white noise with no repeating grid; value is seeded smooth noise that forms clumps about scale pixels across. Patterns follow canvas coordinates, so neighbouring areas line up.' },
  offset: { ...point, description: 'Shift the pattern, for example to crawl it between frames.' },
  seed: int(0, 2147483647, 'Orders the noise or value pattern (default 0): the same seed keeps every pixel\'s threshold, so a rising density grows in a fixed order; another seed reshuffles it.'),
  scale: int(1, 64, 'Clump size of the value pattern in pixels; default 4.'),
  over: { oneOf: [color, { ...array(color, 64), minItems: 1 }], description: 'Only change pixels whose exact current color is listed (transparent included).' }
};
const schema = {
  $schema: 'https://json-schema.org/draft/2020-12/schema',
  title: 'Pixelbolt project',
  ...object({
    $schema: { type: 'string' }, version: { const: 1 }, name: id,
    width: side, height: side,
    palette: { type: 'object', maxProperties: 257, properties: { $ref: { type: 'string', description: 'Shared palette file, resolved by the CLI and MCP relative to this recipe. Local entries add to or override it.' } }, additionalProperties: { type: 'string', pattern: hex } },
    ramps: { ...array({ ...array({ type: 'string', minLength: 1, maxLength: 64 }, 32), minItems: 2 }, 64), description: 'Palette keys from dark to light, one list per material. shade and scene ramp lighting move a colour along its ramp instead of inventing one. A key belongs to one ramp. A shared palette file ({"palette": {...}, "ramps": [...]}) can supply them.' },
    background: color, symbols: { type: 'object', propertyNames: id, additionalProperties: ref('rows') },
    anchor: { ...point, description: 'Default pivot for every frame, exported to the atlas as anchorPx (exported pixels) and as anchor and pivot (anchor / source size, the 0-1 origin Phaser and PixiJS read).' },
    frames: { ...array(ref('frame'), 256), minItems: 1 },
    animations: { type: 'object', minProperties: 1, maxProperties: 65524, description: 'ZIP32 bundle budget: animation count + frame count + 10 support files must not exceed 65,535.', propertyNames: id, additionalProperties: object({ frames: { ...array(id, 1024), minItems: 1 }, direction: { enum: ['forward', 'reverse', 'pingpong'] }, loop: bool }, ['frames']) },
    sheet: object({ columns: int(1, 256), padding: int(0, 16), scale: int(1, 16), trim: { type: 'boolean', description: 'Pack each frame by its visible bounds; the atlas reports trimmed rectangles with spriteSourceSize. Ignores columns.' } })
  }, ['version', 'name', 'width', 'height', 'frames']),
  if: { properties: { frames: { minItems: 2 } }, required: ['frames'] },
  then: { properties: { width: { maximum: 256 }, height: { maximum: 256 } } },
  $defs: {
    rows: { ...array({ type: 'string', minLength: 1, maxLength: 256 }, 256), minItems: 1, description: 'Equal-width text rows. Every character is a palette key; dot and space skip a pixel.' },
    frame: object({ name: id, duration: int(1, 60000, 'Frame duration in milliseconds; default 100.'), from: id, translate: { ...array(int(-4096, 4096), 2), minItems: 2 }, wrap: { type: 'boolean', description: 'Translation wraps around the canvas instead of clipping (scrolling tiles).' }, flipX: bool, flipY: bool,
      palette: { type: 'object', maxProperties: 256, additionalProperties: color, description: 'Recolor project palette keys for this frame only (palette cycling). Keys must exist in the project palette.' },
      anchor: point, points: { type: 'object', maxProperties: 64, propertyNames: id, additionalProperties: point, description: 'Named frame positions (hands, hit points, glyph advance), exported in the atlas in exported pixels.' },
      tile: { ...object({ terrain: { ...id, description: 'The autotile set this frame belongs to; default the recipe name. Each terrain is a Godot terrain set of its own.' },
        corners: { ...array(id, 4), minItems: 4, description: 'A layered set\'s tile: the terrains at its NW, NE, SW and SE corners, instead of terrain. The recipe\'s layered tiles are one Godot corner terrain set, its terrains in order of first appearance, the first the ground under the others.' }, weight: int(1, 1000, 'How often this frame is picked against the other frames for the same cell; default 1.'),
        collision: { oneOf: [{ ...array(point, 32), minItems: 3 }, { ...array({ ...array(point, 32), minItems: 3 }, 8), minItems: 1 }], description: 'Polygon around the solid part in canvas pixels (pixel corners from [0, 0] to [width, height]), in order around the shape; or a list of up to 8 for separate parts.' }, oneWay: { type: 'boolean', description: 'Bodies pass up through the collision polygon and land on top (a platform).' } }),
        description: 'This frame as a tile in the Godot TileSet: its terrain, weight and collision. A frame with tile makes the export write a TileSet.' },
      ops: array(ref('op')), layers: array(ref('layer'), 64), pixels: { ...array(ref('pixel'), 65536), description: 'Final canvas-coordinate RGBA replacements after ops and layers. Coordinates must be inside this canvas. Later entries win; transparent erases.' } }, ['name']),
    pixel: object({ x: int(0, 4095), y: int(0, 4095), color }, ['x', 'y', 'color']),
    layer: object({ name: id, visible: bool, opacity: { type: 'number', minimum: 0, maximum: 1 }, ...xy,
      sort: { enum: ['ground'], description: 'ground: draw the operations far to near by the row each stands on (its ground, or the lowest row it draws), list order breaking ties, as a game draws actors and props. Use it for everything standing on the ground: trees, grass, rocks, figures. Area operations (dither, shade, fill, outline, tilemap...) are refused.' },
      palette: { type: 'object', maxProperties: 256, additionalProperties: color, description: 'Recolor project palette keys for this layer\'s drawing only, on top of the frame palette: a flash or cycle on one layer leaves other drawing that shares the key alone. Keys must exist in the project palette; values are colours or project palette names.' },
      ops: array(ref('op')) }),
    op: { oneOf: [
      operation('pixel', { ...xy, ground, color }, ['color']),
      operation('rect', { ...xy, ground, ...wh, color, filled: bool }, ['w', 'h', 'color']),
      operation('ellipse', { ...xy, ground, ...wh, color, filled: bool }, ['w', 'h', 'color']),
      operation('line', { ...xy, ground, x2: int(-4096, 4096), y2: int(-4096, 4096), color }, ['x2', 'y2', 'color']),
      operation('clear', { ...xy, ...wh }, ['w', 'h']),
      operation('fill', { ...xy, color }, ['color']),
      operation('replace', { from: color, to: color }, ['from', 'to']),
      operation('grid', { ...xy, ground, rows: ref('rows'), ...transform, remap }, ['rows']),
      operation('stamp', { ...xy, ground, symbol: id, ...transform, remap }, ['symbol']),
      { ...operation('text', { ...xy, ground, text: { type: 'string', minLength: 1, maxLength: 512, description: 'Printable ASCII, western European accented letters and common symbols; \\n starts a new line (at most 64).' }, color, align: { enum: ['left', 'center', 'right'], description: 'What x is: the left edge of the text (default), its centre or its right edge. Lines align the same way.' }, spacing: int(0, 16, 'Pixels between glyphs; default 1.'), lineHeight: int(1, 64, 'Pixels from the top of one line to the top of the next; default 10.'), ...transform }, ['text', 'color']),
        description: 'Draw text in the built-in pixel font. y is the top of the capitals; a line is 8 rows: capitals 7 tall, lowercase 5, descenders 1 below, and the accent of a capital reaches 2 rows above y. Glyphs are 1 to 5 pixels wide (© ® — Œ œ are 7), digits always 5, a space 3. One line of n average characters is about 6n pixels wide.' },
      { ...operation('copy', { ...xy, ground, from: id, symbol: id, sx: int(0, 255), sy: int(0, 255), w: int(1, 256), h: int(1, 256), ...transform, remap: { type: 'object', maxProperties: 256, propertyNames: { minLength: 1, maxLength: 64 }, additionalProperties: color, description: 'Symbol copies: recolor grid characters (one character each) → palette name or colour. Frame copies: swap exact colours, named by project palette key or hex (#RGB to #RRGGBBAA), for a palette name or colour.' } }), oneOf: [{ required: ['from'] }, { required: ['symbol'] }], description: 'Copy a rectangle of a symbol (palette characters) or an earlier frame (exact RGBA).' },
      { ...operation('autotile', { ...xy, ground, symbol: id, mask: int(0, 255, 'Neighbour mask. Blob: N=1, NE=2, E=4, SE=8, S=16, SW=32, W=64, NW=128, reduced so a diagonal counts only with both of its sides. Cardinal: N=1, E=2, S=4, W=8. Corner: the terrain cells among the four the tile sits between, NW=1, NE=2, SW=4, SE=8.'), mode: { enum: ['blob', 'cardinal', 'corner'], description: 'blob (default), cardinal or corner.' }, remap }, ['symbol', 'mask']),
        description: 'Draw one autotile tile from a template symbol two tiles wide and three tall: the four quarters the mask selects (see the autotile template format). The autotile compiler emits one per frame, so editing the template redraws every tile.' },
      { ...operation('box', { ...xy, ground, w: { ...int(2, 512), multipleOf: 2, description: 'How far the top face\'s right edge runs across, in pixels (even); it runs half as far down.' }, d: { ...int(2, 512), multipleOf: 2, description: 'How far the top face\'s left edge runs across, in pixels (even).' },
        h: int(0, 512, 'Height of the side faces in pixels; default 0, a flat diamond.'), top: color, left: color, right: color, edge: { ...color, description: 'Marks the top face\'s front edges and the corner between the side faces.' } }, ['w', 'd']), anyOf: [{ required: ['top'] }, { required: ['left'] }, { required: ['right'] }],
        description: 'An isometric box from the top-left of its bounds (w + d wide, (w + d) / 2 + h tall): a 2:1 top face over a left and a right face. Each pixel belongs to the face its centre lies in, so edges step two pixels across per row and boxes on a 2:1 grid meet exactly. A face without a colour is left out.' },
      { ...operation('outline', { color, diagonal: bool, position: { enum: ['outside', 'inside', 'middle'], description: 'outside (default) surrounds the visible pixels; inside recolors their edge pixels; middle splits the width, the odd pixel outside.' }, width: int(1, 8, 'Rings of pixels; default 1.'),
        directions: { ...array({ type: 'string', pattern: '^[x.]{3}$' }, 3), minItems: 3, description: '3×3 grid centred on a visible pixel, with a dot in the centre: x marks the sides that get the line, e.g. ["...", "...", "..x"] for a drop shadow or [".x.", "...", "..."] for a top rim. Replaces diagonal.' } }, ['color']), description: 'Outline every visible pixel in this buffer (frame or layer): outside rings, inside edge rings or both, in chosen directions.' },
      { ...operation('dither', { ...xy, ...wh, color, erase: { type: 'boolean', description: 'Clear the pattern pixels instead of drawing a color.' }, ...densityFields }), anyOf: [{ required: ['color'] }, { required: ['erase'] }], description: 'Ordered dither between the current pixels and color: draws (or erases) where a canvas-anchored threshold pattern is below the density (default 0.5). x/y default to 0 and w/h reach the canvas edge.' },
      { ...operation('shade', { ...xy, ...wh, steps: int(-8, 8, 'Steps along each colour\'s ramp: negative darkens (default -1), positive lightens. Clamped at the ramp\'s ends; not 0.'), shape: { enum: ['rect', 'ellipse'], description: 'rect (default) or the ellipse inside the region.' }, ...densityFields }),
        description: 'Move every pixel of the region along its colour\'s ramp (see ramps), so shadows and light keep the palette on any surface. Colours on no ramp stay. density (default 1) and pattern give a dithered edge. x/y default to 0 and w/h reach the canvas edge.' },
      { ...operation('tilemap', { ...xy, tile: { ...pairOf(int(1, 256)), description: 'Cell size [width, height] in pixels.' }, ...tilemapFields,
        legend: legend(['symbol', 'template'], { symbol: 'A symbol drawn at the cell\'s top-left (in an iso map, standing on its diamond); with autotile, {mask} in its name becomes the neighbour mask.', template: 'An autotile template symbol (two tiles wide, three tall) drawn with the cell\'s neighbour mask; needs autotile.' }) }, ['tile', 'rows', 'legend']),
        description: 'Draw a character map from this recipe\'s symbols and autotile templates, with variants, weights and neighbour rules, so later operations see the composed result (dither over its floor, rewrite rules at its corners).' },
      { ...operation('rewrite', { ...xy, ...region, rules: { ...array(object({ match: ruleRows, replace: ruleRows }, ['match', 'replace']), 16), minItems: 1 },
        empty: { type: 'string', minLength: 1, maxLength: 1, description: 'A non-palette character meaning a transparent pixel in match and erasure in replace.' },
        steps: int(1, 64, 'Passes over every rule; stops early when a pass changes nothing.'), chance: num(0, 1, 'Seeded probability that each match is applied.'), limit: int(1, 65536, 'Most replacements per rule per step.'),
        seed: int(0, 2147483647), rotate: { type: 'boolean', description: 'Also match the rules turned 90°, 180° and 270°.' }, mirror: { type: 'boolean', description: 'Also match the rules mirrored horizontally.' } }, ['rules']),
        description: 'Markov-style rewrite rules on this buffer: each small match grid found on exact colors is replaced, in a seeded order, without overlapping rewrites. The region defaults to the whole canvas.' }
    ] }
  }
};
await writeFile(new URL('../schema.json', import.meta.url), JSON.stringify(schema, null, 2) + '\n');

// Sidecar formats evolve independently; compiled sprite recipes remain version 1.
const structuralColor = {
  ramp: int(0, 63, 'Index of a source ramp; structural parts use one-character palette keys.'),
  base: int(0, 31, 'Neutral fill step inside that ramp.'),
  outline: { oneOf: [{ type: 'string', minLength: 1, maxLength: 1 }, { const: 'selective' }, { type: 'null' }],
    description: 'One-pixel outer line: a palette key, selective for the darkest ramp step, or null/omitted for none.' }
};
const structuralPoint = { ...pairOf(int(-64, 64)), description: '[along, across] relative to the part anchor; transformed with the part.' };
const bonePart = object({
  ...structuralColor, length: int(1, 64, 'Start-to-end joint distance in pixels.'),
  width: { ...array(int(1, 16), 3), minItems: 2, description: '[start, end] or [start, middle, end] fill widths.' },
  caps: pairOf({ enum: ['round', 'flat', 'point', 'socket'] }),
  snap: { type: 'boolean', description: 'Snap within 4 degrees of a clean slope (default true); endpoints follow the stepped slope.' }
}, ['length', 'width', 'ramp', 'base']);
const massPart = object({ ...structuralColor, size: { ...pairOf(int(2, 64)), description: 'Unsquashed ellipse diameters [width, height]; with flat, the dome\'s width and its rows from the base up.' },
  flat: { type: 'boolean', description: 'Draw the top half of the ellipse: a dome with a flat base, anchored at the middle of its base row, which squash and rotation keep in place (slimes, mounds). Default false.' } }, ['size', 'ramp', 'base']);
// How far a motion template swings rig.tail as it follows through.
const follow = num(0, 2, 'How far rig.tail swings as it follows through the motion: 0 holds it as drawn, 1 by default, 2 twice as far. Needs rig.tail.');
const poses = {
  $schema: schema.$schema, title: 'Pixelbolt authored poses',
  ...object({ format: { const: 'pixelforge-poses' }, version: { const: 1 }, name: id, width: int(1, 256), height: int(1, 256), palette: schema.properties.palette,
    ramps: schema.properties.ramps, light: int(0, 359, 'Clockwise light direction: 0 right, 225 top left (default).'),
    innerLines: { enum: ['shade', 'outline'], description: 'Where a bone or mass outline falls inside the figure (an arm across the chest, the near leg over the far one): shade (default) draws it one ramp step below the part\'s base colour, so the figure keeps one outline round its silhouette; outline keeps the outline colour.' },
    rig: { ...object({ ground: int(0, 255, 'Canvas pixel row touched by planted markers; must be below height.'), body: id, head: id, rest: id,
      legs: array({ ...array(id, 3), minItems: 2 }, 8), arms: array({ ...array(id, 3), minItems: 2 }, 8), tail: array(id, 16),
      fore: { ...array({ ...array(id, 3), minItems: 2 }, 2), minItems: 2, description: 'A four-legged rig\'s front legs, near then far (with hind, instead of legs). The solved joint folds forward as a foot lifts and back under weight.' },
      hind: { ...array({ ...array(id, 3), minItems: 2 }, 2), minItems: 2, description: 'A four-legged rig\'s back legs, near then far; the solved joint (the hock) folds back.' },
      chest: { ...id, description: 'Four-legged rigs: a bone attached to body that the fore legs hang from; gaits bend the spine by turning it against the body.' },
      neck: { ...id, description: 'Four-legged rigs: a bone the head hangs from, turned back by half of the chest\'s turn so the head stays steadier.' } }, ['ground']),
      // The rig's legs are legs (two legs) or fore and hind (four), and chest and neck belong to four legs.
      dependentRequired: { fore: ['hind'], hind: ['fore'], chest: ['fore'], neck: ['fore'] }, not: { required: ['legs', 'fore'] } },
    motions: { type: 'object', maxProperties: 16, propertyNames: id, additionalProperties: { oneOf: [
      ...['walk', 'trot', 'run'].map(template => object({ template: { const: template, ...(template === 'trot' && { description: 'A four-legged trot: diagonal pairs of feet.' }) }, frames: { ...int(template === 'run' ? 6 : 4, 64), multipleOf: 2 }, duration: int(1, 60000), follow, speed: num(-1024, 1024), stride: num(1, 64), lift: num(0, 32), bob: num(0, 8), lean: int(-45, 45), swapDepth: { type: 'boolean', description: 'Exchange the draw order of paired limbs in the second half-cycle, for front or back views where the stepping limb comes nearer the camera. Default false: side views keep near limbs in front.' },
        ...(template === 'run' && { flex: int(0, 30, 'Four-legged gallop: degrees the spine curls and stretches each way (the body rocks half as far); default 10.') }) }, ['template'])),
      object({ template: { const: 'idle' }, frames: int(2, 16), duration: int(1, 60000), follow, breath: num(0, .5),
        squash: num(.05, .5, 'Instead of breath: the body stretches, then squashes, by this share over the loop while its lowest drawn pixel stays on rig.ground. Not with breath or legs.') }, ['template']),
      object({ template: { const: 'jump' }, frames: { const: 7 }, duration: int(1, 60000), follow, crouch: num(.5, 1), stretch: num(1, 2), apex: int(1, 32) }, ['template']),
      object({ template: { const: 'attack' }, frames: { const: 4 }, duration: int(1, 60000), follow, arm: int(0, 7), windup: int(-360, 360), strike: int(-360, 360), hold: int(1, 16) }, ['template']),
      object({ template: { const: 'hurt' }, frames: { const: 2 }, duration: int(1, 60000), follow, recoil: int(-90, 90), squash: num(.5, 2) }, ['template'])
    ] } },
    motionInfo: { type: 'object', propertyNames: id, additionalProperties: object({ template: { enum: ['walk', 'trot', 'run', 'idle', 'jump', 'attack', 'hurt'] }, speed: num(-1024, 1024), keyPoses: { ...array(id, 256), minItems: 1, uniqueItems: true } }, ['template', 'speed', 'keyPoses']),
      description: 'Expansion annotations: generated animation speed and key poses. Retain these when editing --expand output; do not combine with motions.' },
    parts: { type: 'object', maxProperties: 256, propertyNames: id, additionalProperties: { oneOf: [
      object({ rows: ref('rows'), anchor: point, points: { type: 'object', propertyNames: id, additionalProperties: point },
        views: { type: 'object', minProperties: 1, maxProperties: 16, propertyNames: { pattern: '^(0|[1-9][0-9]?|[12][0-9]{2}|3[0-5][0-9])$' },
          additionalProperties: object({ rows: ref('rows'), anchor: point, points: { type: 'object', propertyNames: id, additionalProperties: point } }, ['rows', 'anchor']),
          description: 'Authored grid drawings by world angle (0–359). Each supplies its anchor and every named point of the base part. Use the nearest drawing within 22.5 degrees; otherwise rotate the base grid.' }
      }, ['rows']),
      object({ bone: bonePart, points: { type: 'object', propertyNames: id, additionalProperties: { oneOf: [structuralPoint, { const: 'end' }] } } }, ['bone']),
      object({ mass: massPart, points: { type: 'object', propertyNames: id, additionalProperties: structuralPoint } }, ['mass'])
    ] } },
    poses: { ...array({ ...object({ name: id, duration: int(1, 60000), origin: { ...point, description: 'The canvas point the pose stands on (often where the feet meet the ground), exported as the frame anchor. Parts without attach are placed from it. Default [0, 0].' },
      mirror: { ...id, description: 'Reflect an earlier pose (parts, points and markers) around its origin corner: pixel column c becomes 2 × originX − 1 − c, as drawFrame\'s flipX does. Omit parts, markers and origin.' },
      relight: { type: 'boolean', description: 'Mirror poses only: redraw structural parts with the source light unchanged; false/omitted preserves exact runtime-flipped pixels.' },
      tween: { ...object({ from: id, to: id, t: num(0, 1, 'Position between the two poses.'), ease }, ['from', 'to', 't']), description: 'An in-between of two earlier authored or tweened poses with the same part instances: origin, offsets and angles interpolate and round; part definitions and flips switch at the eased halfway point. Omit parts and origin; markers are not inherited.' },
      parts: array(object({ name: id, part: id, at: { ...point, description: 'Offset [x, y] of the part anchor from the pose origin, or with attach from the named point; not a canvas position. Default [0, 0].' }, attach: object({ part: id, point: id }, ['part', 'point']), flipX: { type: 'boolean', description: 'Mirror this part, its anchor and its points inside the part.' },
        rotate: int(-360, 360, 'Whole degrees clockwise around the part anchor pixel, after any flip. The rotated grid is baked into an editable symbol named <part>-r<degrees> (-fr when flipped); points turn with it; right angles are exact.'),
        angle: int(-360, 360, 'Clockwise degrees relative to the parent world angle, or world degrees at a root. Mutually exclusive with rotate. Relative-angle tweens take the shorter arc.'),
        reach: { ...point, description: 'Canvas target [x, y] for the last bone of a two-bone chain. Replaces angle/rotate; attach to a named end point with zero at offset. Both bones are solved at whole degrees.' },
        bend: { enum: ['forward', 'back'], description: 'Reach only: preferred clockwise (forward, default) or anticlockwise bend. Equal-error solutions prefer this bend, then rest-angle proximity and lower angles.' },
        // No multipleOf: 0.05 has no exact binary form, so validators would reject 0.95 or 1.15 that the compiler accepts.
        squash: num(.5, 2, 'Mass parts only, in steps of 0.05. Height scales by squash and width by its inverse; contour adjustments keep opaque pixel area stable.'),
        cleanup: { type: 'boolean', description: 'Remove doubled corners the rotation leaves (default true; false names the symbol with -raw).' } }, ['name', 'part']), 64),
      markers: array(object({ name: id, part: id, point: id }, ['name', 'part', 'point']), 64),
      contacts: { ...array(id, 64), uniqueItems: true, description: 'Markers planted on the ground in this pose. Mirrors inherit contacts; tweens must declare their own.' }
    }, ['name']), anyOf: [{ required: ['parts'] }, { required: ['mirror'] }, { required: ['tween'] }] }, 256), minItems: 1 }, animations: schema.properties.animations, sheet: schema.properties.sheet
  }, ['format', 'version', 'name', 'width', 'height', 'parts', 'poses']), $defs: { rows: schema.$defs.rows }
};
const recipeSchema = { ...schema }; delete recipeSchema.$schema; delete recipeSchema.$defs; delete recipeSchema.title;
// Scene assets keep to the animation canvas: a still larger than 256 pixels a side renders on its own.
const assetSide = int(1, 256, 'A scene asset is at most 256 pixels a side.');
const sceneRecipe = { ...recipeSchema, properties: { ...recipeSchema.properties, width: assetSide, height: assetSide } }; delete sceneRecipe.if; delete sceneRecipe.then;
const themePalette = description => ({ oneOf: [{ type: 'string', description: 'Palette file, resolved by the CLI relative to the scene or inside the MCP root.' }, { type: 'object', additionalProperties: { type: 'string', pattern: hex } }], description });
const cueTime = (maximum, description) => ({ oneOf: [int(0, maximum), { type: 'string', pattern: '^[a-zA-Z][a-zA-Z0-9_-]{0,63}([+-][0-9]{1,5})?$' }], description });
const assetRef = { oneOf: [ref('recipe'), { type: 'string', description: 'Recipe file, resolved by the CLI relative to the scene or inside the MCP root.' }, object({ revision: { type: 'string', pattern: '^[a-f0-9]{12}$' } }, ['revision'])] };
const scene = {
  $schema: schema.$schema, title: 'Pixelbolt scene review',
  ...object({ format: { const: 'pixelforge-scene' }, version: { const: 1 }, name: id, width: int(1, 256), height: int(1, 256), background: color, duration: int(1, 60000),
    palette: themePalette('A theme for every asset: colours for palette keys the recipes share (keys a recipe lacks are ignored), or a palette file resolved by the CLI and MCP.'),
    cues: { type: 'object', maxProperties: 64, propertyNames: id, additionalProperties: int(0, 60000), description: 'Named times in milliseconds; sequence and trajectory times may say "name", "name+90" or "name-20".' },
    assets: { type: 'object', maxProperties: 64, additionalProperties: { oneOf: [assetRef, object({ recipe: assetRef, normal: assetRef, emissive: assetRef, palette: themePalette('A theme for this asset, applied after the scene palette.') }, ['recipe'])] } },
    instances: array(object({ name: { type: 'string' }, asset: { type: 'string' }, at: point,
      anchor: { oneOf: [point, { const: 'frame' }], description: '[x, y] in asset pixels placed at `at` (default [0, 0]), or "frame" to place every drawn frame by its own atlas anchor, so animated placements follow per-frame anchors. Tilemaps take [x, y] only.' }, scale: int(1, 16), frame: id, animation: id,
      hidden: { type: 'boolean', description: 'Start hidden; a later frame or animation cue shows the placement.' },
      repeat: { ...array(int(1, 32), 2), minItems: 2, description: '[columns, rows]: copies of the placement in a grid, `step` apart.' }, step: { ...point, description: '[dx, dy] in scene pixels between repeated copies. Default: the frame size times scale.' },
      trajectory: { ...array(object({ time: cueTime(60000, 'Milliseconds or a named cue.'), at: point, ease: { ...ease, description: `Shape of the segment starting at this key: ${ease.description} Positions round to whole pixels.` } }, ['time', 'at']), 256), minItems: 2 },
      sequence: array(object({ time: cueTime(59999, 'Milliseconds or a named cue.'), frame: id, animation: id, hide: { const: true, description: 'Hide the placement from this time until a later frame or animation cue.' } }, ['time']), 64),
      attach: { ...object({ instance: { type: 'string', description: 'Name of another uniquely named placement that is neither a tilemap nor attached itself.' }, point: { ...id, description: 'A named point of its current frame; not drawn while that frame has no such point. Without one, follow where it stands, which stays on the ground while it is lifted (a contact shadow).' } }, ['instance']), description: 'Follow another placement; at becomes the offset from the point followed. Attached to a frame point, it stands on the other placement\'s ground line below the point and is lifted up to it, so a sorted held item sorts with its holder (list order decides which is in front).' },
      sort: { const: 'ground', description: 'Draw among the other sorted placements by ground line (the y of the placement point), where the first of them is listed. A sorted tilemap joins cell by cell, each standing on the bottom row of its frame, so walls and trees taller than their tile cover what stands behind them.' },
      lift: { oneOf: [int(0, 256), { ...array(object({ time: cueTime(60000, 'Milliseconds or a named cue such as "jump+150".'), height: int(0, 256), ease: { ...ease, description: `Shape of the change from this key to the next: ${ease.description}` } }, ['time', 'height']), 64), minItems: 1 }],
        description: 'Draw this many pixels above where the placement stands, which still orders it: a jump or a flight keeps its ground line. A height, or keys of height over time, held before the first and after the last. Not on tilemaps.' },
      shade: int(-8, 8, 'Draw no colours: wherever the frame is opaque, move the pixels beneath this many steps along the asset recipe\'s ramps (negative darkens). Not 0.'),
      tilemap: object({ tile: { ...point, description: 'Cell size [width, height] in pixels. Default: the asset\'s frame size.' }, ...tilemapFields, legend: legend(['frame', 'animation'], { frame: 'Frame name; with autotile, {mask} becomes the neighbour mask.', animation: 'Animation name; with autotile, {mask} becomes the neighbour mask.' }) }, ['rows', 'legend']),
      lit: { type: 'boolean', description: 'false keeps this placement\'s authored colours under scene lighting: fires, lamps, glows and other light sources. Default true.' },
      parallax: { oneOf: [num(0, 4), { ...array(num(0, 4), 2), minItems: 2 }], description: 'How much of scene.camera\'s movement this placement or tilemap follows, as a number or [x, y]: 1 the scene (default), 0.5 a far plane, 0 fixed on screen (a sky), above 1 a plane nearer than the scene. Each plane rounds its share to whole pixels. Not on attached placements, which move with their target.' },
      haze: num(0, 1, 'How far into scene.haze this placement or tilemap stands: each of its colours moves this much of the way to the haze colour, after lighting (0 none, 1 the haze colour).'),
      shadow: { type: 'boolean', description: 'Cast a shadow from each scene light that reaches this placement (or each tile of this tilemap): its frame, a cutout standing on its ground line and facing the light, stops that light on what is drawn before it (before its sorted group, when sorted). Needs lighting.lights; not on shade placements.' }
    }, ['asset', 'at']), 256),
    camera: { oneOf: [point, { ...array(object({ time: cueTime(60000, 'Milliseconds or a named cue.'), at: point, ease: { ...ease, description: `Shape of the move from this key to the next: ${ease.description}` } }, ['time', 'at']), 256), minItems: 1 }],
      description: 'The scene point at the view\'s top-left corner: [x, y], or keys over time held before the first and after the last. Placements move by their parallax share of it; at [0, 0] everything is where it is written.' },
    haze: { ...object({ color: { type: 'string', pattern: opaqueHex, description: 'The colour far planes fade toward, usually the sky\'s.' }, colors: { ...array({ type: 'string', pattern: opaqueHex }, 64), minItems: 1, description: 'The only colours hazed placements may end on, with color: each faded colour becomes the nearest. List a fixed game palette, or a short ramp toward the haze for silhouettes. Without it, every colour fades exactly.' } }, ['color']),
      description: 'Atmospheric haze for placements with haze: each colour fades as a whole, never per pixel, so each becomes one colour and keeps its place among the others.' },
    lighting: object({ ambient: { type: 'number', minimum: 0, maximum: 1 }, bands: int(2, 16), scope: { enum: ['passes', 'all'], description: 'passes (default) lights only assets with normal/emissive passes; all also lights plain assets as flat surfaces.' },
      mode: { enum: ['multiply', 'ramp'], description: 'multiply (default) scales colours by the light; ramp moves each colour along its recipe\'s ramps instead, so the lit scene keeps its palette (light colour then only sets brightness).' },
      steps: int(1, 8, 'Ramp lighting: steps per unit of brightness away from 1; default 2.'),
      lights: array({ ...object({ at: { ...point, description: 'Where the light is, the point on the ground under it for shadows; with follow, an offset from what it follows (default [0, 0]). Not on a sun.' }, height: int(1, 256, 'Pixels above the scene; default 24. Not on a sun.'), radius: int(1, 512, 'How far it reaches; default 96. Not on a sun.'), color,
        sun: { ...array(num(-8, 8), 2), minItems: 2, description: 'Makes this light a sun: so far away it falls the same way everywhere, with no position, height or reach. [x, y] is how far a shadow falls across the ground per pixel of height: [1, 0.5] is a low sun up and to the left, whose shadows fall right and down; [0, 0] is overhead. Takes color, strength, flicker and strength keys.' },
        strength: num(0, 8, 'Brightness multiplier; default 1. Above 1, ramp lighting can lift colours past their authored shade (a flash); multiply lighting never brightens past the authored colour. 0 is off.'),
        follow: { ...object({ instance: { type: 'string', description: 'Name of a uniquely named placement that is not a tilemap.' }, point: { ...id, description: 'A named frame point of that placement (a torch flame, a blade tip); default: the placement point itself.' } }, ['instance']), description: 'Ride a placement as it moves, animates and attaches. The light is off while the placement is hidden or its current frame has no such point.' },
        flicker: { ...object({ amount: num(0, 1, 'How far it swings either way: 0.3 makes the strength vary from 70% to 130% of its own and the reach by up to 15% either way, so on average it is as bright as a steady light.'), every: int(10, 10000, 'About how often the flicker changes, in milliseconds; default 80.'), seed: int(0, 2147483647, 'Reorders the flicker; default 0. Each light flickers on its own even with the same seed.') }, ['amount']), description: 'Seeded, deterministic flicker that repeats once per scene duration, so a looping scene has no seam.' },
        keys: { ...array(object({ time: cueTime(60000, 'Milliseconds or a named cue such as "strike+70".'), strength: num(0, 8, 'Default: the light\'s strength.'), radius: int(1, 512, 'Default: the light\'s radius.'), ease: { ...ease, description: `Shape of the change from this key to the next: ${ease.description}` } }, ['time']), 64), minItems: 1,
          description: 'Strength and radius over time, held before the first key and after the last: a flash on a hit, a lamp that lights later. Times increase strictly.' }
      }), anyOf: [{ required: ['at'] }, { required: ['follow'] }, { required: ['sun'] }] }, 8) })
  }, ['format', 'version', 'name', 'width', 'height', 'assets', 'instances']), $defs: { ...schema.$defs, recipe: sceneRecipe }
};
// A terrain draws an autotile template from a description: a fill repeated every tile and an edge per side.
const paletteKey = { type: 'string', minLength: 1, maxLength: 1, description: 'A one-character palette key (template rows hold one character per pixel).' };
const keyList = description => ({ ...array(paletteKey, 64), description });
const terrainSide = object({
  depth: int(0, 63, 'Pixels between the tile border and the terrain on this side; the margin holds outside colours and tufts. Default 0.'),
  jitter: int(0, 63, 'The edge wanders up to this many pixels further in, seeded and repeating every tile. Default 0.'),
  size: int(1, 128, 'Pixels between the jitter\'s turns; default 4, or the tile size on a 2-pixel tile.'),
  bands: keyList('Colours of the terrain from this edge inward: an outline, then a rim light or a shade.'),
  outside: keyList('Colours of the margin from this edge outward, such as a cast shadow (a key with alpha).'),
  tufts: { ...object({ colors: { ...keyList('Blade colours from the edge outward; each blade is 1 to this many pixels long.'), minItems: 1 }, amount: num(0, 1, 'Share of the columns with a blade; default 0.5.'), seed: int(0, 2147483647) }, ['colors']), description: 'Seeded blades growing out of this edge into its margin: grass on a top edge, roots or drips under a bottom one.' }
});
const terrain = { ...object({
  seed: int(0, 2147483647, 'Seeds the edges, and the fill unless it has a seed of its own. Default 0.'),
  fill: { oneOf: [paletteKey, object({ color: paletteKey, speckle: { ...array(object({ color: paletteKey, amount: num(0, 1, 'Exact share of the tile in this colour.'), size: int(1, 128, 'Clump size in pixels; default 4, or the tile size on a 2-pixel tile.'), seed: int(0, 2147483647) }, ['color', 'amount']), 8), description: 'Seeded clumps of other colours over the fill colour, in order; each covers exactly its amount of the tile.' }, pattern: { ...ref('rows'), description: 'tile × tile rows repeated across the terrain instead of a colour.' }, seed: int(0, 2147483647, 'Seeds the speckle; default the terrain\'s seed. Give a variant another to vary the fill and keep the edges.') }) ],
    description: 'The inside of the terrain, repeated every tile so it never seams: a palette key, { color, speckle } or { pattern }.' },
  edges: { ...object({ all: terrainSide, n: terrainSide, e: terrainSide, s: terrainSide, w: terrainSide }), description: 'Each side\'s edge: n top, e right, s bottom, w left. all applies to every side and a side\'s own fields override it. depth + jitter + bands + round must fit in half a tile.' },
  round: int(0, 64, 'Round outer corners with this radius in pixels; default 0.'),
  inner: int(0, 64, 'Round inner corners with this radius; default 0.')
}, ['fill']), description: 'Draw the template from a description instead of rows: a fill that repeats every tile and an edge per side, which cannot seam. ops may draw over it.' };
const autotile = {
  $schema: schema.$schema, title: 'Pixelbolt autotile template',
  description: 'A template two tiles wide and three tall: row 0 holds an unused preview tile and an inner-corner tile; rows 1–2 hold a 2×2-tile island whose quadrants give outer corners, edges and fill. Give it as rows, or describe a terrain and let the compiler draw it; ops draw over either. Compiles to a recipe whose frames each draw one tile, with seam warnings and a test map of every tile.',
  ...object({ format: { const: 'pixelforge-autotile' }, version: { const: 1 }, name: id, tile: int(2, 84, 'Even tile size in pixels; the template is three tiles tall, at most 256 rows.'), mode: { enum: ['blob', 'cardinal', 'corner'], description: 'blob (default; corner with layers): 47 tiles; cardinal: 16 without inner corners; corner: 16 tiles that sit where four cells meet (a dual grid), drawing what blob does.' }, palette: schema.properties.palette,
    ramps: schema.properties.ramps, symbols: { ...schema.properties.symbols, description: 'Symbols the ops may stamp; not copied into the compiled recipe.' },
    template: { ...ref('rows'), description: 'tile × 3 rows of tile × 2 characters. Tiles are stitched from its quarters, so it has to repeat every tile.' },
    terrain,
    ops: { ...array(ref('op')), description: 'Drawing operations over the template (rows or terrain) on a canvas two tiles wide and three tall: stamp a flower, a crack or a stone inside one quarter, or dither and shade. Every colour drawn needs a one-character palette key.' },
    frame: { type: 'string', pattern: '\\{(?:mask|corners)\\}', description: 'Frame name template; {mask} is the neighbour mask and {variant} the variant name. A layered set uses {corners}: the layers\' keys at the tile\'s NW, NE, SW and SE corners.' },
    layers: { ...array(object({ name: { type: 'string', pattern: '^[a-zA-Z][a-zA-Z0-9_-]{0,31}$', description: 'The terrain\'s name, in engines.' }, key: { type: 'string', pattern: '^[a-zA-Z0-9]$', description: 'One letter or digit, unique among the layers ignoring letter case: the terrain\'s character in maps and tile names.' },
      terrain: { type: 'object', description: 'This layer\'s terrain, merged into the set\'s terrain (if any) field by field.' }, template: { ...ref('rows'), description: 'This layer\'s template rows instead of a terrain.' }, ops: { ...array(ref('op')), description: 'Drawn over this layer\'s template.' },
      weight: int(1, 1000, 'With variants: how often the plain tile (this terrain at all four corners) is picked against them; default 1.'),
      variants: { ...array(object({ name: { type: 'string', pattern: '^[A-Za-z0-9_-]{1,16}$' }, weight: int(1, 1000, 'Default 1.'), terrain: { type: 'object', description: 'Changes to this layer\'s terrain, merged into it: { "fill": { "seed": 2 } } is another fill.' },
        ops: { ...array(ref('op')), description: 'Drawn over the plain tile in tile pixels (a lily pad, a shell), a pixel inside its border.' } }, ['name']), 16), minItems: 1,
        description: 'Variants of the plain tile, named after it with -<name> and placed after the other tiles; transitions keep the layer\'s own fill. Each has a terrain or ops.' },
      collision: { oneOf: [{ type: 'boolean' }, object({ inset: { oneOf: [int(0, 41), object({ n: int(0, 41), e: int(0, 41), s: int(0, 41), w: int(0, 41) })], description: 'Pixels kept from the sides this terrain shares with lower ones; default its edges\' depth.' }, oneWay: { type: 'boolean', description: 'The same for every solid layer.' } })],
        description: 'Solid where this terrain shows: its corners, from where its edges start, less those of the terrains over it, from where theirs start.' } }, ['name', 'key']), 4), minItems: 2,
      description: 'A layered corner set of 2–4 terrains, bottom first (water, sand, grass): a tile for every mix of them at its four corners, n^4 in all, the lowest filling it and each higher one among them drawn over it. Variants and collision belong to the layers. Not with template, ops or animation.' },
    collision: { oneOf: [{ type: 'boolean' }, object({ inset: { oneOf: [int(0, 41), object({ n: int(0, 41), e: int(0, 41), s: int(0, 41), w: int(0, 41) })], description: 'Pixels the collision box keeps from each open side of a tile, under half a tile; default each terrain edge\'s depth, or 0.' }, oneWay: { type: 'boolean', description: 'One-way platforms: bodies pass up through and land on top.' } })],
      description: 'Give every tile a collision box (true, or { inset, oneWay }): the whole tile, kept inset from its open sides (a corner tile: its terrain quarters). Exported to the Godot TileSet.' },
    variants: { ...array(object({ name: { type: 'string', pattern: '^[A-Za-z0-9_-]{1,16}$' }, duration: int(1, 60000), palette: { type: 'object', additionalProperties: color },
      weight: int(1, 1000, 'How often this variant is picked against the others for a cell, in the test map and Godot; default 1. Give common variants 10 and a rare one 1.'),
      template: { ...ref('rows'), description: 'Redraw this variant from its own template of the same size (compiled as the symbol template-<name>): cracked or mossy stone with the base set\'s edges.' },
      terrain: { type: 'object', description: 'Changes to the set\'s terrain, merged into it field by field: { "fill": { "seed": 2 } } varies the fill and keeps the edges, so variants mix in a map.' },
      ops: { ...array(ref('op')), description: 'Drawn over this variant\'s template after the set\'s ops.' } }, ['name']), 16), minItems: 1 },
    animation: { type: 'string', pattern: '\\{mask\\}', description: 'Optional per-mask animation over the variants, in order.' },
    slopes: { ...object({ frame: { type: 'string', pattern: '\\{slope\\}', description: 'Frame name template; {slope} becomes up, down, gentle-up-low, gentle-up-high, gentle-down-high, gentle-down-low, and <slope>-foot for the tile under a slope\'s low end.' } }, ['frame']),
      description: 'A side-view blob or cardinal set\'s slopes, 45° and gentle (a cell up over two), cut from its top edge and fill so they meet its flat ground; solid under their line with collision. metadata.slopes gives a scene legend for them.' },
    preview: { ...object({ background: color }), description: 'The test map: background is drawn under it (the ground a transparent-edged set sits on).' },
    sheet: schema.properties.sheet
  }, ['format', 'version', 'name', 'tile', 'frame']), anyOf: [{ required: ['template'] }, { required: ['terrain'] }, { required: ['ops'] }],
  // The recipe's definitions that operations use; frames, layers and pixel corrections have no place here.
  $defs: Object.fromEntries(Object.entries(schema.$defs).filter(([key]) => !['frame', 'layer', 'pixel'].includes(key)))
};
const range = (minimum, maximum, description) => ({ oneOf: [num(minimum, maximum), pairOf(num(minimum, maximum))], description: `${description} [min, max] picks per particle.` });
const vector = (minimum, maximum, description) => ({ ...pairOf(num(minimum, maximum)), ...(description && { description }) });
const evenly = { type: 'boolean', description: 'Space the particles spawned together evenly instead of at random.' };
const emitter = { ...object({
  name: id, at: vector(-4096, 4096, 'Spawn centre [x, y] in canvas pixels. For a child (from), an offset from the parent particle; default [0, 0]. For a sprite emitter, the sprite\'s top-left corner, in whole pixels.'),
  area: { ...pairOf(int(1, 256)), description: 'Spawn box [w, h] centred on at; default [1, 1]. Use one of area, ring and line.' },
  ring: { ...object({ radius: range(0, 256, 'Distance from at.'), arc: { ...pairOf(num(-3600, 3600)), description: '[from, to] degrees clockwise (0 right, 90 down) to spawn over, at most 360 apart; default [0, 360].' }, even: evenly,
    outward: { type: 'boolean', description: 'Measure angle from each particle\'s outward direction: 0 straight out (the default angle), 90 clockwise along the ring, 180 inward. Shockwaves and radial bursts.' }, squash: vector(0.125, 8, 'Scale [x, y] of the ring, as a ring layer\'s squash: [1, 0.4] lays it on the ground, so sparks rise from a magic circle\'s ellipse.'), fill: { type: 'boolean', description: 'Pick the distance in a radius range evenly by area, so radius [0, r] fills a disc evenly instead of crowding its middle.' }, grow: { ...array(num(0, 16), 8), minItems: 2, description: '2–8 keys scaling the radius over the emitter\'s window, start to end, timed as a layer\'s keys: [0.2, 1] spawns on a shockwave\'s edge as it spreads, [1, 0] closes in.' } }, ['radius']),
    description: 'Spawn on a circle or arc around at instead of in a box.' },
  line: { ...object({ to: vector(-4096, 4096, 'The other end of the segment (for a child, an offset from the parent particle).'), even: evenly }, ['to']), description: 'Spawn along the segment from at to to instead of in a box.' },
  burst: int(1, 1024, 'Particles spawned at start (each cycle when looping); for a child, particles per event.'), rate: { oneOf: [num(0.001, 64), { ...array(num(0, 64), 8), minItems: 2 }], description: 'Particles per frame from start until end, or 2–8 keys spread from start to end that ramp it (thick at first and tapering, say); for a child with when: life, one number per frame for each parent particle.' },
  start: int(0, 255, 'Frame of the burst or first spawn; default 0.'), end: int(1, 256, 'Frame where a rate emitter stops; default the last.'),
  life: { oneOf: [int(1, 256), pairOf(int(1, 256))], description: 'Frames a particle lives; [min, max] picks per particle. Required to loop or dissolve; otherwise particles live to the end.' },
  angle: range(-3600, 3600, 'Launch direction in degrees, clockwise: 0 right, 90 down, 270 up. Default [0, 360].'), speed: range(0, 64, 'Launch speed in pixels per frame; default 0.'),
  sweep: { ...array(num(-3600, 3600), 8), minItems: 2, description: '2–8 keys in degrees added to angle over the emitter\'s window, start to end: a flamethrower that swings across ([-40, 40]), a fountain that sways. Not for child emitters.' },
  throttle: { ...array(num(0, 8), 8), minItems: 2, description: '2–8 keys scaling the launch speed over the emitter\'s window, start to end: a fountain that weakens ([1, 0.3]), a flamethrower dying out. Not for child emitters.' },
  gravity: vector(-8, 8, 'Acceleration [x, y] added each frame.'), drag: num(0, 1, 'Share of velocity lost each frame.'),
  curve: { type: 'boolean', description: 'Run a path of three or more points through a smooth curve, so an arc has no corner at its middle point.' },
  ease: { enum: EASINGS, description: 'How path, ring grow, sweep and throttle move over the emitter\'s window, as a layer\'s ease moves its keys: linear (default), in, out, inOut, hold, overshoot or bounce. Give a trail its head layer\'s ease to keep pace.' },
  path: { ...array(vector(-4096, 4096), 16), minItems: 2, description: 'Move the spawn centre through 2–16 points [x, y] over the emitter\'s window from start to end, timed as a layer\'s keys are (round a whole loop: end where it starts), instead of at: a meteor shedding smoke, a spark tracing a circle. Not for sprite or child emitters.' },
  attract: { ...object({ at: vector(-4096, 4096), strength: num(-8, 8, 'Acceleration toward at (negative repels); default 0.5.'), swirl: num(-8, 8, 'Acceleration across the line to at, clockwise when positive: particles spiral in or circle it (portals, whirlwinds, healing spirals). Default 0; a mirrored turn swirls the other way.') }, ['at']), description: 'Pull every particle toward a point.' },
  sway: { ...object({ amplitude: vector(0, 32, 'Drawn offset [x, y]: x follows a sine and y a cosine, from a random phase.'), period: num(1, 256, 'Frames per cycle; default 8.') }, ['amplitude']), description: 'Wobble, added when drawing (drifting leaves, rising embers).' },
  spin: { ...range(-180, 180, 'Degrees each particle\'s symbol turns a frame, from a seeded start, drawn in 45° RotSprite steps: shards, rocks and leaves that tumble. A number or [min, max]; the turned symbols join the recipe as <symbol>_r<degrees>, so the symbol\'s visible width plus height may be at most 360. Not with face.') },
  turbulence: { ...object({ strength: num(0, 4, 'Largest push per frame, in pixels per frame; default 0.3.'), scale: num(2, 64, 'Pixels across one swirl of the field; default 8.') }), description: 'Push particles by a smooth seeded field that stays put, so smoke and embers wander organically. It stays put in turned copies too, as gravity does.' },
  floor: int(-4096, 4096, 'Particles never go below this y, sway included.'), kick: vector(-64, 64, 'Velocity [x, y] in pixels per frame added to every launch, whatever its angle: [0, -1.5] makes outward shards on a ring laid on the ground pop up as they fly out. Turns with a turned copy.'), ground: num(-256, 256, 'A floor this many pixels below where each particle was born, instead of floor: shards thrown up from a ring laid on the ground land back on their own patch of it.'), bounce: num(0, 1, 'Share of downward speed returned at the floor or ground; default 0 (they settle).'),
  rest: { type: 'boolean', description: 'A particle that lands on its floor or ground stays where it lands: no more sliding, sway, spin or play: loop (with bounce, once a rebound is too slow to lift it: slower than its gravity or half a pixel a frame). Snow, leaves and coins that settle.' },
  shapes: { oneOf: [{ ...array(id, 64), minItems: 1 }, { ...array({ ...array(id, 64), minItems: 1 }, 64), minItems: 1 }], description: 'Symbol names drawn centred on the particle: one sequence, or a list of sequences with one picked per particle (or by direction, with face).' },
  face: { type: 'boolean', description: 'Pick the sequence by direction of travel instead of at random: shapes lists 2–16 sequences, the first facing right and the rest turning clockwise, evenly spaced (with 8: right, down-right, down, down-left, left, up-left, up, up-right). Streaking sparks and debris; a particle at rest keeps its last direction.' },
  play: { enum: ['life', 'loop', 'once'], description: 'life spreads the sequence over the lifetime (default); loop steps one symbol per frame from a random start; once steps and holds the last.' },
  remaps: { ...array(remap, 64), description: 'Colour variants; each particle picks one.' },
  tint: { ...array({ oneOf: [remap, color] }, 64), minItems: 1, description: 'Colour stages over each life, the first at birth, spread like play: life. A remap overrides the particle\'s remap for the characters it names, so a spark cools from white to red without a symbol per colour; one colour turns the whole particle that colour (a sprite\'s pixels flying off as light).' },
  trail: { ...object({ color, length: int(1, 16, 'Frames back the streak reaches; default 2.') }, ['color']), description: 'A one-pixel streak from an earlier position, drawn under the particle.' },
  dissolve: num(0, 1, 'Share of the life, at its end, during which the particle thins out through an ordered-dither pattern laid where it stands as it starts to dissolve and moving with it, so still particles thin out in step and a moving one loses its pixels in one fixed order instead of blinking.'),
  pattern: { oneOf: [{ enum: DITHER_PATTERNS }, { ...array({ ...array(int(0, 255), 16), minItems: 1 }, 16), minItems: 1 }], description: 'Dissolve pattern, as for the dither operation: bayer2, bayer4 (default), bayer8, noise (ordered by the effect\'s seed) or a matrix of ranks, e.g. [[0, 1, 2], [1, 2, 0], [2, 0, 1]] for diagonal stripes.' },
  from: { ...id, description: 'Make this a child of the earlier emitter with this (unique) name: it spawns from that emitter\'s particles at when, instead of on a schedule of its own (no start or end).' },
  when: { enum: FX_EVENTS, description: 'For a child: death (default; burst particles where a parent particle ends), floor (burst where it first lands on its floor) or life (rate particles per frame from each parent while it lives: trails).' },
  inherit: num(0, 2, 'For a child: the share of its parent particle\'s velocity it starts with, added to its own launch; on an emitter with a path, the share of its own motion along it, so sparks thrown by a projectile carry forward. Default 0.'),
  behind: { type: 'boolean', description: 'Draw this emitter\'s particles under every other emitter\'s (smoke behind sparks, a trail behind its bolt).' },
  depth: { enum: EMITTER_DEPTHS, description: 'Where its particles draw relative to a character standing in the effect: front (default; a child without depth takes its parent particle\'s side), back, split (born above the spawn centre: behind; the rest in front, as sparks rising round a circle on the ground) or between, for a sprite emitter that only draws: a stand-in character, drawn between the two in the whole effect and in neither part. Anything not in front also makes <effect>-back and <effect>-front.' },
  cue: { ...id, description: 'Name a point at the spawn centre in each frame this emitter spawns. Frames carry it as a named point, which atlases export for game code (a shake or a pause on impact); the metadata lists every cue.' },
  sprite: { ...object({ symbol: { ...id, description: 'The symbol whose pixels the particles spawn from: rows, or a frame or animation of a recipe or pose source (see symbols); an animation shows its frame i in frame i.' },
    pixels: { enum: SPRITE_PIXELS, description: 'all (default): every visible pixel; edge: the visible pixels beside an empty one; outline: the empty pixels just outside the sprite (particles from there need shapes or a blob).' },
    draw: { type: 'boolean', description: 'Draw the sprite itself under its particles: what is left of it during a release (the default there), or all of it every frame with burst or rate (default false, for an overlay the game draws over its own sprite). With no burst, rate or release, the emitter only draws the sprite: a character under its trail or aura.' } }, ['symbol']),
    description: 'Spawn on a symbol\'s pixels, its top-left corner at at, instead of around at. Without shapes or a blob each particle is its own pixel, in its colour: dissolves, teleports, sprites that shatter. With rate on the outline: sparkles round a figure.' },
  release: { ...object({ sweep: num(-3600, 3600, 'Direction the release travels across the sprite, in degrees clockwise (270 up: the lowest pixels leave first). Default none: a seeded random order.'), jitter: num(0, 1, 'How much each pixel\'s turn strays from the sweep; default 0.3.'), share: num(0, 1, 'Share of the leaving pixels that become particles; the rest just vanish on their turn. Default 1.') }),
    description: 'With a sprite, in place of burst or rate: every pixel leaves once, between start and end, while what is left of the sprite stays drawn. Not in a loop; reverse the animation to put a sprite together.' },
  blob: { ...object({ look: { ...id, description: 'The look it is drawn into; may be left out when the effect has one look.' },
    radius: { oneOf: [num(0, 64), { ...array(num(0, 64), 8), minItems: 2 }], description: 'Pixels: a number, or 2–8 keys spread over each particle\'s life (shrinking drops). Default 3.' },
    power: { oneOf: [num(0, 4), { ...array(num(0, 4), 8), minItems: 2 }], description: 'Scales the disc\'s field: a number, or 2–8 keys spread over each particle\'s life, so a hot drop cools through the look\'s bands (white, yellow, red) as it fades. Default 1.' },
    size: range(0.1, 8, 'Scales the radius, picked per particle: [0.6, 1.4] mixes small and large puffs so smoke and gas billow instead of sitting as one smooth lump. Default 1.') }),
    description: 'Draw each particle as a soft disc, (1 − d²/r²)², added to a look\'s field instead of stamping a symbol: touching drops merge into one body of water that stretches, pinches and splits, banded, lit and outlined by the look. Replaces shapes, face, play, remaps, tint, trail, dissolve, pattern and behind.' }
}), allOf: [{ anyOf: [{ required: ['at'] }, { required: ['from'] }, { required: ['path'] }] }, { anyOf: [{ required: ['shapes'] }, { required: ['blob'] }, { required: ['sprite'] }] }, { not: { required: ['shapes', 'blob'] } }] };
// Shape layers: each writes an intensity field inside its frame window; a look cuts the layers that name it into bands.
const tween = (minimum, maximum, description) => ({ oneOf: [num(minimum, maximum), { ...array(num(minimum, maximum), 8), minItems: 2 }], description: `${description} A number, or 2–8 keys spread evenly over the layer's frames through its ease.` });
const shading = object({ colors: { ...array({ type: 'string', minLength: 1, maxLength: 1 }, 8), minItems: 1, description: 'Palette keys, one per band.' }, thresholds: { ...array(num(0.001, 1), 8), minItems: 1, description: 'One rising share per colour, where its band begins.' } }, ['colors', 'thresholds']);
const shapeLook = object({
  colors: { ...array({ type: 'string', minLength: 1, maxLength: 1 }, 8), minItems: 1, description: 'Palette keys from the faintest band to the brightest.' },
  thresholds: { ...array(num(0.001, 16), 8), minItems: 1, description: 'One rising threshold per colour: a colour is on where the combined field reaches its threshold.' },
  dither: num(0, 1, 'Feather each band in below its threshold through the pattern, over this share of the gap to the band below; default 0 (hard bands).'),
  pattern: { oneOf: [{ enum: DITHER_PATTERNS }, { ...array({ ...array(int(0, 255), 16), minItems: 1 }, 16), minItems: 1 }], description: 'Dither pattern, as for the dither operation; default bayer4. Needs dither.' },
  outline: { type: 'string', minLength: 1, maxLength: 1, description: 'Palette key for a one-pixel outline on the empty pixels beside this look\'s own.' },
  halo: { ...object({ color: { type: 'string', minLength: 1, maxLength: 1, description: 'Palette key of the glow.' }, width: int(1, 4, 'Pixels it reaches beyond the look and its outline, measured round (one pixel is the four neighbours); default 1.'), dither: { type: 'boolean', description: 'Draw every other pixel, a soft glow (the default from width 2); false fills the band. A one-pixel band reads unevenly dithered.' } }, ['color']), description: 'A glow round this look on empty pixels, dithered when two or more pixels wide, so a bright shape glows without a hard ring.' },
  reach: num(0.5, 8, 'Pixels toward (and away from) the light over which lit and shade compare the field; default 2. 1 keeps a small drop\'s highlight to a thin rim, 3–4 spreads light over a large body. Needs lit or shade.'),
  light: vector(-1, 1, 'Direction toward the light for lit and shade, such as [-1, -1] (the default) for the upper left.'),
  lit: { ...shading, description: 'Highlight bands: recolour this look\'s pixels by the share (0–1) by which its field falls two pixels toward the light, 1 on a rim that faces it and 0 inside. Cel water, ice, slime.' },
  shade: { ...shading, description: 'Shadow bands, as lit but measured away from the light; lit wins where both apply.' },
  front: { type: 'boolean', description: 'Draw this look over the symbol particles instead of under them (smoke over sparks). Cleanup and outlines work within each of the two passes.' },
  hold: num(0, 0.45, 'Keeps bands from flickering: a pixel enters a new band as soon as the field crosses into it, but goes back to the band it just left only once the field has passed the threshold between them by this share of the gap between thresholds. Lit and shade bands hold too. A still field draws as without it, and loops still close exactly. Default 0.3; 0 draws each frame on its own.')
}, ['colors', 'thresholds']);
const layerCommon = {
  look: { ...id, description: 'The look that colours this layer; may be left out when the effect has one look.' },
  at: vector(-4096, 4096, 'Centre [x, y] (a beam or bolt starts here; an aura\'s sprite has its top-left corner here).'),
  frames: { ...pairOf(int(0, 256)), description: '[first, end]: the first frame drawn and the frame after the last; default the whole effect. Progress runs from 0 at first toward 1.' },
  ease: { ...ease, description: 'How tweened values move across the window: out (default; linear for a layer spanning a looping effect), linear, in, inOut, hold, overshoot or bounce.' },
  power: tween(0, 8, 'Multiplies the field: bright bands shrink as it falls, so the shape erodes instead of fading; default 1.'),
  flicker: num(0, 1, 'Every other frame of the window, power drops by this share. A drop smaller than the look\'s hold margin is held away; for crackle rather than a strobe, prefer noise with boil or flow.'),
  blend: { enum: ['max', 'add'], description: 'max (default): the brighter layer of a look wins; add: layers sum.' },
  curve: { type: 'boolean', description: 'Run three or more path points or drift keys through a smooth curve, so an arc has no corner at its middle.' },
  path: { ...array(vector(-4096, 4096), 16), minItems: 2, description: 'Absolute points [x, y] the layer moves through over its window, instead of at and drift: give a projectile\'s head the same path as the emitters trailing it.' },
  drift: { oneOf: [vector(-4096, 4096), { ...array(vector(-4096, 4096), 8), minItems: 2 }], description: 'Move by [x, y] pixels over the window (smoke rising), or 2–8 offsets [x, y] as keys spread over it through the ease, so the layer travels a curve (an orb that arcs).' }, floor: num(-4096, 4096, 'Cut the layer off below this canvas row: a disc becomes a dome, a ring an arch.'), seed: int(0, 2147483647, 'Seeded detail (noise, runes, bolt paths); default the layer index.'),
  cue: { ...id, description: 'Name a point at at in the layer\'s first frame, as an emitter cue does (a shake on impact).' },
  depth: { enum: LAYER_DEPTHS, description: 'Where the layer draws relative to a character standing in the effect: front (default), back, or split at its centre row (the far half above it behind, the near half in front: a ring or glyph lying round the feet). Anything not in front also makes <effect>-back and <effect>-front.' }
};
// The fields every kind shares are defined once, under $defs, and referenced from each kind.
// Tilt and squash, on the kinds drawn around a centre (not bolts and streams, which run between points).
const layerPlaced = {
  tilt: num(-3600, 3600, 'Rotate the shape clockwise by degrees.'), squash: { oneOf: [pairOf(num(0.125, 8)), { ...array(pairOf(num(0.125, 8)), 8), minItems: 2 }], description: '2–8 [x, y] pairs are keys spread over the layer\'s frames (a pool that rounds out as it shrinks). Scale [x, y] before tilt; [1, 0.4] lays a ring or circle on the ground. On a beam it shapes the round ends alone: give a pillar the squash of its circle so its foot lies on the same ground.' }
};
const layerRefs = Object.fromEntries(Object.keys(layerCommon).map(key => [key, ref(`layer-${key}`)]));
const placedRefs = Object.fromEntries(Object.keys(layerPlaced).map(key => [key, ref(`layer-${key}`)]));
const shapeLayer = (kind, description, properties, required = []) => ({ ...object({ kind: { const: kind }, ...layerRefs, ...(!['bolt', 'stream', 'aura', 'trail'].includes(kind) && placedRefs), ...properties }, ['kind', ...required]), allOf: [{ anyOf: [{ required: ['at'] }, { required: ['path'] }] }], description });
const reveal = share => num(0, 0.95, `Share of the window the shape takes to draw on; default ${share}${share ? ' (0 for a layer spanning a looping effect)' : ''}.`);
// Noise on the kinds without their own: smooth seeded noise in screen space that a falling power breaks the shape up through.
const grain = { noise: tween(0, 1, 'Seeded smooth noise: a pixel keeps value × power × (1 − noise × n), so as power falls toward the look\'s first threshold the shape breaks into pieces and drops; keyed, a shape can stand solid and then shatter. Default 0.'), scale: int(1, 64, 'Noise feature size in pixels; default 4.'), flow: vector(-512, 512, 'Pixels [x, y] the noise moves over the window (each cycle, seamlessly, for a layer spanning a loop): water running along a stream, a beam\'s texture streaming out. Needs noise.') };
const layer = { oneOf: [
  shapeLayer('ring', 'A shockwave: a crisp leading edge at radius, fading inward over width.', { radius: tween(0, 512, 'Pixels to the leading edge.'), width: tween(0, 256, 'Band thickness behind the edge; default 3. Ending at 2 or more, with noise, breaks a fading ring up instead of thinning it to an outline.'), fill: tween(0, 2, 'Glow inside the band, as a share; default 0.'), noise: tween(0, 1, 'Seeded breaks along the ring; default 0.'), scale: int(1, 64, 'Noise feature size in pixels; default 6.'), boil: num(-512, 512, 'Pixels the breaks churn through over the window (each cycle, seamlessly, for a ring spanning a looping effect), so a shield or portal rim never stands still; default 0. Needs noise.') }, ['radius']),
  shapeLayer('slash', 'A crescent: a crisp outer arc at radius, thickest mid-arc and pointed at both ends; the head sweeps arc during reveal and the tail chases it.', { radius: tween(1, 512, 'Pixels to the outer edge.'), width: tween(0, 256, 'Thickest point, inward from the edge; default 6.'), arc: { ...pairOf(num(-3600, 3600)), description: '[from, to] degrees clockwise (0 right, 90 down), at most 360 apart; the slash sweeps from the first to the second.' }, reveal: reveal(0.35), ...grain }, ['radius', 'arc']),
  shapeLayer('beam', 'A straight beam from at to to, brightest on its axis, with travelling ripples.', { to: vector(-4096, 4096, 'The far end.'), width: tween(0, 256, 'Pixels across; default 5.'), reveal: reveal(0.15), wobble: num(0, 1, 'Share by which the width ripples; default 0.15.'), wavelength: num(2, 512, 'Pixels between ripples; default 12.'), waves: num(-64, 64, 'Ripples that pass over the window; negative runs back toward at. Default 3.'), fade: num(0, 1, 'Share by which it dims toward to (a pillar of light); default 0.'), ...grain }, ['to']),
  shapeLayer('bolt', 'Lightning from at to to: a jagged one-pixel core with a glow and seeded branches, re-rolled every reroll frames.', { to: vector(-4096, 4096, 'Where it strikes.'), width: tween(1, 9, 'Core thickness in pixels; default 1.'), glow: tween(0, 4, 'Glow in pixels around the core; default 1.'), jag: num(0, 1, 'How far the path strays; default 0.35.'), branches: int(0, 8, 'Default 2.'), reroll: int(0, 256, 'Frames per new path; 0 keeps one. Default 2.'), segment: num(2, 64, 'Pixels per straight piece; default 4.'), reveal: reveal(0), ...grain }, ['to']),
  shapeLayer('glyph', 'A magic circle in one-pixel ink: an outer ring (doubled on request), an inner ring, upright seeded runes between them and an optional star polygon; it draws on clockwise from the top.', { radius: tween(2, 512, 'Outer ring radius.'), inner: num(0.2, 0.95, 'Inner ring as a share of radius; default 0.72.'), points: int(0, 12, 'Star corners on the inner ring: 0 for none (default 5).'), step: int(1, 6, 'Corners each star line skips to, fewer than points: 1 a polygon, 2 a pentagram from 5. Default the largest below half the corners: 1 for 3 or 4, 2 for 5 or 6, 3 for 7 or 8.'), runes: int(0, 48, 'Default 12.'), double: { type: 'boolean', description: 'A second outer ring two pixels inside the first.' }, spin: tween(-3600, 3600, 'Degrees the runes travel round (the star turns the other way); default 0.'), reveal: reveal(0.3), glow: tween(0, 4, 'Glow in pixels around the ink; default 1.'), fill: tween(0, 2, 'Glow inside the outer ring; default 0.'), ...grain }, ['radius']),
  shapeLayer('star', 'An impact star: points spikes, every other one ratio as long, tapering to one-pixel tips around a bright core.', { radius: tween(0, 512, 'Length of the long spikes.'), points: int(2, 16, 'Default 8.'), ratio: num(0.05, 1, 'Length of the short spikes; default 0.55.'), width: tween(0, 64, 'Half-width at the base; default 2.5.'), core: tween(0, 128, 'Core radius; default 1.2 × width.'), angle: num(-3600, 3600, 'Direction of the first spike; default 0 (right).'), spin: tween(-3600, 3600, 'Degrees turned over the window; default 0.'), jitter: num(0, 1, 'Seeded variation in spike length; default 0.'), ...grain }, ['radius']),
  shapeLayer('burst', 'A fireball or puff: a disc broken by seeded smooth noise that boils outward, hottest in the middle, with an optional hole opening from the centre.', { radius: tween(0, 512, 'Pixels.'), hole: tween(0, 1, 'Burnt-out centre as a share of radius; default 0.'), noise: tween(0, 1, 'Default 0.4.'), scale: int(1, 64, 'Noise feature size in pixels; default 4.'), boil: num(-512, 512, 'Pixels the noise moves outward over the window (each cycle, at a steady pace, for a layer spanning a looping effect); default half the largest radius.') }, ['radius']),
  shapeLayer('stream', 'A tapered body of water (or anything that flows) along a smooth curve from at through 1–7 more points, brightest on its centre line: the part between tail and head is drawn, narrowing by taper, swaying in travelling waves. Geyser spikes, whips, spirals, wave curls.', {
    through: { ...array(vector(-4096, 4096), 7), minItems: 1, description: 'More [x, y] points; the curve passes through at and each of them.' },
    width: tween(0, 256, 'Pixels across at the widest; default 6.'), taper: { ...array(num(0, 2), 8), minItems: 2, description: 'Width shares spread along the drawn part, from tail to head; default [0, 1, 0], pointed at both ends.' },
    head: tween(0, 1, 'Share of the curve the front has reached; default 1. Counts to the end of each frame, as reveals do.'), tail: tween(0, 1, 'Share of the curve the back has left behind; default 0.'),
    sway: num(-64, 64, 'Pixels it swings sideways at the far end, less toward at; default 0.'), wavelength: num(2, 512, 'Pixels between sway waves; default 16.'), waves: num(-64, 64, 'Sway waves that pass over the window; default 1.'), fade: num(0, 1, 'Share by which it dims toward the far end of its curve, as a beam\'s fade does: a tail that cools along its length, with no bright one-pixel tip. Default 0.'), ...grain }, ['through']),
  { ...shapeLayer('aura', 'A glow hugging a sprite (its top-left corner at at): brightest on it, banded outward to nothing about width pixels away and rise times as far upward, its edge licking up in flames as seeded noise rises. Power-ups, spirit auras, burning, a holy glow; draw the sprite over it.', {
    symbol: { ...id, description: 'The symbol it hugs: rows, or a frame or animation of a recipe or pose source (see symbols); an animation is hugged frame for frame.' }, width: tween(0, 32, 'Pixels the glow reaches beside and below the sprite; default 3.'),
    rise: num(1, 4, 'How many times further it reaches upward; default 2.'), noise: tween(0, 1, 'How far the noise moves the edge in and out and breaks up the bands; default 0.5.'), scale: int(1, 64, 'Noise feature size in pixels, stretched upright by rise; default 3.'),
    boil: num(-512, 512, 'Pixels the noise rises over the window (each cycle, at a steady pace, for a layer spanning a looping effect); default 2 × width × rise.'),
    around: vector(1, 64, 'Hug an ellipse of radii [x, y] centred on at instead of a symbol: its one-pixel ring (flames rising from a ground ring), or with disc the whole disc.'), disc: { type: 'boolean', description: 'With around, hug the filled ellipse instead of its ring.' } }), anyOf: [{ required: ['symbol'] }, { required: ['around'] }] },
  shapeLayer('trail', 'A smear behind a moving point, such as a sword tip: a stroke along a smooth curve through where the point was over the last length frames, tapered from its oldest end to its newest and dimming toward the oldest. Points are relative to at (the followed sprite\'s top-left corner).', {
    points: { ...array({ oneOf: [vector(-4096, 4096), { type: 'null' }] }, 256), minItems: 1, description: 'The point\'s place [x, y] in each frame of the effect from the first (null where it has none); or use follow.' },
    follow: { ...object({ recipe: { oneOf: [{ type: 'string', minLength: 1, description: 'A recipe, or a pose, fluid or wave source file, relative to this source (CLI and MCP).' }, { ...object({ revision: { type: 'string', minLength: 1 } }, ['revision']), description: 'A saved MCP revision.' }, { type: 'object', description: 'An inline recipe, or a pixelforge-poses, pixelforge-fluid or pixelforge-wave source.' }] }, animation: { type: 'string', minLength: 1, description: 'The animation whose frames the effect\'s frames follow, one for one.' }, point: { type: 'string', minLength: 1, description: 'A frame\'s named point (a pose marker), or part.point for a point of a pose part, such as blade.tip.' }, pivot: { type: 'string', minLength: 1, description: 'A point the smear sweeps round, named the same way, such as blade.anchor (where the blade is fixed: its hilt).' } }, ['recipe', 'animation', 'point']), description: 'Take points from a point of a recipe\'s or pose source\'s animation (a file through the CLI and MCP). Give the effect the animation\'s frame durations so the two stay in step.' },
    pivot: { oneOf: [vector(-4096, 4096), { ...array({ oneOf: [vector(-4096, 4096), { type: 'null' }] }, 256), minItems: 1 }], description: 'A point the smear sweeps round, relative to at: [x, y], or one per frame. Each step between frames then runs round it, and the smear lies inside the path, its outer edge where the point went: a blade\'s crescent. Default none: a smooth curve through the places.' },
    length: int(1, 16, 'Frames of the point\'s path the smear reaches back over; default 3.'), width: tween(0, 64, 'Pixels across at the widest; default 4.'),
    taper: { oneOf: [num(0, 2), { ...array(num(0, 2), 8), minItems: 2 }], description: 'Width shares from the oldest end to the newest; default [0, 1].' }, fade: num(0, 1, 'Share by which it dims toward its oldest end; default 0.5.'), ...grain }, [])
] };
const fx = {
  $schema: schema.$schema, title: 'Pixelbolt particle effects',
  description: 'Start sparks, fire, explosions, splashes and spells from a preset where one fits (pixel_help topic presets, then pixel_compile with preset); for fewer frames keep N evenly spaced frames with one pixel_patch call (the quick start shows it), never by lowering frames in the source, which cuts the effect off. Seeded particle emitters and shape layers (shockwave rings, slashes, beams, lightning, magic circles, impact stars, fireballs, streams of water) compiled into an ordinary recipe: one frame sequence and animation per effect (frames <effect>-0, <effect>-1…). Shapes draw as one grid per frame between behind particles and the rest; particles draw with stamp, grid and line operations on these symbols. Deterministic for a given seed.',
  ...object({ format: { const: 'pixelforge-fx' }, version: { const: 1 }, name: id, width: int(1, 256), height: int(1, 256), palette: schema.properties.palette,
    symbols: { type: 'object', minProperties: 1, propertyNames: id, additionalProperties: { oneOf: [ref('rows'), { ...object({ recipe: { oneOf: [{ type: 'string', minLength: 1, description: 'A recipe, or a pose, fluid or wave source file, relative to this source (CLI and MCP).' }, { ...object({ revision: { type: 'string', minLength: 1 } }, ['revision']), description: 'A saved MCP revision.' }, { type: 'object', description: 'An inline recipe, or a pixelforge-poses, pixelforge-fluid or pixelforge-wave source.' }] }, frame: { type: 'string', minLength: 1, description: 'The frame to take; default the first.' }, animation: { type: 'string', minLength: 1, description: 'Take every frame of this animation instead, in playing order: a sprite or aura then shows its frame i in the effect\'s frame i (holding the last; round again in a loop). Not a particle shape.' } }, ['recipe']), not: { required: ['frame', 'animation'] }, description: 'A frame (or an animation) of a recipe, or of a pose, fluid or wave source compiled first (a fluid\'s or wave\'s effects are its animations, so a simulated explosion can play under shape layers and particles), over its whole canvas (so it keeps the source\'s coordinates). Its colours join the palette under their own keys, or spare letters where the effect already uses a key for another colour.' }] }, description: 'Particle drawings and sprites; may be left out when no effect has emitters or auras.' }, anchor: schema.properties.anchor,
    effects: { type: 'object', minProperties: 1, maxProperties: 64, propertyNames: id, additionalProperties: { ...object({ frames: int(1, 256), duration: { oneOf: [int(1, 60000), array(int(1, 60000), 256),
      object({ from: int(1, 60000, 'Milliseconds of the first frame.'), to: int(1, 60000, 'Milliseconds of the last frame.'), ease: { ...ease, description: 'How durations move from from to to: linear (default), in (quick frames, then a slow settle: impacts), out, inOut, hold, overshoot or bounce.' } }, ['from', 'to'])],
      description: 'Milliseconds per frame, one per frame, or {from, to, ease} eased across the frames; default 100.' },
      loop: { type: 'boolean', description: 'Seamless loop: the simulation warms up so particles in flight at frame 0 are those alive at the end (needs a finite life), and layers spanning every frame cycle, so their last frame runs into their first.' }, seed: int(0, 2147483647, 'Default 1.'), emitters: { ...array(emitter, 16), minItems: 1, description: 'Particle emitters; may be left out when the effect has layers. Blob emitters draw into the looks.' },
      looks: { type: 'object', minProperties: 1, maxProperties: 8, propertyNames: id, additionalProperties: ref('shape-look'), description: 'Named colour ramps for the layers and blob particles, drawn in this order (later over earlier).' },
      layers: { ...array(layer, 16), minItems: 1, description: `Shape layers: ${SHAPE_KINDS.join(', ')}. Needs looks.` },
      cleanup: { ...object({ corners: bool, strays: bool }), description: 'Remove doubled corners and stray pixels from the shapes (not the particles).' },
      edges: { ...array({ enum: EDGE_SIDES }, 4), uniqueItems: true, description: 'Canvas sides the effect is meant to touch: top for a bolt from the sky, bottom for a figure standing on the bottom row. Drawing on any other side\'s outermost row or column is warned about, since whatever reaches past it is cut off. Turned copies turn the sides with them.' },
      light: { type: 'boolean', description: 'Write the light track into the frames as a point named light, where the effect\'s bright pixels are; frames with nothing bright have none. A scene light that follows { instance, point: "light" } then moves with the effect\'s light and goes dark when it does; atlases export the point for game code.' },
      turn: { ...object({ angles: { ...array(int(0, 359), 16), minItems: 1, uniqueItems: true, description: 'Whole degrees clockwise from the direction the effect is drawn in: [0, 90, 180, 270] for four directions, every 45 for eight. Default [0].' }, about: vector(-4096, 4096, 'The point the copies turn about (and mirror across); default the canvas centre.'), mirror: { type: 'boolean', description: 'Also make a mirrored copy of each angle, flipped left to right before it turns: a slash that sweeps the other way, an effect facing left.' } }),
        description: 'Compile a copy of the effect for each direction, named <effect>-<angle> (and <effect>-<angle>-mirror), with its geometry turned instead of its pixels rotated: places, spawn offsets, launch angles, attract points, slash arcs, beam and bolt ends, stream and trail points. Gravity, floors, sway and the looks\' light stay as they are, so sparks still fall and highlights stay where the light is. Not with sprite emitters or auras, whose sprites can\'t turn. Use a canvas with room in every direction.' } }, ['frames']), anyOf: [{ required: ['emitters'] }, { required: ['layers', 'looks'] }] } },
    sheet: schema.properties.sheet
  }, ['format', 'version', 'name', 'width', 'height', 'effects']), $defs: { rows: schema.$defs.rows, 'shape-look': shapeLook, ...Object.fromEntries(Object.entries({ ...layerCommon, ...layerPlaced }).map(([key, value]) => [`layer-${key}`, value])) }
};
const key = { type: 'string', minLength: 1, maxLength: 1, description: 'A one-character palette key (grid rows name colours by character).' };
const keys = description => ({ ...array(key, 16), minItems: 1, description });
const cycle = (extra, lowest, description, required = []) => ({ ...object({ ...extra, period: int(lowest, 256, `Frames per cycle; default the effect's frame count. A looping effect's period must divide its frame count.${lowest < 0 ? ' Negative turns anticlockwise; not 0.' : ''}`), phase: num(-3600, 3600, 'Degrees into the cycle at frame 0.') }, required), description });
const fluidEmitter = object({
  name: id, at: vector(-256, 512, 'Centre [x, y] in canvas pixels (one grid cell per pixel).'),
  radius: num(0.5, 64, 'A disc of this radius; default 2.'), area: { ...pairOf(num(1, 128)), description: 'A box [w, h] centred on at, instead of a disc.' },
  burst: num(0.01, 64, 'Add the amounts once, at start (each cycle when looping), times this strength.'),
  rate: num(0.01, 64, 'Every frame from start until end, raise the covered cells toward the amounts times this strength, so a steady source holds its level.'),
  start: int(0, 255, 'Frame of the burst or first emission; default 0.'), end: int(1, 256, 'Frame where a rate emitter stops; default the last. A short window (end: 3) gives a burst that keeps growing for a few frames.'),
  density: num(-16, 16, 'Gas: smoke added or held (default 0); negative drains. Liquid: share of each covered cell filled with water, 0–1 (default 1); negative drains that share of the particles there each frame.'),
  temperature: num(-16, 16, 'Gas: heat added or held; heat rises by buoyancy and maps to fire ramps. Default 0. Liquid with heat: the temperature of the water it adds (default the air\'s, heat.ambient).'),
  falloff: num(0, 1, 'The amounts fall off from the centre toward the rim: 1 at the centre, 1 - falloff at the edge of the disc (or the ellipse inside the box), so a puff is densest in the middle. Default 0, a flat disc or box.'),
  velocity: vector(-16, 16, 'Flow [x, y] in pixels per frame: a rate emitter steers its cells toward it (a jet; [0, 0] holds them still, as a drop gathering at a tip), a burst adds it once.'),
  expand: num(-16, 16, 'Push outward by this many pixels per frame while active (negative pulls inward): gas expands through the pressure solve, liquid particles are pushed.'),
  vortex: num(-16, 16, 'Swirl speed around at, in pixels per frame; positive turns clockwise on screen.'),
  noise: num(0, 8, 'Random push in pixels per frame, coherent over about three pixels and new every frame (seeded): turbulence.'),
  flicker: num(0, 1, 'Random variation of strength from cell to cell and frame to frame (seeded value noise), so a flame base breaks into tongues.'),
  pulse: cycle({ amplitude: num(0, 1, 'Share by which strength rises and falls; default 0.5. 1 switches the emitter off at the trough.') }, 1, 'Strength follows a sine wave: puffs, heaves, heartbeats.'),
  orbit: cycle({ radius: { oneOf: [num(0, 128), pairOf(num(0, 128))], description: 'Pixels from at, or [x, y] for an ellipse.' } }, -256, 'The emitter circles at (or follows an ellipse round it); a negative period turns anticlockwise. A rate emitter is laid along the path it covered since the last frame, so a fast orbit leaves a smooth trail.', ['radius']),
  carry: { ...object({
    drag: num(0, 1, 'Share of the difference between a carrier\'s velocity and the air\'s that it loses each frame; default 0.1. Low throws dust far, high lets the air take it at once.'),
    release: num(0.01, 1, 'Share of what a carrier still holds that it hands to the air each frame; default 0.2. What it holds is drawn with the smoke.'),
    gravity: vector(-2, 2, 'Each carrier\'s own acceleration [x, y]; a small positive y lets dust settle. Default [0, 0].')
  }), description: 'Gas: throw this emitter\'s smoke and heat (it needs a positive density or temperature) on heavy carriers, one per covered cell (each frame for a rate emitter, whose amounts are then thrown every frame; an orbiting one throws once a frame), launched with its velocity, vortex, expand (outward) and noise. A puff of gas cannot be thrown through still air, but dust can: carriers keep their momentum, slow by drag, hand their smoke to the air as they go and drop the rest where they meet an obstacle. For dust waves, skid smoke, dash trails.' },
  sparks: { ...object({
    count: num(0.01, 256, 'Sparks per frame for a rate emitter (at most 16; fractions spawn on some frames), or in all for a burst; follows pulse and flicker.'),
    life: { oneOf: [int(1, 256), pairOf(int(1, 256))], description: 'Frames each spark lives; [min, max] picks per spark. Default [8, 16]. In a liquid, spray (follow 0) still in the air then flies on, for up to as long again, until it falls back in.' },
    colors: keys('Palette keys spread over each spark\'s life, from birth to death.'),
    size: int(1, 3, 'Pixels across each spark; default 1. 2 reads at 1× (bubbles, embers, spray).'),
    trail: { type: 'boolean', description: 'Streak back to where the spark was a frame earlier, in the next colour of its list: flying debris, rising embers.' },
    angle: range(-3600, 3600, 'Launch direction in degrees, clockwise: 0 right, 90 down, 270 up. Default [0, 360].'), speed: range(0, 16, 'Launch speed in pixels per frame; default 0.'),
    gravity: vector(-2, 2, 'The spark\'s own acceleration [x, y]; negative y rises (bubbles, embers).'), drag: num(0, 1, 'Share of the spark\'s own speed lost each frame; default 0.05.'),
    follow: num(0, 2, 'How much the flow carries the spark: 1 (default) moves with the fluid, 0 ignores it (thrown debris). In a liquid, a spark with follow 0 that leaves the water ends where it falls back in (spray); one riding the flow out of the water flies on as a droplet, falling with the liquid\'s gravity unless it has its own, and ends the same way.'),
    pop: { type: 'boolean', description: 'Liquid only: the spark pops where it leaves the liquid, drawn as a ring around it for one frame and two droplets the next (bubbles bursting at the surface).' },
    rise: num(0, 4, 'Liquid: makes the spark a bubble that behaves like air. It rises this many pixels per frame through still water, against the liquid\'s gravity, on top of the flow that carries it (follow); it slides along any obstacle or closed edge it meets instead of ending there, up a sloping ceiling and out from under a ledge within 5 pixels, or waits under it, where waiting bubbles that touch merge into larger ones (up to 3 pixels across); it ends where it reaches the air, bursting there with pop. About 0.3–0.8.'),
    wobble: num(0, 2, 'With rise: pixels the bubble sways from side to side as it rises, once every eight frames from a seeded start. Default 0.'),
    lift: num(0, 1, 'With rise: share of its buoyancy the bubble hands to the water around it, as if that much of the water weighed nothing. A column of bubbles then drives an upwelling: 1 with about a bubble a frame raises a dome on the surface over it, 0.3 a slight bump. Default 0.')
  }, ['count', 'colors']), description: 'One-pixel particles carried by the flow and drawn over it: embers, sparkles, debris, bubbles. In a loop they wrap round, so they loop exactly.' }
}, ['at']);
const fluidLook = object({
  field: { enum: FLUID_FIELDS, description: 'density (smoke or water; water is 1 inside), temperature (gas heat; a liquid\'s water, ice or vapour with heat), speed (pixels per frame; foam, fast flow; a liquid has speed where there is water, a gas wherever its air moves, smoke or not), depth (pixels down from the liquid surface, 1 on the top row; from the third row down it follows the shallowest surface within three pixels along the row), light or shadow (0–1: how sharply density falls toward or away from the light; these only recolour pixels earlier layers drew), strand (liquids: 1 along a one-pixel path through liquid stretched thinner than the density can draw, a string joining two pieces or hanging at least 3 pixels off one, such as honey pulled up after a spoon), ionization (electric gases, and over a liquid in the vapour look: plasma, 0–1, 1 in a live channel, fading as it recombines) or current (electric gases and vapours: the current through each pixel; peak.current in the metadata gives the brightest).' },
  colors: keys('Palette keys from the lowest level to the highest.'),
  thresholds: { ...array(num(0.001, 256), 16), minItems: 1, description: 'One rising value per colour: each colour is fully on from its threshold up.' },
  dither: num(0, 1, 'Feather each colour in below its threshold through the pattern, over this share of the gap to the previous threshold (to 0 for the first). 0 draws hard bands; default 0.5.'),
  pattern: { oneOf: [{ enum: DITHER_PATTERNS }, { ...array({ ...array(int(0, 255), 16), minItems: 1 }, 16), minItems: 1 }], description: 'Dither pattern, as for the dither operation: bayer4 (default), bayer2, bayer8, noise or value (seeded by the effect) or a matrix of ranks. Anchored to the canvas, so it never crawls.' },
  halo: { ...object({ color: key, width: int(1, 4, 'Pixels of glow; default 1 (the four neighbours).') }, ['color']), description: 'A glow of one colour on the empty pixels within width of what this layer drew: an arc\'s glow, a rim round a flame.' }
}, ['field', 'colors', 'thresholds']);
const fluidWhitewater = { ...object({
  impact: num(0.05, 32, 'Throw where a particle\'s velocity changes by at least this many pixels per frame within one frame: a drop landing, water striking water. Use impact or speed.'),
  speed: num(0.05, 32, 'Throw where a particle moves at least this many pixels per frame: a fast stream shedding drops. Use impact or speed.'),
  chance: num(0.001, 1, 'Share of qualifying surface particles that throw a droplet each frame (a seeded draw per particle); default 0.1.'),
  throw: num(0, 4, 'Droplet speed as a share of the impact or speed; default 1.'), spread: num(0, 180, 'Degrees of random turn either way; default 20.'),
  life: { oneOf: [int(1, 256), pairOf(int(1, 256))], description: 'Frames each droplet lives; [min, max] picks per droplet. Default [6, 12]. Spray still in the air then flies on, for up to as long again, until it falls back in.' },
  colors: keys('Palette keys spread over each droplet\'s life, from birth to death.'), size: int(1, 3, 'Pixels across each droplet; default 1.'),
  trail: { type: 'boolean', description: 'Streak back to where the droplet was a frame earlier, in the next colour of its list.' },
  gravity: vector(-2, 2, 'The droplet\'s own acceleration [x, y]; default the effect\'s gravity.'), drag: num(0, 1, 'Share of the droplet\'s speed lost each frame; default 0.02.'),
  follow: num(0, 2, 'How much the flow carries the droplet: 0 (default) is spray, drawn once it has left the water and ending where it falls back in; above 0 is foam carried on the flow, ending once it is carried under. Bubbles default to 1.'),
  rise: num(0, 4, 'Makes the layer bubbles instead of spray: air a plunging stream (speed) or a landing drop (impact) drives into a pool. They start under the surface, where water lies two pixels deep on every side, at rest in the water; they rise this many pixels per frame against the liquid\'s gravity, ride the flow, slide under obstacles and end at the surface, as sparks with rise do. throw, spread and gravity shape spray only.'),
  wobble: num(0, 2, 'Bubbles: pixels each sways from side to side as it rises, once every eight frames. Default 0.'),
  lift: num(0, 1, 'Bubbles: share of each one\'s buoyancy handed to the water around it (see the sparks\' lift). Default 0.'),
  pop: { type: 'boolean', description: 'Bubbles: burst where they reach the surface, a ring for one frame and two droplets the next. Default false: they vanish there.' }
}, ['colors']), oneOf: [{ required: ['impact'] }, { required: ['speed'] }],
  description: 'Spray and foam thrown off the liquid by its own motion, from particles at the surface, tipped away from the water; or, with rise, bubbles driven under it.' };
// Electricity: a voltage on every frame of the cycle, as a number or keys.
const volts = num(-1000, 1000);
const fluidElectric = { ...object({
  breakdown: num(0.01, 1000, 'Field, in volts per pixel, at which neutral gas breaks down; lower in hot gas. Default 3.'),
  focus: num(0.5, 8, 'How strongly growth favours the strongest field: about 1 forks freely like lightning, 3–4 runs on one path like an arc between close plates. Default 2.'),
  growth: int(1, 256, 'Cells of new plasma a frame, drawn one at a time where the field most exceeds breakdown (a leader\'s speed). Default 8.'),
  recombine: num(0, 1, 'Share of ionization lost a frame where no current holds it (slower in hot gas): the afterglow. Default 0.3.'),
  sustain: num(0.001, 1000, 'Current that keeps a channel fully ionized; below half of it a channel goes out. Default 0.5.'),
  memory: num(0, 256, 'Frames a spent channel keeps guiding new strikes, which run down it at once (a restrike on the same channel). 0: none. Default 8.'),
  heating: num(0, 16, 'Temperature added a frame per unit of current squared (Joule heating), so buoyancy lifts an arc. Default 0.2.'),
  ionize: num(0, 64, 'Gas hotter than this is plasma too, fully at half as hot again: an arc\'s hot air, a fireball\'s core. Default 2, above every flame on the shared heat scale; 0 turns it off.'),
  ground: { ...array({ enum: FLUID_WALLS }, 4), uniqueItems: true, description: 'Canvas edges held at 0 V, the world beyond: arcs that reach them strike them.' },
  iterations: int(1, 200, 'Conjugate-gradient steps of the field solve each step; default 24.')
}), description: 'Electricity and plasma. Obstacles with a voltage are electrodes; the field between them breaks the gas down into branching channels that conduct, glow, heat the gas and recombine. Defaults apply when only an obstacle has a voltage. A liquid with heat and vapour carries it too: arcs burn in the air over it (drawn by the vapour\'s look), land on the water, which conducts, and their current heats the water where they land, so it boils; ice hardly conducts.' };
const fluidShape = object({ x: int(0, 127), y: int(0, 127), w: int(1, 128), h: int(1, 128), at: vector(-256, 512), radius: { oneOf: [num(0.5, 128), pairOf(num(0.5, 128))], description: 'Pixels from at, or [x, y] for an ellipse.' }, velocity: vector(-16, 16, 'Starting velocity [x, y] in pixels per frame.'), burst: { ...object({ speed: { ...range(0, 16, 'Speed'), description: 'How fast each piece flies out from the middle of the fill, in pixels per frame; [min, max] picks per piece.' }, pieces: int(2, 64, 'How many pieces. Default 8.') }, ['speed']), description: 'Break the fill into seeded pieces with a one-pixel gap between them and rounded corners, each flying straight out at its own speed (plus velocity): a liquid burst in mid-air. Outward velocity on one connected blob is cancelled by the pressure solve; separate pieces keep it. The water of the gaps and corners goes to their pieces, so the volume is kept.' },
  temperature: num(-16, 16, 'With heat: the fill\'s temperature; default the air\'s (heat.ambient).'), frozen: { type: 'boolean', description: 'With heat: the fill starts as ice (an ice cube, a frozen pond); give it a temperature at or below heat.freeze.' },
  vapour: num(0.01, 4, 'With vapour: the fill holds still vapour of this density (1 a full cell of steam) instead of water: humid air for dew or frost.') });
const bodyKey = { type: 'string', minLength: 1, maxLength: 1, description: 'A one-character palette key; dot and space are reserved.' };
const bodyMaterial = {
  bounce: num(0, 1, 'How much of its approach speed a body keeps in a bounce: 0 lands dead, 1 bounces back as fast. A pair bounces with the larger. Default 0.3.'),
  friction: num(0, 2, 'Sliding friction; a pair uses the square root of the product. Default 0.4.')
};
// A power, for pickups, events and strikes.
const powerFields = {
  power: { enum: ['split', 'grow', 'speed', 'warp', 'magnet', 'vanish', 'break'], description: 'split: copies turned about its heading; grow: a bigger body for frames; speed: its held speed (or speed) times factor for frames; warp: moves it to to; magnet: pulls the other teams\' bodies toward to (default the pickup) for frames; vanish: the body is gone (an event may take a fixed body away: a ring bursts); break: the body breaks into count pieces, each carrying its part of the picture (an event may break a fixed body, whose pieces fall).' },
  label: { type: 'string', maxLength: 40, description: 'For {news}. Default the power in capitals.' },
  count: int(2, 8, 'split: bodies after. Default 3. break: pieces. Default 6.'), spread: num(1, 180, 'split: degrees between headings. Default 30.'), scale: num(1.25, 4, 'grow. Default 2.'), factor: num(0.25, 4, 'speed. Default 1.5.'),
  to: { ...pairOf(num(-4096, 8192)), description: 'warp, magnet: a canvas point [x, y], each from minus the canvas side to twice it.' }, strength: num(0.001, 1, 'magnet: pixels a frame² . Default 0.05.'), frames: int(1, 18000, 'grow, speed, magnet: how long. Default 120.')
};
const point2 = pairOf(int(-4096, 4096));
// A body's or team's name: as id, at most 60 characters.
const shortId = { ...id, pattern: '^[a-zA-Z][a-zA-Z0-9_-]{0,59}$' };
const body = object({
  name: { ...id, maxLength: 60, description: 'Names the body in the metadata (its path, frame by frame, and when it leaves the canvas). Copies are numbered name-0, name-1, …' },
  shape: { enum: ['circle', 'box', 'polygon', 'hoop'], description: 'circle (radius; 0.5 is one pixel), box (size), polygon (convex points) or hoop (a ring of thin walls with an optional gap, for a fixed container).' },
  radius: num(0.5, 128, 'circle: 0.5–32 pixels, drawn as an ellipse of diameter round(2 × radius). hoop: 2–128.'),
  size: { ...pairOf(num(1, 64)), description: 'box: [width, height] in pixels.' },
  points: { ...array(pairOf(num(-64, 64)), 8), minItems: 3, description: 'polygon: 3–8 convex points [x, y] around the body\'s centre, recentred on their centroid.' },
  sides: int(3, 96, 'hoop: straight walls around it. Default: its radius, from 8 to 64.'),
  gap: num(0, 330, 'hoop: degrees left open, centred on the hoop\'s angle (0 points right, 90 down). Default 0, closed.'),
  thickness: num(1, 8, 'hoop: wall thickness in pixels. Default 1.'),
  at: { ...pairOf(num(-4096, 4096)), description: 'Centre [x, y] in canvas pixels; [10.5, 10.5] is the middle of pixel (10, 10). The centre of a ring or the first copy of a grid. With pivot, where the pivot is.' },
  pivot: { ...pairOf(num(-128, 128)), description: 'Fixed body: the point it turns about, [x, y] from its centre before it turns (a blade about its hilt: [-length / 2, 0]); at places it. Default its centre.' },
  angle: num(-3600, 3600, 'Degrees clockwise. Default 0. Drawn to the whole degree with straight, even sides (under 6 pixels across, always square); collisions use the exact angle.'),
  velocity: { ...pairOf(num(-8, 8)), description: 'Starting velocity [x, y] in pixels a frame; for a fixed body, how it moves for ever. Speeds stop at 8.' },
  spin: num(-45, 45, 'Starting spin in degrees a frame, clockwise; for a fixed body, how it turns for ever.'),
  fixed: { type: 'boolean', description: 'Never pushed: a wall, peg or container. With velocity or spin it moves exactly so, pushing what it meets.' },
  weightless: { type: 'boolean', description: 'Gravity doesn\'t pull it: it floats where it is put, drifting only when hit.' },
  asleep: { type: 'boolean', description: 'Starts asleep: holds exactly still, even in the air, until something moves into it.' },
  tireless: { type: 'boolean', description: 'Every hit gives back the energy (speed plus height against gravity) the hit cost, so a ball keeps bouncing at full height among loose blocks. An open cheat; off by default.' },
  speed: num(0.05, 8, 'Held speed, pixels a frame: set back to it along its heading after every step, so a ball crossing a board never tires. An open cheat, like tireless.'),
  team: { type: 'string', description: 'A territory team\'s name: the body passes through that team\'s cells, bounces off the other teams\' and claims each one it hits.' },
  density: num(0.05, 100, 'Mass per square pixel. Default 1. A heavier body pushes lighter ones about and keeps its own speed.'),
  ...bodyMaterial,
  drag: num(0, 1, 'About the share of its speed lost each frame. Default 0.'),
  spinDrag: num(0, 1, 'About the share of its spin lost each frame. Default 0.02.'),
  fill: { oneOf: [bodyKey, { ...array(bodyKey, 16), minItems: 1 }], description: 'Palette key, or a list the body steps through at each hit.' },
  fillEvery: int(1, 18000, 'With a list of fills: the list steps every this many frames instead of at each hit. The body keeps its fill until it splits; then it and its copies take the fill of that frame, so each generation of a crowd that multiplies has its own colour.'),
  outline: { ...bodyKey, description: 'Key for the pixels on the shape\'s edge.' },
  symbol: { type: 'string', description: 'Draw this symbol instead of fill and outline, centred on the body and turned with it to the whole degree, its outline kept a closed line (under 6 pixels across, in quarter turns).' },
  trail: object({ color: bodyKey, length: int(1, 16, 'Frames of trail. Default 2.') }, ['color']),
  smear: { ...object({ colors: { ...array(bodyKey, 8), minItems: 1, description: 'The most recent part of the sweep first.' }, frames: int(1, 8, 'Frames of sweep. Default 1.') }, ['colors']), description: 'The shape swept over its last frames, drawn under it, banded from the first colour behind it to the last: a blade\'s swish. Not for a hoop.' },
  breaks: { ...object({ at: num(0.1, 16, 'How hard a knock breaks it: the speed it is hit at where it is hit (with the bounce), in pixels a frame, shared with what hits it by how easily each gives there. Default 3.'), pieces: int(2, 16, 'Pieces it breaks into, fewer where a piece would be too small to read. Default 6.'), speed: num(0, 8, 'Pixels a frame the pieces fly apart at, away from where it was hit, on top of its own motion. Default 0.5.') }), description: 'A free body that breaks when knocked hard enough, in a pixelforge-bodies source: into convex pieces cut through its shape about where it was hit, smaller there, each a body of its own carrying its part of the picture. Pieces do not break again.' },
  ring: object({ radius: num(1, 256), count: int(2, 256), from: num(-3600, 3600, 'Degrees of the first copy. Default 0.'), to: num(-3600, 3600, 'Degrees of the last; default a full turn, spaced evenly.') }, ['radius', 'count']),
  grid: object({ count: { ...pairOf(int(1, 256)), description: '[columns, rows].' }, step: { ...pairOf(num(-256, 256)), description: '[x, y] between copies.' }, stagger: num(-256, 256, 'Shifts odd rows across. Default 0.') }, ['count', 'step'])
}, ['shape', 'at']);
// A source's subpixels: bodies drawn finer than the world's pixels.
const subpixels = world => int(1, 8, `Draw the bodies this many times finer than the world's pixels: each pixel of a body's picture turns as a square and the body sits where it is to a fraction of a pixel, so it turns and moves smoothly without changing shape; ${world} are drawn in blocks this size. The recipe's canvas is width and height times this, at most 256 a side and 4,194,304 pixels over its frames. Default 1, bodies at whole pixels.`);
// In a fluid a body can also have a temperature, where the fluid has heat (a gas always does).
const fluidBody = { ...body, properties: { ...Object.fromEntries(Object.entries(body.properties).filter(([key]) => key !== 'team' && key !== 'breaks')), temperature: num(-16, 16, 'With heat (a gas, or a liquid with heat): the temperature the body keeps, warming or chilling what it touches as a hot obstacle does, so a red-hot stone boils the water it lands in. Default none.') } };
const fluid = {
  $schema: schema.$schema, title: 'Pixelbolt fluid effects',
  description: 'Start fire, smoke, explosions and splashes from a preset (pixel_help topic presets, then pixel_compile with preset); for fewer frames keep N evenly spaced frames with one pixel_patch call (the quick start shows it), never by lowering frames in the source, which stops the simulation early. A deterministic fluid simulation compiled into an ordinary recipe: one frame sequence and animation per effect (frames <effect>-0, <effect>-1…), each frame a palette grid operation, with obstacles stamped from symbols. Gases (smoke, fire, steam, explosions, magic) run stable fluids with buoyancy, vorticity confinement, dissipation and cooling; liquids (splashes, waterfalls, drips, potions) run FLIP particles on the same grid. Either may be viscous (honey, syrup, tar), and a liquid may have a yield stress (mud, slime). Look layers map fields onto palette ramps through ordered dither, so no colour outside the palette can appear. Looping effects warm up for whole cycles and blend their closing frames toward the frames before frame 0, so the last frame flows into the first. The same source gives the same recipe on every machine.',
  ...object({ format: { const: 'pixelforge-fluid' }, version: { const: 1 }, name: id, width: int(4, 128, 'Canvas width in pixels; the grid has one cell per pixel.'), height: int(4, 128), subpixels: subpixels('the liquid and its obstacles'), palette: schema.properties.palette,
    symbols: { type: 'object', propertyNames: id, additionalProperties: ref('rows'), description: 'Named rows for obstacles: braziers, logs, pipes, flasks, rocks.' }, anchor: schema.properties.anchor,
    effects: { type: 'object', minProperties: 1, maxProperties: 16, propertyNames: id, additionalProperties: object({
      kind: { enum: FLUID_KINDS, description: 'gas (default): smoke, fire, steam, explosions, magic. liquid: water, potions, honey and slime as FLIP particles.' },
      frames: int(1, 256), duration: { oneOf: [int(1, 60000), array(int(1, 60000), 256)], description: 'Milliseconds per frame, or one per frame; default 80.' },
      loop: { type: 'boolean', description: 'Seamless loop: emitter timing, pulses, orbits and noise repeat every cycle; the simulation warms up and its closing frames blend toward the frames before frame 0.' },
      seed: int(0, 2147483647, 'Default 1.'), warmup: int(1, 8, 'Loops: whole cycles simulated before the recorded one; default 2. Raise it when a flow takes long to settle (a filling pool).'),
      blend: int(1, 128, 'Loops: closing frames blended toward the previous cycle\'s; default a third of the frames, at most 8.'),
      substeps: int(1, 16, 'Simulation steps per frame; default 2. Raise for fast liquids; time grows with it (8 takes about twice as long as 4).'), iterations: int(1, 200, 'Pressure solve work per step, and with viscosity or yield as many steps of the viscosity solve; default 30 (gas) or 40 (liquid). A gas takes this many sweeps; a liquid a third as many conjugate-gradient steps, which settle long columns and channels.'),
      buoyancy: num(-2, 2, 'Gas: upward acceleration per unit of temperature; default 0.15.'), weight: num(-2, 2, 'Gas: downward acceleration per unit of density (negative floats smoke); default 0.'),
      vorticity: num(0, 2, 'Gas: vorticity confinement, which keeps small swirls so smoke curls; default 0.25.'),
      dissipation: num(0, 1, 'Gas: share of density lost per frame; default 0.03.'), cooling: num(0, 1, 'Gas: share of temperature lost per frame; default 0.08.'),
      drag: num(0, 1, 'Share of velocity lost per frame, as if the surroundings held the fluid back (water under water, a gas in still air); it slows falling too. For a thick fluid use viscosity. Default 0.02 (gas) or 0 (liquid).'), wind: vector(-2, 2, 'Gas: acceleration [x, y] everywhere.'),
      advection: { enum: ['smooth', 'sharp'], description: 'Gas: smooth (default) is plain semi-Lagrangian advection, which blurs a little every step; sharp (MacCormack with a limiter) keeps edges and small swirls crisp, at up to twice the cost; smoke lingers longer, so a one-shot may need more dissipation to end empty.' },
      viscosity: num(0, 64, 'Thickness, in square pixels per frame: it slows shearing and stretching but not falling or turning as a whole, so a thick drop falls as fast as water but spreads slowly and a stream never breaks into drops. Liquids: about 0.5 oil, 2–4 syrup, 8–16 honey, 32–64 tar. Gases: 0.1–1 for slow, smooth flows (a swirl dies away within frames above 1). Walls and obstacles hold a viscous fluid unless slip is set. Default 0.'),
      yield: num(0, 16, 'Liquid: yield stress, for mud, slime, dough and toothpaste. Below it the liquid is elastic and keeps its shape, squashing and springing back; pushed past it, it flows. A heap h pixels high holds itself up when yield is more than about gravity × h / 2. Default 0.'),
      slip: { type: 'boolean', description: 'With viscosity or yield: the fluid slides along walls and obstacles instead of being held by them (a greased pan). Default false.' },
      gravity: vector(-2, 2, 'Liquid: acceleration [x, y]; default [0, 0.3]. Gas: only with bodies, the pull on them (the gas itself rises by buoyancy); default [0, 0.3].'), flip: num(0, 1, 'Liquid: FLIP share of each particle\'s velocity (lively, noisier) against the grid\'s (calm); default 0.9. A viscous liquid lowers it where it is thick.'),
      apic: { type: 'boolean', description: 'Liquid: affine particle-in-cell. The calm (grid) share of each particle\'s velocity also carries the turning and shearing of the flow around it, so calm and thick liquids keep their swirls and folds instead of smearing them. Use it with a low flip. Default false.' },
      tension: num(0, 4, 'Liquid: cohesion that keeps drops and streams together; default 0.5.'),
      adhesion: num(0, 4, 'Liquid: how strongly it holds on to walls and obstacles. Liquid touching a solid stays on it unless pulled away faster than about adhesion ÷ 2 pixels per frame, so a film clings under a ledge, to a spoon or down a jar\'s side, and moves with an obstacle that moves. An obstacle\'s own adhesion replaces it there. Default 0.'),
      keys: { ...array(object({ frame: int(0, 255, 'The frame (within the cycle, for a loop) the change starts on.'), over: int(0, 256, 'Frames to move to the new values in a straight line; default 0, at once.'), yield: num(0, 16), viscosity: num(0, 64), adhesion: num(0, 4), gravity: vector(-2, 2), drag: num(0, 1) }, ['frame']), 16), minItems: 1, description: 'Liquid: change yield, viscosity, adhesion, gravity or drag at a chosen frame, so the decisive moment lands where you want it: a heap held up by its yield gives way when a key drops it, a blob held under a ledge by adhesion drops when a key sets adhesion to 0, and drag (not viscosity, which freezes a slosh tilted) calms a one-shot so it ends at rest. Each setting starts from the effect\'s own value and follows the keys that name it, in frame order; a loop repeats them every cycle.' },
      fill: { ...array(fluidShape, 64), description: 'Liquid: water at frame 0 in discs or ellipses (at, radius), boxes (x, y, w, h) or their overlap (both): a disc cut by a box is a dome.' },
      walls: { ...array({ enum: FLUID_WALLS }, 4), uniqueItems: true, description: 'Closed canvas edges. Open edges (the default) let gas and water out.' },
      obstacles: { ...array(object({ symbol: id, x: int(-256, 128, "Left edge; it may hang off the canvas by up to the symbol's width, and what hangs off is clipped."), y: int(-128, 128, "Top edge; it may hang off the canvas by up to the symbol's height, and what hangs off is clipped."), draw: { enum: ['over', 'under', 'none'], description: 'over (default): stamped in front of the fluid, its outline and sparks; under: behind its outline and sparks (the fluid itself never enters a solid obstacle); none: an invisible wall.' }, surface: { enum: ['pixels', 'smooth'], description: 'pixels (default): the fluid meets every pixel step. smooth: it meets an outline traced through the steps, so a liquid slides down a drawn slope, roof or chute (a 1:1 staircase acts as a straight 45° slope; draw lines at least 2 pixels thick to smooth both sides), and a liquid can fall away from it instead of hanging on by suction (adhesion still holds it on). The obstacle is drawn as it is either way.' }, solid: { type: 'boolean', description: 'false: a decoration, drawn over or under the fluid as draw says but never met by it (a net, a candle flame, a label, a background); with a voltage, an electrode the gas flows through (a cloud\'s charge, unseen with draw none). Default true.' }, voltage: { oneOf: [volts, { ...array(object({ frame: int(0, 255), voltage: volts, over: int(0, 256, 'Frames to move to it in a straight line; default 0, at once.') }, ['frame', 'voltage']), 16), minItems: 1 }], description: 'An electrode at this many volts, or keys that change it on cue (strikes, pulses); a loop repeats them. Arcs run between electrodes at different voltages, through a gas or the air over a liquid with heat and vapour.' }, resistance: num(0, 10000, 'The electrode supply\'s own resistance, so its voltage sags as current flows: a long arc starves, a shorter path takes over, and one strike stops the others. Default 0, an ideal supply.'), charge: num(0, 10000, 'Charge the electrode stores (current × frames per volt), refilled through its resistance: strikes drain it and come in bursts. Default 0.'), conductor: { type: 'boolean', description: 'Metal at no set voltage, which arcs jump to and through (a gas, or a liquid with heat and vapour).' }, adhesion: num(0, 4, 'Liquid: this obstacle\'s own adhesion, in place of the effect\'s, for liquid touching it: a sticky spoon (4) beside a non-stick pan (0).'), temperature: num(-16, 16, 'A hot plate or a cold window: the obstacle keeps this temperature and warms or chills what touches it, a gas\'s air, or a liquid\'s water and ice and the air over them (the liquid needs heat). Obstacles without one take no part in the heat\'s flow.'), keys: { ...array(object({ frame: int(0, 255, 'The frame (within the cycle, for a loop) the change starts on.'), over: int(0, 256, 'Frames to move to the new place in a straight line, in whole pixels; default 0, at once.'), x: int(-256, 128), y: int(-128, 128), show: { type: 'boolean', description: 'false takes the obstacle away (not drawn, not solid) from this frame on; true brings it back.' } }, ['frame']), 16), minItems: 1, description: 'Move the obstacle or take it away on cue: a dam that vanishes, a gate that lifts, a plunger, a paddle. Each key starts from where the obstacle is on its frame, and may take it partly or wholly off the canvas (up to its own size past an edge), where it is clipped: a rod reaching in, a load leaving. While a key\'s over runs, the obstacle pushes the fluid ahead of it (its faces carry its speed) and shoves fluid in cells it now covers to the first open cell, never through another solid; liquid flows in behind it, a viscous liquid is dragged along its sides, and with adhesion liquid touching it moves with it. A key with no over is a cut: the obstacle is simply elsewhere, pushes nothing, and fluid where it lands (or where an obstacle appears) is taken away. A loop repeats the keys every cycle.' } }, ['symbol']), 32), description: 'Solid shapes from symbols: their visible pixels block the flow (decorations with solid: false only draw). One may hang off the canvas by up to its own size; what hangs off is clipped, as the edge clips the fluid.' },
      emitters: { ...array(fluidEmitter, 16), description: '1–16 sources; a liquid with a fill, or a gas with electrodes, may have none (an empty list).' },
      electric: fluidElectric,
      look: { ...array(fluidLook, 8), minItems: 1, description: 'Layers drawn in order, later over earlier, each mapping one field to palette colours.' },
      whitewater: { ...array(fluidWhitewater, 4), description: 'Liquid: up to four layers of spray or foam thrown off the water where it lands or runs fast, drawn over it like sparks.' },
      air: { ...object({
        stiffness: num(2, 1000, 'Pixels of liquid head that squeeze a pocket to half its size: under h pixels of liquid a pocket keeps stiffness / (stiffness + h) of its size, and a pocket the liquid pulls on stretches the same way. Default 40; 1000 barely gives. Stable at any setting.'),
        bubbles: { ...object({
          colors: keys('Palette keys spread over each bubble\'s life.'),
          life: { oneOf: [int(1, 256), pairOf(int(1, 256))], description: 'Frames each bubble lives; [min, max] picks per bubble. Default [30, 60].' },
          rise: num(0, 4, 'Pixels per frame each rises through still water; default 0.5.'), wobble: num(0, 2, 'Pixels each sways from side to side; default 0.'),
          lift: num(0, 1, 'Share of each one\'s buoyancy handed to the water; default 0.'), pop: { type: 'boolean', description: 'Burst where they reach the surface; default false.' }
        }, ['colors']), description: 'How the air of a pocket squeezed too small to show (under three cells) rises as bubbles, as large as the air it held, as sparks with rise do. Without it that air leaves unseen.' }
      }), description: 'Liquid: air pockets that keep their air. Off by default, so sealed air collapses as the liquid fills it. With air, a region of air sealed off from the open canvas edges keeps its amount of air and pushes back by the gas law, so an upturned cup keeps most of its air, air stays under a shelf, a sealed bottle glugs as it pours and a big bubble rises. Bubbles gathering under a ceiling, two that touch with eight square pixels of air or more between them, become a pocket there, and a pocket that reaches open air vents. Every sealed space counts: a mould filling from above traps air in its tips, and a closed tank\'s air pushes on its water.' },
      bodies: { ...array(fluidBody, 64), minItems: 1, description: 'Rigid bodies in the fluid, the entries a pixelforge-bodies effect takes (pixel_help topic bodies), with the fluid\'s gravity, walls and obstacles. Each is a moving solid that shoves the fluid aside, a turning one stirring it; water floats it by its density (1 is water\'s: 0.5 floats half out) and drags it, what rests on it weighs on it, resting sand holds it up as ground, and a gas pushes and drags it. In a loop the closing frames bring them back to where the cycle starts; with heat a body keeps its temperature. They are drawn over the fluid, and the metadata gives their paths.' },
      granular: { ...object({
        repose: num(5, 45, 'The steepest slope, in degrees, the grains hold, at any height: a heap stands at it, a steeper face avalanches down to it. Dry sand 30-35, fine dust 20-25, gravel 40-45; default 33.'),
        cohesion: num(0, 8, 'Damp grains: they hold as dry ones do that many pixels down, so they stand steeper than their repose and keep small overhangs. Default 0 (dry).')
      }), description: 'Liquid: grains, such as sand, salt, sugar, gravel or dry snow, in place of a liquid. Friction that grows with pressure holds a slope up to repose at any height; grains land dead instead of splashing, slide down a steeper face as an avalanche and come to rest exactly. Not with yield, heat or air. Cohesion (tension) defaults to 0.' },
      heat: { ...object({
        ambient: num(-16, 16, 'The room\'s air temperature, which air drifts back to; default 0. The scale is the gas one: water freezes at -0.5 and boils at 0.5, flames run about 0.3 to 1.'),
        air: num(0, 0.2, 'How fast the water\'s surface trades heat with the air, per frame; default 0.04.'), conduct: num(0, 0.2, 'How fast heat spreads through the water and ice, per frame; default 0.12.'),
        contact: num(0, 0.2, 'How fast a hot or cold obstacle (its temperature) warms or chills what touches it, per frame; default 0.15.'),
        freeze: num(-8, 8, 'Freezing point; default -0.5.'), boil: num(-8, 16, 'Boiling point, above freeze; default 0.5.'),
        latent: num(0.02, 8, 'Heat to melt or freeze, in degrees of the scale: the temperature holds at freeze while it is taken up or given off, so melting takes visible time and ice never flickers. Default 0.5.'),
        vaporize: num(0.02, 16, 'Heat to boil away, in degrees; each particle needs its own seeded half to one and a half of it, so a pot bubbles steadily. Default 1.'),
        evaporation: num(0, 1, 'With vapour: the chance each frame that a surface particle near the boil steams off (it falls off with the square of the temperature toward freeze): a warm puddle steams. Default 0.'),
        dew: num(-16, 16, 'With vapour: vapour touching anything colder than this condenses, on a solid as dew (drawn as water) that drips off as a drop. Default boil - 0.1; at most boil.'),
        condense: num(0, 1, 'Share of such vapour that condenses each frame; default 0.2.'),
        frost: num(-16, 16, 'With vapour: vapour touching ice or an obstacle colder than this grows straight into ice (frost) as fern-like fingers, only from cold surfaces (corners first) and frost already there, and only into air below freeze. Off unless set; at most freeze.'),
        deposit: num(0, 1, 'Share of such vapour that turns to frost each frame, at a finger\'s tip; default 0.1.'),
        branch: num(0, 1, 'With vapour: how often a frost finger forks at 45 degrees into a shorter branch, at every other cell along it; 0 grows straight fingers. Default 0.5.'),
        sublimate: { type: 'boolean', description: 'With vapour: ice turns straight into vapour at its surface instead of melting (dry ice). Default false.' },
        grain: num(0, 1, 'Seeded unevenness in where water freezes and frost grows, so fronts are ragged. Default 0.')
      }), description: 'Liquid: phase changes. Each particle carries heat; water below freeze turns to ice where it touches ice or a cold solid (or 0.5 below freeze anywhere), ice holds still or settles as a piece and floats, and a cell of ice is solid to the flow, to bubbles and to air pockets. With vapour, water boils into steam, and steam condenses or frosts back. Water, ice and vapour are counted every frame in the figures (water, ice, vapour, added, taken). Obstacles may move on keys or be smooth: a hot spoon, a heated piston or a smooth hot plate work as a still one does.' },
      vapour: { ...object({
        expansion: num(1, 64, 'Cells a cell\'s worth of water fills as vapour: how much room steam takes on screen and how hard boiling pushes the air. Default 8.'),
        buoyancy: num(-2, 2, 'Lift per degree above the air\'s temperature, against gravity; default 0.2.'), weight: num(-2, 2, 'Sinking per unit of vapour density (negative lifts it: steam is light, dry-ice fog heavy); default 0.'),
        vorticity: num(0, 2, 'Default 0.2.'), dissipation: num(0, 1, 'Share of vapour that fades each frame (it leaves the figures as taken); default 0.'),
        cooling: num(0, 1, 'Share of the air\'s difference from heat.ambient lost each frame; default 0.05.'), drag: num(0, 1, 'Default 0.02.'),
        spread: num(0, 0.25, 'Diffusion between neighbouring cells per step, which keeps matter; for still humid air that feeds frost. Default 0.'),
        iterations: int(1, 200, 'Pressure sweeps per step; default 20.'),
        bubbles: { ...object({ colors: keys('Palette keys spread over each bubble\'s life.'), size: int(1, 3), life: { oneOf: [int(1, 256), pairOf(int(1, 256))] }, rise: num(0, 4, 'Default 0.8.'), wobble: num(0, 2), lift: num(0, 1, 'Share of its buoyancy handed to the water, so a boil churns the pot.'), pop: bool, follow: num(0, 2), drag: num(0, 1) }, ['colors']), description: 'Bubbles a boil makes inside the water, as sparks with rise: they carry their vapour up and let it out at the surface (into an air pocket, they add to its air). Without them water boils only at its surface.' },
        look: { ...array(fluidLook, 8), description: 'Gas-style layers for the vapour (density 1 is a cell full of steam, temperature, speed, light, shadow), drawn under the water. Without them vapour is invisible.' }
      }), description: 'Liquid with heat: steam and fog, moved by the gas solver through the cells holding neither water nor ice; the water and ice are walls moving with it.' },
      ice: { ...object({ look: { ...array(fluidLook, 8), minItems: 1, description: 'Gas-style layers for the ice, drawn cell by cell over the water (density 0.5 is a cell of ice).' } }, ['look']), description: 'Liquid with heat: how ice is drawn; default the water\'s look.' },
      light: vector(-1, 1, 'Direction toward the light for the light and shadow fields; default [-1, -1], the upper left.'),
      outline: { ...key, description: 'Palette key for a one-pixel outline around the fluid.' },
      cleanup: { ...object({ strays: bool, corners: bool }), description: 'De-Stray (specks and pinholes take their surroundings\' colour; a liquid\'s lone pixel is a drop, and stays) and De-Corner cleanup of the fluid before outline and sparks.' }
    }, ['frames', 'emitters', 'look']) },
    sheet: schema.properties.sheet
  }, ['format', 'version', 'name', 'width', 'height', 'effects']), $defs: { rows: schema.$defs.rows }
};
const waveCommon = {
  at: vector(-4096, 4096, 'Source centre or phase origin [x, y] in pixel coordinates.'),
  wavelength: num(2, 256, 'Pixels per cycle before radial stretch. Wider bands read better at small sizes.'),
  amplitude: num(0, 4, 'Signed sources are summed before colouring. Default 1.'),
  cycles: int(-16, 16, 'Whole cycles per animation; negative reverses travel, zero is static. Default 1.'),
  phase: num(-3600, 3600, 'Relative phase in degrees. 180 opposes an otherwise identical source. Default 0.')
};
const waveColors = { ...array({ type: 'string', minLength: 1, maxLength: 1 }, 8), minItems: 1, description: 'Single-character palette keys; dot and space are reserved.' };
const waveRows = { ...array({ type: 'string', minLength: 1, maxLength: 128 }, 128), minItems: 1, description: 'A full-canvas palette grid. Dot or space leaves the pixel transparent.' };
const wave = {
  $schema: schema.$schema, title: 'Pixelbolt wave effects',
  description: 'Looping coherent procedural waves compiled to editable palette grids. Direct radial/directional synthesis, not a physical water or obstacle solver. All sources combine before palette thresholds. No runtime physics or dependencies.',
  ...object({ format: { const: 'pixelforge-wave' }, version: { const: 1 }, name: id,
    width: int(1, 128), height: int(1, 128), palette: schema.properties.palette, anchor: point, sheet: schema.properties.sheet,
    effects: { type: 'object', minProperties: 1, maxProperties: 16,
      propertyNames: { ...id, maxLength: 60 }, description: 'Names become animations; unique ignoring case. At most 256 frames and 4,194,304 pixels in total.',
      additionalProperties: object({ frames: int(4, 128), duration: int(20, 1000, 'Milliseconds per frame. Default 80. Every effect loops.'),
        sources: { ...array({ oneOf: [
          object({ kind: { const: 'radial' }, ...waveCommon, stretch: vector(0.125, 8, 'Radial shape scale [x, y]; default [1, 1]. A smaller y flattens the rings onto the ground.') }, ['kind', 'at', 'wavelength']),
          object({ kind: { const: 'directional' }, ...waveCommon, angle: num(-3600, 3600, 'Degrees clockwise, 0 right and 90 down. Default 0.') }, ['kind', 'at', 'wavelength'])
        ] }, 4), minItems: 1 },
        mask: object({ at: vector(-4096, 4096), radius: vector(0.5, 256, 'Ellipse radii [x, y]. Clipping only, never a reflecting obstacle.'), feather: num(0, 1, 'Fraction of the ellipse radius faded inward; 0 is a hard edge. Default 0.2.') }, ['at', 'radius']),
        look: object({ colors: waveColors,
          thresholds: { ...array(num(0.000001, 16), 8), minItems: 1, description: 'Strictly increasing positive values, one per colour. Values below the first remain transparent.' },
          negative: { ...waveColors, description: 'Optional colours for negative amplitudes at the same absolute thresholds; otherwise negative amplitudes are transparent.' },
          hold: num(0, 0.45, 'Keeps bands from flickering where the wave wavers at a threshold: a pixel enters a new band at once, but goes back to the band it just left only once the value has passed the threshold by this share of the gap between thresholds. The loop still closes exactly. Default 0.3; 0 colours each frame from its own values alone.')
        }, ['colors', 'thresholds']),
        underlay: waveRows, overlay: waveRows
      }, ['frames', 'sources', 'look']) }
  }, ['format', 'version', 'name', 'width', 'height', 'palette', 'effects'])
};
const bodies = {
  $schema: schema.$schema, title: 'Pixelbolt rigid bodies',
  description: 'Rigid bodies (balls, boxes, convex polygons, fixed or spinning hoops) with gravity, walls and pixel obstacles, simulated and baked into editable palette grids: they bounce, slide, roll, stack, knock each other about and come to rest. Units: pixels and frames. One-shot; deterministic.',
  ...object({ format: { const: 'pixelforge-bodies' }, version: { const: 1 }, name: id,
    width: int(4, 256), height: int(4, 256), subpixels: subpixels('the obstacles and background'), palette: schema.properties.palette, anchor: point, sheet: schema.properties.sheet,
    symbols: { type: 'object', propertyNames: { ...id, maxLength: 60 }, additionalProperties: { ...array({ type: 'string', minLength: 1, maxLength: 256 }, 256), minItems: 1 }, description: 'Named rows of palette keys for obstacles and body sprites; dot or space is empty.' },
    effects: { type: 'object', minProperties: 1, maxProperties: 16,
      propertyNames: { ...id, maxLength: 60 }, description: 'Names become animations and frame names; unique ignoring case. At most 256 frames in all.',
      additionalProperties: object({
        frames: int(1, 18000, 'At most 256 in a recipe (and in all of a source\'s effects); a longer match goes out as numbered video frames: pixelbolt sequence, or pixel_compile with sequence.'), duration: int(10, 1000, 'Milliseconds per frame. Default 40.'),
        substeps: int(1, 16, 'Solver steps a frame. Default 8.'), iterations: int(1, 16, 'Contact passes a step. Default 6.'),
        gravity: { ...pairOf(num(-2, 2)), description: 'Pixels a frame² [x, y]. Default [0, 0.15].' },
        background: { ...bodyKey, description: 'Fills the canvas under everything.' },
        walls: { ...array({ enum: ['left', 'right', 'top', 'bottom'] }, 4), description: 'Canvas edges that hold bodies in; a body far past an open edge leaves for good.' },
        obstacles: { ...array(object({ symbol: { type: 'string' }, x: int(-4096, 4096), y: int(-4096, 4096),
          draw: { enum: ['over', 'under', 'none'], description: 'over (default), under the bodies, or none (an invisible wall).' },
          solid: { type: 'boolean', description: 'false: a decoration the bodies pass.' }, ...bodyMaterial }, ['symbol']), 32), description: 'Symbols stamped on the canvas whose pixels are solid. Bodies slide along their edges without catching on the seams between pixels.' },
        territory: { ...object({ cell: int(1, 64, 'Pixels a side. Default 4.'), at: { ...pairOf(int(0, 4096)), description: 'Top-left on the canvas. Default [0, 0].' },
          size: { ...pairOf(int(1, 4096)), description: 'With split: [columns, rows]. Default: as many as fit the canvas.' },
          teams: { ...array(object({ name: shortId, color: bodyKey, label: { type: 'string', maxLength: 40, description: 'Shown by {leader}. Default the name in capitals.' } }, ['name', 'color']), 8), minItems: 2 },
          rows: { ...array({ type: 'string', minLength: 1 }, 4096), description: 'One character a cell: a team\'s colour, or . for a cell no one owns.' },
          split: { enum: ['columns', 'rows'], description: 'Instead of rows: the board shared out among the teams in order, side by side or one above the next.' },
          bounce: num(0, 1, 'Default 1.'), friction: num(0, 2, 'Default 0.') }, ['teams']), description: 'Cells owned by teams, drawn in their colours: a team\'s body passes its own and bounces off the others\', claiming each it hits (the metadata counts them each frame).' },
        bodies: { ...array(body, 64), minItems: 1, description: 'At most 256 bodies with their copies.' },
        most: int(1, 4096, 'The most bodies split powers and breaks may make in all, copies and pieces included: at least the bodies listed. Default 256, or room for every body with breaks to break into all its pieces (up to 4096).'),
        pickups: { ...array(object({ at: { ...pairOf(num(0, 4096)), description: 'Centre [x, y] in canvas pixels.' }, size: int(1, 64, 'Pixels a side; default the symbol\'s size, or 5.'), from: int(0, 18000, 'First frame it waits. Default 0.'), until: int(1, 18001), symbol: { type: 'string', description: 'Drawn while it waits.' }, color: { ...bodyKey, description: 'Or a plain square.' }, ...powerFields }, ['at', 'power']), 64), description: 'Power-ups the first body to reach one takes.' },
        events: { ...array(object({ frame: int(1, 18000), body: { type: 'string', description: 'A named body.' }, ...powerFields }, ['frame', 'body', 'power']), 64), description: 'Powers given to a named body at the end of a frame.' },
        strikes: { ...array(object({ by: { type: 'string', description: 'A named body: what it pushes (a hit, or a push along) takes the power.' }, rest: int(1, 18000, 'Frames before a body can take this strike again. Default 10.'), from: int(0, 18000, 'First frame it works. Default 0.'), until: int(1, 18001), cut: num(0.1, 8, 'Cut instead of push: the body passes through the free bodies it touches, and what it strikes leaves behind it at this speed (pixels a frame), the pieces of a split fanned about that way, so they lie in its wake.'), ...powerFields }, ['by', 'power']), 16), description: 'Powers given at the end of a frame to every body a named body struck in it: with split, a blade that multiplies each ball it touches (raise most for a crowd).' },
        hud: { ...array({ oneOf: [object({ text: { type: 'string', maxLength: 80, description: '{team} cells, {team%} share, {leader}, {news} (the last power\'s label, for news frames), {frame}.' }, at: point2, color: bodyKey, align: { enum: ['left', 'center', 'right'] }, back: { ...bodyKey, description: 'A box behind the text.' }, pad: int(0, 16), scale: int(1, 8, 'Default 1; at most 16 divided by subpixels.'), news: int(1, 18000, 'Frames {news} shows. Default 45.'), from: int(0, 18000), until: int(1, 18001) }, ['text', 'at', 'color']), object({ bar: object({ at: { ...pairOf(int(0, 4096)), description: 'Top-left [x, y] in canvas pixels.' }, size: { ...pairOf(int(1, 512)), description: '[width, height] in canvas pixels; at most 512 divided by subpixels.' } }, ['at', 'size']), empty: bodyKey, from: int(0, 18000), until: int(1, 18001) }, ['bar'])] }, 16), description: 'With a territory: the score drawn over everything, every frame.' }
      }, ['frames', 'bodies']) }
  }, ['format', 'version', 'name', 'width', 'height', 'palette', 'effects'])
};
const crystalKey = { type: 'string', minLength: 1, maxLength: 1, description: 'A one-character palette key.' };
const spanOf = (minimum, maximum, description, whole = false) => ({ oneOf: [whole ? int(minimum, maximum) : num(minimum, maximum), pairOf(whole ? int(minimum, maximum) : num(minimum, maximum))], description: `${description} A number, or [low, high] drawn per crystal from the seed.` });
const crystalPoint = pairOf(num(-1024, 1024));
const crystalRows = { ...array({ type: 'string', minLength: 1, maxLength: 256 }, 256), minItems: 1, description: 'A full-canvas palette grid drawn under (underlay) or over (overlay) the crystals, such as the rock they grow from. Dot or space leaves the pixel transparent.' };
const crystalCommon = {
  look: { type: 'string', description: 'Which of the source\'s looks colours it; default the only one.' },
  at: { oneOf: [crystalPoint, { ...array(crystalPoint, 16), minItems: 2 }], description: 'The seed [x, y] in pixels (a whole number is a pixel\'s centre), or a line through 2–16 points [[x, y], …] along which a cluster\'s seeds spread evenly by length.' },
  count: int(1, 64, 'Crystals in this entry: a cluster whose seeds spread along at, each drawing its own size, angle and timing from the ranges. Default 1. A cluster is drawn longest first, so short crystals stand in front.'),
  start: spanOf(0, 255, 'Frame the crystal starts growing, as one bright seed pixel. Default 0.', true),
  grow: spanOf(1, 256, 'Frames from seed to full size. Default 60% of the effect\'s frames.', true),
  ease: { enum: EASINGS.filter(name => name !== 'hold'), description: 'How growth runs over grow: default inOut for faceted crystals (a slow start, then a slowing finish) and out for snowflakes.' }
};
const crystalTurn = {
  angle: spanOf(-360, 360, 'Degrees clockwise from right the crystal grows toward: -90 (default) is straight up. Snapped to the nearest clean pixel slope (level, 3:1, 2:1, 1:1, and steeper), so long edges run as even stairs. With count, a range fans the cluster from the first end of at to the last.'),
  toward: { ...crystalPoint, description: 'Instead of angle: each crystal points at this [x, y], such as a geode\'s centre.' },
  spread: num(0, 90, 'Degrees of seeded wobble around angle or toward. Default 0.'),
  tilt: spanOf(-80, 80, 'Degrees the growth axis leans toward the viewer, showing its end. Default 0 (cube 30).'),
  turn: spanOf(-360, 360, 'Degrees the crystal spins about its own axis: a prism shows a face (0, default) or an edge (30) to the viewer. Default 0 (cube and octahedron 45).')
};
const crystal = {
  $schema: schema.$schema, title: 'Pixelbolt crystal growth',
  description: 'Crystals that grow from seeds and come to rest, compiled to editable palette grids: faceted prisms (quartz, amethyst, ice spikes; pointed, flat or doubly terminated), cubes (pyrite, salt) and octahedra drawn as small solids lit by one light, each face one band of its look, alone or in seeded clusters along a line or round a geode; and six-armed snowflakes grown as dendrites, with side branches and twigs that stop a pixel short of each other and mirror symmetry. One-shot: each crystal starts as a bright seed pixel, grows, glints along its lit edge once grown, and the picture holds still. Deterministic.',
  ...object({ format: { const: 'pixelforge-crystal' }, version: { const: 1 }, name: id,
    width: int(1, 256), height: int(1, 256), palette: schema.properties.palette, anchor: point, sheet: schema.properties.sheet,
    looks: { type: 'object', minProperties: 1, maxProperties: 8, propertyNames: { ...id, maxLength: 60 },
      additionalProperties: object({ colors: { ...array(crystalKey, 6), minItems: 2, description: 'Palette keys from the darkest face to the brightest: a face takes the band of how squarely it faces the light. A snowflake draws its arms in the last, its branches in the one before and its plate in the one before that.' },
        outline: { ...crystalKey, description: 'Drawn round each crystal, over whatever it stands in front of.' },
        glint: { ...crystalKey, description: 'The seed pixel, the spark that runs up a grown crystal\'s lit edge and twinkles at its end, and a snowflake\'s newest pixels.' } }, ['colors']),
      description: 'Named colour ramps for the crystals.' },
    effects: { type: 'object', minProperties: 1, maxProperties: 16,
      propertyNames: { ...id, maxLength: 60 }, description: 'Names become one-shot animations; unique ignoring case. At most 256 frames and 4,194,304 pixels in total.',
      additionalProperties: object({ frames: int(2, 256), duration: int(20, 1000, 'Milliseconds per frame. Default 80.'),
        seed: int(0, 2147483647, 'Seeds the clusters\' draws and the snowflakes\' branch spacing. Default 0.'),
        light: { ...pairOf(num(-1, 1)), description: 'Direction [x, y] toward the light in the picture; it also comes from in front. Default [-1, -1], the upper left.' },
        crystals: { ...array({ oneOf: [
          object({ habit: { const: 'prism' }, ...crystalCommon, ...crystalTurn, length: spanOf(1, 256, 'Pixels from seed to tip.'), width: spanOf(1, 64, 'Pixels across.'),
            tip: spanOf(0, 3, 'Length of the pointed end as a share of the width: 0 is flat, default 1.'), double: { type: 'boolean', description: 'Pointed at both ends (a floating crystal); at is then one end.' } }, ['habit', 'at', 'length', 'width']),
          object({ habit: { enum: ['cube', 'octahedron'] }, ...crystalCommon, ...crystalTurn, size: spanOf(1, 128, 'Pixels along each edge (a cube) or from point to point (an octahedron).') }, ['habit', 'at', 'size']),
          object({ habit: { const: 'snowflake' }, ...crystalCommon, count: int(1, 1, 'A snowflake grows alone: give each snowflake its own entry.'), radius: int(2, 64, 'Pixels from the centre to an arm tip.'),
            spacing: num(2, 16, 'Pixels between side branches along an arm. Default 4.'), branches: num(0, 1, 'How long side branches grow: at 1 their tips reach the hexagon through the arm tips; 0 leaves bare arms. Default 0.7.'),
            twigs: num(0, 1, 'The same for twigs off the side branches. Default 0.'), plate: num(0, 32, 'Radius of a hexagonal plate at the centre, ribbed by the arms. Default 0.'),
            arms: { enum: ['vertical', 'horizontal'], description: 'Two arms point up and down (default), or left and right.' } }, ['habit', 'at', 'radius'])
        ] }, 32), minItems: 1, description: 'Drawn in order, later ones in front; at most 256 with the counts.' },
        underlay: crystalRows, overlay: crystalRows
      }, ['frames', 'crystals']) }
  }, ['format', 'version', 'name', 'width', 'height', 'palette', 'looks', 'effects'])
};
// Falling-sand grids: a material table, a starting scene, scripted inputs and clips sampled into palette grids.
const opaque = { type: 'string', pattern: opaqueHex, description: 'An opaque colour: #RGB or #RRGGBB.' };
const powderName = { type: 'string', pattern: '^[a-z][a-z0-9-]{0,23}$', description: 'A material: lower-case letters, digits and hyphens, starting with a letter (to clear cells, erase).' };
const powderColors = (description, most = 8) => ({ ...array(opaque, most), minItems: 1, description });
const degreesOf = description => num(-2000, 9000, description);
const powderChange = description => object({ temperature: degreesOf('Degrees past which it changes.'), into: { type: 'string', description: 'A material, or "empty".' }, chance: num(0, 1, 'A frame, once past the temperature. Default 1.'), latent: num(0, 9000, 'Degrees more it must take in (above) or give out (below) first, so a hot stone boils a few cells of a pool rather than all of it; the new material starts at the temperature. Default 0.') }, ['temperature', 'into']);
const powderEmit = { ...array(object({ material: powderName, chance: num(0, 1, 'A frame.') }, ['material', 'chance']), 2), description: 'Given off into a free neighbour, upward more often than sideways.' };
const powderSpot = { x: num(-4096, 4096, 'Canvas pixels; quarter pixels are kept.'), y: num(-4096, 4096), x2: num(-4096, 4096, 'With y2: a stroke along a segment.'), y2: num(-4096, 4096), radius: num(0.5, 64, 'Default 3.') };
const powderInputs = {
  paint: object({ material: powderName, ...powderSpot, fill: num(0, 1, 'The share of cells filled: below 1 is a spray. Default 1.'), replace: { type: 'boolean', description: 'Paint over what is there. Default false: only empty cells.' } }, ['material', 'x', 'y']),
  erase: object(powderSpot, ['x', 'y']),
  wall: object(powderSpot, ['x', 'y']),
  heat: object({ ...powderSpot, amount: num(-2000, 2000, 'Degrees added to every cell in the stroke, air included; negative cools. Default 200.') }, ['x', 'y']),
  push: object({ ...powderSpot, vx: num(-8, 8, 'Pixels a frame.'), vy: num(-8, 8) }, ['x', 'y']),
  burst: object({ x: powderSpot.x, y: powderSpot.y, radius: powderSpot.radius, strength: num(0, 8, 'Pixels a frame at the middle. Default 3.') }, ['x', 'y'])
};
const powderMaterial = object({
  state: { enum: ['powder', 'liquid', 'gas', 'solid', 'fire'], description: 'powder and liquid fall and pile or spread; gas and fire drift up (lighter than air) or down; a solid stays put, unless it falls.' },
  density: num(0.01, 1000, 'Relative to air (1): the heavier sinks through the lighter. Defaults: powder 16, liquid 10, gas 0.5, fire 0.2, a solid that falls 50.'),
  spread: int(0, 16, 'Liquids, gases and fire: cells it runs sideways a frame. Defaults: liquid 4, gas 2, fire 1.'),
  speed: num(0, 1, 'Gases and fire: how fast it rises (or sinks) on its own, as a chance a frame, or in pixels a frame in moving air. Default 1.'),
  expand: int(0, 4, 'Gases: extra free cells beside it that it fills when a phase change or reaction makes it (steam billows). Default 0.'),
  viscosity: num(0, 0.95, 'Liquids: how slow it is to slide and spread once landed. Default 0.'),
  drag: num(0, 0.95, 'Liquids and gases: how much it slows what sinks through it. Default 0.5 for a liquid.'),
  splash: num(0, 1, 'Powders and liquids: the share of fast landings thrown back up as spray. Default 0.12 for a liquid, 0 for a powder.'),
  falls: { type: 'boolean', description: 'Solids: drops as a rigid piece, with every solid that falls touching it, once no fixed solid and no floor holds the piece up; it sinks through lighter liquids and floats on denser ones. How it comes down is set by the source\'s pieces.' },
  clings: { type: 'boolean', description: 'A solid that falls (moss): with pieces "tumble", held by any fixed solid it touches, under it too, and a piece of its own apart from other falling solids, as a plant holds on; without it a piece standing on a fixed solid rests there and topples off it. Default false.' },
  colors: powderColors('Opaque colours: a seeded one per cell (or by pattern, age, density or shimmer).'),
  pattern: { enum: ['speckle', 'blotch', 'grain'], description: 'How a cell\'s colour is chosen where it is made: a seeded draw (speckle, default), soft blotches, or streaks along the rows (grain, for wood).' },
  top: { ...opaque, description: 'Liquids: the colour of a cell with air or gas above it, a surface line.' },
  streak: { ...opaque, description: 'Powders and liquids: drawn in empty pixels above a cell falling two pixels a frame or faster, so rain reads as rain.' },
  haze: { ...opaque, description: 'Gases and fire not drawn by density: an empty pixel between two or more of its cells takes this colour.' },
  colorBy: { enum: ['cell', 'age', 'density'], description: 'cell (default): a seeded colour per cell; age: young to old, for a material with a life; density: thin to thick, a gas or flame drawn as a cloud by how its cells crowd (a lone gas cell is not drawn).' },
  shimmer: int(2, 600, 'Frames for a cell\'s colour to cycle once through the colours (lava).'),
  hot: object({ from: degreesOf('Below this its own colours.'), to: degreesOf('At this the last glow colour.'), colors: powderColors('Glow colours from cool to hot.') }, ['from', 'to', 'colors']),
  temperature: degreesOf('Degrees it is made at. Default the ambient.'),
  conduct: num(0, 1, 'How fast heat passes through it (an edge moves at the lower of its two cells). Default 0.2.'),
  cool: num(0, 1, 'How fast it drifts toward the ambient temperature on its own. Default 0.'),
  heat: degreesOf('It holds at least this temperature (fire).'),
  life: object({ frames: { ...pairOf(int(1, 65535)), description: '[fewest, most] frames it lives, drawn per cell.' }, into: { type: 'string', description: 'What it becomes; default "empty".' }, chance: num(0, 1, 'The chance it becomes that rather than empty. Default 1.') }, ['frames']),
  above: powderChange('A phase change above a temperature (melting, boiling).'),
  below: powderChange('A phase change below a temperature (freezing, condensing, crusting).'),
  burn: object({ temperature: degreesOf('It lights at this.'), frames: { ...pairOf(int(1, 65535)), description: '[fewest, most] frames it burns.' }, heat: degreesOf('Holds at least this while it burns. Default 600.'), emit: powderEmit, into: { type: 'string', description: 'What it leaves; default "empty".' }, chance: num(0, 1, 'The chance it leaves that. Default 1.'), colors: powderColors('Burning flicker; default the colours of the flame it gives off.') }, ['temperature', 'frames']),
  emit: powderEmit
}, ['state', 'colors']);
const powderAt = { ...array(int(-4096, 4096), 4) };
const powder = {
  $schema: schema.$schema, title: 'Pixelbolt falling sand',
  description: 'A falling-sand material grid: every pixel holds one material from a table (powders, liquids, gases, fire, fixed solids and solids that fall as rigid pieces), the heavier sinking through the lighter, with velocity (falls that speed up, splashes, surges), heat with phase changes and latent heat, burning, lives, reactions between neighbours and moving air. base "sandbox" starts from the starter materials. The same source runs live (createLivePowder, a frame at a time with pointer input) and compiles to an ordinary recipe of palette grids: each clip samples the grid every `every` frames (60 a second). Deterministic: the same source draws the same pixels everywhere.',
  ...object({ $schema: { type: 'string' }, format: { const: 'pixelforge-powder' }, version: { const: 1 }, name: { ...id, maxLength: 60, description: 'The recipe\'s name, and its clip\'s when there are no clips.' },
    base: { enum: ['sandbox'], description: 'Start from the starter table: sand, water, stone, wood, fire, smoke, steam, oil, lava, ice, ash, moss and wall, their reactions, moving air and a dark background. Materials named again replace the base\'s, a reaction for a pair the base has replaces the base\'s, and air.flow merges field by field.' },
    width: int(8, 1024, 'At most 256 to compile; up to 1024 live.'), height: int(8, 1024, 'At most 256 to compile; up to 1024 live.'),
    seed: int(0, 2147483647, 'Seeds every draw. Default 1.'), ambient: degreesOf('Degrees everything drifts toward. Default 20.'),
    background: { ...color, description: 'Drawn where nothing is (and the compiled recipe\'s background). Default transparent.' },
    gravity: num(0.02, 1, 'Pixels a frame gained each frame by whatever falls (at least a pixel a frame, at most 6). Default 0.15.'),
    air: object({ conduct: num(0, 1, 'How air passes heat on. Default 0.01.'), cool: num(0, 1, 'How fast air drifts to the ambient temperature. Default 0.03.'),
      flow: { oneOf: [{ type: 'boolean' }, object({ cell: int(2, 16, 'Pixels a side of each air cell. Default 4.'), wind: { ...pairOf(num(-2, 2)), description: '[x, y] pixels a frame the air settles toward. Default [0, 0].' }, rise: num(0, 4, 'How strongly heat lifts the air. Default 0.25.'), swirl: num(0, 2, 'How much the air curls. Default 0.3.'), calm: num(0, 1, 'How fast the air settles to the wind, a frame. Default 0.02.'), carry: num(0, 1, 'How much the air carries falling powders and liquids, by their lightness. Default 0.3.') })], description: 'Moving air: it carries gases and flames, lifts over heat and takes push and burst inputs. Edges are open but for the floor.' } }),
    wall: { ...powderName, description: 'The fixed solid the wall input paints; default the material named "wall".' },
    pieces: { enum: ['drop', 'tumble'], description: 'How a loose piece of solids that fall comes down. "drop" (default): straight down as one block, held while any cell touches a fixed solid or the floor. "tumble": as a rigid body that turns, tips off ledges and stubs its weight is not over, floats in denser liquids, pushes what it lands in aside and comes to rest, its cells keeping their material, burning and heat; held only where a fixed solid is beside it or over it (or under a material that clings).' },
    materials: { type: 'object', maxProperties: 200, propertyNames: powderName, additionalProperties: powderMaterial, description: 'Materials by name; at most 89 different colours in all, the base\'s included (base sandbox uses 76): share colours between materials, or replace base materials you do not use with one colour each.' },
    reactions: { ...array(object({ a: powderName, b: { type: 'string', description: 'A material, or "empty".' }, into: { ...pairOf({ type: ['string', 'null'] }), description: '[what a becomes, what b becomes]: a material, "empty", or null to keep it.' }, chance: num(0, 1, 'A frame, when one picks the other as its neighbour. Default 1.'), heat: num(-2000, 9000, 'Degrees added to both (negative cools).'), ignite: { enum: ['a', 'b'], description: 'Lights that side (it must burn).' }, douse: { enum: ['a', 'b'], description: 'Puts that side out, cooling it to the temperature it is made at.' }, burning: { enum: ['a', 'b'], description: 'Only while that side burns.' } }, ['a', 'b']), 256), description: 'A cell of a next to a cell of b; one reaction per pair.' },
    scene: { ...array(object({ material: { type: 'string' }, rect: { ...powderAt, minItems: 4, description: '[x, y, width, height].' }, disc: { ...array(int(-4096, 4096), 3), minItems: 3, description: '[x, y, radius].' }, rows: { ...array({ type: 'string', maxLength: 1024 }, 1024), description: 'Rows of characters drawn with legend from at.' }, at: point, legend: { type: 'object', additionalProperties: { type: 'string' }, description: 'Character → material.' }, fill: num(0, 1, 'The share of cells filled. Default 1.'), replace: { type: 'boolean', description: 'false keeps what earlier fills put there. Default true.' }, temperature: degreesOf('Degrees the cells start at.'), burning: { type: 'boolean', description: 'Starts alight (a material that burns).' } }), 512), description: 'The starting grid, filled in order: exactly one of rect, disc or rows each.' },
    inputs: { ...array(object({ frame: int(0, 20000, 'The frame it happens on.'), frames: { ...pairOf(int(0, 20000)), description: '[first, last]: every frame between, or every `every`th.' }, every: int(1, 20000, 'Default 1.'), ...powderInputs }), 512), description: 'Scripted strokes, each exactly one of paint, erase, wall, heat, push or burst, at the start of a frame: the compiler and the live runner both play them.' },
    clips: { type: 'object', minProperties: 1, maxProperties: 16, propertyNames: { ...id, maxLength: 60 }, additionalProperties: object({ start: int(0, 20000, 'The frame it starts on. Default 0.'), frames: int(1, 256, 'Frames drawn. Default 60.'), every: int(1, 60, 'Frames simulated between drawn frames. Default 2.'), duration: int(10, 10000, 'Milliseconds a drawn frame shows. Default every × 1000 / 60.') }), description: 'One-shot animations sampled from the one run; default one clip named after the source. At most 256 frames and 4,194,304 pixels in all, and about 200 million cell steps, scripted inputs and tumbling pieces counted in.' }
  }, ['format', 'version', 'name', 'width', 'height']),
  anyOf: [{ required: ['base'] }, { required: ['materials'] }]
};
const normals = {
  $schema: schema.$schema, title: 'Pixelbolt normal pass',
  description: 'Derives a lighting normal pass from a colour recipe and compiles it to an ordinary recipe aligned with it (same size, frame names and durations, animations and atlas layout), ready for a scene asset\'s normal and editable like any recipe. Each separate shape is rounded from its silhouette, lighter colours can be raised by detail, and every pixel takes the nearest of 17 directions: palette key 5 faces the viewer, the keypad digits 1–4 and 6–9 lean 30° the way they sit around 5, and q w e a d z x c lean 60° the same way.',
  ...object({ format: { const: 'pixelforge-normals' }, version: { const: 1 }, name: { ...id, description: 'Name of the normal recipe; default <recipe name>-normal.' },
    recipe: { ...assetRef, description: 'The colour recipe, at most 256 pixels a side (a normal pass lights scene assets): inline, a file resolved by the CLI relative to this source (or inside the MCP root), or {"revision": id} through MCP.' },
    bevel: int(1, 64, 'Pixels from the edge to the flat top. Default: each shape rounds all the way to its thickest point, like a cushion.'),
    detail: num(0, 1, 'How far lighter colours stand out of the surface, up to 2 pixels: 0 (default) keeps only the silhouette\'s shape; 0.5–1 embosses textured surfaces such as brick, bark or rock. A colour on a ramp counts its step along the ramp, any other its brightness.'),
    faces: { type: 'object', minProperties: 1, additionalProperties: { enum: NORMAL_KEYS }, description: 'Flat faces by colour: maps the colour recipe\'s palette keys to one direction each, so a box, wall or building gets flat planes instead of a cushion. Pixels drawn in that key\'s colour take the direction; all others are rounded as usual. Side view: tops w, fronts 5. 3/4 top-down: tops w or 8, south faces 2 or 5. Isometric 2:1: tops w, left faces z, right faces c.' }
  }, ['format', 'version', 'recipe']), $defs: { ...schema.$defs, recipe: recipeSchema }
};
for (const [file, value] of [['poses.schema.json', poses], ['scene.schema.json', scene], ['autotile.schema.json', autotile], ['fx.schema.json', fx], ['fluid.schema.json', fluid], ['wave.schema.json', wave], ['crystal.schema.json', crystal], ['powder.schema.json', powder], ['bodies.schema.json', bodies], ['normals.schema.json', normals]]) await writeFile(new URL(`../${file}`, import.meta.url), JSON.stringify(value, null, 2) + '\n');
