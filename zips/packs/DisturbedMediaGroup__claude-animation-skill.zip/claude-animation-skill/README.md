# Animation Direction

A [Claude Code](https://claude.com/claude-code) skill for directing and building 3D animation
in Blender with cinematographic rigor — product and hero shots, camera moves that actually hold
the subject in frame, lens and forced-perspective math, F-curve timing, and the 12 principles
applied to hard-surface objects rather than cartoon characters.

It is two things at once:

- **A reference** you read while animating — what focal length says what, how long a reveal arc
  should run, why your animation feels floaty, how forced perspective actually works.
- **A Python library** that builds the shot — `anim_lib.py` plus five ready recipes that run
  headless in Blender.

Every number in it comes from production practice and is documented in `references/`.
Every formula is implemented in code and verified against a live Blender instance.

---

## What it knows

| Area | Covers |
|---|---|
| **Camera moves** | 11 moves — orbit, reveal arc, turntable, dolly-in, push-in, arc+push, crane, parallax slide, rack focus, whip pan, hero hold. Duration, degrees/second, easing profile, rig setup, and how each one fails. |
| **Lens & framing** | 24–100 mm and what each communicates, aperture by shot type, composition values, screen-direction continuity, 10/15/20-second beat structures. |
| **Forced perspective** | The math: `E = D/(D−δ)` near-feature exaggeration, background compression, dolly zoom `f₂ = f₁·D₂/D₁`, FOV↔mm conversion, monumental-scale placement. |
| **Motion principles** | The 12 principles for rigid products, physics-based timing, free-fall frame tables, overshoot templates, follow-through delays, shutter angle and motion blur. |
| **Blender craft** | Interpolation and handle types, easing equations, blocking→spline workflow, floaty-animation diagnosis, Euler vs quaternion, motion paths. |
| **bpy API** | Exact API for keyframes, F-curves, camera rigs, constraints, drivers, NLA — plus the headless traps that make scripts silently do nothing. |

---

## The core idea

> Animate for the **camera**, not for the viewport. A move that reads beautifully in world space
> can be flat, tangent or unreadable through the lens — and the lens is the only thing that ships.

A few rules the skill will not let you skip:

- **Set the sensor before you name a focal length.** "85 mm" means nothing without `sensor_width`.
- **Separate position from aim from focus.** Three objects, not one. They are frequently not the
  same point.
- **Never overshoot the camera.** Camera overshoot reads as operator error. Product overshoot is
  a style choice.
- **Never scale a rigid product to "squash" it.** Compression lives in parts that can actually
  deform.
- **Offset everything by 3–8 frames.** If camera, product, focus and lights all resolve on the
  same frame, the shot reads as procedural — because it is.
- **A hold is part of the move.** 1–2 seconds of stillness at the hero frame is what makes the
  whole thing land.

---

## Install

Clone into your Claude Code skills directory:

```bash
# user-level (available in every project)
git clone https://github.com/DisturbedMediaGroup/claude-animation-skill.git \
  ~/.claude/skills/animation-direction
```

On Windows:

```powershell
git clone https://github.com/DisturbedMediaGroup/claude-animation-skill.git `
  "$env:USERPROFILE\.claude\skills\animation-direction"
```

Restart Claude Code. The skill self-triggers on phrases like *"animate this"*, *"product
animation"*, *"hero shot"*, *"camera move"*, *"turntable"*, *"dolly zoom"*, *"forced
perspective"*, *"make it feel heavy"*, or *"this looks floaty"* — or invoke it directly.

---

## Using the scripts without Claude

The Python side is a normal Blender library. It does not need Claude Code at all.

```python
import sys
sys.path.append("/path/to/animation-direction/scripts")
import anim_lib as al

scene = al.setup_scene(fps=24, duration_s=15.0)
product = bpy.data.objects["Product"]

# Distance chosen for the depth ratios, lens chosen for framing — never the reverse.
height = al.subject_height(product)
distance = al.distance_for_framing(height, lens_mm=85.0, fill=0.72)

rig = al.camera_rig("CAM", scene=scene, location=(0, -distance, 0.4), lens=85.0)
rig["aim"].location = al.visual_center(product)

# 36 degrees over 3 seconds = 12 deg/s — the luxury orbit
pivot = al.new_empty("Pivot", location=al.visual_center(product))
rig["dolly"].parent = pivot
al.orbit(pivot, al.sec(0.0), al.sec(3.0), 36.0, scene=scene)
```

Run a recipe headless:

```bash
blender -b scene.blend -P scripts/recipes/hero_reveal.py
blender -b scene.blend -P scripts/recipes/hero_reveal.py -o //render/frame_ -a
```

Each recipe has its configuration in a clearly marked block at the top — subject name, lens,
duration, weight class. Point `SUBJECT_NAME` at your object and run.

### Recipes

| Recipe | What it builds |
|---|---|
| `hero_reveal.py` | The full 15-second product film on the beat structure, with staggered arrivals |
| `turntable.py` | Seam-free looping rotation, or a partial eased reveal |
| `dolly_zoom.py` | Vertigo effect holding `f/D` constant — keyed and driver versions |
| `product_drop.py` | Physically sampled fall, impact compression, damped settle |
| `exploded_view.py` | Staggered assembly/disassembly with follow-through |

---

## Verification

The library is proven against a live Blender instance, not just typechecked. The test suite
reads results back out of the F-curves rather than trusting that the script ran:

- Free-fall spacing measured at `1.00 : 3.00 : 5.00 : 7.00 : 9.00` — the ratio constant
  acceleration must produce
- Dolly zoom holds `f/D` constant within 0.0000% across the move
- Framing solver asked for 72% frame height, measured 72.0%
- Turntable seam proven to have no duplicate frame on loop
- Overshoot proven to actually cross the target, not merely hold at it
- Every script AST-verified free of `bpy.context` and `bpy.ops` — so headless runs behave

That suite caught two real bugs during development, both of the silent kind that never raise:

1. **Framing solver was 18% wrong.** It used `sensor_height` (24 mm) as the vertical sensor
   dimension, but under the default `HORIZONTAL` fit at 16:9 the real value is
   `sensor_width × res_y / res_x` = 20.25 mm. Products rendered larger than requested while
   every number in the script looked correct.
2. **Shared actions.** Two objects could end up sharing one action, so keys written for one
   landed on the other's curves — with nothing raising.

Tested on **Blender 4.1.1**. The code targets the 4.2 LTS API (the classic
`action.fcurves.new()` path, which still works in 5.x), but 4.2 itself has not been measured.

---

## Layout

```
SKILL.md                       doctrine, quick-lookup tables, pre-render checklist
references/
  cinematography.md            hero frame, lens, DOF, composition, screen direction, beats
  camera-moves.md              full spec per move: timing, speed, easing, rig, failure modes
  forced-perspective.md        projection math, dolly zoom, FOV, monumental scale, nodal point
  motion-principles.md         12 principles on hard surfaces, physics timing, weight, blur
  blender-fcurves.md           interpolation, handles, easing equations, blocking, floaty
  bpy-api.md                   keyframes, constraints, drivers, NLA, headless gotchas
scripts/
  anim_lib.py                  the shared core — import this, don't retype the numbers
  recipes/                     five runnable shots
```

`SKILL.md` stays deliberately thin — lookup tables and workflow. The heavy material lives in
`references/` so it loads only when it is actually needed.

---

## License

MIT. See [LICENSE](LICENSE).