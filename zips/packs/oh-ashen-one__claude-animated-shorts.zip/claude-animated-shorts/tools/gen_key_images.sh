#!/bin/zsh
# Generate one key painting per scene with Codex's image generation tool.
# Usage: gen_key_images.sh <episode-dir> <style-ref-1.png,style-ref-2.png> <stem> [<stem> ...]
# Pass "none" as the reference list for the first style-key image.
# Reads <episode-dir>/prompts/_style.txt and <episode-dir>/prompts/<stem>.txt,
# writes <episode-dir>/assets/key/<stem>_key.png. Skips stems that already exist.
EP="$1"; REFS="$2"; shift 2
[ "$REFS" = "none" ] && REFS=""
mkdir -p "$EP/assets/key" "$EP/work"
cd "$EP/assets/key" || exit 1
for stem in "$@"; do
  out="${stem}_key.png"
  [ -f "$out" ] && { echo "$stem: exists, skipped"; continue; }
  { cat "$EP/prompts/_style.txt"; echo; cat "$EP/prompts/$stem.txt"; echo
    echo "TASK: You are being used only as an image generator for this one still. Use your built-in image generation tool to create this single image in portrait 9:16 at the highest quality and largest size available, and save it as a PNG named $out in the current working directory. Do not write code to draw it, do not edit any other file, do not run git, and do not do anything else. When the file is saved, reply with its pixel size and stop."
  } | codex exec -s workspace-write --skip-git-repo-check ${REFS:+-i} ${REFS:+"$REFS"} - > "$EP/work/codex_$stem.log" 2>&1
  if [ -f "$out" ]; then echo "$stem: ok $(sips -g pixelWidth -g pixelHeight "$out" | awk '/pixel/{printf "%s ", $2}')"; else echo "$stem: FAILED (see work/codex_$stem.log)"; fi
done
