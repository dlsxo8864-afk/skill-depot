import sys, json, numpy as np, soundfile as sf
from kokoro import KPipeline
out=sys.argv[1]; SPEED=1.5
lines=[
("00_hook","What if every state banned new data centers?",None),
("01_chatbot","The first thing you'd notice is your chatbot. ChatGPT's nine hundred million users would have nowhere new to go.","The first thing you'd notice is your chatbot. Chat G P T's nine hundred million users would have nowhere new to go."),
("02_cloud","Then the cloud would cost more. Only one point four percent of data center space is empty.",None),
("03_power","Your power bill would climb more slowly. Data centers drove most of the last price jump on the biggest grid.",None),
("04_water","Your town would keep more water. Data centers drank seventeen billion gallons in one year.",None),
("05_cranes","But the cranes would stop on a fifty billion dollar a year building boom.",None),
("06_taxes","Your property taxes could rise. In one Virginia county, data centers pay almost half.",None),
("07_retire","Your retirement would feel it. Five companies are spending eight hundred billion dollars on this.",None),
("08_move","And the data centers wouldn't vanish. They'd move, to places like Abu Dhabi.","And the data centers wouldn't vanish. They'd move, to places like Abu Dhabi."),
("09_china","China wouldn't pause. It plans twenty-eight more gigawatts by twenty thirty.",None),
("10_abroad","By year ten, your photos, your bank and your AI could live in another country.","By year ten, your photos, your bank and your A.I. could live in another country."),
("11_catch","A ban wouldn't end data centers. It would decide where they're built.",None),
("12_cta","So where would you rather have them: your town, or another country?",None),
]
pipe=KPipeline(lang_code='a', device='cpu')
meta=[]; tot=0; words=0
for name,script,spoken in lines:
    audio=np.concatenate([np.asarray(a) for _,_,a in pipe(spoken or script, voice='af_nicole', speed=SPEED)])
    sf.write(f"{out}/{name}.wav", audio, 24000)
    d=len(audio)/24000; n=len(script.split()); tot+=d; words+=n
    meta.append({"file":f"{name}.wav","script":script,"tts_text":spoken or script,"seconds":round(d,2),"words":n})
    print(f"{name:12} {d:5.2f}s {n:3d}w")
json.dump({"voice":"kokoro af_nicole","speed":SPEED,"lines":meta},open(f"{out}/lines.json","w"),indent=1)
print("TOTAL speech",round(tot,2),"s",words,"words",round(words/tot*60),"wpm")
