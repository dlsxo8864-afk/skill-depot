#!/bin/zsh
# Ask Codex's image tool for a second pose of an existing key painting (for pose-to-pose animation on 2s).
# Usage: gen_pose_variant.sh <episode-dir> <stem> "<what changes>" [suffix, default poseB]
# Reads assets/key/<stem>_key.png, writes assets/key/<stem>_poseB.png. Skips if it exists.
EP="$1"; stem="$2"; change="$3"; suffix="${4:-poseB}"
cd "$EP/assets/key" || exit 1
out="${stem}_${suffix}.png"
[ -f "$out" ] && { echo "$stem: exists, skipped"; exit 0; }
{ echo "The attached image is one frame of an animated film. Create the very next key pose of the same shot, in exactly the same medium and style as the attached frame (if it is a photograph of clay models, the result must also look like a photograph of the same clay models), for pose-to-pose animation."
  echo "CHANGE ONLY THIS: $change"
  echo "KEEP EVERYTHING ELSE IDENTICAL: the same camera position and framing, the same background, furniture and objects in the same places, the same lighting and colours, the same character design and clothes, the same materials, surface texture, grain and level of finish, the same blank screens and blank signs. No text, letters, numbers or logos anywhere. Portrait 9:16, same size as the attached image."
  echo "TASK: You are being used only as an image generator. Use your built-in image generation tool with the attached image as the reference to create this single image at the highest quality, and save it as a PNG named $out in the current working directory. Do not write code to draw it, do not edit any other file, do not run git, and do not do anything else. When the file is saved, reply with its pixel size and stop."
} | codex exec -s workspace-write --skip-git-repo-check -i "${stem}_key.png" - > "$EP/work/codex_pose_$stem.log" 2>&1
if [ -f "$out" ]; then echo "$stem: ok $(sips -g pixelWidth -g pixelHeight "$out" | awk '/pixel/{printf "%s ", $2}')"; else echo "$stem: FAILED"; fi
