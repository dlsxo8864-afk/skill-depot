import sys, json, numpy as np, soundfile as sf
from kokoro import KPipeline
out, name, script = sys.argv[1], sys.argv[2], sys.argv[3]
spoken = sys.argv[4] if len(sys.argv) > 4 else script
pipe = KPipeline(lang_code='a', device='cpu')
audio = np.concatenate([np.asarray(a) for _, _, a in pipe(spoken, voice='af_nicole', speed=1.5)])
sf.write(f"{out}/{name}.wav", audio, 24000)
m = json.load(open(f"{out}/lines.json"))
for l in m["lines"]:
    if l["file"] == f"{name}.wav":
        l.update(script=script, tts_text=spoken, seconds=round(len(audio)/24000, 2), words=len(script.split()))
json.dump(m, open(f"{out}/lines.json", "w"), indent=1)
print(name, round(len(audio)/24000, 2), "s")
