"""Download the open-licence fonts used by the episode 2 renderer into work/fonts/ (stdlib only).

    python src/tools/fetch_fonts.py

All from github.com/google/fonts (licence file saved next to each font):
  Fredoka (variable)         SIL Open Font License 1.1   clay letters, YEAR sign, card headlines, stamps
  Nunito (variable)          SIL Open Font License 1.1   card body text, chat box on screens
  Courier Prime Bold/Regular SIL Open Font License 1.1   printed tickets and bills, card source lines
  Permanent Marker           Apache License 2.0          hand-lettered placards and cardboard signs
"""
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from whatif.config import FONTS  # noqa: E402

BASE = "https://github.com/google/fonts/raw/main/"
FILES = {
    "fredoka_Fredoka[wdth,wght].ttf": "ofl/fredoka/Fredoka%5Bwdth,wght%5D.ttf",
    "fredoka_OFL.txt": "ofl/fredoka/OFL.txt",
    "nunito_Nunito[wght].ttf": "ofl/nunito/Nunito%5Bwght%5D.ttf",
    "nunito_OFL.txt": "ofl/nunito/OFL.txt",
    "courierprime_CourierPrime-Bold.ttf": "ofl/courierprime/CourierPrime-Bold.ttf",
    "courierprime_CourierPrime-Regular.ttf": "ofl/courierprime/CourierPrime-Regular.ttf",
    "courierprime_OFL.txt": "ofl/courierprime/OFL.txt",
    "permanentmarker_PermanentMarker-Regular.ttf": "apache/permanentmarker/PermanentMarker-Regular.ttf",
    "permanentmarker_LICENSE.txt": "apache/permanentmarker/LICENSE.txt",
}

if __name__ == "__main__":
    FONTS.mkdir(parents=True, exist_ok=True)
    for name, rel in FILES.items():
        dst = FONTS / name
        if not dst.exists():
            urllib.request.urlretrieve(BASE + rel, dst)
        print(dst, dst.stat().st_size)
