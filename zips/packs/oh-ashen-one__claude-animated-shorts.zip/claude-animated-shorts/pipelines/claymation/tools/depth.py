"""Relative depth for a key painting, CPU only (Depth Anything V2 small, ONNX Runtime CPU provider).

Usage: python src/tools/depth.py <model.onnx> <key.png> <out_depth.png>
Writes a 16-bit PNG at the key's resolution; larger value = nearer to camera.
"""
import sys

import cv2
import numpy as np
import onnxruntime as ort


def depth(model, img_path, out_path, long_side=1246):
    img = cv2.cvtColor(cv2.imread(img_path), cv2.COLOR_BGR2RGB)
    h, w = img.shape[:2]
    sh = long_side
    sw = int(round(w * sh / h / 14)) * 14
    x = cv2.resize(img, (sw, sh), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    x = (x - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
    x = x.transpose(2, 0, 1)[None].astype(np.float32)
    sess = ort.InferenceSession(model, providers=["CPUExecutionProvider"])
    out = sess.run(None, {sess.get_inputs()[0].name: x})[0]
    d = np.squeeze(out).astype(np.float32)
    # average with horizontally flipped pass for stabler edges
    out2 = sess.run(None, {sess.get_inputs()[0].name: x[..., ::-1].copy()})[0]
    d = 0.5 * (d + np.squeeze(out2)[..., ::-1])
    d = cv2.resize(d, (w, h), interpolation=cv2.INTER_CUBIC)
    d = (d - d.min()) / (d.max() - d.min())
    cv2.imwrite(out_path, (d * 65535).astype(np.uint16))
    print(out_path, d.shape, sess.get_providers())


if __name__ == "__main__":
    depth(*sys.argv[1:4])
