"""Fonts and type utilities shared by the physical props (props.py).

    font(kind, size, weight=None)   kinds: "clay" (Fredoka), "body" (Nunito), "type" / "type_reg"
                                    (Courier Prime Bold / Regular), "marker" (Permanent Marker)
    cap_height(fnt), at_least_cap(fnt, min_cap=MIN_CAP)
    text_alpha(s, fnt, tracking=0, min_cap=MIN_CAP) -> float32 alpha patch (enforces the cap height)
    wrap(fnt, text, max_w)
    over(dst_rgb, rgba, x, y), transform_rgba(rgba, scale, angle, origin)
"""
import math
from functools import lru_cache

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .config import FONT_FILES, FONTS, MIN_CAP


@lru_cache(maxsize=128)
def font(kind, size, weight=None):
    f = ImageFont.truetype(str(FONTS / FONT_FILES[kind]), int(size))
    if weight is not None:
        try:
            axes = f.get_variation_axes()
            vals = []
            for ax in axes:
                name = ax.get("name", b"")
                name = name.decode() if isinstance(name, bytes) else str(name)
                if "eight" in name:
                    vals.append(min(max(weight, ax["minimum"]), ax["maximum"]))
                else:
                    vals.append(ax.get("default", ax["maximum"]))
            f.set_variation_by_axes(vals)
        except Exception:
            pass
    f._whatif = (kind, int(size), weight)
    return f


def cap_height(fnt):
    b = fnt.getbbox("H")
    return b[3] - b[1]


def at_least_cap(fnt, min_cap=MIN_CAP):
    """The same face enlarged until its cap height is >= min_cap px."""
    if not min_cap or cap_height(fnt) >= min_cap:
        return fnt
    kind, size, weight = fnt._whatif
    for _ in range(60):
        size = max(size + 1, int(math.ceil(size * min_cap / max(cap_height(fnt), 1))))
        fnt = font(kind, size, weight)
        if cap_height(fnt) >= min_cap:
            break
    return fnt


def size_for_cap(kind, cap, weight=None):
    """Font size whose cap height is about `cap` px."""
    f = font(kind, 200, weight)
    return max(6, int(round(200 * cap / cap_height(f))))


def text_size(fnt, s):
    x0, y0, x1, y1 = fnt.getbbox(s)
    return x1 - x0, y1 - y0, x0, y0


def wrap(fnt, text, max_w):
    words, out, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if text_size(fnt, trial)[0] <= max_w or not cur:
            cur = trial
        else:
            out.append(cur)
            cur = w
    if cur:
        out.append(cur)
    return out


def text_alpha(s, fnt, tracking=0, min_cap=MIN_CAP, pad=2):
    """Text as a float alpha patch (supersampled 2x). Enforces the series minimum cap height; pass
    min_cap=0 only for tiny scenery text nobody needs to read."""
    fnt = at_least_cap(fnt, min_cap)
    kind, size, weight = fnt._whatif
    f2 = font(kind, size * 2, weight)
    widths = [text_size(f2, ch)[0] if ch != " " else text_size(f2, "n")[0] * 0.75 for ch in s]
    adv = [f2.getlength(ch) for ch in s]
    tw = int(sum(adv) + tracking * 2 * (len(s) - 1)) + 8
    asc, desc = f2.getmetrics()
    im = Image.new("L", (tw + 4 * pad, asc + desc + 4 * pad), 0)
    d = ImageDraw.Draw(im)
    x = 2 * pad
    for ch, a in zip(s, adv):
        d.text((x, 2 * pad), ch, font=f2, fill=255)
        x += a + tracking * 2
    a = np.asarray(im, np.float32) / 255
    ys, xs = np.nonzero(a > 0.02)
    if len(ys):
        a = a[max(0, ys.min() - 2 * pad):ys.max() + 2 * pad + 1, max(0, xs.min() - 2 * pad):xs.max() + 2 * pad + 1]
    return cv2.resize(a, (max(1, a.shape[1] // 2), max(1, a.shape[0] // 2)), interpolation=cv2.INTER_AREA)


def over(dst, rgba, x, y, opacity=1.0):
    """Alpha-over float RGBA onto float RGB dst at integer offset (clipped). In place."""
    h, w = rgba.shape[:2]
    H, W = dst.shape[:2]
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return dst
    p = rgba[ya - y:yb - y, xa - x:xb - x]
    a = p[..., 3:4] * opacity
    dst[ya:yb, xa:xb] = dst[ya:yb, xa:xb] * (1 - a) + p[..., :3] * a
    return dst


def transform_rgba(rgba, scale=1.0, angle=0.0, origin=None, sx=None, sy=None):
    """Scale (uniform, or sx/sy) and rotate an RGBA patch about origin (patch px). Returns (patch, dx, dy):
    the new patch and where its (0, 0) lands relative to the old one's."""
    h, w = rgba.shape[:2]
    sx = scale if sx is None else sx * scale
    sy = scale if sy is None else sy * scale
    if abs(sx - 1) < 1e-4 and abs(sy - 1) < 1e-4 and abs(angle) < 1e-4:
        return rgba, 0, 0
    ox, oy = origin if origin is not None else (w / 2, h / 2)
    a = math.radians(-angle)
    R = np.float32([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]]) @ np.diag([sx, sy]).astype(np.float32)
    t = np.float32([ox, oy]) - R @ np.float32([ox, oy])
    M = np.hstack([R, t[:, None]])
    corners = np.float32([[0, 0, 1], [w, 0, 1], [w, h, 1], [0, h, 1]]) @ M.T
    x0, y0 = np.floor(corners.min(0)).astype(int)
    x1, y1 = np.ceil(corners.max(0)).astype(int)
    M[:, 2] -= (x0, y0)
    out = cv2.warpAffine(rgba, M, (int(x1 - x0), int(y1 - y0)), flags=cv2.INTER_CUBIC, borderValue=0)
    out[..., 3] = np.clip(out[..., 3], 0, 1)
    return out, int(x0), int(y0)
