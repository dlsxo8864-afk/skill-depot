"""Timing helpers: frames, animating on 2s, easing and keyframe tracks."""
import math

from .config import FPS


def frame_of(t):
    """Nearest frame index for a time in seconds."""
    return int(round(t * FPS))


def even_frame_of(t):
    """Nearest even frame (character/effect animation updates on 2s)."""
    return 2 * int(round(t * FPS / 2))


def on2s(frame):
    """Time in seconds held on 2s: frames 2k and 2k+1 share one drawing."""
    return (frame - frame % 2) / FPS


def clamp01(x):
    return 0.0 if x < 0 else 1.0 if x > 1 else x


def smoothstep(a, b, x):
    t = clamp01((x - a) / (b - a)) if b != a else float(x >= a)
    return t * t * (3 - 2 * t)


def ease_in_out(t):
    t = clamp01(t)
    return 0.5 - 0.5 * math.cos(math.pi * t)


def ease_out_cubic(t):
    t = clamp01(t)
    return 1 - (1 - t) ** 3


def ease_in_cubic(t):
    t = clamp01(t)
    return t ** 3


def ease_out_back(t, s=1.9):
    t = clamp01(t) - 1
    return t * t * ((s + 1) * t + s) + 1


def ease_in_back(t, s=1.7):
    t = clamp01(t)
    return t * t * ((s + 1) * t - s)


EASES = {
    "linear": clamp01, "inout": ease_in_out, "out": ease_out_cubic, "in": ease_in_cubic,
    "back": ease_out_back, "anticip": ease_in_back, "hold": lambda t: 0.0 if t < 1 else 1.0,
}


class Track:
    """Keyframed scalar/tuple track. keys = [(time, value, ease_into_this_key), ...]."""

    def __init__(self, keys):
        self.keys = sorted(keys, key=lambda k: k[0])

    def __call__(self, t):
        ks = self.keys
        if t <= ks[0][0]:
            return ks[0][1]
        for (t0, v0, *_), (t1, v1, *e) in zip(ks, ks[1:]):
            if t <= t1:
                ease = EASES[e[0] if e else "inout"]
                u = ease((t - t0) / (t1 - t0)) if t1 > t0 else 1.0
                if isinstance(v0, (tuple, list)):
                    return tuple(a + (b - a) * u for a, b in zip(v0, v1))
                return v0 + (v1 - v0) * u
        return ks[-1][1]
