"""Text and interface as PHYSICAL OBJECTS in the miniature set.

Nothing here is a caption: every readable thing is a clay letter, a card or paper cut-out, a wooden
sign, a cardboard placard or a rubber-stamp impression. Each one is shaded from a height map by the
scene's key light, takes the local colour of the scene's light, casts a contact shadow onto what is
behind it, and is written into the depth buffer so the lens focuses on it like anything else.

Building blocks (all float32, straight alpha, plate px):
    Prop(rgba, height=None)                          a finished object
    clay_word(text, cap, color, seed)                clay letters (one Prop per glyph, see ClayTitle)
    card(w, h, kind, seed)                           paper / card / cardboard blank with cut edges
    print_text(prop, lines, ...)                     ink printed or painted onto a card
    on_stick(prop, length), hanging(prop, top_y)     mounts: a wooden dowel below, or two threads above
    year_sign(n)                                     the series YEAR sign (wooden plank, clay letters)
    data_card(lines, source)                         a printed card for the shot's real number
    stamp_ink(text, color, seed)                     a rubber-stamp impression (ink layer)
    scenario_ink()                                   the "SCENARIO" stamp for invented figures
    flip_card(text, ...), FlipNumber                 a number that changes by flipping cards
    ribbon(fr, centerline, width)                    a strip of paper along a curve (tickets, bills, tape)
    screen_insert(fr, quad, canvas)                  a backlit printed insert in a clay screen (laptop, phone)
Placing:
    place(fr, prop, x, y, depth=..., shadow=...)     composite into a Frame (plate px, top-left x, y)
    ink_on_quad(fr, ink, quad), ink_on_strip(...)    print/stamp onto a surface already in the picture
    letter_on_quad(fr, lines, quad, ...)             hand-letter a blank placard in perspective
Animation:
    drop_in(f, f_in), lower_in(f, f_in), lift_out(f, f_out)   on-2s arrivals and exits
    ClayTitle                                        words of clay letters landing one by one
"""
import math
from dataclasses import dataclass, field
from functools import lru_cache

import cv2
import numpy as np

from . import text as T
from .config import MIN_CAP

WOOD = (0.66, 0.46, 0.27)
CREAM_CARD = (0.93, 0.89, 0.80)
WHITE_PAPER = (0.95, 0.94, 0.90)
CARDBOARD = (0.74, 0.58, 0.39)
INK = (0.12, 0.10, 0.11)
STAMP_RED = (0.72, 0.12, 0.13)
STAMP_PURPLE = (0.36, 0.18, 0.52)
CLAY_RED = (0.80, 0.25, 0.16)
CLAY_CREAM = (0.93, 0.86, 0.70)
CLAY_YELLOW = (0.95, 0.74, 0.20)
CLAY_BLUE = (0.25, 0.42, 0.75)
CLAY_GREEN = (0.30, 0.58, 0.32)


# ------------------------------------------------------------------ noise and shading
def smooth_noise(h, w, seed, sigma, aniso=None):
    rng = np.random.default_rng(seed % (2 ** 32))
    n = rng.standard_normal((h, w)).astype(np.float32)
    if aniso:
        n = cv2.GaussianBlur(n, (0, 0), sigmaX=sigma * aniso, sigmaY=sigma)
    else:
        n = cv2.GaussianBlur(n, (0, 0), sigma)
    n -= n.mean()
    return n / (n.std() + 1e-6)


def shade(height, base, light=(-0.55, -0.75), strength=1.0, ambient=0.42, spec=0.10, spec_pow=14.0, alpha=None):
    """Light a height map: Lambert from the key light (direction TOWARD the light in image coords) plus a
    soft satin highlight; base (h, w, 3) or colour. Returns rgb."""
    h = height.astype(np.float32)
    gx = cv2.Sobel(h, cv2.CV_32F, 1, 0, ksize=3) / 8 * strength
    gy = cv2.Sobel(h, cv2.CV_32F, 0, 1, ksize=3) / 8 * strength
    nz = 1.0 / np.sqrt(gx * gx + gy * gy + 1)
    nx, ny = -gx * nz, -gy * nz
    lx, ly = light
    lz = 0.85
    ln = math.sqrt(lx * lx + ly * ly + lz * lz)
    lx, ly, lz = lx / ln, ly / ln, lz / ln
    ndl = np.clip(nx * lx + ny * ly + nz * lz, 0, 1)
    flat = lz
    diff = ambient + (1 - ambient) * ndl / flat * 0.9
    hx, hy, hz = lx, ly, lz + 1
    hn = math.sqrt(hx * hx + hy * hy + hz * hz)
    ndh = np.clip((nx * hx + ny * hy + nz * hz) / hn, 0, 1)
    sp = spec * ndh ** spec_pow
    base = np.asarray(base, np.float32)
    rgb = base * diff[..., None] + sp[..., None] * np.float32([1.0, 0.97, 0.92])
    return np.clip(rgb, 0, 1)


@dataclass
class Prop:
    """A physical object: straight-alpha RGBA (plate px) and an optional height map (for shadows)."""
    rgba: np.ndarray
    height: np.ndarray = None
    anchor: tuple = (0.0, 0.0)       # point of the patch that `place` puts at (x, y): (0,0) top-left
    text: bool = True                # carries text a viewer must read (checked against the safe area)
    label: str = ""
    textbox: tuple = None            # (x0, y0, x1, y1) patch px of the readable part (default: all opaque px)

    @property
    def w(self):
        return self.rgba.shape[1]

    @property
    def h(self):
        return self.rgba.shape[0]


def pad_rgba(rgba, p):
    return cv2.copyMakeBorder(rgba, p, p, p, p, cv2.BORDER_CONSTANT, value=0)


# ------------------------------------------------------------------ clay letters
@lru_cache(maxsize=256)
def clay_glyph(ch, cap, color, seed, weight=620, light=(-0.55, -0.75), thumb=True):
    """One plasticine letter: chunky, slightly wonky outline, rounded bevel, thumbprints and a tool mark,
    shaded by the key light. Returns Prop (anchor at the glyph's baseline-left)."""
    fnt = T.font("clay", T.size_for_cap("clay", cap, weight), weight)
    a = T.text_alpha(ch, fnt, min_cap=0)
    M = int(cap * 0.35) + 6
    a = cv2.copyMakeBorder(a, M, M, M, M, cv2.BORDER_CONSTANT, value=0)
    h, w = a.shape
    rng = np.random.default_rng(seed)
    # chunkier, then a hand-rolled wobble of the outline
    k = max(3, int(cap * 0.06)) | 1
    a = cv2.dilate(a, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    dx = smooth_noise(h, w, seed + 1, cap * 0.22) * cap * 0.022
    dy = smooth_noise(h, w, seed + 2, cap * 0.22) * cap * 0.022
    gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    a = cv2.remap(a, gx + dx, gy + dy, cv2.INTER_LINEAR)
    a = cv2.GaussianBlur(a, (0, 0), max(0.8, cap * 0.02))
    a = np.clip((a - 0.5) * 3 + 0.5, 0, 1)
    solid = (a > 0.5).astype(np.uint8)
    dt = cv2.distanceTransform(solid, cv2.DIST_L2, 5).astype(np.float32)
    r = max(3.0, cap * 0.13)
    u = np.clip(dt / r, 0, 1)
    hgt = np.sqrt(1 - (1 - u) ** 2) * r                     # rounded bevel
    hgt += (dt / (dt.max() + 1e-6)) ** 0.5 * r * 0.35        # pillowy middle
    # thumbprints: shallow ovals with fine concentric ridges
    inside = np.argwhere(dt > r * 0.9)
    if thumb and len(inside):
        for k in range(rng.integers(1, 3)):
            cy, cx = inside[rng.integers(len(inside))]
            ax, ay = cap * rng.uniform(0.16, 0.24), cap * rng.uniform(0.11, 0.17)
            ang = rng.uniform(0, math.pi)
            X, Y = gx - cx, gy - cy
            xr = X * math.cos(ang) + Y * math.sin(ang)
            yr = -X * math.sin(ang) + Y * math.cos(ang)
            d = np.sqrt((xr / ax) ** 2 + (yr / ay) ** 2)
            bowl = np.clip(1 - d ** 2, 0, 1)
            ridges = np.sin(d * ax / max(cap * 0.028, 1.2) * 2 * math.pi) * (d < 1)
            hgt -= bowl * r * 0.32 + ridges * r * 0.05 * bowl ** 0.5
    # one tool mark: a short groove
    if len(inside) and rng.random() < 0.7:
        cy, cx = inside[rng.integers(len(inside))]
        ang = rng.uniform(0, math.pi)
        L = cap * rng.uniform(0.15, 0.3)
        X, Y = gx - cx, gy - cy
        along = X * math.cos(ang) + Y * math.sin(ang)
        across = -X * math.sin(ang) + Y * math.cos(ang)
        groove = np.exp(-(across / max(cap * 0.012, 0.8)) ** 2) * np.clip(1 - (along / L) ** 2, 0, 1)
        hgt -= groove * r * 0.22
    # surface: soft low-frequency lumps only (fine noise reads as glitter, not clay)
    hgt += smooth_noise(h, w, seed + 3, cap * 0.035) * r * 0.035 + smooth_noise(h, w, seed + 4, cap * 0.10) * r * 0.06
    hgt = hgt * solid
    col = np.float32(color) * np.float32(1 + rng.uniform(-0.035, 0.035, 3))
    mott = 1 + 0.03 * smooth_noise(h, w, seed + 5, cap * 0.25)[..., None]
    face = shade(cv2.GaussianBlur(hgt, (0, 0), 0.8), col * mott, light, strength=1.25, ambient=0.52, spec=0.05,
                 spec_pow=6)
    # crevice darkening at the outline (ambient occlusion of a rounded edge)
    ao = 0.84 + 0.16 * np.clip(dt / (r * 0.6), 0, 1)
    face = face * ao[..., None]
    # thickness: the camera looks a little down on the set, so each letter shows its lower side wall
    T_ = max(2, int(round(cap * 0.075)))
    side_a = np.zeros_like(a)
    for k in range(1, T_ + 1):
        side_a = np.maximum(side_a, np.roll(a, k, axis=0))
    side_rgb = np.float32(color) * 0.50 * (0.85 + 0.15 * smooth_noise(h, w, seed + 6, cap * 0.2)[..., None] * 0.3)
    yy = np.arange(h, dtype=np.float32)[:, None, None]
    out_a = np.maximum(a, side_a)
    rgb = side_rgb * np.ones((h, w, 1), np.float32)
    rgb = rgb * (1 - a[..., None]) + face * a[..., None]
    # a thin dark seam where the face rolls over into the side
    seam = np.clip(side_a - a, 0, 1)
    seam = np.clip(seam - np.roll(seam, max(1, T_ // 2), axis=0), 0, 1)
    rgb = rgb * (1 - 0.25 * seam[..., None])
    a = out_a
    ys, xs = np.nonzero(a > 0.01)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    rgba = np.dstack([rgb, a])[y0:y1, x0:x1].astype(np.float32)
    return Prop(rgba, hgt[y0:y1, x0:x1], anchor=(0.0, 0.0), label=ch)


def clay_word(text, cap, color=CLAY_RED, seed=0, weight=620, light=(-0.55, -0.75), tracking=0.06,
              colors=None, tilt=2.2):
    """A word (or line) of separate clay letters: [(Prop, x_offset, y_offset, angle)] laid out left to
    right with uneven spacing, bounce and tilt (each letter placed by hand). Width = sum of advances."""
    rng = np.random.default_rng(seed + 99)
    fnt = T.font("clay", T.size_for_cap("clay", cap, weight), weight)
    out = []
    x = 0.0
    capH = T.cap_height(fnt)
    for i, ch in enumerate(text):
        if ch == " ":
            x += fnt.getlength(" ") * 0.9 + cap * 0.1
            continue
        c = colors[i % len(colors)] if colors else color
        g = clay_glyph(ch, cap, tuple(c), seed * 31 + i, weight, light)
        bb = fnt.getbbox(ch)
        # glyph patch top relative to the cap line: getbbox top offset vs "H"
        top = bb[1] - fnt.getbbox("H")[1]
        k = max(3, int(cap * 0.06)) | 1
        out.append((g, x - k * 0.5, top - k * 0.5 + rng.normal(0, cap * 0.03), rng.normal(0, tilt)))
        x += fnt.getlength(ch) + cap * tracking + rng.normal(0, cap * 0.02)
    return out, x, capH


def clay_line_prop(text, cap, color=CLAY_RED, seed=0, light=(-0.55, -0.75), colors=None, weight=620, tilt=2.2):
    """A whole line of clay letters as one Prop (for static use)."""
    glyphs, width, capH = clay_word(text, cap, color, seed, weight, light, colors=colors, tilt=tilt)
    pad = int(cap * 0.5)
    H = int(cap * 1.9) + 2 * pad
    W = int(width + cap * 0.6) + 2 * pad
    canvas = np.zeros((H, W, 4), np.float32)
    hmap = np.zeros((H, W), np.float32)
    for g, gx_, gy_, ang in glyphs:
        rg, dx, dy = T.transform_rgba(g.rgba, angle=ang)
        _over_rgba(canvas, rg, pad + gx_ + dx, pad + cap * 0.25 + gy_ + dy)
    return Prop(canvas, None, label=text)


def _over_rgba(dst, src, x, y):
    h, w = src.shape[:2]
    H, W = dst.shape[:2]
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return dst
    s = src[ya - y:yb - y, xa - x:xb - x]
    d = dst[ya:yb, xa:xb]
    sa = s[..., 3:4]
    da = d[..., 3:4]
    oa = sa + da * (1 - sa)
    rgb = (s[..., :3] * sa + d[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6)
    dst[ya:yb, xa:xb] = np.concatenate([rgb, oa], axis=2)
    return dst


# ------------------------------------------------------------------ paper, card, cardboard, wood
def _cut_outline(w, h, seed, rough=1.2, corner=5):
    """Alpha of a hand-cut rectangle: corners a little off square, edges slightly wavy."""
    rng = np.random.default_rng(seed)
    pts = []
    n = 24
    for side in range(4):
        for i in range(n):
            u = i / n
            if side == 0:
                p = [corner + u * (w - 2 * corner), 0]
            elif side == 1:
                p = [w, corner + u * (h - 2 * corner)]
            elif side == 2:
                p = [w - corner - u * (w - 2 * corner), h]
            else:
                p = [0, h - corner - u * (h - 2 * corner)]
            pts.append(p)
    pts = np.float32(pts)
    jit = np.cumsum(rng.normal(0, rough * 0.35, (len(pts), 2)), 0)
    jit -= np.linspace(0, 1, len(pts))[:, None] * jit[-1]
    pts += jit + rng.normal(0, rough * 0.3, (len(pts), 2))
    pts += 3
    S = 4
    a = np.zeros(((h + 6) * S, (w + 6) * S), np.uint8)
    cv2.fillPoly(a, [np.round(pts * S).astype(np.int32)], 255, cv2.LINE_AA)
    a = cv2.resize(a, (w + 6, h + 6), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    return a


def card(w, h, kind="card", seed=0, color=None, light=(-0.55, -0.75), bend=0.05, edge=1.0):
    """A blank cut-out. kind: "card" (cream card stock), "paper" (thin white paper), "cardboard"
    (corrugated brown), "ticket" (thin off-white paper). Returns Prop (no text)."""
    base = {"card": CREAM_CARD, "paper": WHITE_PAPER, "cardboard": CARDBOARD, "ticket": (0.96, 0.94, 0.88)}[kind]
    base = np.float32(color if color is not None else base)
    a = _cut_outline(w, h, seed, rough=2.2 if kind == "cardboard" else 1.1)
    H, W = a.shape
    fib = smooth_noise(H, W, seed + 1, 0.7, aniso=4.0) * 0.018 + smooth_noise(H, W, seed + 2, 14) * 0.022
    if kind == "cardboard":
        xs = np.arange(W, dtype=np.float32)
        flute = 0.012 * np.sin(xs / 5.5 * 2 * math.pi)[None, :]
        fib = fib * 1.6 + flute + smooth_noise(H, W, seed + 3, 3) * 0.02
    # bend: the card bows gently, so light falls off toward one side
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    u = xx / W - 0.5
    hgt = -bend * ((u * 2) ** 2) * W * 0.25 + smooth_noise(H, W, seed + 4, 25) * 1.2
    rgb = shade(hgt, base * (1 + fib)[..., None], light, strength=0.9, ambient=0.80, spec=0.02, spec_pow=6)
    # cut edge: the card's thickness catches light on the lit side and darkens on the other
    e = a - cv2.erode(a, np.ones((3, 3), np.uint8))
    gx = cv2.Sobel(a, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(a, cv2.CV_32F, 0, 1, ksize=3)
    facing = -(gx * light[0] + gy * light[1])
    facing = facing / (np.abs(facing).max() + 1e-6)
    rgb = rgb * (1 + edge * (0.10 * np.clip(facing, 0, 1)[..., None] * e[..., None]
                             - 0.16 * np.clip(-facing, 0, 1)[..., None] * e[..., None]))
    return Prop(np.dstack([np.clip(rgb, 0, 1), a]).astype(np.float32), hgt, text=False, label=kind)


def wood_plank(w, h, seed=0, color=WOOD, light=(-0.55, -0.75), bevel=5):
    """A small balsa / pine plank with grain, chipped corners and bevelled edges."""
    a = _cut_outline(w, h, seed, rough=1.6, corner=8)
    H, W = a.shape
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    warp = smooth_noise(H, W, seed + 1, 30) * 6
    grain = np.sin((yy + warp) / rng.uniform(3.0, 4.2) * 2 * math.pi) * 0.5 + 0.5
    grain = grain ** 3 * 0.10 + smooth_noise(H, W, seed + 2, 1.0, aniso=12) * 0.035
    knots = smooth_noise(H, W, seed + 3, 18) * 0.05
    base = np.float32(color) * (1 - grain - knots)[..., None]
    dt = cv2.distanceTransform((a > 0.5).astype(np.uint8), cv2.DIST_L2, 5).astype(np.float32)
    hgt = np.clip(dt / bevel, 0, 1) * bevel * 1.2 + smooth_noise(H, W, seed + 4, 1.0, aniso=10) * 0.3
    rgb = shade(hgt, base, light, strength=1.2, ambient=0.55, spec=0.04, spec_pow=8)
    return Prop(np.dstack([rgb, a]).astype(np.float32), hgt, text=False, label="plank")


def dowel(length, width=9, seed=0, color=(0.80, 0.66, 0.46), light=(-0.55, -0.75)):
    """A round wooden stick (vertical), shaded as a cylinder."""
    W, H = width + 4, length
    xx = (np.arange(W, dtype=np.float32) - (W - 1) / 2) / (width / 2)
    prof = np.sqrt(np.clip(1 - xx ** 2, 0, 1))
    hgt = np.tile(prof * width * 0.5, (H, 1))
    a = np.tile(np.clip((1 - np.abs(xx)) * width / 2 + 0.5, 0, 1), (H, 1)).astype(np.float32)
    grain = smooth_noise(H, W, seed + 1, 1.0, aniso=0.08) * 0.04
    base = np.float32(color) * (1 + grain)[..., None]
    rgb = shade(hgt, base, light, strength=1.4, ambient=0.45, spec=0.06, spec_pow=10)
    return Prop(np.dstack([rgb, a]).astype(np.float32), hgt, text=False, label="stick")


# ------------------------------------------------------------------ ink, print, stamps
def ink_alpha(alpha, seed, density=0.93, bleed=0.5, patchy=0.06):
    """A crisp text alpha as ink on fibre: tiny bleed, uneven density, a few voids."""
    a = cv2.GaussianBlur(alpha, (0, 0), bleed) if bleed > 0 else alpha
    h, w = a.shape
    n = smooth_noise(h, w, seed, 1.5) * patchy + smooth_noise(h, w, seed + 1, 6) * patchy
    return np.clip(a * (density + n), 0, 1)


def print_text(prop, lines, kind="body", cap=34, color=INK, weight=700, align="center", x=None, y=None,
               line_gap=0.55, seed=0, max_w=None, tracking=0, paint=False):
    """Print (or, paint=True, hand-paint) lines of text onto a card Prop, in place. lines: list of str or
    (str, dict(kind=, cap=, color=, weight=)) for mixed sizes. Text stays >= MIN_CAP. Returns the block's
    (x0, y0, x1, y1) on the card."""
    rgba = prop.rgba
    W, H = rgba.shape[1], rgba.shape[0]
    items = []
    for ln in lines:
        s, o = (ln, {}) if isinstance(ln, str) else ln
        k = o.get("kind", kind)
        c = max(o.get("cap", cap), MIN_CAP)
        f = T.font(k, T.size_for_cap(k, c, o.get("weight", weight)), o.get("weight", weight))
        al = T.text_alpha(s, f, tracking=o.get("tracking", tracking))
        if max_w and al.shape[1] > max_w:              # shrink only down to the minimum cap height
            sc = max(max_w / al.shape[1], MIN_CAP / c)
            al = cv2.resize(al, (max(1, int(al.shape[1] * sc)), max(1, int(al.shape[0] * sc))), interpolation=cv2.INTER_AREA)
        items.append((al, o.get("color", color), c))
    total = sum(al.shape[0] for al, _, _ in items) + sum(c * line_gap for _, _, c in items[:-1])
    cy = (H - total) / 2 if y is None else y
    x0s, y0s, x1s, y1s = [], [], [], []
    for i, (al, col, c) in enumerate(items):
        if align == "center":
            cx = (W - al.shape[1]) / 2 if x is None else x - al.shape[1] / 2
        else:
            cx = x if x is not None else (W - max(a.shape[1] for a, _, _ in items)) / 2
        ia = ink_alpha(al, seed + 7 * i, density=0.95 if paint else 0.92, bleed=0.7 if paint else 0.45,
                       patchy=0.08 if paint else 0.05)
        _ink_into(rgba, ia, np.float32(col), cx, cy)
        x0s.append(cx), y0s.append(cy), x1s.append(cx + al.shape[1]), y1s.append(cy + al.shape[0])
        cy += al.shape[0] + c * line_gap
    prop.text = True
    return min(x0s), min(y0s), max(x1s), max(y1s)


def _ink_into(rgba, a, col, x, y):
    """Ink soaks into the surface: the surface's own shading carries through the ink."""
    h, w = a.shape
    H, W = rgba.shape[:2]
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return
    p = a[ya - y:yb - y, xa - x:xb - x][..., None] * rgba[ya:yb, xa:xb, 3:4]
    surf = rgba[ya:yb, xa:xb, :3]
    lum = surf.mean(2, keepdims=True)
    inked = col * np.clip(lum / max(float(lum.mean()), 1e-3), 0.75, 1.15)
    rgba[ya:yb, xa:xb, :3] = surf * (1 - p) + inked * p


def stamp_ink(text, color=STAMP_RED, seed=0, cap=34, border=True, kind="clay", weight=700, angle=-6.0,
              lines=None, pad=14, double=True):
    """A rubber-stamp impression: rounded double border, letters, uneven ink (heavier at the rubber's
    edges, speckled voids). Returns (ink_alpha (h, w) float32, colour). Apply with ink_on_quad / stamp_on."""
    lines = lines or [text]
    cap = max(cap, MIN_CAP)
    f = T.font(kind, T.size_for_cap(kind, cap, weight), weight)
    als = [T.text_alpha(s, f, tracking=2) for s in lines]
    tw = max(a.shape[1] for a in als)
    th = sum(a.shape[0] for a in als) + int(cap * 0.35) * (len(als) - 1)
    bw = int(cap * 0.13) + 2
    ring = (4 if double else 2) * bw if border else 0
    W, H = tw + 2 * pad + ring, th + 2 * pad + ring
    canvas = np.zeros((H + 20, W + 20), np.float32)
    y = 10 + (H - th) / 2
    for a in als:
        x = 10 + (W - a.shape[1]) / 2
        canvas[int(y):int(y) + a.shape[0], int(x):int(x) + a.shape[1]] = np.maximum(
            canvas[int(y):int(y) + a.shape[0], int(x):int(x) + a.shape[1]], a)
        y += a.shape[0] + cap * 0.35
    if border:
        r = int(cap * 0.3)
        S = 4
        big = np.zeros(((H + 20) * S, (W + 20) * S), np.uint8)
        cv2.rectangle(big, ((10 + r // 2) * S, (10 + r // 2) * S), ((10 + W - r // 2) * S, (10 + H - r // 2) * S), 255, bw * S, cv2.LINE_AA)
        inset = bw * 2
        if double:
            cv2.rectangle(big, ((10 + inset + r // 2) * S, (10 + inset + r // 2) * S),
                          ((10 + W - inset - r // 2) * S, (10 + H - inset - r // 2) * S), 255, max(1, bw // 2) * S,
                          cv2.LINE_AA)
        bdr = cv2.resize(big, (W + 20, H + 20), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        canvas = np.maximum(canvas, bdr)
    h, w = canvas.shape
    rng = np.random.default_rng(seed)
    cover = 0.86 + 0.10 * smooth_noise(h, w, seed + 1, 9) + 0.06 * smooth_noise(h, w, seed + 2, 2)
    voids = (smooth_noise(h, w, seed + 3, 1.3) > 2.1).astype(np.float32)
    edge = canvas - cv2.erode(canvas, np.ones((3, 3), np.uint8))
    a = np.clip(canvas * cover * (1 - 0.7 * voids) + edge * 0.12, 0, 1)
    a = cv2.GaussianBlur(a, (0, 0), 0.6)
    a = np.clip(a * rng.uniform(0.92, 1.0), 0, 1)
    if angle:
        a, _, _ = T.transform_rgba(np.dstack([np.zeros((h, w, 3), np.float32), a]), angle=angle)
        a = a[..., 3]
    ys, xs = np.nonzero(a > 0.02)                 # trimmed to the impression (+2 px)
    if len(ys):
        a = a[max(ys.min() - 2, 0):ys.max() + 3, max(xs.min() - 2, 0):xs.max() + 3]
    return np.ascontiguousarray(a, dtype=np.float32), np.float32(color)


def scenario_ink(seed=3, cap=32, color=STAMP_PURPLE, angle=-7.0):
    """The series "SCENARIO" stamp for invented figures."""
    return stamp_ink("SCENARIO", color, seed, cap=cap, angle=angle)


def ink_on_quad(fr, ink, color, quad, opacity=1.0, wet=0.0, label="ink", text=True):
    """Print or stamp an ink alpha onto a surface in the picture, in perspective. quad: plate px TL TR BR
    BL. The surface's own light and texture carry through (ink multiplies into it). wet>0 = a fresh
    impression (slightly heavier, glossier)."""
    h, w = ink.shape
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    q = np.float32(quad)
    M = cv2.getPerspectiveTransform(src, q)
    x0, y0 = np.floor(q.min(0)).astype(int) - 2
    x1, y1 = np.ceil(q.max(0)).astype(int) + 3
    H, W = fr.rgb.shape[:2]
    x0, y0, x1, y1 = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
    if x1 <= x0 or y1 <= y0:
        return
    T_ = np.float32([[1, 0, -x0], [0, 1, -y0], [0, 0, 1]]) @ M
    a = cv2.warpPerspective(ink, T_, (x1 - x0, y1 - y0), flags=cv2.INTER_LINEAR)[..., None] * opacity
    a = np.clip(a * (1 + 0.15 * wet), 0, 1)
    surf = fr.rgb[y0:y1, x0:x1]
    lum = surf.mean(2, keepdims=True)
    tint = color * np.clip(lum / max(float(np.percentile(lum, 90)), 1e-3), 0.55, 1.1)
    fr.rgb[y0:y1, x0:x1] = surf * (1 - a) + tint * a + wet * 0.04 * a
    if text:
        fr.text_boxes.append((float(q[:, 0].min()), float(q[:, 1].min()), float(q[:, 0].max()), float(q[:, 1].max()), label))


def strip_map(top, bottom, w, h):
    """Map a w x h canvas onto a curved strip between two polylines (plate px, left to right, same point
    count). Returns (map_x, map_y, x0, y0, out_w, out_h) for cv2.remap into the plate box."""
    top, bottom = np.float32(top), np.float32(bottom)
    n = len(top)
    xs = np.linspace(0, w, n)
    pts = np.concatenate([top, bottom])
    x0, y0 = np.floor(pts.min(0)).astype(int) - 2
    x1, y1 = np.ceil(pts.max(0)).astype(int) + 3
    ow, oh = x1 - x0, y1 - y0
    # for every output pixel find (u, v): rasterise a fine mesh of quads
    U = 64
    us = np.linspace(0, 1, U)
    tx = np.interp(us * (n - 1), np.arange(n), top[:, 0]); ty = np.interp(us * (n - 1), np.arange(n), top[:, 1])
    bx = np.interp(us * (n - 1), np.arange(n), bottom[:, 0]); by = np.interp(us * (n - 1), np.arange(n), bottom[:, 1])
    mx = np.full((oh, ow), -1, np.float32)
    my = np.full((oh, ow), -1, np.float32)
    V = 16
    for i in range(U - 1):
        for j in range(V):
            v0, v1 = j / V, (j + 1) / V
            P = np.float32([[tx[i] + (bx[i] - tx[i]) * v0, ty[i] + (by[i] - ty[i]) * v0],
                            [tx[i + 1] + (bx[i + 1] - tx[i + 1]) * v0, ty[i + 1] + (by[i + 1] - ty[i + 1]) * v0],
                            [tx[i + 1] + (bx[i + 1] - tx[i + 1]) * v1, ty[i + 1] + (by[i + 1] - ty[i + 1]) * v1],
                            [tx[i] + (bx[i] - tx[i]) * v1, ty[i] + (by[i] - ty[i]) * v1]]) - np.float32([x0, y0])
            S = np.float32([[us[i] * w, v0 * h], [us[i + 1] * w, v0 * h], [us[i + 1] * w, v1 * h], [us[i] * w, v1 * h]])
            Hm = cv2.getPerspectiveTransform(P, S)
            qx0, qy0 = np.floor(P.min(0)).astype(int)
            qx1, qy1 = np.ceil(P.max(0)).astype(int) + 1
            qx0, qy0, qx1, qy1 = max(qx0, 0), max(qy0, 0), min(qx1, ow), min(qy1, oh)
            if qx1 <= qx0 or qy1 <= qy0:
                continue
            m = np.zeros((qy1 - qy0, qx1 - qx0), np.uint8)
            cv2.fillConvexPoly(m, np.round(P - [qx0, qy0]).astype(np.int32), 1)
            gy, gx = np.mgrid[qy0:qy1, qx0:qx1].astype(np.float32)
            den = Hm[2, 0] * gx + Hm[2, 1] * gy + Hm[2, 2]
            ux = (Hm[0, 0] * gx + Hm[0, 1] * gy + Hm[0, 2]) / den
            uy = (Hm[1, 0] * gx + Hm[1, 1] * gy + Hm[1, 2]) / den
            sel = m > 0
            mx[qy0:qy1, qx0:qx1][sel] = ux[sel]
            my[qy0:qy1, qx0:qx1][sel] = uy[sel]
    return mx, my, int(x0), int(y0), int(ow), int(oh)


def ink_on_strip(fr, ink, color, top, bottom, opacity=1.0, wet=0.0, label="ink", cache=None):
    """Like ink_on_quad, but onto a curved strip (a ticket or a bill that bends): `top` and `bottom` are
    polylines along the strip's edges (plate px, left to right, same number of points)."""
    h, w = ink.shape
    key = (id(ink), tuple(map(tuple, np.round(np.float32(top), 1))), tuple(map(tuple, np.round(np.float32(bottom), 1))))
    if cache is not None and key in cache:
        mx, my, x0, y0, ow, oh = cache[key]
    else:
        mx, my, x0, y0, ow, oh = strip_map(top, bottom, w, h)
        if cache is not None:
            cache[key] = (mx, my, x0, y0, ow, oh)
    a = cv2.remap(ink, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    a[mx < 0] = 0
    H, W = fr.rgb.shape[:2]
    xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x0 + ow, W), min(y0 + oh, H)
    a = a[ya - y0:yb - y0, xa - x0:xb - x0][..., None] * opacity
    a = np.clip(a * (1 + 0.15 * wet), 0, 1)
    surf = fr.rgb[ya:yb, xa:xb]
    lum = surf.mean(2, keepdims=True)
    tint = color * np.clip(lum / max(float(np.percentile(lum, 90)), 1e-3), 0.55, 1.1)
    fr.rgb[ya:yb, xa:xb] = surf * (1 - a) + tint * a + wet * 0.04 * a
    pts = np.concatenate([np.float32(top), np.float32(bottom)])
    fr.text_boxes.append((float(pts[:, 0].min()), float(pts[:, 1].min()), float(pts[:, 0].max()), float(pts[:, 1].max()), label))


def letter_alpha(lines, w, h, cap, kind="marker", seed=0, weight=None, jitter=0.6, line_gap=0.3):
    """Hand-lettered block (marker / brush) centred in a w x h canvas; letters a little uneven."""
    rng = np.random.default_rng(seed)
    cap = max(cap, MIN_CAP)
    f = T.font(kind, T.size_for_cap(kind, cap, weight), weight)
    rows = []
    for ln in lines:
        glyphs = []
        for ch in ln:
            if ch == " ":
                glyphs.append(None)
                continue
            a = T.text_alpha(ch, f, min_cap=0)
            sc = 1 + rng.normal(0, 0.04 * jitter)
            a = cv2.resize(a, (max(1, int(a.shape[1] * sc)), max(1, int(a.shape[0] * sc))))
            ra, _, _ = T.transform_rgba(np.dstack([np.zeros(a.shape + (3,), np.float32), a]), angle=rng.normal(0, 3 * jitter))
            glyphs.append(ra[..., 3])
        rows.append(glyphs)
    sp = f.getlength(" ") * 0.8
    widths = [sum((g.shape[1] if g is not None else sp) for g in r) + 2 * len(r) for r in rows]
    heights = [max([g.shape[0] for g in r if g is not None] + [cap]) for r in rows]
    total = sum(heights) + cap * line_gap * (len(rows) - 1)
    need_w, need_h = int(max(widths) + cap), int(total + cap * 0.6)
    W0, H0 = w, h
    if need_w > w or need_h > h:                 # the lettering is bigger than the sign: letter a larger
        k = max(need_w / w, need_h / h)          # board and shrink it onto the sign (cap gets smaller!)
        w, h = int(np.ceil(w * k)), int(np.ceil(h * k))
        print(f"[letter_alpha] {lines!r} does not fit {W0}x{H0} at cap {cap}; shrunk by {1 / k:.2f}")
    canvas = np.zeros((h, w), np.float32)
    y = (h - total) / 2
    for r, rw, rh in zip(rows, widths, heights):
        x = (w - rw) / 2
        for g in r:
            if g is None:
                x += sp
                continue
            yy = int(y + (rh - g.shape[0]) + rng.normal(0, 1.5 * jitter))
            xx = int(x)
            ys, xs = slice(max(yy, 0), min(yy + g.shape[0], h)), slice(max(xx, 0), min(xx + g.shape[1], w))
            gs = g[ys.start - yy:ys.stop - yy, xs.start - xx:xs.stop - xx]
            canvas[ys, xs] = np.maximum(canvas[ys, xs], gs)
            x += g.shape[1] + 2
        y += rh + cap * line_gap
    if (w, h) != (W0, H0):
        canvas = cv2.resize(canvas, (W0, H0), interpolation=cv2.INTER_AREA)
    return canvas


def letter_on_quad(fr, lines, quad, cap=40, color=INK, kind="marker", seed=0, canvas=(400, 260), label="placard"):
    """Hand-letter a blank sign already in the picture (placard, cardboard, board), in perspective.
    quad: plate px TL TR BR BL of the sign's face. cap is measured on the flat canvas; keep the
    on-screen result >= 30 px (the quad scales it)."""
    w, h = canvas
    a = letter_alpha(lines, w, h, cap, kind, seed)
    a = ink_alpha(a, seed + 5, density=0.95, bleed=0.6, patchy=0.07)
    ink_on_quad(fr, a, np.float32(color), quad, label=label)


# ------------------------------------------------------------------ assembled signs and cards
def hanging(prop, top_y, seed=0, holes=(0.16, 0.84), color=(0.22, 0.19, 0.16), splay=0.0):
    """Two threads from the prop's top up to plate y = top_y (relative to the prop's top, negative = up).
    Returns a new Prop whose anchor still points at the original prop's top-left."""
    rng = np.random.default_rng(seed)
    up = int(-top_y) + 4
    W, H = prop.w, prop.h + up
    canvas = np.zeros((H, W, 4), np.float32)
    S = 4
    big = np.zeros((H * S, W * S), np.uint8)
    for k, hx in enumerate(holes):
        x = hx * W
        xt = x + splay * (1 if k else -1) + rng.normal(0, 2)
        pts = []
        for i in range(12):
            u = i / 11
            pts.append([(xt + (x - xt) * u + math.sin(u * math.pi) * rng.normal(0, 0.6)) * S, (u * (up + 6)) * S])
        cv2.polylines(big, [np.int32(pts)], False, 255, int(1.7 * S), cv2.LINE_AA)
    th = cv2.resize(big, (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    canvas[..., :3] = np.float32(color)
    canvas[..., 3] = th * 0.9
    _over_rgba(canvas, prop.rgba, 0, up)
    hg = None
    if prop.height is not None:
        hg = np.zeros((H, W), np.float32)
        hg[up:] = prop.height[:H - up, :W]
    tb = prop.textbox or (0, 0, prop.w, prop.h)
    return Prop(canvas, hg, anchor=(prop.anchor[0], prop.anchor[1] + up), text=prop.text, label=prop.label,
                textbox=(tb[0], tb[1] + up, tb[2], tb[3] + up))


def on_stick(prop, length, seed=0, x_frac=0.5, width=9):
    """The prop glued to a wooden dowel that runs `length` px down from behind its lower half."""
    st = dowel(length + prop.h // 2, width, seed)
    W = max(prop.w, st.w)
    H = prop.h + length
    canvas = np.zeros((H, W, 4), np.float32)
    _over_rgba(canvas, st.rgba, int(prop.w * x_frac - st.w / 2), prop.h // 2)
    _over_rgba(canvas, prop.rgba, 0, 0)
    return Prop(canvas, None, anchor=prop.anchor, text=prop.text, label=prop.label,
                textbox=prop.textbox or (0, 0, prop.w, prop.h))


@lru_cache(maxsize=16)
def year_sign(n, cap=46, seed=None, light=(-0.55, -0.75)):
    """The series YEAR sign: a small wooden plank with "YEAR" in cream clay and the number in red clay
    pressed onto it, two screw eyes on top for its threads. Prop (no threads; see BaseShot.draw_year)."""
    seed = 400 + n if seed is None else seed
    word, w1, _ = clay_word("YEAR", int(cap * 0.78), CLAY_CREAM, seed, weight=650, light=light, tilt=1.5)
    num, w2, _ = clay_word(str(n), cap, CLAY_RED, seed + 5, weight=700, light=light, tilt=2.5)
    padx, pady = int(cap * 0.55), int(cap * 0.42)
    gap = int(cap * 0.38)
    W = int(w1 + gap + w2 + 2 * padx)
    H = int(cap * 1.18 + 2 * pady)
    plank = wood_plank(W, H, seed, light=light)
    canvas = pad_rgba(plank.rgba, 12)
    off = 12 + 3
    base_y = off + pady + cap * 0.05
    _place_glyphs(canvas, word, off + padx, base_y + cap * 0.22, light)
    _place_glyphs(canvas, num, off + padx + w1 + gap, base_y, light)
    # screw eyes for the threads
    for hx in (0.16, 0.84):
        cx, cy = int(off + hx * W), off + 6
        cv2.circle(canvas, (cx, cy), 4, (0.55, 0.52, 0.48, 1.0), 2, cv2.LINE_AA)
    return Prop(canvas, None, anchor=(off, off), label=f"YEAR {n}", textbox=(off, off, off + W, off + H))


def _place_glyphs(canvas, glyphs, x, y, light, shadow=0.45):
    """Press clay glyphs onto a surface patch with a soft contact shadow under each."""
    for g, gx_, gy_, ang in glyphs:
        rg, dx, dy = T.transform_rgba(g.rgba, angle=ang)
        px, py = x + gx_ + dx, y + gy_ + dy
        sa = cv2.GaussianBlur(rg[..., 3], (0, 0), 2.2) * shadow
        sx, sy = int(round(px - light[0] * 4)), int(round(py - light[1] * 4))
        h, w = sa.shape
        H, W = canvas.shape[:2]
        xa, ya, xb, yb = max(sx, 0), max(sy, 0), min(sx + w, W), min(sy + h, H)
        if xb > xa and yb > ya:
            s = sa[ya - sy:yb - sy, xa - sx:xb - sx][..., None]
            canvas[ya:yb, xa:xb, :3] *= 1 - s * canvas[ya:yb, xa:xb, 3:4]
        _over_rgba(canvas, rg, px, py)


SOURCE_CAP = 37          # source line cap (px): ink, light and lens soften it ~17 % on screen (check 14: >= 30)
SOURCE_MAX_W = 640      # a longer source line wraps onto a second line so the card stays inside the safe area


def data_card(lines, source=None, width=560, cap=38, kind="card", seed=0, light=(-0.55, -0.75),
              head_color=INK, accent=None, source_kind="type", wrap=True):
    """A printed card for the shot's real number. lines: str or (str, opts) as in print_text; the first
    line is set bold. source: a smaller line underneath, set at SOURCE_CAP (measured >= 30 px on screen),
    wrapped when wider than SOURCE_MAX_W."""
    fnt = T.font("body", T.size_for_cap("body", cap, 800), 800)
    src_rows = []
    if source:                                   # the card is at least as wide as its source line(s)
        sw = 650 if source_kind == "body" else None
        sf_ = T.at_least_cap(T.font(source_kind, T.size_for_cap(source_kind, SOURCE_CAP, sw), sw), SOURCE_CAP)
        src_rows = T.wrap(sf_, source, SOURCE_MAX_W)
        if len(src_rows) == 2 and ", " in source:    # prefer breaking after a comma ("Company guidance," / "Q3 2026")
            for i in sorted((i for i, ch in enumerate(source) if source[i:i + 2] == ", "),
                            key=lambda i: abs(i - len(source) / 2)):
                a, b = source[:i + 1], source[i + 2:]
                if max(T.text_size(sf_, a)[0], T.text_size(sf_, b)[0]) <= SOURCE_MAX_W:
                    src_rows = [a, b]
                    break
        sw_px = max(T.text_size(sf_, r)[0] for r in src_rows)
        width = max(width, int(sw_px + 2 * int(cap * 0.45) + 56))
    rows = []
    for ln in lines:
        s, o = (ln, {}) if isinstance(ln, str) else ln
        rows += [(r, o) for r in (T.wrap(T.at_least_cap(fnt), s, width - 2 * int(cap * 0.7)) if wrap else [s])]
    items = [(r, {"kind": "body", "cap": cap, "weight": 800, "color": head_color, **o}) for r, o in rows]
    for r in src_rows:
        items.append((r, {"kind": source_kind, "cap": SOURCE_CAP, "weight": 650 if source_kind == "body" else None,
                          "color": (0.30, 0.26, 0.24)}))
    lh = sum(max(o["cap"], MIN_CAP) * 1.55 for _, o in items)
    H = int(lh + cap * 1.3)
    c = card(width, H, kind, seed, light=light)
    print_text(c, items, cap=cap, line_gap=0.55, seed=seed, max_w=width - 40)
    c.label = " / ".join(r for r, _ in items)
    return c


def flip_card(text, cap=56, w=None, seed=0, color=INK, light=(-0.55, -0.75)):
    """One card of a flip number: a small cream card with the figure printed big."""
    fnt = T.font("body", T.size_for_cap("body", cap, 900), 900)
    tw = T.text_size(fnt, text)[0]
    w = w or int(tw + cap * 1.0)
    c = card(w, int(cap * 1.9), "card", seed, light=light, bend=0.03)
    print_text(c, [(text, {"weight": 900, "cap": cap, "color": color})], seed=seed)
    c.label = text
    return c


class FlipNumber:
    """A number that changes by replacement: a little stack of cards; on each change the front card
    flips down (one exposure squashed to a sliver, darkened) and the next card is there.
        fn = FlipNumber(["$15", "$19", "$25"], [f_a, f_b], cap=60)
        prop = fn.prop(f)"""

    def __init__(self, values, change_frames, cap=56, seed=0, light=(-0.55, -0.75)):
        self.values, self.changes = list(values), [c - c % 2 for c in change_frames]
        w = max(T.text_size(T.font("body", T.size_for_cap("body", cap, 900), 900), v)[0] for v in values) + int(cap)
        self.cards = [flip_card(v, cap, w, seed + i, light=light) for i, v in enumerate(values)]

    def index(self, f):
        return sum(1 for c in self.changes if f >= c)

    def prop(self, f):
        i = self.index(f)
        # the exposure before a change: the old card is half flipped (squashed toward its bottom edge)
        nxt = [c for c in self.changes if c > f]
        if nxt and nxt[0] - f <= 2 and i + 1 < len(self.cards):
            old = self.cards[i].rgba
            new = self.cards[i + 1].rgba
            h = old.shape[0]
            sq = cv2.resize(old, (old.shape[1], max(2, int(h * 0.28))), interpolation=cv2.INTER_AREA)
            sq[..., :3] *= 0.72
            out = new.copy()
            y = h - sq.shape[0]
            _over_rgba(out, sq, 0, y)
            return Prop(out, None, label=self.values[i + 1])
        return self.cards[min(i, len(self.cards) - 1)]


# ------------------------------------------------------------------ placing into the set
def scene_light(fr, x0, y0, x1, y1, strength=0.45):
    """Colour cast and brightness of the set's light around a box (plate px): (gain (3,), lum)."""
    H, W = fr.rgb.shape[:2]
    pad = 60
    xa, ya, xb, yb = max(int(x0) - pad, 0), max(int(y0) - pad, 0), min(int(x1) + pad, W), min(int(y1) + pad, H)
    if xb <= xa or yb <= ya:
        return np.ones(3, np.float32), 0.5
    patch = fr.rgb[ya:yb:4, xa:xb:4].reshape(-1, 3)
    lum = patch.mean(1)
    lit = patch[lum >= np.percentile(lum, 60)] if len(lum) > 10 else patch   # the light falling here, not the shadows
    c = lit.mean(0)
    cast = c / (c.mean() + 1e-6)
    cast = 1 + (cast - 1) * strength
    L = float(c.mean())
    return np.clip(cast, 0.7, 1.3).astype(np.float32), L


def place(fr, prop, x, y, depth=None, shadow="contact", light_match=0.45, brightness=(0.80, 1.06),
          opacity=1.0, scale=1.0, angle=0.0, sx=None, sy=None, origin=None, label=None, shadow_opacity=None,
          shadow_dist=None, shadow_blur=None):
    """Composite a Prop into the frame at plate px (x, y) = where prop.anchor lands.
    depth: the prop's depth (0 far .. 1 near) written where it is opaque (None = leave the buffer).
    shadow: "contact" (standing on / pressed against a surface: tight dark contact plus a short soft cast
    shadow), "hang" (hanging in front of a backdrop: a softer, longer shadow), "none".
    light_match: how much of the local light colour the prop takes. scale/angle/sx/sy: posed on 2s by
    the caller (squash and stretch). Returns the output box (plate px)."""
    rgba = prop.rgba
    ax, ay = prop.anchor
    tmask = None
    if prop.text and prop.textbox is not None:
        tmask = np.zeros(rgba.shape[:2] + (4,), np.float32)
        bx0, by0, bx1, by1 = (int(round(v)) for v in prop.textbox)
        tmask[max(by0, 0):by1, max(bx0, 0):bx1, 3] = 1.0
    if scale != 1.0 or angle or sx is not None or sy is not None:
        o = origin if origin is not None else (rgba.shape[1] / 2, rgba.shape[0])
        rgba, dx, dy = T.transform_rgba(rgba, scale, angle, o, sx, sy)
        if tmask is not None:
            tmask, _, _ = T.transform_rgba(tmask, scale, angle, o, sx, sy)
        ax, ay = ax - dx, ay - dy
    X, Y = x - ax, y - ay
    h, w = rgba.shape[:2]
    a = rgba[..., 3]
    lx, ly = fr.light
    if shadow != "none":
        dist = shadow_dist if shadow_dist is not None else (7 if shadow == "contact" else 22)
        blur = shadow_blur if shadow_blur is not None else (4.0 if shadow == "contact" else 11.0)
        op = shadow_opacity if shadow_opacity is not None else (0.48 if shadow == "contact" else 0.30)
        pad = int(dist + blur * 3) + 2
        A = cv2.copyMakeBorder(a, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
        M = np.float32([[1, 0, -lx * dist], [0, 1, -ly * dist]])
        cast = cv2.GaussianBlur(cv2.warpAffine(A, M, (A.shape[1], A.shape[0])), (0, 0), blur) * op
        if shadow == "contact":
            M2 = np.float32([[1, 0, -lx * 2], [0, 1, -ly * 2]])
            tight = cv2.GaussianBlur(cv2.warpAffine(A, M2, (A.shape[1], A.shape[0])), (0, 0), 1.6) * 0.35
            cast = np.clip(cast + tight, 0, 0.75)
        _shadow_into(fr.rgb, cast * opacity, X - pad, Y - pad)
    gain, L = scene_light(fr, X, Y, X + w, Y + h, light_match)
    bright = float(np.clip(0.55 + 0.9 * L, *brightness))
    lit = rgba.copy()
    lit[..., :3] = np.clip(rgba[..., :3] * gain * bright, 0, 1)
    T.over(fr.rgb, lit, X, Y, opacity)
    if depth is not None:
        _depth_into(fr.depth, a * opacity, X, Y, depth)
    if prop.text:
        ys, xs = np.nonzero((a > 0.5) if tmask is None else (tmask[..., 3] > 0.5) & (a > 0.5))
        if len(ys):
            fr.text_boxes.append((X + xs.min(), Y + ys.min(), X + xs.max(), Y + ys.max(), label or prop.label))
    return X, Y, X + w, Y + h


def _shadow_into(rgb, s, x, y, tint=(0.30, 0.26, 0.30)):
    h, w = s.shape
    H, W = rgb.shape[:2]
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return
    p = s[ya - y:yb - y, xa - x:xb - x][..., None]
    rgb[ya:yb, xa:xb] *= 1 - p * (1 - np.float32(tint))


def _depth_into(dep, a, x, y, value):
    h, w = a.shape
    H, W = dep.shape
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return
    p = np.clip(a[ya - y:yb - y, xa - x:xb - x] * 2 - 0.5, 0, 1)
    dep[ya:yb, xa:xb] = dep[ya:yb, xa:xb] * (1 - p) + value * p


# ------------------------------------------------------------------ on-2s arrivals
def drop_in(f, f_in, height=46):
    """A prop set down by hand onto the set (on 2s): exposure 0 above and stretched, 1 landing squash,
    2 a little rebound, then still. Returns dict(dy, sx, sy) or None before f_in."""
    if f < f_in:
        return None
    k = (f - (f_in - f_in % 2)) // 2
    seq = [dict(dy=-height, sx=0.94, sy=1.08), dict(dy=0, sx=1.08, sy=0.90), dict(dy=-3, sx=0.98, sy=1.03)]
    return seq[k] if k < len(seq) else dict(dy=0, sx=1.0, sy=1.0)


def lower_in(f, f_in, height=70, swing=2.4):
    """A hanging sign lowered into shot on its threads: drops in, bounces on the strings, swings out.
    Returns dict(dy, angle) or None before f_in."""
    if f < f_in:
        return None
    k = (f - (f_in - f_in % 2)) // 2
    seq = [(-height, swing), (8, -swing * 0.8), (-3, swing * 0.5), (1, -swing * 0.3), (0, swing * 0.15)]
    dy, ang = seq[k] if k < len(seq) else (0, 0.0)
    return dict(dy=dy, angle=ang)


def lift_out(f, f_out, height=60):
    """Reverse of lower_in: two exposures rising out, then gone (None)."""
    if f_out is None or f < f_out - 4:
        return dict(dy=0, angle=0.0)
    k = (f - (f_out - 4 - (f_out - 4) % 2)) // 2
    if k >= 2:
        return None
    return dict(dy=-height * (0.35 if k == 0 else 1.0), angle=0.8 * (1 if k else -1))


class ClayTitle:
    """Clay letters landing word by word (each letter dropped by hand, on 2s, staggered by one
    exposure), then staying put (a tiny settle when the next word lands next to them).

        title = ClayTitle([["WHAT", "IF", "EVERY"], ["STATE", "BANNED"]], cap=72, x=80, y=150,
                          line_h=1.35, colors=[CLAY_CREAM], seed=1)
        title.cue([f_what, f_if, ...])              # one landing frame per word, in reading order
        title.draw(fr, f, depth=0.6)

    Words wrap as given (one list per line), left aligned at plate x, first cap line at plate y."""

    def __init__(self, lines, cap=72, x=80, y=150, line_h=1.38, colors=None, seed=0, light=(-0.55, -0.75),
                 word_gap=0.45, align="left", max_w=None):
        self.cap, self.x, self.y = cap, x, y
        self.words = []
        cy = y
        cols = colors or [CLAY_CREAM]
        k = 0
        for li, line in enumerate(lines):
            built = []
            for wi, word in enumerate(line):
                glyphs, wdt, _ = clay_word(word, cap, tuple(cols[k % len(cols)]), seed + 17 * k, light=light)
                built.append((glyphs, wdt))
                k += 1
            total = sum(w for _, w in built) + cap * word_gap * (len(built) - 1)
            cx = x if align == "left" else x + ((max_w or total) - total) / 2
            for glyphs, wdt in built:
                self.words.append({"glyphs": glyphs, "x": cx, "y": cy, "w": wdt})
                cx += wdt + cap * word_gap
            cy += cap * line_h
        self.cues = [None] * len(self.words)

    def cue(self, frames):
        self.cues = list(frames) + [None] * (len(self.words) - len(frames))
        return self

    def box(self):
        xs = [w["x"] for w in self.words] + [w["x"] + w["w"] for w in self.words]
        ys = [w["y"] for w in self.words]
        return min(xs), min(ys), max(xs), max(ys) + self.cap * 1.1

    def draw(self, fr, f, depth=None, shadow_dist=16, shadow_blur=7.0, shadow_opacity=0.36, light_match=0.35,
             out=None):
        """out: optional frame (lift_out cue) when the title leaves."""
        for wi, wd in enumerate(self.words):
            fc = self.cues[wi]
            if fc is None or f < fc - fc % 2:
                continue
            lo = lift_out(f, out) if out is not None else dict(dy=0, angle=0)
            if lo is None:
                continue
            for gi, (g, gx_, gy_, ang) in enumerate(wd["glyphs"]):
                d = drop_in(f, fc + 2 * (gi // 2), height=self.cap * 0.55)
                if d is None:
                    continue
                place(fr, g, wd["x"] + gx_, wd["y"] + gy_ + d["dy"] + lo["dy"], depth=depth, shadow="hang",
                      angle=ang + lo["angle"], sx=d["sx"], sy=d["sy"], light_match=light_match,
                      shadow_dist=shadow_dist, shadow_blur=shadow_blur, shadow_opacity=shadow_opacity,
                      label="title")


# ------------------------------------------------------------------ paper ribbons and screen inserts
def _resample(points, n):
    p = np.float32(points)
    seg = np.sqrt((np.diff(p, axis=0) ** 2).sum(1))
    s = np.concatenate([[0], np.cumsum(seg)])
    t = np.linspace(0, s[-1], n)
    return np.stack([np.interp(t, s, p[:, 0]), np.interp(t, s, p[:, 1])], 1).astype(np.float32), float(s[-1])


def ribbon(fr, centerline, width, seed=0, kind="ticket", depth=None, shadow=0.35, shadow_dist=6.0, label="ribbon",
           twist=None, cache=None, color=None):
    """A strip of paper lying along `centerline` (plate px points, from its fixed end to its free end),
    `width` px across. Shaded by how each part of the strip faces the key light (a bend toward the light
    is brighter, a bend away darker), with a cut edge, a soft contact shadow and a depth write.
    twist: optional per-point width factors (0..1) where the strip turns edge-on. Returns its box."""
    c, L = _resample(centerline, 48)
    if L < 2:
        return None
    t = np.gradient(c, axis=0)
    t /= np.linalg.norm(t, axis=1, keepdims=True) + 1e-6
    nrm = np.stack([t[:, 1], -t[:, 0]], 1)               # one side of the strip all along (no flips)
    wf = np.ones(len(c), np.float32) if twist is None else np.interp(np.linspace(0, 1, len(c)), np.linspace(0, 1, len(twist)), twist)
    top = c + nrm * (width / 2) * wf[:, None]
    bot = c - nrm * (width / 2) * wf[:, None]
    Lw = max(8, int(L))
    tex = card(Lw, int(width), kind, seed, color=color, light=fr.light, bend=0.0, edge=0.25).rgba
    tex = tex[3:3 + int(width), 3:3 + Lw]
    th, tw = tex.shape[:2]
    # light along the strip: the strip's surface normal tilts with its curvature
    lx, ly = fr.light
    facing = (nrm[:, 0] * lx + nrm[:, 1] * ly) / (math.hypot(lx, ly) + 1e-6)
    k = np.interp(np.linspace(0, len(c) - 1, tw), np.arange(len(c)), 0.94 + 0.12 * facing).astype(np.float32)
    tex = tex.copy()
    tex[..., :3] *= k[None, :, None]
    tex[0, :, 3] *= 0.5
    tex[-1, :, 3] *= 0.5
    key = None
    if cache is not None:
        key = (round(L, 1), tuple(np.round(top[::6].ravel(), 1)), int(width))
    if key is not None and key in cache:
        mx, my, x0, y0, ow, oh = cache[key]
    else:
        mx, my, x0, y0, ow, oh = strip_map(top, bot, tw, th)
        if key is not None:
            cache[key] = (mx, my, x0, y0, ow, oh)
    mapped = cv2.remap(tex, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    mapped[mx < 0] = 0
    a = mapped[..., 3]
    if shadow:
        pad = int(shadow_dist * 3 + 8)
        A_ = cv2.copyMakeBorder(a, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
        M = np.float32([[1, 0, -lx * shadow_dist], [0, 1, -ly * shadow_dist]])
        cast = cv2.GaussianBlur(cv2.warpAffine(A_, M, (A_.shape[1], A_.shape[0])), (0, 0), shadow_dist * 0.7) * shadow
        _shadow_into(fr.rgb, cast, x0 - pad, y0 - pad)
    gain, Lm = scene_light(fr, x0, y0, x0 + ow, y0 + oh, 0.45)
    mapped[..., :3] = np.clip(mapped[..., :3] * gain * float(np.clip(0.55 + 0.9 * Lm, 0.8, 1.04)), 0, 1)
    T.over(fr.rgb, mapped, x0, y0)
    if depth is not None:
        _depth_into(fr.depth, a, x0, y0, depth)
    return x0, y0, x0 + ow, y0 + oh


def screen_insert(fr, quad, canvas, glow=1.0, keep=0.10, feather=1.5, label="screen", text=True, bezel_shadow=0.25,
                  text_rect=None):
    """A backlit printed insert in a clay screen: `canvas` (float RGB, any size, drawn flat) is warped onto
    the screen `quad` (plate px TL TR BR BL). The light comes from behind it, so it is NOT relit by the
    room; `keep` of the painted screen (its glass sheen) stays on top, and the bezel throws a thin
    shadow onto the insert's edges."""
    h, w = canvas.shape[:2]
    q = np.float32(quad)
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    x0, y0 = np.floor(q.min(0)).astype(int) - 3
    x1, y1 = np.ceil(q.max(0)).astype(int) + 4
    H, W = fr.rgb.shape[:2]
    x0, y0, x1, y1 = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
    M = np.float32([[1, 0, -x0], [0, 1, -y0], [0, 0, 1]]) @ cv2.getPerspectiveTransform(src, q)
    warped = cv2.warpPerspective(canvas.astype(np.float32), M, (x1 - x0, y1 - y0), flags=cv2.INTER_AREA
                                 if w > (x1 - x0) * 1.5 else cv2.INTER_LINEAR)
    S = 4
    big = np.zeros(((y1 - y0) * S, (x1 - x0) * S), np.uint8)
    cv2.fillConvexPoly(big, np.round((q - [x0, y0]) * S).astype(np.int32), 255, cv2.LINE_AA)
    m = cv2.resize(big, (x1 - x0, y1 - y0), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    if feather:
        m = cv2.GaussianBlur(m, (0, 0), feather)
    inner = cv2.erode(m, np.ones((5, 5), np.uint8))
    edge = np.clip(m - cv2.GaussianBlur(inner, (0, 0), 3.0), 0, 1)
    sub = fr.rgb[y0:y1, x0:x1]
    lum0 = sub.mean(2, keepdims=True)
    sheen = np.clip(lum0 - float(np.median(lum0[m > 0.5])) if (m > 0.5).any() else 0, 0, 1)
    img = warped * glow * (1 - bezel_shadow * edge[..., None]) + sheen * keep
    mm = m[..., None]
    fr.rgb[y0:y1, x0:x1] = sub * (1 - mm) + np.clip(img, 0, 1) * mm
    if text:
        tq = q
        if text_rect is not None:                    # only the readable part of the canvas (canvas px)
            rx0, ry0, rx1, ry1 = text_rect
            P_ = cv2.getPerspectiveTransform(src, q)
            pts = np.float32([[rx0, ry0], [rx1, ry0], [rx1, ry1], [rx0, ry1]])[:, None, :]
            tq = cv2.perspectiveTransform(pts, P_)[:, 0, :]
        fr.text_boxes.append((float(tq[:, 0].min()), float(tq[:, 1].min()), float(tq[:, 0].max()), float(tq[:, 1].max()), label))
