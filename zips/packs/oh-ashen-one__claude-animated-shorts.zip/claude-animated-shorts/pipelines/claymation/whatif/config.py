"""Project-wide constants and paths for the episode 2 (claymation) renderer."""
from pathlib import Path

EP_ROOT = Path(__file__).resolve().parents[2]          # .../ep02-data-center-ban
ASSETS = EP_ROOT / "assets"
WORK = EP_ROOT / "work"
OUT = EP_ROOT / "out"
FONTS = WORK / "fonts"
CACHE = WORK / "cache"                                  # per-key plates, depth, pose alignments

FPS = 24                    # container rate; the picture changes on 2s (12 exposures a second)
OUT_W, OUT_H = 1080, 1920
# Plates are fitted to the frame with this much spare on every side, so the stepped camera can
# nudge and push in without ever showing an edge (1.06 = 6 % larger than the frame).
PLATE_COVER = 1.06

# Vertical-video safe area for text (fractions of the frame)
SAFE_LEFT, SAFE_TOP = 0.06, 0.06
SAFE_RIGHT, SAFE_BOTTOM = 0.14, 0.22
MIN_CAP = 30                # minimum cap height (px at 1080 wide) for any text a viewer must read


def safe_box():
    """Pixel box (x0, y0, x1, y1) inside which readable text must stay."""
    return (round(OUT_W * SAFE_LEFT), round(OUT_H * SAFE_TOP),
            round(OUT_W * (1 - SAFE_RIGHT)), round(OUT_H * (1 - SAFE_BOTTOM)))


FONT_FILES = {
    "clay": "fredoka_Fredoka[wdth,wght].ttf",                 # SIL OFL 1.1 (variable)
    "body": "nunito_Nunito[wght].ttf",                        # SIL OFL 1.1 (variable)
    "type": "courierprime_CourierPrime-Bold.ttf",             # SIL OFL 1.1
    "type_reg": "courierprime_CourierPrime-Regular.ttf",      # SIL OFL 1.1
    "marker": "permanentmarker_PermanentMarker-Regular.ttf",  # Apache 2.0
}
