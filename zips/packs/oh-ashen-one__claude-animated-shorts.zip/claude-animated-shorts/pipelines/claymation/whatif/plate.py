"""Key images fitted to the frame, and their CPU depth estimates.

A key (941x1672 or 992x1586) is fitted to the PLATE: the output frame (1080x1920) enlarged by
PLATE_COVER (6 %) so the stepped camera can nudge without showing an edge. Fitting is uniform
scaling (never stretching): "cover" scales until both sides are covered and crops the rest at the
anchor you give; "contain" scales to fit inside and extends the short side by mirroring a blurred copy
of the edge (only for an image that must not be cropped).

Coordinates: shots measure points on the ORIGINAL key png (key px). `Fit.k2p` turns them into plate
px; the stage turns plate px into output px through the camera of each exposure.

Depth: Depth Anything V2 Small (ONNX Runtime, CPU provider), flip-averaged, on the fitted plate;
larger = nearer. Cached as 16-bit PNG in work/cache/.
"""
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from .config import CACHE, OUT_H, OUT_W, PLATE_COVER, WORK

PW, PH = int(round(OUT_W * PLATE_COVER)), int(round(OUT_H * PLATE_COVER))
DEPTH_MODEL = WORK / "models" / "da2s" / "onnx" / "model.onnx"


@dataclass(frozen=True)
class Fit:
    """How a key maps onto the plate: plate = key * s - (ox, oy)."""
    s: float
    ox: float
    oy: float
    src_w: int
    src_h: int

    def k2p(self, x, y=None):
        """Key px -> plate px. Accepts (x, y), a list of points or an (N, 2) array."""
        if y is not None:
            return (x * self.s - self.ox, y * self.s - self.oy)
        a = np.asarray(x, np.float32)
        return a * self.s - np.float32([self.ox, self.oy])

    def p2k(self, x, y):
        return ((x + self.ox) / self.s, (y + self.oy) / self.s)


def make_fit(src_w, src_h, anchor=(0.5, 0.5), mode="cover"):
    if mode == "cover":
        s = max(PW / src_w, PH / src_h)
    else:
        s = min(PW / src_w, PH / src_h)
    ox = (src_w * s - PW) * anchor[0]
    oy = (src_h * s - PH) * anchor[1]
    return Fit(float(s), float(ox), float(oy), int(src_w), int(src_h))


def _sig(*parts):
    return hashlib.sha1(json.dumps([str(p) for p in parts]).encode()).hexdigest()[:12]


def fit_image(path, fit, size_like=None):
    """The image at `path` fitted to the plate with `fit` (Lanczos), float32 RGB 0..1, cached.
    size_like=(w, h): first resize the source to the key's exact size (a pose painted 1 px off)."""
    path = Path(path)
    CACHE.mkdir(parents=True, exist_ok=True)
    out = CACHE / f"{path.stem}_plate_{_sig(fit, path.stat().st_mtime, size_like)}.png"
    if not out.exists():
        im = Image.open(path).convert("RGB")
        if size_like and im.size != tuple(size_like):
            im = im.resize(tuple(size_like), Image.LANCZOS)
        W, H = round(im.width * fit.s), round(im.height * fit.s)
        big = im.resize((W, H), Image.LANCZOS)
        a = np.asarray(big)
        ox, oy = int(round(fit.ox)), int(round(fit.oy))
        if ox >= 0 and oy >= 0 and ox + PW <= W and oy + PH <= H:
            a = a[oy:oy + PH, ox:ox + PW]
        else:                                           # contain: extend by mirrored, blurred edges
            canvas = cv2.copyMakeBorder(a, max(0, -oy), max(0, oy + PH - H), max(0, -ox), max(0, ox + PW - W),
                                        cv2.BORDER_REFLECT)
            blur = cv2.GaussianBlur(canvas, (0, 0), 18)
            m = np.zeros(canvas.shape[:2], np.float32)
            m[max(0, -oy):max(0, -oy) + H, max(0, -ox):max(0, -ox) + W] = 1
            m = cv2.GaussianBlur(m, (0, 0), 6)[..., None]
            canvas = (canvas * m + blur * (1 - m)).astype(np.uint8)
            y0, x0 = max(0, oy), max(0, ox)
            a = canvas[y0:y0 + PH, x0:x0 + PW]
        Image.fromarray(a).save(out, compress_level=3)
    return cv2.cvtColor(cv2.imread(str(out)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255


def depth_of(rgb, tag, long_side=1246):
    """Relative depth (0 far .. 1 near) of a plate image, float32 at plate size, cached by `tag`."""
    CACHE.mkdir(parents=True, exist_ok=True)
    out = CACHE / f"{tag}_depth.png"
    if out.exists():
        return cv2.imread(str(out), cv2.IMREAD_UNCHANGED).astype(np.float32) / 65535
    import onnxruntime as ort
    h, w = rgb.shape[:2]
    sh = long_side
    sw = int(round(w * sh / h / 14)) * 14
    x = cv2.resize(rgb, (sw, sh), interpolation=cv2.INTER_AREA).astype(np.float32)
    x = (x - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
    x = x.transpose(2, 0, 1)[None].astype(np.float32)
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 6
    sess = ort.InferenceSession(str(DEPTH_MODEL), opts, providers=["CPUExecutionProvider"])
    name = sess.get_inputs()[0].name
    d = np.squeeze(sess.run(None, {name: x})[0]).astype(np.float32)
    d2 = np.squeeze(sess.run(None, {name: x[..., ::-1].copy()})[0])[..., ::-1]
    d = cv2.resize(0.5 * (d + d2), (w, h), interpolation=cv2.INTER_CUBIC)
    d = (d - np.percentile(d, 0.5)) / (np.percentile(d, 99.5) - np.percentile(d, 0.5) + 1e-9)
    d = np.clip(d, 0, 1)
    cv2.imwrite(str(out), (d * 65535).astype(np.uint16))
    return d.astype(np.float32)


def key_fit(path, anchor=(0.5, 0.5), mode="cover"):
    w, h = Image.open(path).size
    return make_fit(w, h, anchor, mode)
