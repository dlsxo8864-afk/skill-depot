"""Word start times for the narration, measured from the audio's energy envelope.

Why: for this soft, whispery voice a speech-to-text aligner alone places words up to 0.9 s early
(episode 1). Here the transcriber (faster-whisper small, CPU) only supplies the word ORDER and a rough
prior; every word START is snapped to an energy onset found in the audio itself:

1. Envelope: RMS of the 80 Hz - 8 kHz band in 10 ms windows every 5 ms, in dB re the take's peak.
2. Onset candidates: each valley in the envelope followed by a rise of at least `min_rise` dB; the onset
   time is where the rise has covered 20 % of the way from the valley to the next peak (the attack
   becomes audible there). The first candidate is the speech onset after silence.
3. Assignment: a dynamic programme gives each script word one candidate, strictly in order, minimising
   (a) distance to the transcriber's time after removing its average bias, (b) a preference for deep
   valleys (word boundaries are usually deeper than syllable boundaries), and (c) implausible word
   durations for the word's syllable count.
4. A word's end is the last envelope point above the floor before the next word's onset.

`check_snippets` re-transcribes each measured word span on its own, as an independent check.
"""
import difflib
import re

import numpy as np
import soundfile as sf
from scipy import signal

HOP = 0.005
WIN = 0.010


def load(path):
    x, sr = sf.read(path, always_2d=True)
    return x.mean(1).astype(np.float64), sr


def envelope(x, sr, lo=80.0, hi=8000.0):
    """(times, dB re peak) of the band-limited RMS envelope."""
    hi = min(hi, sr * 0.45)
    sos = signal.butter(4, [lo, hi], btype="band", fs=sr, output="sos")
    y = signal.sosfiltfilt(sos, x)
    w, h = int(WIN * sr), int(HOP * sr)
    n = max(1, (len(y) - w) // h + 1)
    idx = np.arange(n)[:, None] * h + np.arange(w)[None]
    rms = np.sqrt((y[idx] ** 2).mean(1) + 1e-14)
    db = 20 * np.log10(rms / (rms.max() + 1e-12))
    db = np.convolve(db, np.ones(3) / 3, mode="same")
    t = (np.arange(n) * h + w / 2) / sr
    return t, db


def speech_bounds(t, db, floor=-45.0):
    on = np.where(db > floor)[0]
    return float(t[on[0]]), float(t[on[-1]])


def onset_candidates(t, db, floor=-45.0, min_rise=1.8, frac=0.2):
    """[(time, depth_db, rise_db)] for every valley -> peak rise of >= min_rise dB above the floor."""
    d = np.maximum(db, floor - 6)
    mins = signal.argrelextrema(d, np.less_equal, order=4)[0]
    peaks = signal.argrelextrema(d, np.greater_equal, order=4)[0]
    cands = []
    i_on = int(np.argmax(db > floor))
    # the very first onset: speech start after the leading silence
    nxt = peaks[peaks > i_on]
    if len(nxt):
        cands.append((float(t[i_on]), 40.0, float(d[nxt[0]] - floor)))
    for v in mins:
        if v <= i_on + 4:
            continue
        nxt = peaks[peaks > v]
        if not len(nxt):
            continue
        p = nxt[0]
        rise = d[p] - d[v]
        if rise < min_rise or d[p] < floor + 8:
            continue
        # the previous peak: how deep this valley is relative to what came before
        prv = peaks[peaks < v]
        depth = (d[prv[-1]] - d[v]) if len(prv) else rise
        lvl = d[v] + frac * rise
        k = v + int(np.argmax(d[v:p + 1] >= lvl))
        cands.append((float(t[k]), float(min(depth, rise)), float(rise)))
    # merge candidates closer than 40 ms (keep the deeper)
    out = []
    for c in sorted(cands):
        if out and c[0] - out[-1][0] < 0.04:
            if c[1] > out[-1][1]:
                out[-1] = c
            continue
        out.append(c)
    return out


_NUM_SYL = {"chatgpt's": 4, "chatgpt": 4, "ai": 2, "a.i.": 2, "gw": 3}


def syllables(word):
    w = re.sub(r"[^a-z.']", "", word.lower())
    if w in _NUM_SYL:
        return _NUM_SYL[w]
    w = w.replace(".", "")
    if not w:
        return 1
    if "-" in word:
        return sum(syllables(p) for p in word.split("-"))
    groups = re.findall(r"[aeiouy]+", w)
    n = len(groups)
    if w.endswith("e") and not w.endswith(("le", "ee")) and n > 1:
        n -= 1
    if w.endswith(("ed",)) and not w.endswith(("ted", "ded")) and n > 1:
        n -= 1
    return max(1, n)


def _norm(s):
    return "".join(ch for ch in s.lower() if ch.isalnum())


def prior_times(script_words, heard, on, off):
    """Transcriber time for every script word: heard words keep theirs, the rest are interpolated."""
    a = [_norm(w) for w in script_words]
    b = [_norm(h["w"]) for h in heard]
    sm = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    pr = [None] * len(a)
    for i, j, n in sm.get_matching_blocks():
        for k in range(n):
            pr[i + k] = heard[j + k]["s"]
    # interpolate gaps by letter count
    i = 0
    while i < len(a):
        if pr[i] is not None:
            i += 1
            continue
        j = i
        while j < len(a) and pr[j] is None:
            j += 1
        t0 = pr[i - 1] if i > 0 else on
        t1 = pr[j] if j < len(a) else off
        lens = np.array([max(len(x), 1) for x in a[max(i - 1, 0):j]], float)
        edges = t0 + np.cumsum(lens) / (lens.sum() + (1 if i == 0 else 0)) * (t1 - t0)
        for k in range(i, j):
            pr[k] = float(edges[k - i]) if i > 0 else float(t0 + (t1 - t0) * (k - i) / max(j - i, 1))
        i = j
    return pr


def assign(script_words, cands, prior, t, db, off, bias=0.0, floor=-45.0, votes=None):
    """DP: one candidate onset per word, strictly in order. Returns candidate indices.

    Costs per word i spanning [onset_j, next onset) (the last word spans to the end of speech):
      duration  the span's ACTIVE time (envelope above floor + 6 dB) against the word's syllables times
                the line's own syllable rate (total active time / total syllables)
      pause     a silent run of > 0.12 s inside the span costs heavily unless it is at the end of a word
                that ends a phrase (punctuation), where the take naturally pauses
      prior     weak pull toward the transcriber's time (after removing its average bias)
      boundary  a small reward for deep valleys (word boundaries)"""
    N, M = len(script_words), len(cands)
    ct = np.array([c[0] for c in cands] + [off + 0.01])
    depth = np.array([c[1] for c in cands])
    syl = np.array([syllables(w) for w in script_words], float)
    act = (db > floor + 6).astype(float)
    cum = np.concatenate([[0], np.cumsum(act)]) * HOP
    idx = lambda tt: int(np.clip(np.searchsorted(t, tt), 0, len(t)))
    rate = (cum[idx(off)] - cum[idx(ct[0])]) / syl.sum()
    phrase_end = [bool(re.search(r"[.,?!:;]$", w)) for w in script_words]
    # longest silent run inside [a, b) and whether it touches b
    sil = (db <= floor + 6)

    def span_cost(i, a, b):
        ia, ib = idx(a), idx(b)
        active = cum[ib] - cum[ia]
        exp = syl[i] * rate
        c = 2.0 * np.log(max(active, 0.03) / exp) ** 2
        if b - a < 0.06:
            c += 50
        seg = sil[ia:ib]
        if seg.any():
            # runs of silence
            d = np.diff(np.concatenate([[0], seg.astype(int), [0]]))
            st, en = np.where(d == 1)[0], np.where(d == -1)[0]
            for s0, e0 in zip(st, en):
                L = (e0 - s0) * HOP
                at_end = e0 >= len(seg) - 2
                if L > 0.12 and not at_end:           # a pause INSIDE a word: implausible when long
                    c += 1.0 + (0.0 if L < 0.22 else 6 + 40 * (L - 0.22))   # (spelled letters "G P T" gap)
                elif L > 0.12 and not phrase_end[i]:
                    c += 1.0 + 4 * (L - 0.12)         # a pause after an unpunctuated word: mild
        return c

    def unary(i, j):
        dt = ct[j] - (prior[i] + bias)
        hub = (dt / 0.25) ** 2 if abs(dt) < 0.5 else 4 + (abs(dt) - 0.5) / 0.125
        v = 0.0 if votes is None else vote_match(script_words, i, votes[j])
        if votes is not None and j > 0 and v > 0.5 and ct[j] - ct[j - 1] < 0.12 \
                and vote_match(script_words, i, votes[j - 1]) >= v - 0.05:
            v -= 0.3                                  # the same word heard from an earlier cut: start there
        return 0.12 * hub - 0.25 * min(depth[j], 20.0) / 6.0 - 10.0 * v

    INF = 1e18
    cost = np.full((N, M), INF)
    back = np.zeros((N, M), int)
    cost[0, 0] = unary(0, 0)                      # the first word starts at the speech onset
    for i in range(1, N):
        for j in range(i, M):
            best, arg = INF, 0
            for k in range(i - 1, j):
                if cost[i - 1, k] >= INF:
                    continue
                v = cost[i - 1, k] + span_cost(i - 1, ct[k], ct[j])
                if v < best:
                    best, arg = v, k
            if best < INF:
                cost[i, j] = best + unary(i, j)
                back[i, j] = arg
    final = np.array([cost[N - 1, j] + span_cost(N - 1, ct[j], off) if cost[N - 1, j] < INF else INF
                      for j in range(M)])
    j = int(np.argmin(final))
    path = [j]
    for i in range(N - 1, 0, -1):
        j = back[i, j]
        path.append(j)
    return path[::-1]


_ONES = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split()
_TENS = "_ _ twenty thirty forty fifty sixty seventy eighty ninety".split()


def num_words(n):
    """Spell an integer < 10**9 the way the narration says it."""
    if n < 20:
        return _ONES[n]
    if n < 100:
        return _TENS[n // 10] + ("" if n % 10 == 0 else " " + _ONES[n % 10])
    if n < 1000:
        return _ONES[n // 100] + " hundred" + ("" if n % 100 == 0 else " " + num_words(n % 100))
    for div, name in ((10 ** 6, "million"), (1000, "thousand")):
        if n >= div:
            return num_words(n // div) + " " + name + ("" if n % div == 0 else " " + num_words(n % div))
    return str(n)


def spoken(text):
    """Heard text with digits spelled out and punctuation dropped: '900 million' -> 'nine hundred million'."""
    def rep(m):
        v = m.group(0).replace(",", "")
        try:
            return " " + num_words(int(v)) + " "
        except ValueError:
            return " " + v + " "
    text = re.sub(r"\d[\d,]*", rep, text.replace("%", " percent"))
    return [_norm(w) for w in text.split() if _norm(w)]


def vote_match(script_words, i, heard_words):
    """0..1: how well the transcript of the audio cut at a candidate onset begins with script word i."""
    if not heard_words:
        return 0.0
    tgt = _norm(script_words[i])
    nxt = _norm(script_words[i + 1]) if i + 1 < len(script_words) else ""
    h0 = heard_words[0]
    h01 = "".join(heard_words[:2])
    r1 = difflib.SequenceMatcher(a=tgt, b=h0[:len(tgt) + 2]).ratio()
    r2 = difflib.SequenceMatcher(a=tgt + nxt, b=h01[:len(tgt + nxt) + 2]).ratio() if nxt else 0.0
    # long words must match their start; very short words are often swallowed, so count weaker
    r3 = difflib.SequenceMatcher(a=tgt, b=heard_words[1][:len(tgt) + 2]).ratio() * 0.75 \
        if len(heard_words) > 1 and len(h0) <= 4 and (i == 0 or difflib.SequenceMatcher(
            a=_norm(script_words[i - 1]), b=h0).ratio() < 0.6) else 0.0
    r = max(r1, 0.9 * r2, r3)
    return float(np.clip((r - 0.45) / 0.45, 0, 1)) * (0.6 if len(tgt) <= 2 else 1.0)


def prefix_votes(model, path, cands, pad=0.5):
    """For each candidate onset: the words heard when the take is cut there (transcribed from the
    onset to the end, `pad` s of silence before)."""
    from scipy.signal import resample_poly
    x, sr = load(path)
    a16 = resample_poly(x, 16000, sr).astype(np.float32) if sr != 16000 else x.astype(np.float32)
    out = []
    for c in cands:
        i0 = max(0, int((c[0] - 0.012) * 16000))
        seg = np.concatenate([np.zeros(int(pad * 16000), np.float32), a16[i0:]])
        segs, _ = model.transcribe(seg, language="en", beam_size=3, without_timestamps=True,
                                   condition_on_previous_text=False)
        out.append(spoken(" ".join(sg.text for sg in segs))[:4])
    return out


def measure_line(path, script, heard, model=None, votes=None):
    """Script words with measured times (seconds in the take): [{"w", "s", "e", "prior", "src"}], plus info."""
    x, sr = load(path)
    t, db = envelope(x, sr)
    on, off = speech_bounds(t, db)
    toks = script.split()
    cands = onset_candidates(t, db)
    prior = prior_times(toks, heard, on, off)
    if votes is None and model is not None:
        votes = prefix_votes(model, path, cands)
    sel = assign(toks, cands, prior, t, db, off, votes=votes)
    # re-estimate the transcriber's average bias from this assignment and run again
    bias = float(np.median([cands[j][0] - p for j, p in zip(sel, prior)]))
    bias = float(np.clip(bias, -0.15, 0.9))
    sel = assign(toks, cands, prior, t, db, off, bias=bias, votes=votes)
    starts = [cands[j][0] for j in sel]
    words = []
    for i, w in enumerate(toks):
        s = starts[i]
        nxt = starts[i + 1] if i + 1 < len(toks) else off + 0.01
        seg = (t >= s) & (t < nxt) & (db > -45)
        e = float(t[seg][-1]) if seg.any() else nxt - 0.02
        e = min(e + 0.02, nxt - 0.005) if i + 1 < len(toks) else min(e, off)
        words.append({"w": w, "s": round(s, 3), "e": round(max(e, s + 0.04), 3), "prior": round(prior[i], 3),
                      "src": "energy"})
    info = {"on": on, "off": off, "bias": bias, "n_cands": len(cands), "cands": [c[0] for c in cands],
            "votes": votes}
    return words, info


def transcribe(model, path, pad=1.0):
    """faster-whisper word list (seconds in the take), audio padded with `pad` s of silence."""
    from scipy.signal import resample_poly
    x, sr = load(path)
    a16 = resample_poly(x, 16000, sr).astype(np.float32) if sr != 16000 else x.astype(np.float32)
    a16 = np.concatenate([np.zeros(int(pad * 16000), np.float32), a16])
    segs, _ = model.transcribe(a16, word_timestamps=True, language="en", beam_size=5)
    out = []
    for s in segs:
        for w in s.words:
            tok = w.word.strip()
            if out and tok and not (tok[0].isalnum() or tok[0] in "$'"):
                out[-1]["w"] += tok
                out[-1]["e"] = round(w.end - pad, 3)
                continue
            out.append({"w": tok, "s": round(w.start - pad, 3), "e": round(w.end - pad, 3), "p": round(w.probability, 3)})
    return out


def check_snippets(model, path, words, pad=0.6):
    """Independent check: transcribe each measured word span [s_i, s_{i+1}) on its own.
    Returns [(script word, heard text)]."""
    from scipy.signal import resample_poly
    x, sr = load(path)
    a16 = resample_poly(x, 16000, sr).astype(np.float32)
    res = []
    for i, w in enumerate(words):
        s = w["s"]
        e = words[i + 1]["s"] if i + 1 < len(words) else w["e"] + 0.05
        seg = a16[int(s * 16000):int(e * 16000)]
        seg = np.concatenate([np.zeros(int(pad * 16000), np.float32), seg, np.zeros(int(pad * 16000), np.float32)])
        segs, _ = model.transcribe(seg, language="en", beam_size=5, without_timestamps=True,
                                   condition_on_previous_text=False)
        res.append((w["w"], " ".join(sg.text.strip() for sg in segs)))
    return res
