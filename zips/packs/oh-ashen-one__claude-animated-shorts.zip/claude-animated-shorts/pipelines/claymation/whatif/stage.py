"""The set: one exposure is built in PLATE space (the fitted key, a little larger than the frame), then
photographed by the stepped camera into the 1080x1920 output.

    st = Stage(ctx, plate_rgb, plate_depth, cam=StepCamera(ctx, zoom=Track(...), x=..., y=...))
    fr = st.frame(f)                 # Frame: rgb, depth (plate space) + bookkeeping, for exposure of f
    ... composite props into fr (props.place / props helpers) ...
    out_rgb, out_depth, boxes = st.shoot(fr)    # camera -> output space

Frame.rgb / Frame.depth are plate-space float32 arrays you may modify. Anything drawn into them moves
with the set when the camera nudges. Frame.text_boxes collects the plate-space boxes of readable text
(props helpers add them) so the renderer can check the safe area after the camera.
"""
import math
from dataclasses import dataclass, field

import cv2
import numpy as np

from . import clay
from .config import FPS, OUT_H, OUT_W
from .plate import PH, PW
from .timing import Track


@dataclass
class Frame:
    f: int                       # global frame asked for
    e: int                       # exposure (the frame whose photograph this is)
    t: float                     # shot-local seconds of the exposure
    rgb: np.ndarray              # plate-space colour (PH, PW, 3) float32
    depth: np.ndarray            # plate-space depth 0 far .. 1 near (PH, PW) float32
    clay: np.ndarray = None      # plate-space mask of hand-animated clay (boils), or None
    text_boxes: list = field(default_factory=list)     # [(x0, y0, x1, y1, label)] plate px
    light: tuple = (-0.55, -0.75)                      # key light direction in the image (toward the light)


class StepCamera:
    """A camera on a tripod, nudged by hand between exposures.

    Tracks are shot-local seconds -> value: zoom (1 = the frame shows the central 1080x1920 of the plate
    at 1:1), x / y (plate px the view centre moves by), roll (degrees). Each track is sampled once per
    exposure and the steps between exposures are made uneven (clay.nudged), so moves read as a series of
    small hand nudges, never a smooth dolly. Bumps from clay.bump_schedule add one-exposure knocks."""

    def __init__(self, ctx, zoom=None, x=None, y=None, roll=None, seed=None, bumps=True, bump_every=4.5,
                 bump_amp=1.6, unevenness=0.35):
        self.ctx = ctx
        seed = ctx.index * 101 + 7 if seed is None else seed
        self.ex = list(range(ctx.f0 - ctx.f0 % 2, ctx.f1 + 2, 2))
        ts = [max(e - ctx.f0, 0) / FPS for e in self.ex]
        self.vals = {}
        for k, tr, base in (("zoom", zoom, 1.0), ("x", x, 0.0), ("y", y, 0.0), ("roll", roll, 0.0)):
            v = [tr(t) if tr is not None else base for t in ts]
            self.vals[k] = clay.nudged(v, seed + len(k), unevenness) if tr is not None else np.asarray(v, float)
        self.bumps = clay.bump_schedule(ctx.f0, ctx.f1, seed, bump_every, bump_amp) if bumps else {}
        self.extra = {}

    def add_bump(self, f, dx, dy):
        """A knock for the exposure of frame f (e.g. a stamp slamming down)."""
        e = f - f % 2
        self.extra[e] = (self.extra.get(e, (0, 0))[0] + dx, self.extra.get(e, (0, 0))[1] + dy)

    def params(self, e):
        i = int(np.clip((e - self.ex[0]) // 2, 0, len(self.ex) - 1))
        z, x, y, r = (float(self.vals[k][i]) for k in ("zoom", "x", "y", "roll"))
        bx, by = self.bumps.get(e, (0.0, 0.0))
        ex, ey = self.extra.get(e, (0.0, 0.0))
        return z, x + bx + ex, y + by + ey, r

    def matrix(self, e):
        """2x3 affine plate px -> output px for exposure e (clamped so no plate edge shows)."""
        z, x, y, r = self.params(e)
        z = max(z, 1.0)
        a = math.radians(r)
        # half-size of the view in plate px, grown by the roll so the rotated corners stay inside
        hw = (OUT_W / 2 * abs(math.cos(a)) + OUT_H / 2 * abs(math.sin(a))) / z
        hh = (OUT_W / 2 * abs(math.sin(a)) + OUT_H / 2 * abs(math.cos(a))) / z
        cx = float(np.clip(PW / 2 + x, hw, PW - hw))
        cy = float(np.clip(PH / 2 + y, hh, PH - hh))
        ca, sa = math.cos(a) * z, math.sin(a) * z
        return np.float32([[ca, -sa, OUT_W / 2 - ca * cx + sa * cy],
                           [sa, ca, OUT_H / 2 - sa * cx - ca * cy]])

    def to_out(self, e, x, y):
        M = self.matrix(e)
        return (M[0, 0] * x + M[0, 1] * y + M[0, 2], M[1, 0] * x + M[1, 1] * y + M[1, 2])

    def to_plate(self, e, x, y):
        Mi = cv2.invertAffineTransform(self.matrix(e))
        return (Mi[0, 0] * x + Mi[0, 1] * y + Mi[0, 2], Mi[1, 0] * x + Mi[1, 1] * y + Mi[1, 2])


def out_to_plate_ref(x, y):
    """Output px -> plate px for the reference camera (zoom 1, centred): for laying out text."""
    return x + (PW - OUT_W) / 2, y + (PH - OUT_H) / 2


class Stage:
    def __init__(self, ctx, cam=None, light=(-0.55, -0.75), crawl_amp=0.55):
        self.ctx = ctx
        self.cam = cam or StepCamera(ctx)
        self.light = light
        self.crawl_amp = crawl_amp

    def frame(self, f, rgb, depth, clay_mask=None):
        e = clay.exposure(f, self.ctx.f0)
        fr = Frame(f=f, e=e, t=(e - self.ctx.f0) / FPS, rgb=rgb.copy(), depth=depth.copy(),
                   clay=clay_mask, light=self.light)
        return fr

    def boil(self, fr, mask=None, amp=None):
        """Apply clay crawl to fr.rgb inside mask (default fr.clay)."""
        m = fr.clay if mask is None else mask
        if m is not None:
            clay.crawl(fr.rgb, m, fr.e, seed=self.ctx.index * 13 + 3, amp=self.crawl_amp if amp is None else amp)
        return fr

    def shoot(self, fr):
        """Photograph the set: plate -> output via the camera. Returns (rgb, depth, text boxes in output px)."""
        M = self.cam.matrix(fr.e)
        rgb = cv2.warpAffine(fr.rgb, M, (OUT_W, OUT_H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
        dep = cv2.warpAffine(fr.depth, M, (OUT_W, OUT_H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        boxes = []
        for x0, y0, x1, y1, lab in fr.text_boxes:
            pts = np.float32([[x0, y0], [x1, y0], [x1, y1], [x0, y1]])
            q = pts @ M[:, :2].T + M[:, 2]
            boxes.append((float(q[:, 0].min()), float(q[:, 1].min()), float(q[:, 0].max()), float(q[:, 1].max()), lab))
        return np.clip(rgb, 0, 1), dep, boxes


def track(*keys):
    """Shorthand: track((0, 1.0), (2.5, 1.03, "inout"))."""
    return Track(list(keys))
