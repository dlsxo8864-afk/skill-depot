"""The photographic finish of every exposure: a miniature shot with a macro lens on a real camera.

finish(rgb, depth, e, ...) runs, in order:
  1. depth of field from the depth estimate: sharp at the focus depth, soft behind and in front (near
     things blur faster, as with a macro lens); gathered from a stack of blurred copies in which in-focus
     pixels barely contribute, so a sharp subject does not smear a halo into the background
  2. lamp flicker between exposures (clay.flicker), about +-1.2 % with a faint warm/cool shift
  3. a gentle lens vignette
  4. fine sensor grain that changes per exposure (luminance with a little chroma, stronger in shadows)
No bloom, no paint or canvas texture, no colour grade: the keys are already lit like the real thing.
"""
from functools import lru_cache

import cv2
import numpy as np

from . import clay
from .config import OUT_H, OUT_W

LEVELS = (0.0, 0.9, 1.9, 3.2, 5.0, 7.5)       # gaussian sigmas (output px) of the blur stack


@lru_cache(maxsize=2)
def _vignette(h, w, strength):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    r = np.sqrt(((x - w / 2) / (w * 0.58)) ** 2 + ((y - h * 0.5) / (h * 0.58)) ** 2)
    return np.clip(1 - strength * r ** 2.6, 0, 1)[..., None].astype(np.float32)


def coc_map(depth, focus, far=3.4, near=5.5, tol=0.05, span=0.45):
    """Blur sigma (output px) per pixel from relative depth (0 far .. 1 near) and the focus depth."""
    d = depth - focus
    far_c = far * np.clip((-d - tol) / span, 0, 1) ** 1.15
    near_c = near * np.clip((d - tol) / (span * 0.8), 0, 1) ** 1.15
    # a blurred foreground spills over what is behind it: grow and soften the near circle of confusion
    if near_c.max() > 0.3:
        k = int(max(3, near * 2.2)) | 1
        near_c = cv2.GaussianBlur(cv2.dilate(near_c, np.ones((k, k), np.uint8)), (0, 0), near * 0.8)
    far_c = cv2.GaussianBlur(far_c, (0, 0), 2.0)
    return np.maximum(far_c, near_c).astype(np.float32)


def depth_of_field(rgb, depth, focus, far=3.4, near=5.5, tol=0.05, span=0.45, scale=1.0):
    if scale <= 0:
        return rgb
    coc = coc_map(depth, focus, far * scale, near * scale, tol, span)
    if coc.max() < 0.35:
        return rgb
    w = np.clip(coc / 1.2, 0.08, 1.0)[..., None]           # in-focus pixels hardly feed the blur
    out = rgb.copy()
    prev = rgb
    prev_s = 0.0
    for s in LEVELS[1:]:
        if coc.max() <= prev_s:
            break
        num = cv2.GaussianBlur(rgb * w, (0, 0), s)
        den = cv2.GaussianBlur(w, (0, 0), s)
        if den.ndim == 2:
            den = den[..., None]
        plain = cv2.GaussianBlur(rgb, (0, 0), s)
        lvl = np.where(den > 0.05, num / np.maximum(den, 1e-4), plain)
        u = np.clip((coc - prev_s) / (s - prev_s), 0, 1)[..., None]
        sel = ((coc > prev_s) & (coc <= s))[..., None]
        out = np.where(sel, prev * (1 - u) + lvl * u, out)
        prev, prev_s = lvl, s
    out = np.where((coc > prev_s)[..., None], prev, out)
    return out.astype(np.float32)


def grain(e, h, w, amount=0.014):
    rng = np.random.default_rng(5000 + e)
    lum = rng.standard_normal((h, w)).astype(np.float32)
    lum = cv2.GaussianBlur(lum, (0, 0), 0.65)
    lum /= lum.std() + 1e-6
    ch = rng.standard_normal((h // 2, w // 2, 3)).astype(np.float32)
    ch = cv2.resize(cv2.GaussianBlur(ch, (0, 0), 0.8), (w, h), interpolation=cv2.INTER_LINEAR)
    return lum[..., None] * amount + ch * amount * 0.22


def finish(rgb, depth, e, focus=0.6, dof=None, flicker=0.012, vignette=0.17, grain_amount=0.013,
           seed=0, extra_gain=1.0):
    """The final pass for one exposure (output-space rgb float32 0..1, depth 0..1). dof: dict of
    depth_of_field kwargs (far, near, tol, span, scale) or False."""
    img = np.clip(rgb, 0, 1).astype(np.float32)
    if dof is not False:
        img = depth_of_field(img, depth, focus, **(dof or {}))
    g, tint = clay.flicker(e, seed, flicker)
    img = img * (g * extra_gain) * tint
    img = img * _vignette(OUT_H, OUT_W, vignette)
    lum = img.mean(2, keepdims=True)
    gr = grain(e, OUT_H, OUT_W, grain_amount)
    img = img + gr * (0.7 + 0.9 * (1 - lum) * np.clip(lum * 4, 0, 1))
    return np.clip(img, 0, 1)
