"""Screens in the paintings: find a blank screen, put an interface on it in perspective, and relight
the scene from what the screen shows.

    scr = ScreenQuad.detect(plane_rgb, lambda r, g, b: (g > .7) & (b > .62) & (r < .62))
    scr = ScreenQuad.from_points([(x, y) * 4 in key px], plane_rgb.shape, scale=WORK_SCALE)
    scr.place(rgb, a, canvas)                  # canvas: float32 HxWx3 interface, any size
    ratio = light_ratio(screen_light(canvas), scr.c0)
    rgb = relight(plate, unlit_plate, ratio)   # per-plane, every frame (see s02_year1)

All arrays are float32 RGB 0..1 at plate (working) resolution unless noted.
"""
import cv2
import numpy as np


# ------------------------------------------------------------------ screen geometry
def _order_quad(q):
    q = np.float32(q)
    c = q.mean(0)
    q = q[np.argsort(np.arctan2(q[:, 1] - c[1], q[:, 0] - c[0]))]
    return np.roll(q, -int(np.argmin(q.sum(1))), axis=0)          # TL, TR, BR, BL


class ScreenQuad:
    """A screen surface: soft mask, corner quad (TL, TR, BR, BL), its painted colour c0, bbox."""

    def __init__(self, mask, quad, c0, overscan=1.025):
        self.mask = mask.astype(np.float32)
        self.quad = _order_quad(quad)
        self.c0 = np.float32(c0)
        self.overscan = overscan
        ys, xs = np.where(self.mask > 0.01)
        H, W = mask.shape
        self.bbox = (max(xs.min() - 8, 0), max(ys.min() - 8, 0), min(xs.max() + 9, W), min(ys.max() + 9, H))

    # ---- construction
    @classmethod
    def detect(cls, plate_rgb, test, refine=True, dilate=9, overscan=1.025):
        """Largest blob where test(r, g, b) is true -> convex hull -> straight-edged quad.
        refine fits a line through each edge's straight middle part (rounded corners are ignored)."""
        r, g, b = plate_rgb[..., 0], plate_rgb[..., 1], plate_rgb[..., 2]
        m = test(r, g, b).astype(np.uint8)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
        if n < 2:
            raise ValueError("no screen pixels matched the colour test")
        i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        core = (lab == i).astype(np.uint8)
        cnt, _ = cv2.findContours(core, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        hull = cv2.convexHull(max(cnt, key=cv2.contourArea))
        full = np.zeros_like(core)
        cv2.fillConvexPoly(full, hull, 1)
        pts = hull[:, 0, :].astype(np.float32)
        cnt, _ = cv2.findContours(full, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        pts = max(cnt, key=cv2.contourArea)[:, 0, :].astype(np.float32)
        peri = cv2.arcLength(pts[:, None, :], True)
        quad = None
        for eps in np.linspace(0.01, 0.12, 40):
            ap = cv2.approxPolyDP(pts[:, None, :], eps * peri, True)
            if len(ap) == 4:
                quad = ap[:, 0, :].astype(np.float32)
                break
        if quad is None:
            quad = cv2.boxPoints(cv2.minAreaRect(pts))
        quad = _order_quad(quad)
        if refine:
            quad = _refine_edges(pts, quad)
        soft = cv2.dilate(full.astype(np.float32), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dilate, dilate)))
        soft = cv2.GaussianBlur(soft, (0, 0), 1.0)
        c0 = plate_rgb[core > 0].mean(0)
        return cls(soft, quad, c0, overscan)

    @classmethod
    def from_points(cls, quad_key_px, plate_shape, scale=1.0, c0=(0.5, 0.5, 0.5), radius=0, overscan=1.0,
                    plate_rgb=None):
        """Screen from four hand-measured corners (key px, TL TR BR BL); radius rounds the corners.
        If plate_rgb is given, c0 is read from the painted screen."""
        q = _order_quad(np.float32(quad_key_px) * scale)
        H, W = plate_shape[:2]
        m = np.zeros((H, W), np.uint8)
        cv2.fillConvexPoly(m, np.round(q).astype(np.int32), 1, cv2.LINE_AA)
        if radius:
            k = 2 * int(radius) + 1
            m = cv2.morphologyEx(m, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        soft = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 0.8)
        if plate_rgb is not None:
            c0 = plate_rgb[m > 0].mean(0)
        return cls(soft, q, c0, overscan)

    # ---- placement
    def homography(self, cw, ch):
        """Canvas (cw x ch) -> plate coordinates, overscanned past the painted edge."""
        cq = self.quad.mean(0)
        big = cq + (self.quad - cq) * self.overscan
        return cv2.getPerspectiveTransform(np.float32([[0, 0], [cw, 0], [cw, ch], [0, ch]]), big)

    def warp(self, canvas):
        """Interface canvas warped onto the screen; returns (patch, x0, y0) covering self.bbox."""
        x0, y0, x1, y1 = self.bbox
        ch, cw = canvas.shape[:2]
        Tm = np.float32([[1, 0, -x0], [0, 1, -y0], [0, 0, 1]]) @ self.homography(cw, ch)
        return cv2.warpPerspective(canvas.astype(np.float32), Tm, (x1 - x0, y1 - y0), flags=cv2.INTER_AREA), x0, y0

    def place(self, rgb, a, canvas, glass=0.20, opacity=1.0):
        """Composite an interface onto the screen in place (rgb, and alpha a if given).
        glass darkens a soft inner rim so the image sits inside the bezel (0 = off)."""
        patch, x0, y0 = self.warp(canvas)
        x1, y1 = x0 + patch.shape[1], y0 + patch.shape[0]
        m = self.mask[y0:y1, x0:x1, None] * opacity
        if glass:
            edge = cv2.GaussianBlur(cv2.erode(m[..., 0], np.ones((9, 9), np.uint8)), (0, 0), 4)[..., None]
            patch = patch * (1 - glass + glass * edge)
        rgb[y0:y1, x0:x1] = rgb[y0:y1, x0:x1] * (1 - m) + patch * m
        if a is not None:
            a[y0:y1, x0:x1] = np.maximum(a[y0:y1, x0:x1], m[..., 0])

    def point(self, u, v):
        """Plate position of canvas fraction (u, v) on the screen (e.g. to spring a card out of it)."""
        q = self.quad
        top = q[0] + (q[1] - q[0]) * u
        bot = q[3] + (q[2] - q[3]) * u
        return top + (bot - top) * v


def _refine_edges(pts, quad):
    lines = []
    for j in range(4):
        a, b2 = quad[j], quad[(j + 1) % 4]
        d = b2 - a
        ln = np.linalg.norm(d)
        u = ((pts - a) @ d) / (ln * ln)
        e = d / ln
        dist = np.abs(e[0] * (pts[:, 1] - a[1]) - e[1] * (pts[:, 0] - a[0]))
        sel = pts[(u > 0.2) & (u < 0.8) & (dist < 12)]
        if len(sel) < 5:
            return quad
        vx, vy, x0, y0 = cv2.fitLine(sel, cv2.DIST_HUBER, 0, 0.01, 0.01).ravel()
        lines.append((np.array([x0, y0]), np.array([vx, vy])))
    q = []
    for j in range(4):
        (p1, d1), (p2, d2) = lines[j - 1], lines[j]
        s = np.linalg.solve(np.array([d1, -d2]).T, p2 - p1)
        q.append(p1 + d1 * s[0])
    return np.float32(q)


def dead_glass(cw, ch, tint=(0.035, 0.03, 0.06), sheen=0.05):
    """A switched-off screen: near-black blue glass with one faint diagonal reflection band."""
    yy = np.linspace(0, 1, ch, dtype=np.float32)[:, None, None]
    xx = np.linspace(0, 1, cw, dtype=np.float32)[None, :, None]
    band = np.clip(1 - np.abs((xx * 0.8 + yy * 0.5) - 0.45) * 5, 0, 1) * sheen
    return np.float32(tint) + band * np.float32([0.6, 0.4, 0.9]) + 0 * xx * yy


# ------------------------------------------------------------------ screen light
def screen_light(canvas):
    """The colour a screen throws on faces/hands: mean of its content, centre-weighted."""
    h, w = canvas.shape[:2]
    return canvas[int(h * 0.15):int(h * 0.85), int(w * 0.1):int(w * 0.9)].reshape(-1, 3).mean(0)


def light_weight(rgb, hue="teal", blur=3):
    """0..1: how much of each pixel's colour comes from a coloured light (the screen's spill).
    hue: "teal" (cyan screens), "magenta", "warm" (orange/amber), or an RGB triple (cosine match)."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    if hue == "teal":
        w = np.clip((np.minimum(g, b) - r + 0.02) / 0.22, 0, 1)
    elif hue == "magenta":
        w = np.clip((np.minimum(r, b) - g + 0.02) / 0.22, 0, 1)
    elif hue == "warm":
        w = np.clip((r - b - 0.05) / 0.25, 0, 1) * np.clip((g - b + 0.05) / 0.2, 0, 1)
    else:
        c = np.float32(hue) / (np.linalg.norm(hue) + 1e-6)
        n = rgb / (np.linalg.norm(rgb, axis=2, keepdims=True) + 1e-6)
        w = np.clip(((n @ c) - 0.85) / 0.13, 0, 1)
    w = w * np.clip((rgb.max(2) - 0.08) / 0.25, 0, 1)
    return cv2.GaussianBlur(w.astype(np.float32), (0, 0), blur) if blur else w.astype(np.float32)


def unlit(rgb, tint=(0.52, 0.36, 0.78), level=0.62):
    """The same surface with the screen's light removed: its value in deep violet."""
    lum = rgb @ np.float32([0.30, 0.50, 0.20])
    return lum[..., None] * np.float32(tint) * level


def unlit_plate(rgb, weight, **kw):
    """Plate with the lit share (weight 0..1) replaced by unlit(); precompute once per plane."""
    w = weight[..., None]
    return rgb * (1 - w) + unlit(rgb, **kw) * w


def light_ratio(c, c0, strength=0.75, lo=0.2, hi=2.2):
    """Per-channel gain from the painted screen colour c0 to the current screen colour c, with an
    overall brightness term so a dark interface dims the face. Pass zeros for a dead screen."""
    c = np.float32(c)
    ratio = np.clip(1 + strength * (c / np.maximum(c0, 1e-3) - 1), lo, hi).astype(np.float32)
    bright = float(np.clip(c.mean() / max(float(np.mean(c0)), 1e-3), 0.5, 1.2))
    return ratio * (0.6 + 0.4 * bright)


def relight(rgb, unlit_rgb, ratio):
    """Scene lit by the screen at `ratio` (light_ratio): unlit + (painted - unlit) * ratio."""
    return unlit_rgb + (rgb - unlit_rgb) * np.asarray(ratio, np.float32)
