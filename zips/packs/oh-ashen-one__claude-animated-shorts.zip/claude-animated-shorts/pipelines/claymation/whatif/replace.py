"""Replacement animation: held poses swapped between exposures, as a stop-motion animator swaps
sculpted heads and bodies.

Each shot has a key (pose "A") and painted variants `<key stem>_poseB.png` (and `_poseC.png`).

mode="region"  (pose keeps the key's framing; most shots)
    Each variant is aligned to the key (ECC homography on the background), and only the CHARACTER
    REGION is taken from it: a soft mask of where the paintings really differ, limited to your `region`
    polygon(s) (key px). The variant is colour-matched to the key in a ring around the mask, so nothing
    outside the character pops. Every change X -> Y is played as
        anticipation  "ant" + X + Y  one exposure: the outgoing pose leans and squashes a little AWAY
                                     from the coming move (pose X mesh-warped against the motion)
        in-between    X + Y          one exposure: the incoming pose drawn halfway back along the
                                     measured motion (a mesh warp, never a cross-fade)
        hold          Y              from the switch frame on
    You can turn either off per switch (see `state`).

mode="full"    (the variant reframes the scene: the hook and the reservoir shot)
    The variant is fitted to the frame like the key and replaces the whole picture on the beat, as a
    cut inside the shot. `state` returns the new pose from the switch frame; give the camera a bump
    there (st.cam.add_bump) so it lands like a re-set between takes.

    rep = Replacement(ctx, fit, region=[[(x, y), ...]], mode="region")       # None-safe: rep.poses
    st  = rep.state(f, [(ctx.f("dead"), "B"), (ctx.f("again"), "A")])      # "A", "antAB", "AB", "B", ...
    rgb, depth = rep.image(st)                                               # plate-space float32
    clay_mask = rep.clay_mask()                                              # where the clay boils

Caches: work/cache/<stem>_rep_<pair>.npz (rebuilt when a painting, the fit or the region changes).
Build happens in the parent process before workers start (call rep.prepare(switches)).
"""
import hashlib
import json
from pathlib import Path

import cv2
import numpy as np

from .config import CACHE
from .plate import PH, PW, depth_of, fit_image


def pose_path(key_path, name):
    key_path = Path(key_path)
    stem = key_path.stem[:-4] if key_path.stem.endswith("_key") else key_path.stem
    return key_path.with_name(f"{stem}_pose{name}.png")


def _gray(x):
    return cv2.cvtColor((np.clip(x, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255


def _ecc(a, b, mask=None, scale=0.25, warp=None):
    sa = cv2.GaussianBlur(cv2.resize(_gray(a), None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA), (0, 0), 1.2)
    sb = cv2.GaussianBlur(cv2.resize(_gray(b), None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA), (0, 0), 1.2)
    m = None if mask is None else (cv2.resize(mask, (sa.shape[1], sa.shape[0])) > 0.5).astype(np.uint8)
    S = np.diag([scale, scale, 1.0]).astype(np.float32)
    w0 = np.eye(3, dtype=np.float32) if warp is None else (S @ warp @ np.linalg.inv(S)).astype(np.float32)
    crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6)
    try:
        _, w = cv2.findTransformECC(sa, sb, w0, cv2.MOTION_HOMOGRAPHY, crit, m, 5)
    except cv2.error:
        return np.eye(3, dtype=np.float32) if warp is None else warp
    return (np.linalg.inv(S) @ w @ S).astype(np.float32)


def _diff(a, b):
    la = cv2.cvtColor(a.astype(np.float32), cv2.COLOR_RGB2LAB)
    lb = cv2.cvtColor(b.astype(np.float32), cv2.COLOR_RGB2LAB)
    d = np.sqrt((((la - lb) * np.float32([1.0, 0.6, 0.6])) ** 2).sum(2))
    return cv2.GaussianBlur(d, (0, 0), 6)


def _flow(src, dst, s=0.5):
    g0 = cv2.resize(_gray(src), None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    g1 = cv2.resize(_gray(dst), None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    f = cv2.calcOpticalFlowFarneback((g0 * 255).astype(np.uint8), (g1 * 255).astype(np.uint8), None,
                                     0.5, 7, 45, 6, 7, 1.5, cv2.OPTFLOW_FARNEBACK_GAUSSIAN)
    return cv2.resize(f, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_LINEAR) / s


def _smooth_flow(fl, mask, sigma=16.0):
    w = np.clip(mask, 0.05, 1).astype(np.float32)
    out = np.empty_like(fl)
    for c in range(2):
        out[..., c] = cv2.GaussianBlur(fl[..., c] * w, (0, 0), sigma) / (cv2.GaussianBlur(w, (0, 0), sigma) + 1e-6)
    return out


def _sample(img, fl, k):
    H, W = img.shape[:2]
    gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    return cv2.remap(img, gx + k * fl[..., 0], gy + k * fl[..., 1], cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def _squash(img, mask, amount):
    ys = np.nonzero((mask > 0.5).any(1))[0]
    if not len(ys) or amount == 0:
        return img
    base = float(ys.max())
    H, W = img.shape[:2]
    gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    sy = base + (gy - base) / (1 - amount)
    return cv2.remap(img, gx, sy.astype(np.float32), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def _q(x):
    return (np.clip(x, 0, 1) * 255 + 0.5).astype(np.uint8)


class Replacement:
    def __init__(self, ctx, fit, region=None, mode="region", poses=None, grow=20, feather=8, min_area=0.003,
                 thresh=None, anticipation=0.15, squash=0.03, tag=None):
        self.ctx, self.fit, self.mode = ctx, fit, mode
        self.tag = tag or ctx.stem
        self.grow, self.feather, self.min_area, self.thresh = grow, feather, min_area, thresh
        self.ant_k, self.squash = anticipation, squash
        self.region_px = region
        names = poses or [n for n in "BCD" if pose_path(ctx.key, n).exists()]
        self.paths = {"A": Path(ctx.key), **{n: pose_path(ctx.key, n) for n in names if pose_path(ctx.key, n).exists()}}
        self.poses = list(self.paths)
        self._img = {}
        self._pair = {}
        self.a = fit_image(ctx.key, fit)
        self.a_depth = depth_of(self.a, f"{self.tag}_A")
        self._img["A"] = (self.a, self.a_depth, np.zeros((PH, PW), np.float32))
        self.reg = None
        if region:
            polys = region if isinstance(region[0][0], (list, tuple)) else [region]
            self.reg = np.zeros((PH, PW), np.float32)
            cv2.fillPoly(self.reg, [np.round(fit.k2p(p)).astype(np.int32) for p in polys], 1.0)

    # ---------------------------------------------------------------- per-pose images
    def _sig(self, *extra):
        parts = [str(self.fit), self.mode, self.region_px, self.grow, self.feather, self.min_area, self.thresh,
                 self.ant_k, self.squash, 3] + [str(p) + str(p.stat().st_mtime) for p in self.paths.values()] + list(extra)
        return hashlib.sha1(json.dumps(parts, default=str).encode()).hexdigest()[:12]

    def pose(self, name):
        """(rgb, depth, mask) of a held pose in plate space; mask = where it differs from the key."""
        if name in self._img:
            return self._img[name]
        CACHE.mkdir(parents=True, exist_ok=True)
        cache = CACHE / f"{self.tag}_pose{name}_{self._sig(name)}.npz"
        if cache.exists():
            z = np.load(cache)
            out = (z["rgb"].astype(np.float32) / 255, z["d"].astype(np.float32) / 65535, z["m"].astype(np.float32) / 255)
            self._img[name] = out
            return out
        src = Image_size(self.paths["A"])
        b = fit_image(self.paths[name], self.fit, size_like=src)
        if self.mode == "full":
            d = depth_of(b, f"{self.tag}_{name}")
            m = np.ones((PH, PW), np.float32)
            out = (b, d, m)
        else:
            out = self._build_region(b, name)
        np.savez_compressed(cache, rgb=_q(out[0]), d=(np.clip(out[1], 0, 1) * 65535).astype(np.uint16), m=_q(out[2]))
        self._img[name] = out
        return out

    def _build_region(self, b, name):
        a = self.a
        reg = self.reg
        w = _ecc(a, b)
        bw = cv2.warpPerspective(b, w, (PW, PH), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
        d0 = _diff(a, bw)
        bg = (d0 < np.quantile(d0, 0.7)).astype(np.float32)
        if reg is not None:
            bg *= 1 - cv2.dilate(reg, np.ones((41, 41), np.uint8))
        w = _ecc(a, b, mask=bg, warp=w)
        bw = cv2.warpPerspective(b, w, (PW, PH), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
        diff = _diff(a, bw)
        thresh = self.thresh
        if thresh is None:
            out_reg = diff if reg is None or not (reg < 0.5).any() else diff[reg < 0.5]
            thresh = float(max(np.median(out_reg) * 3.2, 6.0))
        m = (diff > thresh).astype(np.uint8)
        if reg is not None:
            m &= (reg > 0.5).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)))
        n, lab, stt, _ = cv2.connectedComponentsWithStats(m, 8)
        keep = np.zeros_like(m)
        for i in range(1, n):
            if stt[i, cv2.CC_STAT_AREA] >= self.min_area * PW * PH:
                keep[lab == i] = 1
        ff = keep.copy()
        cv2.floodFill(ff, np.zeros((PH + 2, PW + 2), np.uint8), (0, 0), 1)
        keep = keep | (1 - ff)
        g = self.grow
        keep = cv2.dilate(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * g + 1, 2 * g + 1)))
        if reg is not None:
            keep &= (cv2.dilate(reg, np.ones((2 * g + 1, 2 * g + 1), np.uint8)) > 0.5).astype(np.uint8)
        soft = cv2.GaussianBlur(keep.astype(np.float32), (0, 0), self.feather)
        soft = np.clip(soft * 1.6 - 0.3, 0, 1)
        ring = (cv2.dilate(keep, np.ones((61, 61), np.uint8)) - keep).astype(bool)
        if ring.sum() > 500:
            ma, sa_ = a[ring].mean(0), a[ring].std(0) + 1e-3
            mb, sb_ = bw[ring].mean(0), bw[ring].std(0) + 1e-3
            gn = np.clip(sa_ / sb_, 0.85, 1.18)
            corr = np.clip((bw - mb) * gn + ma, 0, 1)
            bw = bw * 0.35 + corr * 0.65            # partial: keep the painting's own light, remove the offset
        mm = soft[..., None]
        full = a * (1 - mm) + bw * mm
        db = depth_of(np.ascontiguousarray(full), f"{self.tag}_{name}_aligned")
        d = self.a_depth * (1 - soft) + db * soft
        return full.astype(np.float32), d.astype(np.float32), soft.astype(np.float32)

    # ---------------------------------------------------------------- transitions
    def pair(self, x, y):
        """(anticipation, in-between) drawings for the change x -> y (region mode)."""
        if (x, y) in self._pair:
            return self._pair[(x, y)]
        cache = CACHE / f"{self.tag}_rep_{x}{y}_{self._sig(x, y)}.npz"
        if cache.exists():
            z = np.load(cache)
            out = (z["ant"].astype(np.float32) / 255, z["inb"].astype(np.float32) / 255, z["m"].astype(np.float32) / 255)
            self._pair[(x, y)] = out
            return out
        X, _, mx = self.pose(x)
        Y, _, my = self.pose(y)
        m = np.maximum(mx, my)
        fl = _smooth_flow(_flow(X, Y), m)          # X points -> Y points
        inb = _sample(Y, fl, 0.5)                  # Y drawn halfway back toward X
        ant = _squash(_sample(X, fl, self.ant_k), m, self.squash)   # X leaning away from the move
        mm = m[..., None]
        base = self.a
        inb = base * (1 - mm) + inb * mm
        ant = base * (1 - mm) + ant * mm
        np.savez_compressed(cache, ant=_q(ant), inb=_q(inb), m=_q(m))
        out = (ant.astype(np.float32), inb.astype(np.float32), m.astype(np.float32))
        self._pair[(x, y)] = out
        return out

    def prepare(self, switches, start="A"):
        """Build every pose and transition the switch list needs (call in __init__ of the shot)."""
        cur = start
        for _, to, *opt in sorted(switches, key=lambda s: s[0]):
            self.pose(to)
            if self.mode == "region" and to != cur:
                self.pair(cur, to)
            cur = to

    # ---------------------------------------------------------------- animation
    def state(self, f, switches, start="A"):
        """Pose state at global frame f. switches: [(frame, pose)] or [(frame, pose, opts)] with opts a
        dict {"ant": bool, "inb": bool} (both default True in region mode). Switch frames snap to the 2s
        grid; anticipation and in-between take the two exposures BEFORE the switch."""
        cur = start
        for sw in sorted(switches, key=lambda s: s[0]):
            fs, to = int(sw[0]) - int(sw[0]) % 2, sw[1]
            opts = sw[2] if len(sw) > 2 else {}
            if f >= fs:
                cur = to
                continue
            if self.mode == "full" or to == cur:
                break
            use_inb, use_ant = opts.get("inb", True), opts.get("ant", True)
            if use_inb and f >= fs - 2:
                return cur + to
            if use_ant and f >= fs - 2 - (2 if use_inb else 0):
                return "ant" + cur + to
            break
        return cur

    def image(self, st):
        """(rgb, depth) plate-space for a state from `state` (copies are made by the stage)."""
        if st in self.paths:
            rgb, d, _ = self.pose(st)
            return rgb, d
        if st.startswith("ant"):
            x, y = st[3], st[4]
            ant, _, _ = self.pair(x, y)
            return ant, self.pose(x)[1]
        x, y = st[0], st[1]
        _, inb, _ = self.pair(x, y)
        return inb, self.pose(y)[1]

    def clay_mask(self, extra=None):
        """Where the clay characters are (union of every variant's mask, softened), for the boil."""
        if self.mode == "full":
            return extra
        m = np.zeros((PH, PW), np.float32)
        for n in self.poses:
            if n != "A":
                m = np.maximum(m, self.pose(n)[2])
        if extra is not None:
            m = np.maximum(m, extra)
        return cv2.GaussianBlur(m, (0, 0), 6)

    def debug_sheet(self, path, x="A", y="B"):
        """Row of thumbnails: X | Y | anticipation | in-between | mask over X."""
        X, Y = self.pose(x)[0], self.pose(y)[0]
        ant, inb, m = self.pair(x, y) if self.mode == "region" else (X, Y, np.ones((PH, PW), np.float32))
        ov = X * 0.55 + np.float32([1, 0.3, 0.1]) * m[..., None] * 0.45
        row = np.hstack([cv2.resize(v, (360, 640), interpolation=cv2.INTER_AREA) for v in (X, Y, ant, inb, ov)])
        cv2.imwrite(str(path), cv2.cvtColor(_q(row), cv2.COLOR_RGB2BGR))


def Image_size(path):
    from PIL import Image
    return Image.open(path).size
