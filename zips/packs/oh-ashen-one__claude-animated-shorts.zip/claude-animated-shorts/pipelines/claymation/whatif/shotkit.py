"""The contract between the episode renderer (src/ep02.py) and one shot module (src/shots/<stem>.py).

A shot module exposes `make(ctx) -> shot`. The shot object needs
    frame(f) -> stage.Frame          the set for the exposure of GLOBAL frame f (ctx.f0 <= f < ctx.f1),
                                     in plate space; the renderer photographs and finishes it
and may add
    events() -> [(f, kind, info)]    picture events, printed in the sync table and used for the sheet
    sound(snd)                       place beds and effects with the ShotSound `snd`
    focus_for(f) -> depth            lens focus depth for an exposure (default: self.focus)
    finish_args(f) -> dict           extra kwargs for look.finish (dof, flicker, vignette, grain_amount)

The renderer renders each EXPOSURE once (even frames, plus the shot's first frame if it is odd) and
shows it for both of its frames: the whole picture changes 12 times a second.

BaseShot (recommended) wires the common parts:
    self.setup(anchor=(0.5, 0.5), region=..., mode="region", zoom=..., x=..., y=..., roll=...)
    fr = self.base(f, switches)      the pose for f with the clay boil applied -> Frame
    self.draw_year(fr, f)            the YEAR sign, lowered in on its threads two frames after the cut
    self.draw_card(fr, f, prop, f_in, f_out, xy)    a data card hanging (or on a stick) at output xy
    self.kp(x, y)                    key px -> plate px
    self.op(x, y)                    output px (reference camera) -> plate px
"""
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from . import audio as A
from . import props as P
from .config import FPS, OUT_H, OUT_W, safe_box
from .plate import PH, PW, key_fit
from .stage import Stage, StepCamera, out_to_plate_ref
from .timing import even_frame_of, frame_of


def _key(w):
    return w.strip(",.?!;:")


YEAR_DROP_ROOM = 34       # the YEAR sign rests this far below the safe top so its drop-in stays inside it


@dataclass
class ShotContext:
    """Everything a shot needs to know about its place in the episode. Times are GLOBAL seconds,
    frames are GLOBAL frame numbers (frame 0 = first frame of the episode)."""
    stem: str
    index: int
    f0: int
    f1: int
    key: Path
    wav: Path
    year: int | None
    words: list = field(default_factory=list)   # [{"w", "s", "e"}], script spelling, global s/e (measured)
    speech_on: float = 0.0
    speech_off: float = 0.0
    vo_at: float = 0.0
    is_last: bool = False

    @property
    def n(self):
        return self.f1 - self.f0

    @property
    def dur(self):
        return self.n / FPS

    def word(self, w, n=0):
        """n-th word matching w (exact spelling first, then case-insensitive; punctuation ignored)."""
        exact = [x for x in self.words if _key(x["w"]) == _key(w)]
        loose = [x for x in self.words if _key(x["w"]).lower() == _key(w).lower()]
        hits = exact if len(exact) > n else loose
        if len(hits) <= n:
            raise KeyError(f"{w!r} not in {self.stem}: {' '.join(x['w'] for x in self.words)}")
        return hits[n]

    def t(self, w, n=0, at="s"):
        return self.word(w, n)[at]

    def f(self, w, n=0, at="s", even=True):
        """Frame of a word's start (at="e": end). even=True snaps to the 2s grid (anything that moves)."""
        t = self.t(w, n, at)
        return even_frame_of(t) if even else frame_of(t)

    def local(self, f):
        return (f - self.f0) / FPS


class BaseShot:
    focus = 0.62            # lens focus depth (0 far .. 1 near); set from a point with self.focus_at
    dof = None              # look.depth_of_field kwargs, or False
    light = (-0.55, -0.75)  # key light direction in the picture (toward the light): upper left by default
    year_xy = None          # output px of the YEAR sign's top-left (default: the safe area's top-left)

    def __init__(self, ctx: ShotContext):
        self.ctx = ctx
        self.f0, self.f1 = ctx.f0, ctx.f1
        self.rep = None
        self._ev = []

    # ---------------------------------------------------------------- set-up
    def setup(self, anchor=(0.5, 0.5), region=None, mode="region", zoom=None, x=None, y=None, roll=None,
              switches=(), bumps=True, crawl_amp=0.55, clay_extra=None, **rep_kw):
        """Fit the key, build the replacement poses for `switches`, and the stepped camera."""
        from .replace import Replacement
        self.fit = key_fit(self.ctx.key, anchor)
        self.rep = Replacement(self.ctx, self.fit, region=region, mode=mode, **rep_kw)
        self.switches = list(switches)
        self.rep.prepare(self.switches)
        self.clay = self.rep.clay_mask(clay_extra)
        self.cam = StepCamera(self.ctx, zoom=zoom, x=x, y=y, roll=roll, bumps=bumps)
        self.stage = Stage(self.ctx, self.cam, light=self.light, crawl_amp=crawl_amp)

    def kp(self, x, y=None):
        """Key px -> plate px (accepts a point, a list of points or an array)."""
        return self.fit.k2p(x, y)

    def op(self, x, y):
        """Output px (reference camera: no zoom, centred) -> plate px."""
        return out_to_plate_ref(x, y)

    def focus_at(self, x, y, pose="A"):
        """Depth at key px (x, y) of a pose, for `focus`."""
        px, py = self.kp(x, y)
        d = self.rep.pose(pose)[1]
        return float(np.median(d[int(py) - 6:int(py) + 7, int(px) - 6:int(px) + 7]))

    def state(self, f):
        return self.rep.state(f, self.switches) if self.switches else "A"

    def base(self, f, st=None, boil=True):
        """Frame for f: the pose image of the current state, with the clay boil."""
        st = self.state(f) if st is None else st
        rgb, d = self.rep.image(st)
        fr = self.stage.frame(f, rgb, d, self.clay)
        if boil:
            self.stage.boil(fr)
        fr.pose = st
        return fr

    # ---------------------------------------------------------------- safe area
    def safe_plate_box(self, inset=4):
        """The safe text box (output) mapped into plate px so it holds for EVERY exposure of the shot's
        camera (the tightest box), inset a little."""
        x0, y0, x1, y1 = safe_box()
        bx0, by0, bx1, by1 = -1e9, -1e9, 1e9, 1e9
        for e in self.cam.ex:
            if not (self.f0 - 2 <= e < self.f1):
                continue
            pts = [self.cam.to_plate(e, x, y) for x, y in ((x0, y0), (x1, y0), (x1, y1), (x0, y1))]
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
            bx0, by0 = max(bx0, sorted(xs)[1]), max(by0, sorted(ys)[1])
            bx1, by1 = min(bx1, sorted(xs)[2]), min(by1, sorted(ys)[2])
        return bx0 + inset, by0 + inset, bx1 - inset, by1 - inset

    # ---------------------------------------------------------------- series props
    def year_land(self):
        return self.f0 + 2 - (self.f0 % 2)

    def draw_year(self, fr, f, f_in=None, depth=None, knocks=()):
        """The YEAR sign, hanging on two threads in the top-left of the safe area, lowered in on 2s.
        knocks: [(frame, degrees)]: something bumps the sign and it swings on its threads, dying away."""
        if self.ctx.year is None:
            return
        f_in = self.year_land() if f_in is None else f_in
        sb = self.safe_plate_box()
        bx0, by0 = sb[0], sb[1]
        if self.year_xy is not None:
            bx0, by0 = self.op(*self.year_xy)
        x, y = bx0 + 14, by0 + 4 + YEAR_DROP_ROOM        # 14 px: room for the knock swing at the left edge
        # the drop starts inside the safe area: never higher than the room above the resting sign
        an = P.lower_in(f, f_in, height=float(np.clip(y - sb[1] - 8, 0, 70)))
        if an is None:
            return
        for fk, deg in knocks:
            k = (f - (fk - fk % 2)) // 2
            if 0 <= k < 8:
                an = dict(an, angle=an["angle"] + deg * (0.62 ** k) * (1 if k % 2 == 0 else -1),
                          dy=an["dy"] - (3 if k == 0 else 0))
                self._event(fk, "year_knock")
        sign = P.year_sign(self.ctx.year, light=self.light)
        hung = P.hanging(sign, -(y + 10), seed=self.ctx.index)
        P.place(fr, hung, x, y + an["dy"], depth=self.focus if depth is None else depth, shadow="hang",
                angle=an["angle"], origin=(hung.anchor[0] + sign.w / 2, 0), light_match=0.35,
                label=f"YEAR {self.ctx.year}")
        self._event(f_in, "year_sign")

    def draw_card(self, fr, f, prop, f_in, f_out=None, xy=None, mount="hang", depth=None, stick_len=260,
                  shadow=None):
        """A data card at output px xy (its top-left, reference camera), lowered in on threads
        (mount="hang"), set down on a stick (mount="stick") or placed (mount="none"), and lifted out at
        f_out. The card is clamped into the safe area."""
        if f < f_in - f_in % 2:
            return None
        lo = P.lift_out(f, f_out) if f_out is not None else dict(dy=0, angle=0)
        if lo is None:
            return None
        bx0, by0, bx1, by1 = self.safe_plate_box()
        x, y = self.op(*xy) if xy is not None else (bx0 + 6, by0 + 200)
        # margins so the arrival (swing on the threads / landing stretch) never pokes out of the safe box
        mx = (int(np.ceil(prop.h * np.sin(np.radians(3.2)))) + 3 if mount == "hang"
              else int(np.ceil(prop.w * 0.04)) + 3)
        x = float(np.clip(x, bx0 + mx, max(bx0 + mx, bx1 - prop.w - mx)))
        y = float(np.clip(y, by0, by1 - prop.h))
        room = max(0.0, y - by0 - 6)                     # the drop-in starts no higher than the safe top
        d = self.focus if depth is None else depth
        if mount == "hang":
            an = P.lower_in(f, f_in, height=min(70.0, room))
            hung = P.hanging(prop, -(y + 10), seed=self.ctx.index + 3)
            P.place(fr, hung, x, y + an["dy"] + lo["dy"], depth=d, shadow=shadow or "hang",
                    angle=an["angle"] + lo["angle"], origin=(hung.anchor[0] + prop.w / 2, 0), label=prop.label)
        elif mount == "stick":
            an = P.drop_in(f, f_in, height=min(50.0, room))
            st = P.on_stick(prop, stick_len, seed=self.ctx.index + 5)
            P.place(fr, st, x, y + an["dy"] + lo["dy"], depth=d, shadow=shadow or "hang", sx=an["sx"], sy=an["sy"],
                    origin=(prop.w / 2, st.h), label=prop.label)
        else:
            an = P.drop_in(f, f_in, height=min(30.0, room))
            P.place(fr, prop, x, y + an["dy"] + lo["dy"], depth=d, shadow=shadow or "contact", sx=an["sx"],
                    sy=an["sy"], label=prop.label)
        self._event(f_in, "card")
        return x, y

    # ---------------------------------------------------------------- bookkeeping
    def _event(self, f, kind):
        if (f, kind) not in self._ev:
            self._ev.append((f, kind))

    def focus_for(self, f):
        return self.focus

    def finish_args(self, f):
        return {}

    def events(self):
        return []

    def sound(self, snd):
        pass


class ShotSound:
    """Audio stems for one shot. Two buses: `bed` (ambience, ducked under the narration at assembly)
    and `sfx` (effects, only slightly ducked). Positions are GLOBAL seconds; the stem covers
    [shot start - PRE, shot end + POST] so tails and lead-ins may cross the cut."""
    PRE, POST = 1.0, 1.5

    def __init__(self, ctx: ShotContext):
        self.ctx = ctx
        self.t0 = ctx.f0 / FPS - self.PRE
        self.t1 = ctx.f1 / FPS + self.POST
        self.n = int(round((self.t1 - self.t0) * A.SR))
        self.buses = {"bed": np.zeros((self.n, 2)), "sfx": np.zeros((self.n, 2))}

    @staticmethod
    def at_frame(f):
        return f / FPS

    def _add(self, bus, x, t, gain_db, pan):
        x = np.asarray(x, np.float64)
        i = int(round((t - self.t0) * A.SR))
        if x.ndim == 1:
            a = (pan + 1) * np.pi / 4
            x = np.stack([x * np.cos(a), x * np.sin(a)], 1)
        if i < 0:
            x, i = x[-i:], 0
        x = x[: max(0, self.n - i)] * A.db(gain_db)
        self.buses[bus][i:i + len(x)] += x

    def sfx(self, x, t, gain_db=0.0, pan=0.0):
        """Effect at global time t (s). Use snd.at_frame(f) to land it on a picture frame."""
        self._add("sfx", x, t, gain_db, pan)

    def bed(self, x, t, gain_db=0.0, pan=0.0):
        """Ambience at global time t (s); ducked under the narration when assembled."""
        self._add("bed", x, t, gain_db, pan)

    def shot_span(self):
        return self.ctx.f0 / FPS, self.ctx.dur
