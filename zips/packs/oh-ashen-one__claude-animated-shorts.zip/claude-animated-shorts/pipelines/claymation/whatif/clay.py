"""Stop-motion tells: everything is decided per EXPOSURE (one photograph = two frames on 2s).

    exposure(f, f0)                 the frame whose photograph frame f shows (even frames; the shot's
                                    first frame if it is odd)
    flicker(e, seed)                (gain, rgb tint) of the lamps for one exposure: +-1 to 2 %
    bump_schedule(f0, f1, seed)     {exposure: (dx, dy)}: the occasional one-exposure knock of the camera
    Jitter(seed, touches)           a prop that was touched: settles at a slightly new spot after each
                                    touch, trembling for a few exposures first
    crawl(rgb, mask, e, seed)       clay surfaces re-pressed between exposures: sub-pixel boil of the
                                    image inside `mask` plus a faint fingerprint shimmer
    nudged(values, seed)            a camera move done by hand: uneven steps that still land on the target
    nudge_region(fr, mask, ...)     move / squash / tilt one object of the painted set for an exposure
                                    (a machine jolting, a box knocked, a sign shoved): soft-masked warp
    poly_mask(points, shape, feather)   soft mask from a polygon (plate px)
"""
import math

import cv2
import numpy as np

from .config import FPS


def exposure(f, f0=0):
    """Frame of the photograph shown at frame f (on 2s, grid on even GLOBAL frames)."""
    return max(f - f % 2, f0)


def _u(seed, e, k=0):
    """Deterministic uniform -1..1 for (seed, exposure, channel)."""
    x = math.sin(seed * 12.9898 + e * 78.233 + k * 37.719) * 43758.5453
    return 2 * (x - math.floor(x)) - 1


def flicker(e, seed=0, amount=0.012):
    """Lamp flicker between exposures: overall gain 1 +- amount (a little memory, so it wanders rather
    than buzzes) and a tiny warm/cool shift. Returns (gain float, tint (3,) float32)."""
    k = e // 2
    v = 0.65 * _u(seed, k) + 0.35 * _u(seed, k - 1)
    gain = 1 + amount * v
    t = 0.0035 * _u(seed + 7, k)
    return gain, np.float32([1 + t, 1.0, 1 - t])


def bump_schedule(f0, f1, seed=0, every=4.5, amp=1.6):
    """Exposures (even frames in [f0, f1)) where the set gets knocked for one photograph, about one per
    `every` seconds, never in the first or last half second. {exposure frame: (dx, dy) plate px}."""
    rng = np.random.default_rng(seed * 31 + 5)
    out = {}
    t = f0 / FPS + rng.uniform(0.6, every)
    while t < f1 / FPS - 0.5:
        e = int(round(t * FPS))
        e -= e % 2
        a = rng.uniform(0, 2 * math.pi)
        out[e] = (amp * math.cos(a), amp * math.sin(a) * 0.7)
        t += rng.uniform(0.6, 1.4) * every
    return out


class Jitter:
    """A touched prop. touches = [frame, ...] (when an animator handled it). After each touch the prop
    trembles for `settle` exposures, then rests at a slightly new place (props never return to exactly
    the same spot). Call j(f) -> (dx, dy, deg)."""

    def __init__(self, seed, touches=(), amp=0.9, deg=0.35, settle=2, rest=0.6):
        self.seed, self.touches = seed, sorted(int(t) for t in touches)
        self.amp, self.deg, self.settle, self.rest = amp, deg, settle, rest

    def __call__(self, f):
        e = f - f % 2
        before = [t for t in self.touches if t <= e]
        if not before:
            return 0.0, 0.0, 0.0
        k = len(before)
        rx, ry, rr = (self.rest * _u(self.seed, k, 1), self.rest * _u(self.seed, k, 2),
                      self.rest * 0.4 * _u(self.seed, k, 3))
        since = (e - before[-1]) // 2
        if since < self.settle:
            fall = 1 - since / self.settle
            rx += self.amp * fall * _u(self.seed, e, 4)
            ry += self.amp * fall * _u(self.seed, e, 5)
            rr += self.deg * fall * _u(self.seed, e, 6)
        return rx, ry, rr


def _noise_field(h, w, e, seed, cell=24):
    rng = np.random.default_rng((seed * 1009 + e * 7919) % (2 ** 32))
    hs, ws = max(2, h // cell + 2), max(2, w // cell + 2)
    n = rng.standard_normal((hs, ws, 2)).astype(np.float32)
    n = cv2.resize(n, (w, h), interpolation=cv2.INTER_CUBIC)
    return n


def crawl(rgb, mask, e, seed=0, amp=0.55, shimmer=0.006, cell=22):
    """Boil of hand-animated clay: inside mask (0..1, plate size), every exposure the surface shifts by a
    smooth random field of about `amp` px and its fine texture brightens/darkens by +-shimmer (a new
    thumb pass). Works in place on the mask's bounding box; returns rgb."""
    if mask is None:
        return rgb
    ys, xs = np.nonzero(mask > 0.02)
    if not len(ys):
        return rgb
    y0, y1 = max(0, ys.min() - 4), min(rgb.shape[0], ys.max() + 5)
    x0, x1 = max(0, xs.min() - 4), min(rgb.shape[1], xs.max() + 5)
    sub = rgb[y0:y1, x0:x1]
    m = mask[y0:y1, x0:x1].astype(np.float32)
    h, w = sub.shape[:2]
    n = _noise_field(h, w, e, seed, cell) * (amp * m[..., None])
    gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    warped = cv2.remap(sub, gx + n[..., 0], gy + n[..., 1], cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    rng = np.random.default_rng((seed * 131 + e * 17) % (2 ** 32))
    fine = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), 1.6)
    fine /= fine.std() + 1e-6
    warped = warped * (1 + shimmer * fine * m)[..., None]
    rgb[y0:y1, x0:x1] = sub * (1 - m[..., None]) + warped * m[..., None]
    return rgb


def nudged(values, seed=0, unevenness=0.35):
    """values: ideal camera value per exposure (e.g. an eased push-in). Returns the same move done by
    hand: each step between exposures is up to `unevenness` larger or smaller, monotonic where the ideal
    is, and the move still ends exactly on target."""
    v = np.asarray(values, np.float64)
    if len(v) < 2:
        return v
    d = np.diff(v)
    rng = np.random.default_rng(seed)
    dn = d * (1 + unevenness * rng.uniform(-1, 1, len(d)))
    tot, totn = d.sum(), dn.sum()
    if abs(totn) > 1e-12:
        dn *= tot / totn
    return np.concatenate([[v[0]], v[0] + np.cumsum(dn)])


def poly_mask(points, shape, feather=6.0):
    """Soft 0..1 mask of a polygon (plate px), feathered by `feather` px."""
    m = np.zeros(shape[:2], np.float32)
    cv2.fillPoly(m, [np.round(np.float32(points)).astype(np.int32)], 1.0, cv2.LINE_AA)
    return cv2.GaussianBlur(m, (0, 0), feather) if feather > 0 else m


def nudge_region(fr, mask, origin, sx=1.0, sy=1.0, dx=0.0, dy=0.0, angle=0.0, depth=True):
    """Pose one object of the painted set for this exposure: scale (sx, sy) and rotate (degrees) about
    origin (plate px), then shift by (dx, dy), blended in with the soft mask (0..1, plate size). Small
    amounts only (a few px / percent): the painted background under the object is not known, so the
    mask's feather absorbs the stretch. Works on fr.rgb (and fr.depth) in place."""
    ys, xs = np.nonzero(mask > 0.01)
    if not len(ys):
        return fr
    pad = int(max(abs(dx), abs(dy)) + 8 + max(abs(sx - 1), abs(sy - 1)) * 400 + abs(angle) * 6)
    H, W = mask.shape
    y0, y1 = max(0, ys.min() - pad), min(H, ys.max() + pad + 1)
    x0, x1 = max(0, xs.min() - pad), min(W, xs.max() + pad + 1)
    gx, gy = np.meshgrid(np.arange(x0, x1, dtype=np.float32), np.arange(y0, y1, dtype=np.float32))
    ox, oy = origin
    a = math.radians(angle)
    # inverse map: where each output pixel comes from
    ux, uy = gx - dx - ox, gy - dy - oy
    rx = (ux * math.cos(a) + uy * math.sin(a)) / sx
    ry = (-ux * math.sin(a) + uy * math.cos(a)) / sy
    mx, my = (rx + ox - x0).astype(np.float32), (ry + oy - y0).astype(np.float32)
    m_src = cv2.remap(mask[y0:y1, x0:x1], mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    m = np.maximum(m_src, mask[y0:y1, x0:x1] * 0.0)[..., None]
    src = fr.rgb[y0:y1, x0:x1]
    moved = cv2.remap(src, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    fr.rgb[y0:y1, x0:x1] = src * (1 - m) + moved * m
    if depth and fr.depth is not None:
        d = fr.depth[y0:y1, x0:x1]
        dm = cv2.remap(d, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        fr.depth[y0:y1, x0:x1] = d * (1 - m[..., 0]) + dm * m[..., 0]
    return fr
