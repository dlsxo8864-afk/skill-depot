# Adding a shot to episode 2 (claymation)

Run everything from the episode folder (the one holding `src/`, `assets/`, `work/`). Every command below starts with

    uv run --python 3.12 --with-requirements src/requirements.txt python src/ep02.py ...

(written as `ep02.py ...` below). CPU only, at most 6 workers, headless.

## Rules

- `src/whatif/` is FROZEN. Do not edit it. If you find a real bug, report it to the coordinator; do not
  work around it by copying library code into your shot unless it is shot-specific.
- Only create or edit files named for your own shots: `src/shots/<stem>.py`, and your outputs under
  `work/shots/<stem>/`. Shot-private helpers go inside your shot module.
- The timeline (`src/timeline.py`) is shared: do not change gaps or the shot order.
- Read `../STYLE.md` before starting; every check there must hold in your frames.

## Steps

1. Find your row in `SHOTS.md` (stem, key image, sync word, cards and signs) and your measured words:
   `ep02.py --timeline` (frames) and `ep02.py --words` (word starts per take, slow: runs the
   transcriber; the cached starts are in `work/voice/nicole_words.json`).
2. Look at `assets/key/<key>_key.png` and every `<key>_poseB.png` / `_poseC.png`. Decide:
   - same framing (character changes in place) -> `mode="region"` with a `region` polygon (key px)
     around everything that changes;
   - the variant reframes the set -> `mode="full"`: a cut inside the shot on the beat.
3. Copy the template below to `src/shots/<stem>.py` and fill it in.
4. Stills at every event and pose change, full size and 360x640:
   `ep02.py --shot <stem> --frames 1000 1010 1022` -> `work/shots/<stem>/stills/fNNNNN.png` and
   `fNNNNN_360.png`. The command prints the pose state of each frame and any safe-area warning.
5. Render: `ep02.py --shot <stem> --preview --workers 6` -> `work/shots/<stem>/video.mp4`, `bed.wav`,
   `sfx.wav`, `meta.json`, `preview.mp4` (with its narration line, music and sound). It prints the
   sync table: each event's frame against the measured start of its word.
6. Delete your `stills/` when done (disk is tight).
7. Assembly (coordinator): `ep02.py --assemble --name full` joins every rendered shot that matches the
   current timeline. It copies each shot's files first (safe while builders re-render), skips any shot
   still being written, re-masters until the ENCODED file is -14 LUFS and <= -1 dBTP, and checks the
   frame count of the result.

## Minimal template

```python
"""Year N: "<narration>"   event: <what happens> on "<word>"."""
from whatif import audio as A
from whatif import props as P
from whatif.shotkit import BaseShot
from whatif.stage import track

REGION = [(0, 300), (600, 300), (600, 1400), (0, 1400)]      # key px around the character(s)


class Shot(BaseShot):
    light = (-0.55, -0.75)                    # toward the key light in the picture (upper left)

    def __init__(self, ctx):
        super().__init__(ctx)
        self.f_ev = ctx.f("word")             # even frame of the measured word start
        self.setup(anchor=(0.5, 0.5), region=REGION, switches=[(self.f_ev, "B")],
                   zoom=track((0, 1.0), (ctx.dur, 1.03)))
        self.cam.add_bump(self.f_ev, 0.0, 2.5)                # a knock when the beat lands
        self.card = P.data_card(["Line one", "line two"], "Source, 2026", width=420, cap=34, seed=3,
                                wrap=False, source_kind="body")
        self.focus = self.focus_at(400, 800, "A")             # key px of what the lens is focused on

    def frame(self, f):
        fr = self.base(f)                     # pose for f (anticipation / in-between / hold) + clay boil
        self.draw_year(fr, f)
        self.draw_card(fr, f, self.card, self.ctx.f("other") - 2, xy=(560, 420))
        return fr

    def events(self):
        return [(self.f_ev, "pose_B", {"word": "word"})]

    def sound(self, snd):
        snd.sfx(A.squelch(seed=1), snd.at_frame(self.f_ev), -18, 0.0)


def make(ctx):
    return Shot(ctx)
```

`frame(f)` returns a `stage.Frame` in PLATE space (the fitted key, 1145x2035). The renderer photographs
it through the shot's stepped camera, then `look.finish` adds depth of field, lamp flicker, vignette and
grain. Draw props into the frame; never draw onto the output image.

## Coordinates

- Key px: pixels of the original key image (sizes vary). `self.kp(x, y)` -> plate px.
- Plate px: the key fitted by cover x1.06 (1145x2035). Everything in `Frame.rgb/depth` is plate px.
- Output px: 1080x1920. `self.op(x, y)` -> plate px for the reference camera; `draw_card(xy=...)` and
  `year_xy` take output px.
- Safe text area (output): x 65..929, y 115..1498, cap height >= 30 px. Props helpers record text boxes;
  the renderer warns about any that leave the safe area after the camera.

## Timing: pin events to words

- `ctx.f("word")` is the EVEN frame (on 2s) of the measured start of a word; `ctx.f("word", n=1)` the
  second occurrence; `ctx.t("word")` seconds; `ctx.f("word", at="e")` its end. Spelling as in
  `lines.json`, punctuation ignored ("centers?" and "centers" both work).
- Word starts are measured from the take's energy envelope with transcription only for word order
  (`whatif/speech.py`); they are global seconds.
- Picture changes land ON the word start (or one exposure before for an anticipation). Cards are lowered
  in 2 frames before their word so they settle as it is spoken.
- Return every picture event from `events()` with `{"word": ...}` so the sync table prints the offset.

## API a builder needs

### shotkit.BaseShot
- `setup(anchor, region, mode, zoom, x, y, roll, switches, bumps=True, crawl_amp=0.55, **rep_kw)` fits the
  key, builds poses/transitions for `switches`, the camera and the stage. `switches`: `[(frame, "B"),
  (frame, "A", {"ant": False, "inb": True})]`.
- `base(f, st=None, boil=True)` frame with the pose state for f; `state(f)` -> "A", "antAB" (anticipation),
  "AB" (in-between), "B"...
- `draw_year(fr, f, f_in=None, depth=None, knocks=[(frame, degrees)])` YEAR sign on threads, top left.
- `draw_card(fr, f, prop, f_in, f_out=None, xy=None, mount="hang"|"stick"|"none", depth=None)`.
- `kp`, `op`, `focus_at(x, y, pose)`, `safe_plate_box()`, `focus_for(f)`, `finish_args(f)`.
- `self.cam.add_bump(f, dx, dy)` one-exposure camera knock; `self.rep.pose("B")` -> (rgb, depth, mask).
- `ShotSound`: `snd.sfx(x, t, gain_db, pan)`, `snd.bed(...)` (ducked under narration), `snd.at_frame(f)`.

### replace.Replacement (built by setup)
- region mode: each variant aligned to the key, only the differing region (inside your polygon) is used,
  colour-matched; changes play as anticipation (lean + squash), mesh-warped in-between, hold.
- full mode: the variant is fitted like the key and replaces the picture on the switch (a cut).
- Caches in `work/cache/` rebuild when a painting, the fit or the region changes.

### props (physical text and objects; all plate px, all go through `place` or ink helpers)
- `place(fr, prop, x, y, depth, shadow="contact"|"hang"|"none", angle, sx, sy, ...)` composite with contact
  shadow, scene light colour, depth write and text box.
- `clay_glyph`, `clay_word`, `clay_line_prop` clay letters (bevel, thumbprints, side wall).
- `ClayTitle(lines, cap, x, y, align, max_w, colors).cue(frames).draw(fr, f, depth)` letters dropped in by
  hand word by word.
- `card(w, h, kind="card"|"paper"|"cardboard"|"ticket")` blank cut-out; `wood_plank`, `dowel`.
- `print_text(prop, lines, ...)` print / paint text onto a card (>= 30 px cap enforced).
- `data_card(lines, source, width, cap, wrap=False, source_kind="body"|"type")` the shot's number card.
- `year_sign(n)` the series sign (use `draw_year`).
- `hanging(prop, top_y)` threads above; `on_stick(prop, length)` dowel below.
- `stamp_ink(text, color, cap, border, double, angle)` and `scenario_ink()` rubber-stamp ink alphas.
- `ink_on_quad(fr, ink, color, quad, wet)` stamp/print onto a flat surface in the picture (perspective).
- `ink_on_strip(fr, ink, color, top, bottom, wet, cache)` onto a curved strip (ticket, bill).
- `letter_on_quad(fr, lines, quad, cap, color, kind="marker")` hand-letter a blank sign in the picture.
- `flip_card`, `FlipNumber(values, change_frames).prop(f)` numbers changing by replacement cards.
- `ribbon(fr, centerline, width, color)` a paper strip along a curve.
- `screen_insert(fr, quad, canvas, text_rect)` backlit printed insert in a clay screen.
- `drop_in`, `lower_in`, `lift_out` on-2s arrival/exit curves for props.
- Colours: `INK, STAMP_RED, STAMP_PURPLE, CLAY_RED, CLAY_CREAM, CLAY_YELLOW, CLAY_BLUE, CLAY_GREEN, WOOD`.

### text
- `font(kind, size, weight)` kinds: "clay" (Fredoka), "body" (Nunito), "type"/"type_reg" (Courier Prime),
  "marker" (Permanent Marker). `size_for_cap(kind, cap, weight)`, `text_alpha(s, fnt, tracking)` (enforces
  cap >= 30), `text_size`, `wrap`.

### clay (stop-motion tells)
- `exposure(f, f0)`, `flicker(e)`, `bump_schedule`, `Jitter(seed, touches)(f)` -> (dx, dy, deg) for touched
  props, `crawl` (used by `base`), `nudged` (used by the camera).
- `poly_mask(points, shape, feather)` soft plate mask.
- `nudge_region(fr, mask, origin, sx, sy, dx, dy, angle)` move/squash/tilt one painted object for one
  exposure (a jolt, a shove, a flinch). Small amounts only.

### stage / look / timing
- `stage.track((t, value), (t, value, ease))` camera tracks (shot-local seconds); `StepCamera` samples
  them per exposure with uneven hand nudges. Keep moves small (zoom <= 1.05, a few px).
- `look.finish` is applied by the renderer; set `self.dof = False` or a dict, or `finish_args(f)`.
- `screens.ScreenQuad.detect(plate_rgb, test)` finds a blank screen quad in a pose image.

### audio (synthesized, mono, seeded)
`squelch, clay_pop, wood_knock, paper_rustle, paper_flick, rubber_stamp, ratchet, string_creak,
perc(kind="woodblock"|"clave"|"shaker"|"toydrum"|"glock"), crowd, room_tone, bell, whoosh`. The music bed,
ducking, presence carve and mastering happen at assembly; do not add music in a shot. The YEAR sign's
creak and knock are added automatically.

## Example shots

`src/shots/s02_year1.py` (region mode, anticipation and in-between, print on a curved ticket, two stamps,
screen insert, data card, sign knock) and `src/shots/s01_hook.py` (full-mode cut on the beat, painted-set
shoves with `nudge_region`, a slot closed by copying painted wood, flood-filled placard quads lettered in
perspective, clay title cued per word).

## Patterns from s11 to s13 (copy them into your own module; the library stays frozen)

- **Pieces that travel (s11_year10).** When the key shows objects mid-flight and the variant shows them
  gone, use `mode="full", switches=[]`, take pose B as the set (`self.rep.pose("B")`), and cut the
  objects out of pose A as sprites (`cut_pieces`: warm components inside a box, holes filled, one per
  centre). Draw your own base with `fr = self.stage.frame(f, img, depth, None)` and `P.place` each sprite
  along a path read off the painting (`resample` a polyline of key px), shrinking for perspective, one
  exposure of anticipation (dip + squash) before it goes. Paste regions of pose A over pose B with a soft
  mask measured from the painting (`screen_mask`) and `cv2.inpaint` small things away (`remove_queue`).
- **Ghost of the outgoing pose on a smooth background (s13_cta).** Region mode colour-matches only in a
  ring; on a flat dusk sky the area the old hand covered shows as a pale or dark blob. `match_sky` in
  s13 rewrites `self.rep._img` / `self.rep._pair` after `setup`: it measures key minus pose where both
  show sky, fills that difference smoothly (normalised blur at 1/4 size) and adds it inside the swap mask
  only. Keep the sky classifier strict (bright, clearly blue) or dark props leak in.
- **Card signs on sticks (s13_cta).** `sign(lines)` prints painted text on a `P.card` copy (cards are
  cached: copy `rgba` before printing), `P.on_stick`, then `P.place(..., shadow="contact")` with a
  `clay.Jitter` touched on the beat so it jolts when the hand moves toward it.
- **A stamp on a tag (s11_year10).** `draw_card` returns the card's plate (x, y); after the tag has
  settled, `P.ink_on_quad(fr, ink, colour, quad, wet=...)` with `P.scenario_ink(cap=32)` at full size
  (never scale stamp ink below 1.0: the cap height would fall under 30 px).
- **Crumbs and small bits (s12_catch).** A tiny shaded clay Prop (`crumb`) dropped over 3 exposures with
  a shadow that tightens as it lands.
- Words keep their script punctuation in `lines.json`; `ctx.f("photos,")`, `ctx.f("photos")` and
  `ctx.f("country?")` all work.
- Render time on the Studio: about 1 s per exposure per worker; a 5 s shot takes 1 to 3 minutes with 4
  workers. Look at `--frames` stills before a full render.
