"""Episode 2 timeline: one shot per narration line, timed from the measured narration.

Each shot owns one line (one wav in assets/voice/nicole/, listed in lines.json). A shot starts one frame
before its line's first spoken word (the cut lands on the beat) and ends where the next shot starts.
Between the last word of one line and the first word of the next sits that shot's `gap`.

Word times: whatif/speech.py. The transcriber (faster-whisper small, CPU) only gives the word order and
a rough prior; every word START is an energy onset of the take, chosen with prefix-cut transcription
votes (see speech.py). Cached in work/voice/nicole_words.json; delete it, or touch a wav, to re-measure.
Check with:  python src/ep02.py --words   (prints every word, prior vs measured, and a per-word
re-transcription of the measured span).

Only the director edits this file. Shot builders read it through `ShotContext` (whatif/shotkit.py).
"""
import json
import math
from functools import lru_cache

from whatif.config import ASSETS, FPS, WORK

VOICE_DIR = ASSETS / "voice" / "nicole"
WORDS_CACHE = WORK / "voice" / "nicole_words.json"
ALGO = "energy-votes-4"         # bump to force a re-measure after changing speech.py
CUT_LEAD = 0.04                 # the cut lands this long before the line's first word
END_HOLD = 2.25                 # the CTA holds this long after its last word (brief: >= 2.0 s)
GAP = 0.40                      # pause between lines
TAIL = 0.20                     # extra air where the shot's payoff (its data card) is spoken in its last words

# stem, key image, narration wav, gap after the line (s), YEAR sign number (None = no sign)
SHOTS = [
    ("s01_hook",   "y00_hook_key.png",    "00_hook.wav",    0.45, None),
    # Year 1: the number is stamped on "nowhere", three words before the end; the ticket needs reading
    ("s02_year1",  "y01_chatbot_key.png", "01_chatbot.wav", GAP + 0.35, 1),
    ("s03_year2",  "y02_cloud_key.png",   "02_cloud.wav",   GAP + TAIL, 2),    # card spoken to "empty"
    ("s04_year3",  "y03_power_key.png",   "03_power.wav",   GAP + 0.30, 3),    # long card spoken to "grid"
    ("s05_year4",  "y04_water_key.png",   "04_water.wav",   GAP + TAIL, 4),    # "...gallons in one year"
    ("s06_year5",  "y05_cranes_key.png",  "05_cranes.wav",  GAP + TAIL, 5),    # "...building boom"
    ("s07_year6",  "y06_taxes_key.png",   "06_taxes.wav",   GAP + TAIL, 6),    # "...almost half"
    ("s08_year7",  "y07_retire_key.png",  "07_retire.wav",  GAP + TAIL, 7),    # "...billion dollars on this"
    ("s09_year8",  "y08_move_key.png",    "08_move.wav",    GAP + TAIL, 8),    # "...Abu Dhabi"
    ("s10_year9",  "y09_china_key.png",   "09_china.wav",   GAP + TAIL, 9),    # "...by twenty thirty"
    ("s11_year10", "y10_abroad_key.png",  "10_abroad.wav",  GAP + TAIL, 10),   # "...another country"
    ("s12_catch",  "y11_catch_key.png",   "11_catch.wav",   GAP + 0.15, None), # "...where they're built"
    ("s13_cta",    "y12_cta_key.png",     "12_cta.wav",     END_HOLD, None),
]

# Each shot's sync word (SHOTS.md) and how many frames after its start the contact sheet looks.
EVENT_WORD = {
    "s01_hook": ("banned", 6), "s02_year1": ("nowhere", 8), "s03_year2": ("more", 6),
    "s04_year3": ("slowly", 8), "s05_year4": ("water", 8), "s06_year5": ("stop", 6),
    "s07_year6": ("rise", 8), "s08_year7": ("five", 8), "s09_year8": ("move", 6),
    "s10_year9": ("pause", 8), "s11_year10": ("AI", 6), "s12_catch": ("where", 8),
    "s13_cta": ("country?", 24),
}


def lines():
    return json.loads((VOICE_DIR / "lines.json").read_text())["lines"]


def analyse_lines(force=False, verbose=False):
    """Measured word times and speech bounds for every line (seconds within the take); cached."""
    from whatif import speech as SP
    cache = json.loads(WORDS_CACHE.read_text()) if WORDS_CACHE.exists() and not force else {}
    todo = [ln for ln in lines() if ln["file"] not in cache or cache[ln["file"]].get("algo") != ALGO
            or cache[ln["file"]].get("mtime") != (VOICE_DIR / ln["file"]).stat().st_mtime]
    if todo:
        from faster_whisper import WhisperModel
        model = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=6)
        for ln in todo:
            p = VOICE_DIR / ln["file"]
            heard = SP.transcribe(model, p)
            words, info = SP.measure_line(p, ln["script"], heard, model=model)
            x, sr = SP.load(p)
            cache[ln["file"]] = {"script": ln["script"], "dur": len(x) / sr, "on": info["on"], "off": info["off"],
                                 "bias": info["bias"], "words": words, "heard": " ".join(h["w"] for h in heard),
                                 "heard_words": heard, "algo": ALGO, "mtime": p.stat().st_mtime}
            if verbose:
                print(f"{ln['file']}: measured", " ".join(f"{w['w']}@{w['s']:.2f}" for w in words))
        WORDS_CACHE.parent.mkdir(parents=True, exist_ok=True)
        WORDS_CACHE.write_text(json.dumps(cache, indent=1))
    return cache


@lru_cache(maxsize=1)
def layout():
    """Shot dicts with frame ranges and narration placement (global seconds / frames)."""
    info = analyse_lines()
    shots = []
    speech_on = None
    for i, (stem, key, wav, gap, year) in enumerate(SHOTS):
        a = info[wav]
        if speech_on is None:
            speech_on = a["on"]                         # the hook's take starts with the episode
        vo_at = speech_on - a["on"]
        speech_off = vo_at + a["off"]
        shots.append({"index": i, "stem": stem, "key": ASSETS / "key" / key, "wav": VOICE_DIR / wav,
                      "year": year, "gap": gap, "vo_at": vo_at, "speech_on": speech_on, "speech_off": speech_off,
                      "words": [{**w, "s": round(vo_at + w["s"], 3), "e": round(vo_at + w["e"], 3)} for w in a["words"]]})
        speech_on = speech_off + gap
    for i, s in enumerate(shots):
        f0 = 0 if i == 0 else int(math.floor((s["speech_on"] - CUT_LEAD) * FPS))
        s["f0"] = f0 - f0 % 2      # every cut on an even frame (the picture is on 2s): trims the previous shot's tail
    for i, s in enumerate(shots):
        s["f1"] = shots[i + 1]["f0"] if i + 1 < len(shots) else int(math.ceil((s["speech_off"] + s["gap"]) * FPS))
        s["f1"] += s["f1"] % 2 if i + 1 == len(shots) else 0   # whole exposures to the end
    return shots


def total_frames():
    return layout()[-1]["f1"]


def shot_entry(stem):
    return next(s for s in layout() if s["stem"] == stem)


def event_frame(stem):
    """Global frame where the shot's SHOTS.md event is on screen (contact-sheet fallback)."""
    e = shot_entry(stem)
    w, off = EVENT_WORD.get(stem, (None, 0))
    hit = [x for x in e["words"] if w and x["w"].strip(",.?!;:").lower() == w.strip(",.?!;:").lower()]
    f = int(round(hit[0]["s"] * FPS)) + off if hit else (e["f0"] + e["f1"]) // 2
    return min(max(f, e["f0"]), e["f1"] - 3)
