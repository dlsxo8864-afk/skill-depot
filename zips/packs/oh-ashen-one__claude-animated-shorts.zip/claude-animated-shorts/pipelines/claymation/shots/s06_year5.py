"""Year 5: "But the cranes would stop on a fifty billion dollar a year building boom."

Set: y05_cranes_key.png (pose A: three tower cranes hoisting loads over a data-center frame, five workers
chatting over lunch on the block steps) and _poseB.png (pose B: the same set, the workers slumped asleep).
    (from the cut)  the cranes hoist: each load climbs a step per exposure on its cable, swaying a little
    "stop"          the cranes jerk to a halt: the loads drop a notch on their cables and swing out, the
                    whole set gets knocked; the swing dies away on 2s for the rest of the shot
    "a" (1st)       the workers slump (anticipation, in-between, held pose B)
    "fifty"         the data card is lowered in on its threads just above the brick pallet behind the workers
Loads: each one (cable, hook, slings and load) is lifted off the painting and re-hung every exposure,
rotated about its trolley and with its cable lengthened or shortened; the sky behind is filled in.
"""
import math

import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# ---------------------------------------------------------------- set measurements (key px)
WORKERS = [(0, 850), (941, 850), (941, 1420), (0, 1420)]
# each load: (polygon from the trolley down round the load, trolley pivot, hook y, phase, size)
LOADS = [
    ([(236, 210), (259, 210), (262, 330), (314, 392), (316, 522), (178, 522), (178, 368), (232, 330)],
     (247, 214), 320, 0.0, 1.0),
    ([(548, 338), (568, 338), (571, 428), (617, 458), (617, 524), (503, 524), (503, 452), (545, 428)],
     (558, 342), 415, 1.7, 0.8),
    ([(716, 236), (741, 236), (744, 362), (812, 418), (812, 530), (650, 530), (650, 418), (713, 362)],
     (728, 240), 355, 3.1, 1.15),
]
CARD_XY = (330, 806)                    # output px: hung on threads just above the brick pallet behind the workers


class Shot(BaseShot):
    light = (-0.45, -0.85)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_stop = c.f("stop")
        self.f_slump = c.f("a")
        self.f_card = c.f("fifty") - 2
        self.setup(anchor=(0.5, 0.5), region=WORKERS, switches=[(self.f_slump, "B")],
                   zoom=track((0, 1.0), (c.dur, 1.02, "inout")), x=track((0, 6.0), (c.dur, -6.0, "inout")))
        self.cam.add_bump(self.f_stop, 2.6, -3.0)
        self.cam.add_bump(self.f_stop + 2, -1.2, 1.4)
        self.cam.add_bump(self.f_slump, 0.0, 1.2)
        sh = (PH, PW)
        k = self.kp
        self.A, self.Ad = self.rep.pose("A")[:2]
        self.loads = []
        union = np.zeros(sh, np.float32)
        for poly, piv, hook_y, ph, size in LOADS:
            m = clay.poly_mask(k(poly), sh, 1.5)
            union = np.maximum(union, m)
            self.loads.append(dict(mask=m, pivot=np.float32(k(*piv)), hook=float(k(0, hook_y)[1]), phase=ph,
                                   size=size))
        hole = (cv2.dilate(union, np.ones((13, 13), np.uint8)) > 0.2).astype(np.uint8)
        q = (np.clip(self.A, 0, 1) * 255).astype(np.uint8)
        self.sky = cv2.inpaint(q, hole * 255, 11, cv2.INPAINT_TELEA).astype(np.float32) / 255
        # under the panel the building's top beam shows: rebuild it from the beam just to the right
        low = np.zeros(sh, np.float32)
        x0, y0 = k(150, 466)
        x1, y1 = k(300, 548)
        low[int(y0):int(y1), int(x0):int(x1)] = 1
        low = cv2.GaussianBlur(low * hole, (0, 0), 2)
        dx = int(k(140, 0)[0] - k(0, 0)[0])
        Mx = np.float32([[1, 0, -dx], [0, 1, 0]])
        beam = cv2.warpAffine(self.A, Mx, (PW, PH), borderMode=cv2.BORDER_REFLECT)
        self.sky = self.sky * (1 - low[..., None]) + beam * low[..., None]
        self.hole = cv2.GaussianBlur(hole.astype(np.float32), (0, 0), 3)
        self.card = P.data_card(["Data center construction:", "over $50 billion a year"], "Census data, 2026",
                                width=520, cap=32, seed=55, wrap=False, source_kind="body", light=self.light)
        self.focus_W = self.focus_at(470, 980, "A")          # the workers' faces
        self.focus_C = self.focus_at(560, 470, "A")          # the loads

    # ------------------------------------------------------------------ the loads
    def load_pose(self, e, L):
        """(angle degrees, cable change px) of a load for exposure e."""
        n = (e - (self.f0 - self.f0 % 2)) // 2
        s = (e - self.f_stop) // 2
        if s < 0:                                       # hoisting: up a notch every exposure, a gentle sway
            left = -s
            dy = 3.2 * left * (1.0 + 0.15 * math.sin(n * 1.7 + L["phase"]))
            ang = 1.1 * math.sin(n * 0.9 + L["phase"])
            return ang, dy
        # the jerk: the brake bites, the load drops a notch on its cable and swings out, dying away
        bounce = {0: 9.0, 1: -3.0, 2: 2.0}.get(s, 0.0)
        amp = 10.0 / L["size"] * (1 if L["phase"] != 1.7 else -1)      # the middle one swings the other way
        ang = amp * (0.80 ** s) * math.cos(2 * math.pi * s / (6.0 + 0.5 * L["size"]))
        return ang, bounce

    def hang_loads(self, fr, e):
        dm = self.hole[..., None]
        fr.rgb = fr.rgb * (1 - dm) + self.sky * dm
        for L in self.loads:
            ang, dy = self.load_pose(e, L)
            rehang(fr, self.A, self.Ad, L["mask"], L["pivot"], L["hook"], ang, dy)

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        e = f - f % 2
        self.hang_loads(fr, e)
        if (e - self.f_stop) // 2 in (0, 1):            # the jolt runs through the steel frame and the cranes
            jolt = clay.poly_mask(self.kp([(0, 150), (941, 150), (941, 860), (0, 860)]), fr.rgb.shape[:2], 30)
            clay.nudge_region(fr, jolt, self.kp(470, 860), angle=(0.35 if e == self.f_stop else -0.15), depth=False)
        if st == "B" and ((e - self.f_slump) // 8) % 2 == 1:      # asleep: slow breaths, on 2s
            clay.nudge_region(fr, self.clay, self.kp(470, 1420), sy=1.006, sx=1.002)
        self.stage.boil(fr)
        d = self.focus_for(f)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_stop, 4.0)])
        self.hang_card(fr, f)
        return fr

    def hang_card(self, fr, f):
        """The data card lowered in on two threads that run up out of the top of the frame, with a tight
        soft shadow (about 8 px, blur 4) cast away from the key light onto the building behind it."""
        if f < self.f_card - self.f_card % 2:
            return
        bx0, by0, bx1, by1 = self.safe_plate_box()
        x, y = self.op(*CARD_XY)
        x = float(np.clip(x, bx0, bx1 - self.card.w))
        y = float(np.clip(y, by0, by1 - self.card.h))
        an = P.lower_in(f, self.f_card)
        hung = P.hanging(self.card, -(y + 10), seed=self.ctx.index + 3)
        P.place(fr, hung, x, y + an["dy"], depth=self.focus_W, shadow="hang", shadow_dist=10, shadow_blur=3.5,
                shadow_opacity=0.62, angle=an["angle"], origin=(hung.anchor[0] + self.card.w / 2, 0),
                label=self.card.label)
        self._event(self.f_card, "card")

    def finish_args(self, f):
        # a gentler near blur while the lens is on the cranes: the chatting workers stay readable
        return {"dof": {"near": 3.0}} if self.focus_for(f) < self.focus_W - 0.02 else {}

    def focus_for(self, f):
        """Focus on the cranes while they work and stop, then racked to the workers in two hand-turned
        steps before they slump."""
        e = f - f % 2
        r0 = self.f_slump - 6
        if e < r0:
            return self.focus_C
        u = min(1.0, (e - r0) / 4 + 0.5)
        return self.focus_C + (self.focus_W - self.focus_C) * u

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f0 + 2, "loads_hoisting", {}),
                (self.f_stop, "cranes_jerk_halt_loads_swing", {"word": "stop"}),
                (self.f_slump - 4, "slump_anticipation", {}),
                (self.f_slump, "workers_slumped_poseB", {"word": "a"}),
                (self.f_card, "data_card", {"word": "fifty"})]

    def sound(self, snd):
        at = snd.at_frame
        d = self.ctx.dur
        snd.bed(A.room_tone(d + 2.0, seed=61) * 0.5, at(self.f0) - 0.5, -12)
        snd.bed(site_rumble(d + 1.5, seed=62), at(self.f0) - 0.4, -26)
        # the crane winches grinding until the brake bites
        pre = (self.f_stop - self.f0) / 24 + 1.0
        snd.sfx(A.ratchet(pre, rate=22, seed=63, motor=0.6), at(self.f0) - 1.0, -26, 0.3)
        snd.sfx(A.ratchet(pre, rate=17, seed=64, motor=0.5), at(self.f0) - 1.0, -28, -0.4)
        for i, p in enumerate((-0.5, 0.1, 0.5)):
            snd.sfx(clank(seed=65 + i, pitch=(1.0, 1.25, 0.85)[i]), at(self.f_stop) + 0.025 * i, -11 - 2 * i, p)
        snd.sfx(A.wood_knock(seed=69, pitch=0.5, hard=1.0), at(self.f_stop), -18, 0.0)
        for s in range(1, 9, 3):                          # the cables creak at the ends of the swings
            snd.sfx(A.string_creak(seed=70 + s, dur=0.28), at(self.f_stop + 2 * s), -24 - 2 * s, (-0.4, 0.4)[s % 2])
        snd.sfx(squelch(seed=80, dur=0.30, pitch=0.6), at(self.f_slump - 4), -22, 0.0)
        snd.sfx(slide_down(seed=81), at(self.f_slump - 2), -21, 0.0)
        snd.sfx(A.clay_pop(seed=82, pitch=0.65), at(self.f_slump), -20, -0.2)
        snd.sfx(squelch(seed=83, dur=0.22, pitch=0.5), at(self.f_slump) + 0.03, -22, 0.3)
        snd.sfx(A.paper_flick(seed=84), at(self.f_card), -24, 0.2)
        snd.sfx(A.wood_knock(seed=85, pitch=0.9, hard=0.6), at(self.f_card + 2), -24, 0.2)


def make(ctx):
    return Shot(ctx)


def squelch(seed=0, dur=0.28, pitch=1.0, wet=1.0):
    """whatif.audio.squelch with the duration snapped to a whole sample (the shared one mixes int() and
    round() sample counts and fails for durations like 0.30 s)."""
    return A.squelch(seed, (int(dur * A.SR) + 0.25) / A.SR, pitch, wet)


# ---------------------------------------------------------------------- shot-private helpers
def rehang(fr, rgb, depth, mask, pivot, hook_y, angle, dy):
    """Re-hang one crane load: rotate the cable-and-load about the trolley `pivot` by `angle` degrees
    and lengthen the cable by `dy` px (the cable stretches between the trolley and the hook; the hook
    and load move rigidly). Lifted from `rgb`/`mask` and laid over fr."""
    ys, xs = np.nonzero(mask > 0.01)
    pad = int(abs(dy) + abs(angle) * 6 + 30)
    H, W = mask.shape
    y0, y1 = max(0, ys.min() - pad), min(H, ys.max() + pad + 1)
    x0, x1 = max(0, xs.min() - pad - 40), min(W, xs.max() + pad + 41)
    gx, gy = np.meshgrid(np.arange(x0, x1, dtype=np.float32), np.arange(y0, y1, dtype=np.float32))
    a = math.radians(angle)
    px, py = float(pivot[0]), float(pivot[1])
    ux, uy = gx - px, gy - py
    rx = ux * math.cos(a) + uy * math.sin(a)          # inverse rotation
    ry = -ux * math.sin(a) + uy * math.cos(a)
    span = max(hook_y - py, 1.0)
    w = np.clip(ry / (span + dy), 0, 1)               # 0 at the trolley .. 1 at the hook and below
    ry = ry - dy * w
    mx, my = (rx + px).astype(np.float32), (ry + py).astype(np.float32)
    m = cv2.remap(mask, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)[..., None]
    obj = cv2.remap(rgb, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    sub = fr.rgb[y0:y1, x0:x1]
    fr.rgb[y0:y1, x0:x1] = sub * (1 - m) + obj * m
    dob = cv2.remap(depth, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    fr.depth[y0:y1, x0:x1] = fr.depth[y0:y1, x0:x1] * (1 - m[..., 0]) + dob * m[..., 0]


# ---------------------------------------------------------------------- shot-private sounds
def clank(seed=0, pitch=1.0):
    """A crane brake biting: a heavy metallic clank (inharmonic steel partials) with a rattle of chain."""
    rng = np.random.default_rng(seed)
    dur = 0.9
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    f0 = rng.uniform(170, 220) * pitch
    out = np.zeros(n)
    for ratio, amp, tau in ((1.0, 1.0, 0.25), (2.76, 0.7, 0.14), (5.40, 0.5, 0.08), (8.93, 0.35, 0.05),
                            (13.3, 0.2, 0.03)):
        out += amp * np.sin(2 * np.pi * f0 * ratio * (1 + rng.normal(0, 0.01)) * t) * np.exp(-t / tau)
    hitn = A.bandpass(rng.standard_normal(n), 1200, 8000) * np.exp(-t / 0.006) * 1.5
    thud = A.osc(np.linspace(90, 50, n), dur) * np.exp(-t / 0.06) * 0.8
    rattle = np.zeros(n)
    for i in range(7):
        k = int((0.05 + 0.035 * i + rng.uniform(0, 0.01)) * A.SR)
        r = A.bandpass(rng.standard_normal(600), 2500, 9000) * np.exp(-np.arange(600) / 80) * (0.5 * 0.8 ** i)
        rattle[k:k + 600] += r
    y = out * 0.6 + hitn + thud + rattle
    return y / (np.abs(y).max() + 1e-9)


def slide_down(seed=0, dur=0.55):
    """A slide whistle sagging down: the workers deflating."""
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    f = 980 * np.exp(-t / 0.35) + 330
    vib = 1 + 0.012 * np.sin(2 * np.pi * 7 * t)
    y = A.osc(f * vib, dur) + 0.15 * A.osc(2 * f * vib, dur)
    y += A.bandpass(np.random.default_rng(seed).standard_normal(n), 1500, 5000) * 0.04
    env = np.minimum(t / 0.03, 1) * np.exp(-np.maximum(t - dur * 0.6, 0) / 0.08)
    return y * env / (np.abs(y * env).max() + 1e-9)


def site_rumble(dur, seed=0):
    """Far-off building site: low machinery rumble with a slow throb."""
    t = np.arange(int(dur * A.SR)) / A.SR
    x = A.lowpass(A.noise(dur, seed, "brown"), 180) * (1 + 0.25 * np.sin(2 * np.pi * 0.7 * t))
    return x / (np.abs(x).max() + 1e-9)
