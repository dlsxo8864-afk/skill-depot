"""Year 9: "China wouldn't pause. It plans twenty-eight more gigawatts by twenty thirty."

Set: y09_china_key.png (pose A) and _poseB.png (pose B, nearly the same framing): a split set. Left of
the white line an abandoned site (rusty crane, cobwebs, a locked fence with a blank plaque); right of it
a busy build (workers passing servers, a crane with a load, a row of data center blocks).
Only the right side ever takes pose B, and it does so in pieces, as fast replacement steps:
    "China"        the CHINA sign is set down on its stick; the workers start passing servers along
                   (A, A, in-between, B, B, in-between, ... the whole shot)
    "pause"        the crane swings its load over (one in-between); the scaffold building on the right gains a
                   storey every two exposures, four times (each lands a little high and squashed, then
                   settles, behind the crane); on the left a cotton-wool dust puff, the tumbleweed rolls a
                   step, dust starts to settle and a grey clay dust heap grows in the foreground ruin
    (after)        the server stacks on the pallets grow a layer at a time (seven steps, each a thunk)
    "plans"        data card lowered in on its threads
    "twenty-eight", "gigawatts"   the crane swings back and forth again
Left side: dust settles in steps (the colour greys over, cobweb threads appear one by one); nothing moves
except the tumbleweed. The blank plaque on the fence is hand-lettered "HERE".
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# right of the white line (key px): the only parts taken from pose B (crane, skyline, ground)
RIGHT = [[(540, 240), (941, 200), (941, 540), (560, 545)],
         [(396, 515), (941, 495), (941, 790), (398, 790)],
         [(398, 770), (941, 770), (941, 1672), (418, 1672), (404, 1100)]]
WORKERS = [(398, 780), (700, 780), (762, 1062), (941, 1062), (941, 1672), (418, 1672), (404, 1100)]
# server stacks that grow a layer at a time: (top band polygon, rise per layer) in key px
STACKS = {"back": ([(778, 884), (800, 876), (872, 874), (872, 893), (843, 895), (843, 935), (778, 940)], 44),
          "front": ([(843, 895), (860, 887), (941, 889), (941, 952), (843, 956)], 50),
          "mid": ([(715, 772), (735, 766), (803, 768), (803, 801), (715, 805)], 30)}
WORKERS_Y = 770                                                    # key y: above = skyline, below = workers
CRANE = [(540, 240), (941, 200), (941, 540), (560, 545)]            # the right crane and its load (key px)
# one storey of the scaffold building (key px): top floor with its workers, columns and the slab under it;
# the hanging load's bottom (x < 835, y < 522) is left out
STOREY = [(752, 522), (835, 522), (835, 505), (941, 505), (941, 628), (752, 628)]
STOREY_H = 72                                                      # key px added per build step
BUILDING_TOP = 548                                                 # key y of the building's roof slab
HEAP_AT = (150, 1062)                                              # key px: foot of the dust heap (left ruin)
PLAQUE = [(124, 1166), (314, 1168), (313, 1246), (122, 1246)]      # the blank plaque on the fence (upper band)
TUMBLE = [(40, 1390), (120, 1370), (225, 1400), (240, 1490), (180, 1560), (60, 1550), (30, 1470)]
TUMBLE_C = (135, 1470)
# cobweb threads that appear as dust settles (key px polylines): crane, fence corner, ruin
WEBS = [[(110, 520), (160, 470), (215, 445)], [(30, 560), (70, 600), (95, 640)], [(250, 380), (280, 420), (300, 470)],
        [(45, 1105), (75, 1135), (60, 1170)], [(340, 1100), (360, 1140), (380, 1125)], [(205, 640), (230, 690), (205, 730)],
        [(150, 830), (190, 815), (230, 835)], [(10, 700), (40, 690), (55, 720)]]


class Shot(BaseShot):
    light = (0.45, -0.80)          # the low sun / work lights are upper right
    dof = {"near": 3.2}             # the front pair of workers stays readable

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_china = c.f("China")
        self.f_pause = c.f("pause")
        self.f_card = c.f("plans") - 2
        self.crane_moves = [(self.f_pause, "B"), (c.f("twenty-eight"), "A"), (c.f("gigawatts"), "B")]
        self.rise = [self.f_pause + 2 * k for k in range(0, 8, 2)]   # four steps, two exposures apart
        # the right side as pose B (the switch, after the shot ends, only builds the pose and its A->B in-between)
        self.setup(anchor=(0.5, 0.5), region=RIGHT, switches=[(self.f1 + 40, "B")],
                   zoom=track((0, 1.0), (c.dur, 1.025)), y=track((0, -8.0)))
        self.cam.add_bump(self.f_pause, 1.0, 2.6)
        self.cam.add_bump(c.f("twenty-eight"), -0.6, 1.4)
        sh = (PH, PW)
        Bp = self.rep.pose("B")
        self.B = Bp[0]
        self.Bd = Bp[1]
        self.inb = self.rep.pair("A", "B")[1]
        right = np.zeros(sh, np.float32)
        for poly in RIGHT:
            right = np.maximum(right, clay.poly_mask(self.kp(poly), sh, 3.0))
        yy = np.arange(PH, dtype=np.float32)[:, None]
        sky = 1.0 / (1.0 + np.exp(np.clip((yy - self.kp(0, WORKERS_Y)[1]) / 6.0, -50, 50)))
        crane = clay.poly_mask(self.kp(CRANE), sh, 8.0)
        self.m_crane = right * crane
        self.m_work = right * (1 - sky) * clay.poly_mask(self.kp(WORKERS), sh, 4.0)
        A_img = self.rep.pose("A")[0]
        self.m_storey = clay.poly_mask(self.kp(STOREY), sh, 1.5) * not_sky(A_img)
        self.storey_dy = STOREY_H * self.fit.s
        # the crane (and its load) stays in front of the new storeys: its non-sky pixels above the roof
        above = (yy < self.kp(0, BUILDING_TOP)[1]).astype(np.float32)
        self.crane_fg = {k: self.m_crane * above * not_sky(img) for k, img in
                         (("A", A_img), ("AB", self.inb), ("B", self.B))}
        self.left = clay.poly_mask(self.kp([(0, 0), (388, 0), (392, 740), (404, 1100), (414, 1672), (0, 1672)]), sh, 5.0)
        self.left *= not_sky(self.rep.pose("A")[0])          # dust settles on things, not on the sky
        self.tumble = clay.poly_mask(self.kp(TUMBLE), sh, 6.0)
        self.webs = [np.float32(self.kp(w)) for w in WEBS]
        self.puffs = [cotton_puff(r, seed=50 + i) for i, r in enumerate((44, 70, 90, 84))]
        self.tumble_clean = mirror_fill(self.rep.pose("A")[0], self.tumble)
        self.plaque = np.float32(self.kp(PLAQUE))
        self.sign = P.card(250, 96, "cardboard", seed=91, light=self.light, bend=0.03)
        P.print_text(self.sign, [("CHINA", {"weight": 900, "cap": 52, "color": P.INK})], kind="body", cap=52,
                     seed=91)
        self.sign.label = "CHINA"
        self.card = P.data_card(["China: 28 GW", "more planned", "by 2030"], "Rystad Energy", width=330, cap=38,
                                seed=29, wrap=False, source_kind="body", light=self.light)
        self.card_xy = (470, 190)
        self.sign_xy = (472, 560)
        self.focus = self.focus_at(600, 1150, "A")          # between the two front pairs of workers
        self.A0 = self.rep.pose("A")[0]
        self.stacks = {k: (clay.poly_mask(self.kp(poly), sh, 1.5), dy * self.fit.s)
                       for k, (poly, dy) in STACKS.items()}
        self.layers = [("front", 1, self.f_pause + 16), ("back", 1, self.f_pause + 22), ("mid", 1, c.f("plans")),
                       ("front", 2, c.f("twenty-eight")), ("back", 2, c.f("twenty-eight") + 6),
                       ("mid", 2, c.f("gigawatts") + 4), ("front", 3, c.f("twenty"))]
        self.dust_steps = list(range(self.f_pause, self.f1 + 2, 6))
        # the heap takes the ground's own clay colour (median of the mud round its foot, a touch lighter and
        # greyer: settled dust), so it reads as the same clay as the ruin, not a pale cut-out
        hx, hy = (int(v) for v in self.kp(*HEAP_AT))
        r = int(110 * self.fit.s)
        patch = self.rep.pose("A")[0][max(hy - r // 2, 0):hy + r // 3, max(hx - r, 0):hx + r].reshape(-1, 3)
        lum = patch.mean(1)
        mud = np.median(patch[(lum > np.percentile(lum, 25)) & (lum < np.percentile(lum, 85))], 0)
        g = float(mud.mean())
        self.mud = np.clip((g + (mud - g) * 0.7) * 1.10, 0, 1).astype(np.float32)
        self.heaps = [dust_heap(int(w * self.fit.s), seed=60, light=self.light, base=self.mud)
                      for i, w in enumerate((84, 120, 152, 182, 206, 226))]

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        fr = self.base(f, "A", boil=False)
        e = f - f % 2
        # the workers pass servers along: A, A, in-between, B, B, in-between, ... from "China" on
        ws = self.worker_state(e)
        if ws == "B":
            self._swap(fr, self.m_work, self.B, self.Bd)
        elif ws == "AB":
            self._swap(fr, self.m_work, self.inb, self.Bd)
        # the crane: A <-> B with an in-between exposure before each move
        cs = "A"
        for fm, to in self.crane_moves:
            if e >= fm:
                cs = to
        nxt = [(fm, to) for fm, to in self.crane_moves if fm > e]
        if nxt and nxt[0][0] - e == 2:
            self._swap(fr, self.m_crane, self.inb, None)
        elif cs == "B":
            self._swap(fr, self.m_crane, self.B, self.Bd)
        crane_state = "AB" if (nxt and nxt[0][0] - e == 2) else cs
        self.build_storeys(fr, e, crane_state)
        self.grow_stacks(fr, e)
        self.left_side(fr, f)
        self.draw_heap(fr, e)
        self.stage.boil(fr, mask=self.m_work, amp=0.5)
        P.letter_on_quad(fr, ["HERE"], self.plaque, cap=74, color=(0.20, 0.17, 0.15), kind="marker", seed=7,
                         canvas=(380, 150), label="HERE")
        d = self.focus
        self.draw_card(fr, f, self.sign, self.f_china, xy=self.sign_xy, mount="stick", depth=d, stick_len=230)
        self.draw_year(fr, f, depth=d)
        self.draw_card(fr, f, self.card, self.f_card, xy=self.card_xy, depth=d)
        return fr

    def build_storeys(self, fr, e, crane_state):
        """A storey of the scaffold building is added on each build step: a copy of the painted top floor set
        one storey higher (lands a little high and squashed, then settles), behind the crane."""
        n = sum(1 for r in self.rise if e >= r)
        if not n:
            return
        for i in range(1, n + 1):
            k = (e - self.rise[i - 1]) // 2
            extra, sy = {0: (-12.0, 1.06), 1: (2.0, 0.97)}.get(k, (0.0, 1.0))
            paste_copy(fr, self.A0, self.m_storey, -self.storey_dy * i + extra, sy)
        src = {"A": self.A0, "AB": self.inb, "B": self.B}[crane_state]
        self._swap(fr, self.crane_fg[crane_state], src, None)

    def draw_heap(self, fr, e):
        """A heap of grey clay dust in the ruin on the left, a size bigger every second dust step."""
        n = sum(1 for s_ in self.dust_steps if e >= s_)
        if not n:
            return
        hp = self.heaps[min((n - 1) // 2, len(self.heaps) - 1)]
        x, y = self.kp(*HEAP_AT)
        # a soft contact shadow round its foot (ambient occlusion on the ground), wider than the heap itself
        w = hp.rgba.shape[1]
        H, W = fr.rgb.shape[:2]
        x0, x1 = max(int(x - w), 0), min(int(x + w), W)
        y0, y1 = max(int(y - w * 0.4), 0), min(int(y + w * 0.4), H)
        yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
        lx, ly = fr.light
        ao = np.exp(-(((xx - x + lx * 8) / (w * 0.50)) ** 2 + ((yy - y + 1) / (w * 0.07)) ** 2))
        fr.rgb[y0:y1, x0:x1] *= (1 - 0.32 * ao)[..., None]
        P.place(fr, hp, x, y, depth=None, shadow="contact", shadow_opacity=0.45, light_match=0.6, shadow_dist=3,
                shadow_blur=6.0)

    def worker_state(self, e):
        if e < self.f_china:
            return "A"
        return ("A", "A", "AB", "B", "B", "AB")[((e - self.f_china) // 2) % 6]

    def grow_stacks(self, fr, e):
        """Server stacks get one more layer at a time: the stack's painted top band is copied one layer
        higher (it lands a little high and squashed, then settles). Back stacks first, front last."""
        for name in ("mid", "back", "front"):
            m, dy = self.stacks[name]
            for nm, layer, fl in self.layers:
                if nm != name or e < fl - fl % 2:
                    continue
                k = (e - (fl - fl % 2)) // 2
                extra, sy = {0: (-14.0, 1.05), 1: (2.0, 0.96)}.get(k, (0.0, 1.0))
                paste_copy(fr, self.A0, m, -dy * layer + extra, sy)

    def _swap(self, fr, m, rgb, dep):
        mm = m[..., None]
        fr.rgb = fr.rgb * (1 - mm) + rgb * mm
        if dep is not None:
            fr.depth = fr.depth * (1 - m) + dep * m

    def left_side(self, fr, f):
        """Dust settles on the abandoned side in steps; a puff and a tumbleweed roll on "pause"."""
        e = f - f % 2
        n = sum(1 for s in self.dust_steps if e >= s)
        amt = min(n / max(len(self.dust_steps) - 1, 1), 1.0)
        k = (e - self.f_pause) // 2
        if k >= 0:                                       # the tumbleweed rolls a step (half, then all of it)
            roll, ang, dy = (16.0, -20.0, -4.0) if k == 0 else (34.0, -42.0, 0.0)
            move_patch(fr, self.tumble, self.tumble_clean, TUMBLE_C_plate(self), roll, dy, 1.0, -ang)
        if amt > 0:
            m = self.left[..., None] * amt
            lum = fr.rgb.mean(2, keepdims=True)
            dusty = lum * 0.65 + fr.rgb * 0.35
            dusty = dusty * 0.86 + np.float32([0.70, 0.66, 0.62]) * 0.16
            fr.rgb = fr.rgb * (1 - 0.75 * m) + dusty * 0.75 * m
            for i, w in enumerate(self.webs[:int(round(amt * len(self.webs)))]):
                cobweb(fr, w, seed=i)
        if 0 <= k < 4:                                   # cotton-wool dust puff, replaced in sizes
            pf = self.puffs[k]
            cx, cy = self.kp(105, 1540)
            P.place(fr, pf, cx - pf.w / 2 - 8 * k, cy - pf.h * 0.75 - 10 * k, depth=None, shadow="contact",
                    shadow_opacity=0.18, light_match=0.6, opacity=(1.0, 0.95, 0.8, 0.5)[k])

    def focus_for(self, f):
        return self.focus

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        c = self.ctx
        ev = [(self.f_china, "china_sign_workers_start", {"word": "China"}),
              (self.f_pause - 2, "crane_inbetween", {}),
              (self.f_pause, "build_step_dust_puff", {"word": "pause"})]
        ev += [(r, f"storey_{i + 2}", {}) for i, r in enumerate(self.rise[1:])]
        ev += [(self.f_card, "data_card", {"word": "plans"}),
               (c.f("twenty-eight"), "crane_back", {"word": "twenty-eight"}),
               (c.f("gigawatts"), "crane_over", {"word": "gigawatts"})]
        return ev

    def sound(self, snd):
        at = snd.at_frame
        c = self.ctx
        snd.bed(A.room_tone(c.dur + 2.0, seed=71) * 0.6, at(self.f0) - 0.5, -12)
        # left: a dry wind; right: the busy site
        snd.bed(A.whoosh(c.dur + 1.0, seed=72) * 0.35, at(self.f0), -28, -0.6)
        i = 0
        for e in range(self.f_china, self.f1, 2):        # each hand-over: a soft knock as a server lands
            if self.worker_state(e) in ("A", "B") and self.worker_state(e - 2) == "AB":
                snd.sfx(A.wood_knock(seed=200 + i, pitch=1.5 + 0.15 * (i % 3), hard=0.4, dur=0.12), at(e) + 0.01,
                        -30, 0.45)
                snd.sfx(A.squelch(seed=300 + i, dur=0.10, pitch=1.3), at(e) + 0.03, -34, 0.35)
                i += 1
        for nm, layer, fl in self.layers:                # each new layer on a stack: a thunk
            snd.sfx(A.wood_knock(seed=500 + fl, pitch=0.75, hard=0.8, dur=0.22), at(fl + 2), -24, 0.6)
        snd.sfx(A.wood_knock(seed=11, pitch=0.9, hard=0.6, dur=0.25), at(self.f_china), -24, 0.3)
        for fm, _ in self.crane_moves:
            snd.sfx(A.ratchet(0.22, rate=34, seed=fm), at(fm - 2), -27, 0.55)
            snd.sfx(A.string_creak(seed=fm + 1), at(fm), -27, 0.55)
        for j, s_ in enumerate(self.dust_steps[::2]):     # the dust heap grows: a soft dry patter
            if j < len(self.heaps):
                snd.sfx(A.paper_rustle(0.18, seed=600 + j, busy=0.2), at(s_), -36, -0.5)
        for j, r in enumerate(self.rise):                # each new storey: a quick wood knock
            snd.sfx(A.wood_knock(seed=400 + j, pitch=1.0 + 0.12 * j, hard=0.9, dur=0.2), at(r), -20, 0.25)
        snd.sfx(A.paper_rustle(0.45, seed=13, busy=0.5), at(self.f_pause), -24, -0.6)    # tumbleweed
        snd.sfx(A.whoosh(0.5, seed=14), at(self.f_pause), -30, -0.6)
        snd.sfx(A.string_creak(seed=15), at(self.f_card), -30, 0.0)
        snd.sfx(A.paper_flick(seed=16), at(self.f_card + 2), -28, 0.0)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def mirror_fill(rgb, mask):
    """The ground behind an object near the frame's left edge: the ground just right of it, mirrored
    (real gravel texture rather than a smeared inpaint)."""
    xs = np.nonzero(mask.max(0) > 0.05)[0]
    xr = int(xs.max()) + 2
    out = rgb.copy()
    W = rgb.shape[1]
    src_x = np.clip(2 * xr - np.arange(W), 0, W - 1)
    out[:, :xr] = rgb[:, src_x[:xr]]
    return out


def move_patch(fr, mask, clean, origin, dx=0.0, dy=0.0, sy=1.0, angle=0.0):
    """Lift a painted object (soft mask) off the set without leaving a ghost: its old spot shows `clean`,
    the object is redrawn turned (degrees, clockwise), squashed (sy about origin) and shifted."""
    ox, oy = origin
    M = cv2.getRotationMatrix2D((ox, oy), -angle, 1.0)
    M = np.vstack([M, [0, 0, 1]]) @ np.float32([[1, 0, 0], [0, sy, oy * (1 - sy)], [0, 0, 1]])
    M = (M[:2] + np.float32([[0, 0, dx], [0, 0, dy]])).astype(np.float32)
    H, W = mask.shape
    src = fr.rgb.copy()
    moved = cv2.warpAffine(src, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    mm = cv2.warpAffine(mask, M, (W, H), flags=cv2.INTER_LINEAR)[..., None]
    m0 = mask[..., None]
    fr.rgb = (src * (1 - m0) + clean * m0) * (1 - mm) + moved * mm


def paste_copy(fr, src, mask, dy, sy=1.0):
    """Copy the painted patch under `mask` (from src) dy px up/down, squashed by sy about its bottom."""
    ys = np.nonzero(mask.max(1) > 0.05)[0]
    base = float(ys.max())
    M = np.float32([[1, 0, 0], [0, sy, base * (1 - sy) + dy]])
    H, W = mask.shape
    moved = cv2.warpAffine(src, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    mm = cv2.warpAffine(mask, M, (W, H), flags=cv2.INTER_LINEAR)[..., None]
    fr.rgb = fr.rgb * (1 - mm) + moved * mm
    if fr.depth is not None:
        dm = cv2.warpAffine(fr.depth, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        fr.depth = np.maximum(fr.depth, dm * mm[..., 0])


def not_sky(rgb):
    """Soft mask of everything that is not the evening sky (blue-violet, smooth, upper part of the set)."""
    lab = cv2.cvtColor(np.ascontiguousarray(rgb, dtype=np.float32), cv2.COLOR_RGB2LAB)
    H = rgb.shape[0]
    yy = np.arange(H, dtype=np.float32)[:, None] / H
    sky = (lab[..., 2] < -4.0) | ((lab[..., 1] > 8) & (lab[..., 2] < 4) & (yy < 0.38))
    sky &= yy < 0.42
    sky = cv2.morphologyEx(sky.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    return 1.0 - cv2.GaussianBlur(sky.astype(np.float32), (0, 0), 2.0)


def TUMBLE_C_plate(shot):
    return tuple(shot.kp(*TUMBLE_C))


def cobweb(fr, pts, seed=0):
    """A sagging cobweb thread (two or three strands) between points: thin, pale, a little glinting."""
    rng = np.random.default_rng(seed)
    x0, y0 = np.floor(pts.min(0)).astype(int) - 12
    x1, y1 = np.ceil(pts.max(0)).astype(int) + 12
    H, W = fr.rgb.shape[:2]
    x0, y0, x1, y1 = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
    S = 4
    m = np.zeros(((y1 - y0) * S, (x1 - x0) * S), np.uint8)
    for k in range(3):
        sag = rng.uniform(4, 12)
        p = []
        for a, b in zip(pts[:-1], pts[1:]):
            for u in np.linspace(0, 1, 10):
                q = a + (b - a) * u
                p.append(((q[0] - x0) * S, (q[1] - y0 + sag * np.sin(np.pi * u) + k * 3) * S))
        cv2.polylines(m, [np.int32(p)], False, 255, S, cv2.LINE_AA)
    a = cv2.resize(m, (x1 - x0, y1 - y0), interpolation=cv2.INTER_AREA).astype(np.float32)[..., None] / 255 * 0.55
    fr.rgb[y0:y1, x0:x1] = fr.rgb[y0:y1, x0:x1] * (1 - a) + np.float32([0.86, 0.84, 0.82]) * a


def cotton_puff(r, seed=0):
    """A stop-motion dust puff: a tuft of grey cotton wool, r px across-ish (Prop, no text)."""
    rng = np.random.default_rng(seed)
    S = int(r * 2.6)
    a = np.zeros((S, S), np.float32)
    for _ in range(9):
        cx, cy = rng.normal(S / 2, r * 0.35), rng.normal(S * 0.55, r * 0.2)
        rr = r * rng.uniform(0.35, 0.6)
        yy, xx = np.mgrid[0:S, 0:S].astype(np.float32)
        a = np.maximum(a, np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * rr ** 2))))
    fib = P.smooth_noise(S, S, seed + 1, 1.2) * 0.25 + P.smooth_noise(S, S, seed + 2, 4) * 0.2
    a = np.clip((a + fib - 0.30) * 2.2, 0, 0.95)
    shade = np.clip(0.8 + 0.25 * P.smooth_noise(S, S, seed + 3, 6), 0.6, 1.1)
    rgb = np.float32([0.95, 0.92, 0.87]) * shade[..., None]
    return P.Prop(np.dstack([rgb, a]).astype(np.float32), None, text=False, label="dust")


def dust_heap(w, seed=0, light=(0.45, -0.80), base=(0.76, 0.72, 0.66)):
    """A low heap of clay dust, w px wide (Prop, anchor at the middle of its foot): a broad lumpy mound with
    smaller pours slumped against it, an irregular crumbly outline, finger-pressed clay texture and fine grit,
    in the ground's own colour (base)."""
    h = int(w * 0.34)
    pad = 6
    H, W = h + 2 * pad, w + 2 * pad
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    u = (xx - W / 2) / (w / 2)
    lump = P.smooth_noise(H, W, seed, max(w / 14, 2.0)) * 0.9 + P.smooth_noise(H, W, seed + 1, 2.0) * 0.25
    rng0 = np.random.default_rng(seed + 9)
    prof = np.clip(1 - (u / 0.62) ** 2, 0, None) ** 0.7                  # a rounded main mound and
    for _ in range(4):                                                   # smaller pours slumped beside it
        c, r_, hh = rng0.uniform(-0.65, 0.65), rng0.uniform(0.14, 0.30), rng0.uniform(0.25, 0.55)
        prof = prof + hh * np.exp(-((u - c) / r_) ** 2)
    prof = prof / prof.max() * h
    edge = P.smooth_noise(1, W, seed + 4, max(w / 12, 2.0))[0] * 0.8 + P.smooth_noise(1, W, seed + 5, 3.0)[0] * 0.3
    edge = edge / max(float(np.abs(edge).max()), 1e-6)                 # -1..1, smooth bumps, no spikes
    prof = np.clip(prof * (1 + 0.22 * edge[None, :]) + 1.5 * edge[None, :] - 1.0, 0, h)
    top = (H - pad) - prof
    a = np.clip(yy - top + 0.5, 0, 1) * (yy < H - pad + 0.5)
    # crumbs at the foot: a few loose lumps rolled off the heap
    for _ in range(int(w / 18)):
        cx = W / 2 + rng0.uniform(-0.6, 0.6) * w
        cv2.ellipse(a, (int(cx), int(H - pad - 1)), (int(rng0.integers(2, 5)), int(rng0.integers(1, 3))), 0, 0, 360,
                    1.0, -1, cv2.LINE_AA)
    a = cv2.GaussianBlur(a.astype(np.float32), (0, 0), 0.9)
    # the foot sinks into the ground: the last few rows thin out unevenly instead of a ruled bottom edge
    foot = np.clip((H - pad - yy) / 4.0, 0, 1)
    footn = np.clip(0.55 + 0.6 * P.smooth_noise(H, W, seed + 7, 2.0) / 0.3, 0, 1)
    a = a * np.maximum(foot, footn * (yy < H - pad))
    hgt = cv2.GaussianBlur(a, (0, 0), max(w / 14, 2.0)) * h * 0.5 + lump * 1.4 \
        + P.smooth_noise(H, W, seed + 6, 1.0) * 0.5                     # thumb-pressed clay surface
    tone = (1 + 0.08 * P.smooth_noise(H, W, seed + 2, 3.0) + 0.05 * P.smooth_noise(H, W, seed + 3, 1.0))
    basec = np.float32(base)[None, None, :] * tone[..., None]
    rgb = P.shade(hgt, basec, light, strength=1.3, ambient=0.55, spec=0.03, spec_pow=10)
    # darker toward its foot (bounced shade of the ground)
    rgb *= (0.86 + 0.14 * np.clip((H - pad - yy) / max(h * 0.6, 1), 0, 1))[..., None]
    rng = np.random.default_rng(seed)
    for _ in range(int(w / 3)):                                   # fine grit, single specks
        x, y = rng.uniform(pad, W - pad), rng.uniform(0, H - pad)
        if a[int(y), int(x)] > 0.9:
            c = np.float32(base) * rng.uniform(0.45, 0.7)
            rgb[int(y), int(x)] = c
    return P.Prop(np.dstack([rgb, a]).astype(np.float32), hgt, anchor=(W / 2, H - pad), text=False, label="dust")
