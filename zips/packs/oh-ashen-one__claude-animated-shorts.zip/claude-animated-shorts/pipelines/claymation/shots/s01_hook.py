"""Hook: "What if every state banned new data centers?"

Set: y00_hook_key.png (pose A: the crowd shoves the data center up the ramp into the ballot box) and
_poseB.png (pose B: a different camera set-up: it is in the slot, two shovers sprawled on the ramp, the
crowd in the air). B reframes the set, so it is played as a cut inside the shot on "banned".
    "What" ...  the title's clay letters land word by word in the sky, as each word is spoken
    (before)    the data center creeps up the ramp in small shoves, on 2s; the crowd crouches
    "banned"    cut to pose B with a camera knock: crowd in the air
    +2, +4      the slot's lips snap shut over the data center (half shut, then shut with a seam)
Card (from the first word): "This month, 40 of 41 local votes went against data centers" / "CNBC, Nov 4,
2026". Blank placards in both poses are hand-lettered "NOT HERE" and "NO MORE".
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.config import FPS
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot

# the data center and its two shovers in pose A (plate px) and the way up the ramp (unit vector)
LOAD = [(130, 880), (330, 760), (560, 600), (810, 590), (812, 720), (600, 1120), (430, 1330), (130, 1300)]
UP_RAMP = (0.53, -0.85)
CROWD_A = [(0, 1320), (1145, 1300), (1145, 2035), (0, 2035)]
CROWD_B = [(0, 1080), (1145, 1060), (1145, 2035), (0, 2035)]
# pose B: the slot opening and the notch the data center sits in, and the lips that close over them
OPENING = [(352, 600), (380, 568), (930, 566), (985, 590), (985, 652), (352, 655)]
NOTCH = [(486, 628), (802, 628), (802, 772), (486, 772)]
PLACARD_SEEDS = {"A": {"NOT HERE": (200, 1450), "NO MORE": (880, 1310)},     # a point on each blank placard
                 "B": {"NOT HERE": (150, 1210), "NO MORE": (860, 1090)}}
PLACARD_INK = {"NOT HERE": (0.55, 0.12, 0.10), "NO MORE": (0.12, 0.10, 0.11)}
# pose B's placards poke past the safe lines: they are held a little further in (plate px)
PLACARD_NUDGE = {("B", "NOT HERE"): 22.0, ("B", "NO MORE"): -26.0}
# the "NO MORE" placards are narrow: the lettering uses more of the board so the cap stays >= 30 px
PLACARD_GROW = {("A", "NO MORE"): 1.07, ("B", "NO MORE"): 1.07}


CARD_Y = 890                    # output px: the card's top, low enough to clear the data center going in


class Shot(BaseShot):
    light = (-0.45, -0.85)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_ban = c.f("banned")
        self.setup(anchor=(0.5, 0.5), mode="full", switches=[(self.f_ban, "B")])
        self.cam.add_bump(self.f_ban, 2.5, 3.5)
        self.cam.add_bump(self.f_ban + 4, -1.2, 2.4)
        self.load = clay.poly_mask(LOAD, (PH, PW), 14.0)
        self.crowd = {"A": clay.poly_mask(CROWD_A, (PH, PW), 30.0), "B": clay.poly_mask(CROWD_B, (PH, PW), 30.0)}
        B = self.rep.pose("B")
        self.closed, self.closed_d, self.jaw_masks = build_shut(B[0], B[1])
        self.quads = {p: {t: placard_quad(self.rep.pose(p)[0], xy) for t, xy in seeds.items()}
                      for p, seeds in PLACARD_SEEDS.items()}
        for (p, t), g in PLACARD_GROW.items():
            q = self.quads[p][t]
            if q is not None:
                q[:] = q.mean(0) + (q - q.mean(0)) * g
        self.placard_moves = []
        for (p, t), dx in PLACARD_NUDGE.items():
            q = self.quads[p][t]
            if q is None:
                continue
            qc = q.mean(0)
            self.placard_moves.append((p, clay.poly_mask([tuple(v) for v in qc + (q - qc) * 1.22], (PH, PW), 9.0),
                                       tuple(qc), dx))
            q[:, 0] += dx
        safe = self.safe_plate_box(inset=4)                   # keep the lettering inside the safe area
        for qs in self.quads.values():
            for t, q in qs.items():
                if q is not None:
                    q[:, 0] = np.clip(q[:, 0], safe[0], safe[2])
        words = ["What", "if", "every", "state", "banned", "new", "data", "centers?"]
        self.title = P.ClayTitle([["WHAT", "IF", "EVERY"], ["STATE", "BANNED", "NEW"], ["DATA", "CENTERS?"]],
                                 cap=56, x=110, y=246, line_h=1.40, align="center", max_w=838, seed=5,
                                 colors=[P.CLAY_CREAM, P.CLAY_CREAM, P.CLAY_CREAM, P.CLAY_CREAM, P.CLAY_RED,
                                         P.CLAY_CREAM, P.CLAY_YELLOW, P.CLAY_YELLOW], light=self.light)
        self.title.cue([c.f(w) for w in words])
        self.card = P.data_card(["This month,", "40 of 41 local", "votes went", "against data", "centers"],
                                "CNBC, Nov 2026", width=300, cap=31, seed=4, wrap=False, source_kind="body",
                                light=self.light)
        self.f_card = max(self.f0, c.f("What") - 2)
        self.focus_A = self.focus_at(470, 700, "A")
        self.focus_B = self.focus_at(420, 700, "B")

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        k = (f - self.f_ban) // 2
        for p, m, c, dx in self.placard_moves:              # placards first: they then move with the crowd
            if p == st:
                clay.nudge_region(fr, m, c, dx=dx)
        for text, q in self.quads[st].items():
            if q is not None:
                letter(fr, text, q, st)
        if st == "A":
            self.shove(fr, f)
        elif k >= 1:                                       # the slot snaps shut over two exposures
            shut(fr, self.closed, self.closed_d, self.jaw_masks, 0.6 if k == 1 else 1.0)
            if k == 2:
                clay.nudge_region(fr, clay.poly_mask([(300, 420), (1145, 420), (1145, 800), (300, 800)], (PH, PW), 20),
                                  (700, 790), sx=1.01, sy=0.985)
        if st == "B" and k in (0, 1):                     # the crowd still rising at the top of its jump
            clay.nudge_region(fr, self.crowd["B"], (570, 2035), dy=(-12.0 if k == 0 else -5.0))
        self.stage.boil(fr, mask=self.crowd[st], amp=0.45)
        d = self.focus_for(f)
        self.title.draw(fr, f, depth=d, light_match=0.30)
        self.hang_card(fr, f, d)
        return fr

    def hang_card(self, fr, f, d):
        """The data card lowered in on its threads, as draw_card, but with a smaller swing: the card is wide
        and hangs low, so the library's 2.4 degree swing about the thread tops carries it out of the safe
        area on the landing exposures."""
        an = P.lower_in(f, self.f_card, swing=0.9)
        if an is None:
            return
        bx0, by0, bx1, by1 = self.safe_plate_box()
        x = bx1 - self.card.w - 22
        y = float(np.clip(self.op(0, CARD_Y)[1], by0, by1 - self.card.h))
        hung = P.hanging(self.card, -(y + 10), seed=self.ctx.index + 3)
        P.place(fr, hung, x, y + an["dy"], depth=d, shadow="hang", angle=an["angle"],
                origin=(hung.anchor[0] + self.card.w / 2, 0), label=self.card.label)

    def shove(self, fr, f):
        """Pose A: the load creeps up the ramp in uneven shoves on 2s; one pull-back before the cut;
        the crowd crouches for its jump."""
        steps = {}
        pos = 0.0
        for e in range(self.f0, self.f_ban, 2):
            if (e - self.f0) % 6 == 4:
                pos += (3.2, 4.4, 2.6, 5.0)[(e // 6) % 4]
            steps[e] = pos
        e = f - f % 2
        p = steps.get(e, pos)
        if e == self.f_ban - 2:
            p -= 3.0                                        # anticipation: a breath back before the big push
        clay.nudge_region(fr, self.load, (470, 900), dx=UP_RAMP[0] * p, dy=UP_RAMP[1] * p)
        if e >= self.f_ban - 4:
            clay.nudge_region(fr, self.crowd["A"], (570, 2035), sy=0.985)

    def focus_for(self, f):
        return self.focus_A if self.state(f) == "A" else self.focus_B

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        ev = [(self.ctx.f(w), "title_word", {"word": w}) for w in ("What", "every", "state", "new", "centers?")]
        return ev + [(self.f_card, "data_card", {}),
                     (self.f_ban - 2, "shove_anticipation", {}),
                     (self.f_ban, "cut_poseB_crowd_jumps", {"word": "banned"}),
                     (self.f_ban + 2, "slot_half_shut", {}),
                     (self.f_ban + 4, "slot_shut", {})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.crowd(self.ctx.dur + 1.5, seed=3), at(self.f0) - 0.3, -20)
        for e in range(self.f0 + 4, self.f_ban, 6):          # each shove: a creak of the ramp and a squelch
            snd.sfx(A.wood_knock(seed=e, pitch=0.55, hard=0.35, dur=0.25), at(e), -31, -0.2)
            snd.sfx(A.squelch(seed=e + 1, dur=0.16, pitch=0.7), at(e), -32, -0.2)
        for i, w in enumerate(("What", "if", "every", "state", "banned", "new", "data", "centers?")):
            snd.sfx(A.clay_pop(seed=60 + i, pitch=1.3 + 0.08 * (i % 3)), at(self.ctx.f(w)) + 0.02, -32, -0.4 + 0.1 * i)
        snd.sfx(A.string_creak(seed=7), at(self.f_card), -31, 0.4)
        snd.sfx(A.wood_knock(seed=11, pitch=0.6, hard=1.0, dur=0.5), at(self.f_ban), -14, 0.0)
        snd.sfx(A.clay_pop(seed=12, pitch=0.7), at(self.f_ban), -18, 0.1)
        snd.sfx(A.crowd(1.6, seed=13), at(self.f_ban), -19, 0.0)
        snd.sfx(A.wood_knock(seed=14, pitch=1.4, hard=0.8, dur=0.25), at(self.f_ban + 2), -21, 0.1)
        snd.sfx(A.wood_knock(seed=15, pitch=1.15, hard=1.0, dur=0.35), at(self.f_ban + 4), -15, 0.1)
        snd.sfx(A.perc("woodblock", seed=16, pitch=1.0), at(self.f_ban + 4) + 0.01, -22, 0.1)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def build_shut(rgb, depth):
    """Pose B with the slot shut: the lips grown over the notch from both sides (wood copied from each
    lip, meeting at a seam) and the opening closed with wood from the box top just above it.
    Returns (rgb, depth, {"left", "right", "top"} soft masks) so the shutting can be played partially."""
    out, dep = rgb.copy(), depth.copy()
    H, W = rgb.shape[:2]

    def shifted(img, dx, dy):
        M = np.float32([[1, 0, dx], [0, 1, dy]])
        return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)

    seam = 644
    top = clay.poly_mask(OPENING, (H, W), 2.5)
    left = clay.poly_mask([(486, 640), (seam, 640), (seam, 772), (486, 772)], (H, W), 2.0)
    right = clay.poly_mask([(seam, 630), (804, 630), (804, 772), (seam, 772)], (H, W), 2.0)
    src_top = shifted(rgb, 0, 84)
    src_l, src_r = shifted(rgb, 170, 0), shifted(rgb, -190, 0)
    d_top, d_l, d_r = shifted(depth, 0, 84), shifted(depth, 170, 0), shifted(depth, -190, 0)
    for m, s, d in ((top, src_top, d_top), (left, src_l, d_l), (right, src_r, d_r)):
        out = out * (1 - m[..., None]) + s * m[..., None]
        dep = dep * (1 - m) + d * m
    # seams: where the lips meet, and the closed slot's outline (a dark hairline and a lit edge below it)
    sm = np.zeros((H, W), np.float32)
    cv2.line(sm, (seam, 642), (seam + 3, 770), 1.0, 3, cv2.LINE_AA)
    cv2.polylines(sm, [np.int32(OPENING)], True, 0.8, 3, cv2.LINE_AA)
    sm = cv2.GaussianBlur(sm, (0, 0), 1.2)
    out = out * (1 - 0.55 * sm[..., None])
    return out.astype(np.float32), dep.astype(np.float32), {"top": top, "left": left, "right": right}


def shut(fr, closed, closed_d, masks, amount):
    """Play the shutting: amount 1 = shut; below 1 the lips have come part of the way in from each side
    and the lid part of the way down."""
    if amount >= 1:
        m = np.maximum(np.maximum(masks["top"], masks["left"]), masks["right"])
    else:
        H, W = closed.shape[:2]
        xx = np.arange(W, dtype=np.float32)[None, :]
        yy = np.arange(H, dtype=np.float32)[:, None]
        lw = masks["left"] * (xx <= 486 + (644 - 486) * amount)
        rw = masks["right"] * (xx >= 804 - (804 - 644) * amount)
        tp = masks["top"] * (yy <= 566 + (655 - 566) * amount)
        m = np.maximum(np.maximum(lw, rw), tp)
        m = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 1.5)
    fr.rgb = fr.rgb * (1 - m[..., None]) + closed * m[..., None]
    fr.depth = fr.depth * (1 - m) + closed_d * m


def placard_quad(rgb, seed, tol=10):
    """Corners (TL, TR, BR, BL, plate px) of a blank placard, measured from the painting: flood fill from
    a point on it (within `tol`/255 of the seed's colour, lightly blurred copy), hull, four corners."""
    x, y = seed
    x0, y0 = max(x - 260, 0), max(y - 220, 0)
    sub = np.ascontiguousarray(rgb[y0:y + 220, x0:x + 260])
    img = cv2.GaussianBlur((np.clip(sub, 0, 1) * 255).astype(np.uint8), (0, 0), 1.0)
    m = np.zeros((img.shape[0] + 2, img.shape[1] + 2), np.uint8)
    cv2.floodFill(img, m, (x - x0, y - y0), (0, 0, 0), (tol,) * 3, (tol,) * 3,
                  4 | cv2.FLOODFILL_MASK_ONLY | cv2.FLOODFILL_FIXED_RANGE | (255 << 8))
    m = cv2.morphologyEx(m[1:-1, 1:-1], cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    cnt, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    hull = cv2.convexHull(max(cnt, key=cv2.contourArea))
    peri = cv2.arcLength(hull, True)
    quad = None
    for eps in np.linspace(0.01, 0.15, 50):
        ap = cv2.approxPolyDP(hull, eps * peri, True)
        if len(ap) == 4:
            quad = ap[:, 0, :].astype(np.float32)
            break
    if quad is None:
        quad = cv2.boxPoints(cv2.minAreaRect(hull)).astype(np.float32)
    c = quad.mean(0)
    quad = quad[np.argsort(np.arctan2(quad[:, 1] - c[1], quad[:, 0] - c[0]))]
    quad = np.roll(quad, -int(np.argmin(quad.sum(1))), axis=0)
    # pull the corners in a little: the lettering keeps a margin from the placard's rounded edges
    quad = c + (quad - c) * 0.84
    return quad + np.float32([x0, y0])


def letter(fr, text, quad, pose):
    """Hand-letter a placard: two lines of marker/paint, sized so the cap height on screen is >= 31 px."""
    lines = text.split()
    w = float(np.linalg.norm(quad[1] - quad[0]))
    hq = float(np.linalg.norm(quad[3] - quad[0]))
    canvas = (400, int(max(300, 400 * hq / w)))          # a placard narrowed to the safe area gets a taller canvas
    cap = int(np.ceil(31 / (w / canvas[0])))
    P.letter_on_quad(fr, lines, quad, cap=cap, color=PLACARD_INK[text], kind="marker",
                     seed=sum(map(ord, text)) + (0 if pose == "A" else 1), canvas=canvas, label=f"placard {text}")
