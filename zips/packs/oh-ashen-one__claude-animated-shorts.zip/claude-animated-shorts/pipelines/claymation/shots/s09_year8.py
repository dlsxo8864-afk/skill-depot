"""Year 8: "And the data centers wouldn't vanish. They'd move, to places like Abu Dhabi."

Set: y08_move_key.png (pose A: the server queue at the gate, the agent takes a boarding pass) and
_poseB.png (pose B, same framing: the queue one place on, the first server walking out to the plane,
the agent holding a rubber stamp over a pass on the counter).
    "data", "vanish"   the rear of the queue shuffles forward one small step on each beat
    (pause)            the whole queue moves up a place (anticipation, in-between, pose B)
    "move"             the stamp is lifted, then comes down on the pass (camera knock); red ink left
    "move" +2/+6       ABU DHABI is pressed onto the departures board in clay letters
    "places"/"like"    5 GW CAMPUS PLANNED follows on the board's lower slats
    "places", "Abu"    the queue shuffles again (pose B)
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# everything that changes between the poses (key px): the queue, the walker outside, the agent
REGION = [(0, 820), (330, 800), (540, 790), (941, 820), (941, 1180), (640, 1190), (640, 1470), (0, 1470)]
# the rear of the queue (key px), A and B: shuffled on the beats
QUEUE_A = [(0, 860), (200, 900), (362, 958), (366, 1250), (345, 1345), (240, 1350), (90, 1290), (0, 1250)]
QUEUE_B = [(0, 860), (200, 900), (330, 950), (348, 1150), (345, 1345), (240, 1360), (90, 1290), (0, 1250)]
# pose B: the agent's fist and the rubber stamp (key px), and the pass on the counter (TL TR BR BL)
STAMP = [(700, 1040), (760, 1030), (800, 1042), (832, 1052), (838, 1094), (792, 1106), (772, 1142), (700, 1142)]
PASS = [(696, 1149), (764, 1145), (776, 1166), (706, 1171)]
BOARD = (170, 408, 967, 688)        # plate px: the inside of the departures board


class Shot(BaseShot):
    light = (-0.35, -0.85)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_move = c.f("move")
        self.f_sw = c.f("vanish", at="e") + 6                # the big shuffle, in the pause after "vanish."
        self.shuffles_A = [c.f("data"), c.f("vanish")]
        self.shuffles_B = [c.f("places"), c.f("Abu")]
        self.setup(anchor=(0.5, 0.5), region=REGION, switches=[(self.f_sw, "B")],
                   x=track((0, 6.0), (c.dur, -4.0, "inout")), y=track((0, -10.0)))
        self.cam.add_bump(self.f_move, 0.4, 3.4)
        self.cam.add_bump(self.f_sw, -0.8, 1.6)
        self.cam.add_bump(c.f("Dhabi"), 0.3, 2.2)
        sh = (PH, PW)
        self.queue = {"A": clay.poly_mask(self.kp(QUEUE_A), sh, 4.0), "B": clay.poly_mask(self.kp(QUEUE_B), sh, 4.0)}
        self.stamp = clay.poly_mask(self.kp(STAMP), sh, 4.0)
        self.stamp_origin = tuple(self.kp(846, 1072))     # her shoulder
        self.stamp_clean = clean_under(self.rep.pose("B")[0], self.stamp)
        q = np.float32(self.kp(PASS))
        # stamped on "move" and once more, harder, on "Dhabi" (nearly the same spot, a hair turned)
        q2 = (q - q.mean(0)) @ np.float32([[0.9986, 0.052], [-0.052, 0.9986]]).T + q.mean(0) + np.float32([-4, 1])
        self.slams = [(self.f_move, q, gate_ink(seed=81)), (c.f("Dhabi"), q2, gate_ink(seed=83))]
        light = self.light
        # departures board: clay letters pressed onto the slats
        self.row0 = P.ClayTitle([["DEPARTURES"]], cap=32, x=BOARD[0], y=BOARD[1] + 20, align="center",
                                max_w=BOARD[2] - BOARD[0], seed=3, colors=[P.CLAY_CREAM], light=light)
        self.row0.cue([self.f0 - 12])                       # already on the board when the shot starts
        self.row1 = P.ClayTitle([["ABU", "DHABI"]], cap=62, x=BOARD[0], y=BOARD[1] + 92, align="center",
                                max_w=BOARD[2] - BOARD[0], seed=8, colors=[P.CLAY_YELLOW], light=light)
        self.row1.cue([self.f_move + 2, self.f_move + 6])
        self.row2 = P.ClayTitle([["5 GW", "CAMPUS", "PLANNED"]], cap=34, x=BOARD[0], y=BOARD[1] + 206,
                                align="center", max_w=BOARD[2] - BOARD[0], seed=18, colors=[P.CLAY_CREAM],
                                light=light, word_gap=0.6)
        self.row2.cue([c.f("places"), c.f("places") + 4, c.f("like")])
        bx = (BOARD[0] + BOARD[2]) // 2
        self.board_depth = float(np.median(self.rep.pose("A")[1][BOARD[1] + 40:BOARD[3] - 40, bx - 200:bx + 200]))
        self.focus_A = self.focus_at(470, 1150, "A")       # the front server
        self.focus_B = self.focus_at(560, 1150, "B")

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        if st in ("A", "antAB"):
            self.shuffle(fr, f, "A", self.shuffles_A)
        elif st == "B":
            self.shuffle(fr, f, "B", self.shuffles_B)
            self.stamp_down(fr, f)
        self.stage.boil(fr)
        d = self.focus_for(f)
        self.row0.draw(fr, f, depth=self.board_depth, shadow_dist=5, shadow_blur=2.5, shadow_opacity=0.55,
                       light_match=0.25)
        self.row1.draw(fr, f, depth=self.board_depth, shadow_dist=6, shadow_blur=3.0, shadow_opacity=0.55,
                       light_match=0.25)
        self.row2.draw(fr, f, depth=self.board_depth, shadow_dist=5, shadow_blur=2.5, shadow_opacity=0.55,
                       light_match=0.25)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_move, 3.0)])
        return fr

    def shuffle(self, fr, f, pose, beats):
        """The rear of the queue steps forward on each beat: a lift and lean on the beat's exposure,
        then it stays a few px further on (touched clay never lands exactly where it was)."""
        m = self.queue[pose]
        e = f - f % 2
        dx = 0.0
        dy = 0.0
        sy = 1.0
        for i, b in enumerate(beats):
            b -= b % 2
            if e >= b:
                dx += (2.5, 2.0)[i % 2]
            if e == b:
                dy, sy = -6.0, 1.02
            elif e == b + 2:
                dy, sy = 1.0, 0.985
        if dx or dy:
            clay.nudge_region(fr, m, tuple(self.kp(200, 1340)), sy=sy, dx=dx, dy=dy)

    def stamp_down(self, fr, f):
        """Pose B: the stamp lifts (two exposures), slams onto the pass on "move", rebounds, rests; and
        once more on "Dhabi" (the next pass)."""
        for fs, quad, ink in self.slams:
            k = (f - fs) // 2
            if k >= 0:
                wet = 1.0 if k < 3 else 0.3
                P.ink_on_quad(fr, ink, P.STAMP_RED, quad, opacity=0.95, wet=wet, label="gate stamp", text=False)
        for i, (fs, _, _) in enumerate(self.slams):
            k = (f - fs) // 2
            lift = 1.0 if i == 0 else 0.7                    # the second one is quicker, a smaller lift
            # small moves only: a big lift uncovered the inpainted spot behind the stamp, which read as a
            # grey smudge / dust puff. The stretch (sy) and the swing about her shoulder carry the action.
            pose = {-2: (0, -3 * lift, 1.03, 2.0 * lift), -1: (0, -5 * lift, 1.06, 3.0 * lift),
                    0: (-1 * i, 4, 0.94, -1.0), 1: (0, -1, 1.0, 0.5)}.get(k)
            if pose:
                dx, dy, sy, ang = pose
                move_patch(fr, self.stamp, self.stamp_clean, self.stamp_origin, dx, dy, sy, ang)

    def focus_for(self, f):
        return self.focus_A if self.state(f) in ("A", "antAB") else self.focus_B

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        c = self.ctx
        ev = [(b, "queue_shuffle", {"word": w}) for b, w in zip(self.shuffles_A, ("data", "vanish"))]
        ev += [(self.f_sw - 4, "queue_anticipation", {}), (self.f_sw, "queue_poseB", {}),
               (self.f_move - 4, "stamp_lift", {}),
               (self.f_move, "gate_stamp_down", {"word": "move"}),
               (self.f_move + 2, "board_ABU", {}), (self.f_move + 6, "board_DHABI", {}),
               (c.f("places"), "board_5GW", {"word": "places"}), (c.f("like"), "board_PLANNED", {"word": "like"}),
               (c.f("Dhabi"), "second_pass_stamped", {"word": "Dhabi"})]
        ev += [(b, "queue_shuffle", {"word": w}) for b, w in zip(self.shuffles_B, ("places", "Abu"))]
        return ev

    def sound(self, snd):
        at = snd.at_frame
        c = self.ctx
        snd.bed(A.room_tone(c.dur + 2.0, seed=91) * 0.6, at(self.f0) - 0.5, -12)
        snd.sfx(A.bell(784.0, 0.9, seed=92), at(self.f0) + 0.10, -33, 0.5)      # the terminal's chime
        snd.sfx(A.bell(622.3, 1.1, seed=93), at(self.f0) + 0.42, -33, 0.5)
        for i, b in enumerate(self.shuffles_A + self.shuffles_B):        # shuffling feet
            snd.sfx(A.squelch(seed=93 + i, dur=0.14, pitch=0.85 + 0.07 * (i % 3)), at(b), -27, -0.4)
            snd.sfx(A.paper_rustle(0.18, seed=97 + i, busy=0.6), at(b) + 0.06, -31, -0.4)
        snd.sfx(A.squelch(seed=101, dur=0.22, pitch=0.7), at(self.f_sw - 4), -23, -0.2)
        for j in range(3):                                               # the whole queue steps up
            snd.sfx(A.squelch(seed=102 + j, dur=0.12, pitch=0.9 + 0.1 * j), at(self.f_sw) + 0.05 * j, -25, -0.3 + 0.2 * j)
        snd.sfx(A.wood_knock(seed=105, pitch=1.3, hard=0.3, dur=0.15), at(self.f_move - 4), -30, 0.4)
        snd.sfx(A.rubber_stamp(seed=106), at(self.f_move), -12, 0.35)
        snd.sfx(A.wood_knock(seed=107, pitch=0.8, hard=0.9, dur=0.3), at(self.f_move), -20, 0.35)
        f2 = c.f("Dhabi")
        snd.sfx(A.wood_knock(seed=108, pitch=1.35, hard=0.3, dur=0.12), at(f2 - 4), -32, 0.4)
        snd.sfx(A.rubber_stamp(seed=109), at(f2), -15, 0.35)
        for i, f in enumerate([self.f_move + 2, self.f_move + 6, c.f("places"), c.f("places") + 4, c.f("like")]):
            snd.sfx(A.clay_pop(seed=110 + i, pitch=1.2 + 0.08 * (i % 3)), at(f) + 0.02, -30, -0.1 + 0.1 * i)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def clean_under(rgb, mask):
    """What the set looks like behind a painted object (inpainted once from its surroundings), so the
    object can be lifted off its spot without leaving a ghost of itself."""
    m = (cv2.dilate((mask > 0.05).astype(np.uint8), np.ones((9, 9), np.uint8)) * 255)
    img = (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
    out = cv2.inpaint(img, m, 9, cv2.INPAINT_TELEA)
    return out.astype(np.float32) / 255


def move_patch(fr, mask, clean, origin, dx=0.0, dy=0.0, sy=1.0, angle=0.0):
    """Lift a painted object (soft mask) off the set: its old spot shows `clean`, the object is redrawn
    scaled (sy about origin), turned and shifted. Unlike clay.nudge_region it leaves no ghost behind
    (a shared-library gap: nudge_region only covers what the moved object lands on)."""
    ox, oy = origin
    M = cv2.getRotationMatrix2D((ox, oy), -angle, 1.0)
    M = np.vstack([M, [0, 0, 1]]) @ np.float32([[1, 0, 0], [0, sy, oy * (1 - sy)], [0, 0, 1]])
    M = (M[:2] + np.float32([[0, 0, dx], [0, 0, dy]])).astype(np.float32)
    H, W = mask.shape
    src = fr.rgb.copy()
    moved = cv2.warpAffine(src, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    mm = cv2.warpAffine(mask, M, (W, H), flags=cv2.INTER_LINEAR)[..., None]
    m0 = mask[..., None]
    fr.rgb = (src * (1 - m0) + clean * m0) * (1 - mm) + moved * mm
    if fr.depth is not None:
        dm = cv2.warpAffine(fr.depth, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        fr.depth = fr.depth * (1 - mm[..., 0]) + dm * mm[..., 0]


def gate_ink(seed=0, size=120):
    """The gate stamp's impression: a round double ring with a little aeroplane in the middle (no
    letters: the pass is too small for readable text). Ink alpha, uneven like a real stamp."""
    S = 4
    big = np.zeros((size * S, int(size * 1.5) * S), np.uint8)
    h, w = big.shape
    c = (w // 2, h // 2)
    cv2.ellipse(big, c, (int(w * 0.46), int(h * 0.44)), 0, 0, 360, 255, 7 * S, cv2.LINE_AA)
    cv2.ellipse(big, c, (int(w * 0.38), int(h * 0.34)), 0, 0, 360, 255, 3 * S, cv2.LINE_AA)
    # aeroplane: fuselage, wings, tail (seen from above, flying right and a little up)
    rot = cv2.getRotationMatrix2D((0, 0), 18, 1.0)
    def poly(pts):
        p = np.float32(pts) @ rot[:, :2].T
        return np.int32((p * S * 1.1 + np.float32(c)))
    cv2.fillPoly(big, [poly([(-34, -4), (36, -4), (44, 0), (36, 4), (-34, 4)])], 255, cv2.LINE_AA)
    cv2.fillPoly(big, [poly([(-4, -3), (8, -3), (-10, -34), (-18, -34)])], 255, cv2.LINE_AA)
    cv2.fillPoly(big, [poly([(-4, 3), (8, 3), (-10, 34), (-18, 34)])], 255, cv2.LINE_AA)
    cv2.fillPoly(big, [poly([(-34, -3), (-26, -3), (-36, -14), (-40, -14)])], 255, cv2.LINE_AA)
    cv2.fillPoly(big, [poly([(-34, 3), (-26, 3), (-36, 14), (-40, 14)])], 255, cv2.LINE_AA)
    a = cv2.resize(big, (w // S, h // S), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    hh, ww = a.shape
    cover = 0.84 + 0.12 * P.smooth_noise(hh, ww, seed + 1, 7) + 0.06 * P.smooth_noise(hh, ww, seed + 2, 2)
    voids = (P.smooth_noise(hh, ww, seed + 3, 1.3) > 2.0).astype(np.float32)
    return np.clip(a * cover * (1 - 0.7 * voids), 0, 1).astype(np.float32)
