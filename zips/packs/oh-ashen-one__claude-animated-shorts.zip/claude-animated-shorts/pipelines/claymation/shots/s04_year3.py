"""Year 3: "Your power bill would climb more slowly. Data centers drove most of a record price jump on the
biggest grid."

Set: y03_power_key.png (pose A: the family holds its breath under the meter, father holding the bill) and
_poseB.png (pose B: relief: father scratches his head and grins, mother hugs the girl, the boy waves).
    (from the cut)  the meter disc spins in a blur (replacement smears on 2s), the index mark a smudge
    "slowly"        the disc slows from a blur to a crawl over five exposures; the whirr turns to ticks
    (pause)         the family exhales: anticipation, in-between, pose B
    +6              the bill: the printed $310 is struck through and a red $270 stamped on it
    "Data"          data card lowered in on its threads (63% of the PJM capacity price jump)
    (whole shot)    a purple SCENARIO stamp runs up the bill's right half from the first frame the $310 shows
                    (the totals are invented); the bill is too narrow for it across, so it is stamped along
The bill text and stamp are inked on the paper UNDER the father's thumbs: the thumbs are put back over it.
"""
import math

import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif import text as T
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# key px: the family (both paintings)
REGION = [(0, 500), (430, 500), (430, 590), (520, 590), (520, 880), (650, 880), (650, 1450), (0, 1450)]
# plate px: the meter disc (an ellipse seen from above the rim) and its hub
DISC_C, DISC_A, DISC_B = (676.0, 771.0), 166.0, 82.0
HUB_R = 34.0
FAMILY_A = [(0, 940), (600, 860), (700, 1300), (700, 1800), (0, 1800)]
METER = [(450, 410), (860, 380), (870, 1040), (455, 1050)]
# plate px: the bill's corners TL TR BR BL per pose (measured on the paintings)
BILL = {"A": [(321, 1268), (521, 1267), (500, 1530), (311, 1530)],
        "B": [(301, 1280), (469, 1283), (461, 1513), (289, 1516)]}
BILL_W, BILL_H = 200, 262         # flat canvas (about 1 plate px per canvas px)
STEPS_SLOW = [96.0, 58.0, 32.0, 17.0, 9.0]          # degrees per exposure after "slowly", then the crawl
CRAWL = 4.0
FAST = 137.0
SCEN_U = 0.75                 # the SCENARIO stamp's centre across the bill (0 left edge .. 1 right edge)


class Shot(BaseShot):
    light = (-0.75, -0.55)      # the lamp, upper left

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_slow = c.f("slowly.")
        self.f_exhale = self.f_slow + 16
        self.f_bill = self.f_exhale + 6
        self.f_card = c.f("Data") - 2
        self.setup(anchor=(0.5, 0.5), region=REGION, switches=[(self.f_exhale, "B")],
                   zoom=track((0, 1.0), (c.dur, 1.03, "inout")), x=track((0, 6.0), (c.dur, -4.0, "inout")),
                   y=track((0, -16.0), (c.dur, -4.0, "inout")))
        self.cam.add_bump(self.f_exhale, -0.6, 2.0)
        self.cam.add_bump(self.f_bill, 0.5, 3.0)
        self.angles, self.spans = disc_schedule(self.f0, self.f1, self.f_slow)
        self.disc_maps = disc_maps()
        self.meter = clay.poly_mask(METER, (PH, PW), 6.0)
        self.family = clay.poly_mask(FAMILY_A, (PH, PW), 14.0)
        self.inks = bill_inks(verbose=__name__ != "__mp_main__")
        ink, self.scen_col = P.stamp_ink("SCENARIO", P.STAMP_PURPLE, seed=95, cap=30, border=False, kind="clay",
                                         weight=600, angle=0.0, pad=2, double=False)
        self.scen_ink = np.ascontiguousarray(np.rot90(ink))          # reads bottom to top, up the bill
        self.card = P.data_card(["63% of the 2025-26", "capacity price jump", "on PJM, the largest", "US grid"],
                                "PJM market monitor", width=440, cap=32, seed=34, wrap=False, source_kind="body",
                                light=self.light)
        self.card_xy = (402, 124)
        self.focus_A = self.focus_at(230, 1100, "A")      # the bill
        self.focus_B = self.focus_at(230, 1100, "B")

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        e = f - f % 2
        spin_disc(fr, self.disc_maps, self.angles.get(e, 0.0), self.spans.get(e, 0.0))
        if e < self.f_slow + 6:                       # the meter rattles on the wall while it races
            amp = 1.0 if e < self.f_slow else (0.6 if e < self.f_slow + 4 else 0.25)
            k = (e - self.f0) // 2
            clay.nudge_region(fr, self.meter, (650, 1040), dx=amp * (1.6, -1.2, 0.8, -1.5)[k % 4],
                              dy=amp * (-0.8, 0.6, -0.4, 0.9)[k % 4], angle=amp * (0.25, -0.2, 0.12, -0.25)[k % 4])
        self.print_bill(fr, f, st)
        if st == "A" and e < self.f_exhale - 4:      # holding their breath: a tiny tense tremble on 2s
            k = (e - self.f0) // 2
            clay.nudge_region(fr, self.family, (330, 1760), sy=(1.005, 0.998, 1.004, 0.997)[k % 4],
                              sx=(0.998, 1.002, 0.999, 1.002)[k % 4])
        self.stage.boil(fr)
        d = self.focus_for(f)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_exhale, 3.0)])
        self.draw_card(fr, f, self.card, self.f_card, xy=self.card_xy, depth=d)
        return fr

    def print_bill(self, fr, f, pose):
        if pose in BILL:
            q = np.float32(BILL[pose])
        elif pose.startswith("ant"):                  # the outgoing pose leaning away: the A bill
            q = np.float32(BILL[pose[3]])
        else:                                         # the in-between: halfway along
            q = (np.float32(BILL[pose[0]]) + np.float32(BILL[pose[1]])) / 2
        x0, y0 = np.floor(q.min(0)).astype(int) - 4
        x1, y1 = np.ceil(q.max(0)).astype(int) + 5
        before = fr.rgb[y0:y1, x0:x1].copy()
        pr, strike, num = self.inks
        P.ink_on_quad(fr, pr, np.float32(P.INK), q, opacity=0.92, label="bill $310")
        if f >= self.f_bill:
            wet = 1.0 if f < self.f_bill + 4 else 0.2
            P.ink_on_quad(fr, strike, np.float32(P.STAMP_RED), q, opacity=0.9, wet=wet, text=False)
            P.ink_on_quad(fr, num, np.float32(P.STAMP_RED), q, wet=wet, label="bill $270")
        P.ink_on_quad(fr, self.scen_ink, self.scen_col, scen_quad(q, self.scen_ink.shape), opacity=0.95,
                      label="SCENARIO")
        # the thumbs and fingers in front of the paper: put the painting back where it is not paper
        occ = occluder_mask(before, q - [x0, y0])
        fr.rgb[y0:y1, x0:x1] = fr.rgb[y0:y1, x0:x1] * (1 - occ[..., None]) + before * occ[..., None]

    def focus_for(self, f):
        return self.focus_A if self.state(f) in ("A", "antAB") else self.focus_B

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f0, "disc_blur", {}),
                (self.f_slow, "disc_slows", {"word": "slowly."}),
                (self.f_slow + 10, "disc_crawl", {}),
                (self.f_exhale - 4, "exhale_anticipation", {}),
                (self.f_exhale, "exhale_poseB", {}),
                (self.f_bill, "bill_restamped", {}),
                (self.f0, "scenario_on_bill", {}),
                (self.f_card, "data_card", {"word": "Data"})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=71) * 0.5, at(self.f0) - 0.5, -13)
        # the meter: a fast whirr until "slowly", then ticks that space out with the disc
        whirr_t = (self.f_slow - self.f0) / 24 + 0.15
        snd.sfx(A.ratchet(whirr_t + 1.0, rate=34, seed=72, motor=0.6), at(self.f0) - 1.0, -27, 0.25)   # on the effects bus: it carries the event
        snd.sfx(A.hum(whirr_t + 0.3, 92, seed=73) * 0.6, at(self.f0) - 0.3, -30, 0.25)
        t = at(self.f_slow) + 0.15
        gap = 0.07
        while t < at(self.f1) + 0.5:
            snd.sfx(A.tick(seed=int(t * 100), freq=2600), t, -30 - min(8, gap * 10), 0.25)
            gap = min(gap * 1.45, 0.9)
            t += gap
        snd.sfx(A.squelch(seed=74, dur=0.20, pitch=0.7), at(self.f_exhale - 4), -24, -0.3)
        snd.sfx(A.whoosh(0.5, seed=75), at(self.f_exhale) - 0.05, -26, -0.3)
        snd.sfx(A.clay_pop(seed=76, pitch=0.8), at(self.f_exhale), -19, -0.3)
        snd.sfx(A.paper_rustle(0.3, seed=77, busy=1.2), at(self.f_exhale), -24, -0.4)
        snd.sfx(A.rubber_stamp(seed=78), at(self.f_bill), -14, -0.4)
        snd.sfx(A.perc("glock", seed=79, pitch=1.4), at(self.f_bill) + 0.03, -29, -0.4)
        snd.sfx(A.string_creak(seed=80), at(self.f_card), -30, 0.3)
        snd.sfx(A.paper_flick(seed=81), at(self.f_card + 2), -27, 0.3)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def disc_schedule(f0, f1, f_slow):
    """Disc angle (deg) and smear span (deg) per exposure: fast and smeared until "slowly", then five
    slowing exposures, then a crawl. The fast steps are uneven (a hand turns it between photographs)."""
    ang, angles, spans = 0.0, {}, {}
    rng = np.random.default_rng(7)
    k = 0
    for e in range(f0 - f0 % 2, f1 + 2, 2):
        if e < f_slow:
            step, span = FAST * rng.uniform(0.85, 1.15), 220.0
        else:
            i = (e - (f_slow - f_slow % 2)) // 2
            step = STEPS_SLOW[i] if i < len(STEPS_SLOW) else CRAWL
            span = min(220.0, step * 2.0) if step > 12 else 0.0
        ang = (ang + step) % 360
        angles[e], spans[e] = ang, span
        k += 1
    return angles, spans


def disc_maps():
    """Polar coordinates of the disc region (ellipse unsquashed to a unit circle) for the smear."""
    cx, cy = DISC_C
    x0, y0 = int(cx - DISC_A - 6), int(cy - DISC_B - 6)
    x1, y1 = int(cx + DISC_A + 7), int(cy + DISC_B + 7)
    gx, gy = np.meshgrid(np.arange(x0, x1, dtype=np.float32), np.arange(y0, y1, dtype=np.float32))
    u, v = (gx - cx) / DISC_A, (gy - cy) / DISC_B
    r = np.sqrt(u * u + v * v)
    phi = np.arctan2(v, u)
    disc = np.clip((1.0 - r) * DISC_B / 2.0, 0, 1)                       # ~2 px soft rim
    hub = np.clip((np.sqrt((gx - cx) ** 2 + ((gy - cy) * DISC_A / DISC_B * 0.55) ** 2) - HUB_R) / 2.0, 0, 1)
    m = (disc * hub).astype(np.float32)
    return dict(box=(x0, y0, x1, y1), r=r.astype(np.float32), phi=phi.astype(np.float32), m=m)


def spin_disc(fr, mp, angle, span, n=14):
    """Turn the disc to `angle` (deg) with a rotational smear over `span` (deg), and paint the dark index
    mark on its rim. Specular light on the disc smears into rings while it is a blur, as on film."""
    x0, y0, x1, y1 = mp["box"]
    cx, cy = DISC_C
    r, phi, m = mp["r"], mp["phi"], mp["m"]
    src = fr.rgb[y0:y1, x0:x1].copy()
    if span > 1:
        acc = np.zeros_like(src)
        for i in range(n):
            d = math.radians(span * (i / (n - 1) - 0.5))
            sx = (cx + DISC_A * r * np.cos(phi - d) - x0).astype(np.float32)
            sy = (cy + DISC_B * r * np.sin(phi - d) - y0).astype(np.float32)
            acc += cv2.remap(src, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        sm = acc / n
        out = src * (1 - m[..., None]) + sm * m[..., None]
    else:
        out = src.copy()
    # painted on the disc: a bold black index mark and fine graduation ticks round the rim; while the
    # disc is a blur they are averaged over the smear (the mark becomes a grey streak, the ticks a ring)
    n = max(1, int(span / 2.0)) if span > 1 else 1
    mark = np.zeros(r.shape, np.float32)
    ticks = np.zeros(r.shape, np.float32)
    rim = np.clip((0.97 - r) / 0.03, 0, 1)
    band_mark = np.clip((r - 0.50) / 0.05, 0, 1) * rim
    band_tick = np.clip((r - 0.86) / 0.02, 0, 1) * rim
    head = 1.0 if span < 30 else (0.85 if span < 120 else 0.7)
    for i in range(n):
        u = i / (n - 1) if n > 1 else 0.0
        a = math.radians(angle - span * u)
        dphi = np.angle(np.exp(1j * (phi - a)))
        mk = np.clip(1.6 - np.abs(dphi) / math.radians(5.5), 0, 1) * band_mark
        mark = np.maximum(mark, mk * head * (1 - u) ** 1.4)          # a comet: dark head, fading tail
        tk = np.clip(1.0 - np.abs(((dphi + math.radians(6)) % math.radians(12)) - math.radians(6)) / math.radians(1.3), 0, 1)
        ticks += 0.55 * tk * band_tick
    ink = np.clip(np.maximum(mark, ticks / n), 0, 1) * m
    out = out * (1 - 0.88 * ink[..., None]) + np.float32([0.06, 0.04, 0.04]) * 0.88 * ink[..., None]
    fr.rgb[y0:y1, x0:x1] = out


def bill_inks(verbose=False):
    """Ink layers on the flat bill canvas (the top band: the father's thumbs cover the middle): the
    printed total $310, the red strike line through it, and the red stamped $270 below it."""
    W, H = BILL_W, BILL_H
    f_big = T.font("body", T.size_for_cap("body", 34, 900), 900)
    l2 = T.text_alpha("$310", f_big, tracking=-1)
    pr = np.zeros((H, W), np.float32)
    y2, x2 = 8, 3
    _blit(pr, l2, x2, y2)
    pr[4:6, 12:W - 12] = 0.6                                    # a printed rule along the top
    pr = P.ink_alpha(pr, seed=91, density=0.9, bleed=0.45, patchy=0.07)
    strike = np.zeros((H, W), np.float32)
    ys = y2 + l2.shape[0] // 2 + 2
    cv2.line(strike, (x2 - 6, ys + 5), (x2 + l2.shape[1] + 6, ys - 5), 1.0, 5, cv2.LINE_AA)
    strike = P.ink_alpha(strike, seed=92, density=0.92, bleed=0.6, patchy=0.1)
    num, _ = P.stamp_ink("$270", P.STAMP_RED, seed=93, cap=34, border=False, kind="body", weight=900, angle=-5.0,
                         pad=2, double=False)
    nm = np.zeros((H, W), np.float32)
    y3 = y2 + l2.shape[0] + 2
    _blit(nm, num, -6, y3)
    if verbose:
        print("bill canvas", W, H, "$310", l2.shape, "at", (x2, y2), "stamp $270", num.shape, "at", y3)
    return pr, strike, nm


def scen_quad(q, shape):
    """Plate quad (TL TR BR BL) on the bill quad q for the SCENARIO stamp ink at 1:1 (cap stays 30 px):
    centred at SCEN_U across, half way down."""
    tl, tr, br, bl = np.float32(q)
    wq = (np.linalg.norm(tr - tl) + np.linalg.norm(br - bl)) / 2
    hq = (np.linalg.norm(bl - tl) + np.linalg.norm(br - tr)) / 2
    h, w = shape
    u0, u1 = SCEN_U - w / wq / 2, SCEN_U + w / wq / 2
    v0, v1 = 0.5 - h / hq / 2, 0.5 + h / hq / 2

    def at(u, v):
        return (1 - v) * ((1 - u) * tl + u * tr) + v * ((1 - u) * bl + u * br)
    return np.float32([at(u0, v0), at(u1, v0), at(u1, v1), at(u0, v1)])


def occluder_mask(patch, quad, tol=13.0):
    """Inside the bill quad: where the painting is NOT paper (thumbs, fingers), soft 0..1. Paper = close
    in Lab to the quad's median colour."""
    h, w = patch.shape[:2]
    inside = np.zeros((h, w), np.float32)
    cv2.fillConvexPoly(inside, np.round(quad).astype(np.int32), 1.0, cv2.LINE_AA)
    lab = cv2.cvtColor(np.clip(patch, 0, 1).astype(np.float32), cv2.COLOR_RGB2LAB)
    paper = np.median(lab[inside > 0.5], axis=0)
    d = np.sqrt((((lab - paper) * np.float32([0.5, 1.0, 1.0])) ** 2).sum(2))
    occ = (d > tol).astype(np.uint8)
    occ = cv2.morphologyEx(occ, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    occ = cv2.morphologyEx(occ, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    occ = cv2.GaussianBlur(occ.astype(np.float32), (0, 0), 1.5)
    return np.clip(np.maximum(occ, 1 - inside), 0, 1)


def _blit(dst, a, x, y):
    h, w = a.shape
    H, W = dst.shape
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb > xa and yb > ya:
        dst[ya:yb, xa:xb] = np.maximum(dst[ya:yb, xa:xb], a[ya - y:yb - y, xa - x:xb - x])
