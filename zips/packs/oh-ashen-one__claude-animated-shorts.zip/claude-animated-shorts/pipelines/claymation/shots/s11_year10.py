"""Year 10: "By year ten, your photos, your bank and your AI could live in another country."

Set: y10_abroad_key.png (pose A: photos, coins and a speech bubble flying out of a glowing clay phone
along a glowing cable) and _poseB.png (pose B: the same table, the phone dark, one coin left on it, the
cable re-laid, the little objects queued at the data center's door across the sea).

The set is pose B with the cable's neon glow taken out of the painting (a satin clay tube, no halo on the
sea or the table). The travelling objects are pose A's own clay pieces, cut out of the key and posed by
hand on 2s (sprites). Until its word every piece is hidden in the lit phone; on its word it pops out of
the screen top (one exposure, small and squashed), then hops along the cable through three held
positions (two exposures each, shrinking with distance) and goes in at the door:
    "photos"  the three photos, two exposures apart (a little train)
    "bank"    the five coins
    "AI"      the speech bubble goes last; two exposures later the phone screen dims and goes dark
    arrival   once the bubble has reached the door the far end of the cable shows pose B's queue
    "could"   a paper tag comes down on its threads by the YEAR sign; a wooden rubber stamp comes down
              from above over two exposures, presses on "could" and lifts off, leaving SCENARIO
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# the pieces in the key (key px, 941x1672): centre of each clay piece and its group
PIECES = [((570, 556), "photos"), ((526, 704), "photos"), ((673, 900), "photos"),
          ((508, 606), "bank"), ((705, 756), "bank"), ((607, 784), "bank"), ((531, 884), "bank"),
          ((523, 1008), "bank"),
          ((657, 662), "AI")]
PIECE_BOX = (420, 520, 800, 1052)             # key px box the pieces are cut from
# pose B's cable, phone -> data center door (key px, read off the painting)
CABLE = [(413, 1000), (467, 947), (547, 907), (627, 867), (660, 813), (667, 773), (647, 727), (600, 693),
         (533, 660), (513, 627), (527, 593), (567, 573), (607, 553), (653, 533), (680, 513), (684, 488)]
FAR_BOX = (530, 494, 725, 600)                # pose B's queue of little objects at the door (key px)
DOOR_BOX = (664, 455, 724, 494)               # the coin and photo already in the doorway (key px)
SCREEN_BOX = (170, 1040, 770, 1480)          # key px box around the phone's glowing glass in pose A
HOLDS = (0.20, 0.47, 0.76)                    # held positions along the cable (fraction of the path)
STEPS = 1 + 2 * len(HOLDS)                    # exposures for one piece: pop out, then two per held position
STAGGER = 2                                   # exposures between pieces of one group
EMERGE = (430, 1112)                          # key px: the top of the lit screen, where pieces pop out
NEAR = {"photos": 210.0, "bank": 138.0, "AI": 250.0}   # plate px (longest side) of a piece at the phone


class Shot(BaseShot):
    light = (-0.45, -0.8)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_go = {"photos": c.f("photos,"), "bank": c.f("bank"), "AI": c.f("AI")}
        self.f_dark = self.f_go["AI"] + 4
        self.f_could = c.f("could")
        self.f_tag = self.f_could - 8                       # settles (lower_in, 5 exposures) as the stamp lands
        self.setup(anchor=(0.5, 0.5), mode="full", switches=[],
                   zoom=track((0, 1.0), (c.dur, 1.035, "inout")), y=track((0, 10.0), (c.dur, 4.0)))
        self.cam.add_bump(self.f_dark, 0.0, 1.4)
        self.cam.add_bump(self.f_could, 0.8, 2.6)
        a_rgb, a_d, _ = self.rep.pose("A")
        b_rgb, b_d, _ = self.rep.pose("B")
        b_rgb, b_core = deglow_cable(b_rgb, self.fit.s, return_core=True)
        self.b_rgb, self.b_d = b_rgb, b_d
        # pose B with A's lit screen (until the bubble has left) and without its far queue (until it arrives)
        scr = screen_mask(a_rgb, self.kp(SCREEN_BOX[:2]), self.kp(SCREEN_BOX[2:]))[..., None]
        self.lit = b_rgb * (1 - scr) + a_rgb * scr
        self.dim = b_rgb * (1 - scr) + (a_rgb * 0.45 + b_rgb * 0.55) * scr
        self.path = resample(np.float32([self.kp(*p) for p in CABLE]), 120)
        self.clean_far = remove_queue(b_rgb, self.kp(FAR_BOX[:2]), self.kp(FAR_BOX[2:]),
                                      door=(self.kp(*DOOR_BOX[:2]), self.kp(*DOOR_BOX[2:])),
                                      core=b_core, path=self.path, s=self.fit.s)
        self.lit_clean = self.clean_far * (1 - scr) + a_rgb * scr
        self.path = snap_path(self.path, b_core)            # the hops sit on the painted tube itself
        self.pieces = cut_pieces(a_rgb, a_d, [self.kp(*p) for p, _ in PIECES], self.kp(PIECE_BOX[:2]),
                                 self.kp(PIECE_BOX[2:]))
        self.groups = [g for _, g in PIECES]
        self.d_far = float(np.median(b_d[int(self.path[-1][1]) - 4:int(self.path[-1][1]) + 4,
                                         int(self.path[-1][0]) - 4:int(self.path[-1][0]) + 4]))
        self.jit = [clay.Jitter(200 + i, amp=1.4, deg=1.2) for i in range(len(PIECES))]
        self.order = {}
        for g in ("photos", "bank", "AI"):
            idx = [i for i, gg in enumerate(self.groups) if gg == g]
            for k, i in enumerate(idx):
                self.order[i] = self.f_go[g] + 2 * STAGGER * k
        self.f_arrive = max(self.order.values()) + 2 * STEPS
        self.emerge = np.float32(self.kp(*EMERGE))
        self.near = [NEAR[g] / max(pc[0].w, pc[0].h) for pc, g in zip(self.pieces, self.groups)]
        self.tag = P.card(272, 104, "paper", seed=91, light=self.light)
        self.scen_ink, self.scen_col = P.scenario_ink(seed=93, cap=32, angle=-5.0)
        self.stamp = rubber_stamp_prop(self.scen_ink.shape[1] + 22, self.scen_ink.shape[0] + 18, light=self.light)
        self.focus = self.focus_at(600, 760, "A")          # the pieces in the air

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        far_done = f >= self.f_arrive                     # pose B's queue at the door once the bubble is there
        e_dark = self.f_dark - self.f_dark % 2
        if e_dark - 2 <= f < e_dark:                       # one exposure of the screen dimming
            img = self.dim
        elif f < e_dark:
            img = self.lit if far_done else self.lit_clean
        else:
            img = self.b_rgb if far_done else self.clean_far
        fr = self.stage.frame(f, img, self.b_d, None)
        for i, pc in enumerate(self.pieces):
            self.draw_piece(fr, f, i, pc)
        d = self.focus_for(f)
        self.draw_year(fr, f, depth=d)
        e_tag = self.f_tag - self.f_tag % 2
        if e_tag - 2 <= f < e_tag:                         # one lowering pose: the tag coming down, still high
            self.tag_coming(fr, d)
        xy = self.draw_card(fr, f, self.tag, self.f_tag, xy=(606, 140), depth=d)
        if xy is not None:
            x, y = xy
            an = P.lower_in(f, self.f_tag) or {"dy": 0}
            cx, cy = x + self.tag.w / 2, y + an["dy"] + self.tag.h / 2
            if f >= self.f_could:
                h, w = self.scen_ink.shape
                sc = 1.0                                   # full size: cap >= 30 px
                q = [(cx - w * sc / 2, cy - h * sc / 2), (cx + w * sc / 2, cy - h * sc / 2),
                     (cx + w * sc / 2, cy + h * sc / 2), (cx - w * sc / 2, cy + h * sc / 2)]
                wet = 1.0 if f < self.f_could + 4 else 0.25
                P.ink_on_quad(fr, self.scen_ink, self.scen_col, q, wet=wet, label="SCENARIO")
            self.draw_stamp(fr, f, cx, cy, d)
        return fr

    def tag_coming(self, fr, d):
        """The blank tag on its way down, the exposure before it lands: most of a tag-height higher than its
        rest (threads that much shorter), tilted on the swing. Same placement maths as draw_card's hang mount."""
        prop = self.tag
        bx0, by0, bx1, by1 = self.safe_plate_box()
        x, y = self.op(606, 140)
        mx = int(np.ceil(prop.h * np.sin(np.radians(3.2)))) + 3
        x = float(np.clip(x, bx0 + mx, max(bx0 + mx, bx1 - prop.w - mx)))
        y = float(np.clip(y, by0, by1 - prop.h))
        y_up = y - prop.h * 0.62 - 26
        hung = P.hanging(prop, -(y_up + 10), seed=self.ctx.index + 3)
        P.place(fr, hung, x, y_up, depth=d, shadow="hang", angle=3.0, origin=(hung.anchor[0] + prop.w / 2, 0),
                label=prop.label)

    def draw_stamp(self, fr, f, cx, cy, d):
        """The rubber stamp, held from above: high, just above (stretched), pressed (squashed), lifted, gone."""
        ec = self.f_could - self.f_could % 2
        k = (f - f % 2 - ec) // 2
        # (dx, dy, scale, angle): the stamp is pressed onto the hanging tag's face, toward the camera side
        pose = {-2: (60.0, -150.0, 1.30, 6.0), -1: (14.0, -34.0, 1.12, 2.0), 0: (0.0, 0.0, 1.0, -5.0),
                1: (70.0, -170.0, 1.28, 4.0)}.get(k)
        if pose is None:
            return
        dx, dy, sc, ang = pose
        st = self.stamp
        P.place(fr, st, cx + dx, cy + dy, depth=d, shadow="contact" if k == 0 else "hang", scale=sc, angle=ang,
                origin=(st.w / 2, st.h / 2), shadow_opacity=0.42 if k == 0 else 0.25, light_match=0.35,
                shadow_dist=5 if k == 0 else 26, shadow_blur=3.0 if k == 0 else 12.0)

    def draw_piece(self, fr, f, i, pc):
        """Hidden in the phone until its word; pops out of the screen top (one exposure), then three held
        positions along the cable (two exposures each), then in at the door (gone)."""
        prop, (x0, y0), dep = pc
        f_go = self.order[i]
        e = f - f % 2
        k = (e - (f_go - f_go % 2)) // 2
        if k < 0 or k >= STEPS:
            return
        s0 = self.near[i]
        if k == 0:                                         # anticipation: squeezed out of the glass, small
            P.place(fr, prop, float(self.emerge[0]), float(self.emerge[1]), depth=dep, shadow="none",
                    scale=s0 * 0.85, sx=1.14, sy=0.80, light_match=0.0, brightness=(1.0, 1.0),
                    origin=(prop.w / 2, prop.h / 2))
            return
        h = (k - 1) // 2                                   # which held position
        u = HOLDS[h]
        j = int(round(u * (len(self.path) - 1)))
        sc = s0 * (1 - 0.70 * u) / (1 + 0.4 * u)          # perspective: shrinks faster as it goes far
        lift = 0.30 * prop.h * sc                         # riding on top of the cable
        pos = self.path[j] - np.float32([0, lift])
        settle = 2.0 if (k - 1) % 2 == 0 else 0.0          # lands a hair high, then settles
        dx, dy, deg = self.jit[i](f)
        d = dep * (1 - u) + self.d_far * u
        P.place(fr, prop, float(pos[0] + dx * 0.3), float(pos[1] - settle + dy * 0.3), depth=d, shadow="none",
                scale=max(sc, 0.05), angle=(-7 + 14 * ((i + h) % 2)) + deg, light_match=0.0,
                brightness=(1.0, 1.0), origin=(prop.w / 2, prop.h / 2))

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f_go["photos"], "photos_leave", {"word": "photos,"}),
                (self.f_go["bank"], "coins_leave", {"word": "bank"}),
                (self.f_go["AI"], "bubble_leaves", {"word": "AI"}),
                (self.f_dark, "screen_dark", {}),
                (self.f_tag, "tag_lowered", {}),
                (self.f_could, "scenario_stamp", {"word": "could"})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=51) * 0.5, at(self.f0) - 0.5, -14)
        for i in range(len(PIECES)):
            f = self.order[i]
            g = self.groups[i]
            if g == "photos":
                snd.sfx(A.paper_flick(seed=300 + i), at(f), -24, 0.1)
            elif g == "bank":
                snd.sfx(A.perc("glock", seed=310 + i, pitch=1.8 + 0.15 * (i % 3)), at(f), -30, 0.15)
            else:
                snd.sfx(A.clay_pop(seed=320, pitch=1.1), at(f), -20, 0.1)
            for h in range(len(HOLDS)):                    # a soft tick at each hop along the cable
                snd.sfx(A.perc("woodblock", seed=350 + 7 * i + h, pitch=1.6 + 0.2 * h), at(f + 2 + 4 * h), -36, 0.2)
        snd.sfx(A.wood_knock(seed=340, pitch=1.5, hard=0.4, dur=0.2), at(self.f_dark), -26, -0.1)
        snd.sfx(A.string_creak(seed=341), at(self.f_tag), -30, 0.4)
        snd.sfx(A.whoosh(0.25, seed=343), at(self.f_could - 4), -34, 0.4)
        snd.sfx(A.rubber_stamp(seed=342), at(self.f_could), -15, 0.4)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def snap_path(path, core):
    """Move each point of the read-off path onto the centre of the painted tube near it (core pixels grouped
    by their nearest path point), keeping the path's order; gaps are interpolated and smoothed."""
    ys, xs = np.nonzero(core)
    if len(xs) < 10:
        return path
    pts = np.float32(np.stack([xs, ys], 1))[::2]
    near = np.empty(len(pts), np.int64)
    for a in range(0, len(pts), 4096):
        near[a:a + 4096] = np.argmin(((pts[a:a + 4096, None, :] - path[None]) ** 2).sum(2), 1)
    d = np.sqrt(((pts - path[near]) ** 2).sum(1))
    n = len(path)
    out = path.copy()
    ok = np.zeros(n, bool)
    for i in range(n):
        sel = (near == i) & (d < 60)
        if sel.sum() >= 3:
            out[i] = pts[sel].mean(0)
            ok[i] = True
    if ok.sum() < 2:
        return path
    idx = np.arange(n)
    for c in range(2):
        out[:, c] = np.interp(idx, idx[ok], out[ok, c])
    return cv2.GaussianBlur(out.reshape(-1, 1, 2), (1, 9), 0).reshape(-1, 2).astype(np.float32)


def resample(points, n):
    seg = np.sqrt((np.diff(points, axis=0) ** 2).sum(1))
    s = np.concatenate([[0], np.cumsum(seg)])
    t = np.linspace(0, s[-1], n)
    return np.stack([np.interp(t, s, points[:, 0]), np.interp(t, s, points[:, 1])], 1).astype(np.float32)


def _pieces_mask(img):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    return ((r > b + 0.02) & (r > 0.33)).astype(np.uint8)


def cut_pieces(rgb, depth, centres, p0, p1):
    """Cut pose A's clay pieces out of the key: warm (red > blue) components inside the box, one per
    centre (plate px). Returns [(Prop with anchor at its centre, (x, y) centre, depth)]."""
    x0, y0 = int(p0[0]), int(p0[1])
    x1, y1 = int(p1[0]), int(p1[1])
    m = np.zeros(rgb.shape[:2], np.uint8)
    m[y0:y1, x0:x1] = _pieces_mask(rgb[y0:y1, x0:x1])
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    out = []
    for cx, cy in centres:
        i = int(lab[int(cy), int(cx)])
        if i == 0:
            i = 1 + int(np.argmin(((cen[1:] - np.float32([cx, cy])) ** 2).sum(1)))
        mm = (lab == i).astype(np.uint8)
        ff = mm.copy()                                     # fill holes (the photo's picture area)
        cv2.floodFill(ff, np.zeros((mm.shape[0] + 2, mm.shape[1] + 2), np.uint8), (0, 0), 1)
        mm = mm | (1 - ff)
        mm = cv2.dilate(mm, np.ones((3, 3), np.uint8))
        bx, by, bw, bh = cv2.boundingRect(mm)
        pad = 4
        bx, by = max(bx - pad, 0), max(by - pad, 0)
        bw, bh = bw + 2 * pad, bh + 2 * pad
        a = cv2.GaussianBlur(mm[by:by + bh, bx:bx + bw].astype(np.float32), (0, 0), 0.9)
        rgba = np.dstack([rgb[by:by + bh, bx:bx + bw], a]).astype(np.float32)
        ys, xs = np.nonzero(mm[by:by + bh, bx:bx + bw])
        ccx, ccy = float(xs.mean()), float(ys.mean())
        d = float(np.median(depth[by:by + bh, bx:bx + bw][mm[by:by + bh, bx:bx + bw] > 0]))
        out.append((P.Prop(rgba, None, anchor=(ccx, ccy), text=False, label="piece"), (bx + ccx, by + ccy), d))
    return out


def remove_queue(rgb, p0, p1, door=None, core=None, path=None, s=1.0):
    """Pose B without the little queue of objects at the door. The objects (gold coins, grey photos, the
    bubble) are filled with the light around them plus wave/sand texture borrowed from beside them; the
    cable under them is laid again as a satin clay tube along `path` (plate px), snapped onto the painted
    tube (`core`) wherever it shows."""
    x0, y0 = int(p0[0]), int(p0[1])
    x1, y1 = int(p1[0]), int(p1[1])
    m = np.zeros(rgb.shape[:2], np.uint8)
    sub = rgb[y0:y1, x0:x1]
    mx, mn = sub.max(2), sub.min(2)
    grey = ((mx - mn) < 0.22 * np.maximum(mx, 1e-3) + 0.04) & (mx > 0.42)        # photos and bubble
    m[y0:y1, x0:x1] = _pieces_mask(sub) | grey.astype(np.uint8)
    if door is not None:                       # the coin and photo already in the doorway: by colour only
        (dx0, dy0), (dx1, dy1) = door
        dx0, dy0, dx1, dy1 = int(dx0), int(dy0), int(dx1), int(dy1)
        d = rgb[dy0:dy1, dx0:dx1]
        dmx, dmn = d.max(2), d.min(2)
        gold = (d[..., 0] > 0.6) & (d[..., 2] < 0.32) & (d[..., 0] - d[..., 2] > 0.45)
        card = (dmx > 0.78) & (dmx - dmn < 0.25)
        m[dy0:dy1, dx0:dx1] |= (gold | card).astype(np.uint8)
    m = cv2.dilate(m, np.ones((5, 5), np.uint8))
    if core is not None:
        m = m & (1 - core)
    img = (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
    if core is None or path is None:
        return cv2.inpaint(img, m, 5, cv2.INPAINT_TELEA).astype(np.float32) / 255
    # 1) the sea and sand without the objects AND without the tube (so no cyan is smeared into the holes)
    box = np.zeros_like(m)
    box[y0 - 40:y1 + 10, x0 - 10:x1 + 40] = 1
    tub = cv2.dilate(core & box, np.ones((5, 5), np.uint8))
    out = cv2.inpaint(img, m | tub, 5, cv2.INPAINT_TELEA).astype(np.float32) / 255
    out = rgb * (1 - box[..., None]) + out * box[..., None]
    # 2) the tube's centre line: core pixels in the box, grouped by the nearest point of the read-off path
    ys, xs = np.nonzero(core & box)
    pts = np.float32(np.stack([xs, ys], 1))
    near = np.argmin(((pts[:, None, :] - path[None, :, :]) ** 2).sum(2), 1)
    n = len(path)
    cen = np.zeros((n, 2), np.float32)
    wid = np.zeros(n, np.float32)
    ok = np.zeros(n, bool)
    dti = cv2.distanceTransform(core, cv2.DIST_L2, 5)
    for i in range(n):
        sel = near == i
        if sel.sum() >= 3:
            cen[i] = pts[sel].mean(0)
            wid[i] = 2 * float(dti[ys[sel], xs[sel]].max())
            ok[i] = True
    if ok.sum() < 2:
        return out
    idx = np.arange(n)
    lo, hi_ = idx[ok].min(), idx[ok].max()
    for c in range(2):
        cen[:, c] = np.interp(idx, idx[ok], cen[ok, c])
    wid = np.interp(idx, idx[ok], wid[ok])
    cen = cv2.GaussianBlur(cen.reshape(-1, 1, 2), (1, 7), 0).reshape(-1, 2)
    # 3) lay the tube again: a satin clay tube, lit from the upper left
    H, W = m.shape
    tube = np.zeros((H, W), np.float32)
    hl = np.zeros((H, W), np.float32)
    for i in range(lo, hi_):
        a = tuple(int(round(v)) for v in cen[i])
        b = tuple(int(round(v)) for v in cen[i + 1])
        wd = max(int(round(wid[i])), 2)
        cv2.line(tube, a, b, 1.0, wd, cv2.LINE_AA)
        cv2.line(hl, (a[0] - 1, a[1] - 1), (b[0] - 1, b[1] - 1), 1.0, max(wd // 3, 1), cv2.LINE_AA)
    tube = cv2.GaussianBlur(tube, (0, 0), 0.7) * box
    hl = cv2.GaussianBlur(hl, (0, 0), 0.8) * tube
    col = np.float32([0.27, 0.55, 0.86]) * 0.68 + hl[..., None] * np.float32([0.12, 0.18, 0.16])
    out = out * (1 - tube[..., None]) + col * tube[..., None]
    return out


def screen_mask(rgb, p0, p1):
    """Soft mask of pose A's glowing glass: the bright cream area inside the box, holes filled."""
    x0, y0 = int(p0[0]), int(p0[1])
    x1, y1 = int(p1[0]), int(p1[1])
    r, g = rgb[..., 0], rgb[..., 1]
    m = np.zeros(rgb.shape[:2], np.uint8)
    m[y0:y1, x0:x1] = ((r[y0:y1, x0:x1] > 0.80) & (g[y0:y1, x0:x1] > 0.66)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    m = (lab == 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))).astype(np.uint8)
    ff = m.copy()
    cv2.floodFill(ff, np.zeros((m.shape[0] + 2, m.shape[1] + 2), np.uint8), (0, 0), 1)
    m = cv2.dilate(m | (1 - ff), np.ones((9, 9), np.uint8))
    return cv2.GaussianBlur(m.astype(np.float32), (0, 0), 4.0)


def deglow_cable(rgb, s=1.0, return_core=False):
    """Take the neon glow out of the painted cable: the halo on the sea and the table is replaced by the
    surrounding light (low frequencies filled in from outside, the texture kept), and the white-hot core
    becomes a satin light-blue clay tube shaded across its width. s = plate px per key px."""
    rgb = np.ascontiguousarray(rgb, dtype=np.float32)
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    core = ((g > 0.62) & (b > 0.80) & (g - r > 0.25)).astype(np.uint8)
    core = cv2.morphologyEx(core, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(core)
    keep = np.zeros_like(core)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] > 30 * s * s:
            keep[lab == i] = 1
    core = cv2.morphologyEx(keep, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    hot = ((g > 0.80) & (b > 0.85)).astype(np.uint8)              # the white-hot middle of the tube
    for _ in range(3):
        core = core | (cv2.dilate(core, np.ones((3, 3), np.uint8)) & hot)
    rad = int(round(22 * s))
    zone = cv2.dilate(core, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * rad + 1, 2 * rad + 1)))
    # glow the distance test misses (where the core is hidden behind the little objects): cyan light
    cyan = ((g > 0.50) & (b > 0.70) & (g - r > 0.28) & (core == 0)).astype(np.uint8)
    cyan = cv2.morphologyEx(cyan, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    zone = zone | cv2.dilate(cyan, np.ones((int(9 * s) | 1, int(9 * s) | 1), np.uint8))
    sig = 5.0 * s
    low = cv2.GaussianBlur(rgb, (0, 0), sig)
    detail = rgb - low
    q = 4
    small = cv2.resize(rgb, None, fx=1 / q, fy=1 / q, interpolation=cv2.INTER_AREA)
    zs = cv2.resize(cv2.dilate(zone, np.ones((5, 5), np.uint8)), (small.shape[1], small.shape[0]),
                    interpolation=cv2.INTER_NEAREST)
    fill = cv2.inpaint((np.clip(small, 0, 1) * 255).astype(np.uint8), zs, 5, cv2.INPAINT_TELEA)
    fill = cv2.resize(fill.astype(np.float32) / 255, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_CUBIC)
    fill = cv2.GaussianBlur(fill, (0, 0), sig)
    dt = cv2.distanceTransform((1 - core).astype(np.uint8), cv2.DIST_L2, 5)
    w = np.clip(1.0 - (dt - rad * 0.8) / (rad * 0.4), 0, 1) * (core == 0)
    w = np.maximum(w, cv2.dilate(cyan, np.ones((5, 5), np.uint8)).astype(np.float32))
    bluish = np.clip((b - np.maximum(r, 0.0) - 0.10) / 0.15, 0, 1)   # glow lies on sea / tinted wood, not on the
    w = w * cv2.GaussianBlur(bluish.astype(np.float32), (0, 0), 1.5 * s)   # little gold and grey objects
    w = cv2.GaussianBlur(w.astype(np.float32), (0, 0), 2.0 * s)[..., None]
    out = rgb * (1 - w) + np.clip(fill + detail * 0.8, 0, 1) * w
    dti = cv2.distanceTransform(core, cv2.DIST_L2, 5)
    k = int(9 * s) | 1
    prof = np.clip(dti / (cv2.dilate(dti, np.ones((k, k), np.uint8)) + 1e-3), 0, 1)
    gx = cv2.Sobel(dti, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(dti, cv2.CV_32F, 0, 1, ksize=3)
    nn = np.sqrt(gx * gx + gy * gy) + 1e-3
    lit = np.clip(0.5 + 0.5 * ((gx * 0.55 + gy * 0.75) / nn) * (1 - prof), 0, 1)
    tube = np.float32([0.27, 0.55, 0.86]) * (0.50 + 0.35 * prof + 0.20 * lit)[..., None]
    tube = tube + (prof ** 6 * 0.10)[..., None] + detail * 0.5
    cm = cv2.GaussianBlur(core.astype(np.float32), (0, 0), 0.8)[..., None]
    out = (out * (1 - cm) + np.clip(tube, 0, 1) * cm).astype(np.float32)
    return (out, core) if return_core else out


def _over(dst, src, x, y):
    h, w = src.shape[:2]
    a = src[..., 3:4]
    reg = dst[y:y + h, x:x + w]
    oa = a + reg[..., 3:4] * (1 - a)
    rgb = (src[..., :3] * a + reg[..., :3] * reg[..., 3:4] * (1 - a)) / np.maximum(oa, 1e-4)
    dst[y:y + h, x:x + w] = np.concatenate([rgb, oa], 2)


def rubber_stamp_prop(w, h, light=(-0.45, -0.8), seed=97):
    """A wooden office rubber stamp seen from behind (pressed against a surface facing the camera): the pine
    block's back with a dark rubber rim showing at its edges, and the red clay knob of the handle pointing
    at the camera (Prop, anchor at the block's centre)."""
    rim = 5
    W, H = w + 2 * rim, h + 2 * rim
    can = np.zeros((H, W, 4), np.float32)
    rub = np.zeros((H, W, 4), np.float32)
    rub[..., :3] = np.float32([0.22, 0.16, 0.24])
    rub[..., 3] = cv2.resize(P.wood_plank(W, H, seed=seed + 5, light=light).rgba[..., 3], (W, H))
    _over(can, rub, 0, 0)
    blk = P.wood_plank(w, h, seed=seed, light=light, bevel=7).rgba
    blk = cv2.resize(blk, (w, h), interpolation=cv2.INTER_AREA)
    _over(can, blk, rim, rim - 2)
    knob = int(min(h * 0.9, 60))
    yy, xx = np.mgrid[0:knob, 0:knob].astype(np.float32)
    rr = ((xx - knob / 2 + 0.5) ** 2 + (yy - knob / 2 + 0.5) ** 2) / (knob / 2) ** 2
    hgt = np.sqrt(np.clip(1 - rr, 0, 1)) * knob * 0.45 + P.smooth_noise(knob, knob, seed + 2, 2.0) * 0.6
    a = np.clip((1 - rr) * knob / 3, 0, 1)
    kn = P.shade(hgt, P.CLAY_RED, light, strength=1.0, ambient=0.45, spec=0.10)
    # the knob's own soft shadow on the block (down-right of it, away from the light)
    sh = np.zeros((H, W), np.float32)
    kx, ky = (W - knob) // 2, (H - knob) // 2
    sh[ky + 5:ky + 5 + knob, kx + 4:kx + 4 + knob] = a
    sh = cv2.GaussianBlur(sh, (0, 0), 4.0) * 0.45 * can[..., 3]
    can[..., :3] *= (1 - sh)[..., None]
    _over(can, np.dstack([kn, a]).astype(np.float32), kx, ky)
    return P.Prop(can, None, anchor=(W / 2, H / 2), text=False, label="stamp")
