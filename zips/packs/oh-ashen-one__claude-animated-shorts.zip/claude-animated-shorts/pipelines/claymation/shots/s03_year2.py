"""Year 2: "Then the cloud would cost more. Only one point four percent of data center space is empty."

Set: y02_cloud_key.png (pose A: auctioneer with the gavel up, the room bidding) and _poseB.png (pose B: the
gavel slammed down, eyes screwed shut, every paddle and fan thrust higher).
    (from the cut)  the room bids: paddles and card fans bob on 2s, out of step with each other
    "cloud"         the BID board hung on the empty rack flips up a card ($9 -> $12)
    "cost"          ... and again ($12 -> $15)
    "more" -4       up-pose: the auctioneer rears up and cocks the gavel higher (held two exposures)
    "more"          gavel slams (the auctioneer cuts straight to pose B: a strike has no in-between), camera
                    knock, the board flips to $19 and swings on its threads; the room holds one exposure
    "more" +4       the crowd swaps to pose B and jumps; the lettered paddle now says $19
    +8              SCENARIO stamped on the BID board (the bids are invented)
    "Only"          data card lowered in on its threads: "Empty data center space: 1.4%, a record low"
    "empty"         a small knock: the empty rack rattles on the velvet
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# key px: the auctioneer and the whole crowd (everything that differs between the paintings)
REGION = [(0, 380), (445, 380), (455, 760), (941, 740), (941, 1672), (0, 1672)]
# plate px: a point on the blank face of the paddle we letter, per pose
PADDLE_SEED = {"A": (410, 1405), "B": (470, 1290)}
# plate px: things that bob while the room bids (pose A), each with its own phase
BOBS = [([(300, 1290), (520, 1300), (520, 1600), (300, 1600)], (410, 1600), 0),          # lettered paddle
        ([(225, 975), (370, 975), (370, 1130), (225, 1130)], (300, 1130), 1),            # left fan
        ([(420, 1085), (540, 1080), (540, 1200), (420, 1200)], (480, 1200), 3),          # small fan
        ([(600, 1200), (810, 1200), (810, 1380), (600, 1380)], (700, 1380), 2),          # centre fan
        ([(770, 1330), (930, 1330), (930, 1520), (770, 1520)], (850, 1520), 1),          # right fan
        ([(830, 1095), (1015, 1095), (1015, 1290), (830, 1290)], (920, 1290), 0)]        # right paddle
CROWD_B = [(0, 900), (1145, 900), (1145, 2035), (0, 2035)]
# plate px: the auctioneer above the podium top (pose A and B), his body for the up-pose, the gavel arm
AUCT = [(0, 380), (520, 380), (520, 862), (0, 862)]
AUCT_BODY = [(0, 520), (480, 450), (500, 866), (0, 866)]
GAVEL_ARM = [(392, 470), (530, 470), (530, 700), (450, 800), (374, 792), (374, 690), (386, 640)]
RACK = [(640, 340), (920, 340), (920, 1030), (640, 1030)]
BOARD_XY = (646, 600)          # plate px top-left of the BID board hung in the rack
BIDS = ["$9", "$12", "$15", "$19"]


class Shot(BaseShot):
    light = (-0.15, -0.95)      # the spotlight is above the rack
    dof = {"scale": 0.8}

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_cloud = c.f("cloud")
        self.f_cost = c.f("cost")
        self.f_more = c.f("more.")
        self.f_up = self.f_more - 4                     # the up-pose, held for two exposures
        self.f_crowd = self.f_more + 4                  # the room reacts one held exposure after the slam
        self.f_scen = self.f_more + 8
        self.f_card = c.f("Only") - 2
        self.f_empty = c.f("empty.")
        self.setup(anchor=(0.5, 0.5), region=REGION, switches=[(self.f_more, "B", {"ant": False, "inb": False})],
                   zoom=track((0, 1.0), (c.dur, 1.035, "inout")), x=track((0, 0.0), (c.dur, 10.0, "inout")),
                   y=track((0, -10.0)))
        self.cam.add_bump(self.f_more, 0.8, 5.0)
        self.cam.add_bump(self.f_more + 2, -0.4, -1.6)
        self.cam.add_bump(self.f_scen, 0.3, 1.8)
        self.cam.add_bump(self.f_empty, -0.6, 1.0)
        self.bobs = [(clay.poly_mask(p, (PH, PW), 10.0), o, ph) for p, o, ph in BOBS]
        self.crowd_b = clay.poly_mask(CROWD_B, (PH, PW), 30.0)
        self.auct = clay.poly_mask(AUCT, (PH, PW), 5.0)
        self.auct_body = clay.poly_mask(AUCT_BODY, (PH, PW), 14.0)
        self.gavel_arm = clay.poly_mask(GAVEL_ARM, (PH, PW), 6.0)
        self.rack = clay.poly_mask(RACK, (PH, PW), 4.0)
        self.quads = {p: paddle_quad(self.rep.pose(p)[0], xy) for p, xy in PADDLE_SEED.items()}
        self.flip = P.FlipNumber(BIDS, [self.f_cloud, self.f_cost, self.f_more], cap=50, seed=21,
                                 light=self.light)
        self.scen_ink = P.stamp_ink("SCENARIO", P.STAMP_PURPLE, seed=23, cap=30, border=True, kind="clay",
                                    weight=600, angle=-5.0, pad=2, double=False)
        self.boards = {}
        self.card = P.data_card(["Empty data center", "space: 1.4%,", "a record low"], "CBRE, 2026",
                                width=400, cap=33, seed=25, wrap=False, source_kind="body", light=self.light)
        self.card_xy = (70, 236)
        # focus between the auctioneer and the lettered paddle, so the bid on it still reads
        self.focus_A = 0.5 * self.focus_at(230, 560, "A") + 0.5 * self.focus_at(340, 1150, "A")
        self.focus_B = 0.5 * self.focus_at(170, 590, "B") + 0.5 * self.focus_at(385, 1060, "B")
        if __name__ != "__mp_main__":
            print("focus A/B", round(self.focus_A, 3), round(self.focus_B, 3), "auctioneer",
                  round(self.focus_at(230, 560, "A"), 3), "paddle", round(self.focus_at(340, 1150, "A"), 3))

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        k = (f - self.f_crowd) // 2
        if st == "A":
            self.letter_paddle(fr, "A", "$12")
            if f < self.f_up:
                self.bid(fr, f)
            else:                                              # up-pose: rears up, gavel cocked high
                clay.nudge_region(fr, self.auct_body, (240, 866), sy=1.022, dy=-2.0)
                clay.nudge_region(fr, self.gavel_arm, (380, 760), dx=-4.0, dy=-18.0, angle=-6.0)
        elif f < self.f_crowd:                                 # slammed; the room still holds pose A
            a = self.rep.pose("A")
            m = self.auct[..., None]
            fr.rgb[:] = fr.rgb * m + a[0] * (1 - m)
            fr.depth[:] = fr.depth * self.auct + a[1] * (1 - self.auct)
            self.letter_paddle(fr, "A", "$12")
        else:
            self.letter_paddle(fr, "B", "$19")
            if k in (0, 1):                                    # the room jumps, one exposure after the slam
                clay.nudge_region(fr, self.crowd_b, (570, 2035), dy=(-11.0 if k == 0 else -4.0))
        ke = (f - self.f_empty) // 2
        if ke in (0, 1):                                       # the empty rack rattles
            clay.nudge_region(fr, self.rack, (780, 1030), dx=(2.0 if ke == 0 else -1.0), angle=(0.4 if ke == 0 else -0.15))
        self.stage.boil(fr)
        d = self.focus_for(f)
        self.draw_board(fr, f, d)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_more, 4.0)])
        self.draw_card(fr, f, self.card, self.f_card, xy=self.card_xy, depth=d)
        return fr

    def bid(self, fr, f):
        """Pose A: paddles and fans bob on 2s, each on its own count, like a room bidding."""
        e = (f - self.f0) // 2
        for m, o, ph in self.bobs:
            s = (e + ph) % 4
            dy = (-9.0, -3.0, 2.0, 0.0)[s] * (1.4 if f >= self.f_cost - 2 else 1.0)
            clay.nudge_region(fr, m, o, dy=dy, angle=(-0.6, 0.0, 0.4, 0.0)[s])

    def letter_paddle(self, fr, pose, text):
        q = self.quads.get(pose)
        if pose == "AB":
            q = None if self.quads["A"] is None or self.quads["B"] is None else (self.quads["A"] + self.quads["B"]) / 2
        if q is None:
            return
        P.letter_on_quad(fr, [text], q, cap=100, color=P.INK, kind="marker", seed=31 + (pose == "B"),
                         canvas=(250, 215), label=f"paddle {text}")

    def board(self, f):
        """The BID board: a little plank with 'BID' painted on, the flip number pinned to it, and the
        SCENARIO stamp from f_scen. Cached per (card state, stamped)."""
        flip = self.flip.prop(f)
        key = (flip.label, id(flip), f >= self.f_scen)
        if key in self.boards:
            return self.boards[key]
        W, H = max(236, self.scen_ink[0].shape[1] + 16), 226
        pl = P.wood_plank(W, H, seed=27, light=self.light, color=(0.84, 0.77, 0.62))   # cream-painted board
        rgba = pl.rgba.copy()
        f_lab = P.T.font("clay", P.T.size_for_cap("clay", 32, 700), 700)
        lab = P.T.text_alpha("BID", f_lab, tracking=3)
        P._ink_into(rgba, P.ink_alpha(lab, 28, density=0.95, bleed=0.6), np.float32(P.STAMP_RED) * 0.9,
                    (rgba.shape[1] - lab.shape[1]) / 2, 14)
        P._over_rgba(rgba, flip.rgba, (rgba.shape[1] - flip.w) / 2, 62)
        if f >= self.f_scen:
            ink, col = self.scen_ink
            P._ink_into(rgba, ink, col, (rgba.shape[1] - ink.shape[1]) / 2, rgba.shape[0] - ink.shape[0] - 12)
        pr = P.Prop(rgba, None, anchor=pl.anchor, label=f"BID {flip.label}", textbox=(0, 0, rgba.shape[1], rgba.shape[0]))
        self.boards[key] = pr
        return pr

    def draw_board(self, fr, f, d):
        b = self.board(f)
        x, y = BOARD_XY
        ang = 0.0
        for fk, deg in ((self.f_cloud, 1.2), (self.f_cost, 1.4), (self.f_more, 5.0), (self.f_scen, 1.5)):
            k = (f - (fk - fk % 2)) // 2
            if 0 <= k < 7:
                ang += deg * (0.6 ** k) * (1 if k % 2 == 0 else -1)
        hung = P.hanging(b, -(y - 470), seed=29)
        P.place(fr, hung, x, y, depth=d, shadow="hang", angle=ang, origin=(hung.anchor[0] + b.w / 2, 0),
                light_match=0.5, label=b.label, shadow_dist=14)

    def focus_for(self, f):
        return self.focus_A if self.state(f) in ("A", "antAB") else self.focus_B

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f_cloud, "bid_flip_12", {"word": "cloud"}),
                (self.f_cost, "bid_flip_15", {"word": "cost"}),
                (self.f_up, "gavel_up_pose", {}),
                (self.f_more, "gavel_slam_poseB", {"word": "more."}),
                (self.f_crowd, "crowd_poseB_jumps", {}),
                (self.f_scen, "scenario_stamp", {}),
                (self.f_card, "data_card", {"word": "Only"}),
                (self.f_empty, "rack_rattle", {"word": "empty."})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.crowd(self.ctx.dur + 2.0, seed=41) * 0.6, at(self.f0) - 0.5, -24)
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=42) * 0.5, at(self.f0) - 0.5, -14)
        for e in range(self.f0 + 2, self.f_more - 4, 4):        # paddles flapping up as the room bids
            snd.sfx(A.paper_flick(seed=e), at(e), -31, ((e // 4) % 3 - 1) * 0.4)
        for i, fk in enumerate((self.f_cloud, self.f_cost)):
            snd.sfx(A.paper_flick(seed=50 + i), at(fk), -22, 0.35)
            snd.sfx(A.perc("woodblock", seed=52 + i, pitch=1.2 + 0.15 * i), at(fk) + 0.01, -28, 0.35)
        snd.sfx(A.squelch(seed=55, dur=0.18, pitch=0.9), at(self.f_up), -24, -0.5)
        snd.sfx(A.wood_knock(seed=56, pitch=0.55, hard=1.0, dur=0.55), at(self.f_more), -11, -0.45)
        snd.sfx(A.perc("woodblock", seed=57, pitch=0.8), at(self.f_more) + 0.005, -20, -0.45)
        snd.sfx(A.crowd(1.4, seed=58), at(self.f_crowd) + 0.01, -17, 0.0)
        snd.sfx(A.paper_rustle(0.4, seed=59, busy=1.6), at(self.f_crowd), -21, 0.2)
        snd.sfx(A.paper_flick(seed=60), at(self.f_crowd) + 0.02, -22, 0.35)
        snd.sfx(A.string_creak(seed=61), at(self.f_more + 2), -27, 0.35)
        snd.sfx(A.rubber_stamp(seed=62), at(self.f_scen), -16, 0.35)
        snd.sfx(A.string_creak(seed=63), at(self.f_card), -30, -0.4)
        snd.sfx(A.paper_flick(seed=64), at(self.f_card + 2), -27, -0.4)
        snd.sfx(A.wood_knock(seed=65, pitch=1.3, hard=0.5, dur=0.25), at(self.f_empty), -26, 0.3)
        snd.sfx(A.perc("glock", seed=66, pitch=1.6), at(self.f_empty) + 0.02, -31, 0.3)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def paddle_quad(rgb, seed, tol=9):
    """Corners (TL, TR, BR, BL, plate px) of a blank paddle face measured from the painting: flood fill
    from a point on it, hull, four corners, pulled in a little for a margin (as s01's placard_quad)."""
    x, y = seed
    x0, y0 = max(x - 200, 0), max(y - 200, 0)
    sub = np.ascontiguousarray(rgb[y0:y + 200, x0:x + 200])
    img = cv2.GaussianBlur((np.clip(sub, 0, 1) * 255).astype(np.uint8), (0, 0), 1.2)
    m = np.zeros((img.shape[0] + 2, img.shape[1] + 2), np.uint8)
    cv2.floodFill(img, m, (x - x0, y - y0), (0, 0, 0), (tol,) * 3, (tol,) * 3,
                  4 | cv2.FLOODFILL_MASK_ONLY | cv2.FLOODFILL_FIXED_RANGE | (255 << 8))
    m = cv2.morphologyEx(m[1:-1, 1:-1], cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    cnt, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not cnt:
        return None
    hull = cv2.convexHull(max(cnt, key=cv2.contourArea))
    peri = cv2.arcLength(hull, True)
    quad = None
    for eps in np.linspace(0.01, 0.15, 50):
        ap = cv2.approxPolyDP(hull, eps * peri, True)
        if len(ap) == 4:
            quad = ap[:, 0, :].astype(np.float32)
            break
    if quad is None:
        quad = cv2.boxPoints(cv2.minAreaRect(hull)).astype(np.float32)
    c = quad.mean(0)
    quad = quad[np.argsort(np.arctan2(quad[:, 1] - c[1], quad[:, 0] - c[0]))]
    quad = np.roll(quad, -int(np.argmin(quad.sum(1))), axis=0)
    quad = c + (quad - c) * 0.80
    return quad + np.float32([x0, y0])
