"""Year 1: "The first thing you'd notice is your chatbot. ChatGPT's nine hundred million users would have
nowhere new to go."

Set: y01_chatbot_key.png (pose A, seated, reading the ticket) and _poseB.png (leapt up, ticket overhead).
    "chatbot"   the ticket machine jolts and spits: a new hump of ticket paper arches out of its mouth
    (pause)     the person leaps up (anticipation, in-between, held pose B); the leap knocks the YEAR sign
    "ChatGPT's" data card lowered in on its threads
    "nowhere"   the number is stamped on the ticket in red (camera knock, the ticket jolts in his hands)
    "go"        the SCENARIO stamp follows
Laptop: a backlit printed insert, an invented chat box saying "Please wait", dots swapped on 2s.
"""
from functools import lru_cache

import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif import text as T
from whatif.config import FPS
from whatif.plate import PH, PW
from whatif.screens import ScreenQuad
from whatif.shotkit import BaseShot
from whatif.stage import track

# character region (key px): the person in both poses, the chair, the ticket on the table
REGION = [(0, 130), (705, 130), (705, 560), (520, 820), (480, 1060), (400, 1100), (400, 1135), (870, 1105),
          (885, 1300), (400, 1330), (0, 1360)]
# the ticket machine (plate px) and the point it squashes about (its foot)
MACHINE = [(928, 1150), (1145, 1140), (1145, 1610), (955, 1612), (936, 1420), (925, 1300)]
MACHINE_FOOT = (1040, 1600)
# the paper between the machine's mouth and the table (plate px): bulged out on "chatbot"
PAPER_RUN = [(1012, 1368), (1040, 1384), (1004, 1446), (982, 1512), (968, 1606), (852, 1612), (862, 1526),
             (886, 1446), (930, 1384)]
MOUTH, TABLE_END = (1005, 1386), (915, 1592)
TICKET_BOX = (13, 153, 859, 461)        # plate px box around the overhead ticket in pose B
TICKET_SPAN = (96, 706)                 # plate x of the ticket's free part between the fists
LOWER = 50.0                            # pose B's ticket and fists are held this much lower (plate px) so the
                                        # ticket clears the YEAR sign; the arms take it up, the head stays put


class Shot(BaseShot):
    light = (-0.55, -0.75)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_spit = c.f("chatbot")
        self.f_leap = self.f_spit + 20                     # in the pause after "chatbot."
        self.f_card = c.f("ChatGPT's") - 2                 # lands on the word
        self.f_stamp = c.f("nowhere")
        self.f_scen = c.f("go")
        self.setup(anchor=(0.5, 0.5), region=REGION, switches=[(self.f_leap, "B")],
                   x=track((0, -16.0), (c.dur, -6.0, "inout")), y=track((0, -52.0)))
        self.cam.add_bump(self.f_leap, -1.2, 2.2)
        self.cam.add_bump(self.f_stamp, 0.6, 3.2)
        self.cam.add_bump(self.f_scen, -0.4, 1.8)
        self.machine = clay.poly_mask(MACHINE, (PH, PW), 5.0)
        self.ticket_mask = clay.poly_mask([(10, 210), (830, 210), (830, 510), (10, 510)], (PH, PW), 18.0)
        self.low_B = lower_pose_b(self.rep.pose("A")[0], *self.rep.pose("B")[:2])
        self.screen = ScreenQuad.detect(self.rep.pose("A")[0], lambda r, g, b: (b > .80) & (g > .70) & (r < .70) & (b - r > .2))
        top, bot = ticket_edges(self.rep.pose("B")[0])
        top[:, 1] += LOWER
        bot[:, 1] += LOWER
        self.top, self.bot = normal_edges(top, bot)          # letters stand on the paper's own curve
        w = int(np.sqrt((np.diff(np.stack([self.top, self.bot]).mean(0), axis=0) ** 2).sum(1)).sum())
        h = int(np.median(self.bot[:, 1] - self.top[:, 1]))
        self.ink_print, self.ink_number, self.ink_scen = ticket_inks(w, h, verbose=__name__ != "__mp_main__")
        self.card = P.data_card(["ChatGPT:", "900 million", "weekly users"], "OpenAI, Feb 2026", width=318, cap=34,
                                seed=12, wrap=False, source_kind="body")
        self.card_xy = (598, 408)
        self.paper_run = clay.poly_mask(PAPER_RUN, (PH, PW), 10.0)
        self.focus_A = self.focus_at(170, 760, "A")        # his face
        self.focus_B = self.focus_at(330, 230, "B")        # the ticket overhead
        self._strip_cache = {}

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        if st == "B":
            fr.rgb[:], fr.depth[:] = self.low_B
        self.machine_jolt(fr, f)
        if st == "B":
            self.ticket_print(fr, f)
            k = (f - self.f_stamp) // 2
            if k in (0, 1):                                 # the stamp knocks the ticket in his hands
                clay.nudge_region(fr, self.ticket_mask, (400, 300), dy=(3.5 if k == 0 else -1.0), depth=False)
        self.stage.boil(fr)
        P.screen_insert(fr, self.screen.quad, chat_canvas(dots_at(f, self.f0)), glow=1.0, label="Please wait",
                        text_rect=CHAT_TEXT)
        d = self.focus_for(f)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_leap, 4.5)])
        self.hang_card(fr, f, d)
        return fr

    def hang_card(self, fr, f, d):
        """draw_card's hang, kept clear of the right safe line: the card is wide and clamped against it, so
        it hangs a few px further in and swings a little less on its landing exposure."""
        an = P.lower_in(f, self.f_card, swing=1.6)
        if an is None:
            return
        bx0, by0, bx1, by1 = self.safe_plate_box()
        x = min(self.op(*self.card_xy)[0], bx1 - self.card.w - 14)
        y = float(np.clip(self.op(*self.card_xy)[1], by0, by1 - self.card.h))
        hung = P.hanging(self.card, -(y + 10), seed=self.ctx.index + 3)
        P.place(fr, hung, x, y + an["dy"], depth=d, shadow="hang", angle=an["angle"],
                origin=(hung.anchor[0] + self.card.w / 2, 0), label=self.card.label)

    def machine_jolt(self, fr, f):
        k = (f - (self.f_spit - self.f_spit % 2)) // 2
        pose = {-1: (1.025, 0.97, 0, 1.5), 0: (0.975, 1.045, 0, -2.0), 1: (1.008, 0.99, 0, 0.6)}.get(k)
        if pose:
            sx, sy, dx, dy = pose
            clay.nudge_region(fr, self.machine, MACHINE_FOOT, sx=sx, sy=sy, dx=dx, dy=dy)
        if k >= 0:                                   # the paper is shoved out: it bulges, then keeps some slack
            amp = (40.0, 25.0, 16.0)[min(k, 2)]
            paper_bulge(fr, self.paper_run, amp)

    def ticket_print(self, fr, f):
        P.ink_on_strip(fr, self.ink_print, np.float32(P.INK), self.top, self.bot, opacity=0.92,
                       label="ticket print", cache=self._strip_cache)
        if f >= self.f_stamp:
            wet = 1.0 if f < self.f_stamp + 4 else 0.25
            P.ink_on_strip(fr, self.ink_number, np.float32(P.STAMP_RED), self.top, self.bot, wet=wet,
                           label="2,000,000", cache=self._strip_cache)
        if f >= self.f_scen:
            wet = 1.0 if f < self.f_scen + 4 else 0.25
            ink, col = self.ink_scen
            P.ink_on_strip(fr, ink, col, self.top, self.bot, wet=wet, opacity=0.95, label="SCENARIO",
                           cache=self._strip_cache)

    def focus_for(self, f):
        return self.focus_A if self.state(f) in ("A", "antAB") else self.focus_B

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f_spit, "ticket_spit", {"word": "chatbot"}),
                (self.f_leap - 4, "leap_anticipation", {}),
                (self.f_leap, "leap_poseB", {}),
                (self.f_card, "data_card", {"word": "ChatGPT's"}),
                (self.f_stamp, "number_stamped", {"word": "nowhere"}),
                (self.f_scen, "scenario_stamp", {"word": "go"})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=31) * 0.5, at(self.f0) - 0.5, -12)
        snd.sfx(A.ratchet(0.30, rate=30, seed=3), at(self.f_spit - 4), -22, 0.6)
        snd.sfx(A.paper_flick(seed=4), at(self.f_spit), -18, 0.55)
        snd.sfx(A.perc("glock", seed=5, pitch=1.5), at(self.f_spit + 2), -27, 0.6)
        snd.sfx(A.squelch(seed=6, dur=0.22, pitch=0.8), at(self.f_leap - 4), -20, -0.3)
        snd.sfx(A.clay_pop(seed=7, pitch=0.9), at(self.f_leap), -17, -0.3)
        snd.sfx(A.paper_rustle(0.35, seed=8, busy=1.4), at(self.f_leap), -22, -0.2)
        snd.sfx(A.wood_knock(seed=9, pitch=0.7, hard=0.8), at(self.f_leap + 2), -24, -0.6)
        snd.sfx(A.string_creak(seed=10), at(self.f_leap), -28, -0.6)
        snd.sfx(A.string_creak(seed=11), at(self.f_card), -30, 0.4)
        snd.sfx(A.paper_flick(seed=12), at(self.f_card + 2), -27, 0.4)
        snd.sfx(A.rubber_stamp(seed=13), at(self.f_stamp), -13, -0.2)
        snd.sfx(A.paper_rustle(0.2, seed=14, busy=0.8), at(self.f_stamp + 1), -28, -0.2)
        snd.sfx(A.rubber_stamp(seed=15), at(self.f_scen), -17, 0.1)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def lower_pose_b(A, B, dB):
    """Pose B with the overhead ticket and fists LOWER px lower: everything that differs from the key moves
    down by a weight that is 1 over the ticket and fists, eases out along the forearms and is 0 on the head;
    the key (clean wall and window) shows where the ticket used to be."""
    la = cv2.cvtColor(np.ascontiguousarray(A), cv2.COLOR_RGB2LAB)
    lb = cv2.cvtColor(np.ascontiguousarray(B), cv2.COLOR_RGB2LAB)
    obj = (np.sqrt(((la - lb) ** 2).sum(2)) > 7).astype(np.uint8)
    obj = cv2.morphologyEx(obj, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    obj = cv2.morphologyEx(obj, cv2.MORPH_CLOSE, np.ones((21, 21), np.uint8))
    k, lab, st, _ = cv2.connectedComponentsWithStats(obj)
    keep = np.isin(lab, [i for i in range(1, k) if st[i, cv2.CC_STAT_AREA] > 3000]).astype(np.uint8)
    ff = keep.copy()
    cv2.floodFill(ff, np.zeros((PH + 2, PW + 2), np.uint8), (PW - 1, 0), 1)
    objm = cv2.GaussianBlur((keep | (1 - ff)).astype(np.float32), (0, 0), 1.5)
    yy, xx = np.mgrid[0:PH, 0:PW].astype(np.float32)
    arm = np.clip(1 - (yy - 420) / 260, 0, 1)
    head = np.clip(1 - (yy - 375) / 25, 0, 1)
    inhead = cv2.GaussianBlur(((xx > 165) & (xx < 455)).astype(np.float32), (0, 0), 14)
    wgt = arm * (1 - inhead) + head * inhead
    my = yy - LOWER * wgt * wgt * (3 - 2 * wgt)
    rgb = cv2.remap(B, xx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    dep = cv2.remap(dB, xx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    ow = cv2.remap(objm, xx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    rgb = rgb * ow[..., None] + A * (1 - ow[..., None])
    dep = dep * ow + dB * (1 - ow)
    return rgb.astype(np.float32), dep.astype(np.float32)


def normal_edges(top, bot):
    """Re-pair the strip's edge points along the local normal of its centre line, so the canvas columns lean
    with the paper: printed letters rotate with the bend instead of only sliding up and down."""
    c = (top + bot) / 2
    tx, ty = np.gradient(c[:, 0]), np.gradient(c[:, 1])
    nrm = np.sqrt(tx ** 2 + ty ** 2)
    nx, ny = -ty / nrm, tx / nrm
    h = (bot[:, 1] - top[:, 1]) / 2 * (tx / nrm)
    t2 = np.stack([c[:, 0] - nx * h, c[:, 1] - ny * h], 1)
    b2 = np.stack([c[:, 0] + nx * h, c[:, 1] + ny * h], 1)
    return t2.astype(np.float32), b2.astype(np.float32)


def paper_bulge(fr, region, amp):
    """Push the painted paper run out toward the upper left by up to `amp` px in its middle (zero at the
    mouth and where it meets the table): the paper's own pixels move, the background stretches under the
    soft region."""
    (mx_, my_), (tx_, ty_) = MOUTH, TABLE_END
    x0, y0, x1, y1 = 820, 1340, 1080, 1630
    gx, gy = np.meshgrid(np.arange(x0, x1, dtype=np.float32), np.arange(y0, y1, dtype=np.float32))
    t = np.clip((gy - my_) / (ty_ - my_), 0, 1)
    prof = np.sin(np.pi * t ** 0.8) * region[y0:y1, x0:x1]
    d = amp * prof
    sx = (gx + 0.70 * d - x0).astype(np.float32)
    sy = (gy + 0.55 * d - y0).astype(np.float32)
    sub = fr.rgb[y0:y1, x0:x1].copy()
    fr.rgb[y0:y1, x0:x1] = cv2.remap(sub, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    dsub = fr.depth[y0:y1, x0:x1].copy()
    fr.depth[y0:y1, x0:x1] = cv2.remap(dsub, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def ticket_edges(B, n=24):
    """Top and bottom edge of the overhead ticket in pose B (plate px, n points over TICKET_SPAN),
    measured from the painting: the ticket is the light, low-red cream area in TICKET_BOX."""
    x0, y0, x1, y1 = TICKET_BOX
    lab = cv2.cvtColor(np.ascontiguousarray(B[y0:y1, x0:x1]), cv2.COLOR_RGB2LAB)
    m = ((lab[..., 0] > 66) & (lab[..., 1] < 14.5) & (lab[..., 2] < 32)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    k, lb, st, _ = cv2.connectedComponentsWithStats(m)
    m = (lb == 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    xs = np.linspace(TICKET_SPAN[0], TICKET_SPAN[1], n)
    top, bot = [], []
    for x in xs:
        col = m[:, int(round(x)) - x0]
        ys = np.nonzero(col)[0]
        top.append((x, y0 + ys.min() + 2.5))
        bot.append((x, y0 + ys.max() - 2.5))
    top, bot = np.float32(top), np.float32(bot)
    for arr in (top, bot):                                  # smooth the measured edges a little
        arr[:, 1] = np.convolve(np.pad(arr[:, 1], 2, mode="edge"), np.ones(5) / 5, mode="valid")
    return top, bot


def ticket_inks(w, h, verbose=False):
    """Ink layers for the ticket canvas (w x h, mapped onto the curved strip): the machine's print, the red
    numbering stamp and the purple SCENARIO stamp.
        row 1   YOU ARE NUMBER
        row 2   [2,000,000] IN LINE          (the number lands on a printed blank)
        right   [SCENARIO] across both rows"""
    cap = 30
    f_body = T.font("body", T.size_for_cap("body", cap, 800), 800)
    l1 = T.text_alpha("YOU ARE NUMBER", f_body, tracking=-2.4)
    l2 = T.text_alpha("IN LINE", f_body, tracking=-2.4)
    num, _ = P.stamp_ink("2,000,000", P.STAMP_RED, seed=41, cap=30, border=False, kind="body", weight=900,
                         angle=-2.0, pad=2)
    sc, scol = P.stamp_ink("SCENARIO", P.STAMP_PURPLE, seed=43, cap=30, border=True, kind="clay", weight=600,
                           angle=-2.0, pad=3, double=False)
    xL = 4
    y1 = int(h * 0.07)
    y2 = h - int(h * 0.11) - l2.shape[0]
    lx = xL + num.shape[1] + 3
    sx = w - sc.shape[1] + 8                      # the stamp canvas has a 10 px blank margin; 2 px from the end
    if verbose:
        print("ticket canvas", w, h, "row1 ends", xL + l1.shape[1], "row2 ends", lx + l2.shape[1], "stamp from", sx,
              "stamp size", sc.shape)
    pr = np.zeros((h, w), np.float32)
    _blit(pr, l1, xL, y1)
    _blit(pr, l2, lx, y2)
    ly = y2 + l2.shape[0] - 3                                   # the printed blank for the number
    pr[ly:ly + 3, xL:lx - 8] = np.maximum(pr[ly:ly + 3, xL:lx - 8], 0.85)
    pr = P.ink_alpha(pr, seed=42, density=0.9, bleed=0.45, patchy=0.07)
    nm = np.zeros((h, w), np.float32)
    _blit(nm, num, xL - 2, ly - num.shape[0] + 6)
    sm = np.zeros((h, w), np.float32)
    _blit(sm, sc, sx, (h - sc.shape[0]) // 2 + 2)
    return pr, nm, (sm, scol)


def _blit(dst, a, x, y):
    h, w = a.shape
    H, W = dst.shape
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb > xa and yb > ya:
        dst[ya:yb, xa:xb] = np.maximum(dst[ya:yb, xa:xb], a[ya - y:yb - y, xa - x:xb - x])


def dots_at(f, f0):
    """'Please wait' dots, swapped like printed inserts every two exposures: 0, 1, 2, 3, 0, ..."""
    return ((f - f0) // 4) % 4


CHAT_TEXT = (150, 330, 600, 420)        # canvas px of the readable "Please wait" line


@lru_cache(maxsize=4)
def chat_canvas(dots):
    """The invented chat box, printed on backlit film (drawn at 2x the screen's plate size). No brand."""
    W, H = 720, 530
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    r = np.sqrt(((xx - W * 0.5) / W) ** 2 + ((yy - H * 0.45) / H) ** 2)
    back = np.float32([0.80, 0.96, 1.0]) * (1 - 0.30 * r[..., None] ** 1.5) + np.float32([0, 0.0, 0]) * r[..., None]
    img = np.clip(back, 0, 1)
    img *= (1 + 0.015 * P.smooth_noise(H, W, 5, 1.2) + 0.02 * P.smooth_noise(H, W, 6, 30))[..., None]

    def rrect(x0, y0, x1, y1, rad, col, a=1.0):
        m = np.zeros((H * 2, W * 2), np.uint8)
        cv2.rectangle(m, (int(x0 + rad) * 2, int(y0) * 2), (int(x1 - rad) * 2, int(y1) * 2), 255, -1)
        cv2.rectangle(m, (int(x0) * 2, int(y0 + rad) * 2), (int(x1) * 2, int(y1 - rad) * 2), 255, -1)
        for cx, cy in ((x0 + rad, y0 + rad), (x1 - rad, y0 + rad), (x1 - rad, y1 - rad), (x0 + rad, y1 - rad)):
            cv2.circle(m, (int(cx) * 2, int(cy) * 2), int(rad) * 2, 255, -1, cv2.LINE_AA)
        mm = cv2.resize(m, (W, H), interpolation=cv2.INTER_AREA).astype(np.float32)[..., None] / 255 * a
        img[:] = img * (1 - mm) + np.float32(col) * mm

    # window chrome: a header strip with a round little robot face (invented)
    rrect(0, 0, W, 86, 6, (0.30, 0.56, 0.72))
    cv2.circle(img, (58, 43), 27, (0.95, 0.98, 1.0), -1, cv2.LINE_AA)
    cv2.circle(img, (48, 38), 5, (0.20, 0.35, 0.50), -1, cv2.LINE_AA)
    cv2.circle(img, (68, 38), 5, (0.20, 0.35, 0.50), -1, cv2.LINE_AA)
    cv2.ellipse(img, (58, 50), (10, 6), 0, 10, 170, (0.20, 0.35, 0.50), 3, cv2.LINE_AA)
    for k in range(3):
        rrect(118, 24 + k * 14, 118 + (230, 170, 120)[k], 30 + k * 14, 3, (0.80, 0.90, 0.96))
    # the user's question: a bubble of unreadable grey lines (right)
    rrect(330, 116, 690, 196, 24, (0.62, 0.80, 0.92))
    for k, ln in enumerate((280, 200)):
        rrect(356, 136 + k * 28, 356 + ln, 148 + k * 28, 6, (0.95, 0.98, 1.0))
    # the bot's reply bubble: three dots that never resolve (left)
    rrect(30, 222, 220, 290, 24, (0.96, 0.99, 1.0))
    for k in range(3):
        cv2.circle(img, (82 + k * 44, 256), 11, (0.55, 0.66, 0.74), -1, cv2.LINE_AA)
    # "Please wait" with the swapped dots (cap 64 on the 2x canvas -> >= 30 px on screen)
    fnt = T.font("body", T.size_for_cap("body", 66, 800), 800)
    a = T.text_alpha("Please wait", fnt, tracking=1)
    dw = T.text_alpha("...", fnt)
    tw = a.shape[1] + dw.shape[1]
    x = (W - tw) // 2
    y = 335
    ink = np.zeros((H, W), np.float32)
    _blit(ink, a, x, y)
    if dots:
        d = T.text_alpha("." * dots, fnt)
        _blit(ink, d, x + a.shape[1] + 4, y + a.shape[0] - d.shape[0])
    ink = P.ink_alpha(ink, seed=7, density=0.96, bleed=0.6, patchy=0.04)
    img = img * (1 - ink[..., None]) + np.float32([0.08, 0.18, 0.32]) * ink[..., None]
    # a thin progress bar that never moves
    rrect(150, 470, 570, 488, 9, (0.62, 0.80, 0.92))
    rrect(150, 470, 196, 488, 9, (0.20, 0.45, 0.66))
    return np.clip(img, 0, 1).astype(np.float32)
