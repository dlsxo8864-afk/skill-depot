"""Year 4: "Your town would keep more water. Data centers drank seventeen billion gallons in one year."

Set: y04_water_key.png (pose A: the dry reservoir, the data center's striped straw sucking the last puddle,
villagers with empty buckets) and _poseB.png (pose B: the reservoir full, the straw lying on the hill,
villagers cheering, ducks swimming). B is painted on the same set-up as A (aligned within ~3 px), so the
refill is played as replacement steps between the two paintings.
    (from the cut)  the straw gulps: a bulge travels up it on 2s, the puddle shrinks a little each gulp
    "water" -2      anticipation: the straw dips into the puddle
    "water"         the straw is yanked out with a pop: swung up toward the data center, drops flying
    +2 .. +8        the reservoir refills from the puddle outward in four replacement steps; the
                    villagers cheer from the first; the water reaches the ducks and they float (+4), then swim (+8)
    after           cheering bounce on 2s, the water shimmers
Card "17.4 billion gallons in 2023 / Berkeley Lab" lowered in on its threads on "seventeen".
"""
import math

import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# ---------------------------------------------------------------- set measurements (key px)
STRAW = [(268, 335), (282, 292), (312, 262), (360, 247), (412, 254), (462, 274), (552, 302), (662, 332),
         (716, 350), (722, 384), (662, 366), (552, 336), (462, 310), (402, 294), (364, 304), (354, 332),
         (351, 420), (346, 600), (343, 900), (346, 995), (230, 995), (234, 900), (249, 600), (261, 420)]
STRAW_PIVOT = (714, 367)            # where it plugs into the data center
STRAW_FOOT = (290, 975)
PUDDLE = (300, 965)                 # centre of the puddle
PUDDLE_POLY = [(140, 935), (250, 912), (420, 918), (470, 962), (420, 1015), (250, 1030), (140, 1005)]
BASIN = [(0, 590), (941, 590), (941, 1150), (0, 1150)]       # the reservoir bed (both poses)
DUCKS_A = [(610, 905), (690, 870), (770, 820), (905, 815), (910, 965), (820, 1010), (735, 1055), (605, 1055)]
DUCKS_B = [(580, 880), (680, 850), (770, 815), (892, 815), (898, 925), (805, 975), (705, 1018), (580, 1018)]
DUCK_FEET_A = [(675, 1040), (765, 995), (840, 955)]          # where each duck stands (for splashes)
DUCK_WATER_B = [(645, 985), (740, 945), (830, 905)]           # where each duck sits in the water
# villagers at the edges of the frame that the depth estimate puts too far back (both poses)
EDGE_PEOPLE = [[(0, 825), (205, 825), (215, 1100), (0, 1110)], [(730, 980), (941, 975), (941, 1260), (730, 1260)]]
# the refill: two water levels in the bowl (key px shorelines), then pose B (full to the rim)
LEVEL1 = [(0, 868), (120, 838), (260, 822), (400, 836), (500, 868), (556, 900), (600, 945), (618, 1000),
          (630, 1050), (680, 1076), (740, 1078), (800, 1040), (870, 1010), (941, 1004), (941, 1180), (0, 1180)]
#          the low half of the bed: the shore passes below the boat and wraps under the ducks' mud bank
LEVEL2 = [(0, 735), (150, 716), (330, 706), (520, 704), (700, 712), (941, 730), (941, 1180), (0, 1180)]  # to the wall's foot
BOAT_BOX = (560, 640, 880, 860)                      # x0, y0, x1, y1 around the boat (both poses)
DUCKS_A_BOX = (560, 780, 941, 1100)                  # around the standing ducks, feet included


class Shot(BaseShot):
    light = (-0.55, -0.75)
    year_xy = (74, 122)                 # a hair lower than the default: the sign is knocked on the cut

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_yank = c.f("water")
        self.f_cut = self.f_yank + 2
        self.f_card = c.f("seventeen") - 2
        self.setup(anchor=(0.5, 0.5), mode="full", switches=[(self.f_cut, "B")],
                   zoom=track((0, 1.0), (c.dur, 1.025, "inout")), y=track((0, -8.0), (c.dur, -24.0, "inout")))
        self.cam.add_bump(self.f_yank, 1.8, -2.6)
        self.cam.add_bump(self.f_cut, -2.2, 1.6)
        self.cam.add_bump(self.f_cut + 8, 0.8, 1.2)
        sh = (PH, PW)
        k = self.kp
        self.A, self.Ad = self.rep.pose("A")[:2]
        self.B, self.Bd = self.rep.pose("B")[:2]
        self.straw = clay.poly_mask(k(STRAW), sh, 2.5)
        self.straw_hard = clay.poly_mask(k(STRAW), sh, 0)
        self.puddle = clay.poly_mask(k(PUDDLE_POLY), sh, 14.0)
        self.basin = clay.poly_mask(k(BASIN), sh, 6.0)
        self.ducks_a = clay.poly_mask(k(DUCKS_A), sh, 4.0)
        self.ducks_b = clay.poly_mask(k(DUCKS_B), sh, 4.0)
        self.A_clean = remove_straw(self.A, self.straw_hard, k, self.B)
        self.Ad_clean = remove_straw(np.repeat(self.Ad[..., None], 3, 2), self.straw_hard, k,
                                     np.repeat(self.Bd[..., None], 3, 2))[..., 0]
        self.B_noducks = clone_patch(self.B, self.ducks_b, dx=-int(300 * self.fit.s), dy=0)
        dxa = -int(250 * self.fit.s)               # twice: the first pass copies the left duck onto the right one
        self.A_noducks = clone_patch(clone_patch(self.A_clean, self.ducks_a, dxa, 0), self.ducks_a, dxa, 0)
        edge = np.zeros(sh, np.float32)
        for poly in EDGE_PEOPLE:
            edge = np.maximum(edge, clay.poly_mask(k(poly), sh, 6.0))
        self.people = np.maximum(people_mask(self.Bd, self.basin), edge)
        self.people_a = np.maximum(people_mask(self.Ad, self.basin), edge)
        self.people_a_wide = cv2.GaussianBlur(cv2.dilate(self.people_a, np.ones((21, 21), np.uint8)), (0, 0), 6)
        # the ducks as solid cut-outs (body from the depth relief, beaks/legs/feet by colour), shrunk 2 px
        self.duck_bodies = duck_mask_a(self.A, self.Ad, self.box(DUCKS_A_BOX)) * (1 - self.people_a)
        self.duck_b = duck_mask_b(self.B, self.ducks_b) * (1 - self.people)
        self.boat_b = boat_mask(self.Bd, self.box(BOAT_BOX))
        self.levels = [level_mask(k(LEVEL1), sh, seed=11), level_mask(k(LEVEL2), sh, seed=12)]
        self.levels[1] = np.maximum(self.levels[1], self.boat_b)
        self.card = P.data_card(["17.4 billion", "gallons in 2023"], "Berkeley Lab", width=330, cap=36,
                                seed=44, wrap=False, source_kind="body", light=self.light)
        self.step = 4                                       # frames between refill steps (two exposures each)
        self.card_xy = (540, 192)
        self.focus_A = self.focus_at(300, 760, "A")          # the straw
        self.focus_B = self.focus_at(560, 1150, "B")         # the cheering villagers
        # gulps before the yank: a bulge climbing the straw, one exposure per rung
        self.gulps = list(range(self.f0 + 2 - self.f0 % 2, self.f_yank - 6, 8))

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        e = f - f % 2
        k = (e - self.f_yank) // 2                     # exposures since the yank
        if k < 1:
            fr = self.base(f, "A", boil=False)
            if k < -1:
                self.suck(fr, e)
            elif k == -1:                               # anticipation: the straw dips into the puddle
                clay.nudge_region(fr, self.straw, self.kp(*STRAW_PIVOT), sy=0.992, dy=7.0, angle=0.4)
                clay.nudge_region(fr, self.puddle, self.kp(*PUDDLE), sx=0.93, sy=0.93)
            else:                                       # the yank: the straw swung up out of the puddle
                self.yank(fr)
            self.stage.boil(fr, mask=self.people_a, amp=0.55)

        else:
            fr = self.base(f, "B", boil=False)
            self.refill_step(fr, (e - self.f_cut) // self.step, (e - self.f_cut) % self.step == 0)
        d = self.focus_for(f)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_cut, 3.0)])
        self.draw_card(fr, f, self.card, self.f_card, xy=self.card_xy, depth=d)
        return fr

    def suck(self, fr, e):
        """Pose A: the straw gulps, the puddle shrinks a step with each gulp."""
        done = sum(1 for g in self.gulps if e >= g + 6)
        s = 1 - 0.07 * done
        if done:
            clay.nudge_region(fr, self.puddle, self.kp(*PUDDLE), sx=s, sy=s)
        for g in self.gulps:
            r = (e - g) // 2
            if 0 <= r < 3:                              # the bulge: low, middle, high
                yk = (900, 700, 480)[r]
                band = self.straw * band_mask(self.kp(0, yk)[1], 48 * self.fit.s, fr.rgb.shape[:2])
                cx = self.kp(300 - (yk - 700) * 0.05, yk)
                clay.nudge_region(fr, band, cx, sx=1.24, sy=1.04)

    def yank(self, fr):
        """The straw swung up about its plug in the data center (the background behind it re-made),
        the puddle bursting up in drops where its foot was."""
        piv = self.kp(*STRAW_PIVOT)
        M = cv2.getRotationMatrix2D(piv, -4.0, 1.0)        # +ve = counter-clockwise on screen
        M[0, 2] += 30
        M[1, 2] -= 125
        fr.rgb = self.A_clean.copy()
        fr.depth = self.Ad_clean.copy()
        paste_moved(fr, self.A, self.Ad, self.straw, M)
        foot = np.float32(self.kp(*STRAW_FOOT))
        splash(fr, (foot[0] + 10, foot[1] - 10), n=9, spread=(150, 170), size=(9, 20), seed=5, up=True,
               depth=float(self.Ad[int(foot[1]), int(foot[0])]))

    def afloat(self, fr, first):
        """A's ducks set IN the water as it rises round them: each cut off at its own waterline (legs and lower
        body hidden under the water), nudged down and a little toward where they will swim, with an elliptical
        ripple ring at the waterline (wider on the second exposure)."""
        sc = self.fit.s
        dx, dy = -8.0 * sc, 14.0 * sc                     # plate px: down into the water, toward pose B
        src = self.duck_bodies * (1 - self.people)
        H, W = src.shape
        n, lab = cv2.connectedComponents((src > 0.3).astype(np.uint8))
        feet = [self.kp(x, y) for x, y in DUCK_FEET_A]
        yy = np.arange(H, dtype=np.float32)[:, None]
        cut = np.zeros_like(src)
        lines = []
        for i in range(1, n):
            ys, xs = np.nonzero(lab == i)
            if len(ys) < 200:
                continue
            cx = xs.mean()
            fx, fy = min(feet, key=lambda p: abs(p[0] - cx) + 0.3 * abs(p[1] - ys.max()))
            if abs(fx - cx) > 70 * sc or not (fy - 90 * sc < ys.max() < fy + 25 * sc):
                continue                                  # a stone or tuft the duck mask caught, not a duck
            wl = fy - 40.0 * sc                           # source y of the waterline: a little above the legs
            comp = cv2.dilate((lab == i).astype(np.uint8), np.ones((5, 5), np.uint8)).astype(np.float32)
            keep = np.clip((wl - yy) / 2.0 + 0.5, 0, 1)   # a crisp (2 px) waterline
            ci = src * comp * keep
            cut = np.maximum(cut, ci)
            yb = np.nonzero((ci > 0.5).any(1))[0]
            if not len(yb):
                continue
            yb = int(yb.max())                            # the body's own waterline after the cut
            cols = np.nonzero((ci[yb - 8:yb + 1] > 0.5).any(0))[0]
            if len(cols):
                lines.append(((cols.min() + cols.max()) / 2 + dx, yb + dy, (cols.max() - cols.min()) / 2))
        # the ripple rings first (on the water), then the ducks over them
        lx, ly = self.light
        for (cx, cy, hw) in lines:
            grow = 1.0 if first else 1.35
            a, b = (hw + 14 * sc) * grow, (hw * 0.28 + 5 * sc) * grow
            ring = np.zeros((H, W), np.float32)
            cv2.ellipse(ring, (int(cx), int(cy - 1)), (int(a), int(b)), 0, 0, 360, 1.0, max(2, int(3 * sc)),
                        cv2.LINE_AA)
            ring = cv2.GaussianBlur(ring, (0, 0), 1.6)
            dark = np.zeros((H, W), np.float32)
            cv2.ellipse(dark, (int(cx), int(cy)), (int(a * 0.86), int(b * 0.72)), 0, 0, 360, 1.0, -1,
                        cv2.LINE_AA)
            dark = cv2.GaussianBlur(dark, (0, 0), 3.0)
            water = self.basin * (1 - self.people)
            fr.rgb *= (1 - 0.22 * dark * water)[..., None]
            ring *= water * (0.42 if first else 0.30)
            fr.rgb = fr.rgb * (1 - ring[..., None]) + np.float32([0.86, 0.92, 0.96]) * ring[..., None]
        paste_moved(fr, self.A, self.Ad, cut, np.float32([[1, 0, dx], [0, 1, dy]]))

    def box(self, b):
        m = np.zeros((PH, PW), np.float32)
        (x0, y0), (x1, y1) = self.kp(b[0], b[1]), self.kp(b[2], b[3])
        m[int(y0):int(y1), int(x0):int(x1)] = 1
        return m

    def refill_step(self, fr, k, first=True):
        """k = 0..: exposures since the cut. Two water levels from B fill the bowl over the dry bed of A
        (a soft wet-mud band at each shoreline), then pose B; the villagers are B from the first step."""
        if k < 2:
            wet = self.levels[k]
            if k == 0:                                  # the ducks still stand on dry mud, left of the shore
                wet = wet * (1 - self.duck_bodies)
            area = self.basin * (1 - self.people) * (1 - self.people_a_wide)
            bed = (self.A_noducks if k == 1 else self.A_clean).copy()
            band = wet_band(wet, area * (1 - (self.duck_bodies if k == 0 else 0)))
            bed *= (1 - 0.34 * band)[..., None]         # wet mud: darker and a touch more saturated
            g = bed.mean(2, keepdims=True)
            bed = np.clip(g + (bed - g) * (1 + 0.25 * band[..., None]), 0, 1)
            shallow = np.clip((wet - 0.15) / 0.85, 0, 1) ** 0.8   # the water thins to the shore
            water = self.B_noducks * shallow[..., None] + bed * 0.62 * (1 - shallow[..., None])
            a = np.clip(wet * 1.6, 0, 1)
            lay = bed * (1 - a[..., None]) + water * a[..., None]
            lap = cv2.GaussianBlur(np.clip(1 - np.abs(wet - 0.35) * 5, 0, 1), (0, 0), 1.2) * area
            lay = lay * (1 - 0.18 * lap[..., None]) + np.float32([0.85, 0.88, 0.86]) * 0.18 * lap[..., None]
            am = area[..., None]
            fr.rgb = fr.rgb * (1 - am) + lay * am
            dry = area * (1 - a)
            fr.depth = fr.depth * (1 - dry) + self.Ad_clean * dry
            if k == 1:                                  # the water has reached the ducks: they float, sunk to
                self.afloat(fr, first)                  # the belly, a ripple ring round each
            if k == 0 and first:                        # the water bursting out of the puddle hole
                splash(fr, self.kp(*PUDDLE), n=7, spread=(120, 80), size=(8, 16), seed=21, up=True,
                       depth=float(self.Bd[int(self.kp(*PUDDLE)[1]), int(self.kp(*PUDDLE)[0])]))
            self.stage.boil(fr, mask=self.people, amp=0.6)
            return
        if k == 2:                                      # full: the ducks land, drops thrown up behind them
            if first:
                rgb0 = fr.rgb.copy()
                for i, (x, y) in enumerate(DUCK_WATER_B):
                    splash(fr, self.kp(x + 30, y - 6), n=6, spread=(70, 46), size=(6, 12), seed=30 + i, up=True,
                           depth=float(self.Bd[int(self.kp(x, y)[1]), int(self.kp(x, y)[0])]))
                dm = self.duck_b[..., None]
                fr.rgb = fr.rgb * (1 - dm) + rgb0 * dm
            self.stage.boil(fr, mask=self.people, amp=0.6)
            return
        # held B: the villagers bounce with their buckets on 2s, the water shimmers
        beat = ((fr.e - self.f_cut) // 2) % 4
        bob = ((fr.e - self.f_cut) // 6) % 2
        if bob:                                         # the ducks bob on the water
            clay.nudge_region(fr, self.duck_b, self.kp(740, 990), dy=-3.0, angle=1.2)
        dy = (-7.0, 0.0, -4.0, 0.0)[beat]
        if dy:
            clay.nudge_region(fr, self.people, self.kp(470, 1672), dy=dy, sy=1.0 - dy * 0.0012)
        water = self.basin * (1 - self.people) * (1 - cv2.dilate(self.duck_b, np.ones((7, 7), np.uint8)))
        self.stage.boil(fr, mask=water, amp=0.9)
        self.stage.boil(fr, mask=self.people, amp=0.55)

    def focus_for(self, f):
        return self.focus_A if f < self.f_cut else self.focus_B

    def finish_args(self, f):
        # pose A: the lens is on the straw; the aghast villagers in front stay a little more readable
        return {"dof": {"near": 4.0}} if f < self.f_cut else {}

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(g, "straw_gulp", {}) for g in self.gulps] + [
            (self.f_yank - 2, "straw_dips_anticipation", {}),
            (self.f_yank, "straw_yanked_pop", {"word": "water."}),
            (self.f_cut, "refill_starts_cheer", {}),
            (self.f_cut + self.step, "ducks_afloat", {}),
            (self.f_cut + 2 * self.step, "ducks_land_in_water", {}),
            (self.f_cut + 3 * self.step, "reservoir_full", {}),
            (self.f_card, "data_card", {"word": "seventeen"})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=51) * 0.5, at(self.f0) - 0.5, -12)
        snd.bed(birds(self.ctx.dur + 1.0, seed=52), at(self.f0) - 0.3, -30, 0.2)
        for i, g in enumerate(self.gulps):              # each gulp: a wet slurp up the straw
            snd.sfx(squelch(seed=60 + i, dur=0.30, pitch=0.55 + 0.05 * i), at(g), -21, -0.4)
        snd.sfx(A.string_creak(seed=70, dur=0.18), at(self.f_yank - 2), -27, -0.4)
        snd.sfx(cork_pop(seed=71), at(self.f_yank), -9, -0.3)
        snd.sfx(A.clay_pop(seed=72, pitch=0.6), at(self.f_yank) + 0.01, -16, -0.3)
        snd.sfx(splash_sfx(0.35, seed=73), at(self.f_yank) + 0.03, -20, -0.4)
        snd.sfx(gurgle(1.0, seed=74), at(self.f_cut), -16, -0.1)
        snd.sfx(A.crowd(1.8, seed=75), at(self.f_cut), -17, 0.0)
        snd.sfx(A.wood_knock(seed=76, pitch=0.7, hard=0.6), at(self.f_cut), -24, 0.0)
        for i in range(3):
            snd.sfx(quack(seed=80 + i, pitch=1.0 + 0.12 * i), at(self.f_cut + self.step) + 0.05 * i, -21, 0.4 + 0.1 * i)
            snd.sfx(splash_sfx(0.22, seed=90 + i, bright=1.3), at(self.f_cut + 2 * self.step) + 0.04 * i, -22,
                    0.4 + 0.1 * i)
        snd.sfx(A.string_creak(seed=95), at(self.f_card), -30, 0.4)
        snd.sfx(A.paper_flick(seed=96), at(self.f_card + 2), -26, 0.4)


def make(ctx):
    return Shot(ctx)


def squelch(seed=0, dur=0.28, pitch=1.0, wet=1.0):
    """whatif.audio.squelch with the duration snapped to a whole sample (the shared one mixes int() and
    round() sample counts and fails for durations like 0.30 s)."""
    return A.squelch(seed, (int(dur * A.SR) + 0.25) / A.SR, pitch, wet)


# ---------------------------------------------------------------------- shot-private helpers
def remove_straw(img, straw, k, other):
    """The set with the straw taken out: in the basin the bed and wall are cloned from beside the straw
    (the cracked mud and stones repeat), above the rim the houses are filled in (only ever seen as a
    sliver behind the swung straw for one exposure)."""
    out = img.copy()
    m = cv2.dilate(straw, np.ones((9, 9), np.uint8))
    rim = int(k(0, 600)[1])
    below = m.copy()
    below[:rim] = 0
    out = clone_patch(out, cv2.GaussianBlur(below, (0, 0), 3), dx=int(k(130, 0)[0] - k(0, 0)[0]), dy=0)
    above = cv2.dilate(straw, np.ones((35, 35), np.uint8))
    above[rim:] = 0
    if above.any():                                # pose B is painted on the same set-up: its sky and houses
        a = cv2.GaussianBlur(above, (0, 0), 3)[..., None]
        out = out * (1 - a) + other * a
    return out.astype(np.float32)


def clone_patch(img, mask, dx, dy):
    """Fill `mask` with the image shifted by (dx, dy) (a clone stamp from beside the hole)."""
    H, W = mask.shape
    M = np.float32([[1, 0, -dx], [0, 1, -dy]])
    src = cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    m = mask[..., None] if img.ndim == 3 else mask
    return (img * (1 - m) + src * m).astype(np.float32)


def paste_moved(fr, rgb, depth, mask, M, sy=1.0, origin=None):
    """Lift the object under `mask` out of `rgb` and set it down moved by the 2x3 affine M (plate px),
    optionally squashed/stretched vertically by sy about origin, over what is already in fr."""
    M = np.float32(M).copy()
    if sy != 1.0 and origin is not None:
        S = np.float32([[1, 0, 0], [0, sy, origin[1] * (1 - sy)], [0, 0, 1]])
        M = (np.vstack([M, [0, 0, 1]]) @ S)[:2].astype(np.float32)
    H, W = mask.shape
    ys, xs = np.nonzero(mask > 0.01)
    if not len(ys):
        return
    m = cv2.warpAffine(mask, M, (W, H), flags=cv2.INTER_LINEAR)
    obj = cv2.warpAffine(rgb, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    dob = cv2.warpAffine(depth, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    fr.rgb = fr.rgb * (1 - m[..., None]) + obj * m[..., None]
    fr.depth = fr.depth * (1 - m) + dob * m


def band_mask(y, half, shape):
    yy = np.arange(shape[0], dtype=np.float32)[:, None]
    return np.repeat(np.exp(-((yy - y) / half) ** 2), shape[1], 1).astype(np.float32)


def people_mask(depth, basin):
    """The villagers in pose B (the nearest things in the picture, below the water's far edge)."""
    H, W = depth.shape
    near = (cv2.GaussianBlur(depth, (0, 0), 2) > 0.62).astype(np.uint8)
    near[: int(H * 0.40)] = 0
    near = cv2.morphologyEx(near, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(near)
    keep = np.zeros_like(near)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] > 0.004 * H * W:
            keep[lab == i] = 1
    keep = cv2.dilate(keep, np.ones((7, 7), np.uint8))
    return cv2.GaussianBlur(keep.astype(np.float32), (0, 0), 3)


def splash(fr, c, n=8, spread=(120, 100), size=(8, 16), seed=0, up=True, depth=None):
    """Clear-resin water drops on wires, as a model-maker sets them: lit blobs with a bright highlight,
    a darker rim, and a soft shadow, scattered up and out from c (plate px)."""
    rng = np.random.default_rng(seed)
    lx, ly = fr.light
    for i in range(n):
        a = rng.uniform(-math.pi * 0.95, -math.pi * 0.05) if up else rng.uniform(0, 2 * math.pi)
        r = rng.uniform(0.35, 1.0)
        x = c[0] + math.cos(a) * spread[0] * r
        y = c[1] + math.sin(a) * spread[1] * r
        s = rng.uniform(*size)
        drop(fr, x, y, s, s * rng.uniform(1.0, 1.35), depth)


def drop(fr, x, y, rx, ry, depth=None):
    H, W = fr.rgb.shape[:2]
    pad = int(max(rx, ry) * 2 + 6)
    x0, y0 = int(x - pad), int(y - pad)
    x1, y1 = x0 + 2 * pad, y0 + 2 * pad
    if x0 < 0 or y0 < 0 or x1 > W or y1 > H:
        return
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    u, v = (xx - x) / rx, (yy - y) / ry
    r2 = u * u + v * v
    a = np.clip((1 - r2) * rx * 0.8, 0, 1)
    sub = fr.rgb[y0:y1, x0:x1]
    lx, ly = fr.light
    # shadow below-away from the light
    su, sv = (xx - x + lx * rx * 1.4) / rx, (yy - y + ly * ry * 1.6 - ry * 0.8) / ry
    sh = np.clip(1 - (su * su + sv * sv), 0, 1) * 0.25
    sub *= (1 - sh[..., None] * (1 - a[..., None]))
    body = np.float32([0.62, 0.78, 0.90]) * (0.85 + 0.25 * (-(u * lx + v * ly)))[..., None]
    rim = np.clip(r2 - 0.55, 0, 1)[..., None]
    body = body * (1 - 0.45 * rim)
    hl = np.exp(-(((u - lx * 0.45) ** 2 + (v - ly * 0.45) ** 2) / 0.04))[..., None]
    col = np.clip(body + hl * 0.9, 0, 1)
    see = 0.55 + 0.35 * rim                              # resin: partly see-through
    out = sub * (1 - a[..., None] * see) + col * a[..., None] * see
    out = out + hl * 0.4 * a[..., None]
    fr.rgb[y0:y1, x0:x1] = np.clip(out, 0, 1)
    if depth is not None:
        fr.depth[y0:y1, x0:x1] = fr.depth[y0:y1, x0:x1] * (1 - a) + depth * a


# ---------------------------------------------------------------------- shot-private sounds
def cork_pop(seed=0):
    """The straw pulled out of the mud: a hollow tube pop (a resonant body with a quick downward
    glide), a wet smack under it."""
    rng = np.random.default_rng(seed)
    dur = 0.30
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    f = 380 * np.exp(-t / 0.05) + 260
    tube = A.osc(f, dur) * np.exp(-t / 0.045)
    burst = A.bandpass(rng.standard_normal(n), 500, 3500) * np.exp(-t / 0.006) * 1.2
    smack = squelch(seed + 1, 0.2, 0.7) * 0.4
    out = tube + burst + np.pad(smack, (0, n))[:n]
    return out / (np.abs(out).max() + 1e-9)


def splash_sfx(dur=0.3, seed=0, bright=1.0):
    """Small water splash: a burst of bubbly noise with a few plinks."""
    rng = np.random.default_rng(seed)
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    x = A.bandpass(rng.standard_normal(n), 600 * bright, 6000) * np.exp(-t / (dur * 0.25))
    for _ in range(5):
        k = int(rng.uniform(0.0, 0.7) * n)
        fq = rng.uniform(700, 1600) * bright
        m = n - k
        tt = np.arange(m) / A.SR
        x[k:] += 0.5 * np.sin(2 * np.pi * (fq + 900 * tt / 0.05) * tt) * np.exp(-tt / 0.02)
    return x / (np.abs(x).max() + 1e-9)


def gurgle(dur=0.7, seed=0):
    """The reservoir refilling: bubbly low gurgles and a rushing swell."""
    rng = np.random.default_rng(seed)
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    rush = A.lowpass(rng.standard_normal(n), 900) * np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 0.7 * 0.6
    out = rush
    for i in range(10):
        k = int(rng.uniform(0, 0.8) * n)
        b = squelch(seed + 10 + i, rng.uniform(0.08, 0.16), rng.uniform(0.9, 1.6), 0.3) * rng.uniform(0.3, 0.7)
        out[k:k + len(b)] += b[: n - k]
    return out / (np.abs(out).max() + 1e-9)


def quack(seed=0, pitch=1.0):
    """A rubber-toy duck quack: a nasal buzz with a falling formant."""
    rng = np.random.default_rng(seed)
    dur = 0.16
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    f0 = (300 + 40 * rng.standard_normal()) * pitch * (1 - 0.25 * t / dur)
    src = A.osc(f0, dur, "saw")
    y = A.bandpass(src, 900 * pitch, 2600 * pitch) * 1.2 + A.bandpass(src, 400, 900) * 0.6
    env = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 0.5
    out = y * env
    return out / (np.abs(out).max() + 1e-9)


def birds(dur, seed=0):
    """Far-off village birds: sparse little chirps."""
    rng = np.random.default_rng(seed)
    n = int(dur * A.SR)
    out = np.zeros(n)
    tt = rng.uniform(0.2, 0.8)
    while tt < dur - 0.3:
        m = int(rng.uniform(0.05, 0.11) * A.SR)
        t = np.arange(m) / A.SR
        f = rng.uniform(2800, 4200) + rng.uniform(-1500, 1500) * t / t[-1]
        c = np.sin(2 * np.pi * np.cumsum(f) / A.SR) * np.sin(np.pi * t / t[-1]) ** 2
        for r in range(int(rng.integers(1, 4))):
            i = int((tt + r * 0.09) * A.SR)
            out[i:i + m] += c[: max(0, n - i)] * rng.uniform(0.4, 1.0)
        tt += rng.uniform(0.6, 1.6)
    return out / (np.abs(out).max() + 1e-9)


def level_mask(poly, shape, seed=0, feather=5.0):
    """A water level: the shoreline polygon (plate px) with a small irregular wobble, softly edged."""
    m = clay.poly_mask(poly, shape, 0)
    n = cv2.resize(P.smooth_noise(shape[0] // 8, shape[1] // 8, seed, 2.5), (shape[1], shape[0]))
    edge = cv2.GaussianBlur(m, (0, 0), 9) + 0.07 * n
    return cv2.GaussianBlur((edge > 0.5).astype(np.float32), (0, 0), feather)


def wet_band(wet, where, width=16.0):
    """Darkened wet mud in a band just outside a shoreline, fading out over ~2 x width px."""
    out = np.clip(cv2.GaussianBlur(wet, (0, 0), width) * 2.4 - wet * 1.2, 0, 1)
    return out * (1 - wet) * where


def _fill_small_holes(m, max_area=600):
    inv = (1 - m).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(inv, connectivity=4)
    out = m.copy()
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] < max_area:
            out[lab == i] = 1
    return out


def duck_mask_a(rgb, depth, box):
    """The standing ducks of pose A as solid cut-outs: bodies stand out of the ground in the depth map
    (depth minus each row's median, the mud), beaks, legs and feet are the saturated orange just below or
    beside a body. Shrunk 2 px and edged over ~1 px, so no mud rides along and nothing is see-through."""
    ys, xs = np.nonzero(box > 0)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    d = depth[y0:y1, x0:x1]
    g = cv2.GaussianBlur(np.median(d, axis=1, keepdims=True), (0, 0), 6)
    body = ((d - g) > 0.02).astype(np.uint8)
    img = (np.clip(rgb[y0:y1, x0:x1], 0, 1) * 255).astype(np.uint8)
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV).astype(np.float32)
    h, s, v = hsv[..., 0], hsv[..., 1] / 255, hsv[..., 2] / 255
    orange = ((s > 0.66) & (h >= 4) & (h <= 22) & (v > 0.30)).astype(np.uint8)
    down = np.zeros_like(body)
    for k in range(0, 70, 5):
        down |= np.roll(body, k, axis=0)
    zone = cv2.dilate(body, np.ones((25, 25), np.uint8)) | cv2.dilate(down, np.ones((5, 25), np.uint8))
    m = body | (orange & zone)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    keep = np.zeros_like(m)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] > 1200:
            keep[lab == i] = 1
    keep = cv2.erode(_fill_small_holes(keep), np.ones((5, 5), np.uint8))
    out = np.zeros(box.shape, np.float32)
    out[y0:y1, x0:x1] = keep
    return cv2.GaussianBlur(out, (0, 0), 0.8)


def duck_mask_b(rgb, region):
    """The swimming ducks of pose B: everything warm (not water blue) inside their polygon, shrunk 2 px."""
    ys, xs = np.nonzero(region > 0.05)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    img = (np.clip(rgb[y0:y1, x0:x1], 0, 1) * 255).astype(np.uint8)
    hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV).astype(np.float32)
    h, s, v = hsv[..., 0], hsv[..., 1] / 255, hsv[..., 2] / 255
    warm = (((h < 35) | (h > 165)) & (v > 0.45) & ((s > 0.12) | (v > 0.8))).astype(np.uint8)
    warm = cv2.morphologyEx(warm, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    warm = cv2.morphologyEx(warm, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(warm)
    keep = np.zeros_like(warm)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] > 1500:
            keep[lab == i] = 1
    keep = cv2.erode(_fill_small_holes(keep, 2000), np.ones((5, 5), np.uint8))
    out = np.zeros(region.shape, np.float32)
    out[y0:y1, x0:x1] = keep * (region[y0:y1, x0:x1] > 0.05)
    return cv2.GaussianBlur(out, (0, 0), 0.8)


def boat_mask(depth, box):
    """The floating boat in pose B: what stands out of the water in the depth map inside its box."""
    ys, xs = np.nonzero(box > 0)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    d = depth[y0:y1, x0:x1]
    g = cv2.GaussianBlur(np.median(d, axis=1, keepdims=True), (0, 0), 6)
    m = ((d - g) > 0.012).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    keep = np.zeros_like(m)
    if n > 1:
        keep[lab == 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))] = 1
    keep = cv2.dilate(_fill_small_holes(keep, 5000), np.ones((5, 5), np.uint8))
    out = np.zeros(box.shape, np.float32)
    out[y0:y1, x0:x1] = keep
    return cv2.GaussianBlur(out, (0, 0), 2.0)
