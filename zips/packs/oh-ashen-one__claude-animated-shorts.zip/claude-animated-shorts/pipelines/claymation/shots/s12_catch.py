"""Catch: "A ban wouldn't end data centers. It would decide where they're built."

Set: y11_catch_key.png (pose A: a clay hand has pinched the data center model up off the left continent,
a bare rectangle of fresh clay where it stood) and _poseB.png (pose B: the hand sets it down on the right
continent). Same set, region mode.
    "end"     the hand lifts: a dip (anticipation), a jolt up, crumbs of clay drop from the model's base
    "data"    the data card is lowered in on its threads over the top left of the map
    "where"   the hand carries the model across (anticipation, in-between, held pose B) with a knock
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.config import FPS
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# only the hand, sleeve and model of each pose are swapped (key px, 941x1672): pose B's painting redraws the
# map (the central landmass turns to water), so everything else stays the key's own map
HAND_A = [(290, 60), (941, 60), (941, 520), (720, 640), (560, 760), (430, 920), (250, 900), (290, 600)]
HAND_B = [(850, 320), (941, 320), (941, 1250), (820, 1295), (660, 1305), (415, 1295), (405, 1100), (455, 820),
          (560, 640), (700, 555), (850, 465)]
REGION = [HAND_A, HAND_B]
# pose B's model set down on the map, with the rim of sand it sits on (key px): all of it comes from B
HOUSE_B = [(790, 1020), (941, 1000), (941, 1180), (790, 1180)]      # B's cottage right of the thumb: not hand
BOX_B = [(405, 1145), (560, 990), (680, 990), (690, 1190), (560, 1300), (430, 1320), (400, 1270)]
# where pose A's hand shadow may lie (key px); only its darker WATER pixels are replaced
SHADOW_A = [(300, 1100), (330, 1000), (560, 760), (700, 600), (941, 560), (941, 720), (800, 760), (600, 1000),
            (450, 1100)]
CRUMB_FROM = [(300, 880), (340, 895), (385, 905), (325, 900)]          # key px under the model's base
CRUMB_TO = [(270, 975), (300, 1010), (360, 990), (318, 1030)]           # where they land on the map


class Shot(BaseShot):
    light = (0.45, -0.85)         # the overhead lamp, a little to the right (the hand's shadow falls left)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_end = c.f("end")
        self.f_card = c.f("data") - 2
        self.f_where = c.f("where")
        tc = (self.f_where - self.f0) / FPS        # the camera holds still across the carry cut
        self.setup(anchor=(0.5, 0.5), region=REGION, switches=[(self.f_where, "B", {"inb": False})],
                   zoom=track((0, 1.0), (tc - 0.25, 1.024, "inout"), (tc + 0.25, 1.024), (c.dur, 1.03, "inout")),
                   x=track((0, 6.0), (tc - 0.25, 12.5), (tc + 0.25, 12.5), (c.dur, 14.0)))
        self.cam.add_bump(self.f_end, 0.0, -1.8)
        # no camera knock on the carry: only the hand, its model and their shadows change at the cut
        rgb, dep, self.hand, self.carry_m = carry_plate(self.rep, self.kp, ctx.stem)
        self.rep._img["B"] = (rgb, dep, self.carry_m)
        # the lift / lean nudges move the hand a few px: a wider soft mask so no edge of the old hand stays
        self.lift_m = cv2.GaussianBlur(cv2.dilate((self.hand > 0.5).astype(np.uint8),
                                                  cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41))).astype(np.float32),
                                       (0, 0), 5.0)
        self.clay = cv2.GaussianBlur(np.maximum(self.carry_m, self.hand), (0, 0), 3.0)   # boil the hands only
        self.hand_origin = tuple(self.kp(420, 880))
        self.card = tall_card(["Data center", "power use: set", "to double", "by 2030"], "(IEA)", width=300,
                              seed=17, light=self.light)
        self.card_xy = (100, 250)        # hangs over the top-left of the map, clear of the hand in both poses
        self.crumbs = [crumb(9 + 2 * i, seed=50 + i, light=self.light) for i in range(len(CRUMB_FROM))]
        self.focus_A = self.focus_at(400, 760, "A")
        self.focus_B = self.focus_at(520, 1150, "B")
        self.d_map = self.focus_at(150, 1150, "A")

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, "A" if st.startswith("ant") else st, boil=False)
        fr.pose = st
        k = (f - self.f_end) // 2
        if st.startswith("ant"):          # the carry's anticipation: the held hand leans up and away
            clay.nudge_region(fr, self.lift_m, self.hand_origin, sx=1.0, sy=0.99, dx=-3.0, dy=-6.0)
        if st == "A":
            lift = {-2: (0, 2.0, 1.0, 0.99), -1: (0, 5.0, 1.0, 0.985), 0: (-2.0, -9.0, 1.0, 1.012),
                    1: (-0.5, -3.5, 1.0, 1.004)}.get(k)
            if lift:
                dx, dy, sx, sy = lift
                clay.nudge_region(fr, self.lift_m, self.hand_origin, sx=sx, sy=sy, dx=dx, dy=dy)
        self.stage.boil(fr)
        self.draw_crumbs(fr, f, k)
        d = self.focus_for(f)
        self.hang_card(fr, f, d)
        return fr

    def hang_card(self, fr, f, d):
        """The data card lowered in on two light threads (visible against the dark wall) with a soft shadow
        on the map behind it."""
        if f < self.f_card:
            return
        x, y = self.op(*self.card_xy)
        an = P.lower_in(f, self.f_card)
        hung = P.hanging(self.card, -(y + 10), seed=self.ctx.index + 3, color=(0.80, 0.74, 0.62))
        P.place(fr, hung, x, y + an["dy"], depth=d, shadow="hang", angle=an["angle"],
                origin=(hung.anchor[0] + self.card.w / 2, 0), label=self.card.label, shadow_opacity=0.55,
                shadow_dist=22, shadow_blur=9)
        self._event(self.f_card, "card")

    def draw_crumbs(self, fr, f, k):
        """Crumbs drop from the model's base on the lift: three exposures falling, then lying on the map."""
        if k < 0:
            return
        for i, (cp, (a, b)) in enumerate(zip(self.crumbs, zip(CRUMB_FROM, CRUMB_TO))):
            kk = k - (i % 2)
            if kk < 0:
                continue
            u = min(1.0, (kk / 3.0) ** 1.6)
            x = a[0] + (b[0] - a[0]) * u
            y = a[1] + (b[1] - a[1]) * u
            px, py = self.kp(x, y)
            P.place(fr, cp, px, py, depth=self.d_map, shadow="contact" if u >= 1 else "hang",
                    shadow_dist=3 if u >= 1 else 6 + 30 * (1 - u), light_match=0.6)

    def focus_for(self, f):
        return self.focus_A            # one focus: a rack between poses would change the whole map's blur

    def hand_mask(self, f):
        """Plate-space mask of everything the carry may change (both hands, models, shadows)."""
        return np.maximum(self.carry_m, self.hand)

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f_end - 2, "lift_anticipation", {}),
                (self.f_end, "lift_crumbs", {"word": "end"}),
                (self.f_card, "data_card", {"word": "data"}),
                (self.f_where - 4, "carry_anticipation", {}),
                (self.f_where, "carry_poseB", {"word": "where"})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=61) * 0.6, at(self.f0) - 0.5, -13)
        snd.sfx(A.squelch(seed=62, dur=0.22, pitch=0.75), at(self.f_end - 2), -21, 0.2)
        snd.sfx(A.clay_pop(seed=63, pitch=0.85), at(self.f_end), -17, 0.2)
        for i in range(len(CRUMB_FROM)):
            snd.sfx(A.perc("shaker", seed=64 + i, pitch=1.6 + 0.2 * i), at(self.f_end + 6 + 2 * (i % 2)), -33, -0.2)
        snd.sfx(A.string_creak(seed=70), at(self.f_card), -30, -0.5)
        snd.sfx(A.paper_flick(seed=71), at(self.f_card + 2), -28, -0.5)
        snd.sfx(A.whoosh(seed=72) if hasattr(A, "whoosh") else A.paper_rustle(0.3, seed=72), at(self.f_where - 4), -27, 0.3)
        snd.sfx(A.squelch(seed=73, dur=0.25, pitch=0.7), at(self.f_where), -18, 0.4)
        snd.sfx(A.wood_knock(seed=74, pitch=0.8, hard=0.9, dur=0.35), at(self.f_where + 2), -19, 0.4)


def make(ctx):
    return Shot(ctx)


def crumb(r, seed, light):
    """A crumb of brown clay (r px), lit from the set's lamp."""
    rng = np.random.default_rng(seed)
    S = 2 * r + 6
    a = np.zeros((S, S), np.float32)
    pts = [(S / 2 + r * (0.75 + 0.35 * rng.random()) * np.cos(t), S / 2 + r * (0.7 + 0.35 * rng.random()) * np.sin(t))
           for t in np.linspace(0, 2 * np.pi, 9, endpoint=False)]
    cv2.fillPoly(a, [np.int32(pts)], 1.0, cv2.LINE_AA)
    a = cv2.GaussianBlur(a, (0, 0), 0.7)
    hgt = cv2.GaussianBlur(a, (0, 0), r * 0.5) * r
    rgb = P.shade(hgt, np.float32([0.47, 0.36, 0.28]) * np.ones((S, S, 1), np.float32), light, strength=1.0)
    return P.Prop(np.dstack([rgb, a]).astype(np.float32), hgt, anchor=(S / 2, S / 2), text=False, label="crumb")


def tall_card(lines, source, width, seed, light, cap=30):
    """The data card for a narrow column: every row measured, so nothing is clipped at the card's foot."""
    import whatif.text as T
    items = [(r, {"kind": "body", "cap": cap, "weight": 800}) for r in lines]
    items.append((source, {"kind": "body", "cap": 30, "weight": 600, "color": (0.30, 0.26, 0.24)}))
    hs = [T.text_alpha(r, T.font("body", T.size_for_cap("body", o["cap"], o["weight"]), o["weight"])).shape[0]
          for r, o in items]
    gap = 0.32
    H = int(sum(hs) + cap * gap * (len(items) - 1) + cap * 1.6)
    c = P.card(width, H, "card", seed, light=light)
    c = P.Prop(c.rgba.copy(), c.height, c.anchor, text=False, label="card")
    P.print_text(c, items, cap=cap, line_gap=gap, seed=seed, max_w=width - 24)
    c.label = " / ".join(r for r, _ in items)
    return c


def carry_plate(rep, kp, tag):
    """Pose B as the key's plate everywhere except the hands: A's hand + model + cuff and its shadow on the
    water (filled from the aligned B painting, which shows the open water there) and B's hand + model +
    sleeve and its shadow. Pose B's painting redraws the map (the central landmass turns to water, the rim
    thins), so nothing else may come from it. Masks come from the depth (the hand is by far the nearest
    thing on its rows), dilated ~12 px and feathered ~6 px. Returns (rgb, depth, mask A hand, mask)."""
    from PIL import Image
    from whatif.plate import depth_of, fit_image
    from whatif.replace import _diff, _ecc
    A, Ad = rep.a, rep.a_depth
    H, W = A.shape[:2]
    raw = fit_image(rep.paths["B"], rep.fit, size_like=Image.open(rep.paths["A"]).size)

    def poly(pts):
        z = np.zeros((H, W), np.uint8)
        cv2.fillPoly(z, [np.round(np.float32(kp(pts))).astype(np.int32)], 1)
        return z

    # align B to the key on what both paintings share (not the hands, not the redrawn middle)
    hands = cv2.dilate(poly(HAND_A) | poly(HAND_B) | poly(SHADOW_A), np.ones((41, 41), np.uint8))
    w = _ecc(A, raw)
    Bw = cv2.warpPerspective(raw, w, (W, H), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
    d0 = _diff(A, Bw)
    bg = ((d0 < np.quantile(d0, 0.6)) & (hands == 0)).astype(np.float32)
    w = _ecc(A, raw, mask=bg, warp=w)
    Bw = cv2.warpPerspective(raw, w, (W, H), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
    # tone: the key - B offset where both show the same thing, filled smoothly (normalised blur at 1/4 size)
    s = 0.25
    small = lambda x: cv2.resize(x, (int(W * s), int(H * s)), interpolation=cv2.INTER_AREA)
    D = A - Bw
    ok = ((np.abs(D).max(2) < 0.07) & (hands == 0)).astype(np.float32)
    num = cv2.GaussianBlur(small(D * ok[..., None]), (0, 0), 22)
    den = cv2.GaussianBlur(small(ok), (0, 0), 22)[..., None]
    Bw = np.clip(Bw + cv2.resize(num / (den + 1e-4), (W, H), interpolation=cv2.INTER_LINEAR), 0, 1).astype(np.float32)
    Bd = depth_of(np.ascontiguousarray(Bw), f"{tag}_B_aligned")

    def near(d, region):
        """The hand: well nearer than the map on its own row (low quantile of the key's depth on the row)."""
        base = np.quantile(Ad, 0.2, axis=1, keepdims=True)
        m = ((d - base > 0.10) & (region > 0)).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        if n < 2:
            return m
        m = (lab == 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))).astype(np.uint8)
        ff = m.copy()
        cv2.floodFill(ff, np.zeros((H + 2, W + 2), np.uint8), (0, 0), 1)
        return m | (1 - ff)

    ha = near(Ad, poly(HAND_A))
    hb = near(Bd, poly(HAND_B) & (1 - poly(HOUSE_B)))

    def lab(x):
        L = cv2.cvtColor(np.ascontiguousarray(x, np.float32), cv2.COLOR_RGB2LAB)
        return L[..., 0], L[..., 1], L[..., 2]

    La, aa, ba = lab(A)
    Lb, ab, bb = lab(Bw)
    water_a, water_b = ba < -10, bb < -10
    # B's model sits ON the map (depth ~ the map's): add the grey clay next to B's hand
    grey = (np.abs(ab) < 8) & (np.abs(bb) < 14) & (Lb > 15) & (Lb < 80)
    hb = hb | (grey & (cv2.dilate(hb, np.ones((61, 61), np.uint8)) > 0) & (poly(HAND_B) > 0)).astype(np.uint8)
    hb = cv2.morphologyEx(hb, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21)))
    hb = hb | poly(BOX_B)
    # A's shadow lies on open water: wherever the key shows water inside SHADOW_A, B's (lit) water replaces it
    sa = ((poly(SHADOW_A) > 0) & water_a & water_b).astype(np.uint8)
    # B's shadow: B darker than the key next to B's hand, on water in both
    near_b = cv2.dilate(hb, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (241, 241))) > 0
    left_of_b = np.arange(W)[None, :] < np.nonzero(hb)[1].mean()        # the lamp is up-right: shadow falls left
    sb = (near_b & left_of_b & (hb == 0) & water_a & water_b & (Lb < La - 6)).astype(np.uint8)
    sh = cv2.morphologyEx(sa | sb, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
    n, lb_, st, _ = cv2.connectedComponentsWithStats(sh)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] < 2500:
            sh[lb_ == i] = 0
    sh = cv2.morphologyEx(sh, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))           # ~12 px
    k6 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))
    # ~12 px round A's hand and both shadows; round B's hand only ~6 px where the paintings disagree (B's
    # redrawn map must not bleed into the key's land next to the fingers)
    similar = (np.abs(A - Bw).max(2) < 0.10).astype(np.uint8)
    hard = (cv2.dilate(ha | sh, k) | cv2.dilate(hb, k6) | (cv2.dilate(hb, k) & similar)).astype(np.float32)
    M = cv2.GaussianBlur(hard, (0, 0), 6.0)                              # ~6 px feather
    mA = cv2.GaussianBlur(cv2.dilate(ha, k).astype(np.float32), (0, 0), 6.0)
    rgb = (A * (1 - M[..., None]) + Bw * M[..., None]).astype(np.float32)
    dep = (Ad * (1 - M) + Bd * M).astype(np.float32)
    return rgb, dep, mA, M.astype(np.float32)
