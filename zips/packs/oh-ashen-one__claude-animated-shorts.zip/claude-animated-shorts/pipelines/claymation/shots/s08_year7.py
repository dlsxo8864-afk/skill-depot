"""Year 7: "Your retirement would feel it. Five companies are spending eight hundred billion dollars on this."

Set: y07_retire_key.png (pose A: five clay towers crowd the low end of a see-saw, the piggy bank perched
up on the high end, a pensioner couple on the bench) and _poseB.png (pose B: same camera; the towers have
stepped off onto the grass, the see-saw has slammed down on the piggy bank's end, coins in the air, the
couple jolted off the bench). Most of the picture changes, so B is a cut inside the shot.
    (start)     the towers bounce on the plank, cheering, on 2s; the piggy bank teeters up top
    "feel"      the piggy bank wobbles: the plank creaks
    "Five"-4    the towers crouch (anticipation), -2 they spring (stretch, a little up)
    "Five"      cut to B with a camera knock: crash, the towers are off
    +0..+6      the coins burst out of the piggy bank: cut-out coins from the painting fly from its back
                to where they are painted, then fall and settle in the grass
    "spending"  data card lowered in on threads: 5 companies, about $800 billion in 2026
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

TOWERS_A = [(325, 470), (720, 450), (935, 620), (935, 1095), (720, 1090), (330, 900)]
TOWER_FEET = (630, 1040)
PIG_A = [(35, 590), (200, 590), (205, 745), (35, 745)]
PIG_B = [(55, 785), (225, 785), (225, 970), (55, 970)]
COIN_BOX = (0, 470, 360, 850)          # key px: where the coins are painted in B
COIN_AREA = [(0, 470), (360, 470), (360, 760), (230, 800), (215, 850), (0, 850)]   # ... above the plank
SLOT_B = (150, 800)                    # key px: the piggy bank's back in B (the coins come from here)
GROUND_Y = (975, 1010)                 # key px: where fallen coins come to rest


class Shot(BaseShot):
    light = (-0.75, -0.55)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_feel = c.f("feel")
        self.f_five = c.f("Five")
        self.f_card = c.f("spending") - 2
        self.setup(anchor=(0.5, 0.5), mode="full", switches=[(self.f_five, "B")],
                   zoom=track((0, 1.0), (c.dur, 1.03, "inout")), y=track((0, -10.0)))
        self.cam.add_bump(self.f_five, -2.5, 4.0)
        self.cam.add_bump(self.f_five + 4, 1.0, -1.6)
        self.towers = clay.poly_mask(self.kp(TOWERS_A), (PH, PW), 10.0)
        self.pig_a = clay.poly_mask(self.kp(PIG_A), (PH, PW), 8.0)
        self.pig_b = clay.poly_mask(self.kp(PIG_B), (PH, PW), 8.0)
        B_rgb, B_d, _ = self.rep.pose("B")
        self.clean_b, self.coins = cut_coins(B_rgb, self.kp(COIN_AREA))
        self.slot = np.float32(self.kp(*SLOT_B))
        rng = np.random.default_rng(7)
        g0, g1 = self.kp(0, GROUND_Y[0])[1], self.kp(0, GROUND_Y[1])[1]
        for cn in self.coins:
            cn["ground"] = float(rng.uniform(g0, g1))
            cn["delay"] = int(rng.integers(0, 2))
            cn["spin"] = float(rng.uniform(0.55, 1.0))
        self.card = P.data_card(["5 companies,", "about $800 billion", "in 2026"], "Company guidance, Q3 2026",
                                width=360, cap=36, seed=71, wrap=False, source_kind="body", light=self.light)
        self.card_xy = (300, 250)
        self.focus_A = self.focus_at(620, 760, "A")
        self.focus_B = self.focus_at(150, 880, "B")

    # ------------------------------------------------------------------ picture
    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        if st == "A":
            self.act_a(fr, f)
        else:
            self.act_b(fr, f)
        self.stage.boil(fr)
        d = self.focus_for(f)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_five, 4.5)])
        self.draw_card(fr, f, self.card, self.f_card, xy=self.card_xy, depth=d)
        return fr

    def act_a(self, fr, f):
        k = (f - self.f_five) // 2                      # -2 crouch, -1 spring
        feet = self.kp(*TOWER_FEET)
        if k == -2:
            clay.nudge_region(fr, self.towers, feet, sx=1.03, sy=0.95)
        elif k == -1:
            clay.nudge_region(fr, self.towers, feet, sx=0.97, sy=1.05, dx=6, dy=-10)
        else:                                           # cheering bounce on the plank
            e = (f - self.f0) // 2
            dy = (0.0, -4.0, -1.0, -5.0)[e % 4]
            clay.nudge_region(fr, self.towers, feet, sy=1.0 + (0.012 if dy < -3 else 0.0), dy=dy)
        j = (f - self.f_feel) // 2
        if 0 <= j < 6:                                  # the piggy bank teeters on "feel"
            ang = (5.0, -4.0, 3.0, -2.0, 1.0, 0.0)[j]
            clay.nudge_region(fr, self.pig_a, self.kp(118, 735), angle=ang)

    def act_b(self, fr, f):
        k = (f - self.f_five) // 2
        if k in (0, 1):                                 # the crash squashes the piggy bank, then rebound
            clay.nudge_region(fr, self.pig_b, self.kp(140, 965), sx=(1.08 if k == 0 else 0.97),
                              sy=(0.88 if k == 0 else 1.04))
        hole = self.coin_hole()
        fr.rgb = fr.rgb * (1 - hole) + self.clean_b * hole
        for cn in self.coins:
            self.draw_coin(fr, cn, k - cn["delay"])

    def coin_hole(self):
        if not hasattr(self, "_hole"):
            m = np.zeros((PH, PW), np.float32)
            for cn in self.coins:
                x0, y0 = cn["x0"], cn["y0"]
                h, w = cn["a"].shape
                m[y0:y0 + h, x0:x0 + w] = np.maximum(m[y0:y0 + h, x0:x0 + w], cv2.dilate(cn["a"], np.ones((7, 7), np.uint8)))
            self._hole = np.clip(m, 0, 1)[..., None]
        return self._hole

    def draw_coin(self, fr, cn, k):
        if k < 0:
            return
        cx, cy = cn["c"]
        sx, sy = self.slot
        if k <= 3:                                      # burst: from the slot to the painted place
            s = (0.30, 0.62, 0.88, 1.0)[k]
            x, y = sx + (cx - sx) * s, sy + (cy - sy) * s
            spin = 1.0
        else:                                           # fall and settle
            t = k - 3
            y = min(cy + 7.0 * t * t, cn["ground"])
            x = cx + 2.5 * t * np.sign(cx - sx)
            spin = cn["spin"] if (t % 2) else 1.0
            if y >= cn["ground"]:
                spin = 0.45                             # lying in the grass
        rgba = cn["rgba"]
        if spin != 1.0:
            h, w = rgba.shape[:2]
            rgba = cv2.resize(rgba, (w, max(2, int(h * spin))), interpolation=cv2.INTER_AREA)
        h, w = rgba.shape[:2]
        X, Y = int(round(x - w / 2)), int(round(y - h / 2))
        if spin == 0.45:                                # contact shadow under a settled coin
            sh = cv2.GaussianBlur(rgba[..., 3], (0, 0), 2.0) * 0.35
            _over(fr.rgb, np.zeros((h, w, 3), np.float32), sh, X + 2, Y + 3)
        _over(fr.rgb, rgba[..., :3], rgba[..., 3], X, Y)

    def focus_for(self, f):
        return self.focus_A if self.state(f) == "A" else self.focus_B

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f_feel, "piggy_teeters", {"word": "feel"}),
                (self.f_five - 4, "towers_crouch", {}),
                (self.f_five - 2, "towers_spring", {}),
                (self.f_five, "cut_poseB_crash", {"word": "Five"}),
                (self.f_five + 6, "coins_at_peak", {}),
                (self.f_card, "data_card", {"word": "spending"})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=91) * 0.5, at(self.f0) - 0.5, -12)
        for e in range(self.f0 + 2, self.f_five - 4, 8):     # the towers bouncing on the plank
            snd.sfx(A.wood_knock(seed=e, pitch=0.7, hard=0.3, dur=0.2), at(e), -33, 0.3)
        snd.sfx(A.string_creak(seed=92, dur=0.4), at(self.f_feel), -22, -0.4)
        snd.sfx(A.wood_knock(seed=93, pitch=1.1, hard=0.4, dur=0.2), at(self.f_feel + 2), -28, -0.5)
        snd.sfx(A.squelch(seed=94, dur=0.2, pitch=0.7), at(self.f_five - 4), -22, 0.3)
        snd.sfx(A.string_creak(seed=95, dur=0.3), at(self.f_five - 2), -20, 0.0)
        snd.sfx(A.wood_knock(seed=96, pitch=0.5, hard=1.0, dur=0.6), at(self.f_five), -11, -0.3)
        snd.sfx(A.thunk(seed=97), at(self.f_five), -15, -0.4)
        snd.sfx(A.clay_pop(seed=98, pitch=0.7), at(self.f_five), -18, -0.4)
        rng = np.random.default_rng(99)
        for i in range(14):                                   # coins: a burst of glock-like clinks
            t = at(self.f_five) + 0.03 + i * 0.045 + rng.uniform(0, 0.03)
            snd.sfx(A.perc("glock", seed=100 + i, pitch=1.6 + rng.uniform(-0.3, 0.5)), t, -27 - rng.uniform(0, 5),
                    -0.6 + rng.uniform(0, 0.5))
        for i in range(8):                                    # ... and landing in the grass
            t = at(self.f_five + 10) + i * 0.07 + rng.uniform(0, 0.04)
            snd.sfx(A.tick(seed=120 + i, freq=2600 + 400 * rng.uniform()), t, -31, -0.5 + rng.uniform(0, 0.4))
        snd.sfx(A.string_creak(seed=130), at(self.f_card), -30, 0.4)
        snd.sfx(A.paper_flick(seed=131), at(self.f_card + 2), -27, 0.4)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def cut_coins(rgb, area):
    """Find the painted gold coins in pose B inside the area polygon (plate px), cut each one out as a
    sprite and inpaint the sky / trees behind them. Returns (clean rgb, [coin dict])."""
    u8 = (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
    lab = cv2.cvtColor(u8, cv2.COLOR_RGB2LAB).astype(np.float32)
    L, a, b = lab[..., 0], lab[..., 1] - 128, lab[..., 2] - 128
    m = ((b > 28) & (L > 80) & (a > -4) & (a < 35) & (b > 0.9 * a + 12)).astype(np.uint8)
    box_m = np.zeros_like(m)
    cv2.fillPoly(box_m, [np.round(np.float32(area)).astype(np.int32)], 1)
    m &= box_m
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    n, lb, st, cen = cv2.connectedComponentsWithStats(m)
    coins = []
    hole = np.zeros_like(m)
    for i in range(1, n):
        x, y, w, h, area = st[i]
        if area < 30:
            continue
        cm = (lb == i).astype(np.uint8)
        cm = cv2.dilate(cm, np.ones((3, 3), np.uint8))
        hole |= cm
        p = 3
        x0, y0 = max(x - p, 0), max(y - p, 0)
        x1, y1 = min(x + w + p, PW), min(y + h + p, PH)
        al = cv2.GaussianBlur(cm[y0:y1, x0:x1].astype(np.float32), (0, 0), 0.8)
        rg = np.ascontiguousarray(rgb[y0:y1, x0:x1])
        coins.append({"rgba": np.dstack([rg, al]).astype(np.float32), "a": al, "x0": x0, "y0": y0,
                      "c": (float(cen[i][0]), float(cen[i][1]))})
    hole = cv2.dilate(hole, np.ones((5, 5), np.uint8))
    clean = cv2.inpaint(u8, hole, 6, cv2.INPAINT_TELEA).astype(np.float32) / 255
    return clean, coins


def _over(dst, rgb, a, x, y):
    h, w = a.shape
    H, W = dst.shape[:2]
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return
    al = a[ya - y:yb - y, xa - x:xb - x][..., None]
    dst[ya:yb, xa:xb] = dst[ya:yb, xa:xb] * (1 - al) + rgb[ya - y:yb - y, xa - x:xb - x] * al
