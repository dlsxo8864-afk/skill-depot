"""CTA: "So where would you rather have them: your town, or another country?"

Set: y12_cta_key.png (pose A: the hand holds the data center model halfway between the town and the far
shore), _poseB.png (pose B: the hand has wobbled toward the town), _poseC.png (pose C: toward the far
shore). Same set; B and C are aligned to the key and only the hand region is swapped (region mode).
    "So" ... "them"   the question lands in clay letters in the sky, word by word; the hand hesitates
                      (two small one-exposure wobbles of pose A)
    One hand throughout: pose A's cupped hand with the model and its knitted cuff is lifted off the painting
    as ONE cut-out and re-posed for the town and shore beats by turning and scaling it (<= 15 %) about the
    cuff at the frame's left edge (so the cuff never leaves the edge and no sleeve is ever synthesised);
    behind it is always the same clean sky plate (the key with the hand removed, filled from the B and C
    paintings' own sky, tone-matched to the key). The B and C paintings' hands are never shown.
    "town"            the hand wobbles toward the town (anticipation, in-between, held pose B);
                      the "YOUR TOWN" sign on its stick on the quay jolts
    "country"         the hand wobbles toward the far shore (pose C); the "ANOTHER COUNTRY" sign jolts
    after             the hand comes back to the middle (pose A) and stops; the hold runs >= 2 s
"""
import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif.config import FPS
from whatif.plate import PH, PW
from whatif.shotkit import BaseShot
from whatif.stage import track

# the hand + model + sleeve in all three poses (key px, 992x1585); the town and shore stay the key's
REGION = [(0, 330), (992, 330), (992, 1010), (700, 1010), (560, 860), (300, 1000), (0, 1010)]
HAND_A = [(0, 330), (720, 330), (720, 760), (300, 780), (0, 700)]     # pose A hand (key px), for the wobbles
# the one hand's pose: (dx, dy plate px, degrees + = counter-clockwise, scale) about the cuff pivot.
# Town (lower left): the hand dips and draws back; shore (right): it reaches out. Both stay clear of the
# two signs (the palm never covers their text) and of the title.
HAND_POSE = {"A": (0.0, 0.0, 0.0, 1.0), "B": (0.0, 100.0, 2.0, 0.87), "C": (0.0, -15.0, -2.0, 1.12)}
WORDS = ["So", "where", "would", "you", "rather", "have", "them:"]


class Shot(BaseShot):
    light = (0.25, -0.8)          # dusk sky light from above, a touch from the right

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_town = c.f("town,")
        self.f_country = c.f("country?")
        self.f_mid = self.f_country + 14                    # back to the middle, then the long hold
        # the camera holds still while the hand moves between the town, the shore and the middle
        ta, tb = (self.f_town - 8 - self.f0) / FPS, (self.f_mid + 8 - self.f0) / FPS
        self.setup(anchor=(0.5, 0.5), region=REGION,
                   switches=[(self.f_town, "B"), (self.f_country, "C"), (self.f_mid, "A")],
                   zoom=track((0, 1.0), (ta, 1.008, "inout"), (tb, 1.008), (c.dur, 1.025, "inout")))
        # no camera knocks on the hand's moves: only the hand changes between poses
        match_sky(self.rep, horizon=self.kp(0, 885)[1])
        self.hand_a = clay.poly_mask(self.kp(HAND_A), (PH, PW), 18.0)
        self.hand_origin = tuple(self.kp(150, 560))
        self.build_hand(horizon=self.kp(0, 885)[1])
        bx0, by0, bx1, by1 = self.safe_plate_box()
        self.title = P.ClayTitle([["SO", "WHERE", "WOULD"], ["YOU", "RATHER"], ["HAVE", "THEM?"]],
                                 cap=60, x=bx0 + 10, y=by0 + 22, line_h=1.42, align="center",
                                 max_w=(bx1 - bx0) - 20, seed=21, light=self.light,
                                 colors=[P.CLAY_CREAM, P.CLAY_YELLOW, P.CLAY_CREAM, P.CLAY_CREAM, P.CLAY_CREAM,
                                         P.CLAY_CREAM, P.CLAY_CREAM])
        self.title.cue([c.f(w) for w in WORDS])
        self.sign_town = sign(["YOUR TOWN"], seed=31, light=self.light)
        self.sign_far = sign(["ANOTHER", "COUNTRY"], seed=37, light=self.light)
        self.f_signs = c.f("them:") + 4                      # both signs set down before the choice
        self.f_sign_far = self.f_signs + 4
        self.jit_town = clay.Jitter(41, touches=[self.f_town], amp=2.2, deg=2.5)
        self.jit_far = clay.Jitter(43, touches=[self.f_country], amp=2.2, deg=2.5)
        self.focus = self.focus_at(330, 560, "A")           # the model in the hand
        self.d_town = self.focus_at(200, 1150, "A")
        self.d_far = self.focus_at(720, 1060, "A")

    # ------------------------------------------------------------------ picture
    def build_hand(self, horizon):
        """Pose A's hand + model + cuff as ONE cut-out (from the depth: it is by far the nearest thing above
        the horizon) and the set without it, the hole filled from B's and C's painted sky. The pivot is the
        middle of the cuff where it leaves the plate's left edge."""
        A, Ad, _ = self.rep.pose("A")
        near = (cv2.GaussianBlur(Ad, (0, 0), 1.5) > 0.5).astype(np.uint8)
        near[int(horizon) + 60:] = 0
        n, lab, st, _ = cv2.connectedComponentsWithStats(near)
        keep = (lab == 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))).astype(np.float32)
        alpha = cv2.GaussianBlur(cv2.erode(keep, np.ones((3, 3), np.uint8)), (0, 0), 1.0)
        H, W = alpha.shape
        self.hand_rgba = np.dstack([A, alpha, Ad]).astype(np.float32)
        ys = np.nonzero(keep[:, :3].max(1) > 0.5)[0]
        self.pivot = (0.0, float(ys.mean()) if len(ys) else float(self.kp(0, 560)[1]))
        self.cuff_h = float(ys.max() - ys.min()) if len(ys) else 0.0
        # the set without the hand: B's and C's own sky where they show sky there, then a smooth fill
        hole = cv2.dilate(keep, np.ones((25, 25), np.uint8))
        clean = A.copy()
        filled = np.zeros((H, W), np.float32)
        for name in ("B", "C"):
            rgb, d, _ = self.rep.pose(name)
            ok = hole * (1 - filled) * _sky(rgb) * (cv2.GaussianBlur(d, (0, 0), 1.5) < 0.4)
            ok = cv2.erode(ok, np.ones((5, 5), np.uint8))
            ring = _sky(A) * (1 - hole) * cv2.dilate(hole, np.ones((61, 61), np.uint8)) * _sky(rgb)
            if ring.sum() > 50:                                 # tone-match to the key around the hole
                rgb = rgb + ((A - rgb) * ring[..., None]).sum((0, 1)) / ring.sum()
            m = cv2.GaussianBlur(ok, (0, 0), 3)[..., None]
            clean = clean * (1 - m) + rgb * m
            filled = np.maximum(filled, ok)
        rest = (hole * (1 - filled) > 0.5).astype(np.uint8)
        if rest.any():
            q = (np.clip(clean, 0, 1) * 255).astype(np.uint8)
            s_ = 0.25
            small = cv2.resize(q, (int(W * s_), int(H * s_)), interpolation=cv2.INTER_AREA)
            ms = cv2.resize(cv2.dilate(rest, np.ones((9, 9), np.uint8)), (int(W * s_), int(H * s_)),
                            interpolation=cv2.INTER_NEAREST)
            inp = cv2.inpaint(small, ms * 255, 9, cv2.INPAINT_TELEA)
            big = cv2.GaussianBlur(cv2.resize(inp, (W, H)).astype(np.float32) / 255, (0, 0), 6)
            m = cv2.GaussianBlur(rest.astype(np.float32), (0, 0), 4)[..., None]
            clean = clean * (1 - m) + big * m
        self.clean = np.clip(clean, 0, 1).astype(np.float32)
        self.clean_d = Ad * (1 - hole) + np.minimum(Ad, 0.05) * hole

    def hand_pose(self, f, st):
        """(dx, dy, deg, scale) of the one hand for frame f in pose state st (anticipation: a small lean
        away; in-between: half way)."""
        P_ = HAND_POSE
        if st in P_:
            T = P_[st]
        elif st.startswith("ant"):
            a, b = P_[st[3]], P_[st[4]]
            T = tuple(x - 0.10 * (y - x) for x, y in zip(a, b))
        else:
            a, b = P_[st[0]], P_[st[1]]
            T = tuple(0.5 * (x + y) for x, y in zip(a, b))
        k = (f - self.f0) // 2
        wob = None
        if st == "A" and f < self.f_town - 6:                # hesitation: two tiny wobbles of the held hand
            wob = {6: (1.2, -1.5, -0.8), 7: (-0.6, 0.5, 0.4), 13: (-1.4, -1.2, 0.9), 14: (0.5, 0.4, -0.3)}.get(k)
        if st == "A" and f >= self.f_mid:                    # it stops in the middle: a settle, then still
            wob = {0: (2.5, 2.0, -1.0), 1: (-1.2, -0.8, 0.5), 2: (0.4, 0.3, -0.2)}.get((f - self.f_mid) // 2)
        if st in ("B", "C"):                                 # held out there: a settle on arrival
            f_s = self.f_town if st == "B" else self.f_country
            wob = {0: (3.0 * (1 if st == "C" else -1), 4.0, 0.0), 1: (0.0, -1.5, 0.0)}.get((f - f_s) // 2)
        if wob:
            T = (T[0] + wob[0] * 0.3, T[1] + wob[1], T[2] + wob[2], T[3])
        return T

    def hand_matrix(self, f, st):
        dx, dy, deg, sc = self.hand_pose(f, st)
        M = cv2.getRotationMatrix2D(self.pivot, deg, sc)
        M[0, 2] += dx
        M[1, 2] += dy
        return M

    def hand_mask(self, f):
        """Plate-space alpha of the hand for frame f (for checks)."""
        H, W = self.hand_rgba.shape[:2]
        return cv2.warpAffine(self.hand_rgba[..., 3], self.hand_matrix(f, self.state(f)), (W, H),
                              flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)

    def draw_hand(self, fr, f, st):
        M = self.hand_matrix(f, st)
        H, W = fr.rgb.shape[:2]
        out = cv2.warpAffine(self.hand_rgba, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
        a = out[..., 3:4]
        rgb = out[..., :3]
        lay = np.zeros_like(fr.rgb)
        lay[:] = rgb
        clay.crawl(lay, a[..., 0], fr.e, seed=self.ctx.index * 13 + 3, amp=self.stage.crawl_amp)
        fr.rgb = fr.rgb * (1 - a) + lay * a
        fr.depth = fr.depth * (1 - a[..., 0]) + out[..., 4] * a[..., 0]

    def frame(self, f):
        st = self.state(f)
        fr = self.stage.frame(f, self.clean, self.clean_d, None)
        fr.pose = st
        d = self.focus_for(f)
        self.draw_sign(fr, f, self.sign_town, self.f_signs, (84, 1318), self.d_town, self.jit_town)
        self.draw_sign(fr, f, self.sign_far, self.f_sign_far, (650, 1150), self.d_far, self.jit_far)
        self.draw_hand(fr, f, st)
        self.title.draw(fr, f, depth=d, light_match=0.30)
        return fr

    def draw_sign(self, fr, f, prop, f_in, xy, depth, jit):
        an = P.drop_in(f, f_in, height=40)
        if an is None:
            return
        dx, dy, deg = jit(f)
        x, y = self.op(*xy)
        bx0, by0, bx1, by1 = self.safe_plate_box()
        x = float(np.clip(x, bx0, bx1 - prop.w))
        st = P.on_stick(prop, 150, seed=prop.w)
        P.place(fr, st, x + dx, y + dy + an["dy"], depth=depth, shadow="contact", sx=an["sx"], sy=an["sy"],
                angle=deg, origin=(prop.w / 2, st.h), label=prop.label, light_match=0.5)

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        ev = [(self.ctx.f(w), "title_word", {"word": w}) for w in ("So", "would", "rather", "them:")]
        return ev + [(self.f_signs, "signs_set_down", {}),
                     (self.f_town, "hand_to_town_poseB", {"word": "town,"}),
                     (self.f_country, "hand_to_shore_poseC", {"word": "country?"}),
                     (self.f_mid, "hand_stops_middle", {})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=71) * 0.6, at(self.f0) - 0.5, -14)
        for i, w in enumerate(WORDS):
            snd.sfx(A.clay_pop(seed=80 + i, pitch=1.25 + 0.07 * (i % 3)), at(self.ctx.f(w)) + 0.02, -31, -0.3 + 0.1 * i)
        snd.sfx(A.wood_knock(seed=90, pitch=1.2, hard=0.6, dur=0.25), at(self.f_signs + 2), -25, -0.5)
        snd.sfx(A.wood_knock(seed=91, pitch=1.05, hard=0.6, dur=0.25), at(self.f_sign_far + 2), -26, 0.5)
        for f, pan, s in ((self.f_town, -0.4, 92), (self.f_country, 0.4, 95)):
            snd.sfx(A.squelch(seed=s, dur=0.2, pitch=0.85), at(f - 4), -22, pan)
            snd.sfx(A.clay_pop(seed=s + 1, pitch=0.8), at(f), -19, pan)
            snd.sfx(A.wood_knock(seed=s + 2, pitch=1.3, hard=0.5, dur=0.2), at(f + 2), -27, pan)
        snd.sfx(A.squelch(seed=99, dur=0.25, pitch=0.7), at(self.f_mid), -21, 0.0)
        snd.sfx(A.perc("glock", seed=100, pitch=1.0), at(self.f_mid + 6), -29, 0.0)


def make(ctx):
    return Shot(ctx)


def sign(lines, seed, light):
    """A small cream card sign with the option painted on it, for a dowel stuck into the set."""
    import whatif.text as T
    cap = 34
    fnt = T.font("body", T.size_for_cap("body", cap, 900), 900)
    w = int(max(T.text_size(fnt, s)[0] for s in lines) + cap * 1.2)
    c = P.card(w, int(cap * (0.8 + 1.5 * len(lines))), "card", seed, light=light)
    c = P.Prop(c.rgba.copy(), c.height, c.anchor, text=False, label=" ".join(lines))
    P.print_text(c, [(s, {"weight": 900, "cap": cap}) for s in lines], seed=seed, paint=True, line_gap=0.45)
    c.label = " ".join(lines)
    return c


def _sky(img):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    m = ((b - r > 0.08) & (b - g > 0.05) & (b > 0.55)).astype(np.float32)
    return cv2.erode(m, np.ones((9, 9), np.uint8))           # keep off soft edges of the hand and model


def match_sky(rep, horizon, sigma=24.0):
    """The swapped poses' sky has a slightly different tone from the key's, which shows as a pale ghost of
    the outgoing hand. Where a pose (or transition drawing) shows sky, pull it to the key's sky: the
    difference key - pose, measured where both show sky, filled smoothly over the rest of the sky
    (normalised blur at 1/4 size) and added inside the pose's swap mask only."""
    A = rep.a
    H, W = A.shape[:2]
    above = np.zeros((H, W), np.float32)
    above[: int(horizon)] = 1.0
    above = cv2.GaussianBlur(above, (0, 0), 6)
    skyA = _sky(A)
    s = 0.25

    def fix(img, m):
        sk = _sky(img) * above
        both = sk * skyA
        D = (A - img) * both[..., None]
        small = lambda x: cv2.resize(x, (int(W * s), int(H * s)), interpolation=cv2.INTER_AREA)
        num = cv2.GaussianBlur(small(D), (0, 0), sigma)
        den = cv2.GaussianBlur(small(both), (0, 0), sigma)[..., None] + 1e-4
        fill = cv2.resize(num / den, (W, H), interpolation=cv2.INTER_LINEAR)
        sk = cv2.GaussianBlur(sk, (0, 0), 1.5)
        w = (np.clip(m, 0, 1) * sk)[..., None]
        return np.clip(img + fill * w, 0, 1).astype(np.float32)

    for name, (rgb, d, m) in list(rep._img.items()):
        if name != "A":
            rep._img[name] = (fix(rgb, m), d, m)
    for key, (ant, inb, m) in list(rep._pair.items()):
        rep._pair[key] = (fix(ant, m), fix(inb, m), m)
