"""Year 6: "Your property taxes could rise. In one Virginia county, data centers pay almost half."

Set: y06_taxes_key.png (pose A: hands on his head, the bill unrolled from the mailbox down the street) and
_poseB.png (pose B: same set-up, he leaps, the bill wrapped round his legs, slippers flying).
    (start)     only a short tongue of the bill hangs out of the mailbox; the rest of the street is bare
                (a clean plate: the painted bill removed by shifting the paving / road over it)
    "rise"      the mailbox jolts and the bill shoots out: the painted paper is uncovered along its own
                length, exposure by exposure, down the path and away down the street (camera knock)
    (pause)     he leaps (anticipation, in-between, held pose B): the bill has caught his legs
    "Virginia"  data card lowered in on threads: Loudoun County, almost half of property tax revenue
Figures: printed on the bill where it comes out of the mailbox (invented tax lines), with the SCENARIO stamp
down the hanging tongue under them from the first frame (the stamp is on the paper whenever the figures show).
"""
from pathlib import Path

import cv2
import numpy as np

from whatif import audio as A
from whatif import clay
from whatif import props as P
from whatif import text as T
from whatif.plate import PH, PW, fit_image
from whatif.shotkit import BaseShot
from whatif.stage import track

# what changes between the poses (key px): the man, the bill round his legs, the slippers
REGION = [(0, 360), (420, 360), (430, 700), (330, 760), (250, 900), (230, 1150), (560, 1180), (590, 1420),
          (330, 1480), (0, 1480)]
# where our bill lies (key px): the tongue under the mailbox, the run toward the camera, the run up the
# path and away down the road
CORRIDOR = [(212, 790), (392, 790), (392, 1170), (470, 1210), (560, 1120), (640, 1010), (690, 900), (700, 820),
            (745, 740), (790, 690), (840, 610), (880, 560), (910, 545), (925, 560), (890, 640), (885, 700),
            (875, 790), (840, 840), (820, 950), (800, 1060), (775, 1190), (720, 1215), (800, 1300), (870, 1440), (900, 1560),
            (941, 1672), (300, 1672), (300, 1430), (212, 1300)]
MOUTH = (330, 815)          # key px: where the bill leaves the mailbox
TONGUE = 390                # plate px of bill hanging out before "rise"
# the bill's face just under the mailbox, the same in both poses (key px, TL TR BR BL): printed figures
PRINT_Q = [(268, 846), (374, 842), (373, 992), (266, 996)]
PLATE = Path(__file__).resolve().parents[2] / "assets" / "plates" / "s07_year6_clean.png"
# SCENARIO stamped down the hanging tongue under the figures, reading upward (key px: bottom and top centre)
STAMP_BOT, STAMP_TOP = (296, 1176), (318, 1004)


class Shot(BaseShot):
    light = (-0.60, -0.70)

    def __init__(self, ctx):
        super().__init__(ctx)
        c = ctx
        self.f_rise = c.f("rise")
        self.f_leap = self.f_rise + 22                     # in the pause after "rise."
        self.f_card = c.f("Virginia") - 2
        self.f_scen = c.f("almost")
        self.setup(anchor=(0.5, 0.5), region=REGION, switches=[(self.f_leap, "B")],
                   zoom=track((0, 1.0), (c.dur, 1.025, "inout")), y=track((0, -20.0)))
        self.cam.add_bump(self.f_rise, 1.5, 2.8)
        self.cam.add_bump(self.f_leap, -1.0, 2.2)
        A_rgb, A_d, _ = self.rep.pose("A")
        self.paper, self.dist = paper_map(A_rgb, self.kp(CORRIDOR), self.kp(*MOUTH))
        # clean plate (assets/plates/s07_year6_clean.png, see rebuild_clean_plate): the key with the bill's path
        # taken from the painted clean plate y06_taxes_clean.png, registered, gain-matched, 10 px feather
        self.clean = fit_image(PLATE, self.fit).astype(np.float32)
        self._reach = {}
        self.k5 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        self.k9 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        self.k15 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
        # the bill's whole zone in pose A (paper, painted outline, cast shadow): wherever the clean plate differs
        # from the painting, plus the measured paper grown a little
        A0 = self.rep.pose("A")[0]
        diff = cv2.GaussianBlur(np.abs(A0 - self.clean).max(2), (0, 0), 2.0)
        self.zone = np.maximum(np.clip((diff - 0.02) / 0.04, 0, 1),
                               cv2.dilate((self.paper > 0.05).astype(np.float32),
                                          cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41))))
        self.zone = cv2.dilate(self.zone, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
        self.dmax = float(self.dist[np.isfinite(self.dist)].max())
        self.box = clay.poly_mask(self.kp([(250, 690), (490, 690), (490, 930), (250, 930)]), (PH, PW), 6.0)
        self.card = P.data_card(["Loudoun County,", "Virginia: almost", "half of property", "tax revenue"],
                                "Loudoun County budget", width=330, cap=34, seed=61, wrap=False,
                                source_kind="body", light=self.light)
        self.card_xy = (380, 300)              # 20 px in from the safe edge through the swing
        self.ink_fig = bill_print()
        self.print_q = np.float32(self.kp(PRINT_Q))
        self.ink_scen, self.col_scen = P.stamp_ink("SCENARIO", P.STAMP_PURPLE, seed=66, cap=32, border=True,
                                                   kind="clay", weight=600, angle=-3.0, pad=4, double=False)
        self.scen_q = spine_quad(self.ink_scen.shape, self.kp(*STAMP_TOP), self.kp(*STAMP_BOT))
        self.focus_A = self.focus_at(200, 620, "A")
        self.focus_B = self.focus_at(160, 600, "B")

    # ------------------------------------------------------------------ picture
    def front(self, f):
        """Length of bill out of the mailbox (plate px of path) at exposure f."""
        if f < self.f_rise:
            return TONGUE
        k = (f - self.f_rise) // 2
        prog = [0.16, 0.34, 0.52, 0.66, 0.78, 0.87, 0.94, 0.98]
        p = prog[k] if k < len(prog) else 1.01
        return TONGUE + (self.dmax + 40 - TONGUE) * p

    def frame(self, f):
        st = self.state(f)
        fr = self.base(f, st, boil=False)
        fl = self.front(f)
        if st == "A" and fl < self.dmax + 30:
            keep = self.reach(fl)
            solid = np.clip(self.paper * 3.0, 0, 1)         # the paper's soft rim counts as paper
            # the paper actually out: connected to the mouth and short of the roll front (hard front, the roll
            # itself covers the cut); nothing of the painted bill beyond the front shows, not even its outline
            vis = solid * keep * np.clip((fl - self.dist) / 3.0 + 0.5, 0, 1)
            # no thin slivers of painted edge left along the cut (the geodesic front runs ahead along the rims)
            core = cv2.morphologyEx((vis > 0.5).astype(np.uint8), cv2.MORPH_OPEN, self.k15)
            vis = vis * cv2.GaussianBlur(cv2.dilate(core, self.k5).astype(np.float32), (0, 0), 1.0)
            beyond = cv2.dilate(solid * (1 - vis), self.k9)
            # the visible paper keeps its own painted edge and cast shadow (a rim round it), the rest of the
            # bill's zone (paper, painted outlines, shadow) is the clean plate
            rim = cv2.dilate(vis, self.k15) * (1 - beyond)
            # ... only where the picture is darker than the clean ground (the cast shadow), never stray painted
            # paper slivers next to the measured mask
            rim *= np.clip((self.clean.mean(2) - fr.rgb.mean(2)) / 0.04, 0, 1)
            show = np.maximum(vis, rim)
            hide = cv2.GaussianBlur(self.zone * (1 - show), (0, 0), 1.2)[..., None]
            fr.rgb = fr.rgb * (1 - hide) + self.clean * hide
            curl_edge(fr, self.paper * (keep > 0.5), self.dist, fl)
        k = (f - self.f_rise) // 2
        jolt = {-1: (1.02, 0.97, 0, 2.0), 0: (0.97, 1.05, 0, -4.0), 1: (1.01, 0.99, 0, 1.0)}.get(k)
        if jolt:
            sx, sy, dx, dy = jolt
            clay.nudge_region(fr, self.box, self.kp(370, 930), sx=sx, sy=sy, dx=dx, dy=dy)
        P.ink_on_quad(fr, self.ink_fig, np.float32(P.INK), self.print_q, opacity=0.9, label="bill figures")
        P.ink_on_quad(fr, self.ink_scen, self.col_scen, self.scen_q, wet=0.25, opacity=0.95, label="SCENARIO")
        self.stage.boil(fr)
        d = self.focus_for(f)
        self.draw_year(fr, f, depth=d, knocks=[(self.f_leap, 4.0)])
        self.draw_card(fr, f, self.card, self.f_card, xy=self.card_xy, depth=d)
        return fr

    def reach(self, fl):
        """Soft mask of the paper actually out of the mailbox at front length fl: the part of the bill
        with dist < fl that is connected to the mouth (stray far pieces at a similar distance stay hidden)."""
        fl = float(fl)
        if fl not in self._reach:
            m = ((self.paper > 0.3) & (self.dist < fl + 8)).astype(np.uint8)
            n, lb = cv2.connectedComponents(m)
            mx, my = np.int32(np.round(self.kp(*MOUTH)))
            ys, xs = np.nonzero(m)
            j = np.argmin((xs - mx) ** 2 + (ys - my) ** 2)
            k = (lb == lb[ys[j], xs[j]]).astype(np.uint8)
            k = cv2.dilate(k, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
            self._reach[fl] = cv2.GaussianBlur(k.astype(np.float32), (0, 0), 2.0)
        return self._reach[fl]

    def focus_for(self, f):
        return self.focus_A if self.state(f) in ("A", "antAB") else self.focus_B

    # ------------------------------------------------------------------ bookkeeping
    def events(self):
        return [(self.f_rise - 2, "mailbox_anticipation", {}),
                (self.f_rise, "bill_shoots_out", {"word": "rise."}),
                (self.f_rise + 14, "bill_fully_unrolled", {}),
                (self.f_leap - 4, "leap_anticipation", {}),
                (self.f_leap, "leap_poseB", {}),
                (self.f_card, "data_card", {"word": "Virginia"})]

    def sound(self, snd):
        at = snd.at_frame
        snd.bed(A.room_tone(self.ctx.dur + 2.0, seed=71) * 0.5, at(self.f0) - 0.5, -12)
        snd.sfx(A.wood_knock(seed=72, pitch=1.2, hard=0.5, dur=0.2), at(self.f_rise - 2), -26, -0.2)
        snd.sfx(A.clay_pop(seed=73, pitch=0.8), at(self.f_rise), -17, -0.2)
        snd.sfx(A.paper_flick(seed=74), at(self.f_rise), -16, -0.1)
        snd.sfx(A.paper_rustle(0.75, seed=75, busy=1.8), at(self.f_rise), -17, 0.2)
        snd.sfx(A.whoosh(0.6, seed=76), at(self.f_rise), -27, 0.3)
        snd.sfx(A.squelch(seed=77, dur=0.22, pitch=0.8), at(self.f_leap - 4), -21, -0.4)
        snd.sfx(A.clay_pop(seed=78, pitch=0.9), at(self.f_leap), -17, -0.4)
        snd.sfx(A.paper_rustle(0.35, seed=79, busy=1.2), at(self.f_leap), -21, -0.3)
        snd.sfx(A.perc("woodblock", seed=80, pitch=0.8), at(self.f_leap + 6), -26, -0.5)
        snd.sfx(A.perc("woodblock", seed=81, pitch=0.9), at(self.f_leap + 8), -28, -0.2)
        snd.sfx(A.string_creak(seed=82), at(self.f_leap), -28, -0.6)
        snd.sfx(A.string_creak(seed=83), at(self.f_card), -30, 0.4)
        snd.sfx(A.paper_flick(seed=84), at(self.f_card + 2), -27, 0.4)


def make(ctx):
    return Shot(ctx)


# ---------------------------------------------------------------------- shot-private helpers
def paper_map(rgb, corridor, mouth):
    """Our bill in pose A (plate px): soft mask and the path length from the mailbox mouth to every bill
    pixel (geodesic, through the bill only), measured from the painting: cream, low-chroma, bright."""
    u8 = (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
    lab = cv2.cvtColor(u8, cv2.COLOR_RGB2LAB).astype(np.float32)
    L, a, b = lab[..., 0], lab[..., 1] - 128, lab[..., 2] - 128
    mu = cv2.blur(L, (9, 9))
    sd = np.sqrt(np.maximum(cv2.blur(L * L, (9, 9)) - mu * mu, 0))
    m = ((L > 112) & (np.abs(a) < 13) & (b > 4) & (b < 46) & (sd < 7.5) & ((L > 168) | (sd < 4.0))).astype(np.uint8)
    cor = np.zeros((PH, PW), np.uint8)
    cv2.fillPoly(cor, [np.round(np.float32(corridor)).astype(np.int32)], 1)
    m &= cor
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    # geodesic distance at quarter resolution, 8-connected dilation steps
    s = 4
    q = cv2.resize(m, (PW // s, PH // s), interpolation=cv2.INTER_AREA) > 0
    q = cv2.morphologyEx(q.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8)).astype(bool)
    dist = np.full(q.shape, np.inf, np.float32)
    mx, my = int(mouth[0] / s), int(mouth[1] / s)
    ys, xs = np.nonzero(q)
    j = np.argmin((xs - mx) ** 2 + (ys - my) ** 2)
    reached = np.zeros(q.shape, np.uint8)
    reached[ys[j], xs[j]] = 1
    dist[ys[j], xs[j]] = 0
    ks = [np.ones((3, 3), np.uint8), cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))]
    qq = q.astype(np.uint8)
    for it in range(1, 3000):                  # square and cross steps alternated: octagonal fronts
        nxt = cv2.dilate(reached, ks[it % 2]) & qq
        new = (nxt > 0) & (reached == 0)
        if not new.any():
            break
        dist[new] = it * s * 0.83
        reached = nxt
    keep = np.isfinite(dist).astype(np.uint8)
    keep = cv2.resize(keep, (PW, PH), interpolation=cv2.INTER_NEAREST)
    d_full = cv2.resize(np.where(np.isfinite(dist), dist, 0).astype(np.float32), (PW, PH),
                        interpolation=cv2.INTER_LINEAR)
    paper = (m & keep).astype(np.uint8)
    paper = cv2.morphologyEx(paper, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25)))
    ff = paper.copy()                                        # fill holes (print shadows, curl undersides)
    cv2.floodFill(ff, np.zeros((PH + 2, PW + 2), np.uint8), (0, 0), 1)
    paper = paper | (1 - ff)
    paper = cv2.dilate(paper, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (17, 17)))
    # spread the distance into the dilated rim: nearest measured value
    d_in = np.where(keep > 0, d_full, 0).astype(np.float32)
    w = cv2.GaussianBlur((keep > 0).astype(np.float32), (0, 0), 6)
    d_sp = cv2.GaussianBlur(d_in, (0, 0), 6) / np.maximum(w, 1e-4)
    dist_p = np.where(keep > 0, d_full, d_sp).astype(np.float32)
    soft = cv2.GaussianBlur(paper.astype(np.float32), (0, 0), 1.5)
    return soft, dist_p


def rebuild_clean_plate(ctx, fit, paper_plate, out_path=PLATE):
    """How assets/plates/s07_year6_clean.png is made (run by hand when the key, the painted clean plate or the
    bill mask changes: `ctx, shot = ep02.load_shot("s07_year6"); rebuild_clean_plate(ctx, shot.fit, shot.paper)`).
    The key everywhere, except the bill's path (the paper plus 20 px, plus the bill's own cast shadow next to it)
    taken from the painted clean plate y06_taxes_clean.png (the image model's repaint with the bill removed; the
    man's pose differs there but he lies outside the path). The clean plate is first registered to the key (ECC
    on gradients over the gate, fence and paving, translation), its colour matched to the key's ground just
    outside the path (per-channel gain: global, refined by a smooth local field), then pasted through a 10 px
    feather that lies inside the path mask (the painted bill is fully replaced). The open gate on the right is
    protected; the left gate post foot gets a soft contact shadow if the pasted ground leaves it lighter."""
    key = cv2.imread(str(ctx.key))[..., ::-1].astype(np.float32) / 255     # RGB, key px
    src = Path(str(ctx.key).replace("_key.png", "_clean.png"))
    cl = cv2.imread(str(src))[..., ::-1].astype(np.float32) / 255
    KH, KW = key.shape[:2]
    assert cl.shape == key.shape, (src, cl.shape, key.shape)
    # plate px -> key px
    M = np.float32([[1 / fit.s, 0, fit.ox / fit.s], [0, 1 / fit.s, fit.oy / fit.s]])
    paper = cv2.warpAffine(paper_plate, M, (KW, KH), flags=cv2.INTER_LINEAR)
    pm = (paper > 0.05).astype(np.uint8)
    ell = lambda r: cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))

    # 1. register the clean plate to the key: gradients of the gate, fence and paving round the path (the man
    #    and the bill excluded)
    def grad(im):
        g = cv2.GaussianBlur(im.mean(2), (0, 0), 1.5)
        return np.hypot(cv2.Sobel(g, cv2.CV_32F, 1, 0), cv2.Sobel(g, cv2.CV_32F, 0, 1))
    reg = np.zeros((KH, KW), np.uint8)
    reg[700:1220, 430:800] = 1
    reg[cv2.dilate(pm, ell(20)) > 0] = 0
    W = np.eye(2, 3, dtype=np.float32)
    cc, W = cv2.findTransformECC(grad(key), grad(cl), W, cv2.MOTION_TRANSLATION,
                                 (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 300, 1e-6), reg, 5)
    assert abs(W[0, 2]) < 12 and abs(W[1, 2]) < 12 and cc > 0.8, (W, cc)
    ca = cv2.warpAffine(cl, W, (KW, KH), flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP,
                        borderMode=cv2.BORDER_REPLICATE)
    print(f"s07 clean plate: ECC cc {cc:.3f}, shift ({W[0, 2]:+.2f}, {W[1, 2]:+.2f}) px")

    # 2. the path mask: the paper plus 20 px, plus the bill's cast shadow just outside it (key darker than the
    #    clean ground, connected to the paper, within 60 px)
    mask = cv2.dilate(pm, ell(20))
    dark = (ca.mean(2) - key.mean(2)) > 0.035
    dark &= cv2.dilate(pm, ell(60)) > 0
    dark = cv2.morphologyEx(dark.astype(np.uint8), cv2.MORPH_OPEN, ell(2))
    n, lb, st, _ = cv2.connectedComponentsWithStats(dark | mask)
    touch = np.unique(lb[mask > 0])
    mask = np.isin(lb, touch[touch > 0]).astype(np.uint8)
    # ... and the bill's far tail up the road beyond the measured corridor (cream paper on the grey road, touching
    # the path mask): the street is bare before "rise"; the tail comes back with the key once the bill is fully out
    lab0 = cv2.cvtColor((key * 255).astype(np.uint8)[..., ::-1], cv2.COLOR_BGR2LAB).astype(np.float32)
    cream = (lab0[..., 0] > 165) & (lab0[..., 2] - 128 > 6) & (np.abs(lab0[..., 1] - 128) < 14)
    cream[:450] = 0
    cream[760:] = 0
    cream[:, :760] = 0
    cream = cv2.dilate(cv2.morphologyEx(cream.astype(np.uint8), cv2.MORPH_OPEN, ell(1)), ell(20))
    n, lb, st, _ = cv2.connectedComponentsWithStats(cream | mask)
    touch = np.unique(lb[mask > 0])
    mask = np.isin(lb, touch[touch > 0]).astype(np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, ell(6))
    mask = cv2.dilate(mask, ell(4))
    # the open gate on the right stays the key's (only the paper itself is replaced there)
    gate = np.zeros((KH, KW), np.uint8)
    gate[800:1240, 806:] = 1
    mask &= ~(gate & ~cv2.dilate(pm, ell(3))) & 1

    # 3. colour match: per-channel gain from the key's ground just outside the path where both pictures agree,
    #    global, then a smooth local field (sigma 50) toward it where the ring is dense enough
    ring = (cv2.dilate(mask, ell(40)) > 0) & (mask == 0) & (np.abs(key - ca).max(2) < 0.08)
    g0 = key[ring].mean(0) / np.maximum(ca[ring].mean(0), 1e-4)
    w = cv2.GaussianBlur(ring.astype(np.float32), (0, 0), 50)[..., None]
    gk = cv2.GaussianBlur(key * ring[..., None], (0, 0), 50)
    gc = cv2.GaussianBlur(ca * ring[..., None], (0, 0), 50)
    loc = np.clip(gk / np.maximum(gc, 1e-4), g0 * 0.9, g0 * 1.1)
    a = np.clip(w / 0.15, 0, 1)
    gain = g0 * (1 - a) + loc * a
    print(f"s07 clean plate: global gain RGB {np.round(g0, 3).tolist()}")
    fill = np.clip(ca * gain, 0, 1)

    # 4. paste through a 10 px feather lying inside the mask
    dist = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    m = np.clip(dist / 10.0, 0, 1)
    m = cv2.GaussianBlur(m, (0, 0), 1.0)[..., None] * (mask[..., None] > 0)
    res = key * (1 - m) + fill * m

    # 5. the left gate post's foot: if the pasted ground right under it is lighter than the ground beside it,
    #    seat it with a soft contact shadow (the post is detected as the white columns above the path)
    u8 = (key * 255).astype(np.uint8)
    lab = cv2.cvtColor(u8[..., ::-1], cv2.COLOR_BGR2LAB).astype(np.float32)
    white = (lab[..., 0] > 150) & (np.abs(lab[..., 1] - 128) < 10) & (lab[..., 2] - 128 < 22)
    colfrac = white[830:990, 560:660].mean(0)
    cols = np.nonzero(colfrac > 0.55)[0] + 560
    if len(cols):
        px0, px1 = int(cols.min()), int(cols.max()) + 1
        colw = (cv2.cvtColor((np.clip(res, 0, 1) * 255).astype(np.uint8)[..., ::-1], cv2.COLOR_BGR2LAB)[..., 0]
                > 150) & (np.abs(lab[..., 1] - 128) < 14)
        foot = 990 + int(np.nonzero(colw[990:1240, px0:px1].mean(1) > 0.5)[0].max(initial=0))
        under = res[foot + 3:foot + 12, px0 - 6:px1 + 6].mean()
        side = res[foot - 10:foot + 10, px1 + 20:px1 + 50].mean()
        print(f"s07 clean plate: left post x {px0}-{px1}, foot y {foot}, under {under:.3f} side {side:.3f}")
        if under > side - 0.03:
            sh = np.zeros((KH, KW), np.float32)
            cv2.ellipse(sh, ((px0 + px1) // 2 + 6, foot + 3), ((px1 - px0) // 2 + 12, 6), 0, 0, 360, 1.0, -1)
            sh[:foot - 1] = 0
            sh = cv2.GaussianBlur(sh, (0, 0), 3.5)[..., None]
            res = res * (1 - 0.35 * sh)
    cv2.imwrite(str(out_path), (np.clip(res, 0, 1)[..., ::-1] * 255 + 0.5).astype(np.uint8))
    return mask


def bill_print():
    """The bill's printed head (invented figures): TAX / +41% / DUE, on a canvas the shape of PRINT_Q
    (drawn at plate scale: cap >= 31 px plate)."""
    W, H = 132, 184
    ink = np.zeros((H, W), np.float32)
    f1 = T.font("body", T.size_for_cap("body", 31, 900), 900)
    f2 = T.font("body", T.size_for_cap("body", 34, 900), 900)
    y = 8
    for s_, fnt in (("TAX", f1), ("+41%", f1), ("DUE", f1)):
        a = T.text_alpha(s_, fnt, tracking=-1)
        if a.shape[1] > W - 4:
            a = cv2.resize(a, (W - 4, a.shape[0]), interpolation=cv2.INTER_AREA)
        x = (W - a.shape[1]) // 2
        ink[y:y + a.shape[0], x:x + a.shape[1]] = np.maximum(ink[y:y + a.shape[0], x:x + a.shape[1]], a)
        y += a.shape[0] + 14
    return P.ink_alpha(ink, seed=64, density=0.9, bleed=0.45, patchy=0.07)


def curl_edge(fr, paper, dist, fl):
    """The unrolling front: the rest of the roll lies across the paper's free end, a small cream cylinder
    with a lit top, a dark underside and a contact shadow (one per branch of the bill)."""
    band = ((paper > 0.5) & (np.abs(dist - fl) < 7)).astype(np.uint8)
    n, lb, st, _ = cv2.connectedComponentsWithStats(band)
    lx, ly = fr.light
    if n < 2:
        return
    top = int(np.argmax(st[1:, cv2.CC_STAT_AREA])) + 1      # one roll: the strip has a single free end
    for i in (top,):
        if st[i, cv2.CC_STAT_AREA] < 60:
            continue
        ys, xs = np.nonzero(lb == i)
        pts = np.float32(np.stack([xs, ys], 1))
        c = pts.mean(0)
        u, s_, vt = np.linalg.svd(pts - c, full_matrices=False)
        ax = vt[0]
        proj = (pts - c) @ ax
        p0, p1 = c + ax * proj.min(), c + ax * proj.max()
        if np.linalg.norm(p1 - p0) < 20:
            continue
        r = 11
        x0, y0 = np.floor(np.minimum(p0, p1) - 3 * r).astype(int)
        x1, y1 = np.ceil(np.maximum(p0, p1) + 3 * r).astype(int)
        H, W = paper.shape
        x0, y0, x1, y1 = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
        if x1 <= x0 or y1 <= y0:
            continue
        sub = fr.rgb[y0:y1, x0:x1]
        q0, q1 = tuple(np.int32(np.round(p0 - [x0, y0]))), tuple(np.int32(np.round(p1 - [x0, y0])))
        def line(off, width, blur):
            m = np.zeros(sub.shape[:2], np.float32)
            cv2.line(m, (q0[0] + off[0], q0[1] + off[1]), (q1[0] + off[0], q1[1] + off[1]), 1.0, width, cv2.LINE_AA)
            return cv2.GaussianBlur(m, (0, 0), blur)[..., None] if blur else m[..., None]
        shadow = line((int(-lx * 7), int(-ly * 7)), 2 * r, 3.0) * 0.45
        sub *= 1 - shadow * (1 - np.float32([0.30, 0.26, 0.30]))
        body = line((0, 0), 2 * r, 0.8)
        cream = np.float32([0.97, 0.89, 0.78])                 # the bill's own paper colour in the sun
        sub[:] = sub * (1 - body) + cream * body
        dark = line((int(round(-lx * r * 0.75)), int(round(-ly * r * 0.75))), max(3, r // 2), 1.5) * body
        sub *= 1 - 0.28 * dark * (1 - np.float32([0.30, 0.22, 0.20]))
        lit = line((int(round(lx * r * 0.45)), int(round(ly * r * 0.45))), max(3, r // 2), 1.2) * body
        sub[:] = sub * (1 - 0.30 * lit) + np.float32([1.0, 0.97, 0.91]) * 0.30 * lit
        rim = line((0, 0), 2, 0.6) * 0.0
        fr.rgb[y0:y1, x0:x1] = sub + rim


def spine_quad(shape, top, bot):
    """Plate quad (TL TR BR BL of the ink) that lays a stamp along a hanging strip from bot to top, reading
    upward (letter tops toward the left), at least full size (cap never shrinks)."""
    h, w = shape
    p1, p0 = np.float32(top), np.float32(bot)
    u = p1 - p0
    L = float(np.linalg.norm(u))
    u /= L
    if L < w:                                    # extend upward to the ink's own length
        p1 = p0 + u * w
    n = np.float32([-u[1], u[0]])                # right-pointing normal
    if n[0] < 0:
        n = -n
    return np.float32([p0 - n * h / 2, p1 - n * h / 2, p1 + n * h / 2, p0 + n * h / 2])
