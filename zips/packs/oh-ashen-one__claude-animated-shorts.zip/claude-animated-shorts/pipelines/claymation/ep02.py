"""Episode 2 ("What if every state banned new data centers?"), claymation, built shot by shot.

    python src/ep02.py --timeline                    # shot table (frames, seconds, narration placement)
    python src/ep02.py --words                       # measured word starts (+ per-word re-transcription check)
    python src/ep02.py --shot s03_year2              # render one shot -> work/shots/s03_year2/
    python src/ep02.py --shot s03_year2 --preview    # ... plus preview.mp4 (picture + its line + its sound)
    python src/ep02.py --shot s03_year2 --frames 300 340    # stills only -> work/shots/s03_year2/stills/
    python src/ep02.py --assemble                    # rendered shots + full mix -> out/ep02_full_vN.mp4
    python src/ep02.py --assemble --name first_two   # -> out/ep02_first_two_vN.mp4

Every shot is rendered per EXPOSURE (even global frames, and the shot's first frame if it is odd); each
exposure is shown for both of its frames, so the picture changes 12 times a second (on 2s).
Per shot, work/shots/<stem>/ holds video.mp4 (H.264 CRF 16, video only), bed.wav and sfx.wav (48 kHz
stereo float stems covering the shot plus 1.0 s before / 1.5 s after), meta.json and, with --preview,
preview.mp4. --assemble joins every shot whose render matches the current timeline (stream copy), lays
the narration, the shot stems and the music bed on one timeline, ducks beds and music under the voice,
carves a further 6+ dB at 2-5 kHz under speech, masters to -14 LUFS with a -2.0 dBTP ceiling (<= -1 dBTP
after AAC), muxes, and writes a contact sheet.
"""
import argparse
import importlib
import json
import math
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import soundfile as sf

import timeline as TL
from whatif import audio as A
from whatif import look
from whatif.config import FPS, OUT, OUT_H, OUT_W, WORK, safe_box
from whatif.shotkit import ShotContext, ShotSound

SHOTS_DIR = WORK / "shots"
X264 = ["-c:v", "libx264", "-preset", "slow", "-crf", "16", "-pix_fmt", "yuv420p", "-profile:v", "high",
        "-tune", "film", "-r", str(FPS)]


# ------------------------------------------------------------------ shot loading
def context(stem):
    shots = TL.layout()
    e = TL.shot_entry(stem)
    return ShotContext(stem=stem, index=e["index"], f0=e["f0"], f1=e["f1"], key=e["key"], wav=e["wav"],
                       year=e["year"], words=e["words"], speech_on=e["speech_on"], speech_off=e["speech_off"],
                       vo_at=e["vo_at"], is_last=e["index"] == len(shots) - 1)


def missing_reason(stem):
    e = TL.shot_entry(stem)
    if not (Path(__file__).resolve().parent / "shots" / f"{stem}.py").exists():
        return f"no module src/shots/{stem}.py"
    if not e["key"].exists():
        return f"no key image {e['key'].name}"
    return None


def load_shot(stem):
    ctx = context(stem)
    mod = importlib.import_module(f"shots.{stem}")
    return ctx, mod.make(ctx)


def exposure_of(ctx, f):
    return max(f - f % 2, ctx.f0)


def render_exposure(ctx, shot, f):
    """Final RGB uint8 for the exposure of frame f, plus text boxes (output px) for the safe-area check."""
    fr = shot.frame(f)
    rgb, dep, boxes = shot.stage.shoot(fr)
    fa = shot.finish_args(f) if hasattr(shot, "finish_args") else {}
    kw = {"focus": shot.focus_for(f), "dof": getattr(shot, "dof", None), "seed": ctx.index * 3 + 1}
    kw.update(fa)
    img = look.finish(rgb, dep, fr.e, **kw)
    return (np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8), boxes


def check_boxes(boxes, f):
    """Readable text must stay inside the safe area."""
    x0, y0, x1, y1 = safe_box()
    bad = []
    for bx0, by0, bx1, by1, lab in boxes:
        if bx0 < x0 - 1 or by0 < y0 - 1 or bx1 > x1 + 1 or by1 > y1 + 1:
            bad.append(f"frame {f}: '{lab}' at ({bx0:.0f},{by0:.0f})-({bx1:.0f},{by1:.0f}) leaves the safe box {safe_box()}")
    return bad


# ------------------------------------------------------------------ parallel render
_W = None


def _init_worker(stem):
    import cv2
    cv2.setNumThreads(1)
    global _W
    _W = load_shot(stem)


def _work(f):
    ctx, shot = _W
    img, boxes = render_exposure(ctx, shot, f)
    return f, img.tobytes(), check_boxes(boxes, f)


def render_video(stem, path, frames, workers=None):
    import multiprocessing as mp
    ctx, shot = load_shot(stem)               # builds every cache once, before the workers start
    shot.frame(ctx.f0)
    workers = max(1, min(workers or 6, 6))
    exps = sorted({exposure_of(ctx, f) for f in frames})
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OUT_W}x{OUT_H}",
           "-r", str(FPS), "-i", "-", *X264, str(path)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    warnings = []
    ctxm = mp.get_context("spawn")            # fork deadlocks once OpenCV/BLAS threads exist
    with ctxm.Pool(workers, initializer=_init_worker, initargs=(stem,)) as pool:
        done = {}
        it = pool.imap(_work, exps, chunksize=1)
        for k, (e, buf, bad) in enumerate(it):
            warnings += bad
            for f in frames:
                if exposure_of(ctx, f) == e:
                    proc.stdin.write(buf)
            if k % 24 == 0:
                print(f"  {stem}: exposure {e} ({k + 1}/{len(exps)})", flush=True)
    proc.stdin.close()
    if proc.wait() != 0:
        raise RuntimeError("ffmpeg failed")
    for w in warnings[:12]:
        print("  [safe area]", w)
    if len(warnings) > 12:
        print(f"  [safe area] ... {len(warnings) - 12} more")
    return ctx, shot, warnings


# ------------------------------------------------------------------ sound
def shot_sound(ctx, shot):
    snd = ShotSound(ctx)
    if hasattr(shot, "sound"):
        shot.sound(snd)
    if ctx.year is not None:                  # the YEAR sign lowered in on its threads two frames after the cut
        f = shot.year_land() if hasattr(shot, "year_land") else ctx.f0 + 2
        snd.sfx(A.string_creak(ctx.index + 40), f / FPS, -30, -0.5)
        snd.sfx(A.wood_knock(ctx.index + 41, 0.9, 0.7), (f + 2) / FPS, -27, -0.5)
    return snd


def voice_line(path):
    """A narration take through the episode voice chain (presence lift, word leveller, gentle compression)."""
    return A.voice_chain_ep(A.load_mono(path))


def master(mix, tmp_path, ceiling=-2.0):
    """Loudness to -14 LUFS integrated with a true-peak ceiling (default -2.0 dBTP; AAC adds up to ~1.4 dB,
    so cmd_assemble lowers it and re-masters until the ENCODED file is <= -1 dBTP)."""
    mix = A.limiter(mix / (np.abs(mix).max() + 1e-9) * 0.5, -6)
    sf.write(tmp_path, mix, A.SR, subtype="FLOAT")
    for _ in range(5):
        I, tp = A.measure_loudness(tmp_path)
        if abs(I + 14.0) < 0.15 and tp <= ceiling + 0.3:
            break
        mix = A.limiter(mix * A.db(-14.0 - I), ceiling)
        sf.write(tmp_path, mix, A.SR, subtype="FLOAT")
    I, tp = A.measure_loudness(tmp_path)
    return mix, I, tp


MUSIC_GAIN = {"pluck": -27.0, "bass": -29.0, "perc": -36.0, "whistle": -30.0}
MUSIC_DUCK = {"pluck": -10.0, "bass": -8.0, "perc": -8.0, "whistle": -20.0}


def mix_timeline(items, total, cut_times, music_t0=0.0):
    """items: [{"bed": arr, "sfx": arr, "at": s}, {"vo": arr, "at": s}]; returns the stereo mix."""
    n = int(round(total * A.SR))
    vo = np.zeros(n)
    beds = np.zeros((n, 2))
    sfx = np.zeros((n, 2))

    def put(buf, x, at):
        i = int(round(at * A.SR))
        if i < 0:
            x, i = x[-i:], 0
        x = x[: max(0, n - i)]
        buf[i:i + len(x)] += x

    for it in items:
        if "vo" in it:
            put(vo, it["vo"], it["at"])
        else:
            put(beds, it["bed"], it["at"])
            put(sfx, it["sfx"], it["at"])
    env = A.duck_envelope(vo)                 # opens 80 ms before every word, full depth for soft ones
    stems = A.music_bed(total + music_t0, cut_times)
    music = np.zeros((n, 2))
    pans = {"pluck": -0.25, "bass": 0.0, "perc": 0.35, "whistle": 0.2}
    for k, x in stems.items():
        x = x[int(music_t0 * A.SR):][:n]
        x = np.pad(x, (0, n - len(x)))
        g = A.db(MUSIC_GAIN[k]) * (1 - (1 - A.db(MUSIC_DUCK[k])) * env)
        a = (pans[k] + 1) * np.pi / 4
        music += np.stack([x * g * np.cos(a), x * g * np.sin(a)], 1) * 1.41
    duck_b = 1 - (1 - A.db(-9)) * env          # ambience beds -9 dB under the voice
    duck_s = 1 - (1 - A.db(-3)) * env          # effects keep their punch, a touch under words
    mix = beds * duck_b[:, None] + music + sfx * duck_s[:, None]
    mix = A.presence_carve(mix, env, -7.5, 1900.0, 5300.0)   # a further >= 6 dB over 2-5 kHz under words
    return mix + np.stack([vo, vo], 1) * A.db(-1)


# ------------------------------------------------------------------ commands
def cmd_shot(stem, preview=False, workers=None):
    why = missing_reason(stem)
    if why:
        print(f"[skip] {stem}: {why}")
        return False
    d = SHOTS_DIR / stem
    d.mkdir(parents=True, exist_ok=True)
    ctx = context(stem)
    t = time.time()
    print(f"{stem}: frames {ctx.f0}-{ctx.f1 - 1} ({ctx.n} frames, {ctx.dur:.2f} s)")
    ctx, shot, warnings = render_video(stem, d / "video.mp4", list(range(ctx.f0, ctx.f1)), workers)
    snd = shot_sound(ctx, shot)
    for bus in ("bed", "sfx"):
        sf.write(d / f"{bus}.wav", snd.buses[bus].astype(np.float32), A.SR, subtype="FLOAT")
    ev = [(int(f), k, {kk: (float(v) if isinstance(v, (int, float, np.floating, np.integer)) else str(v))
                       for kk, v in info.items()}) for f, k, info in shot.events()]
    meta = {"stem": stem, "f0": ctx.f0, "f1": ctx.f1, "stem_t0": snd.t0, "rendered": time.ctime(),
            "events": ev, "words": [{k: w[k] for k in ("w", "s", "e")} for w in ctx.words],
            "safe_area_warnings": len(warnings)}
    (d / "meta.json").write_text(json.dumps(meta, indent=1))
    print(f"{stem}: rendered in {time.time() - t:.0f} s -> {d}")
    print_sync(ctx, ev)
    if preview:
        write_preview(ctx, snd, d)
    return True


def print_sync(ctx, events):
    print("  words: " + " ".join(f"{w['w']}@{w['s']:.2f}" for w in ctx.words))
    seen = set()
    for f, kind, info in sorted(events, key=lambda e: e[0]):
        if (f, kind) in seen:
            continue
        seen.add((f, kind))
        word = info.get("word", "")
        wt = ""
        if word:
            try:
                w = ctx.word(word)
                wt = f"  word '{word}' starts {w['s']:7.3f} s (frame {w['s'] * FPS:6.1f}), event {f / FPS - w['s']:+.3f} s"
            except KeyError:
                pass
        print(f"  {kind:16s} frame {f:5d}  {f / FPS:7.3f} s{wt}")


def write_preview(ctx, snd, d):
    t0 = ctx.f0 / FPS
    items = [{"vo": voice_line(ctx.wav), "at": ctx.vo_at - t0},
             {"bed": snd.buses["bed"], "sfx": snd.buses["sfx"], "at": snd.t0 - t0}]
    mix = mix_timeline(items, ctx.dur, [], music_t0=t0)
    mix, I, tp = master(mix, d / "preview_mix.wav")
    sf.write(d / "preview_mix.wav", mix, A.SR, subtype="PCM_16")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(d / "video.mp4"), "-i", str(d / "preview_mix.wav"),
                    "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                    "-t", f"{ctx.dur:.4f}", str(d / "preview.mp4")], check=True)
    (d / "preview_mix.wav").unlink()
    print(f"  preview: {d / 'preview.mp4'}  ({I:.1f} LUFS, {tp:.1f} dBTP pre-AAC)")


def cmd_stills(stem, frames):
    why = missing_reason(stem)
    if why:
        print(f"[skip] {stem}: {why}")
        return
    ctx, shot = load_shot(stem)
    import cv2
    out = SHOTS_DIR / stem / "stills"
    out.mkdir(parents=True, exist_ok=True)
    for f in frames:
        img, boxes = render_exposure(ctx, shot, f)
        for w in check_boxes(boxes, f):
            print("  [safe area]", w)
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        cv2.imwrite(str(out / f"f{f:05d}.png"), img)
        cv2.imwrite(str(out / f"f{f:05d}_360.png"), cv2.resize(img, (360, 640), interpolation=cv2.INTER_AREA))
        print("wrote", out / f"f{f:05d}.png", f"(state {getattr(shot, 'state', lambda f: '')(f)})")


def video_frames(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_packets", "-show_entries",
                        "stream=nb_read_packets", "-of", "csv=p=0", str(path)], capture_output=True, text=True)
    try:
        return int(r.stdout.strip())
    except ValueError:
        return -1


def next_version(name):
    k = 1
    while (OUT / f"ep02_{name}_v{k}.mp4").exists():
        k += 1
    return k


def cmd_assemble(name="full"):
    shots = TL.layout()
    use, t_new = [], 0.0
    for s in shots:
        d = SHOTS_DIR / s["stem"]
        why = missing_reason(s["stem"])
        if why is None and not (d / "meta.json").exists():
            why = f"not rendered yet (python src/ep02.py --shot {s['stem']})"
        if why is None:
            meta = json.loads((d / "meta.json").read_text())
            if (meta["f0"], meta["f1"]) != (s["f0"], s["f1"]):
                why = f"stale render (frames {meta['f0']}-{meta['f1']}, timeline now {s['f0']}-{s['f1']}); re-render it"
            else:
                n = video_frames(d / "video.mp4")
                if n != s["f1"] - s["f0"]:
                    why = f"video.mp4 has {n} frames, expected {s['f1'] - s['f0']} (still rendering?)"
        if why is None:                      # other builders may re-render while we join: work from a copy
            snap = WORK / "full" / "snap" / s["stem"]
            snap.mkdir(parents=True, exist_ok=True)
            for fn in ("video.mp4", "bed.wav", "sfx.wav", "meta.json"):
                shutil.copy2(d / fn, snap / fn)
            meta = json.loads((snap / "meta.json").read_text())
            if (meta["f0"], meta["f1"]) != (s["f0"], s["f1"]) or video_frames(snap / "video.mp4") != s["f1"] - s["f0"]:
                why = "changed while copying (being re-rendered); try again"
            d = snap
        if why:
            print(f"[skip] {s['stem']}: {why}")
            continue
        use.append({**s, "meta": meta, "dir": d, "shift": t_new - s["f0"] / FPS})
        t_new += (s["f1"] - s["f0"]) / FPS
    if not use:
        print("nothing to assemble")
        return
    total = sum(u["f1"] - u["f0"] for u in use) / FPS
    print(f"assembling {len(use)} of {len(shots)} shots, {total:.2f} s")
    work = WORK / "full"
    work.mkdir(parents=True, exist_ok=True)
    items, cuts = [], []
    for u in use:
        items.append({"vo": voice_line(u["wav"]), "at": u["vo_at"] + u["shift"]})
        bed, _ = sf.read(u["dir"] / "bed.wav", always_2d=True)
        sfx, _ = sf.read(u["dir"] / "sfx.wav", always_2d=True)
        items.append({"bed": bed, "sfx": sfx, "at": u["meta"]["stem_t0"] + u["shift"]})
        if u is not use[0]:
            cuts.append(u["f0"] / FPS + u["shift"])
    mix0 = mix_timeline(items, total, cuts)
    lst = work / "concat.txt"
    lst.write_text("".join(f"file '{u['dir'] / 'video.mp4'}'\n" for u in use))
    k = next_version(name)
    out = OUT / f"ep02_{name}_v{k}.mp4"
    ceiling = -2.0
    for attempt in range(4):                  # the ENCODED file must be <= -1 dBTP (AAC overshoots)
        mix, I, tp = master(mix0, work / "mix.wav", ceiling)
        sf.write(work / "mix.wav", mix, A.SR, subtype="PCM_24")
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-i", str(work / "mix.wav"),
                        "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-ar", "48000",
                        "-ac", "2", "-t", f"{total:.4f}", "-movflags", "+faststart", str(out)], check=True)
        I2, tp2 = A.measure_loudness(out)
        print(f"  master ceiling {ceiling:.1f} dBTP -> encoded {I2:.1f} LUFS, {tp2:.1f} dBTP")
        if tp2 <= -1.0 and abs(I2 + 14.0) <= 0.5:
            break
        ceiling -= max(0.3, tp2 + 1.0 + 0.2)
    nf = video_frames(out)
    if nf != int(round(total * FPS)):
        raise RuntimeError(f"{out} has {nf} video frames, expected {int(round(total * FPS))} (a shot changed mid-join?)")
    print(f"mix {I:.1f} LUFS, {tp:.1f} dBTP (pre-AAC); encoded file {I2:.1f} LUFS, {tp2:.1f} dBTP")
    print(f"wrote {out}")
    contact_sheet(out, use, OUT / f"ep02_{name}_v{k}_sheet.png")
    (work / "mix.wav").unlink()
    shutil.rmtree(work / "snap", ignore_errors=True)


def contact_sheet(mp4, use, png):
    """Per shot: its first exposure, every picture event (+4 frames) and its last exposure, labelled."""
    from PIL import Image, ImageDraw, ImageFont
    from whatif.config import FONTS, FONT_FILES
    fnt = ImageFont.truetype(str(FONTS / FONT_FILES["body"]), 17)
    rows = []
    t_shot = 0
    for u in use:
        fs = [u["f0"] + 2]
        for f, k, *_ in sorted(u["meta"]["events"], key=lambda e: e[0]):
            fs.append(min(max(f + 4, u["f0"]), u["f1"] - 1))
        fs.append(u["f1"] - 2)
        fs = sorted(set(fs))[:8]
        labels = {f + 4: k for f, k, *_ in u["meta"]["events"]}
        tiles = []
        for f in fs:
            g = f - u["f0"] + t_shot
            r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(mp4), "-vf", f"select=eq(n\\,{g})", "-vframes", "1",
                                "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True)
            im = Image.frombytes("RGB", (OUT_W, OUT_H), r.stdout).resize((270, 480), Image.LANCZOS)
            dr = ImageDraw.Draw(im)
            dr.rectangle([0, 450, 270, 480], fill=(20, 16, 14))
            dr.text((6, 455), f"{g / FPS:5.2f}s {u['stem']} {labels.get(f, '')}"[:34], font=fnt, fill=(240, 232, 216))
            tiles.append(im)
        rows.append(tiles)
        t_shot += u["f1"] - u["f0"]
    cols = max(len(r) for r in rows)
    sheet = Image.new("RGB", (cols * 276 + 6, len(rows) * 486 + 6), (16, 12, 10))
    for ri, r in enumerate(rows):
        for ci, im in enumerate(r):
            sheet.paste(im, (6 + ci * 276, 6 + ri * 486))
    sheet.save(png)
    print(f"wrote {png}")


def cmd_timeline():
    print(f"{'shot':12s} {'frames':>12s} {'start':>7s} {'end':>7s}  speech")
    for s in TL.layout():
        why = missing_reason(s["stem"])
        print(f"{s['stem']:12s} {s['f0']:5d}-{s['f1']:5d} {s['f0'] / FPS:7.2f} {s['f1'] / FPS:7.2f}  "
              f"{s['speech_on']:6.2f}-{s['speech_off']:6.2f}  gap {s['gap']:.2f}  {'' if why is None else '(' + why + ')'}")
    print(f"total {TL.total_frames()} frames = {TL.total_frames() / FPS:.2f} s")


def cmd_words(check=True):
    """Measured word starts per line (take seconds), the transcriber's prior, and (check=True) what a
    fresh transcription hears in each measured word span."""
    info = TL.analyse_lines()
    model = None
    if check:
        from faster_whisper import WhisperModel
        from whatif import speech as SP
        model = WhisperModel("small", device="cpu", compute_type="int8", cpu_threads=6)
    for ln in TL.lines():
        a = info[ln["file"]]
        print(f"{ln['file']}  (transcriber bias {a['bias']:+.2f} s)")
        heard = SP.check_snippets(model, TL.VOICE_DIR / ln["file"], a["words"]) if check else [("", "")] * len(a["words"])
        for w, (_, h) in zip(a["words"], heard):
            print(f"   {w['w']:14s} {w['s']:6.2f}  prior {w['prior']:6.2f}  {'heard: ' + h if check else ''}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--shot", action="append", help="render this shot (repeatable)")
    ap.add_argument("--preview", action="store_true", help="with --shot: also write preview.mp4 with sound")
    ap.add_argument("--frames", type=int, nargs="+", help="with --shot: render these global frames as PNG stills only")
    ap.add_argument("--assemble", action="store_true", help="join rendered shots into out/ep02_<name>_vN.mp4")
    ap.add_argument("--name", default="full", help="with --assemble: output name (default full)")
    ap.add_argument("--timeline", action="store_true", help="print the shot timeline")
    ap.add_argument("--words", action="store_true", help="print measured word starts with a re-transcription check")
    ap.add_argument("--workers", type=int, help="render processes (default and maximum 6)")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if a.words:
        cmd_words()
    if a.timeline or not (a.shot or a.assemble or a.words):
        cmd_timeline()
    for stem in a.shot or []:
        if a.frames:
            cmd_stills(stem, a.frames)
        else:
            cmd_shot(stem, preview=a.preview, workers=a.workers)
    if a.assemble:
        cmd_assemble(a.name)
