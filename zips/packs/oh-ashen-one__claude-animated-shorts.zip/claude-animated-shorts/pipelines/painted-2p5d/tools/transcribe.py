"""Transcribe narration on CPU with word timestamps (faster-whisper small, int8).

Usage: uv run --with faster-whisper python src/tools/transcribe.py <wav> <out.json>
"""
import json
import subprocess
import sys

import numpy as np

from faster_whisper import WhisperModel


def main(wav, out):
    model = WhisperModel("small", device="cpu", compute_type="int8")
    pcm = subprocess.run(["ffmpeg", "-v", "error", "-i", wav, "-ac", "1", "-ar", "16000", "-f", "f32le", "-"],
                         check=True, capture_output=True).stdout
    audio = np.frombuffer(pcm, np.float32)
    segs, info = model.transcribe(audio, word_timestamps=True, language="en", beam_size=5)
    words = []
    text = []
    for s in segs:
        text.append(s.text)
        for w in s.words:
            words.append({"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3), "p": round(w.probability, 3)})
    json.dump({"text": " ".join(t.strip() for t in text), "words": words}, open(out, "w"), indent=1)
    print(" ".join(t.strip() for t in text))
    for w in words:
        print(f"{w['s']:6.2f} {w['e']:6.2f} {w['p']:.2f} {w['w']}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
