"""Debug: build a shot's layers and dump plane mosaics plus an exaggerated-parallax render.

Usage: python src/tools/inspect_layers.py s01_hook|s02_year1 [--force]
"""
import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cv2
import numpy as np

from whatif import layers as L
from whatif.camera import ParallaxCamera, deform_sprite, composite_into
from whatif.config import WORK


def main(shot, force):
    spec = importlib.import_module(f"shots.{shot}_spec")
    L.build(spec.SHOT, spec.KEY, spec.DEPTH, spec.PLANES, spec.SPRITES, force=force)
    lay = L.Layers(spec.SHOT)
    dbg = WORK / "dbg"
    tiles = []
    for p in lay.planes:
        rgb = p["rgb"].astype(np.float32) / 255
        a = p["a"].astype(np.float32)[..., None] / 255
        chk = ((np.indices(a.shape[:2]).sum(0) // 32) % 2)[..., None] * 0.3 + 0.35
        tiles.append(cv2.resize(rgb * a + chk * (1 - a), (304, 538)))
    for s in lay.sprites:
        print(s["name"], s["bbox"])
    cv2.imwrite(str(dbg / f"{shot}_planes.jpg"), cv2.cvtColor((np.hstack(tiles) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR))
    near = lambda d: np.clip(d / 0.9, 0, 1) ** 0.8
    for tag, z, k, rise in [("static", 1.0, 0.0, 0.0), ("push", 1.03, 0.18, 60.0)]:
        cam = ParallaxCamera(lay.W, lay.H, (lay.W * 0.5, lay.H * 0.45), near, lambda t: z, lambda t: k, lambda t: rise)
        pls = []
        for i, p in enumerate(lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            a = p["a"].astype(np.float32) / 255
            for s in lay.sprites:
                if s["plane"] == i:
                    patch, x0, y0 = deform_sprite(s, angle_deg=4 if tag == "push" else 0, dy=-12 if tag == "push" else 0)
                    composite_into(rgb, a, patch, x0, y0)
            pls.append({"rgb": rgb, "a": a, "n": near(p["d"].astype(np.float32) / 65535)})
        img = cam.render(pls, 0.0)
        cv2.imwrite(str(dbg / f"{shot}_{tag}.png"), cv2.cvtColor((np.clip(img, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR))


if __name__ == "__main__":
    main(sys.argv[1], "--force" in sys.argv)
