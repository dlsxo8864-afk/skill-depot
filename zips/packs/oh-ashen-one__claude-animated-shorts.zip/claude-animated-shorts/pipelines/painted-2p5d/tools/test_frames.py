"""Render a few frames of one shot to PNG for review (no video). Same as
`python src/ep03.py --shot <stem> --frames <f> ...`.

Usage: python src/tools/test_frames.py <stem> <frame> [<frame> ...]   (GLOBAL frame numbers)
Writes work/shots/<stem>/stills/f#####.png and a 360x640 copy for phone-size legibility checks.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import ep03  # noqa: E402

if __name__ == "__main__":
    ep03.cmd_stills(sys.argv[1], [int(a) for a in sys.argv[2:]])
