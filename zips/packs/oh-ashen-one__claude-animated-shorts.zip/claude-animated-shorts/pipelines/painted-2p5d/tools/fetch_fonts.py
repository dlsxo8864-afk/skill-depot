"""Download the open-licence fonts used by the renderer into work/fonts/ (stdlib only)."""
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from whatif.config import FONTS  # noqa: E402

BASE = "https://github.com/google/fonts/raw/main/"
FILES = {
    "anton_Anton-Regular.ttf": "ofl/anton/Anton-Regular.ttf",
    "anton_OFL.txt": "ofl/anton/OFL.txt",
    "inter_Inter[opsz,wght].ttf": "ofl/inter/Inter%5Bopsz,wght%5D.ttf",
    "inter_OFL.txt": "ofl/inter/OFL.txt",
    "permanentmarker_PermanentMarker-Regular.ttf": "apache/permanentmarker/PermanentMarker-Regular.ttf",
    "permanentmarker_LICENSE.txt": "apache/permanentmarker/LICENSE.txt",
}

if __name__ == "__main__":
    FONTS.mkdir(parents=True, exist_ok=True)
    for name, rel in FILES.items():
        dst = FONTS / name
        if not dst.exists():
            urllib.request.urlretrieve(BASE + rel, dst)
        print(dst)
