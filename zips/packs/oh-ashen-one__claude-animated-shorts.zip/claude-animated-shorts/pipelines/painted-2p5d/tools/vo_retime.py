"""Speed up a narration take without changing pitch, then tighten its pauses. Never cuts words.

    python src/tools/vo_retime.py <in.wav> <out.wav> <tempo> <words_in_stretched.json> [plan.json]

1. Run once with only <in.wav> <stretched.wav> <tempo> to time-stretch (Rubber Band R3 engine, CPU,
   pitch untouched), then transcribe the stretched file with tools/transcribe.py.
2. Run again with the stretched file's word json: pauses are measured from the waveform (silent runs
   between word boundaries, not the transcriber's guesses) and trimmed from their middle to the targets:
   PAUSE_HOOK between "years?" and "The", PAUSE_SENT between the two Year-1 sentences, and at most
   PAUSE_MAX anywhere inside a sentence.
"""
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from whatif.audio import edit_voice  # noqa: E402

PAUSE_HOOK, PAUSE_SENT, PAUSE_MAX = 0.45, 0.30, 0.20
SILENT_DB = -48.0          # below this (re. the take's peak, 10 ms RMS) counts as pause
DEAD_GAP_MIN, DEAD_GAP_KEEP = 0.09, 0.05   # silences inside words longer than a stop closure


def stretch(src, dst, tempo):
    subprocess.run(["rubberband", "-3", "-q", "-T", str(tempo), str(src), str(dst)], check=True)


def silent_runs(x, sr, hop=0.005, win=0.010):
    m = x.mean(1) if x.ndim == 2 else x
    h, w = int(hop * sr), int(win * sr)
    n = 1 + (len(m) - w) // h
    rms = np.sqrt(np.array([np.mean(m[i * h:i * h + w] ** 2) for i in range(n)]) + 1e-12)
    db = 20 * np.log10(rms / (np.abs(m).max() + 1e-9))
    quiet = db < SILENT_DB
    runs, i = [], 0
    while i < n:
        if quiet[i]:
            j = i
            while j < n and quiet[j]:
                j += 1
            runs.append((i * h / sr + win / 2, j * h / sr + win / 2))
            i = j
        else:
            i += 1
    return runs


def plan_cuts(x, sr, words):
    runs = silent_runs(x, sr)
    cuts, report, used = [], [], set()
    for a, b in zip(words[:-1], words[1:]):
        if a["w"].endswith("?") and b["w"] == "The":
            target = PAUSE_HOOK
        elif a["w"].endswith("."):
            target = PAUSE_SENT
        else:
            target = PAUSE_MAX
        # the silent run that sits between the two words (allow for loose word boundaries)
        lo, hi = a["e"] - 0.12, b["s"] + 0.12
        cand = [(s, e) for s, e in runs if s < hi and e > lo]
        if not cand:
            report.append((a["w"], b["w"], 0.0, 0.0))
            continue
        s0, e0 = max(cand, key=lambda r: r[1] - r[0])
        s, e = max(s0, lo), min(e0, hi)
        gap = e - s
        if gap > target + 0.02:
            mid = (s + e) / 2
            cut = gap - target
            cuts.append((round(mid - cut / 2, 4), round(mid + cut / 2, 4)))
        report.append((a["w"], b["w"], gap, min(gap, target)))
        used.add((s0, e0))
    # dead gaps inside words (e.g. the digital-silence dropout in "doom|scrolling" that v1 also removed):
    # any other silent run longer than a natural stop closure is trimmed to DEAD_GAP_KEEP
    for s, e in runs:
        if (s, e) in used or s < words[0]["e"] or e > words[-1]["s"] or e - s <= DEAD_GAP_MIN:
            continue
        mid, cut = (s + e) / 2, (e - s) - DEAD_GAP_KEEP
        cuts.append((round(mid - cut / 2, 4), round(mid + cut / 2, 4)))
        report.append(("(inside)", f"{s:.2f}s", e - s, DEAD_GAP_KEEP))
    return sorted(cuts), report


if __name__ == "__main__":
    src, dst, tempo = sys.argv[1], sys.argv[2], float(sys.argv[3])
    if len(sys.argv) == 4:
        stretch(src, dst, tempo)
        print("stretched", dst)
        sys.exit()
    words = json.loads(Path(sys.argv[4]).read_text())["words"]
    x, sr = sf.read(src, always_2d=True)
    cuts, report = plan_cuts(x, sr, words)
    for a, b, g, t in report:
        print(f"{a:>12s} | {b:<12s} pause {g:5.2f} -> {t:5.2f}")
    y = edit_voice(src, cuts)
    sf.write(dst, y, sr, subtype="FLOAT")
    if len(sys.argv) > 5:
        Path(sys.argv[5]).write_text(json.dumps({"tempo": tempo, "cuts": cuts}, indent=1))
    print("cuts", cuts)
