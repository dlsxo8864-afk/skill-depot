"""Episode 3 timeline: one entry per shot, timed from the narration takes.

Each shot owns one narration line (one wav in assets/voice/nicole/). A shot starts one frame before its
line's first spoken word (the cut lands on the beat) and ends where the next shot starts. Between the
last word of one line and the first word of the next sits the shot's `gap` (seconds of pause).

Only the director edits this file. Shot builders read it through `ShotContext` (whatif/shotkit.py).
"""
import json
import math
from functools import lru_cache
from pathlib import Path

import numpy as np
import soundfile as sf

from whatif.config import ASSETS, FPS, WORK

VOICE_DIR = ASSETS / "voice" / "nicole"
WORDS_CACHE = WORK / "voice" / "nicole_words.json"
CUT_LEAD = 0.04            # cut this long before the line's first word (one frame ahead of the attack)
PAD = 1                   # s of silence prepended for transcription
GAP = 0.40                 # episode 3: pause between the end of one line and the start of the next
END_HOLD = 2.25            # last shot: the CTA question holds this long after the final word
HOOK_LEAD = 0.0            # the hook's take starts with the episode (its first word lands < 0.3 s in)

# stem, key image, narration wav, gap after the line (s), year tag (None = no tag)
# Shot table from ../SHOTS.md. Only the integration builder / director edits this list.
SHOTS = [
    ("s01_hook",   "g00_hook_key.png",     "00_hook.wav",     GAP, None),
    ("s02_year1",  "g01_wedding_key.png",  "01_wedding.wav",  GAP, 1),
    ("s03_year2",  "g02_north_key.png",    "02_north.wav",    GAP, 2),
    ("s04_year3",  "g03_dothraki_key.png", "03_dothraki.wav", GAP, 3),
    ("s05_year4",  "g04_ironbank_key.png", "04_ironbank.wav", GAP, 4),
    ("s06_year5",  "g05_bran_key.png",     "05_bran.wav",     GAP, 5),
    ("s07_year6",  "g06_dragon_key.png",   "06_dragon.wav",   GAP, 6),
    ("s08_year7",  "g07_cradle_key.png",   "07_cradle.wav",   GAP, 7),
    ("s09_year8",  "g08_essos_key.png",    "08_essos.wav",    GAP, 8),
    ("s10_year9",  "g09_winter_key.png",   "09_winter.wav",   GAP, 9),
    ("s11_year10", "g10_council_key.png",  "10_council.wav",  GAP, 10),
    ("s12_catch",  "g11_catch_key.png",    "11_catch.wav",    GAP, None),
    ("s13_cta",    "g12_cta_key.png",      "12_cta.wav",      END_HOLD, None),
]


# Each shot's sync word from SHOTS.md (the picture event lands on it); the contact sheet shows the
# frame `offset` frames after the word starts, where the event is on screen.
EVENT_WORD = {
    "s01_hook": ("never", 6), "s02_year1": ("Targaryens", 6), "s03_year2": ("leaves.", 6),
    "s04_year3": ("bored.", 6), "s05_year4": ("hers", 6), "s06_year5": ("writes", 6), "s07_year6": ("one", 8),
    "s08_year7": ("never", 6), "s09_year8": ("back.", 6), "s10_year9": ("price.", 6),
    "s11_year10": ("choose", 8), "s12_catch": ("ended.", 8), "s13_cta": ("anyway?", 24),
}


# Each shot's main picture event (kind as listed in its meta.json events) and how many frames after it
# the contact sheet looks, so the event is on screen. Shot builders: name your main event kind here
# (ask the integration builder) or the sheet falls back to EVENT_WORD.
MAIN_EVENT = {
    "s01_hook": ("dragon_bank", 6), "s02_year1": ("sigil", 6),
}


def main_event_frame(stem, events):
    """Frame showing the shot's main event, from its rendered events; falls back to event_frame."""
    kind, off = MAIN_EVENT.get(stem, (None, 0))
    hits = [f for f, k, *_ in events if k == kind]
    e = shot_entry(stem)
    if not hits:
        return event_frame(stem)
    return min(max(min(hits) + off, e["f0"]), e["f1"] - 3)


def event_frame(stem):
    """Global frame where the shot's SHOTS.md event is on screen (for contact sheets)."""
    e = shot_entry(stem)
    w, off = EVENT_WORD.get(stem, (None, 0))
    hit = [x for x in e["words"] if w and x["w"].strip(",.?!;:").lower() == w.strip(",.?!;:").lower()]
    f = int(round(hit[0]["s"] * FPS)) + off if hit else (e["f0"] + e["f1"]) // 2
    return min(max(f, e["f0"]), e["f1"] - 3)


# ------------------------------------------------------------------ narration analysis
def speech_bounds(x, sr, floor_db=-45.0):
    """First and last sample time (s) above floor_db re. the take's peak (10 ms RMS)."""
    m = x.mean(1) if x.ndim == 2 else x
    w = int(0.010 * sr)
    n = len(m) // w
    rms = np.sqrt((m[: n * w].reshape(n, w) ** 2).mean(1) + 1e-12)
    db = 20 * np.log10(rms / (np.abs(m).max() + 1e-9))
    on = np.where(db > floor_db)[0]
    return float(on[0] * w / sr), float((on[-1] + 1) * w / sr)


def analyse_lines(force=False):
    """Word timestamps (faster-whisper small, int8, CPU) and speech bounds for every line; cached."""
    lines = json.loads((VOICE_DIR / "lines.json").read_text())["lines"]
    cache = json.loads(WORDS_CACHE.read_text()) if WORDS_CACHE.exists() and not force else {}
    todo = [ln for ln in lines if ln["file"] not in cache
            or cache[ln["file"]].get("mtime") != (VOICE_DIR / ln["file"]).stat().st_mtime]
    if todo:
        from faster_whisper import WhisperModel
        from scipy.signal import resample_poly
        model = WhisperModel("small", device="cpu", compute_type="int8")
        for ln in todo:
            p = VOICE_DIR / ln["file"]
            x, sr = sf.read(p, always_2d=True)
            m = x.mean(1).astype(np.float32)
            a16 = resample_poly(m, 16000, sr).astype(np.float32) if sr != 16000 else m
            # 1 s of leading silence: the takes start ~0.2 s in, and without padding whisper drops or
            # mistimes the first word. (Prompting with the script made the timestamps unreliable.)
            a16 = np.concatenate([np.zeros(PAD * 16000, np.float32), a16])
            segs, _ = model.transcribe(a16, word_timestamps=True, language="en", beam_size=5)
            words = [{"w": w.word.strip(), "s": round(w.start - PAD, 3), "e": round(w.end - PAD, 3),
                      "p": round(w.probability, 3)} for s in segs for w in s.words]
            words = _merge_fragments(words)
            on, off = speech_bounds(x, sr)
            cache[ln["file"]] = {"script": ln["script"], "dur": len(x) / sr, "sr": sr, "on": on, "off": off,
                                 "words": align_script(ln["script"], words, on, off), "heard_words": words,
                                 "mtime": p.stat().st_mtime, "heard": " ".join(w["w"] for w in words)}
            print(f"{ln['file']}: {cache[ln['file']]['heard']}")
        WORDS_CACHE.parent.mkdir(parents=True, exist_ok=True)
        WORDS_CACHE.write_text(json.dumps(cache, indent=1))
    return cache


def _merge_fragments(words):
    """Glue tokens like "-nine" or "&P" onto the previous word ("ninety-nine", "S&P")."""
    out = []
    for w in words:
        if out and w["w"] and not (w["w"][0].isalnum() or w["w"][0] in "$'"):
            out[-1] = {**out[-1], "w": out[-1]["w"] + w["w"], "e": w["e"], "p": min(out[-1]["p"], w["p"])}
        else:
            out.append(dict(w))
    return out


def _norm(t):
    return "".join(ch for ch in t.lower() if ch.isalnum())


def align_script(script, heard, on, off):
    """Script words with times. Words the transcriber heard (same spelling) keep its times; runs it
    missed or spelled differently ("$49.99" for "forty-nine ninety-nine") share the time between their
    heard neighbours by letter count. The first word never starts before the speech onset."""
    import difflib
    toks = script.split()
    sm = difflib.SequenceMatcher(a=[_norm(t) for t in toks], b=[_norm(w["w"]) for w in heard], autojunk=False)
    out = [None] * len(toks)
    pa = pb = 0
    for a, b, n in sm.get_matching_blocks():
        # ep03: a run the transcriber spelled differently ("Mary's John." for "marries Jon.") but with the
        # same word count takes the heard times one to one instead of being interpolated
        if a - pa == b - pb and a > pa:
            for k in range(a - pa):
                h = heard[pb + k]
                out[pa + k] = {"w": toks[pa + k], "s": h["s"], "e": h["e"], "p": h["p"], "src": "heard~"}
        for k in range(n):
            h = heard[b + k]
            out[a + k] = {"w": toks[a + k], "s": h["s"], "e": h["e"], "p": h["p"], "src": "heard"}
        pa, pb = a + n, b + n
    # drop heard times that are impossible (before the onset, or running backwards): whisper's first
    # word after silence is often stamped early
    last_e = on - 0.02
    for k in range(len(toks)):
        if out[k] is None:
            continue
        if out[k]["s"] < last_e - 0.03 or out[k]["s"] < on - 0.02 or out[k]["e"] > off + 0.1:
            out[k] = None
        else:
            last_e = out[k]["e"]
    i = 0
    while i < len(toks):
        if out[i] is not None:
            i += 1
            continue
        j = i
        while j < len(toks) and out[j] is None:
            j += 1
        t0 = out[i - 1]["e"] if i > 0 else on
        t1 = out[j]["s"] if j < len(toks) else off
        t1 = max(t1, t0 + 0.05 * (j - i))
        lens = np.array([max(len(_norm(t)), 1) for t in toks[i:j]], float)
        edges = t0 + np.concatenate([[0], np.cumsum(lens)]) / lens.sum() * (t1 - t0)
        for k in range(i, j):
            out[k] = {"w": toks[k], "s": round(float(edges[k - i]), 3), "e": round(float(edges[k - i + 1]), 3),
                      "p": 0.0, "src": "interpolated"}
        i = j
    out[0]["s"] = max(out[0]["s"], on)
    out[-1]["e"] = min(max(out[-1]["e"], out[-1]["s"] + 0.05), off)
    return out


# ------------------------------------------------------------------ layout
@lru_cache(maxsize=1)
def layout():
    """List of shot dicts with frame ranges and narration placement (global seconds / frames)."""
    info = analyse_lines()
    shots = []
    speech_on = None
    for i, (stem, key, wav, gap, year) in enumerate(SHOTS):
        a = info[wav]
        if speech_on is None:
            vo_at = HOOK_LEAD                            # the hook's take starts with the episode
            speech_on = vo_at + a["on"]
        vo_at = speech_on - a["on"]                      # where the wav file is placed
        speech_off = vo_at + a["off"]
        shots.append({"index": i, "stem": stem, "key": ASSETS / "key" / key, "wav": VOICE_DIR / wav,
                      "year": year, "gap": gap, "vo_at": vo_at, "speech_on": speech_on, "speech_off": speech_off,
                      "words": [{**w, "s": round(vo_at + w["s"], 3), "e": round(vo_at + w["e"], 3)} for w in a["words"]]})
        speech_on = speech_off + gap
    for i, s in enumerate(shots):
        s["f0"] = 0 if i == 0 else int(math.floor((s["speech_on"] - CUT_LEAD) * FPS))
    for i, s in enumerate(shots):
        s["f1"] = shots[i + 1]["f0"] if i + 1 < len(shots) else int(math.ceil((s["speech_off"] + s["gap"]) * FPS))
    return shots


def lines():
    return json.loads((VOICE_DIR / "lines.json").read_text())["lines"]


def total_frames():
    return layout()[-1]["f1"]


def shot_entry(stem):
    return next(s for s in layout() if s["stem"] == stem)


if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    for s in layout():
        print(f"{s['stem']:12s} f{s['f0']:5d}-{s['f1']:5d}  {s['f0'] / FPS:6.2f}-{s['f1'] / FPS:6.2f}s  "
              f"speech {s['speech_on']:6.2f}-{s['speech_off']:6.2f}")
    print(f"total {total_frames()} frames = {total_frames() / FPS:.2f}s")
