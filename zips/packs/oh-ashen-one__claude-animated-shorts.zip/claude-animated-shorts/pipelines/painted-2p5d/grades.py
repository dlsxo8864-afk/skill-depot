"""Per-shot colour grade parameters for the shared final pass (whatif.style.grade).

The key paintings come out of the generator washed in purple (35-87 % of pixels against <= 9 % in the
Arcane stills). The grade turns blue-violet to magenta surfaces into a cool slate ambient (darker) or
warm key light (lit), gives mauve skin the warm key, never lands a pixel in olive, and keeps purple only
in the deepest shadows; finish() then pulls the darkest 2 % of pixels to about 0.045 luma. Light colours that carry meaning are protected here: the
furnace orange and red monitors sit outside the purple band anyway; the server hall's magenta (s12) is
protected by hue. Director-owned; a shot may override with a class attribute `grade = {...}` (merged
over this table) or opt out with `grade = False`.
"""
GRADES = {
    "s01_hook":   {"strength": 0.5},
    "s02_year1":  {"strength": 0.5},
    "s03_year2":  {"strength": 0.5},
    "s04_year3":  {"strength": 0.5},
    "s05_year4":  {"strength": 0.5},
    "s06_year5":  {"strength": 0.5},
    "s07_year6":  {"strength": 0.5},
    "s08_year7":  {"strength": 0.5},
    "s09_year8":  {"strength": 0.5},
    "s10_year9":  {"strength": 0.5},
    "s11_year10": {"strength": 0.5},
    "s12_catch":  {"strength": 0.5},
    "s13_cta":    {"strength": 0.5},
}


def grade_for(stem, shot=None):
    g = getattr(shot, "grade", None)
    if g is False:
        return False
    out = dict(GRADES.get(stem, {}))
    if isinstance(g, dict):
        out.update(g)
    return out
