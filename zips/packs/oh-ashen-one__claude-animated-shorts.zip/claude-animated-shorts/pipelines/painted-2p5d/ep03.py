"""Episode 3 ("What if Daenerys never burned King's Landing?"), built shot by shot.

    python src/ep03.py --timeline                 # shot table (frames, seconds, narration placement)
    python src/ep03.py --shot s03_year2           # render one shot -> work/shots/s03_year2/
    python src/ep03.py --shot s03_year2 --preview # ... plus preview.mp4 (picture + its line + its sound)
    python src/ep03.py --shot s03_year2 --frames 300 340   # stills only -> work/shots/s03_year2/stills/
    python src/ep03.py --assemble                 # concat rendered shots + full mix -> out/ep03_full_vN.mp4
    python src/ep03.py --assemble --name rough   # ... -> out/ep03_rough_vN.mp4 (missing shots are skipped)
    python src/ep03.py --words                    # every line's words with times (heard / interpolated)

Per shot, work/shots/<stem>/ holds video.mp4 (final quality, H.264 CRF 16, video only), bed.wav and
sfx.wav (48 kHz stereo float stems covering the shot plus 1.0 s before / 1.5 s after) and meta.json.
--assemble joins every shot whose render matches the current timeline (stream copy, no re-encode),
lays the narration lines, the shot stems and a continuous music bed on one timeline, ducks beds and
music under the voice, masters to -14 LUFS with a -2.0 dBTP ceiling (<= -1 dBTP after AAC), and muxes.
"""
import argparse
import importlib
import json
import math
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import soundfile as sf

import timeline as TL
from grades import grade_for
from whatif import audio as A
from whatif.config import FPS, OUT, OUT_H, OUT_W, WORK
from whatif.shotkit import ShotContext, ShotSound
from whatif.style import finish
from whatif.transitions import cut_frame, key_color

SHOTS_DIR = WORK / "shots"
X264 = ["-c:v", "libx264", "-preset", "slow", "-crf", "16", "-pix_fmt", "yuv420p", "-profile:v", "high",
        "-tune", "film", "-r", str(FPS)]


# ------------------------------------------------------------------ shot loading
def context(stem):
    shots = TL.layout()
    e = TL.shot_entry(stem)
    return ShotContext(stem=stem, index=e["index"], f0=e["f0"], f1=e["f1"], key=e["key"], wav=e["wav"],
                       year=e["year"], words=e["words"], speech_on=e["speech_on"], speech_off=e["speech_off"],
                       vo_at=e["vo_at"], is_last=e["index"] == len(shots) - 1)


def missing_reason(stem):
    """None if the shot can be rendered, else why not."""
    e = TL.shot_entry(stem)
    if not (Path(__file__).resolve().parent / "shots" / f"{stem}.py").exists():
        return f"no module src/shots/{stem}.py"
    if not e["key"].exists():
        return f"no key image {e['key'].relative_to(TL.ASSETS.parent)}"
    return None


def load_shot(stem):
    ctx = context(stem)
    mod = importlib.import_module(f"shots.{stem}")
    shot = mod.make(ctx)
    if getattr(shot, "flash_color", None) is None:
        from whatif.keyprep import load_rgb
        shot.flash_color = key_color(load_rgb(ctx.key, width=300))
    shots = TL.layout()
    if not ctx.is_last:                       # the next shot's key colour, for a match cut on colour
        from whatif.keyprep import load_rgb
        shot.next_color = key_color(load_rgb(shots[ctx.index + 1]["key"], width=300))
    return ctx, shot


def render_frame(ctx, shot, f):
    img, info = shot.frame(f)
    fa = getattr(shot, "finish_args", None)
    img = finish(img, f, grade_params=grade_for(ctx.stem, shot), **(fa(f, info) if fa else {}))
    if not ctx.is_last and getattr(shot, "transition", True):
        left = ctx.f1 - f
        if left in (1, 2):      # drawn cut mark painted after the final pass: grade/bloom never grey it
            img = cut_frame(img, left, shot.flash_color, seed=ctx.index * 7,
                            next_color=getattr(shot, "next_color", None))
    return (np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8)


# ------------------------------------------------------------------ parallel render
_W = None


def _init_worker(stem):
    import cv2
    cv2.setNumThreads(1)
    global _W
    _W = load_shot(stem)


def _work(f):
    ctx, shot = _W
    return f, render_frame(ctx, shot, f).tobytes()


def render_video(stem, path, frames, workers=None):
    import multiprocessing as mp
    ctx, shot = load_shot(stem)               # builds the layer cache once, before the workers start
    shot.frame(ctx.f0)
    workers = workers or max(2, min(12, (os.cpu_count() or 4) - 8))
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{OUT_W}x{OUT_H}",
           "-r", str(FPS), "-i", "-", *X264, str(path)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    ctxm = mp.get_context("spawn")            # fork deadlocks once OpenCV/BLAS threads exist
    with ctxm.Pool(workers, initializer=_init_worker, initargs=(stem,)) as pool:
        for i, (f, buf) in enumerate(pool.imap(_work, frames, chunksize=2)):
            proc.stdin.write(buf)
            if i % 48 == 0:
                print(f"  {stem}: frame {f} ({i + 1}/{len(frames)})", flush=True)
    proc.stdin.close()
    if proc.wait() != 0:
        raise RuntimeError("ffmpeg failed")
    return ctx, shot


# ------------------------------------------------------------------ sound stems
def shot_sound(ctx, shot):
    snd = ShotSound(ctx)
    if hasattr(shot, "sound"):
        shot.sound(snd)
    if ctx.year is not None:                  # the YEAR tag lands two frames after the cut
        snd.sfx(A.tick(ctx.f0 + 2, 1800), (ctx.f0 + 2) / FPS, -28, -0.5)
    if not ctx.is_last and getattr(shot, "transition", True):
        t_cut = ctx.f1 / FPS
        # the whoosh starts only after the shot's last word has finished (v5: s05 rode over "live")
        last = max([ctx.speech_off] + [w["e"] for w in ctx.words])
        wh = A.whoosh(float(np.clip(t_cut - (last + 0.06), 0.25, 0.65)), seed=ctx.index + 5)
        snd.sfx(wh, t_cut - len(wh) / A.SR, -17)
        snd.sfx(A.hit(seed=ctx.index + 6), t_cut, -13)
    return snd


def voice_line(path):
    """A narration take through the episode voice chain (presence lift + gentle compression), mono 48 kHz."""
    return A.voice_chain_ep(A.load_mono(path))


def master(mix, tmp_path):
    """Loudness to -14 LUFS integrated with a -2.0 dBTP true-peak ceiling (AAC adds up to ~0.8 dB)."""
    mix = A.limiter(mix / (np.abs(mix).max() + 1e-9) * 0.5, -6)
    sf.write(tmp_path, mix, A.SR, subtype="FLOAT")
    for _ in range(4):                         # limiting costs loudness: re-measure and re-gain
        I, tp = A.measure_loudness(tmp_path)
        if abs(I + 14.0) < 0.15 and tp <= -1.7:
            break
        mix = A.limiter(mix * A.db(-14.0 - I), -2.0)
        sf.write(tmp_path, mix, A.SR, subtype="FLOAT")
    I, tp = A.measure_loudness(tmp_path)
    return mix, I, tp


def mix_timeline(items, total, cut_times, tail_fade=0.0):
    """items: [{"bed": arr, "sfx": arr, "at": s}, {"vo": arr, "at": s}]; returns the stereo mix.
    tail_fade > 0: the music, beds and effects fade out over the last tail_fade s (narration untouched)."""
    n = int(round(total * A.SR))
    vo = np.zeros(n)
    beds = np.zeros((n, 2))
    sfx = np.zeros((n, 2))

    def put(buf, x, at):
        i = int(round(at * A.SR))
        if i < 0:
            x, i = x[-i:], 0
        x = x[: max(0, n - i)]
        buf[i:i + len(x)] += x

    for it in items:
        if "vo" in it:
            put(vo, it["vo"], it["at"])
        else:
            put(beds, it["bed"], it["at"])
            put(sfx, it["sfx"], it["at"])
    music = A.music_bed(total, cut_times)
    env = A.duck_envelope(vo)                 # opens 80 ms before every word, bridges gaps < 1.2 s, holds 0.8 s,
                                              # then a 0.3 s linear release (fix round: no swell inside gaps)
    duck = 1 - (1 - A.db(-9)) * env            # ambience beds -9 dB under the voice
    duck_m = 1 - (1 - A.db(-17)) * env         # music -17 dB under the voice (fix round: was -11)
    duck_s = 1 - (1 - A.db(-3)) * env          # effects keep their punch, a touch under words
    mix = (beds * duck[:, None] + np.stack([music, music], 1) * A.db(-23) * duck_m[:, None]
           + sfx * duck_s[:, None])
    mix = A.presence_carve(mix, env, -7.5, 1900.0, 5300.0)   # a further >= 6 dB over 2-5 kHz under words
    if tail_fade > 0:                          # the end gets a tail instead of a hard stop at the last frame
        k = min(n, int(round(tail_fade * A.SR)))
        mix[n - k:] *= (0.5 + 0.5 * np.cos(np.linspace(0, np.pi, k)))[:, None]
    return mix + np.stack([vo, vo], 1) * A.db(-1)


# ------------------------------------------------------------------ commands
def cmd_shot(stem, preview=False, workers=None):
    why = missing_reason(stem)
    if why:
        print(f"[skip] {stem}: {why}")
        return False
    d = SHOTS_DIR / stem
    d.mkdir(parents=True, exist_ok=True)
    ctx = context(stem)
    t = time.time()
    print(f"{stem}: frames {ctx.f0}-{ctx.f1 - 1} ({ctx.n} frames, {ctx.dur:.2f} s)")
    ctx, shot = render_video(stem, d / "video.mp4", list(range(ctx.f0, ctx.f1)), workers)
    snd = shot_sound(ctx, shot)
    for bus in ("bed", "sfx"):
        sf.write(d / f"{bus}.wav", snd.buses[bus].astype(np.float32), A.SR, subtype="FLOAT")
    ev = [(int(f), k, {kk: (float(v) if isinstance(v, (int, float, np.floating, np.integer)) else str(v))
                       for kk, v in info.items()}) for f, k, info in getattr(shot, "events", lambda: [])()]
    meta = {"stem": stem, "f0": ctx.f0, "f1": ctx.f1, "stem_t0": snd.t0, "rendered": time.ctime(),
            "events": ev, "words": [{k: w[k] for k in ("w", "s", "e")} for w in ctx.words]}
    (d / "meta.json").write_text(json.dumps(meta, indent=1))
    print(f"{stem}: rendered in {time.time() - t:.0f} s -> {d}")
    print_sync(ctx, ev)
    if preview:
        write_preview(ctx, snd, d)
    return True


def print_sync(ctx, events):
    print(f"  words: " + " ".join(f"{w['w']}@{w['s']:.2f}" for w in ctx.words))
    seen = set()
    for f, kind, info in sorted(events, key=lambda e: e[0]):
        if (f, kind) in seen:
            continue
        seen.add((f, kind))
        print(f"  {kind:14s} frame {f:5d}  {f / FPS:7.3f} s")


def write_preview(ctx, snd, d):
    t0 = ctx.f0 / FPS
    items = [{"vo": voice_line(ctx.wav), "at": ctx.vo_at - t0},
             {"bed": snd.buses["bed"], "sfx": snd.buses["sfx"], "at": snd.t0 - t0}]
    mix = mix_timeline(items, ctx.dur, [])
    mix, I, tp = master(mix, d / "preview_mix.wav")
    sf.write(d / "preview_mix.wav", mix, A.SR, subtype="PCM_16")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(d / "video.mp4"), "-i", str(d / "preview_mix.wav"),
                    "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                    "-t", f"{ctx.dur:.4f}", str(d / "preview.mp4")], check=True)
    (d / "preview_mix.wav").unlink()
    print(f"  preview: {d / 'preview.mp4'}  ({I:.1f} LUFS, {tp:.1f} dBTP)")


def cmd_stills(stem, frames):
    why = missing_reason(stem)
    if why:
        print(f"[skip] {stem}: {why}")
        return
    ctx, shot = load_shot(stem)
    import cv2
    out = SHOTS_DIR / stem / "stills"
    out.mkdir(parents=True, exist_ok=True)
    for f in frames:
        img = cv2.cvtColor(render_frame(ctx, shot, f), cv2.COLOR_RGB2BGR)
        cv2.imwrite(str(out / f"f{f:05d}.png"), img)
        cv2.imwrite(str(out / f"f{f:05d}_360.png"), cv2.resize(img, (360, 640), interpolation=cv2.INTER_AREA))
        print("wrote", out / f"f{f:05d}.png")


def video_frames(path):
    """Decoded frame count of a segment (catches a render that is still being written)."""
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_packets", "-show_entries",
                        "stream=nb_read_packets", "-of", "csv=p=0", str(path)], capture_output=True, text=True)
    try:
        return int(r.stdout.strip())
    except ValueError:
        return -1


def next_version(name="full"):
    k = 1
    while (OUT / f"ep03_{name}_v{k}.mp4").exists():
        k += 1
    return k


def cmd_assemble(name="full"):
    shots = TL.layout()
    use, t_new, missing = [], 0.0, []
    for s in shots:
        d = SHOTS_DIR / s["stem"]
        why = missing_reason(s["stem"])
        if why is None and not (d / "meta.json").exists():
            why = "not rendered yet (python src/ep03.py --shot %s)" % s["stem"]
        if why is None:
            meta = json.loads((d / "meta.json").read_text())
            if (meta["f0"], meta["f1"]) != (s["f0"], s["f1"]):
                why = f"stale render (frames {meta['f0']}-{meta['f1']}, timeline now {s['f0']}-{s['f1']}); re-render it"
            else:
                n = video_frames(d / "video.mp4")
                if n != s["f1"] - s["f0"]:
                    why = f"video.mp4 has {n} frames, expected {s['f1'] - s['f0']} (still rendering?)"
        if why:
            print(f"[skip] {s['stem']}: {why}")
            missing.append(s["stem"])
            continue
        snap = WORK / "full" / "snap" / s["stem"]        # builders may re-render while we join: use a copy
        snap.mkdir(parents=True, exist_ok=True)
        for fn in ("video.mp4", "bed.wav", "sfx.wav"):
            shutil.copy2(d / fn, snap / fn)
        use.append({**s, "meta": meta, "dir": snap, "shift": t_new - s["f0"] / FPS})
        t_new += (s["f1"] - s["f0"]) / FPS
    if not use:
        print("nothing to assemble")
        return
    total = sum(u["f1"] - u["f0"] for u in use) / FPS
    print(f"assembling {len(use)} of {len(shots)} shots, {total:.2f} s")
    if missing:
        print(f"missing ({len(missing)}): {' '.join(missing)}")
    work = WORK / "full"
    work.mkdir(parents=True, exist_ok=True)
    items, cuts = [], []
    for u in use:
        items.append({"vo": voice_line(u["wav"]), "at": u["vo_at"] + u["shift"]})
        bed, _ = sf.read(u["dir"] / "bed.wav", always_2d=True)
        sfx, _ = sf.read(u["dir"] / "sfx.wav", always_2d=True)
        items.append({"bed": bed, "sfx": sfx, "at": u["meta"]["stem_t0"] + u["shift"]})
        if u is not use[0]:
            cuts.append(u["f0"] / FPS + u["shift"])
    mix = mix_timeline(items, total, cuts, tail_fade=0.4)
    mix, I, tp = master(mix, work / "mix.wav")
    sf.write(work / "mix.wav", mix, A.SR, subtype="PCM_24")
    lst = work / "concat.txt"
    lst.write_text("".join(f"file '{u['dir'] / 'video.mp4'}'\n" for u in use))
    k = next_version(name)
    out = OUT / f"ep03_{name}_v{k}.mp4"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-i", str(work / "mix.wav"),
                    "-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k", "-ar", "48000",
                    "-ac", "2", "-t", f"{total:.4f}", "-movflags", "+faststart", str(out)], check=True)
    print(f"mix {I:.1f} LUFS, {tp:.1f} dBTP (pre-AAC)")
    print(f"wrote {out}")
    contact_sheet(out, use, OUT / f"ep03_{name}_v{k}_sheet.png")
    (work / "mix.wav").unlink()


def contact_sheet(mp4, use, png):
    """One tile per shot at its main event (timeline.main_event_frame), labelled with time and stem."""
    from PIL import Image, ImageDraw
    from whatif import text as T
    tiles = []
    t_shot = 0
    for u in use:
        f = TL.main_event_frame(u["stem"], u["meta"]["events"]) - u["f0"] + t_shot
        t_shot += u["f1"] - u["f0"]
        r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(mp4), "-vf", f"select=eq(n\\,{f})", "-vframes", "1",
                            "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, check=True)
        im = Image.frombytes("RGB", (OUT_W, OUT_H), r.stdout).resize((270, 480), Image.LANCZOS)
        d = ImageDraw.Draw(im)
        d.rectangle([0, 446, 270, 480], fill=(14, 8, 22))
        d.text((8, 452), f"{f / FPS:5.2f}s {u['stem']}", font=T.sans(17, 600), fill=(246, 236, 216))
        tiles.append(im)
    cols = min(7, len(tiles))
    rows = math.ceil(len(tiles) / cols)
    sheet = Image.new("RGB", (cols * 270 + (cols + 1) * 6, rows * 480 + (rows + 1) * 6), (10, 6, 16))
    for i, im in enumerate(tiles):
        sheet.paste(im, (6 + (i % cols) * 276, 6 + (i // cols) * 486))
    sheet.save(png)
    print(f"wrote {png}")


def cmd_timeline():
    print(f"{'shot':12s} {'frames':>12s} {'start':>7s} {'end':>7s}  speech")
    for s in TL.layout():
        why = missing_reason(s["stem"])
        print(f"{s['stem']:12s} {s['f0']:5d}-{s['f1']:5d} {s['f0'] / FPS:7.2f} {s['f1'] / FPS:7.2f}  "
              f"{s['speech_on']:6.2f}-{s['speech_off']:6.2f}  {'' if why is None else '(' + why + ')'}")
    print(f"total {TL.total_frames()} frames = {TL.total_frames() / FPS:.2f} s")


def cmd_words():
    """Every line's script words with their global start/end and whether the transcriber heard them."""
    for s in TL.layout():
        print(f"{s['stem']}  ({s['wav'].name}, speech {s['speech_on']:.2f}-{s['speech_off']:.2f} s, "
              f"frames {s['f0']}-{s['f1']})")
        for w in s["words"]:
            print(f"   {w['w']:16s} {w['s']:7.3f} {w['e']:7.3f}  f{int(round(w['s'] * FPS)):5d}  {w.get('src', '')}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--shot", action="append", help="render this shot (repeatable)")
    ap.add_argument("--preview", action="store_true", help="with --shot: also write preview.mp4 with sound")
    ap.add_argument("--frames", type=int, nargs="+", help="with --shot: render these global frames as PNG stills only")
    ap.add_argument("--assemble", action="store_true", help="join rendered shots into out/ep03_<name>_vN.mp4")
    ap.add_argument("--name", default="full", help="with --assemble: output name (default full)")
    ap.add_argument("--words", action="store_true", help="print every line's word times (global s, frame)")
    ap.add_argument("--timeline", action="store_true", help="print the shot timeline")
    ap.add_argument("--workers", type=int, help="render processes (default: cores - 8, max 12; use 4-6 when "
                                                "several builders render at once)")
    a = ap.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if a.words:
        cmd_words()
    if a.timeline or not (a.shot or a.assemble or a.words):
        cmd_timeline()
    for stem in a.shot or []:
        if a.frames:
            cmd_stills(stem, a.frames)
        else:
            cmd_shot(stem, preview=a.preview, workers=a.workers)
    if a.assemble:
        cmd_assemble(a.name)
