"""Pose-to-pose animation on 2s from a second painted pose of the hero.

The director paints `assets/key/<key stem>_poseB.png` (e.g. y05_gaming_poseB.png for y05_gaming_key.png):
same framing as the key, the hero in a second pose. Generated paintings never match pixel for pixel, so
the whole of pose B is NOT used: it is aligned to the key (ECC homography on the background), only the
hero region is taken from it through a soft mask (where the two paintings really differ, plus an
optional polygon), its colour is matched to the key around that region, and the rest of the frame stays
the key's own pixels. So switching poses changes the hero and nothing else pops.

    from whatif.poses import PoseSwap
    self.pose = PoseSwap.for_shot(ctx, STEM, region=[(x, y), ...])   # None if no pose B exists
    ...
    st = self.pose.state(f, [(f_a_to_b, "B"), (f_b_to_a, "A")]) if self.pose else "A"
    n = self.pose.nearness(pl["n"], pl["a"], st)                     # flatten parallax depth there
    rgb, a = self.pose.apply(pl["rgb"], pl["a"], st)                 # on the hero's (nearest) plane

Safe by default: only the hero changes (the difference mask inside `region`; the rest of the region,
and every background pixel, stays pose A's and holds still), and every change is animated on 2s as
    anticipation  "antAB" / "antBA": the outgoing pose leans and squashes a little AWAY from the coming
                  move (pose A mesh-warped against the measured motion), one drawing (2 frames)
    in-between    "AB" / "BA": a mesh warp halfway between the poses inside the mask (smoothed motion
                  field, the incoming pose drawn halfway back: one drawing, no cross-fade ghosting)
    hold          "B" / "A"
Switch frames are snapped to the 2s grid; the anticipation and in-between come BEFORE the switch frame.
`apply(..., whole_region=True)` restores the old colour replacement over the whole region.

Everything is cached in work/layers/<stem>/poseB.npz (rebuilt when either painting or the region
changes); the parent renderer builds it before the workers start.
"""
import hashlib
import json
from pathlib import Path

import cv2
import numpy as np

from .config import LAYER_CACHE, WORK_SCALE
from .keyprep import KEY_DIR, upscale


def pose_b_path(key_path):
    key_path = Path(key_path)
    stem = key_path.stem[:-4] if key_path.stem.endswith("_key") else key_path.stem
    return key_path.with_name(f"{stem}_poseB.png")


def _gray(x):
    return cv2.cvtColor((np.clip(x, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255


def _ecc(a, b, mask=None, scale=0.25, warp=None):
    """Homography taking b onto a (ECC on downscaled, slightly blurred grayscale)."""
    sa = cv2.GaussianBlur(cv2.resize(_gray(a), None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA), (0, 0), 1.2)
    sb = cv2.GaussianBlur(cv2.resize(_gray(b), None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA), (0, 0), 1.2)
    m = None if mask is None else (cv2.resize(mask, (sa.shape[1], sa.shape[0])) > 0.5).astype(np.uint8)
    S = np.diag([scale, scale, 1.0]).astype(np.float32)
    w0 = np.eye(3, dtype=np.float32) if warp is None else (S @ warp @ np.linalg.inv(S)).astype(np.float32)
    crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6)
    try:
        _, w = cv2.findTransformECC(sa, sb, w0, cv2.MOTION_HOMOGRAPHY, crit, m, 5)
    except cv2.error:
        return np.eye(3, dtype=np.float32) if warp is None else warp
    return (np.linalg.inv(S) @ w @ S).astype(np.float32)


def _diff_mask(a, b):
    la = cv2.cvtColor(a.astype(np.float32), cv2.COLOR_RGB2LAB)
    lb = cv2.cvtColor(b.astype(np.float32), cv2.COLOR_RGB2LAB)
    d = np.sqrt(((la - lb) * np.float32([1.0, 0.6, 0.6])) ** 2).sum(2)
    return cv2.GaussianBlur(d, (0, 0), 7)


def _flow(src, dst):
    """Dense flow (Farneback, half res) such that dst(x) ~ src(x + flow(x)) is NOT assumed; returns
    flow from src to dst: a point at p in src moves to p + flow(p)."""
    s = 0.5
    g0 = cv2.resize(_gray(src), None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    g1 = cv2.resize(_gray(dst), None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    f = cv2.calcOpticalFlowFarneback((g0 * 255).astype(np.uint8), (g1 * 255).astype(np.uint8), None,
                                     0.5, 6, 41, 5, 7, 1.5, cv2.OPTFLOW_FARNEBACK_GAUSSIAN)
    return cv2.resize(f, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_LINEAR) / s


def _smooth_flow(fl, mask, sigma=14.0):
    """Mesh-like motion field: the flow averaged (weighted by the hero mask) so the warp bends the drawing
    smoothly instead of tearing it along noisy flow vectors."""
    w = np.clip(mask, 0.05, 1).astype(np.float32)
    out = np.empty_like(fl)
    for c in range(2):
        out[..., c] = cv2.GaussianBlur(fl[..., c] * w, (0, 0), sigma) / (cv2.GaussianBlur(w, (0, 0), sigma) + 1e-6)
    return out


def _squash(img, mask, amount):
    """Squash the masked drawing vertically toward its base by `amount` (0.03 = 3 %)."""
    ys = np.nonzero((mask > 0.5).any(1))[0]
    if not len(ys) or amount == 0:
        return img
    base = float(ys.max())
    H, W = img.shape[:2]
    gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    sy = base + (gy - base) / (1 - amount)
    return cv2.remap(img, gx, sy.astype(np.float32), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def _stretch_back(img, flow_from_prev, k=0.5):
    """`img` (the incoming pose) pulled k of the way back toward the previous pose: sample img at
    p + k * flow(p), where flow maps previous-pose points to incoming-pose points."""
    H, W = img.shape[:2]
    gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    return cv2.remap(img, gx + k * flow_from_prev[..., 0], gy + k * flow_from_prev[..., 1],
                     cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


class PoseSwap:
    """Pose A (the key) / pose B (second painting) for one shot, at the layer work scale."""

    def __init__(self, z):
        self.b = z["b"].astype(np.float32) / 255           # aligned + colour-matched pose B (work scale)
        self.ab = z["ab"].astype(np.float32) / 255         # in-between drawing A -> B
        self.ba = z["ba"].astype(np.float32) / 255         # in-between drawing B -> A
        self.ant_ab = z["ant_ab"].astype(np.float32) / 255  # anticipation before A -> B (pose A leaning back)
        self.ant_ba = z["ant_ba"].astype(np.float32) / 255
        self.a_img = z["a"].astype(np.float32) / 255
        self.mask = z["m"].astype(np.float32) / 255         # soft hero mask, 0..1
        self.region = z["r"].astype(np.float32) / 255 if "r" in z else None   # soft region polygon
        self.info = json.loads(str(z["info"]))

    # ---------------------------------------------------------------- construction
    @classmethod
    def for_shot(cls, ctx, stem, region=None, pose_path=None, min_area=0.004, grow=22, feather=9,
                 thresh=None, force=False):
        """PoseSwap for a shot, or None if its pose B painting does not exist (code keeps working).
        region: optional polygon (or list of polygons) in upscaled-key px (1520 wide, like PlaneSpec points) that
        limits the hero mask; strongly recommended when other things also differ between the paintings.
        min_area: drop difference blobs smaller than this fraction of the frame. grow/feather: px at
        work scale. thresh: Lab difference threshold (None = automatic)."""
        pb = Path(pose_path) if pose_path else pose_b_path(ctx.key)
        if not pb.exists():
            return None
        key_up, _ = ctx.key_paths()
        d = LAYER_CACHE / stem
        d.mkdir(parents=True, exist_ok=True)
        cache = d / "poseB.npz"
        sig = hashlib.sha1(json.dumps([str(pb), pb.stat().st_mtime, Path(key_up).stat().st_mtime, region,
                                       min_area, grow, feather, thresh, 5]).encode()).hexdigest()[:16]
        if cache.exists() and not force:
            z = np.load(cache)
            if json.loads(str(z["info"])).get("sig") == sig:
                return cls(z)
        z = cls._build(key_up, pb, region, min_area, grow, feather, thresh, sig)
        tmp = d / "poseB.tmp.npz"
        np.savez_compressed(tmp, **z)
        tmp.replace(cache)
        return cls(np.load(cache))

    @staticmethod
    def _build(key_up, pb, region, min_area, grow, feather, thresh, sig):
        KEY_DIR.mkdir(parents=True, exist_ok=True)
        pb_up = KEY_DIR / (pb.stem + ".png")
        if not pb_up.exists() or pb_up.stat().st_mtime < pb.stat().st_mtime:
            upscale(pb, pb_up)
        A = cv2.cvtColor(cv2.imread(str(key_up)), cv2.COLOR_BGR2RGB)
        B = cv2.cvtColor(cv2.imread(str(pb_up)), cv2.COLOR_BGR2RGB)
        H0, W0 = A.shape[:2]
        if B.shape[:2] != (H0, W0):
            B = cv2.resize(B, (W0, H0), interpolation=cv2.INTER_LANCZOS4)
        W, H = round(W0 * WORK_SCALE), round(H0 * WORK_SCALE)
        a = cv2.resize(A, (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        b = cv2.resize(B, (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        reg = None
        if region:
            reg = np.zeros((H, W), np.float32)
            polys = region if isinstance(region[0][0], (list, tuple)) else [region]   # one polygon or several
            cv2.fillPoly(reg, [np.round(np.float32(pg) * WORK_SCALE).astype(np.int32) for pg in polys], 1.0)
        # 1) align: ECC on everything, then again with the changed (hero) area masked out
        w = _ecc(a, b)
        bw = cv2.warpPerspective(b, w, (W, H), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
        d0 = _diff_mask(a, bw)
        bg = (d0 < np.quantile(d0, 0.75)).astype(np.float32)
        if reg is not None:
            bg *= 1 - cv2.dilate(reg, np.ones((41, 41), np.uint8))
        w = _ecc(a, b, mask=bg, warp=w)
        bw = cv2.warpPerspective(b, w, (W, H), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
        # 2) hero mask: where the paintings really differ (inside the region), big blobs only, filled
        diff = _diff_mask(a, bw)
        if thresh is None:
            base = np.median(diff if reg is None else diff[reg < 0.5]) if (reg is None or (reg < 0.5).any()) else np.median(diff)
            thresh = float(max(base * 3.2, 6.0))
        m = (diff > thresh).astype(np.uint8)
        if reg is not None:
            m &= (reg > 0.5).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)))
        n, lab, st, _ = cv2.connectedComponentsWithStats(m, 8)
        keep = np.zeros_like(m)
        for i in range(1, n):
            if st[i, cv2.CC_STAT_AREA] >= min_area * W * H:
                keep[lab == i] = 1
        # fill holes (a hero is a solid shape)
        ff = keep.copy()
        cv2.floodFill(ff, np.zeros((H + 2, W + 2), np.uint8), (0, 0), 1)
        keep = keep | (1 - ff)
        keep = cv2.dilate(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * grow + 1, 2 * grow + 1)))
        if reg is not None:
            keep &= (cv2.dilate(reg, np.ones((2 * grow + 1, 2 * grow + 1), np.uint8)) > 0.5).astype(np.uint8)
        soft = cv2.GaussianBlur(keep.astype(np.float32), (0, 0), feather)
        soft = np.clip(soft * 1.6 - 0.3, 0, 1)                    # solid core, soft painted rim
        # 3) colour-match pose B to the key in a ring just outside the hero (same light, no seam)
        ring = (cv2.dilate(keep, np.ones((61, 61), np.uint8)) - keep).astype(bool)
        if ring.sum() > 500:
            ma, sa_ = a[ring].mean(0), a[ring].std(0) + 1e-3
            mb, sb_ = bw[ring].mean(0), bw[ring].std(0) + 1e-3
            g = np.clip(sa_ / sb_, 0.8, 1.25)
            bw = np.clip((bw - mb) * g + ma, 0, 1)
        # 4) in-between drawings: incoming pose stretched halfway back along the measured motion
        fl_ab = _smooth_flow(_flow(a, bw), soft)    # key pose points -> pose B points (mesh-smooth)
        fl_ba = _smooth_flow(_flow(bw, a), soft)
        mm = soft[..., None]
        ab = _stretch_back(bw, fl_ab, 0.5)          # B sampled at p + flow/2: B drawn halfway from A
        ba = _stretch_back(a, fl_ba, 0.5)
        ab = a * (1 - mm) + ab * mm
        ba = a * (1 - mm) + ba * mm
        # anticipation: the outgoing pose leans 15 % of the move the other way and squashes 3 %
        ant_ab = _squash(_stretch_back(a, fl_ab, 0.15), soft, 0.03)
        ant_ba = _squash(_stretch_back(bw, fl_ba, 0.15), soft, 0.03)
        ant_ab = a * (1 - mm) + ant_ab * mm
        ant_ba = a * (1 - mm) + ant_ba * mm
        info = {"sig": sig, "thresh": thresh, "mask_frac": float((soft > 0.5).mean()),
                "homography": w.tolist(), "W": W, "H": H}
        q = lambda x: (np.clip(x, 0, 1) * 255 + 0.5).astype(np.uint8)
        out = {"a": q(a), "b": q(bw), "ab": q(ab), "ba": q(ba), "ant_ab": q(ant_ab), "ant_ba": q(ant_ba),
               "m": q(soft), "info": json.dumps(info)}
        if reg is not None:
            out["r"] = q(cv2.GaussianBlur(reg, (0, 0), feather))
        return out

    # ---------------------------------------------------------------- animation
    @staticmethod
    def state(f, switches, start="A", inbetween=2, anticipation=2):
        """Pose at global frame f. switches: [(frame, "A"|"B"), ...] (snapped down to even frames).
        Before each switch: `anticipation` frames of the anticipation drawing ("antAB" / "antBA"), then
        `inbetween` frames of the in-between drawing ("AB" / "BA"); the new pose holds from the switch."""
        cur = start
        for fs, to in sorted((int(fs) - int(fs) % 2, to) for fs, to in switches):
            if f >= fs:
                cur = to
                continue
            if to != cur and f >= fs - inbetween:
                return cur + to
            if to != cur and f >= fs - inbetween - anticipation:
                return "ant" + cur + to
            break
        return cur

    def image(self, state):
        return {"B": self.b, "AB": self.ab, "BA": self.ba, "antAB": self.ant_ab, "antBA": self.ant_ba}.get(state)

    def apply(self, rgb, a, state, mask_scale=1.0, src=None, whole_region=False, hero_alpha=None):
        """Swap the hero region of one plane (rgb float HxWx3, a float HxW, work scale) to `state`.
        Returns (rgb, a), new arrays; unchanged inputs for state "A". Use the NEAREST plane that holds
        any part of the hero (after compositing that plane's sprites). If your shot relights or grades
        the plane, pass src = the same treatment applied to self.image(state) (work-scale RGB).
        hero_alpha (work-scale HxW, optional): the drawing's coverage inside the mask; without it the whole
        mask turns opaque (fine when the hero fills it or the background behind is static)."""
        if state == "A":
            return rgb, a
        src = self.image(state) if src is None else src     # src: your relit/graded version of image(state)
        if src is None:
            return rgb, a
        m = self.mask * mask_scale
        if m.shape != rgb.shape[:2]:
            m = cv2.resize(m, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)
        if src.shape[:2] != rgb.shape[:2]:
            src = cv2.resize(src, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)
        mc = self._m(a, rgb.shape[:2], whole_region) * mask_scale
        # colour: the hero mask only (default): everything else in the frame stays pose A's and holds
        # still; whole_region=True replaces every pixel of the plane inside the region
        out = rgb * (1 - mc[..., None]) + src * mc[..., None]
        if hero_alpha is not None:          # the drawing's own coverage inside the mask (e.g. sky around an arm
            ha = hero_alpha                 # stays see-through, so a live background behind it keeps moving)
            if ha.shape != rgb.shape[:2]:
                ha = cv2.resize(ha, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)
            return out.astype(np.float32), (a * (1 - m) + ha * m).astype(np.float32)
        return out.astype(np.float32), np.maximum(a, m).astype(np.float32)

    def _m(self, a, shape, whole_region=False):
        """Colour-replacement mask: the hero mask, or (whole_region=True) the hero mask plus the whole
        region polygon."""
        m, r = self.mask, (self.region if whole_region else None)
        if m.shape != shape:
            m = cv2.resize(m, (shape[1], shape[0]), interpolation=cv2.INTER_LINEAR)
            r = None if r is None else cv2.resize(r, (shape[1], shape[0]), interpolation=cv2.INTER_LINEAR)
        return m if r is None else np.maximum(m, r)       # (colour where a = 0 is invisible anyway)

    def nearness(self, n, a, state, whole_region=False):
        """The plane's per-pixel nearness, smoothed over the swapped area so the
        parallax camera does not fold along pose A's old silhouette (a faint ghost outline). Use the
        ORIGINAL plane alpha `a` (before apply). Unchanged for state "A"."""
        if state == "A":
            return n
        m = self._m(a, n.shape, whole_region)
        if not (m > 0.5).any():
            return n
        # smooth the depth over the swapped area (keeps its overall slope, removes the old silhouette's
        # step); weighted blur so pixels outside the plane do not drag it toward zero
        w = np.clip(a, 0.02, 1).astype(np.float32)
        ns = cv2.GaussianBlur(n * w, (0, 0), 40) / (cv2.GaussianBlur(w, (0, 0), 40) + 1e-6)
        return (n * (1 - m) + ns * m).astype(np.float32)

    def debug_sheet(self, path):
        """A | B (aligned, colour-matched) | in-between A->B | mask overlay, for checking a pose pair."""
        ov = self.a_img * 0.5 + np.float32([1, 0.3, 0.1]) * self.mask[..., None] * 0.5
        row = np.hstack([cv2.resize(x, (360, 640)) for x in (self.a_img, self.b, self.ab, ov)])
        cv2.imwrite(str(path), cv2.cvtColor((np.clip(row, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR))
