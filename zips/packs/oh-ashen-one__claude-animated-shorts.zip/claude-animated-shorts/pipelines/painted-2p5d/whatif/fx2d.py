"""Hand-drawn-style 2D effects, posed on 2s.

Shapes are graphic (tapered streaks, 4-point flashes, zig-zag bolts, painted
haze blobs) with a hard bright core and a coloured glow, in the manner of
Fortiche effects animation, never particle-system dots.
"""
import math

import cv2
import numpy as np

from .layers import brush_noise


def _patch(h, w):
    return np.zeros((h, w), np.float32)


def tapered_streak_poly(p, d, length, width):
    """Tear-drop streak: fat round head at p, tapering tail along -d."""
    d = np.asarray(d, np.float32)
    d = d / (np.linalg.norm(d) + 1e-6)
    nrm = np.array([-d[1], d[0]], np.float32)
    head = np.asarray(p, np.float32)
    pts = []
    for a in np.linspace(-math.pi / 2, math.pi / 2, 7):
        pts.append(head + (d * math.cos(a) + nrm * math.sin(a)) * width * 0.5)
    pts.append(head - d * length)
    return np.array(pts, np.float32)


def star4_poly(c, r, angle=0.0, pinch=0.18):
    pts = []
    for i in range(8):
        a = angle + i * math.pi / 4
        rr = r if i % 2 == 0 else r * pinch
        pts.append((c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)))
    return np.array(pts, np.float32)


def bolt_points(p0, direction, length, segs, rng, jag=0.45):
    d = np.asarray(direction, np.float32)
    d /= np.linalg.norm(d) + 1e-6
    nrm = np.array([-d[1], d[0]], np.float32)
    pts = [np.asarray(p0, np.float32)]
    for i in range(1, segs + 1):
        base = pts[0] + d * length * i / segs
        off = nrm * rng.uniform(-1, 1) * length / segs * jag * (1 if i < segs else 0.3)
        pts.append(base + off)
    return np.array(pts, np.float32)


class ShapeCanvas:
    """Accumulates emissive shapes (core mask + glow mask) in a W x H space at 2x for AA."""

    def __init__(self, w, h, ss=2):
        self.w, self.h, self.ss = w, h, ss
        self.core = np.zeros((h * ss, w * ss), np.uint8)
        self.glow_src = np.zeros((h * ss, w * ss), np.uint8)
        self.color = np.zeros((h, w, 3), np.float32)   # glow colour weights
        self.layers = []

    def _pts(self, pts):
        return np.round(np.asarray(pts) * self.ss * 8).astype(np.int32)

    def fill(self, pts, glow=True, value=255):
        cv2.fillPoly(self.core, [self._pts(pts)], value, cv2.LINE_AA, shift=3)
        if glow:
            cv2.fillPoly(self.glow_src, [self._pts(pts)], 255, cv2.LINE_AA, shift=3)

    def line(self, pts, width, glow=True, value=255):
        cv2.polylines(self.core, [self._pts(pts)], False, value, max(1, int(width * self.ss)), cv2.LINE_AA, shift=3)
        if glow:
            cv2.polylines(self.glow_src, [self._pts(pts)], False, 255, max(1, int(width * self.ss * 2)), cv2.LINE_AA, shift=3)

    def result(self, glow_sigma=6.0):
        core = cv2.resize(self.core.astype(np.float32) / 255, (self.w, self.h), interpolation=cv2.INTER_AREA)
        g = cv2.resize(self.glow_src.astype(np.float32) / 255, (self.w, self.h), interpolation=cv2.INTER_AREA)
        glow = cv2.GaussianBlur(g, (0, 0), glow_sigma) * 1.6 + cv2.GaussianBlur(g, (0, 0), glow_sigma * 3) * 0.8
        return core, glow


def screen_emissive(dst, core, glow, core_rgb, glow_rgb, x0=0, y0=0, opacity=1.0):
    """Screen-blend an emissive core+glow into dst (float RGB) at offset."""
    h, w = core.shape
    H, W = dst.shape[:2]
    xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x0 + w, W), min(y0 + h, H)
    if xb <= xa or yb <= ya:
        return dst
    c = core[ya - y0:yb - y0, xa - x0:xb - x0, None]
    g = glow[ya - y0:yb - y0, xa - x0:xb - x0, None]
    src = np.clip(np.asarray(glow_rgb, np.float32) * g * 0.75 + np.asarray(core_rgb, np.float32) * c, 0, 1) * opacity
    region = dst[ya:yb, xa:xb]
    dst[ya:yb, xa:xb] = 1 - (1 - region) * (1 - src)
    return dst


# --------------------------------------------------------------- systems
class Embers:
    """Drifting ember streaks in world space with parallax (positions on 2s)."""

    def __init__(self, n, W, H, seed=4, y_range=(0.25, 1.0), n_range=(0.1, 0.9)):
        rng = np.random.default_rng(seed)
        self.p0 = np.stack([rng.uniform(0, W, n), rng.uniform(H * y_range[0], H * y_range[1], n)], 1)
        self.near = rng.uniform(*n_range, n)
        self.vel = np.stack([rng.uniform(-14, 30, n), rng.uniform(-75, -30, n)], 1) * (0.6 + self.near[:, None])
        self.size = rng.uniform(0.7, 1.4, n) * (0.6 + self.near)
        self.phase = rng.uniform(0, 6.28, n)
        self.wob = rng.uniform(0.6, 1.6, n)
        self.W, self.H = W, H

    def draw(self, cam, t_held, dst, warm=(1.0, 0.42, 0.12), core=(1.0, 0.72, 0.42), intensity=1.0):
        sc = ShapeCanvas(dst.shape[1], dst.shape[0])
        for i in range(len(self.near)):
            p = self.p0[i] + self.vel[i] * t_held
            p = p + np.array([math.sin(t_held * self.wob[i] * 2 + self.phase[i]) * 12, 0])
            p[1] = (p[1] - self.H * 0.15) % (self.H * 0.9) + self.H * 0.15
            p[0] = p[0] % self.W
            q = cam.screen_point(p, self.near[i], t_held)
            v = self.vel[i] + np.array([math.cos(t_held * self.wob[i] * 2 + self.phase[i]) * 24, 0])
            flick = 0.55 + 0.45 * math.sin(t_held * 9 + self.phase[i] * 3)
            if flick < 0.25:
                continue
            s = self.size[i] * cam.scale_at(self.near[i], t_held)
            sc.fill(tapered_streak_poly(q, v, 11 * s, 3.4 * s), value=int(255 * flick))
        c, g = sc.result(glow_sigma=3)
        return screen_emissive(dst, c * 0.9, g * 0.9, np.asarray(core) * intensity, np.asarray(warm) * intensity)


def spark_burst(sc, center, drawing, seed, scale=1.0):
    """Draw one drawing (0,1,2) of a short-circuit burst into a ShapeCanvas."""
    rng = np.random.default_rng(seed)
    cx, cy = center
    if drawing == 0:
        sc.fill(star4_poly((cx, cy), 30 * scale, rng.uniform(0, 0.6)))
        sc.fill(star4_poly((cx, cy), 14 * scale, 0.78, pinch=0.3))
        for _ in range(rng.integers(3, 6)):
            a = rng.uniform(0, 2 * math.pi)
            sc.line(bolt_points((cx, cy), (math.cos(a), math.sin(a)), rng.uniform(26, 58) * scale, 4, rng), 2.2 * scale)
    elif drawing == 1:
        sc.fill(star4_poly((cx, cy), 15 * scale, rng.uniform(0, 0.6), pinch=0.25))
        for _ in range(rng.integers(4, 7)):
            a = rng.uniform(0.15, math.pi - 0.15)
            d = np.array([math.cos(a), math.sin(a) * 0.8 + 0.4])
            p = np.array([cx, cy]) + d * rng.uniform(18, 40) * scale
            sc.fill(tapered_streak_poly(p, d, rng.uniform(16, 30) * scale, 4.5 * scale))
    else:
        for _ in range(rng.integers(3, 6)):
            a = rng.uniform(0.3, math.pi - 0.3)
            d = np.array([math.cos(a) * 0.6, 1.0])
            p = np.array([cx, cy]) + np.array([math.cos(a) * rng.uniform(30, 60), rng.uniform(40, 80)]) * scale
            sc.fill(tapered_streak_poly(p, d, rng.uniform(10, 20) * scale, 3.2 * scale), value=200)


def painted_haze(h, w, seed, blobs=5, softness=40):
    """A painted fog band texture (alpha float32 h x w) with brushy edges."""
    rng = np.random.default_rng(seed)
    a = np.zeros((h, w), np.float32)
    for _ in range(blobs):
        cx, cy = rng.uniform(0, w), rng.uniform(h * 0.3, h * 0.7)
        ax, ay = rng.uniform(w * 0.15, w * 0.35), rng.uniform(h * 0.12, h * 0.3)
        cv2.ellipse(a, (int(cx), int(cy)), (int(ax), int(ay)), rng.uniform(-12, 12), 0, 360, 1.0, -1)
    a = cv2.GaussianBlur(a, (0, 0), softness)
    n = brush_noise((h, w), seed + 1, scale=8, angle=-0.1, stretch=9)
    a = np.clip(a * (0.75 + 0.35 * n), 0, 1)
    # stepped density = painted value bands rather than smooth airbrush
    return np.round(a * 5) / 5 * 0.5 + a * 0.5
