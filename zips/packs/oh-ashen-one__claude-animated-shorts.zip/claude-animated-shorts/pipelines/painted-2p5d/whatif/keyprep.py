"""Input preparation for a shot's key painting: upscale to working size, then CPU depth.

    from whatif.keyprep import prepare_key
    key_path, depth_path = prepare_key(ASSETS / "key" / "y02_netflix_key.png")

New keys arrive at 941x1672. They are upscaled once to KEY_W (1520) px wide with a Lanczos-3
resampler (PIL, CPU; no sharpening, so brush edges stay soft) and cached in work/keys/. Spec
coordinates for a shot (plane regions, sprite envelopes, screen quads) are pixels of that
upscaled image: open work/keys/<name>.png to measure them.

Depth: Depth Anything V2 Small (ONNX, ONNX Runtime CPU provider), flip-averaged, saved as a
16-bit PNG next to the upscaled key (larger = nearer). The model lives in work/models/da2s/.
"""
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from .config import WORK

KEY_W = 1520                      # working key width (the first two keys were painted at 1520x2688)
KEY_DIR = WORK / "keys"
DEPTH_MODEL = WORK / "models" / "da2s" / "onnx" / "model.onnx"


def upscale(src, dst, width=KEY_W):
    """Lanczos-3 upscale to `width` px (aspect kept). Returns dst. Keys already that wide are copied as is."""
    im = Image.open(src).convert("RGB")
    if im.width != width:
        h = round(im.height * width / im.width)
        im = im.resize((width, h), Image.LANCZOS)
    im.save(dst, optimize=False, compress_level=3)
    return dst


def depth_map(key_path, out_path, long_side=1246, model=DEPTH_MODEL):
    """Relative depth (nearer = larger), 16-bit PNG at the key's size. CPU only."""
    import onnxruntime as ort
    img = cv2.cvtColor(cv2.imread(str(key_path)), cv2.COLOR_BGR2RGB)
    h, w = img.shape[:2]
    sh = long_side
    sw = int(round(w * sh / h / 14)) * 14
    x = cv2.resize(img, (sw, sh), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    x = (x - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
    x = x.transpose(2, 0, 1)[None].astype(np.float32)
    sess = ort.InferenceSession(str(model), providers=["CPUExecutionProvider"])
    name = sess.get_inputs()[0].name
    d = np.squeeze(sess.run(None, {name: x})[0]).astype(np.float32)
    d2 = np.squeeze(sess.run(None, {name: x[..., ::-1].copy()})[0])[..., ::-1]
    d = cv2.resize(0.5 * (d + d2), (w, h), interpolation=cv2.INTER_CUBIC)
    d = (d - d.min()) / (d.max() - d.min() + 1e-9)
    cv2.imwrite(str(out_path), (d * 65535).astype(np.uint16))
    return out_path


def prepare_key(key_path):
    """(upscaled key path, depth path), both cached in work/keys/. Safe to call every render."""
    key_path = Path(key_path)
    if not key_path.exists():
        raise FileNotFoundError(key_path)
    KEY_DIR.mkdir(parents=True, exist_ok=True)
    up = KEY_DIR / (key_path.stem + ".png")
    dp = KEY_DIR / (key_path.stem + "_depth.png")
    if not up.exists() or up.stat().st_mtime < key_path.stat().st_mtime:
        upscale(key_path, up)
    if not dp.exists() or dp.stat().st_mtime < up.stat().st_mtime:
        depth_map(up, dp)
    return up, dp


def load_rgb(path, width=None):
    """Key image as float32 RGB 0..1, optionally resized to `width` (INTER_AREA)."""
    k = cv2.cvtColor(cv2.imread(str(path)), cv2.COLOR_BGR2RGB)
    if width and k.shape[1] != width:
        k = cv2.resize(k, (width, round(k.shape[0] * width / k.shape[1])), interpolation=cv2.INTER_AREA)
    return k.astype(np.float32) / 255
