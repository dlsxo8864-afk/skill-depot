"""Generic vertical short-video feed for painted phone screens (no real app's name, logo or layout),
plus the system notification card. Everything is drawn as simple painted cards."""
import math
from functools import lru_cache

import cv2
import numpy as np
from PIL import Image, ImageDraw

from . import text as T
from .layers import brush_noise

CW, CH = 520, 1150           # screen canvas (portrait), matched to the painted phone's aspect


# ------------------------------------------------------------- painted videos
def _grad(h, w, top, bot):
    y = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
    return (np.asarray(top, np.float32) * (1 - y) + np.asarray(bot, np.float32) * y) * np.ones((1, w, 1), np.float32)


def _paintify(img, seed):
    """Make flat vector shapes read as quick gouache: soft edges, stroke texture, value banding."""
    img = cv2.GaussianBlur(img, (0, 0), 1.4)
    # broad dabs of value instead of a uniform hatch, then gentle value banding
    n1 = brush_noise(img.shape[:2], seed, scale=14, angle=-0.4, stretch=3)
    n2 = brush_noise(img.shape[:2], seed + 1, scale=7, angle=1.2, stretch=3)
    n = cv2.GaussianBlur((n1 * 0.7 + n2 * 0.3), (0, 0), 2)[..., None]
    img = img * (1 + 0.05 * n)
    img = np.round(img * 10) / 10 * 0.5 + img * 0.5
    return _dabs(np.clip(img, 0, 1), seed)


def _dabs(img, seed, count=2600):
    """Gouache stroke pass: short strokes in the local colour, laid along the forms (perpendicular to the
    value gradient), so flat fills break up into visible brushwork like the key paintings."""
    h, w = img.shape[:2]
    rng = np.random.default_rng(seed + 500)
    lum = cv2.GaussianBlur(img.mean(2), (0, 0), 3)
    gx = cv2.Sobel(lum, cv2.CV_32F, 1, 0, ksize=5)
    gy = cv2.Sobel(lum, cv2.CV_32F, 0, 1, ksize=5)
    flow = brush_noise((h, w), seed + 3, scale=40, angle=0.0, stretch=1)
    over = Image.fromarray((img * 255).astype(np.uint8)).convert("RGBA")
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for _ in range(count):
        x, y = int(rng.uniform(0, w)), int(rng.uniform(0, h))
        mag = math.hypot(gx[y, x], gy[y, x])
        ang = math.atan2(gy[y, x], gx[y, x]) + math.pi / 2 if mag > 0.4 else -0.5 + 0.8 * float(flow[y, x])
        ln = rng.uniform(10, 26) * (0.6 if mag > 0.4 else 1.0)
        c = img[y, x] * rng.uniform(0.9, 1.1) + rng.uniform(-0.025, 0.025, 3)
        col = tuple(int(v) for v in np.clip(c * 255, 0, 255)) + (int(rng.uniform(90, 170)),)
        dx, dy = math.cos(ang) * ln / 2, math.sin(ang) * ln / 2
        d.line([(x - dx, y - dy), (x + dx, y + dy)], fill=col, width=int(rng.uniform(4, 9)))
    over.alpha_composite(layer)
    return np.asarray(over.convert("RGB"), np.float32) / 255


def _draw(fn, bg_top, bg_bot, seed):
    base = _grad(CH, CW, bg_top, bg_bot)
    im = Image.fromarray((base * 255).astype(np.uint8))
    d = ImageDraw.Draw(im, "RGBA")
    fn(d, np.random.default_rng(seed))
    return _paintify(np.asarray(im, np.float32) / 255, seed)


def _jelly(d, rng):
    for cx, cy, r in [(170, 380, 95), (360, 640, 70), (230, 860, 52)]:
        for k in range(6):
            x = cx - r * 0.7 + k * r * 0.28
            pts = [(x + 14 * math.sin(j * 0.5 + k), cy + j * 18) for j in range(16)]
            d.line(pts, fill=(225, 255, 250, 160), width=5)
        d.pieslice([cx - r, cy - r * 0.9, cx + r, cy + r * 0.9], 180, 360, fill=(235, 255, 252, 235))
        d.pieslice([cx - r * 0.6, cy - r * 0.6, cx + r * 0.5, cy + r * 0.3], 180, 360, fill=(255, 255, 255, 120))
    for _ in range(40):
        x, y, r = rng.uniform(0, CW), rng.uniform(0, CH), rng.uniform(2, 6)
        d.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 255, 110))


def _sunset(d, rng):
    d.ellipse([170, 330, 360, 520], fill=(255, 226, 150, 255))
    for k in range(9):
        y = 560 + k * 36
        d.rectangle([0, y, CW, y + 36], fill=(110 - k * 9, 40 + k * 2, 110 - k * 6, 255))
        d.line([(120 + k * 6, y + 10), (400 - k * 8, y + 10)], fill=(255, 200, 140, 180 - k * 18), width=5)
    d.polygon([(40, 980), (90, 700), (110, 700), (95, 980)], fill=(40, 16, 46, 255))
    for a in range(5):
        ang = -2.6 + a * 0.45
        d.line([(100, 705), (100 + 130 * math.cos(ang), 705 + 70 * math.sin(ang) + 40)], fill=(40, 16, 46, 255), width=16)


def _dancer(d, rng):
    d.polygon([(260, -20), (60, 1150), (470, 1150)], fill=(255, 150, 230, 90))
    d.ellipse([60, 940, 460, 1060], fill=(255, 170, 235, 120))
    body = (36, 8, 48, 255)
    d.ellipse([228, 330, 300, 405], fill=body)
    d.polygon([(232, 410), (300, 410), (330, 640), (300, 650), (282, 820), (318, 990), (290, 1000), (258, 840),
               (232, 1000), (204, 990), (236, 820), (220, 650), (196, 640)], fill=body)
    d.line([(240, 430), (170, 330), (120, 230)], fill=body, width=26)
    d.line([(296, 430), (380, 470), (430, 400)], fill=body, width=26)
    for _ in range(26):
        x, y = rng.uniform(0, CW), rng.uniform(0, 900)
        d.polygon([(x, y - 9), (x + 3, y), (x, y + 9), (x - 3, y)], fill=(255, 235, 255, 200))


def _cat(d, rng):
    # a ginger cat on a sofa under a warm lamp: three values per form (light, mid, shadow), like the keys
    d.ellipse([300, 60, 620, 380], fill=(255, 200, 120, 70))           # lamp glow on the wall
    d.ellipse([360, 120, 560, 320], fill=(255, 214, 150, 90))
    d.rounded_rectangle([-40, 700, CW + 40, CH + 40], 60, fill=(40, 52, 120, 255))   # sofa
    d.rounded_rectangle([-40, 700, CW + 40, 760], 30, fill=(62, 78, 160, 255))
    d.rectangle([0, 940, CW, CH], fill=(30, 38, 92, 255))
    sh, mid, lit = (178, 84, 40, 255), (236, 136, 58, 255), (255, 190, 110, 255)
    d.line([(360, 840), (440, 820), (470, 740), (452, 680)], fill=sh, width=34, joint="curve")   # tail
    d.line([(362, 836), (438, 816), (464, 742)], fill=mid, width=20, joint="curve")
    d.ellipse([130, 520, 390, 880], fill=sh)                           # body: shadow, mid, light
    d.ellipse([136, 516, 370, 850], fill=mid)
    d.ellipse([170, 540, 300, 720], fill=lit)
    d.ellipse([205, 620, 300, 820], fill=(250, 232, 210, 255))         # white chest
    for k in range(4):                                                  # tabby stripes
        y = 600 + k * 52
        d.arc([140, y - 30, 380, y + 50], 200, 260, fill=sh, width=12)
        d.arc([140, y - 30, 380, y + 50], 290, 340, fill=sh, width=10)
    d.polygon([(186, 430), (196, 318), (252, 392)], fill=mid)          # ears
    d.polygon([(338, 430), (330, 318), (276, 392)], fill=sh)
    d.polygon([(200, 412), (204, 350), (236, 394)], fill=(240, 150, 150, 255))
    d.ellipse([172, 370, 352, 545], fill=sh)                           # head
    d.ellipse([174, 366, 338, 530], fill=mid)
    d.ellipse([196, 378, 300, 470], fill=lit)
    d.ellipse([214, 484, 310, 540], fill=(250, 232, 210, 255))         # muzzle
    for ex in (226, 290):                                               # eyes, half-shut: guilty
        d.ellipse([ex - 15, 438, ex + 15, 466], fill=(120, 190, 90, 255))
        d.rectangle([ex - 16, 436, ex + 16, 450], fill=mid)
        d.ellipse([ex - 4, 446, ex + 4, 462], fill=(25, 20, 30, 255))
    d.polygon([(252, 486), (270, 486), (261, 498)], fill=(220, 110, 120, 255))      # nose
    for s in (-1, 1):                                                   # whiskers
        for k in range(3):
            d.line([(261 + s * 30, 505 + k * 8), (261 + s * 110, 492 + k * 16)], fill=(255, 245, 230, 150), width=2)
    d.ellipse([60, 820, 150, 880], fill=(120, 170, 240, 255))           # knocked-over mug
    d.ellipse([70, 900, 230, 930], fill=(150, 190, 250, 180))           # spilled milk


VIDEOS = [
    dict(fn=_jelly, top=(0.42, 0.93, 0.84), bot=(0.10, 0.52, 0.55), cap="they glow in the dark", likes="1.2M", comments="8.4K"),
    dict(fn=_sunset, top=(1.00, 0.52, 0.30), bot=(0.88, 0.30, 0.42), cap="last light, again", likes="402K", comments="2.9K"),
    dict(fn=_dancer, top=(0.92, 0.28, 0.72), bot=(0.26, 0.05, 0.30), cap="day 214 of learning this", likes="3.7M", comments="41K"),
    dict(fn=_cat, top=(0.36, 0.56, 0.98), bot=(0.20, 0.30, 0.78), cap="he knows what he did", likes="980K", comments="12K"),
]


@lru_cache(maxsize=8)
def video_frame(i):
    v = VIDEOS[i % len(VIDEOS)]
    img = _draw(v["fn"], v["top"], v["bot"], seed=31 + i)
    return _ui_overlay(img, v, i)


def _ui_overlay(img, v, i):
    """Generic vertical-video player chrome (not any real app's layout: no side icon rail, no account
    handle): a caption with a view count over a soft scrim, a time readout, the progress bar, and a row
    of page dots at the top."""
    im = Image.fromarray((img * 255).astype(np.uint8)).convert("RGBA")
    ov = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    white = (250, 248, 255, 235)
    dim = (250, 248, 255, 150)
    shade = (10, 6, 20, 90)
    for k in range(60):                                   # soft bottom scrim for the caption
        d.rectangle([0, CH - 300 + k * 5, CW, CH - 295 + k * 5], fill=(12, 6, 24, int(k * 2.2)))
    for k in range(5):                                    # page dots, top centre
        cx = CW / 2 + (k - 2) * 26
        r = 7 if k == i % 5 else 5
        d.ellipse([cx - r, 52 - r, cx + r, 52 + r], fill=white if k == i % 5 else dim)
    f_cap, f_small = T.sans(30, 700), T.sans(24, 560)
    for txt, yy, fnt, col in [(v["cap"], CH - 178, f_cap, white), (f'{v["likes"]} views', CH - 128, f_small, dim)]:
        d.text((31, yy + 2), txt, font=fnt, fill=shade)
        d.text((30, yy), txt, font=fnt, fill=col)
    tt = f"0:{12 + 7 * i:02d} / 0:{40 + 3 * i:02d}"
    tw = T.text_size(f_small, tt)[0]
    d.text((CW - 30 - tw, CH - 128), tt, font=f_small, fill=dim)
    d.rounded_rectangle([28, CH - 70, CW - 28, CH - 64], 3, fill=(255, 255, 255, 80))
    d.rounded_rectangle([28, CH - 70, 28 + (CW - 56) * (0.35 + 0.15 * i), CH - 64], 3, fill=white)
    im = Image.alpha_composite(im, ov)
    out = np.asarray(im.convert("RGB"), np.float32) / 255
    return cv2.GaussianBlur(out, (0, 0), 0.7)


def feed_canvas(pos, smear=0.0):
    """Screen content for a feed scrolled to `pos` (float, 1.0 = one full video swiped up)."""
    k = int(math.floor(pos))
    frac = pos - k
    a = video_frame(k)
    if frac <= 1e-4:
        out = a.copy()
    else:
        b = video_frame(k + 1)
        off = int(round(frac * CH))
        out = np.empty_like(a)
        out[:CH - off] = a[off:]
        out[CH - off:] = b[:off]
    if smear > 0:
        ksz = int(smear * 90) | 1
        ker = np.zeros((ksz, 1), np.float32)
        ker[:] = 1 / ksz
        out = cv2.filter2D(out, -1, ker)
    return out


def screen_light(canvas):
    """Colour the screen throws on the face/hands: mean of the content, centre-weighted."""
    h, w = canvas.shape[:2]
    c = canvas[int(h * 0.15):int(h * 0.85), int(w * 0.1):int(w * 0.9)]
    return c.reshape(-1, 3).mean(0)


# --------------------------------------------------------------- notification
NOTE_TEXT = "You've used your allotted data center time for the day."


def _hourglass(d, x, y, s, col):
    d.polygon([(x - s, y - s), (x + s, y - s), (x, y)], fill=col)
    d.polygon([(x - s, y + s), (x + s, y + s), (x, y)], fill=col)
    d.line([(x - s * 1.15, y - s), (x + s * 1.15, y - s)], fill=col, width=max(2, int(s * 0.25)))
    d.line([(x - s * 1.15, y + s), (x + s * 1.15, y + s)], fill=col, width=max(2, int(s * 0.25)))


def notification_rgba(width, scale=1.0):
    """The system notification card as float RGBA (premultiplied-free). width in px."""
    s = scale
    pad = int(26 * s)
    icon = int(64 * s)
    fnt = T.sans(int(31 * s), 640)
    small = T.sans(int(22 * s), 520)
    text_w = width - pad * 3 - icon
    lines = T.wrap(fnt, NOTE_TEXT, text_w)
    lh = int(fnt.size * 1.22)
    h = max(icon + 2 * pad, pad * 2 + int(30 * s) + lh * len(lines))
    im = Image.new("RGBA", (width, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, width - 1, h - 1], int(30 * s), fill=(28, 24, 40, 242))
    d.rounded_rectangle([0, 0, width - 1, h - 1], int(30 * s), outline=(255, 255, 255, 40), width=max(1, int(2 * s)))
    ix, iy = pad, pad
    d.rounded_rectangle([ix, iy, ix + icon, iy + icon], int(16 * s), fill=(255, 170, 70, 255))
    _hourglass(d, ix + icon / 2, iy + icon / 2, icon * 0.24, (60, 24, 30, 255))
    tx = ix + icon + pad
    d.text((tx, pad - int(4 * s)), "now", font=small, fill=(200, 192, 214, 255))
    y = pad + int(26 * s)
    for ln in lines:
        d.text((tx, y), ln, font=fnt, fill=(252, 250, 255, 255))
        y += lh
    a = np.asarray(im, np.float32) / 255
    return a
