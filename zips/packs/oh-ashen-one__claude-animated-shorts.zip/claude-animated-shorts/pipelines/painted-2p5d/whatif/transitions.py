"""Cut transitions, applied by the episode renderer AFTER the final pass to the outgoing shot's last two
frames (so grade and bloom never wash them toward grey or white), to every shot except the last. A shot can
opt out with `transition = False` or pick its colour with `flash_color`.

    img = cut_frame(img, k, color, seed, next_color=None)   # k = frames left before the cut (2 or 1)

Three devices, chosen per cut (seed // 7 = shot index, see DEVICES), so no two neighbouring cuts match:
    smear  - flat painted brush shapes dragged across in the key colour: hard, chipped brush edges,
             three flat paint tones, a dark painted rim; no streaks, no blur        (`wipe`)
    cut    - a hard cut: the frames are left alone (the cut lands on the shot's last drawing)
    match  - a match on colour: the last two frames are re-lit toward the NEXT shot's key colour
             (luminance kept), so the colour carries across the cut                (`match`)
The paint is the key colour forced saturated (S >= 0.62, V 0.42-0.92): no frame goes white or grey.
`flash` (ink bloom) and `slash` remain available to shots but no cut uses them.
"""
from functools import lru_cache
import colorsys

import cv2
import numpy as np

from .layers import brush_noise


def key_color(key_rgb):
    """The painting's signature light colour: mean of its brightest, most saturated pixels."""
    k = key_rgb if key_rgb.shape[1] <= 400 else cv2.resize(key_rgb, (300, round(key_rgb.shape[0] * 300 / key_rgb.shape[1])),
                                                            interpolation=cv2.INTER_AREA)
    mx, mn = k.max(2), k.min(2)
    score = (mx - mn) * mx
    sel = score >= np.quantile(score, 0.97)
    c = k[sel].mean(0)
    return tuple(float(v) for v in np.clip(c / max(c.max(), 1e-3), 0, 1))


def paint_color(color):
    """The key colour as paint: saturated, never near white or grey. Returns (deep, body, hot) RGB."""
    r, g, b = [float(np.clip(v, 0, 1)) for v in color]
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    if s < 0.18:                       # no usable hue: fall back to ember orange
        h, s = 0.07, 0.8
    s = max(s, 0.62)
    deep = colorsys.hsv_to_rgb(h, min(1.0, s + 0.12), 0.42)
    body = colorsys.hsv_to_rgb(h, s, 0.78)
    hot = colorsys.hsv_to_rgb(h, max(0.62, s - 0.08), 0.92)
    return np.float32(deep), np.float32(body), np.float32(hot)


def _ss(a, b, x):
    t = np.clip((x - a) / max(b - a, 1e-6), 0, 1)
    return t * t * (3 - 2 * t)


def _capsule(c, d, L, t, taper=0.35):
    """Polygon of a tapered brush stroke centred at c along unit d, half-length L, half-width t."""
    nrm = np.array([-d[1], d[0]])
    u = np.linspace(-1, 1, 32)
    prof = np.sqrt(np.clip(1 - u ** 2, 0, 1)) ** 0.5 * (1 - taper * np.clip(u, 0, 1))
    top = c + np.outer(u * L, d) + np.outer(prof * t, nrm)
    bot = c + np.outer(u * L, d) - np.outer(prof * t, nrm)
    return np.concatenate([top, bot[::-1]])


def _fill(mask, pts):
    cv2.fillPoly(mask, [np.round(pts * 8).astype(np.int32)], 1.0, cv2.LINE_AA, shift=3)


def _dry_edge(mask, seed, angle, depth=34.0):
    """Hard painted boundary with chipped, ragged brush edges (blobby noise thresholded against the
    distance to the edge; a 1 px anti-aliased rim, no blur, no streaks)."""
    m8 = (mask > 0.5).astype(np.uint8)
    dist = cv2.distanceTransform(m8, cv2.DIST_L2, 5)
    H, W = mask.shape
    chips = brush_noise((H // 4, W // 4), seed, scale=3.0, angle=angle, stretch=4.0)
    chips = cv2.resize(chips, (W, H), interpolation=cv2.INTER_LINEAR)
    keep = dist / depth + 0.30 * chips - 0.12        # > 0 keeps paint; deep inside is always kept
    alpha = np.clip(keep * 40.0 + 0.5, 0, 1) * np.clip(mask * 2.0, 0, 1)
    return alpha.astype(np.float32), dist


def _paint(img, alpha, dist, color, seed, angle, opacity=1.0, tone=None):
    """Lay key-colour paint over img through alpha: three flat tones in broad brush-shaped patches with
    hard boundaries, and a dark painted rim along the edge. No streak texture, no blur."""
    H, W = img.shape[:2]
    deep, body, hot = paint_color(color)
    if tone is None:
        broad = brush_noise((H // 8, W // 8), seed + 13, scale=4.0, angle=angle, stretch=9.0)
        broad = cv2.resize(broad, (W, H), interpolation=cv2.INTER_LINEAR)
        tone = np.digitize(broad, [-0.9, 0.8])    # 0 deep, 1 body, 2 hot: long flat bands along the stroke
    paint = np.stack([deep, body, hot])[tone]
    rim = (dist < 7.0)[..., None]                                  # painted dark rim, hard-edged
    paint = np.where(rim, deep * 0.85, paint)
    a = (alpha * opacity)[..., None]
    return np.clip(img * (1 - a) + paint * a, 0, 1).astype(np.float32)


# ------------------------------------------------------------------ the three marks (masks cached)
@lru_cache(maxsize=16)
def _wipe_mask(H, W, seed, cover, direction):
    """Horizontal loaded-brush strokes dragged in from the left (mirrored for direction < 0). Returns
    (mask, tone): each stroke is one flat tone (deep or body) with a hard hot ridge along its upper edge."""
    rng = np.random.default_rng(seed)
    m = np.zeros((H, W), np.float32)
    tone = np.ones((H, W), np.uint8)
    y = -40.0
    k = 0
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    while y < H + 40:
        th = rng.uniform(150, 280)
        ang = np.deg2rad(rng.uniform(-7, 7))
        d = np.array([np.cos(ang), np.sin(ang)])
        nrm = np.array([-d[1], d[0]])
        end = cover * W * rng.uniform(0.8, 1.15)
        c = np.array([end / 2 - 60, y + th / 2])
        sm = np.zeros((H, W), np.float32)
        _fill(sm, _capsule(c, d, end / 2 + 60, th / 2 * 1.2, taper=0.3))
        st = (sm > 0.5)
        m = np.maximum(m, sm)
        tone[st] = 0 if k % 3 == 1 else 1
        across = (xx - c[0]) * nrm[0] + (yy - c[1]) * nrm[1]          # signed distance from the stroke axis
        tone[st & (across < -th * rng.uniform(0.22, 0.34))] = 2       # hot ridge along one edge
        y += th * rng.uniform(0.6, 0.82)
        k += 1
    if direction < 0:
        m, tone = m[:, ::-1].copy(), tone[:, ::-1].copy()
    return m, tone


@lru_cache(maxsize=16)
def _bloom_mask(H, W, seed, cover):
    rng = np.random.default_rng(seed)
    cx, cy = W * rng.uniform(0.42, 0.58), H * rng.uniform(0.4, 0.5)
    R = cover * np.hypot(W, H) * 0.56
    th = np.linspace(0, 2 * np.pi, 720, endpoint=False)
    r = np.ones_like(th)
    for k in range(2, 9):
        r += rng.uniform(0.03, 0.10) / (k ** 0.4) * np.sin(k * th + rng.uniform(0, 6.3))
    for _ in range(9):                                            # ink fingers pushing outward
        c0, wdt = rng.uniform(0, 2 * np.pi), rng.uniform(0.05, 0.16)
        r += rng.uniform(0.10, 0.28) * np.exp(-((np.angle(np.exp(1j * (th - c0)))) / wdt) ** 2)
    pts = np.stack([cx + R * r * np.cos(th), cy + R * r * np.sin(th)], 1)
    m = np.zeros((H, W), np.float32)
    _fill(m, pts)
    for _ in range(int(26 * (1.2 - cover))):                       # splatter beyond the blot
        a = rng.uniform(0, 2 * np.pi)
        d = R * rng.uniform(1.15, 1.6)
        rad = rng.uniform(6, 26) * (1.4 - cover)
        cv2.circle(m, (int(cx + d * np.cos(a)) * 8, int(cy + d * np.sin(a)) * 8), int(rad * 8), 1.0,
                   -1, cv2.LINE_AA, shift=3)
    return m


@lru_cache(maxsize=16)
def _slash_mask(H, W, seed, n, direction):
    rng = np.random.default_rng(seed)
    m = np.zeros((H, W), np.float32)
    ang = np.deg2rad(rng.uniform(-38, -28) * direction)
    d = np.array([np.cos(ang), np.sin(ang)])
    nrm = np.array([-d[1], d[0]])
    span = abs(W * nrm[0]) + abs(H * nrm[1])
    offs = np.sort(rng.uniform(-0.5, 0.5, n)) if n < 6 else np.linspace(-0.48, 0.48, n) + rng.uniform(-0.03, 0.03, n)
    for o in offs:
        c = np.array([W / 2, H / 2]) + nrm * o * span + d * rng.uniform(-120, 120)
        L = rng.uniform(0.75, 1.1) * np.hypot(W, H) / 2
        t = rng.uniform(0.07, 0.12) * span * (1.0 if n < 6 else 1.25)
        _fill(m, _capsule(c, d, L, t, taper=0.5))
    return m, float(ang)


# ------------------------------------------------------------------ public marks
def smear(img, strength=1.0, direction=1, seed=0):
    """Dry-brush wipe in from the side opposite `direction` in ember orange (see `wipe` for a colour):
    strength 0.8 ~ 45 % of the width covered, 1.75 ~ nearly all. Drawn paint, no blur."""
    return wipe(img, (1.0, 0.5, 0.2), strength, direction, seed)


def wipe(img, color, strength=1.0, direction=1, seed=0):
    """Dry-brush wipe of `color` (see `smear`)."""
    H, W = img.shape[:2]
    cover = float(np.clip(0.56 * strength, 0.05, 1.05))
    m, tone = _wipe_mask(H, W, seed, round(cover, 3), 1 if direction > 0 else -1)
    alpha, dist = _dry_edge(m, seed + 3, 0.0, depth=60.0)
    return _paint(img, alpha, dist, color, seed, 0.0, tone=tone)


def flash(img, color, amount=0.7, seed=0):
    """Ink-bloom flash of `color`: a blot that covers ~amount of the frame from its centre."""
    H, W = img.shape[:2]
    m = _bloom_mask(H, W, seed, round(float(np.clip(amount, 0.05, 1.2)), 3))
    alpha, dist = _dry_edge(m, seed + 3, np.deg2rad(20.0), depth=22.0)
    return _paint(img, alpha, dist, color, seed, np.deg2rad(20.0))


def slash(img, color, n=3, direction=1, seed=0):
    """`n` broad diagonal brush slashes in `color` (3 = partial, 8 = nearly full)."""
    H, W = img.shape[:2]
    m, ang = _slash_mask(H, W, seed, int(n), 1 if direction > 0 else -1)
    alpha, dist = _dry_edge(m, seed + 3, ang, depth=46.0)
    return _paint(img, alpha, dist, color, seed, ang)


def match(img, color, amount=0.5):
    """Re-light img toward `color` (the next shot's key colour), keeping its luminance: a match cut on
    colour. amount 0..1."""
    deep, body, hot = paint_color(color)
    hsv = cv2.cvtColor(np.float32(body).reshape(1, 1, 3), cv2.COLOR_RGB2HSV)[0, 0]
    if 225.0 <= hsv[0] <= 345.0:          # never relight toward violet / purple (v5: s12 -> s13 went violet)
        hsv[0] = 212.0
        hsv[1] = min(hsv[1], 0.45)
        body = cv2.cvtColor(hsv.reshape(1, 1, 3), cv2.COLOR_HSV2RGB)[0, 0]
    lum = (img @ np.float32([0.3, 0.55, 0.15]))[..., None]
    tint = body / max(float(body @ np.float32([0.3, 0.55, 0.15])), 1e-3)
    lit = np.clip(lum * tint, 0, 1)
    return np.clip(img * (1 - amount) + lit * amount, 0, 1).astype(np.float32)


# device per cut, by outgoing shot index (12 cuts): all hard cuts (match/smear stay available)
DEVICES = ["cut"] * 12   # fix round: the colour-match tint led into only 4 of 12 cuts; every cut is now a clean hard cut


def cut_frame(img, frames_left, color, seed=0, next_color=None):
    """Transition treatment for the outgoing shot's last frames (frames_left = 2 or 1)."""
    if frames_left not in (1, 2):
        return img
    shot = seed // 7
    device = DEVICES[shot % len(DEVICES)]
    direction = 1 if (shot // 3) % 2 == 0 else -1
    img = np.clip(img, 0, 1).astype(np.float32)
    if device == "smear":
        return wipe(img, color, 0.9 if frames_left == 2 else 1.9, direction, seed=seed)
    if device == "match":
        return match(img, next_color if next_color is not None else color, 0.35 if frames_left == 2 else 0.7)
    return img
