"""Split a painted key image into depth planes and animatable sprites.

Planes come from a CPU depth map (Depth Anything V2 small, see tools/depth.py),
cut into bands, snapped to painted edges with a guided filter, and each plane
is extended behind whatever sits in front of it (push-pull fill plus brush
texture) so camera parallax and sprite motion reveal paint, never holes.

Everything is cached as one compressed work/layers/<shot>/layers.npz (+ meta.json). Delete the folder
(or pass force=True) after changing a shot's PLANES/SPRITES spec.
"""
import json
from dataclasses import dataclass, field

import cv2
import numpy as np

from .config import LAYER_CACHE, WORK_SCALE


# ---------------------------------------------------------------- primitives
def guided_filter(guide, src, r, eps):
    """He et al. guided filter, single-channel guide, float32 in [0,1]."""
    box = lambda x: cv2.boxFilter(x, -1, (2 * r + 1, 2 * r + 1))
    mI, mp = box(guide), box(src)
    cov = box(guide * src) - mI * mp
    var = box(guide * guide) - mI * mI
    a = cov / (var + eps)
    b = mp - a * mI
    return np.clip(box(a) * guide + box(b), 0, 1)


def push_pull_fill(img, valid, levels=12):
    """Fill pixels where valid==0 from surrounding valid pixels (pyramid normalized convolution)."""
    img = img.astype(np.float32)
    w = valid.astype(np.float32)
    if img.ndim == 2:
        img = img[..., None]
    pyr = []
    cur_c, cur_w = img * w[..., None], w
    for _ in range(levels):
        pyr.append((cur_c, cur_w))
        if min(cur_w.shape) < 4:
            break
        cur_c = cv2.pyrDown(cur_c)
        if cur_c.ndim == 2:
            cur_c = cur_c[..., None]
        cur_w = cv2.pyrDown(cur_w)
    c, ww = pyr[-1]
    filled = c / np.maximum(ww[..., None], 1e-6)
    for c, ww in reversed(pyr[:-1]):
        up = cv2.resize(filled, (c.shape[1], c.shape[0]), interpolation=cv2.INTER_LINEAR)
        if up.ndim == 2:
            up = up[..., None]
        a = np.clip(ww * 4.0, 0, 1)[..., None]
        filled = a * (c / np.maximum(ww[..., None], 1e-6)) + (1 - a) * up
    out = np.where(valid[..., None] > 0.5, img, filled)
    return out[..., 0] if out.shape[2] == 1 else out


def brush_noise(shape, seed, scale=6.0, angle=-0.35, stretch=5.0):
    """Anisotropic stroke-like noise, zero mean, unit std."""
    rng = np.random.default_rng(seed)
    h, w = shape
    n = rng.standard_normal((h, w)).astype(np.float32)
    k = int(scale * stretch) | 1
    ker = np.zeros((k, k), np.float32)
    c = k // 2
    dx, dy = np.cos(angle), np.sin(angle)
    for i in range(-c, c + 1):
        x, y = int(round(c + i * dx)), int(round(c + i * dy))
        ker[y, x] = 1
    ker /= ker.sum()
    n = cv2.filter2D(n, -1, ker)
    n = cv2.GaussianBlur(n, (0, 0), scale * 0.35)
    n -= n.mean()
    return n / (n.std() + 1e-6)


def textured_fill(img, valid, seed, amp_scale=1.0):
    """Push-pull fill, then add brush-like texture matched to the plate's own high-pass energy."""
    filled = push_pull_fill(img, valid)
    hp = img - cv2.GaussianBlur(img, (0, 0), 3)
    v = valid > 0.5
    amp = float(np.sqrt((hp[v] ** 2).mean())) if v.any() else 0.02
    noise = (brush_noise(valid.shape, seed, scale=5.0, angle=-0.35) +
             brush_noise(valid.shape, seed + 1, scale=9.0, angle=1.1, stretch=3.0)) * 0.7
    # modulate so it reads as patchy strokes, not a uniform hatch
    patch = cv2.GaussianBlur(np.random.default_rng(seed + 2).standard_normal(valid.shape).astype(np.float32), (0, 0), 25)
    patch = np.clip(0.5 + patch / (patch.std() + 1e-6) * 0.35, 0.15, 1.0)
    lum = (noise * patch)[..., None] * amp * 0.9 * amp_scale
    out = filled + np.where(v[..., None], 0, lum)
    return np.clip(out, 0, 1)


def poly_mask(shape, pts, scale=1.0):
    m = np.zeros(shape, np.uint8)
    cv2.fillPoly(m, [np.round(np.asarray(pts, np.float32) * scale).astype(np.int32)], 255, cv2.LINE_AA)
    return m.astype(np.float32) / 255


# -------------------------------------------------------------------- specs
@dataclass
class PlaneSpec:
    name: str
    dmin: float                 # depth band (relative inverse depth, 0 far .. 1 near)
    dmax: float
    fill: str = "dilate"        # "full" = opaque everywhere, "dilate" = extend r px behind occluders
    radius: int = 70            # extension radius in working px
    region: list = None         # optional polygon (key px) the band is restricted to


@dataclass
class SpriteSpec:
    name: str
    plane: int                  # plane the sprite lives in (for parallax and draw order)
    envelope: list              # polygon (key px) around the moving part
    dmin: float = 0.0           # depth threshold inside the envelope (separates it from the far background)
    dmax: float = 1.0
    pivot: tuple = (0, 0)       # rotation pivot (key px)
    anchor: tuple = None        # (x0, y0, x1, y1) key px: motion weight ramps from 1 at (x0,y0) to 0 at (x1,y1)
    mask_fn: object = None      # optional f(img_rgb01, depth) -> bool mask, ANDed with the envelope
    fill_own_plane: bool = False  # also extend its own plane behind it (when what is behind is that plane)
    extra: dict = field(default_factory=dict)


# -------------------------------------------------------------------- build
def _scaled(pts):
    return [(x * WORK_SCALE, y * WORK_SCALE) for x, y in pts]


def build(shot, key_path, depth_path, planes, sprites, force=False):
    """Cut key_path into planes/sprites using depth_path (16-bit, nearer = larger); cached per shot.
    Coordinates in the specs are key-image pixels (1520 px wide keys, see keyprep.prepare_key)."""
    out = LAYER_CACHE / shot
    meta_path = out / "meta.json"
    if meta_path.exists() and not force:
        return out
    out.mkdir(parents=True, exist_ok=True)
    arrays = {}
    key = cv2.cvtColor(cv2.imread(str(key_path)), cv2.COLOR_BGR2RGB)
    H0, W0 = key.shape[:2]
    W, H = round(W0 * WORK_SCALE), round(H0 * WORK_SCALE)
    img = cv2.resize(key, (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
    depth = cv2.imread(str(depth_path), -1).astype(np.float32) / 65535
    depth = cv2.resize(depth, (W, H), interpolation=cv2.INTER_AREA)
    guide = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    # plane labels from depth bands (later specs win where bands overlap)
    label = np.full((H, W), -1, np.int16)
    for i, p in enumerate(planes):
        m = (depth >= p.dmin) & (depth < p.dmax)
        if p.region:
            m &= poly_mask((H, W), _scaled(p.region)) > 0.5
        label[m] = i
    label[label < 0] = 0

    # sprites
    sprite_masks = []
    for s in sprites:
        env = poly_mask((H, W), _scaled(s.envelope))
        hard = (env > 0.5) & (depth >= s.dmin) & (depth <= s.dmax)
        if s.mask_fn is not None:
            hard &= s.mask_fn(img, depth)
        hard = hard.astype(np.float32)
        hard = cv2.morphologyEx(hard, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        soft = guided_filter(guide, hard, 4, 1e-3)
        soft = np.clip((soft - 0.25) / 0.5, 0, 1)
        # envelope cuts stay crisp (anti-aliased polygon) so the plane underneath is exactly complementary
        sprite_masks.append(soft * env)
    any_sprite = np.zeros((H, W), np.float32)
    for m in sprite_masks:
        any_sprite = np.maximum(any_sprite, m)

    meta = {"W": W, "H": H, "planes": [], "sprites": []}
    for i, p in enumerate(planes):
        hard_band = (label == i).astype(np.float32)
        soft = guided_filter(guide, hard_band, 4, 1e-3)
        soft = np.clip((soft - 0.3) / 0.4, 0, 1) * (1 - any_sprite)
        hard = hard_band * (any_sprite < 0.5)
        # occluders: nearer planes plus sprites that live in nearer-or-equal planes
        occ = (label > i).astype(np.float32)
        for s, m in zip(sprites, sprite_masks):
            if s.plane > i or (s.plane == i and s.fill_own_plane):
                occ = np.maximum(occ, (m > 0.02).astype(np.float32))
        if p.fill == "full":
            ext = np.ones_like(soft) if i == 0 else np.maximum(soft, occ)
            if i > 0:
                ext = np.clip(cv2.GaussianBlur(ext, (0, 0), 1.0) * 1.2, 0, 1)
        else:
            k = 2 * p.radius + 1
            near = cv2.dilate(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
            ext_region = near * occ
            ext_region = cv2.GaussianBlur(ext_region, (0, 0), p.radius * 0.25)
            ext = np.maximum(soft, np.clip(ext_region * 1.5, 0, 1) * (occ > 0.02))
        valid = cv2.erode(hard, np.ones((5, 5), np.uint8))
        rgb = textured_fill(img, valid, seed=17 + i)
        rgb = np.where(hard[..., None] > 0.5, img, rgb)
        # per-plane depth: interior values only, extended and smoothed so each plane bends gently
        # and never ripples along its cut edge (depth-model edges are soft)
        core = cv2.erode(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)))
        if core.sum() < 100:
            core = valid
        dep = push_pull_fill(depth, core)
        dep = cv2.GaussianBlur(dep, (0, 0), 18)
        arrays[f"plane{i}_rgb"] = (rgb * 255 + 0.5).astype(np.uint8)
        arrays[f"plane{i}_a"] = (ext * 255 + 0.5).astype(np.uint8)
        arrays[f"plane{i}_d"] = (dep * 65535).astype(np.uint16)
        meta["planes"].append({"name": p.name, "index": i})

    for j, (s, m) in enumerate(zip(sprites, sprite_masks)):
        ys, xs = np.where(m > 0.01)
        pad = 48
        x0, x1 = max(xs.min() - pad, 0), min(xs.max() + pad, W)
        y0, y1 = max(ys.min() - pad, 0), min(ys.max() + pad, H)
        rgba = np.dstack([img[y0:y1, x0:x1], m[y0:y1, x0:x1]])
        # motion weight: 1 on the free end, ramping to 0 at the anchored end
        wgt = np.ones((y1 - y0, x1 - x0), np.float32)
        if s.anchor:
            ax0, ay0, ax1, ay1 = [v * WORK_SCALE for v in s.anchor]
            gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
            dvec = np.array([ax1 - ax0, ay1 - ay0], np.float32)
            u = ((gx - ax0) * dvec[0] + (gy - ay0) * dvec[1]) / (dvec @ dvec)
            u = np.clip(u, 0, 1)
            wgt = 1 - u * u * (3 - 2 * u)
        arrays[f"sprite{j}_rgba"] = (rgba * 255 + 0.5).astype(np.uint8)
        arrays[f"sprite{j}_w"] = (wgt * 255 + 0.5).astype(np.uint8)
        meta["sprites"].append({"name": s.name, "plane": s.plane, "bbox": [int(x0), int(y0), int(x1), int(y1)],
                                "pivot": [s.pivot[0] * WORK_SCALE, s.pivot[1] * WORK_SCALE], **s.extra})
    # one compressed archive per shot (~4x smaller than raw arrays; the disk is nearly full)
    np.savez_compressed(out / "layers.npz", **arrays)
    meta_path.write_text(json.dumps(meta, indent=1))
    return out


class Layers:
    """Plane/sprite stack for one shot, loaded from the cache written by build()."""

    def __init__(self, shot):
        d = LAYER_CACHE / shot
        self.dir = d
        self.meta = json.loads((d / "meta.json").read_text())
        self.W, self.H = self.meta["W"], self.meta["H"]
        if (d / "layers.npz").exists():
            z = np.load(d / "layers.npz")
            ld = lambda n: z[n[:-4]]
        else:                                     # older uncompressed caches
            ld = lambda n: np.load(d / n, mmap_mode="r")
        self.planes = [{"rgb": ld(f"plane{i}_rgb.npy"), "a": ld(f"plane{i}_a.npy"), "d": ld(f"plane{i}_d.npy"),
                        **p} for i, p in enumerate(self.meta["planes"])]
        self.sprites = [{"rgba": ld(f"sprite{j}_rgba.npy"), "w": ld(f"sprite{j}_w.npy"), **s}
                        for j, s in enumerate(self.meta["sprites"])]

    def sprite_index(self, name):
        return next(i for i, s in enumerate(self.sprites) if s["name"] == name)
