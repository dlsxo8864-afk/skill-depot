"""Type: hand-lettered paint on surfaces, on-screen titles, tags and data labels.

All on-screen type is rendered at 2x, given slightly irregular edges and a
paper/canvas tooth, then handed back as float RGBA so the final style pass
grains and grades it together with the painting.
"""
import math
from functools import lru_cache

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .config import FONT_FILES, FONTS
from .layers import brush_noise


MIN_CAP = 30      # px cap height at 1080 wide: the smallest on-screen type the series allows (phone legibility)


@lru_cache(maxsize=64)
def font(kind, size, weight=None):
    f = ImageFont.truetype(str(FONTS / FONT_FILES[kind]), int(size))
    if weight is not None:
        try:
            f.set_variation_by_axes([14 if kind == "sans" else weight, weight] if kind == "sans" else [weight])
        except Exception:
            pass
    f._whatif = ("font", kind, int(size), weight)
    return f


def cap_height(fnt):
    return fnt.getbbox("H")[3] - fnt.getbbox("H")[1]


def at_least_cap(fnt, min_cap=MIN_CAP):
    """The same face, enlarged until its cap height is >= min_cap px (unchanged if already large)."""
    if not min_cap or cap_height(fnt) >= min_cap:
        return fnt
    meta = getattr(fnt, "_whatif", None)
    size = int(fnt.size)
    for _ in range(40):
        size = max(size + 1, int(math.ceil(size * min_cap / max(cap_height(fnt), 1))))
        if meta and meta[0] == "font":
            fnt = font(meta[1], size, meta[3])
        elif meta and meta[0] == "sans":
            fnt = sans(size, meta[1])
        else:
            fnt = fnt.font_variant(size=size)
        if cap_height(fnt) >= min_cap:
            break
    return fnt


def sans(size, weight=700):
    return _sans(int(size), int(weight))


@lru_cache(maxsize=64)
def _sans(size, weight):
    f = ImageFont.truetype(str(FONTS / FONT_FILES["sans"]), int(size))
    try:
        axes = f.get_variation_axes()
        vals = []
        for ax in axes:
            name = ax.get("name", b"")
            name = name.decode() if isinstance(name, bytes) else str(name)
            vals.append(weight if "eight" in name else min(max(int(size) // 2, ax["minimum"]), ax["maximum"]))
        f.set_variation_by_axes(vals)
    except Exception:
        pass
    f._whatif = ("sans", weight)
    return f


def text_size(fnt, s):
    x0, y0, x1, y1 = fnt.getbbox(s)
    return x1 - x0, y1 - y0, x0, y0


def wrap(fnt, text, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if text_size(fnt, trial)[0] <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


# ------------------------------------------------------------------ textures
@lru_cache(maxsize=8)
def paper_tooth(h, w, seed=3):
    """Static canvas/paper tooth in [-1, 1]: fine weave plus soft blotches."""
    rng = np.random.default_rng(seed)
    fine = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), 0.8)
    blot = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), 12)
    t = fine / (fine.std() + 1e-6) * 0.5 + blot / (blot.std() + 1e-6) * 0.6
    return np.clip(t / 1.5, -1, 1)


def rough_alpha(a, seed, amount=0.6):
    """Make a crisp text alpha read as ink/paint: irregular edge and dry-brush streaks."""
    h, w = a.shape
    n = brush_noise((h, w), seed, scale=2.0, angle=0.0, stretch=4.0)
    edge = cv2.GaussianBlur(a, (0, 0), 1.2)
    a2 = np.clip((edge - 0.5 + n * 0.12 * amount) * 3.0 + 0.5, 0, 1)
    return np.minimum(a2, cv2.dilate(a, np.ones((3, 3), np.uint8)))


# ----------------------------------------------------------- painted signs
def lettering(lines, size_px, w, h, seed=0, font_kind="marker", line_gap=0.92, jitter=0.6):
    """Hand-lettered block centred in a w x h canvas. Returns alpha float32 (h, w)."""
    rng = np.random.default_rng(seed)
    S = 2
    canvas = Image.new("L", (w * S, h * S), 0)
    fnt = font(font_kind, size_px * S)
    heights = [text_size(fnt, ln)[1] for ln in lines]
    lh = max(heights) * (1 + (1 - line_gap) * 0 + 0.18)
    total = lh * len(lines)
    y = (h * S - total) / 2
    for ln in lines:
        lw = sum(text_size(fnt, ch)[0] + 6 * S if ch != " " else text_size(fnt, "n")[0] * 0.7 for ch in ln)
        scale = min(1.0, (w * S * 0.96) / max(lw, 1))
        x = (w * S - lw * scale) / 2
        base_tilt = rng.normal(0, 1.5 * jitter)
        for ch in ln:
            if ch == " ":
                x += text_size(fnt, "n")[0] * 0.7 * scale
                continue
            cw, chh, ox, oy = text_size(fnt, ch)
            tile = Image.new("L", (int(cw * 1.6 + 20 * S), int(lh * 1.4)), 0)
            ImageDraw.Draw(tile).text((10 * S - ox, (lh * 0.2) - oy + (lh - heights[0]) * 0.3), ch, font=fnt, fill=255)
            sc = scale * (1 + rng.normal(0, 0.04 * jitter))
            tile = tile.resize((max(1, int(tile.width * sc)), max(1, int(tile.height * sc))), Image.LANCZOS)
            tile = tile.rotate(base_tilt + rng.normal(0, 3.0 * jitter), resample=Image.BICUBIC, expand=False)
            dy = rng.normal(0, 3.0 * S * jitter)
            canvas.paste(255, (int(x - 10 * S * sc), int(y + dy)), tile)
            x += (cw + 6 * S) * sc
        y += lh
    a = np.asarray(canvas, np.float32) / 255
    k = max(3, int(size_px * S * 0.045)) | 1          # marker -> loaded brush weight
    a = cv2.dilate(a, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    a = cv2.resize(a, (w, h), interpolation=cv2.INTER_AREA)
    return rough_alpha(a, seed + 11, 1.0)


def warp_to_quad(alpha, quad, out_shape):
    """Perspective-map a flat canvas alpha onto a quad (TL, TR, BR, BL) in a target image."""
    h, w = alpha.shape
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    M = cv2.getPerspectiveTransform(src, np.float32(quad))
    return cv2.warpPerspective(alpha, M, (out_shape[1], out_shape[0]), flags=cv2.INTER_LINEAR)


def paint_on_surface(rgb, alpha, paint_rgb, opacity=0.92, seed=0):
    """Lay paint into a painted surface so its light and grain carry through.
    rgb float32 (h,w,3) is modified in place."""
    lum = rgb.mean(2, keepdims=True)
    m = float(lum[alpha > 0.3].mean()) if (alpha > 0.3).any() else float(lum.mean())
    shade = np.clip(0.55 + 0.6 * lum / max(m, 1e-3), 0.3, 1.6)
    streak = brush_noise(alpha.shape, seed, scale=1.5, angle=0.05, stretch=8.0)[..., None]
    paint = np.asarray(paint_rgb, np.float32)[None, None] * shade * (1 + 0.06 * streak)
    a = (alpha * opacity)[..., None] * np.clip(0.92 + 0.12 * streak, 0.6, 1.0)
    rgb[:] = rgb * (1 - a) + paint * a
    return rgb


# ----------------------------------------------------------- on-screen type
def render_text_block(spec, W, H):
    """spec: list of dicts {text, font(PIL), color, x, y, (max_w), (align)}; returns list of line
    items {img RGBA float32 at 2x downsampled, x, y, w, h, anchor} for animation."""
    items = []
    for s in spec:
        fnt = s["font"]
        tw, th, ox, oy = text_size(fnt, s["text"])
        pad = int(fnt.size * 0.35)
        im = Image.new("L", (tw + 2 * pad, th + 2 * pad), 0)
        ImageDraw.Draw(im).text((pad - ox, pad - oy), s["text"], font=fnt, fill=255)
        items.append({"a": np.asarray(im, np.float32) / 255, "x": s["x"] - pad, "y": s["y"] - pad,
                      "color": s["color"], **{k: v for k, v in s.items() if k not in ("font", "text")}})
    return items


def styled_text_rgba(alpha, color, shadow=(18, 8, 30), seed=0, outline=0, grad=0.10,
                     shadow_off=(4, 5), soft_shadow=10, shadow_strength=0.75):
    """Turn a text alpha into a finished RGBA: slight vertical tint gradient, canvas tooth,
    irregular edges, hard drop shadow plus a soft ambient shadow in deep violet (never black)."""
    h, w = alpha.shape
    pad = soft_shadow * 2 + max(shadow_off) + 4
    A = np.zeros((h + 2 * pad, w + 2 * pad), np.float32)
    A[pad:pad + h, pad:pad + w] = alpha
    A = rough_alpha(A, seed, 0.35)
    col = np.asarray(color, np.float32) / 255
    yy = np.linspace(-1, 1, A.shape[0], dtype=np.float32)[:, None, None]
    tooth = paper_tooth(*A.shape, seed=seed % 5 + 1)[..., None]
    rgb_fill = np.clip(col * (1 + grad * -yy) * (1 + 0.05 * tooth), 0, 1) * np.ones((1, A.shape[1], 1), np.float32)
    sh = np.asarray(shadow, np.float32) / 255
    M = np.float32([[1, 0, shadow_off[0]], [0, 1, shadow_off[1]]])
    hard = cv2.warpAffine(A, M, (A.shape[1], A.shape[0]))
    soft = cv2.GaussianBlur(A, (0, 0), soft_shadow) * 0.55
    if outline:
        ring = cv2.dilate(A, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * outline + 1,) * 2))
        hard = np.maximum(hard, ring)
    sa = np.clip(np.maximum(hard * 0.95, soft) * shadow_strength, 0, 1)
    out_a = A + sa * (1 - A)
    rgb = (rgb_fill * A[..., None] + sh * (sa * (1 - A))[..., None]) / np.maximum(out_a[..., None], 1e-4)
    return np.dstack([rgb, out_a]).astype(np.float32), pad


def over(dst, rgba, x, y, opacity=1.0):
    """Alpha-over float RGBA onto float RGB dst at integer offset (clipped)."""
    h, w = rgba.shape[:2]
    H, W = dst.shape[:2]
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return dst
    p = rgba[ya - y:yb - y, xa - x:xb - x]
    a = p[..., 3:4] * opacity
    dst[ya:yb, xa:xb] = dst[ya:yb, xa:xb] * (1 - a) + p[..., :3] * a
    return dst


def transform_rgba(rgba, scale=1.0, angle=0.0, origin=None):
    """Scale/rotate an RGBA patch about origin (patch px); returns new patch and offset of its (0,0)."""
    h, w = rgba.shape[:2]
    if abs(scale - 1) < 1e-4 and abs(angle) < 1e-4:
        return rgba, 0, 0
    ox, oy = origin if origin is not None else (w / 2, h / 2)
    M = cv2.getRotationMatrix2D((ox, oy), angle, scale)
    corners = np.array([[0, 0, 1], [w, 0, 1], [w, h, 1], [0, h, 1]], np.float32) @ M.T
    x0, y0 = np.floor(corners.min(0)).astype(int)
    x1, y1 = np.ceil(corners.max(0)).astype(int)
    M[:, 2] -= (x0, y0)
    out = cv2.warpAffine(rgba, M, (x1 - x0, y1 - y0), flags=cv2.INTER_LINEAR, borderValue=0)
    return out, x0, y0


def pop_scale(u):
    """Snappy 2s-style pop: small -> overshoot -> settle, u = (time since start) in seconds."""
    if u < 0:
        return None
    keys = [(0.0, 0.55), (2 / 24, 1.12), (4 / 24, 0.97), (6 / 24, 1.0)]
    for (t0, v0), (t1, v1) in zip(keys, keys[1:]):
        if u <= t1:
            return v0 + (v1 - v0) * ((u - t0) / (t1 - t0))
    return 1.0


def over_rgba(dst, src, x, y, opacity=1.0):
    """Straight-alpha RGBA over RGBA (both float32), in place on dst."""
    h, w = src.shape[:2]
    H, W = dst.shape[:2]
    x, y = int(round(x)), int(round(y))
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return dst
    s = src[ya - y:yb - y, xa - x:xb - x]
    d = dst[ya:yb, xa:xb]
    sa = s[..., 3:4] * opacity
    da = d[..., 3:4]
    oa = sa + da * (1 - sa)
    rgb = (s[..., :3] * sa + d[..., :3] * da * (1 - sa)) / np.maximum(oa, 1e-6)
    dst[ya:yb, xa:xb] = np.concatenate([rgb, oa], axis=2)
    return dst
