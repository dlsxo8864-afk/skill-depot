"""2.5D parallax camera over depth planes.

Each plane is warped with a per-pixel scale/offset driven by its own (filled)
depth, so continuous surfaces bend smoothly while depth discontinuities are
handled by the plane split. The camera moves on 1s (every frame); sprites and
effects are posed on 2s by the shot code before they reach the camera.
"""
import math

import cv2
import numpy as np

from .config import OUT_H, OUT_W


class ParallaxCamera:
    def __init__(self, W, H, focus, nearness, zoom, push, rise, pan=None, roll=None):
        """W,H: working plate size. focus: (x, y) working px the push-in heads toward.
        nearness: f(depth array) -> 0 (sky) .. 1 (closest foreground).
        zoom/push/rise/pan/roll: callables of time (seconds) -> float.
        zoom scales everything; push adds scale proportional to nearness (dolly);
        rise shifts content down proportional to nearness (camera rising), in output px."""
        self.W, self.H = W, H
        self.focus_fn = focus if callable(focus) else (lambda t, f=tuple(focus): f)
        self.nearness = nearness
        self.zoom, self.push, self.rise = zoom, push, rise
        self.pan = pan or (lambda t: 0.0)
        self.roll = roll or (lambda t: 0.0)
        self.s0 = max(OUT_W / W, OUT_H / H)
        gy, gx = np.mgrid[0:OUT_H, 0:OUT_W].astype(np.float32)
        self.qx, self.qy = gx, gy
        self.C = np.array([OUT_W / 2, OUT_H / 2], np.float32)

    def focus(self, t):
        """Focus point clamped so the farthest plane (nearness 0) always covers the frame."""
        fx, fy = self.focus_fn(t)
        S = self.s0 * self.zoom(t)
        hw, hh = OUT_W / 2 / S, OUT_H / 2 / S
        return (min(max(fx, hw), self.W - hw), min(max(fy, hh), self.H - hh))

    def screen_point(self, p, n, t):
        """Forward map of a working-space point with nearness n to output px (for overlays)."""
        S = self.s0 * self.zoom(t) * (1 + self.push(t) * n)
        F = self.focus(t)
        dx, dy = (p[0] - F[0]) * S, (p[1] - F[1]) * S
        r = math.radians(self.roll(t))
        rx, ry = dx * math.cos(r) - dy * math.sin(r), dx * math.sin(r) + dy * math.cos(r)
        return (self.C[0] + rx + self.pan(t) * n, self.C[1] + ry + self.rise(t) * n)

    def scale_at(self, n, t):
        return self.s0 * self.zoom(t) * (1 + self.push(t) * n)

    def _inverse(self, nmap_w, t, n_init):
        z, k, rise, pan = self.zoom(t), self.push(t), self.rise(t), self.pan(t)
        r = math.radians(self.roll(t))
        cr, sr = math.cos(r), math.sin(r)
        F = self.focus(t)
        n = np.full(self.qx.shape, n_init, np.float32) if np.isscalar(n_init) else n_init
        for _ in range(3):
            S = self.s0 * z * (1 + k * n)
            ux = self.qx - self.C[0] - pan * n
            uy = self.qy - self.C[1] - rise * n
            vx, vy = ux * cr + uy * sr, -ux * sr + uy * cr      # undo roll
            px = F[0] + vx / S
            py = F[1] + vy / S
            n = cv2.remap(nmap_w, px, py, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        return px, py

    def render(self, planes, t):
        """planes: list (far->near) of dict(rgb float32 HxWx3, a float32 HxW, n float32 HxW nearness).
        Returns float32 OUT_H x OUT_W x 3 composite, plus per-plane coverage (for debugging)."""
        out = None
        for pl in planes:
            n_mean = float(np.median(pl["n"][::16, ::16]))
            px, py = self._inverse(pl["n"], t, n_mean)
            rgba = np.dstack([pl["rgb"], pl["a"]]).astype(np.float32)
            w = cv2.remap(rgba, px, py, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            if out is None:
                out = w[..., :3].copy()
            else:
                a = w[..., 3:4]
                out = out * (1 - a) + w[..., :3] * a
        return out


def deform_sprite(sprite, angle_deg=0.0, dx=0.0, dy=0.0, scale=1.0):
    """Pose a sprite (rigid rotate/translate/scale about its pivot) with the motion
    weight ramp so its anchored end stays attached. Returns (rgba float32, x0, y0)."""
    rgba = sprite["rgba"]
    rgba = rgba.astype(np.float32) / 255 if rgba.dtype == np.uint8 else rgba
    wgt = sprite["w"].astype(np.float32) / 255
    x0, y0, x1, y1 = sprite["bbox"]
    px, py = sprite["pivot"]
    h, w = rgba.shape[:2]
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    gx += x0
    gy += y0
    a = math.radians(angle_deg)
    ca, sa = math.cos(-a), math.sin(-a)
    # inverse rigid transform: source = R^-1 (q - pivot - d)/s + pivot
    ux, uy = (gx - px - dx) / scale, (gy - py - dy) / scale
    sx = ux * ca - uy * sa + px
    sy = ux * sa + uy * ca + py
    sx = gx + wgt * (sx - gx) - x0
    sy = gy + wgt * (sy - gy) - y0
    outp = cv2.remap(rgba, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    return outp, x0, y0


def composite_into(dst_rgb, dst_a, rgba, x0, y0):
    """Alpha-over a working-space RGBA patch into plane arrays (in place)."""
    h, w = rgba.shape[:2]
    H, W = dst_a.shape
    xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x0 + w, W), min(y0 + h, H)
    if xb <= xa or yb <= ya:
        return
    p = rgba[ya - y0:yb - y0, xa - x0:xb - x0]
    a = p[..., 3:4]
    dst_rgb[ya:yb, xa:xb] = dst_rgb[ya:yb, xa:xb] * (1 - a) + p[..., :3] * a
    dst_a[ya:yb, xa:xb] = dst_a[ya:yb, xa:xb] * (1 - a[..., 0]) + a[..., 0]
