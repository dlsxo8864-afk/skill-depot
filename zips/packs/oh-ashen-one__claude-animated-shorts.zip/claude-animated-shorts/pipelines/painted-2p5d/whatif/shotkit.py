"""The contract between the episode renderer (src/ep03.py) and one shot module (src/shots/<stem>.py).

A shot module exposes `make(ctx) -> shot`. The shot object needs:
    frame(f) -> (rgb float32 (1920, 1080, 3) in 0..1, info dict)   f = GLOBAL frame, ctx.f0 <= f < ctx.f1
and may add:
    finish_args(f, info) -> dict        kwargs for style.finish (bloom_strength, vignette, ...)
    events() -> [(f, kind, info)]       picture events, printed in the sync table
    sound(snd)                          place beds and effects with the ShotSound `snd`
    flash_color = (r, g, b)             cut-flash colour (default: the key's signature colour)
    transition = False                  opt out of the automatic smear/flash + whoosh/hit at its cut

The renderer adds, for every shot: the final style pass, the cut treatment on the last two frames
(whatif.transitions), a whoosh into the cut and a hit on it, and a tick when the year tag lands.
BaseShot gives the standard year tag / data tag drawing; inheriting it is optional.
"""
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from . import audio as A
from . import overlays as O
from .config import FPS
from .timing import even_frame_of, frame_of


def _key(w):
    return w.strip(",.?!;:")


@dataclass
class ShotContext:
    """Everything a shot needs to know about its place in the episode. Times are GLOBAL seconds,
    frames are GLOBAL frame numbers (frame 0 = first frame of the episode)."""
    stem: str
    index: int
    f0: int                      # first frame of the shot
    f1: int                      # first frame of the next shot (exclusive end)
    key: Path                    # key painting as delivered (assets/key/...)
    wav: Path                    # this shot's narration line
    year: int | None             # YEAR tag number, None for no tag
    words: list = field(default_factory=list)   # [{"w", "s", "e", "src"}], script spelling, global s/e
    speech_on: float = 0.0       # first spoken sound of the line
    speech_off: float = 0.0      # last spoken sound of the line
    vo_at: float = 0.0           # where the wav file starts
    is_last: bool = False

    # ---- time helpers
    @property
    def n(self):
        return self.f1 - self.f0

    @property
    def dur(self):
        return self.n / FPS

    def word(self, w, n=0):
        """n-th word matching w (exact spelling first, then case-insensitive; punctuation ignored).
        Hyphenated numbers are one word: "forty-nine". Raises KeyError with the line's words if absent."""
        exact = [x for x in self.words if _key(x["w"]) == _key(w)]
        loose = [x for x in self.words if _key(x["w"]).lower() == _key(w).lower()]
        hits = exact if len(exact) > n else loose
        if len(hits) <= n:
            raise KeyError(f"{w!r} not in {self.stem}: {' '.join(x['w'] for x in self.words)}")
        return hits[n]

    def t(self, w, n=0, at="s"):
        """Global time (s) of a word's start ("s") or end ("e")."""
        return self.word(w, n)[at]

    def f(self, w, n=0, at="s", even=True):
        """Frame of a word: even=True puts it on the 2s grid (characters/FX), False for camera/cuts."""
        t = self.t(w, n, at)
        return even_frame_of(t) if even else frame_of(t)

    def local(self, f):
        """Seconds since the shot started (for camera Tracks that span the shot)."""
        return (f - self.f0) / FPS

    def key_paths(self):
        """(upscaled key, depth map) paths; computed once and cached (see keyprep)."""
        from .keyprep import prepare_key
        return prepare_key(self.key)


class BaseShot:
    """Optional base class: stores ctx and draws the series tags in their standard slots."""
    transition = True
    flash_color = None

    def __init__(self, ctx: ShotContext):
        self.ctx = ctx
        self.f0, self.f1 = ctx.f0, ctx.f1

    def draw_year_tag(self, img, f, f_in=None):
        """YEAR n, top-left, popping in 2 frames after the cut."""
        if self.ctx.year is None:
            return img
        x, y = O.tag_slots()["year"]
        O.draw_pop(img, O.year_tag(self.ctx.year), x, y, f, self.f0 + 2 if f_in is None else f_in)
        return img

    def draw_data_tag(self, img, f, text, f_in, f_out=None, size=44, xy=None):
        """One data tag under the year tag, popping in at f_in and (optionally) out at f_out."""
        x, y = xy if xy is not None else O.tag_slots()["data"]
        O.draw_pop(img, O.data_tag(text, size=size), x, y, f, f_in, f_out)
        return img

    def finish_args(self, f, info):
        return {}

    def events(self):
        return []

    def sound(self, snd):
        pass


class ShotSound:
    """Audio stems for one shot. Two buses: `bed` (ambience, ducked under the narration at assembly)
    and `sfx` (effects, never ducked). Positions are GLOBAL seconds or frames; the stem covers
    [shot start - PRE, shot end + POST] so tails and lead-ins may cross the cut."""
    PRE, POST = 1.0, 1.5

    def __init__(self, ctx: ShotContext):
        self.ctx = ctx
        self.t0 = ctx.f0 / FPS - self.PRE
        self.t1 = ctx.f1 / FPS + self.POST
        self.n = int(round((self.t1 - self.t0) * A.SR))
        self.buses = {"bed": np.zeros((self.n, 2)), "sfx": np.zeros((self.n, 2))}

    @staticmethod
    def at_frame(f):
        return f / FPS

    def _add(self, bus, x, t, gain_db, pan):
        x = np.asarray(x, np.float64)
        i = int(round((t - self.t0) * A.SR))
        if x.ndim == 1:
            a = (pan + 1) * np.pi / 4
            x = np.stack([x * np.cos(a), x * np.sin(a)], 1)
        if i < 0:
            x, i = x[-i:], 0
        x = x[: max(0, self.n - i)] * A.db(gain_db)
        self.buses[bus][i:i + len(x)] += x

    def sfx(self, x, t, gain_db=0.0, pan=0.0):
        """Effect at global time t (s). Use snd.at_frame(f) to land it on a picture frame."""
        self._add("sfx", x, t, gain_db, pan)

    def bed(self, x, t, gain_db=0.0, pan=0.0):
        """Ambience starting at global time t (s); ducked under the narration when assembled."""
        self._add("bed", x, t, gain_db, pan)

    def shot_span(self):
        """(start, length) in seconds of the shot itself, for beds that fill the shot."""
        return self.ctx.f0 / FPS, self.ctx.dur
