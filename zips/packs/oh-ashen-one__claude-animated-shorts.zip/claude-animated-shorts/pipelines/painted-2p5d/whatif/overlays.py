"""Reusable on-screen overlays for the series: YEAR tag (years 1-10), data tags, enlarged cards.

All return float32 RGBA patches built from painted swatches + styled type, so the
final style pass grains and grades them with the painting."""
import math
from functools import lru_cache

import cv2
import numpy as np
from PIL import Image, ImageDraw

from . import text as T
from .layers import brush_noise

CREAM = (246, 236, 216)
EMBER = (255, 146, 72)
TEAL = (110, 236, 214)
PLUM = (0.13, 0.05, 0.18)


def painted_swatch(w, h, seed, color=PLUM, opacity=0.82, rough=0.22, radius=6):
    """A dry-brushed rectangle of colour: ragged ends, stroke streaks, never a clean UI box."""
    a = np.zeros((h, w), np.float32)
    cv2.rectangle(a, (radius, radius), (w - radius, h - radius), 1.0, -1)
    a = cv2.GaussianBlur(a, (0, 0), 3)
    n = brush_noise((h, w), seed, scale=3, angle=0.02, stretch=14)
    a = np.clip((a - 0.5 + n * rough) * 4 + 0.5, 0, 1) * opacity
    rgb = np.ones((h, w, 3), np.float32) * np.float32(color) * (1 + 0.08 * n[..., None])
    return np.dstack([rgb, a])


def _text_alpha(s, fnt, tracking=0, min_cap=None):
    """Text as a float alpha patch. Enforces the series minimum cap height (T.MIN_CAP = 30 px at
    1080 wide) by enlarging a smaller font; pass min_cap=0 only for diegetic text painted INTO the
    scene (a name on a screen in the picture), never for a tag, label or source line."""
    fnt = T.at_least_cap(fnt, T.MIN_CAP if min_cap is None else min_cap)
    if tracking == 0:
        tw, th, ox, oy = T.text_size(fnt, s)
        im = Image.new("L", (tw + 4, th + 4), 0)
        ImageDraw.Draw(im).text((2 - ox, 2 - oy), s, font=fnt, fill=255)
        return np.asarray(im, np.float32) / 255
    widths = [T.text_size(fnt, ch)[0] for ch in s]
    tw = sum(widths) + tracking * (len(s) - 1)
    _, th, _, oy = T.text_size(fnt, s)
    im = Image.new("L", (tw + 6, th + 4), 0)
    d = ImageDraw.Draw(im)
    x = 2
    for ch, w in zip(s, widths):
        ox = T.text_size(fnt, ch)[2]
        d.text((x - ox, 2 - oy), ch, font=fnt, fill=255)
        x += w + tracking
    return np.asarray(im, np.float32) / 255


def _place(canvas, rgba, x, y):
    T.over_rgba(canvas, rgba, x, y)


@lru_cache(maxsize=16)
def year_tag(n):
    """'YEAR n' tag: small tracked YEAR over a big ember numeral, on a painted plum chip."""
    a_year = _text_alpha("YEAR", T.font("display", 40), tracking=6)
    a_num = _text_alpha(str(n), T.font("display", 104))
    y_rgba, py = T.styled_text_rgba(a_year, CREAM, seed=40 + n, shadow_off=(2, 3), soft_shadow=5, shadow_strength=0.5)
    n_rgba, pn = T.styled_text_rgba(a_num, EMBER, seed=50 + n, shadow_off=(3, 4), soft_shadow=8, grad=0.16)
    w = a_year.shape[1] + a_num.shape[1] + 70
    h = max(a_num.shape[0], a_year.shape[0]) + 40
    chip = painted_swatch(w, h, seed=60 + n)
    canvas = np.zeros((h + 40, w + 40, 4), np.float32)
    T.over_rgba(canvas, chip, 10, 14)
    # underline stroke in ember
    ul = painted_swatch(a_year.shape[1] + 6, 10, seed=70 + n, color=np.float32(EMBER) / 255, opacity=0.95, rough=0.3, radius=1)
    T.over_rgba(canvas, n_rgba, 10 + 28 + a_year.shape[1] + 14 - pn, 14 + 20 - pn)
    T.over_rgba(canvas, y_rgba, 10 + 26 - py, 14 + 20 + a_num.shape[0] - a_year.shape[0] - 14 - py)
    T.over_rgba(canvas, ul, 10 + 24, 14 + 20 + a_num.shape[0] - 4)
    return canvas


SAFE_X1, SAFE_Y1 = round(1080 * 0.86), round(1920 * 0.78)    # nothing past 86 % width / 78 % height
SAFE_X0, SAFE_Y0 = round(1080 * 0.06), round(1920 * 0.06)


def _wrapped_alpha(text, fnt, max_w, line_gap=1.18):
    """Text alpha wrapped to max_w px (word wrap; min cap enforced), lines left-aligned."""
    fnt = T.at_least_cap(fnt)
    lines = [ln for part in text.split("\n") for ln in T.wrap(fnt, part, max_w)]   # "\n" forces a break
    if len(lines) == 1:
        return _text_alpha(text, fnt)
    alphas = [_text_alpha(ln, fnt) for ln in lines]
    step = int(T.cap_height(fnt) * 1.0 + fnt.size * (line_gap - 0.72))
    h = step * (len(alphas) - 1) + alphas[-1].shape[0]
    w = max(a.shape[1] for a in alphas)
    out = np.zeros((h, w), np.float32)
    for i, a in enumerate(alphas):
        out[i * step:i * step + a.shape[0], :a.shape[1]] = np.maximum(out[i * step:i * step + a.shape[0], :a.shape[1]], a)
    return out


TAG_CAP = 33     # data tag / source text cap height at 1080 wide (11 px on a 360-wide phone preview)


def painted_chip(w, h, seed, color=PLUM, opacity=0.86):
    """A brush-laid chip of paint: slightly tilted, uneven ends and edges (chipped, hard, no blur), two
    flat tones laid along the stroke. Float RGBA (h + 16, w + 16)."""
    rng = np.random.default_rng(seed)
    H, W = h + 16, w + 16
    # outline: a long quad with jittered vertices along each edge (a brush stroke, not a box)
    n = 9
    xs = np.linspace(8, W - 8, n)
    top = np.stack([xs, 8 + rng.uniform(-3, 4, n) + np.linspace(0, rng.uniform(-4, 4), n)], 1)
    bot = np.stack([xs[::-1], H - 8 + rng.uniform(-4, 3, n) + np.linspace(rng.uniform(-4, 4), 0, n)], 1)
    ends = [np.array([[8 - rng.uniform(2, 9), H * rng.uniform(0.3, 0.7)]]),
            np.array([[W - 8 + rng.uniform(2, 9), H * rng.uniform(0.3, 0.7)]])]
    pts = np.concatenate([ends[0], top, ends[1], bot])
    a = np.zeros((H, W), np.float32)
    cv2.fillPoly(a, [np.round(pts * 8).astype(np.int32)], 1.0, cv2.LINE_AA, shift=3)
    dist = cv2.distanceTransform((a > 0.5).astype(np.uint8), cv2.DIST_L2, 5)
    chips = brush_noise((H, W), seed + 1, scale=2.5, angle=0.03, stretch=5)
    a = np.clip((dist / 6.0 + 0.35 * chips - 0.15) * 30 + 0.5, 0, 1) * np.clip(a * 2, 0, 1)
    band = brush_noise((H, W), seed + 2, scale=5, angle=0.02, stretch=14)
    c0 = np.float32(color)
    rgb = np.where((band > 0.55)[..., None], c0 * 1.45 + 0.02, c0)           # flat lighter streaks of paint
    rgb = np.where((dist < 2.5)[..., None], c0 * 0.6, rgb)                   # darker painted rim
    return np.dstack([rgb.astype(np.float32), a * opacity])


@lru_cache(maxsize=16)
def data_tag(text, size=30):
    """Data tag: a painted chip (uneven, chipped edges; takes the scene's light when drawn with
    draw_pop/seat) with the fact in sans type of at least TAG_CAP cap height. Wraps to two lines if the
    chip would run past 86 % width from the standard data slot ("\n" in text forces a line break)."""
    max_text_w = SAFE_X1 - (SAFE_X0 - 6) - 74 - 20 - 8
    a = _wrapped_alpha(text, T.at_least_cap(T.sans(size, 640), TAG_CAP), max_text_w)
    a = np.maximum(T.rough_alpha(a, 83, 0.35), a * 0.85)
    t_rgba, pad = T.styled_text_rgba(a, CREAM, seed=80, shadow_off=(1, 2), soft_shadow=4, shadow_strength=0.45, grad=0.10)
    w, h = a.shape[1] + 74, a.shape[0] + 34
    chip = painted_chip(w, h, seed=81 + len(text))
    canvas = np.zeros((h + 20, w + 20, 4), np.float32)
    T.over_rgba(canvas, chip, -2, -2)
    dot = painted_swatch(14, 14, seed=82, color=np.float32(TEAL) / 255, opacity=1.0, rough=0.1, radius=1)
    T.over_rgba(canvas, dot, 6 + 22, 6 + h // 2 - 7)
    T.over_rgba(canvas, t_rgba, 6 + 50 - pad, 6 + 17 - pad)
    return canvas


def card_with_shadow(rgba, seed=0, underlight=None):
    """Give a UI card a soft violet drop shadow and the canvas tooth, as float RGBA."""
    h, w = rgba.shape[:2]
    pad = 40
    out = np.zeros((h + 2 * pad, w + 2 * pad, 4), np.float32)
    sh = np.zeros((h + 2 * pad, w + 2 * pad), np.float32)
    sh[pad + 10:pad + 10 + h, pad + 4:pad + 4 + w] = rgba[..., 3]
    sh = cv2.GaussianBlur(sh, (0, 0), 16) * 0.75
    out[..., :3] = np.float32([0.05, 0.02, 0.09])
    out[..., 3] = sh
    tooth = T.paper_tooth(h, w, seed=seed % 5 + 1)[..., None]
    card = rgba.copy()
    card[..., :3] = np.clip(card[..., :3] * (1 + 0.035 * tooth), 0, 1)
    if underlight is not None:
        # paint the dark body (not the type): stroke streaks plus light from the scene below and the icon
        body = np.abs(card[..., :3] - card[h // 2, w - 12, :3]).max(-1) < 0.06
        bodyf = cv2.GaussianBlur(body.astype(np.float32), (0, 0), 1.0)[..., None]
        n = brush_noise((h, w), seed + 7, scale=3, angle=0.06, stretch=12)[..., None]
        yy = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
        under = np.clip((yy - 0.35) / 0.65, 0, 1) ** 1.6 * np.float32(underlight) * 0.30
        xx = np.linspace(0, 1, w, dtype=np.float32)[None, :, None]
        warm = np.exp(-((xx - 0.08) ** 2) / 0.02 - ((yy - 0.45) ** 2) / 0.2) * np.float32([0.16, 0.08, 0.02])
        painted = card[..., :3] * (1 + 0.12 * n) + under + warm
        card[..., :3] = np.clip(card[..., :3] * (1 - bodyf) + painted * bodyf, 0, 1)
    T.over_rgba(out, card, pad, pad)
    return out, pad


# ------------------------------------------------------------------ scenario label
@lru_cache(maxsize=8)
def scenario_label(size=26, text="scenario"):
    """Small lowercase 'scenario' chip that sits next to every invented figure (series rule)."""
    a = _text_alpha(text, T.sans(size, 600), tracking=1)
    t_rgba, pad = T.styled_text_rgba(a, (255, 214, 170), seed=90, shadow_off=(1, 1), soft_shadow=3,
                                     shadow_strength=0.35, grad=0.04)
    w, h = a.shape[1] + 30, a.shape[0] + 16
    chip = painted_swatch(w, h, seed=91, color=(0.30, 0.10, 0.16), opacity=0.85, rough=0.18, radius=4)
    canvas = np.zeros((h + 12, w + 12, 4), np.float32)
    T.over_rgba(canvas, chip, 6, 6)
    T.over_rgba(canvas, t_rgba, 6 + 15 - pad, 6 + 8 - pad)
    return canvas


# ------------------------------------------------------------------ rolling number counter
@lru_cache(maxsize=4)
def _digit_strip(size, color, seed):
    """Styled glyphs for 0-9 (tabular cells) plus the cell size, for the odometer."""
    fnt = T.font("display", size)
    cw = max(T.text_size(fnt, str(d))[0] for d in range(10)) + 4
    ch = int(size * 1.18)
    _, th0, _, oy0 = T.text_size(fnt, "0")
    base_y = (ch - th0) / 2 - oy0                        # same pen y for every glyph = shared baseline
    cells = []
    for d in range(10):
        im = Image.new("L", (cw, ch), 0)
        tw, th, ox, oy = T.text_size(fnt, str(d))
        ImageDraw.Draw(im).text(((cw - tw) / 2 - ox, base_y), str(d), font=fnt, fill=255)
        cells.append(np.asarray(im, np.float32) / 255)
    return cells, cw, ch, base_y


def counter_rgba(value, fmt="${:,.2f}", size=150, color=CREAM, decimals=2, roll=True, seed=5):
    """A big number as a mechanical counter. Digits sit in fixed-width cells; with roll=True each
    column scrolls to its next digit as the columns to its right pass 9 (a true odometer), so a
    smoothly eased value reads as rolling. Feed it a value sampled on 2s (see roll_value)."""
    scale = 10 ** decimals
    x = round(max(float(value), 0.0) * scale, 6)
    text = fmt.format(np.floor(x) / scale)
    cells, cw, ch, base_y = _digit_strip(size, color, seed)
    fnt = T.font("display", size)
    # glyph alpha strip, left to right
    cols = []
    digit_k = sum(c.isdigit() for c in text) - 1          # place value of the leftmost digit
    for c in text:
        if c.isdigit():
            k = digit_k
            digit_k -= 1
            d = int(c)
            if not roll:
                frac = 0.0
            elif k == 0:
                frac = x - np.floor(x)
            else:
                frac = max(0.0, (x % 10 ** k) - (10 ** k - 1))
            col = np.zeros((ch, cw), np.float32)
            sh = int(round(frac * ch))
            col[: ch - sh] = cells[d][sh:]
            if sh:
                col[ch - sh:] = cells[(d + 1) % 10][: sh]
            cols.append(col)
        else:
            tw, th, ox, oy = T.text_size(fnt, c)
            w = max(tw + 4, int(size * 0.18))
            im = Image.new("L", (w, ch), 0)
            ImageDraw.Draw(im).text(((w - tw) / 2 - ox, base_y), c, font=fnt, fill=255)
            cols.append(np.asarray(im, np.float32) / 255)
    a = np.concatenate(cols, axis=1)
    rgba, _ = T.styled_text_rgba(a, color, seed=seed, shadow_off=(4, 6), soft_shadow=10, grad=0.14)
    return rgba


def roll_value(f, f_start, f_end, v0, v1, ease="inout"):
    """Counter value at frame f, eased from v0 (at f_start) to v1 (at f_end), sampled on 2s."""
    from .timing import Track
    fh = f - f % 2
    return float(Track([(f_start, v0), (f_end, v1, ease)])(fh))


# ------------------------------------------------------------------ pop in / out
def pop_out_scale(d):
    """Old shrink-away on 2s (kept for callers; series rule now: tags leave with a slide or a cut)."""
    return {0: 1.06, 2: 0.7, 4: 0.3}.get(d - d % 2)


def seat(img, rgba, x, y, opacity=1.0, tint=0.30, wrap=0.45, soften=0.8, glow=None, ambient=0.28):
    """Composite an overlay patch INTO the painting instead of on top of it (series rule: no pasted-on
    look). Its edge is softened like a painted edge, its colours take on the scene's local light, the
    blurred picture behind it bleeds over its rim (light wrap), `ambient` of the scene's local colour falls
    on its dark paint (a chip takes the light of the place it sits in), and an optional `glow` (rgb 0..1) adds
    a soft coloured halo from a light source in the scene. The final style pass then grains, blooms and
    vignettes it together with everything else. In place on img (float RGB); returns img."""
    import cv2
    h, w = rgba.shape[:2]
    H, W = img.shape[:2]
    x, y = int(round(x)), int(round(y))
    m = 24                                                # margin for blur context
    xa, ya, xb, yb = max(x - m, 0), max(y - m, 0), min(x + w + m, W), min(y + h + m, H)
    if xb <= xa or yb <= ya:
        return img
    reg = img[ya:yb, xa:xb]
    P = np.zeros((yb - ya, xb - xa, 4), np.float32)
    T.over_rgba(P, rgba, x - xa, y - ya)
    a = cv2.GaussianBlur(P[..., 3], (0, 0), soften) if soften else P[..., 3]
    rgb = P[..., :3]
    bg = cv2.GaussianBlur(reg, (0, 0), 14)
    lum = float(bg.max(2).mean()) + 1e-3
    light = np.clip(bg / lum, 0, 1.7)
    rgb = rgb * ((1 - tint) + tint * light)
    # the scene's own light falls on the dark paint of a chip (not on its light type)
    amb = cv2.GaussianBlur(reg, (0, 0), 40)
    dark = np.clip(1 - rgb.max(2, keepdims=True) / 0.45, 0, 1)
    rgb = rgb + amb * ambient * dark
    inner = np.clip(a - cv2.GaussianBlur(a, (0, 0), 3.0), 0, 1) * 2.2      # band just inside the edge
    near = cv2.GaussianBlur(reg, (0, 0), 5)
    k = np.clip(inner * wrap, 0, 0.8)[..., None]
    rgb = rgb * (1 - k) + (rgb * 0.5 + near * 0.9) * k
    out = reg * (1 - a[..., None] * opacity) + rgb * a[..., None] * opacity
    if glow is not None:
        halo = cv2.GaussianBlur(P[..., 3], (0, 0), 18)[..., None] * (1 - a[..., None]) * 0.35 * opacity
        out = 1 - (1 - out) * (1 - np.float32(glow) * halo)
    img[ya:yb, xa:xb] = out
    return img


def draw_pop(img, rgba, x, y, f, f_in, f_out=None, origin=None, opacity=1.0, seated=True, glow=None):
    """Draw rgba at (x, y) with the series pop: in at f_in (overshoot + settle on 2s), and if f_out is
    given a quick slide out toward the nearer side edge starting there (two drawings, never a shrink).
    origin is the scale pivot inside the patch (default left-middle, so tags grow out of the margin).
    seated=True composites with `seat` (scene light, light wrap, soft edge); glow adds a coloured halo.
    Returns True if drawn."""
    fh = f - f % 2
    if fh < f_in or (f_out is not None and fh >= f_out + 4):
        return False
    s = T.pop_scale((fh - f_in) / 24)
    dx = 0
    if f_out is not None and fh >= f_out:
        s = 1.0
        side = -1 if x + rgba.shape[1] / 2 < 540 else 1
        dx = side * {0: 0.22, 2: 0.75}[fh - f_out] * (rgba.shape[1] + 40)
    if not s or s < 0.05:
        return False
    o = origin if origin is not None else (20, rgba.shape[0] / 2)
    x, y = safe_clamp(rgba, x, y)
    x += dx
    p, ox, oy = T.transform_rgba(rgba, s, 0, origin=o)
    if seated:
        seat(img, p, x + ox, y + oy, opacity=opacity, glow=glow)
    else:
        T.over(img, p, x + ox, y + oy, opacity=opacity)
    return True


def safe_clamp(rgba, x, y, thresh=0.3):
    """Shift a patch placed at (x, y) so its visible part (alpha > thresh, shadows ignored) stays inside
    the safe area: x 6-86 % of the width, y 6-78 % of the height. A patch larger than the safe area on
    an axis keeps its position on that axis (big cards and full-frame layers are not moved)."""
    vis = rgba[..., 3] > thresh
    if not vis.any():
        return x, y
    ys, xs = np.nonzero(vis.any(1))[0], np.nonzero(vis.any(0))[0]
    l, r, t, b = xs[0], xs[-1], ys[0], ys[-1]
    if r - l <= SAFE_X1 - SAFE_X0:
        x = x + min(0, SAFE_X1 - (x + r)) + max(0, SAFE_X0 - (x + l) - min(0, SAFE_X1 - (x + r)))
    if b - t <= SAFE_Y1 - SAFE_Y0:
        y = y + min(0, SAFE_Y1 - (y + b)) + max(0, SAFE_Y0 - (y + t) - min(0, SAFE_Y1 - (y + b)))
    return int(x), int(y)


def tag_slots():
    """Standard positions inside the safe area: {'year': (x, y), 'data': (x, y)} for the series tags."""
    from .config import safe_box
    x0, y0, x1, y1 = safe_box()
    yt = year_tag(1)
    return {"year": (x0 - 10, y0 - 14), "data": (x0 - 6, y0 + yt.shape[0] - 30)}


# ------------------------------------------------------------------ episode 3: fan-content label
@lru_cache(maxsize=4)
def fan_tag(text="Unofficial fan fiction", size=28):
    """Small chip that marks the episode as unofficial fan content (hook and CTA). Cap height >= 30 px."""
    a = _text_alpha(text, T.sans(size, 620), tracking=1)
    t_rgba, pad = T.styled_text_rgba(a, CREAM, seed=95, shadow_off=(1, 2), soft_shadow=3, shadow_strength=0.4,
                                     grad=0.04)
    w, h = a.shape[1] + 34, a.shape[0] + 20
    chip = painted_swatch(w, h, seed=96, color=(0.10, 0.05, 0.14), opacity=0.86, rough=0.18, radius=4)
    canvas = np.zeros((h + 12, w + 12, 4), np.float32)
    T.over_rgba(canvas, chip, 6, 6)
    T.over_rgba(canvas, t_rgba, 6 + 17 - pad, 6 + 10 - pad)
    return canvas
