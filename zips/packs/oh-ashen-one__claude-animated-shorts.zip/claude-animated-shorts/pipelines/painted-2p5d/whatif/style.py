"""Final look pass applied to every finished frame: one image, one surface.

Order: grade -> bloom on emissive areas -> faint coloured shadow -> vignette -> black point (darkest
2 % pulled to about 0.045 luma) -> static canvas tooth -> film grain that changes on 2s.
"""
from functools import lru_cache

import cv2
import numpy as np

from .config import OUT_H, OUT_W
from .text import paper_tooth

SHADOW_TINT = np.array([0.065, 0.035, 0.095], np.float32)   # deep violet floor (deepest shadows only)


@lru_cache(maxsize=2)
def _vignette(h, w, strength):
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    r = np.sqrt(((x - w / 2) / (w * 0.62)) ** 2 + ((y - h * 0.48) / (h * 0.62)) ** 2)
    return np.clip(1 - strength * r ** 2.4, 0, 1)[..., None]


@lru_cache(maxsize=2)
def _canvas(h, w):
    t = paper_tooth(h, w, seed=9)
    return t[..., None]


def bloom(img, threshold=0.62, strength=0.55, mask=None):
    lum = img.max(2)
    sat = img.max(2) - img.min(2)
    k = np.clip((lum - threshold) / (1 - threshold), 0, 1) * np.clip(sat * 2.0 + 0.2, 0, 1)
    if mask is not None:
        k = k * mask
    src = img * k[..., None]
    small = cv2.resize(src, (OUT_W // 4, OUT_H // 4), interpolation=cv2.INTER_AREA)
    b = cv2.GaussianBlur(small, (0, 0), 3) * 0.6 + cv2.GaussianBlur(small, (0, 0), 10) * 0.4
    b = cv2.resize(b, (OUT_W, OUT_H), interpolation=cv2.INTER_LINEAR)
    return 1 - (1 - img) * (1 - np.clip(b * strength, 0, 1))      # screen blend


def grain(frame_index, h, w, amount=0.032):
    seed = frame_index // 2                                     # grain on 2s
    rng = np.random.default_rng(1000 + seed)
    n = rng.standard_normal((h // 2, w // 2, 1)).astype(np.float32)
    n = cv2.resize(n, (w, h), interpolation=cv2.INTER_LINEAR)[..., None]
    c = rng.standard_normal((h // 4, w // 4, 3)).astype(np.float32)
    c = cv2.resize(c, (w, h), interpolation=cv2.INTER_LINEAR)
    fine = rng.standard_normal((h, w, 1)).astype(np.float32)
    return (n * 0.6 + fine * 0.4) * amount + c * amount * 0.25


# ------------------------------------------------------------------ colour grade
GRADE_DEFAULT = {
    "strength": 0.9,          # how far purple surfaces move (0 = off)
    "shadow": (0.07, 0.20),   # value range: purple kept below the first, fully regraded above the second
    "lit": (0.30, 0.60),      # value range from ambient (cool) to lit (warm) for regraded purple
    "ambient_hue": 208.0,     # cool slate ambient (not cyan: cyan + warm light mixes into olive)
    "warm_hue": 26.0,         # warm key light on the subject
    "ambient_sat": 0.55,      # saturation kept by purple turned ambient: a coloured slate blue, not a teal wash
    "lit_sat": 0.85,
    "skin": (328.0, 30.0),    # (hue, half width): mauve / pink faces and hands take the warm key at any value
    "skin_hue": 18.0,         # hue of that warm key on skin
    "olive_cap": 0.9,         # regraded pixels that land in 45-150 deg (olive / green) lose this much saturation
    "warm_sat_max": 0.78,     # saturation ceiling of the warm key on regraded pixels
    "mid_sat": 1.7,           # max chroma gain where cool ambient and warm key mix (stops grey skin)
    "skin_vibrance": 0.35,    # extra saturation for warm midtones (skin) after the grade
    "protect": (),            # [(hue deg, half width deg)] light colours that carry meaning: left alone
    "protect_emissive": True, # saturated bright pixels (lamps, screens, fire) are never regraded
    "split": (0.008, 0.03),   # cool into the low mids, warm into the highlights (whole frame)
}
BLACK_POINT = 0.045           # finish(): the darkest 2 % of pixels are pulled to about this luma (Rec.709)


def _ang(a, b):
    """Signed shortest angle from b to a (degrees)."""
    return (a - b + 540.0) % 360.0 - 180.0


def _ss(a, b, x):
    t = np.clip((x - a) / max(b - a, 1e-6), 0, 1)
    return t * t * (3 - 2 * t)


def grade(img, params=None):
    """Arcane-style grade: purple surfaces become cool slate ambient (dark) or warm key light (lit);
    mauve skin takes the warm key at any value; nothing lands in olive; protected hues and emissive
    lights are untouched. img float RGB 0..1."""
    p = dict(GRADE_DEFAULT)
    p.update(params or {})
    if p["strength"] <= 0:
        return img
    hsv = cv2.cvtColor(np.clip(img, 0, 1).astype(np.float32), cv2.COLOR_RGB2HSV)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    # the band: blue-violet through purple to magenta (222-355 deg); reds and skin tones stay outside
    hh = (h - 222.0) % 360.0
    wp = np.clip(hh / 14.0, 0, 1) * np.clip((133.0 - hh) / 10.0, 0, 1) * np.clip((s - 0.07) / 0.12, 0, 1)
    k = p["strength"] * wp * _ss(p["shadow"][0], p["shadow"][1], v)
    for hc, hw in p["protect"]:
        k = k * np.clip((np.abs(_ang(h, hc)) - hw) / 10.0, 0, 1)
    if p["protect_emissive"]:
        k = k * (1 - _ss(0.55, 0.75, s) * _ss(0.62, 0.85, v))
    # warm weight: lit values, and skin-coloured mauve at any but the deepest value
    sc, sw = p["skin"]
    skin = np.clip((sw - np.abs(_ang(h, sc))) / 12.0, 0, 1) * _ss(0.16, 0.34, v) * (1 - _ss(0.55, 0.8, s))
    t = np.maximum(_ss(p["lit"][0], p["lit"][1], v), skin)[..., None]
    amb, warm = hsv.copy(), hsv.copy()
    amb[..., 0] = (h + k * _ang(p["ambient_hue"], h)) % 360.0
    amb[..., 1] = s * (1 - k * (1 - p["ambient_sat"]))
    wh = p["warm_hue"] + (p["skin_hue"] - p["warm_hue"]) * skin
    warm[..., 0] = (h + k * _ang(wh, h)) % 360.0
    warm[..., 1] = np.minimum(s * (1 - k * (1 - p["lit_sat"])), s * (1 - k) + k * p["warm_sat_max"])
    out = cv2.cvtColor(amb, cv2.COLOR_HSV2RGB) * (1 - t) + cv2.cvtColor(warm, cv2.COLOR_HSV2RGB) * t
    # mixing a cool ambient with a warm key in RGB greys the middle (pale grey skin): give back chroma
    # up to the saturation the two endpoints have, capped, around each pixel's own grey
    if p["mid_sat"] > 1:
        want = amb[..., 1] * (1 - t[..., 0]) + warm[..., 1] * t[..., 0]
        g0 = out.mean(2, keepdims=True)
        mx, mn = out.max(2), out.min(2)
        have = (mx - mn) / np.maximum(mx, 1e-3)
        oh1 = cv2.cvtColor(out.astype(np.float32), cv2.COLOR_RGB2HSV)[..., 0]
        nopurple = 1 - np.clip((oh1 - 228.0) / 12.0, 0, 1) * np.clip((350.0 - oh1) / 10.0, 0, 1)
        gain = 1 + (np.clip(want / np.maximum(have, 1e-3), 1, p["mid_sat"]) - 1) * np.clip(k * 1.5, 0, 1) * nopurple
        out = np.clip(g0 + (out - g0) * gain[..., None], 0, 1)
    # cap: a regraded pixel that ends up olive / green (45-150 deg) is desaturated toward its own grey
    if p["olive_cap"] > 0:
        oh = cv2.cvtColor(out.astype(np.float32), cv2.COLOR_RGB2HSV)[..., 0]
        ol = (np.clip((oh - 45.0) / 10.0, 0, 1) * np.clip((150.0 - oh) / 10.0, 0, 1)) * np.clip(k * 1.5, 0, 1)
        g = out.mean(2, keepdims=True)
        out = out + (g - out) * (p["olive_cap"] * ol)[..., None]
    # vibrance on warm midtones (skin, lamplight): Arcane faces read warm and saturated
    if p["skin_vibrance"] > 0:
        oh2 = cv2.cvtColor(out.astype(np.float32), cv2.COLOR_RGB2HSV)
        hw_ = np.clip((40.0 - np.abs(_ang(oh2[..., 0], 18.0))) / 15.0, 0, 1)
        vw = _ss(0.12, 0.30, oh2[..., 2]) * (1 - _ss(0.55, 0.85, oh2[..., 1]))
        g1 = out.mean(2, keepdims=True)
        out = np.clip(g1 + (out - g1) * (1 + p["skin_vibrance"] * hw_ * vw)[..., None], 0, 1)
    lum = out @ np.float32([0.3, 0.55, 0.15])
    lo, hi = p["split"]
    out = out + (np.float32([-0.2, 0.0, 0.25]) * lo * np.clip(1 - np.abs(lum - 0.3) / 0.25, 0, 1)[..., None]
                 + np.float32([0.5, 0.2, -0.35]) * hi * np.clip((lum - 0.55) / 0.35, 0, 1)[..., None])
    return np.clip(out, 0, 1)


def black_point(img, target=BLACK_POINT):
    """Pull the darkest 2 % of pixels to about `target` luma with a toe that leaves mids and highs alone
    (the key paintings have lifted, milky blacks)."""
    lum = img @ np.float32([0.2126, 0.7152, 0.0722])
    p2 = float(np.percentile(lum[::8, ::8], 2))
    if p2 <= target:
        return img
    off = p2 - target                      # above p2 the offset fades out by the knee; below, a plain scale
    knee = p2 + 0.25
    l = np.maximum(lum, 1e-4)
    f = np.where(lum <= p2, target / p2, (l - off * (1 - _ss(p2, knee, l))) / l)
    return img * f[..., None]


def finish(img, frame_index, bloom_strength=0.5, vignette=0.32, grain_amount=0.022, bloom_mask=None, grade_params=None):
    img = np.clip(img, 0, 1).astype(np.float32)
    if grade_params is not False:
        img = grade(img, grade_params)
    img = bloom(img, strength=bloom_strength, mask=bloom_mask)
    # coloured shadows: a faint violet in the darkest values (kept low: blacks must read as black)
    lift = (1 - np.clip(img.max(2, keepdims=True) / 0.22, 0, 1)) ** 2
    img = img + SHADOW_TINT * lift * 0.18
    v = _vignette(OUT_H, OUT_W, vignette)
    img = img * v + SHADOW_TINT * 0.15 * (1 - v)
    img = black_point(img)
    img = img * (1 + 0.014 * _canvas(OUT_H, OUT_W))
    lum = img.mean(2, keepdims=True)
    g = grain(frame_index, OUT_H, OUT_W, grain_amount)
    img = img + g * (0.45 + 0.9 * lum * (1 - lum) * 2)
    return np.clip(img, 0, 1)
