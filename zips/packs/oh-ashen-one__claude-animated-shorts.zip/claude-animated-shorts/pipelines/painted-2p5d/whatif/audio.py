"""Synthesized sound design + narration mix (numpy/scipy only; ffmpeg for loudness).

Primitives return mono float arrays at SR; `Mix` places them (with pan) on a
stereo timeline in seconds. Everything is deterministic (seeded)."""
import json
import re
import subprocess

import numpy as np
import soundfile as sf
from scipy import signal

SR = 48000


def t_axis(dur):
    return np.arange(int(round(dur * SR))) / SR


def env_adsr(n, a=0.005, d=0.05, s=0.6, r=0.1, hold=None):
    a, d, r = int(a * SR), int(d * SR), int(r * SR)
    hold = n - a - d - r if hold is None else int(hold * SR)
    hold = max(hold, 0)
    e = np.concatenate([np.linspace(0, 1, a, endpoint=False), np.linspace(1, s, d, endpoint=False),
                        np.full(hold, s), np.linspace(s, 0, r)])
    return np.pad(e, (0, max(0, n - len(e))))[:n]


def exp_decay(n, tau):
    return np.exp(-np.arange(n) / (tau * SR))


def bandpass(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def lowpass(x, f, order=2):
    return signal.sosfilt(signal.butter(order, f, btype="low", fs=SR, output="sos"), x)


def highpass(x, f, order=2):
    return signal.sosfilt(signal.butter(order, f, btype="high", fs=SR, output="sos"), x)


def noise(dur, seed, kind="white"):
    rng = np.random.default_rng(seed)
    n = rng.standard_normal(int(round(dur * SR)))
    if kind == "brown":
        n = np.cumsum(n)
        n = highpass(n, 15)
        n /= np.abs(n).max() + 1e-9
    elif kind == "pink":
        b, a = [0.049922035, -0.095993537, 0.050612699, -0.004408786], [1, -2.494956002, 2.017265875, -0.522189400]
        n = signal.lfilter(b, a, n)
        n /= np.abs(n).max() + 1e-9
    return n


def osc(freq, dur, kind="sine", phase=0.0):
    """freq may be a scalar or an array (per-sample) for glides."""
    n = int(round(dur * SR))
    f = np.broadcast_to(np.asarray(freq, float), (n,)) if np.ndim(freq) == 0 else np.asarray(freq)[:n]
    ph = 2 * np.pi * np.cumsum(f) / SR + phase
    if kind == "sine":
        return np.sin(ph)
    if kind == "saw":
        return 2 * ((ph / (2 * np.pi)) % 1) - 1
    if kind == "tri":
        return 2 * np.abs(2 * ((ph / (2 * np.pi)) % 1) - 1) - 1
    raise ValueError(kind)


def db(x):
    return 10 ** (x / 20)


class Mix:
    def __init__(self, dur):
        self.buf = np.zeros((int(round(dur * SR)) + SR, 2))
        self.dur = dur

    def add(self, x, t, gain_db=0.0, pan=0.0):
        """pan -1 (L) .. 1 (R), equal power."""
        i = int(round(t * SR))
        if i < 0:
            x = x[-i:]
            i = 0
        x = x[: max(0, len(self.buf) - i)] * db(gain_db)
        a = (pan + 1) * np.pi / 4
        self.buf[i:i + len(x), 0] += x * np.cos(a)
        self.buf[i:i + len(x), 1] += x * np.sin(a)

    def add_stereo(self, xs, t, gain_db=0.0):
        i = int(round(t * SR))
        xs = xs[: len(self.buf) - i] * db(gain_db)
        self.buf[i:i + len(xs)] += xs

    def out(self):
        return self.buf[: int(self.dur * SR)]


# ----------------------------------------------------------------- sounds
def zap(seed, dur=0.09, bright=1.0):
    """Electrical short: crackle impulses + band noise + a falling buzz."""
    rng = np.random.default_rng(seed)
    n = int(round(dur * SR))
    imp = np.zeros(n)
    for _ in range(int(14 * bright)):
        imp[rng.integers(0, n)] = rng.uniform(-1, 1)
    crack = bandpass(imp, 1500, 9000) * 6
    hiss = bandpass(rng.standard_normal(n), 2500, 8000) * exp_decay(n, dur * 0.3) * 0.5
    f = np.linspace(220 * (1 + 0.3 * rng.random()), 90, n)
    buzz = np.sign(osc(f, dur)) * 0.25 * exp_decay(n, dur * 0.4)
    buzz = lowpass(buzz, 2500)
    return (crack + hiss + buzz) * env_adsr(n, 0.001, 0.02, 0.5, dur * 0.5)


def hum(dur, f0, seed=1):
    """Building mains hum: harmonic stack with slow AM, f0 may be a glide array."""
    rng = np.random.default_rng(seed)
    out = 0
    for k, amp in [(1, 1.0), (2, 0.55), (3, 0.35), (4, 0.22), (5, 0.12), (6, 0.08)]:
        out = out + amp * osc(np.asarray(f0) * k, dur, phase=rng.uniform(0, 6.28))
    am = 1 + 0.08 * osc(0.7, dur) + 0.04 * osc(3.1, dur)
    return out * am / 2.3


def drone(dur, seed=2):
    """Low tense drone: detuned saws through a slow low-pass, plus sub and a dissonant tritone shimmer."""
    t = t_axis(dur)
    x = osc(55.0, dur, "saw") + osc(55.4, dur, "saw") + 0.6 * osc(82.4, dur, "saw") + 0.35 * osc(77.8, dur, "saw")
    x = lowpass(x, 380, 2) * 0.35 + 0.5 * osc(27.5, dur)
    sh = bandpass(noise(dur, seed, "pink"), 600, 1400) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.23 * t)) * 0.12
    return (x + sh) / 1.5


def crowd(dur, seed=3):
    """Distant crowd: many band-limited babble voices with syllable-rate envelopes."""
    rng = np.random.default_rng(seed)
    n = int(round(dur * SR))
    out = np.zeros(n)
    for v in range(14):
        f = rng.uniform(380, 1100)
        band = bandpass(rng.standard_normal(n), f * 0.7, f * 1.9)
        rate = rng.uniform(2.5, 5.5)
        syl = np.clip(np.sin(2 * np.pi * rate * t_axis(dur) + rng.uniform(0, 6)) + rng.uniform(-0.2, 0.4), 0, None)
        syl = lowpass(syl, 12)
        out += band * syl
    out = lowpass(out, 2200)
    return out / (np.abs(out).max() + 1e-9)


def whoosh(dur=0.7, seed=5):
    n = int(round(dur * SR))
    x = noise(dur, seed, "pink")
    # rising band sweep via short-time filtering in blocks
    out = np.zeros(n)
    blk = 1024
    for i in range(0, n, blk):
        u = i / n
        f = 300 + 3500 * u ** 2
        seg = bandpass(x[max(0, i - 2048):i + blk], f * 0.6, min(f * 1.6, 20000))[-(min(blk, n - i)):]
        out[i:i + len(seg)] = seg
    e = np.linspace(0, 1, n) ** 2.2
    return out * e / (np.abs(out * e).max() + 1e-9)


def hit(seed=6):
    n = int(0.6 * SR)
    f = np.linspace(85, 38, n)
    body = osc(f, 0.6) * exp_decay(n, 0.16)
    click = bandpass(noise(0.6, seed), 800, 5000) * exp_decay(n, 0.008)
    return body + click * 0.5


def tick(seed, freq=3200):
    n = int(0.05 * SR)
    imp = np.zeros(n)
    imp[0] = 1
    b, a = signal.iirpeak(freq, 6, fs=SR)
    x = signal.lfilter(b, a, imp) * 3
    x += bandpass(noise(0.05, seed), 1500, 7000) * exp_decay(n, 0.004) * 0.4
    return x * exp_decay(n, 0.012)


def swish(dur=0.22, seed=7):
    n = int(round(dur * SR))
    x = bandpass(noise(dur, seed, "pink"), 1800, 7000)
    e = np.sin(np.linspace(0, np.pi, n)) ** 2
    return x * e


def bell(freq, dur=0.9, seed=8):
    n = int(round(dur * SR))
    out = 0
    for k, (ratio, amp, tau) in enumerate([(1, 1.0, 0.45), (2.0, 0.35, 0.25), (3.01, 0.18, 0.15), (4.2, 0.08, 0.08)]):
        out = out + amp * osc(freq * ratio, dur) * exp_decay(n, tau)
    return out * env_adsr(n, 0.002, 0.01, 1.0, 0.05)


def thunk(seed=9):
    n = int(0.45 * SR)
    f = np.linspace(95, 32, n)
    body = osc(f, 0.45) * exp_decay(n, 0.09)
    click = lowpass(bandpass(noise(0.45, seed), 200, 2500) * exp_decay(n, 0.01), 1800)
    return body + click * 0.6


def soft_click(freq, seed):
    n = int(0.09 * SR)
    imp = np.zeros(n)
    imp[0] = 1
    b, a = signal.iirpeak(freq, 4, fs=SR)
    x = signal.lfilter(b, a, imp) * 2
    x = x + lowpass(noise(0.09, seed), 900) * exp_decay(n, 0.006) * 0.6
    return x * exp_decay(n, 0.03)


def room_tone(dur, seed=10):
    x = lowpass(noise(dur, seed, "brown"), 400) * 0.6 + lowpass(noise(dur, seed + 1, "pink"), 2500) * 0.08
    return x


def city_hum(dur, seed=11):
    t = t_axis(dur)
    rumble = lowpass(noise(dur, seed, "brown"), 160)
    traffic = bandpass(noise(dur, seed + 1, "pink"), 200, 900) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.11 * t + 1)) ** 2
    return rumble * 0.7 + traffic * 0.5


# --------------------------------------------------------------- narration
def edit_voice(path, cuts, xfade=0.012):
    """Remove silent spans [(a, b), ...] (seconds) with short equal-power crossfades. Returns stereo."""
    x, sr = sf.read(path, always_2d=True)
    assert sr == SR, sr
    out = []
    pos = 0
    nx = int(xfade * SR)
    for a, b in cuts:
        ia, ib = int(a * SR), int(b * SR)
        out.append(x[pos:ia])
        pos = ib
    out.append(x[pos:])
    y = out[0]
    for seg in out[1:]:
        fade = np.linspace(0, 1, nx)[:, None]
        tail = y[-nx:] * np.cos(fade * np.pi / 2) + seg[:nx] * np.sin(fade * np.pi / 2)
        y = np.concatenate([y[:-nx], tail, seg[nx:]])
    return y


def voice_chain(y):
    """Clean-up: high-pass, gentle de-mud, smooth RMS compression, then normalise."""
    m = y.mean(1)
    m = highpass(m, 85, 4)
    b, a = signal.iirpeak(300, 1.2, fs=SR)
    m = m - 0.25 * signal.lfilter(b, a, m)          # small dip in the boxy region
    # presence lift around 3.5 kHz
    b, a = signal.iirpeak(3500, 1.0, fs=SR)
    m = m + 0.18 * signal.lfilter(b, a, m)
    env = np.sqrt(np.maximum(lowpass(m ** 2, 12), 0) + 1e-12)
    thr = np.percentile(env[env > env.max() * 0.05], 60)
    gain = np.where(env > thr, (env / thr) ** (-(1 - 1 / 2.5)), 1.0)
    gain = lowpass(gain, 30)
    m = m * gain
    m = m / (np.abs(m).max() + 1e-9) * 0.7
    return m


def peaking_eq(x, f0, gain_db, q=0.8):
    """RBJ peaking biquad: +-gain_db around f0 (Hz), bandwidth set by q."""
    A_ = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * f0 / SR
    al = np.sin(w0) / (2 * q)
    b = np.array([1 + al * A_, -2 * np.cos(w0), 1 - al * A_])
    a = np.array([1 + al / A_, -2 * np.cos(w0), 1 - al / A_])
    return signal.lfilter(b / a[0], a / a[0], x)


def voice_chain_ep(y):
    """Narration chain for the full episode (pass 2): the whispery takes need to cut through.
    High-pass, small de-mud dip, a broad presence lift (+4.5 dB around 3.2 kHz, so soft consonants and
    first syllables read), a word leveller (soft syllables up to +10 dB), gentle 2.5:1 soft-knee compression with a fast-ish envelope (8 ms attack
    feel, 120 ms release), then normalise. Pitch and timing untouched."""
    m = y.mean(1) if y.ndim == 2 else y
    m = highpass(m, 85, 4)
    m = peaking_eq(m, 300, -2.5, 1.0)
    m = peaking_eq(m, 3200, 4.5, 0.7)
    m = peaking_eq(m, 7500, 1.5, 0.9)
    # word leveller: raise soft syllables (up to +10 dB) toward the line's typical speech level; only
    # where there is speech (the takes are clean TTS, so the gate never lifts noise)
    pw = lowpass(m ** 2, 16)
    lev = 10 * np.log10(np.maximum(pw, 1e-14))
    speech = lev > lev.max() - 48
    target = np.percentile(lev[speech], 60) - 2 if speech.any() else lev.max()
    up = np.clip(target - lev, 0, 10) * np.clip((lev - (lev.max() - 48)) / 6, 0, 1)
    up = lowpass(up, 20)
    m = m * 10 ** (up / 20)
    pw = lowpass(m ** 2, 40)
    lev = 10 * np.log10(np.maximum(pw, 1e-12))
    ref = np.percentile(lev[lev > lev.max() - 40], 50)
    thr, ratio, knee = ref - 4, 2.5, 8.0
    over = lev - thr
    gr = np.where(over <= -knee / 2, 0.0,
                  np.where(over >= knee / 2, over * (1 - 1 / ratio),
                           (1 - 1 / ratio) * (over + knee / 2) ** 2 / (2 * knee)))
    g_db = -gr
    # attack fast, release slower: follow drops in gain quickly, recover over ~120 ms
    a_rel = np.exp(-1 / (0.12 * SR))
    g = signal.lfilter([1 - a_rel], [1, -a_rel], g_db)
    g = np.minimum(g, lowpass(g_db, 60))
    m = m * 10 ** (g / 20)
    return m / (np.abs(m).max() + 1e-9) * 0.7


def presence_carve(x, env, gain_db=-6.0, lo=2000.0, hi=5000.0):
    """Dip x (mono or stereo) by gain_db in the lo-hi band while env (0..1, e.g. duck_envelope) is up:
    a zero-phase band split, so the rest of the spectrum and the transients are untouched."""
    from scipy.signal import butter, sosfiltfilt
    sos = butter(2, [lo, hi], btype="band", fs=SR, output="sos")
    band = sosfiltfilt(sos, x, axis=0)
    g = (1 - db(gain_db)) * env
    return x - band * (g[:, None] if x.ndim == 2 else g)


def duck_envelope(vo, floor_db=-50.0, full_db=-34.0, lookahead=0.08, hold=0.80, release=0.30, attack=0.03,
                  bridge=1.2):
    """0..1 ducking control from the narration: full duck for anything above full_db re the peak
    (so soft first syllables duck the bed as hard as stressed ones). Opens `lookahead` s BEFORE each
    word (reaching full depth `attack` s later), stays fully down through any pause shorter than `bridge`
    s (the gaps between and inside lines), holds `hold` s after the last word of a longer pause, then comes
    back up over `release` s (linear ramp): no pumping in the gaps. 1 kHz control rate. (fix round: was a
    0.10 s hold + 0.22 s exponential release, which let the music swell 6-10 dB inside every gap.)"""
    from scipy.ndimage import binary_closing, maximum_filter1d
    pw = lowpass(vo ** 2, 50)
    lev = 10 * np.log10(np.maximum(pw, 1e-14) / (np.abs(vo).max() ** 2 + 1e-12))
    u = np.clip((lev - floor_db) / (full_db - floor_db), 0, 1)
    u = u * u * (3 - 2 * u)
    n = len(u)
    k = SR // 1000                                         # 1 kHz control rate
    m = -(-n // k)
    uc = np.pad(u, (0, m * k - n)).reshape(m, k).max(1)
    cr = SR / k
    # bridge every pause shorter than `bridge` s at full depth (pad so the ends are not eroded)
    pad = int(bridge * cr) + 2
    sp = np.pad(uc > 0.35, pad)
    closed = binary_closing(sp, structure=np.ones(int(bridge * cr) + 1, bool))[pad:-pad]
    uc = np.maximum(uc, closed.astype(float))
    la, hd = int(lookahead * cr), int(hold * cr)
    # window covering [t - hold, t + lookahead]: opens early, holds after the words
    uc = maximum_filter1d(uc, size=la + hd + 1, origin=(hd - la) // 2)
    up, down = 1.0 / max(attack * cr, 1), 1.0 / max(release * cr, 1)
    e = np.empty_like(uc)
    cur = 0.0
    for i, x in enumerate(uc):
        cur = min(x, cur + up) if x > cur else max(x, cur - down)
        e[i] = cur
    env = np.interp(np.arange(n), np.arange(m) * k + (k - 1) / 2, e)
    return np.clip(env, 0, 1)


def vo_envelope(m, smooth=0.12):
    e = np.sqrt(np.maximum(lowpass(m ** 2, 1 / smooth), 0) + 1e-12)
    return np.clip(e / (np.percentile(e, 95) + 1e-9), 0, 1)


def measure_loudness(path):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(path), "-af", "ebur128=peak=true", "-f", "null", "-"],
                       capture_output=True, text=True)
    txt = r.stderr
    I = float(re.findall(r"I:\s+(-?[\d.]+) LUFS", txt)[-1])
    tp = float(re.findall(r"Peak:\s+(-?[\d.]+) dBFS", txt)[-1])
    return I, tp


def loudnorm(src, dst, target=-14.0, tp=-1.5):
    """Two-pass ffmpeg loudnorm in linear mode (no pumping)."""
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(src), "-af",
                        f"loudnorm=I={target}:TP={tp}:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True)
    js = json.loads(r.stderr[r.stderr.rindex("{"):r.stderr.rindex("}") + 1])
    af = (f"loudnorm=I={target}:TP={tp}:LRA=11:measured_I={js['input_i']}:measured_TP={js['input_tp']}:"
          f"measured_LRA={js['input_lra']}:measured_thresh={js['input_thresh']}:offset={js['target_offset']}:linear=true")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-af", af, "-ar", str(SR), "-c:a", "pcm_s24le", str(dst)],
                   check=True)


def limiter(x, ceiling_db=-1.6, release=0.08):
    """True-peak-aware brickwall limiter: 4x oversampled peak detection, instant attack with
    a 2 ms look-ahead, exponential release. x: (n, 2)."""
    up = signal.resample_poly(x, 4, 1, axis=0)
    pk = np.abs(up).max(1).reshape(-1, 4).max(1)[: len(x)]
    ceil = db(ceiling_db)
    need = np.minimum(1.0, ceil / np.maximum(pk, 1e-9))
    la = int(0.002 * SR)
    # look-ahead: min over a +-2 ms window so the gain is already down when the peak arrives
    from scipy.ndimage import minimum_filter1d
    need = minimum_filter1d(need, size=2 * la + 1, origin=0)
    g = np.empty_like(need)
    a = np.exp(-1 / (release * SR))
    cur = 1.0
    for i in range(len(need)):
        cur = need[i] if need[i] < cur else a * cur + (1 - a) * need[i]
        g[i] = cur
    return x * g[:, None]


# --------------------------------------------------------------- episode helpers
def load_mono(path):
    """Any wav as mono float64 at SR (resampled with a polyphase filter if needed)."""
    from math import gcd
    x, sr = sf.read(path, always_2d=True)
    m = x.mean(1)
    if sr != SR:
        g = gcd(SR, sr)
        m = signal.resample_poly(m, SR // g, sr // g)
    return m


def music_bed(dur, cut_times=(), seed=21):
    """Continuous low music bed for a whole episode: a slow minor pad (detuned saws through a soft
    low-pass) whose chord moves at each cut, plus a sub pulse. Quiet by design; sits under everything."""
    roots = [55.0, 43.65, 65.41, 49.0, 58.27, 41.2]         # A1 F1 C2 G1 Bb1 E1 (Aeolian-ish walk)
    thirds = [1.189, 1.26, 1.189, 1.26, 1.26, 1.189]         # minor / major third over each root
    n = int(round(dur * SR))
    t = np.arange(n) / SR
    edges = [0.0] + [c for c in cut_times if 0 < c < dur] + [dur]
    f_root = np.zeros(n)
    f_third = np.zeros(n)
    for k, (a, b) in enumerate(zip(edges[:-1], edges[1:])):
        i0, i1 = int(a * SR), int(b * SR)
        f_root[i0:i1] = roots[k % len(roots)]
        f_third[i0:i1] = roots[k % len(roots)] * thirds[k % len(thirds)]
    # glide 120 ms between chords
    sm = int(0.12 * SR)
    kern = np.ones(sm) / sm
    f_root = np.convolve(f_root, kern, mode="same")
    f_third = np.convolve(f_third, kern, mode="same")
    f_root[: sm] = f_root[sm]
    f_third[: sm] = f_third[sm]
    f_root[-sm:] = f_root[-sm - 1]
    f_third[-sm:] = f_third[-sm - 1]

    def saw(freq, detune):
        ph = np.cumsum(freq * detune / SR)
        return 2 * (ph % 1.0) - 1

    pad = (saw(f_root, 1.0) + saw(f_root, 1.004) + 0.7 * saw(f_root * 1.5, 0.997)
           + 0.55 * saw(f_third * 2, 1.002) + 0.4 * saw(f_root * 2, 0.995))
    lfo = 0.5 + 0.5 * np.sin(2 * np.pi * 0.07 * t)
    pad = lowpass(pad, 420, 2) * (0.75 + 0.25 * lfo)
    sub = np.sin(2 * np.pi * np.cumsum(f_root / 2) / SR) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.5 * t) ** 2)
    air = bandpass(noise(dur, seed, "pink"), 900, 2600) * 0.05 * lfo
    out = pad * 0.30 + sub * 0.45 + air
    fade = np.clip(t / 1.5, 0, 1) * np.clip((dur - t) / 1.2, 0, 1)
    return out * fade / (np.abs(out).max() + 1e-9)
