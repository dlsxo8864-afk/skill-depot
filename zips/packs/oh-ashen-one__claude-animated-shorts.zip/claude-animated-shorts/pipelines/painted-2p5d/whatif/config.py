"""Project-wide constants and paths for the What-If shorts renderer."""
from pathlib import Path

EP_ROOT = Path(__file__).resolve().parents[2]          # .../ep03-dany-and-jon
ASSETS = EP_ROOT / "assets"
WORK = EP_ROOT / "work"
OUT = EP_ROOT / "out"
FONTS = WORK / "fonts"
LAYER_CACHE = WORK / "layers"

FPS = 24
OUT_W, OUT_H = 1080, 1920
# Working resolution for plates (key art 1520x2688 scaled by 0.8). Plates are
# pre-reduced with INTER_AREA so the per-frame camera warp never minifies hard.
WORK_SCALE = 0.8

# Vertical-video safe area (fractions of the frame)
SAFE_LEFT, SAFE_TOP = 0.06, 0.06
SAFE_RIGHT, SAFE_BOTTOM = 0.14, 0.22


def safe_box():
    """Pixel box (x0, y0, x1, y1) inside which on-screen text must stay."""
    return (round(OUT_W * SAFE_LEFT), round(OUT_H * SAFE_TOP),
            round(OUT_W * (1 - SAFE_RIGHT)), round(OUT_H * (1 - SAFE_BOTTOM)))


FONT_FILES = {
    "display": "anton_Anton-Regular.ttf",                 # SIL OFL 1.1
    "sans": "inter_Inter[opsz,wght].ttf",                 # SIL OFL 1.1 (variable)
    "marker": "permanentmarker_PermanentMarker-Regular.ttf",  # Apache 2.0
}
