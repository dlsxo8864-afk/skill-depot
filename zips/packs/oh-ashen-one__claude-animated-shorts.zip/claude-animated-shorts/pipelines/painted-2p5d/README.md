# What If shorts renderer (ep03, "What if Daenerys never burned King's Landing?")

CPU-only pipeline copied from episode 1 (`ep01-data-centers/src/`): painted key images + narration become an
animated, sound-designed vertical short (1080x1920, 24 fps). No GPU, no engines, no paid or generative services.
Unofficial fan content: original character designs, no HBO footage, music, logos or title type.

## Run

From `ep03-dany-and-jon/` (Python 3.12 via uv; dependencies in `src/requirements.txt`):

```sh
R="uv run --python 3.12 --with-requirements src/requirements.txt python"
$R src/ep03.py --timeline                       # 13 shots timed from the Nicole narration (word times cached)
$R src/ep03.py --words                          # every line's words with global times and frames
$R src/ep03.py --shot s01_hook --preview        # one shot -> work/shots/s01_hook/ (video, stems, preview.mp4)
$R src/ep03.py --shot s01_hook --frames 12 30   # stills -> work/shots/s01_hook/stills/
$R src/ep03.py --assemble --name rough          # rendered shots + narration + music -> out/ep03_rough_vN.mp4
```

`--assemble` works with any subset of shots: missing or stale shots are skipped and listed. Add `--workers 6`
to renders when other builders are rendering.

Inputs: keys `assets/key/<g..>_key.png` (941x1672; upscaled to 1520 px wide in `work/keys/`, the camera fits
them to 1080x1920 by scale and crop, never a stretch), pose B paintings `assets/key/<g..>_poseB.png`, narration
`assets/voice/nicole/NN_*.wav` + `lines.json`. Word times: faster-whisper small on CPU, aligned to the script,
cached in `work/voice/nicole_words.json` (delete it after re-recording a line). Episode constants in
`timeline.py`: `GAP` 0.40 s between lines, `END_HOLD` 2.25 s after the CTA, the hook's take starts at 0
(first word at 0.21 s). One-time caches copied from episode 1: `work/fonts/` (OFL/Apache fonts) and
`work/models/da2s/` (Depth Anything V2 Small ONNX, Apache 2.0); `src/tools/fetch_fonts.py` re-fetches the fonts.

New shots: `ADDING_A_SHOT.md`. Shot list: `../SHOTS.md`.

## Layout

| Path | Role |
| --- | --- |
| `whatif/config.py` | fps, output size, working scale, safe area, font files |
| `whatif/timing.py` | frame helpers, on-2s time, easing, keyframe `Track` |
| `whatif/layers.py` | depth-band plane split, guided-filter mattes, push-pull + brush-texture fill behind occluders, sprites (rigid parts with an anchor ramp); `.npy` cache |
| `whatif/camera.py` | `ParallaxCamera` (per-pixel depth parallax inside each plane, 1s camera), `deform_sprite`, plane compositing |
| `whatif/fx2d.py` | drawn FX: tapered streaks, 4-point flashes, bolts, spark bursts, embers, painted haze |
| `whatif/text.py` | fonts, hand-lettering painted onto surfaces in perspective, styled on-screen type, pop animation |
| `whatif/overlays.py` | series overlays: `year_tag(n)` for years 1-10, `data_tag(text)`, card shadows; 30 px minimum cap height and the safe-area clamp |
| `whatif/ui_phone.py` | generic painted short-video feed (player chrome: caption, views, time, progress, page dots; no side icon rail, no account handle) + system notification card (no real app branding) |
| `whatif/style.py` | final pass: colour grade (purple to teal ambient or warm key light, purple kept in the deepest shadows), bloom, coloured shadow lift, vignette, canvas tooth, grain on 2s |
| `grades.py` | per-shot grade settings (protected light hues, strength) |
| `whatif/poses.py` | pose A / pose B hero swap on 2s from a second painting (`PoseSwap`); see ADDING_A_SHOT.md |
| `whatif/audio.py` | synth primitives (drone, hum, zaps, crowd, whoosh, ticks, chimes, thunk, clicks), narration edit/clean-up, limiter, loudness |
| `shots/sNN_*.py` | per-shot animation: camera tracks, poses, lighting events, overlays, `events()` for sound and sync |
| `timeline.py` | episode shot table, narration analysis (word times, speech bounds), shot frame ranges |
| `ep03.py` | per-shot render (`--shot`), stills (`--frames`), previews, `--words`, `--assemble [--name]` (concat, full mix, master, contact sheet) |
| `whatif/shotkit.py` | the shot contract: `ShotContext`, `BaseShot`, `ShotSound` |
| `whatif/keyprep.py` | key upscaling (Lanczos-3 to 1520 px) and CPU depth, cached in work/keys/ |
| `whatif/screens.py` | screen detection/placement in perspective, screen-light relighting |
| `whatif/transitions.py` | drawn cut marks in the shot's key colour: dry-brush wipe, ink bloom, brush slashes |
| `tools/` | transcription, depth, layer inspection, test frames, font fetch |

## Models and fonts (all CPU, open licences)
- Transcription: faster-whisper `small`, int8, CPU (MIT).
- Depth: Depth Anything V2 Small, ONNX `onnx-community/depth-anything-v2-small`, ONNX Runtime CPU (Apache 2.0).
- Fonts: Anton (OFL 1.1), Inter (OFL 1.1), Permanent Marker (Apache 2.0), in `work/fonts/`.
