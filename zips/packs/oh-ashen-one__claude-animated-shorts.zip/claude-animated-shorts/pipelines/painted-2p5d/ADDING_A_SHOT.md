# Adding a shot to Episode 3

"What if Daenerys never burned King's Landing?" is 13 shots in `src/timeline.py` (stems `s01_hook` to `s13_cta`). Each has a key painting in `assets/key/`, one narration line in `assets/voice/nicole/` and a 0.40 s gap after it (the CTA holds 2.25 s after its last word). The renderer derives every frame range from the narration, so you never type times by hand. You write one module, `src/shots/<stem>.py`. The renderer does the rest: style pass, cut, narration, music, mix.

Your shot's spec (key, sync words, overlays, pose B) is its row in `../SHOTS.md`. The look is `../prompts/_style.txt`. Finished examples: `src/shots/s01_hook.py` and `src/shots/s02_year1.py`. The fuller generic template is `src/shots/_template.py`.

## Commands

Run everything from `ep03-dany-and-jon/`:

```sh
R="uv run --python 3.12 --with-requirements src/requirements.txt python"
$R src/ep03.py --timeline                          # shot table: frames, seconds, what is missing
$R src/ep03.py --words                             # every line's words: global start/end s, frame, heard/interpolated
$R src/ep03.py --shot s05_year4 --frames 470 520   # stills only -> work/shots/s05_year4/stills/ (full + 360x640)
$R src/ep03.py --shot s05_year4 --preview --workers 6   # video.mp4 + bed/sfx stems + meta.json + preview.mp4
$R src/ep03.py --assemble --name rough             # every rendered shot -> out/ep03_rough_vN.mp4 + _sheet.png
```

`--assemble` joins whatever shots are rendered and current, skips the rest and prints which are missing (and why: no module, not rendered, stale frame range, still rendering). It copies each shot's files to `work/full/snap/` first, so a builder re-rendering at the same moment cannot corrupt the cut. Frame numbers are always GLOBAL (frame 0 = first frame of the episode).

## Rules

1. Create only `src/shots/<stem>.py` (optionally `<stem>_spec.py`) and the caches made for you in `work/layers/<stem>/` and `work/shots/<stem>/`. `work/keys/` is shared (upscaled keys and depth maps, made on first use).
2. Read-only for shot builders: `src/whatif/`, `src/timeline.py`, `src/ep03.py`, `src/grades.py`, other shots, `assets/`. Need a helper, a different gap or a main-event name in `timeline.MAIN_EVENT`? Ask the integration builder. A private helper inside your module is fine.
3. CPU only, headless, no audio playback, no GUI. `--workers 6` or fewer when others render (32 cores).
4. One lore tag per shot (`self.draw_data_tag`), shown while its fact is spoken. Invented figures get `overlays.scenario_label()`. No HBO logos, title type or real brand marks: names appear as plain text only.
5. Time box: get a crude version rendering end to end first (`--shot <stem>` must finish), then improve. Never spend more than 20 minutes on one detail; note it and move on.

## Steps

1. `$R src/ep03.py --timeline`: find your stem, check the key exists. `$R src/ep03.py --words`: note your sync words' frames.
2. Copy `src/shots/s02_year1.py` (or `_template.py`) to `src/shots/<stem>.py`.
3. Run `--frames <one frame>` once: this upscales the key to 1520 px wide (`work/keys/<key>.png`), computes depth (`<key>_depth.png`, white = near) and builds your layer cache.
4. Measure in key px: open `work/keys/<key>.png` (1520 x 2701). All spec coordinates (planes' `region`, sprite envelopes, pivots, pose regions) are px of that upscaled image; the work plates are 0.8x (`config.WORK_SCALE`), so multiply by 0.8 when you draw into a plane or sprite patch yourself.
5. Choose depth bands from the depth map. Typical: sky 0-0.14 `fill="full"`, a mid band, a hero band, a near crowd band. Use `region=` polygons to split two subjects that share a depth (s01 splits the dragon from the crowd that way). After any spec change delete `work/layers/<stem>/`.
6. Write the animation:
   - **Sync.** `ctx.f("word")` is the frame of the word's start on the 2s grid; `ctx.f("word", at="e")` its end; `ctx.f("word", n=1)` the second occurrence; `even=False` for camera/cut timing. Punctuation is ignored ("blink." == "blink"), spelling is the script's (`lines.json`). Words the transcriber did not hear are interpolated (`--words` marks them); words it spelled differently ("Mary's John" for "marries Jon") keep its times one to one ("heard~").
   - **Motion.** Camera on 1s (`ctx.local(f)`, `Track`s spanning `ctx.dur`); characters, sprites and effects on 2s (`on2s(f - self.f0)` or `f - f % 2`).
   - **Overlays.** `self.draw_year_tag(img, f)` (YEAR n top-left, pops 2 frames after the cut), `self.draw_data_tag(img, f, text, f_in, f_out=None)` (lore tag under it), `O.draw_pop`, `O.counter_rgba` + `O.roll_value`, `O.scenario_label()`, `O.fan_tag()`. Composite with `O.seat`/`O.draw_pop`, never `text.over`.
   - **Sound.** In `sound(snd)`: `snd.bed(x, t, db)` for ambience (ducked under the voice), `snd.sfx(x, snd.at_frame(f), db, pan)` for effects on event frames. Synth sounds are in `whatif/audio.py`.
   - **Events.** Return `[(frame, kind, {}), ...]` from `events()`; they print as a sync table after a render.
7. Check stills with `--frames`, then look at the 360x640 copies for phone legibility.
8. Render with `--shot <stem> --preview --workers 6` and watch/inspect `work/shots/<stem>/preview.mp4` (frames via ffmpeg; no playback on this machine).

## Text size and safe area (enforced)

- All text stays inside the safe area: x 65 to 929, y 115 to 1498 output px (`config.safe_box()`: 6 % from left/top, 14 % from the right, 22 % from the bottom). `draw_pop` and `O.safe_clamp` push a patch back inside.
- Cap height >= 30 px at 1080 wide for every tag, label and caption (`text.MIN_CAP`); `_text_alpha`, `data_tag`, `scenario_label` and `fan_tag` enlarge a smaller font automatically. Data tags use 33 px caps and wrap to two lines. Big title type (hook, CTA) is built with `T.font("display", size)` + `T.styled_text_rgba`, see `s01_hook.Shot.title`.
- The top 15 % of each key is kept calm for the year tag; the data tag sits under it. If your key has the subject there, move the tag with `xy=` (inside the safe area).

## Pose B: pose-to-pose on 2s

`assets/key/<key stem>_poseB.png` exists for hook, wedding, north, dothraki, ironbank, bran, cradle, essos, catch and cta (`g08_essos_arm.png` is an extra arm painting for s09). It is loaded in your `__init__`:

```python
from whatif.poses import PoseSwap
self.pose = PoseSwap.for_shot(ctx, STEM, region=HERO)     # None when no pose B exists; HERO in key px
self.swaps = [(ctx.f("blink"), "B")]                      # (frame, pose); hold each pose >= 8 frames
# in frame(f), for each plane that holds part of the hero, after compositing that plane's sprites:
st = PoseSwap.state(f, self.swaps) if self.pose else "A"
n = self.pose.nearness(n, a, st)                         # use the ORIGINAL plane alpha
rgb, a = self.pose.apply(rgb, a, st)
```

Before each switch it shows an anticipation drawing and one in-between (2 frames each), then the new pose holds. Lessons from s01 and s02 (check with `self.pose.debug_sheet(path)` and `self.pose.info`, which reports `thresh` and `mask_frac`):

- **Empty mask.** The ep3 pose B paintings are re-generated whole, so everything differs a little and the automatic threshold can come out too high: s02's lord had `mask_frac` 0.0 at the automatic 22. Pass `thresh=` (s02 uses 14) and confirm `mask_frac` > 0.
- **Ghost outlines of pose A.** If the hero's change spans a whole area (s01: the dragon's wings move across the sky), thin dark lines trace pose A's silhouette along the mask edge. Pass `whole_region=True` to `nearness` and `apply` on every plane inside the region (sky included); draw the region along edges that hide a seam (s01 follows the bell tower's roof).
- **Region.** Always give `region` around both poses with a margin; everything outside it stays pose A's pixels.
- Sprites cut from the key belong to pose A: do not pose them while B shows.

## Hidden or moving cloth, props and holes

Anything you move or hide reveals what the plane fill painted behind it, and the generated keys have nothing real there. s02 first rolled its banner up and left a grey ghost pennant; the shipped version ripples the cloth instead (row-wise `cv2.remap` of the sprite patch on 2s) and refills the sky behind its edge from sky-coloured pixels only (`s02_year1.Shot.planes`). Prefer deforming a prop over hiding it; set `fill_own_plane=False` when the plane behind the prop is a different (farther) plane.

## Library gaps found, not fixed

- `PoseSwap` automatic threshold fails on whole-repainted pose B images (see above); there is no `whole_region` default per shot, each plane must pass it.
- `ShotSound` has no reverb or distance filter; bells and roars are dry synth.
- No drawn particle helper for falling things (petals, snow, ash fall): `fx2d.Embers` only rises and is emissive. Write a private one or ask.
- No sigil/heraldry or map drawing helpers; s02 draws its sigil from PIL polygons (`sigil_alpha`).
- `overlays.year_tag` and `data_tag` are positioned for an empty top-left; nothing checks overlap with the painting's subject.
- `transitions.cut_frame` picks the cut device by shot index; there is no per-shot override other than `transition = False`.
- The legacy `tools/` (`transcribe.py`, `vo_retime.py`, `depth.py`) are episode 1 utilities; `ep03.py` covers what a shot builder needs.

## What the renderer does for every shot

- **Grade.** Before bloom, `style.grade` moves the generator's violet wash (hue 222 to 355) toward a muted slate-blue ambient on darker surfaces and a warm key on lit surfaces. Skin-coloured midtones get the warm key whether or not they are lit. A pixel whose new hue would land in olive or green is pulled back toward grey, so nothing turns olive. Saturated emissive lights are left alone. `style.finish` then sets the darkest 2 % of pixels to about 0.045 luminance (`style.BLACK_POINT`) with a toe that leaves midtones alone. Per-shot settings live in `src/grades.py` (integration-owned). Episode 3 runs every shot at `strength` 0.5: at 0.9 (episode 1's value) the lavender skies of the ep3 keys turned beige. To tune your own shot without editing that file, give the shot class `grade = {"strength": 0.8, "protect": ((325.0, 22.0),)}` (merged over the table; `protect` = (hue in degrees, half-width) of light colours to keep) or `grade = False` to opt out.
- **Style pass.** It applies `style.finish` with the grade, bloom, coloured shadow lift, vignette, canvas and grain on 2s. Your `finish_args(f, info)` can change bloom and vignette.
- **Cut.** After the style pass the renderer treats the last two frames with one of three devices, chosen by shot index (`transitions.DEVICES`): a painted smear (thick flat strokes in the shot's key colour with hard dry-brush edges, no streak blur; frame −2 partly covered, frame −1 nearly fully), a hard cut (frames untouched, so land your impact on the last frame), or a colour match (the last two frames relit toward the next shot's key colour). Set `flash_color = (r, g, b)` to choose the smear colour, or `transition = False` to turn it off.
- **Voice.** At assembly the narration gets a presence lift, a word leveller and gentle compression. The beds and music duck under every word (opening 80 ms early), and beds, music and effects lose a further 6 dB or more in the 2 to 5 kHz band while a word is spoken. Keep beds steady; don't duck them yourself.
- **Cut sound.** A whoosh leads into the cut and a hit lands on it.
- **Year tag sound.** A tick plays when the year tag lands at `f0 + 2`.
- **Mix.** The narration line is placed, a continuous music bed runs underneath, and the voice ducks beds and music. The episode is mastered to −14 LUFS with true peak at or below −1 dBTP.

## Shared helpers (`src/whatif/`, read-only)

| Module | Function | Purpose |
|---|---|---|
| `shotkit` | `ShotContext` | `f0`, `f1`, `dur`, `year`, `words`, `word(w, n)`, `t(w)`, `f(w, even=True)`, `local(f)`, `key_paths()` |
| `shotkit` | `BaseShot` | `draw_year_tag(img, f)` and `draw_data_tag(img, f, text, f_in, f_out)` in the standard slots |
| `shotkit` | `ShotSound` | `bed(x, t, db, pan)`, `sfx(x, t, db, pan)`, `at_frame(f)`, `shot_span()` |
| `keyprep` | `prepare_key(path)` | Upscale to 1520 px (Lanczos-3) plus CPU depth, cached in `work/keys/` |
| `keyprep` | `load_rgb(path, width)` | Load a key as float RGB |
| `layers` | `PlaneSpec`, `SpriteSpec` | Depth bands and rigid sprites |
| `layers` | `build(...)`, `Layers(stem)` | Plane and sprite cache (compressed `.npz`) |
| `layers` | `poly_mask`, `textured_fill`, `push_pull_fill`, `brush_noise` | Masks, painted hole fill, stroke noise |
| `camera` | `ParallaxCamera(...)` | Per-pixel depth parallax. Methods: `render(planes, t)`, `screen_point(p, n, t)`, `scale_at(n, t)` |
| `camera` | `deform_sprite(s, angle_deg, dx, dy, scale)` | Pose a sprite about its pivot; its anchored end stays put |
| `camera` | `composite_into(rgb, a, rgba, x0, y0)` | Place a posed sprite into a plane |
| `screens` | `ScreenQuad.detect(plate, test)` | Find a blank screen by colour |
| `screens` | `ScreenQuad.from_points(quad, shape, scale=WORK_SCALE, plate_rgb=)` | Screen from four hand-measured corners |
| `screens` | `.place(rgb, a, canvas)`, `.warp(canvas)`, `.point(u, v)` | Put an interface on a screen in perspective; find a point on it |
| `screens` | `dead_glass(cw, ch)` | A switched-off screen |
| `screens` | `screen_light(canvas)` | Colour the screen throws |
| `screens` | `light_weight(rgb, hue)` | How much of a surface is lit by the screen |
| `screens` | `unlit(rgb)`, `unlit_plate(rgb, w)` | The surface with the screen light removed |
| `screens` | `light_ratio(c, c0)`, `relight(rgb, unlit, ratio)` | Relight the scene from what the screen shows |
| `overlays` | `year_tag(n)`, `data_tag(text, size)` | Series tags (RGBA) |
| `overlays` | `tag_slots()` | Standard positions for the tags |
| `overlays` | `scenario_label()` | Chip for invented figures |
| `overlays` | `fan_tag()` | Episode 3: the "Unofficial fan fiction" chip (hook and CTA) |
| `overlays` | `counter_rgba(value, fmt, size)` | Odometer-style rolling price or number |
| `overlays` | `roll_value(f, fa, fb, v0, v1)` | Eased counter value on 2s |
| `overlays` | `draw_pop(img, rgba, x, y, f, f_in, f_out, glow=)` | Pop in and out on 2s, seated in the scene, clamped to the safe area |
| `overlays` | `safe_clamp(rgba, x, y)` | Position that keeps a patch inside the safe area |
| `overlays` | `seat(img, rgba, x, y, glow=)` | Composite any overlay into the painting (scene light, light wrap, soft edge) |
| `overlays` | `painted_swatch(w, h, seed)` | Dry-brushed colour band |
| `overlays` | `card_with_shadow(rgba, underlight=)` | Card with shadow and painted body |
| `text` | `font(kind, size)`, `sans(size, weight)`, `wrap`, `MIN_CAP`, `at_least_cap(fnt)`, `cap_height(fnt)` | Fonts, line wrapping and the 30 px minimum cap height |
| `text` | `styled_text_rgba(alpha, color)` | Type with tooth, shadow and gradient |
| `text` | `lettering(lines, size, w, h)` | Hand lettering |
| `text` | `warp_to_quad`, `paint_on_surface` | Painted signs in perspective |
| `text` | `over`, `transform_rgba`, `pop_scale` | Compositing and pop scale |
| `ui_phone` | `feed_canvas(pos, smear)` | Generic painted vertical feed |
| `ui_phone` | `notification_rgba(width, scale)` | The limit notification card |
| `ui_phone` | `CW`, `CH` | Phone canvas size |
| `fx2d` | `ShapeCanvas` | Anti-aliased shapes with core plus glow |
| `fx2d` | `tapered_streak_poly`, `star4_poly`, `bolt_points` | Drawn FX shapes |
| `fx2d` | `spark_burst`, `Embers`, `painted_haze`, `screen_emissive` | Ready-made FX |
| `transitions` | `cut_frame`, `wipe`, `match`, `smear`, `paint_color`, `key_color` | Cut devices (painted smear, hard cut, colour match); applied for you, usable inside a shot too |
| `poses` | `PoseSwap.for_shot(ctx, stem, region)`, `.state(f, swaps)`, `.apply(rgb, a, state)`, `.debug_sheet(path)` | Pose A / pose B hero swap: anticipation, in-between, hero-only mask |
| `timing` | `Track`, `on2s`, `even_frame_of`, `frame_of`, `smoothstep`, eases | Timing |
| `audio` | Primitives | `osc`, `noise`, `bandpass`, `lowpass`, `highpass`, `env_adsr`, `exp_decay`, `t_axis`, `db` |
| `audio` | Sounds | `zap`, `hum`, `drone`, `crowd`, `whoosh`, `hit`, `tick`, `swish`, `bell`, `thunk`, `soft_click`, `room_tone`, `city_hum` |
| `style` | `finish(...)`, `grade(img, params)` | The final pass and its colour grade; the renderer applies them (per-shot settings in `src/grades.py`) |
| `config` | Constants | `FPS`, `OUT_W`, `OUT_H`, `WORK_SCALE`, `safe_box()` |
