"""Shot 11, Year 10: "By year ten, with no heir, Jon and Daenerys call a Great Council to choose who rules next."

The lords' hands go up in waves on 2s from "choose": eleven raised arms (sprites cut from the key, pivoting at the
shoulder with an anchor ramp) start half lowered and rise row by row, far rows first, with an overshoot. On "next"
a spotlight falls on the empty chair (an additive cone of warm light from above, 40 % at most, soft edges and a
little haze; the chair's highlights are clamped so it never blows out)
while the camera pushes toward the chair. YEAR 10; lore tag "Great Council of 233 AC: the last time the lords
chose a king" from "Great Council" (233 AC chose Aegon V; 101 AC only chose an heir).
Coordinates are px of the upscaled key work/keys/g10_council_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import WORK_SCALE
from whatif.shotkit import BaseShot
from whatif.timing import Track

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("sky", 0.00, 0.12, fill="full"),
    L.PlaneSpec("ruins", 0.12, 0.30, radius=60),
    L.PlaneSpec("stands", 0.30, 0.55, radius=60),
    L.PlaneSpec("couple", 0.55, 1.01, radius=70),
]
CHAIR = (1118, 1170)                   # the empty chair (seat), key px


def _arm(name, hand, shoulder, w, wave, sign, plane, dmin=0.0):
    """Sprite around a raised forearm from hand (top) to shoulder; pivots at the shoulder, which stays put.
    plane = the plane its depth falls in (top rows sit in the far band, the left rows in the ruins band)."""
    (hx, hy), (sx, sy) = hand, shoulder
    env = [(hx - w * 0.5, hy - 22), (hx + w * 0.5, hy - 22), (sx + w * 0.5, sy + 10), (sx - w * 0.5, sy + 10)]
    spec = L.SpriteSpec(name, plane, env, dmin=dmin, pivot=shoulder, anchor=(hx, hy, sx, sy), fill_own_plane=True)
    return spec, wave, sign


ARMS = [
    # far rows (wave 0); depth ~0.09, sky band
    _arm("a_top1", (618, 610), (609, 720), 48, 0, -1, 0),
    _arm("a_top2", (1073, 740), (1073, 840), 48, 0, 1, 0),
    _arm("a_top3", (1391, 750), (1382, 855), 48, 0, 1, 0),
    _arm("a_top4", (427, 750), (418, 860), 48, 0, -1, 0),
    # left stands, middle rows (wave 1); depth ~0.21, ruins band
    _arm("a_mid1", (155, 790), (145, 910), 50, 1, -1, 1),
    _arm("a_mid2", (182, 1020), (173, 1148), 52, 1, -1, 1),
    _arm("a_mid3", (318, 1058), (291, 1185), 54, 1, -1, 1),
    _arm("a_mid4", (382, 1200), (364, 1350), 58, 1, 1, 1),
    # front lords (wave 2); arms ~0.38 against the floor ~0.26: the depth cut keeps the floor out
    _arm("a_fr1", (770, 1440), (722, 1660), 110, 2, -1, 2, 0.32),
    _arm("a_fr2", (1135, 1495), (1073, 1712), 115, 2, 1, 2, 0.32),
    _arm("a_fr3", (1455, 1515), (1436, 1712), 105, 2, 1, 2, 0.32),
]
SPRITES = [a[0] for a in ARMS]
LOWERED = 42.0                         # degrees the arms start lowered by


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_great = ctx.f("Great")
        self.f_choose = ctx.f("choose")
        self.f_next = ctx.f("next.")
        self.wave_f = [self.f_choose + 4 * k for k in range(3)]
        tn = ctx.local(ctx.f("next.", even=False))
        cx, cy = CHAIR[0] * WORK_SCALE, CHAIR[1] * WORK_SCALE
        self.cam = ParallaxCamera(
            W, H, focus=Track([(0, (W * 0.50, H * 0.52)), (tn - 0.2, (W * 0.56, H * 0.49), "inout"),
                               (d, (0.4 * W * 0.5 + 0.6 * cx, 0.4 * H * 0.52 + 0.6 * cy), "inout")]),
            nearness=nearness,
            zoom=Track([(0, 1.0), (tn - 0.2, 1.05, "inout"), (d, 1.16, "inout")]),
            push=Track([(0, 0.0), (d, 0.07, "inout")]),
            rise=Track([(0, 0.0), (d, 18.0, "inout")]),
            pan=Track([(0, 0.0), (d, -16.0, "inout")]))

    @cached_property
    def planes(self):
        """The cached planes, cleaned where the arms were cut: every plane at or behind an arm gets the arm's
        rest silhouette (grown a little) repainted from its own surrounding pixels, so no soft-edged
        remnant of a raised hand survives while the arm is lowered; the front lords' own plane also drops
        its hand and forearm area, so the arena floor behind shows there instead of a smeared dark fill."""
        pls = [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]
        H, W = self.lay.H, self.lay.W
        grow = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))
        holes = [np.zeros((H, W), np.float32) for _ in pls]
        cut = np.zeros((H, W), np.float32)
        for s, (spec, wave, sign) in zip(self.lay.sprites, ARMS):
            x0, y0, x1, y1 = s["bbox"]
            m = np.zeros((H, W), np.float32)
            m[y0:y1, x0:x1] = (s["rgba"][..., 3] > 6).astype(np.float32)
            m = cv2.dilate(m, grow)
            for i in range(spec.plane + 1):
                holes[i] = np.maximum(holes[i], m)
            if wave == 2:                                   # front lords: hand + forearm (free end) only
                hx, hy, sx, sy = [v * WORK_SCALE for v in spec.anchor]
                gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
                dv = np.float32([sx - hx, sy - hy])
                u = ((gx - hx) * dv[0] + (gy - hy) * dv[1]) / float(dv @ dv)
                cut = np.maximum(cut, m * np.clip((0.72 - u) / 0.12, 0, 1))
        for i, pl in enumerate(pls):
            hole = holes[i]
            if not hole.any():
                continue
            valid = ((pl["a"] > 0.9) & (hole < 0.5)).astype(np.float32)
            fill = L.textured_fill(pl["rgb"], valid, seed=140 + i)
            k = cv2.GaussianBlur(hole, (0, 0), 2.0)[..., None]
            pl["rgb"] = (pl["rgb"] * (1 - k) + fill * k).astype(np.float32)
            if i == 2:
                pl["a"] = (pl["a"] * (1 - cv2.GaussianBlur(cut, (0, 0), 2.5))).astype(np.float32)
        # the floor behind the front lords' cut hands: the plane builder left pale hand silhouettes with dark
        # rims there (ghost hands while the arms are down). Repaint that zone with the real floor from
        # above it (shifted copy, twice, so the source is always clean painted floor), fully opaque.
        zone = cv2.dilate((cut > 0.02).astype(np.float32),
                          cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41)))
        zone = cv2.GaussianBlur(zone, (0, 0), 6.0)
        p1 = pls[1]
        # low frequencies (the light) come from the floor around the zone, only the brush texture is copied
        out_w = cv2.GaussianBlur(1 - zone, (0, 0), 28)[..., None] + 1e-4
        lo_t = cv2.GaussianBlur(p1["rgb"] * (1 - zone[..., None]), (0, 0), 28) / out_w
        for _ in range(2):
            src = np.roll(p1["rgb"], 150, axis=0)
            src = src - cv2.GaussianBlur(src, (0, 0), 28) + lo_t
            p1["rgb"] = (p1["rgb"] * (1 - zone[..., None]) + src * zone[..., None]).astype(np.float32)
        p1["a"] = np.maximum(p1["a"], zone).astype(np.float32)
        return pls

    def arm_angle(self, wave, sign, f):
        """Lowered until its wave, then up on 2s with an overshoot and a settle."""
        dd = (f - f % 2) - self.wave_f[wave]
        k = {-2: 1.04, 0: 0.62, 2: 0.18, 4: -0.10, 6: 0.04}.get(dd, 1.0 if dd < -2 else 0.0)
        return sign * LOWERED * k

    # ---------------------------------------------------------------- spotlight
    def _spot(self, img, f, t):
        """A cone of warm light from above onto the chair, added on top (screen blend, 40 % at most), soft
        edged with a little drifting haze, then a highlight shoulder inside the beam so the gilded chair
        keeps its painted detail instead of blowing out."""
        fh = f - f % 2
        dd = fh - self.f_next
        if dd < 0:
            return img
        k = {0: 0.40, 2: 0.78}.get(dd, 1.0) * (1 + 0.02 * math.sin(fh * 1.9))
        H, W = img.shape[:2]
        c = self.cam.screen_point((CHAIR[0] * WORK_SCALE, CHAIR[1] * WORK_SCALE), 0.35, t)
        s = self.cam.scale_at(0.35, t) * WORK_SCALE
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        fx, fy = c[0], c[1] + 75 * s                       # footprint centre at the chair's feet
        ax0, ay0 = fx + 230 * s, -260.0                    # apex above the frame, a little to the right
        u = np.clip((yy - ay0) / max(1.0, fy - ay0), 0, 1.2)
        axis = ax0 + (fx - ax0) * u
        half = (40 + 175 * u) * s
        lat = np.abs(xx - axis) / half
        cone = np.clip((1.0 - lat) / 0.45, 0, 1)
        cone = cone * cone * (3 - 2 * cone)                 # soft edges
        below = np.clip(1 - (yy - fy) / (60 * s), 0, 1)
        cone = cone * below * (0.30 + 0.70 * np.clip(u, 0, 1))
        foot = np.exp(-(((xx - fx) / (215 * s)) ** 2 + ((yy - fy) / (78 * s)) ** 2) ** 1.4)
        beam = np.maximum(cone, foot * 0.25)               # the cone carries the light, no round pool
        # haze: slow streaks along the beam, drifting on 2s
        n = L.brush_noise((H // 4, W // 4), 117 + (fh // 4) % 3, scale=4, angle=1.35, stretch=10)
        n = cv2.resize(n, (W, H))
        beam = beam * (0.80 + 0.20 * n)
        warm = np.float32([1.0, 0.86, 0.62])
        lit = (0.40 * k * beam)[..., None] * warm
        out = img * (1 - 0.12 * k * (1 - np.clip(beam * 1.3, 0, 1)))[..., None]
        out = 1 - (1 - out) * (1 - lit)
        # highlight shoulder inside the beam (chair gilt, seat): compress values above 0.78 toward 0.90
        t0 = 0.70
        hi = t0 + (1 - t0) * 0.45 * np.tanh((out - t0) / ((1 - t0) * 0.45))
        w = np.clip(beam * 2.0, 0, 1)[..., None] * k
        out = np.where(out > t0, out * (1 - w) + hi * w, out)
        return np.clip(out, 0, 1).astype(np.float32)

    # ---------------------------------------------------------------- frame
    def frame(self, f):
        t = self.ctx.local(f)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            mine = [(s, arm) for s, arm in zip(self.lay.sprites, ARMS) if arm[0].plane == i]
            if mine:
                rgb, a = rgb.copy(), a.copy()
                for s, (spec, wave, sign) in mine:
                    patch, x0, y0 = deform_sprite(s, angle_deg=self.arm_angle(wave, sign, f))
                    composite_into(rgb, a, patch, x0, y0)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._spot(img, f, t)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Great Council of 233 AC: the last time the lords chose a king", self.f_great)
        return img, {}

    def finish_args(self, f, info):
        # less bloom once the beam is on, so the lit chair keeps its detail
        return {"bloom_strength": 0.4 if f < self.f_next else 0.22}

    def events(self):
        ev = [(self.f_great, "lore_tag", {}), (self.f_next, "spotlight", {})]
        return sorted(ev + [(fw, f"hands_wave_{k}", {}) for k, fw in enumerate(self.wave_f)])

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.crowd(dur + 0.6, seed=111), t0 - 0.2, -31)
        wind = A.lowpass(A.noise(dur + 0.6, 112, kind="pink"), 600)
        snd.bed(wind / (np.abs(wind).max() + 1e-9), t0 - 0.2, -34, 0.3)
        # sleeves rustle as each wave of hands goes up
        for k, fw in enumerate(self.wave_f):
            snd.sfx(A.swish(0.28, seed=113 + k), snd.at_frame(fw - 2), -21 + 2 * k, (-0.4, 0.0, 0.4)[k])
        # the spotlight lands: a low boom and a shimmer
        snd.sfx(A.thunk(seed=120), snd.at_frame(self.f_next), -19, 0.2)
        snd.sfx(A.bell(880, 1.4, seed=121), snd.at_frame(self.f_next), -30, 0.2)


def make(ctx):
    return Shot(ctx)
