"""Shot 8, Year 7: "And no heir. A witch told the queen she would never bear a child, and the lords are
counting."

The queen's hand rests on the empty cradle; on "never" it leaves the rail and she turns away (pose B,
anticipation and in-between on 2s). The camera drifts right toward the lords; on "counting" the lord's
scroll unrolls down to show a Great Council summons (code-drawn parchment, serif lettering multiplied into
it, a soft shadow under the sheet), and the lord at the right edge counts: one finger jumps up per tick on 2s
(anticipation dip, overshoot drawing, hold), the last tick lifts the whole hand. Braziers flicker and a few embers rise on 2s. YEAR 7; the
lore tag "Mirri Maz Duur's prophecy, season 1" while the witch's words are spoken.
Coordinates are px of the upscaled key work/keys/g07_cradle_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into
from whatif.config import FPS, WORK_SCALE
from whatif.fx2d import Embers
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]

QUEEN_R = [(0, 690), (700, 690), (760, 1300), (880, 1940), (900, 2200), (780, 2701), (0, 2701)]
CRADLE_R = [(700, 690), (1520, 690), (1520, 2701), (780, 2701), (900, 2200), (880, 1940), (760, 1300)]
PLANES = [
    L.PlaneSpec("hall", 0.00, 0.14, fill="full"),
    L.PlaneSpec("court", 0.14, 0.40, radius=60),
    L.PlaneSpec("cradle", 0.40, 1.01, radius=60, region=CRADLE_R),
    L.PlaneSpec("queen", 0.40, 1.01, radius=70, region=QUEEN_R),
]
HAND = [(1385, 1135), (1520, 1135), (1520, 1300), (1385, 1300)]       # the right lord's raised hand
SPRITES = [L.SpriteSpec("fingers", 1, HAND, dmin=0.12, pivot=(1470, 1300), anchor=(1440, 1140, 1460, 1300))]
# the queen in both poses, plus the cradle rail where her hand was
TURN = [(0, 680), (720, 680), (780, 1300), (900, 1930), (920, 2200), (800, 2701), (0, 2701)]
# the held scroll (key x 1170-1350, rolls at y 1120-1170 and 1365-1400) is replaced by a wider sheet that
# unrolls downward from the top roll; its lettering sits in the left part, inside the safe area
SCROLL_X0, SCROLL_X1 = 985, 1386
SCROLL_Y0, SCROLL_Y1 = 1150, 1452
PAINTED_SCROLL = [(1150, 1168), (1365, 1168), (1365, 1330), (1405, 1330), (1405, 1436), (1150, 1436)]   # key scroll below its top roll
GRIP = [(1192, 1118), (1268, 1118), (1272, 1210), (1192, 1214)]      # the lord's fingers over the top roll
PAPER = np.float32([0.90, 0.82, 0.64])
INK = np.float32([0.24, 0.10, 0.08])
INK_WARM = np.float32([0.36, 0.16, 0.07])
SERIF = "/System/Library/Fonts/Supplemental/Baskerville.ttc"   # macOS book serif (Bold face, index 1)
# finger ticks: each tick jabs one raised finger of the right lord's hand up along its length (tip, base in
# key px); the last lifts the whole hand. A finger moves rigidly above its base, the palm stretches below it,
# the wrist and the thumb hold.
FINGERS = (((1418, 1134), (1440, 1196)), ((1442, 1128), (1456, 1192)), ((1478, 1164), (1486, 1196)), None)
WRIST_Y = 1262


def _serif_alpha(lines, size, w, h):
    """Centred serif lines as alpha (h, w); falls back to the display face if the serif is missing."""
    from PIL import Image, ImageDraw, ImageFont
    try:
        fnt = ImageFont.truetype(SERIF, size, index=1)
    except OSError:
        fnt = T.font("display", size)
    im = Image.new("L", (w, h), 0)
    dr = ImageDraw.Draw(im)
    lh = h / len(lines)
    for i, ln in enumerate(lines):
        x0, y0, x1, y1 = dr.textbbox((0, 0), ln, font=fnt)
        dr.text(((w - 36 - (x1 - x0)) / 2 - x0, i * lh + (lh - (y1 - y0)) / 2 - y0 + (4 if i == 0 else -4)), ln,
                font=fnt, fill=255)
    return np.asarray(im, np.float32) / 255


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_witch = ctx.f("witch")
        self.f_never = ctx.f("never")
        self.f_lords = ctx.f("lords")
        self.f_count = ctx.f("counting.")
        tn, tl = ctx.local(self.f_never), ctx.local(self.f_lords)
        fx = Track([(0, W * 0.42), (tn, W * 0.45, "inout"), (d, W * 0.66, "inout")])
        self.cam = ParallaxCamera(                        # camera on 1s: hold on the queen, then drift right
            W, H, focus=lambda t: (fx(t), H * 0.50), nearness=nearness,
            zoom=Track([(0, 1.0), (tn, 1.04, "inout"), (d, 1.15, "inout")]),
            push=Track([(0, 0.0), (d, 0.06, "inout")]),
            rise=Track([(0, 0.0), (d, 16.0, "inout")]),
            pan=Track([(0, 0.0), (tl, -10.0, "inout"), (d, -28.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=TURN, thresh=14.0)
        self.swaps = [(self.f_never, "B")]
        self.ticks = [self.f_lords + 2 + 4 * k for k in range(4) if self.f_lords + 2 + 4 * k < self.f1 - 2]

    # ---------------------------------------------------------------- layers
    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    @cached_property
    def flames(self):
        out = []
        for pl in self.planes:
            rgb = pl["rgb"]
            m = ((rgb.max(2) > 0.55) & (rgb[..., 0] > rgb[..., 2] + 0.25)).astype(np.float32) * pl["a"]
            out.append(cv2.GaussianBlur(cv2.dilate(m, np.ones((7, 7), np.uint8)), (0, 0), 12) if m.sum() > 50 else None)
        return out

    @cached_property
    def embers(self):
        return Embers(10, self.lay.W, self.lay.H, seed=23, y_range=(0.28, 0.45), n_range=(0.15, 0.3))

    @cached_property
    def sheet(self):
        """The unrolled summons at work scale: paper rgb, alpha and lettering alpha (full length)."""
        x0, x1 = int(SCROLL_X0 * WORK_SCALE), int(SCROLL_X1 * WORK_SCALE)
        y0, y1 = int(SCROLL_Y0 * WORK_SCALE), int(SCROLL_Y1 * WORK_SCALE)
        w, h = x1 - x0, y1 - y0
        tooth = T.paper_tooth(h, w, seed=12)[..., None]
        xx = np.linspace(-1, 1, w, dtype=np.float32)[None, :, None]
        court = self.planes[1]["rgb"]
        paper = np.median(court[int(1220 * WORK_SCALE):int(1310 * WORK_SCALE),
                                int(1215 * WORK_SCALE):int(1300 * WORK_SCALE)].reshape(-1, 3), 0)
        n = L.brush_noise((h, w), 31, scale=3, angle=-0.4, stretch=6)[..., None]
        rgb = paper * (1 + 0.05 * tooth + 0.05 * n) * (1 - 0.22 * xx ** 4) * (0.97 + 0.06 * xx)
        a = np.ones((h, w), np.float32)
        rng = np.random.default_rng(14)                  # deckled side edges
        for yy in range(h):
            a[yy, :int(rng.integers(0, 3))] = 0
            a[yy, w - int(rng.integers(0, 3)):] = 0
        a = cv2.GaussianBlur(a, (0, 0), 0.7)
        # parchment, not a card: burnt edges, a curl shade along its length, ragged deckle
        yy = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
        rgb = rgb * (0.90 + 0.10 * np.sin(np.pi * np.clip(yy * 1.1, 0, 1)))
        dist = np.minimum.reduce([np.arange(w)[None, :].repeat(h, 0), (w - 1 - np.arange(w))[None, :].repeat(h, 0),
                                  np.arange(h)[:, None].repeat(w, 1), (h - 1 - np.arange(h))[:, None].repeat(w, 1)])
        burn = np.exp(-dist.astype(np.float32) / 9.0) * (0.7 + 0.3 * n[..., 0])
        rgb = rgb * (1 - 0.32 * burn[..., None]) + np.float32([0.30, 0.16, 0.06]) * 0.12 * burn[..., None]
        edge = cv2.GaussianBlur(rng.uniform(0, 1, (h, 2)).astype(np.float32), (0, 0), 3)
        for yy_ in range(h):
            a[yy_, :int(1 + 6 * edge[yy_, 0])] = 0
            a[yy_, w - int(1 + 6 * edge[yy_, 1]):] = 0
        a = cv2.GaussianBlur(a, (0, 0), 0.8)
        # lettering: a book serif in warm iron-gall ink, multiplied into the paper (cap >= 40 work px)
        lt = _serif_alpha(["Great", "Council"], 62, w, 116)
        lt = cv2.GaussianBlur(T.rough_alpha(lt, 4, 0.35), (0, 0), 0.7)
        letters = np.zeros((h, w), np.float32)
        letters[58:174, :] = lt                           # below the lord's grip on the top roll
        small = np.zeros((h, w), np.float32)
        for yl in (186, 198, 210):
            cv2.line(small, (22, yl), (w - 84 - (yl % 3) * 14, yl), 0.6, 2, cv2.LINE_AA)
        seal = np.zeros((h, w), np.float32)
        cv2.circle(seal, (w - 40, h - 44), 15, 1.0, -1, cv2.LINE_AA)
        T.paint_on_surface(rgb, T.rough_alpha(small, 4, 0.9) * 0.6, INK * 1.4, opacity=0.55, seed=5)
        ink = letters[..., None] * 0.92
        rgb = rgb * (1 - ink) + rgb * INK_WARM / PAPER.mean() * ink      # multiply: paper tooth shows through
        T.paint_on_surface(rgb, T.rough_alpha(seal, 7, 1.0), np.float32([0.62, 0.08, 0.08]), opacity=0.95, seed=7)
        return rgb.astype(np.float32), a, (x0, y0)

    def _unroll(self, rgb, a, f):
        """Sheet unrolls down from the top roll on 2s, a rolled cylinder at its bottom edge."""
        fh = f - f % 2
        k = Track([(self.f_count - 2, 0.0), (self.f_count + 6, 1.0, "out")])(fh)
        if k <= 0:
            return
        srgb, sa, (x0, y0) = self.sheet
        m = self.scroll_patch[..., None]                  # the painted scroll goes the frame the sheet shows
        rgb[:] = rgb * (1 - m) + self.scroll_fill * m
        h = max(8, int(sa.shape[0] * k))
        w = sa.shape[1]
        patch = np.dstack([srgb[:h], sa[:h]]).copy()
        r = 9                                              # the roll: darker band with a highlight
        yy = np.arange(min(2 * r, h), dtype=np.float32)
        band = 0.55 + 0.45 * np.sin(np.pi * yy / (2 * r))
        patch[h - len(yy):, :, :3] = srgb[:1].mean(1)[None] * 0.9 * band[:, None, None]
        self._shadow(rgb, patch[..., 3], x0, y0)
        composite_into(rgb, a, patch, x0, y0)
        top = np.dstack([np.broadcast_to(srgb[:1].mean(1)[0] * 0.8, (12, w, 3)), np.ones((12, w), np.float32)])
        composite_into(rgb, a, top.astype(np.float32), x0, y0 - 6)
        g = self.grip
        rgb[:] = rgb * (1 - g[..., None]) + self.planes[1]["rgb"] * g[..., None]

    @staticmethod
    def _shadow(rgb, pa, x0, y0, off=(7, 11), sigma=8.0, k=0.5):
        """Soft contact shadow of the sheet on the coat behind it (in place)."""
        P = int(3 * sigma) + max(off)
        h, w = pa.shape
        big = np.zeros((h + 2 * P, w + 2 * P), np.float32)
        big[P + off[1]:P + off[1] + h, P + off[0]:P + off[0] + w] = pa
        sh = cv2.GaussianBlur(big, (0, 0), sigma) * k
        H, W = rgb.shape[:2]
        xa, ya, xb, yb = max(x0 - P, 0), max(y0 - P, 0), min(x0 - P + w + 2 * P, W), min(y0 - P + h + 2 * P, H)
        sub = sh[ya - (y0 - P):yb - (y0 - P), xa - (x0 - P):xb - (x0 - P)]
        rgb[ya:yb, xa:xb] *= (1 - sub[..., None])

    @cached_property
    def scroll_patch(self):
        """The painted scroll below its top roll (key px), feathered: hidden once the summons sheet is up."""
        m = L.poly_mask(self.planes[1]["a"].shape, PAINTED_SCROLL, WORK_SCALE).astype(np.float32)
        m = cv2.dilate(m, np.ones((5, 5), np.uint8))
        return cv2.GaussianBlur(m, (0, 0), 2.0)

    @cached_property
    def scroll_fill(self):
        """The coat behind the painted scroll, filled in from around it (push-pull) with a little brush grain."""
        rgb = self.planes[1]["rgb"]
        valid = (self.scroll_patch < 0.02).astype(np.float32)
        fill = L.push_pull_fill(rgb, valid)
        n = L.brush_noise(valid.shape, 41, scale=3, angle=0.3, stretch=5)[..., None]
        return (fill * (1 + 0.05 * n)).astype(np.float32)

    @cached_property
    def grip(self):
        m = L.poly_mask(self.planes[1]["a"].shape, GRIP, WORK_SCALE).astype(np.float32)
        return cv2.GaussianBlur(m, (0, 0), 1.5)

    def _finger_lift(self, f):
        """Per-tick lift in work px on 2s: a finger jumps ~32 px on its tick drawing (overshoot), then holds
        at ~24 px; the fourth tick lifts the whole hand."""
        fh = f - f % 2
        out = []
        for k, ft in enumerate(self.ticks):
            if fh < ft - 2:
                out.append(0.0)
            elif fh == ft - 2:
                out.append(-3.0)                              # anticipation: a small dip
            elif fh == ft:
                out.append(32.0 if FINGERS[k] is not None else 18.0)
            else:
                out.append(24.0 if FINGERS[k] is not None else 12.0)
        return out

    @cached_property
    def finger_masks(self):
        """Per finger (work px, hand patch padded by 44 rows on top): weight 1 on the finger above its base,
        ramping to 0 a little way into the palm; the last entry (whole hand) ramps from palm to wrist."""
        s = self.lay.sprites[0]
        h, w = s["rgba"].shape[0] + 44, s["rgba"].shape[1]
        x0, y0 = s["bbox"][0], s["bbox"][1] - 44
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        X, Y = (gx + x0) / WORK_SCALE, (gy + y0) / WORK_SCALE              # key px
        out = []
        for fg in FINGERS:
            if fg is None:
                out.append((np.clip((WRIST_Y - Y) / 40.0, 0, 1).astype(np.float32), (0.0, 1.0)))
                continue
            (tx, ty), (bx, by) = fg
            L_ = math.hypot(bx - tx, by - ty)
            ux, uy = (bx - tx) / L_, (by - ty) / L_
            t = (X - tx) * ux + (Y - ty) * uy                               # along the finger, 0 at the tip
            dperp = np.abs(-(X - tx) * uy + (Y - ty) * ux)
            along = np.clip((L_ + 26 - t) / 26.0, 0, 1)                       # rigid finger, ramp into the palm
            m = (dperp < 10).astype(np.float32) * (t > -60) * along
            m = cv2.GaussianBlur(m, (0, 0), 3.0)
            out.append((m, (-ux, -uy)))                                       # move toward the tip
        return out

    def _fingers_patch(self, s, f):
        """The hand sprite with the counted fingers jabbed up (a private warp; the wrist stays attached)."""
        rgba = s["rgba"].astype(np.float32) / 255 if s["rgba"].dtype == np.uint8 else s["rgba"]
        x0, y0 = s["bbox"][0], s["bbox"][1]
        lifts = self._finger_lift(f)
        P = 44
        src = np.zeros((rgba.shape[0] + P, rgba.shape[1], 4), np.float32)
        src[P:] = rgba
        if not any(lifts):
            return src, x0, y0 - P
        h, w = src.shape[:2]
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        DX = np.zeros((h, w), np.float32)
        DY = np.zeros((h, w), np.float32)
        for (m, (dx, dy)), L_ in zip(self.finger_masks, lifts):
            if L_:
                DX += L_ * m * dx
                DY += L_ * m * dy
        out = cv2.remap(src, gx - DX, gy - DY, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        return out, x0, y0 - P

    # ---------------------------------------------------------------- frame
    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        fh = f - f % 2
        st = PoseSwap.state(f, self.swaps) if self.pose else "A"
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            fl = self.flames[i]
            if fl is not None:
                z = 0.10 * math.sin(fh * 1.7) + 0.06 * math.sin(fh * 3.1 + 1)
                rgb = rgb * (1 + fl[..., None] * z)
            if i == 1:
                rgb, a = rgb.copy(), a.copy()
                for s in self.lay.sprites:
                    patch, x0, y0 = self._fingers_patch(s, f)
                    composite_into(rgb, a, patch, x0, y0)
                self._unroll(rgb, a, f)
            if self.pose and i in (1, 3):
                wr = i == 3
                n = self.pose.nearness(n, pl["a"], st, whole_region=wr)
                rgb, a = self.pose.apply(rgb, a, st, whole_region=wr)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self.embers.draw(self.cam, th * 0.6, img, intensity=0.7)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Mirri Maz Duur's prophecy,\nseason 1", self.f_witch)
        return img, {"pose": st}

    def finish_args(self, f, info):
        return {"bloom_strength": 0.5}

    def events(self):
        return [(self.f_witch, "data_tag", {}), (self.f_never, "hand_off_cradle", {}),
                (self.f_count, "scroll_unrolls", {})] + [(ft, "finger_tick", {}) for ft in self.ticks]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.room_tone(dur + 0.6, seed=81), t0 - 0.2, -30)
        snd.bed(A.crowd(dur + 0.6, seed=82), t0 - 0.2, -36)
        snd.bed(A.drone(dur + 0.6, seed=83), t0 - 0.2, -34)
        # her hand leaves the cradle: a creak of wood and the swish of the coat as she turns
        creak = A.bandpass(A.noise(0.35, 84, "brown"), 180, 700) * np.exp(-np.linspace(0, 1, int(0.35 * A.SR)) * 4)
        snd.sfx(creak / (np.abs(creak).max() + 1e-6), snd.at_frame(self.f_never - 4), -24, -0.4)
        snd.sfx(A.swish(0.4, seed=85), snd.at_frame(self.f_never - 2), -17, -0.4)
        snd.sfx(A.thunk(seed=86), snd.at_frame(self.f_never), -27, -0.3)
        # the scroll unrolls
        snd.sfx(A.swish(0.3, seed=87), snd.at_frame(self.f_count - 2), -19, 0.4)
        rust = A.bandpass(A.noise(0.4, 88, "white"), 2500, 7000) * np.exp(-np.linspace(0, 1, int(0.4 * A.SR)) * 6)
        snd.sfx(rust, snd.at_frame(self.f_count), -26, 0.4)
        for k, ft in enumerate(self.ticks):
            snd.sfx(A.tick(89 + k, 2400 + 200 * k), snd.at_frame(ft), -27, 0.7)


def make(ctx):
    return Shot(ctx)
