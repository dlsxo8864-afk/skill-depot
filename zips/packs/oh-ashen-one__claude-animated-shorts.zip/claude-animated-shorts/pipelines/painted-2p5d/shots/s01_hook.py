"""Shot 1, hook: "What if Daenerys never burned King's Landing?"

The bell swings and rings (drawn sound rings on 2s); on "never" the dragon banks away (wings dip on 2s,
two in-betweens, then pose B: wings up,
the queen's hand higher) with a camera roll; title text, the "Unofficial fan fiction" chip and the
"Season 8, episode 5: the bells" tag. Narration starts 0.21 s in (timeline: the hook's take starts at 0).
Coordinates are px of the upscaled key work/keys/g00_hook_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS, WORK_SCALE, safe_box
from whatif.fx2d import Embers, ShapeCanvas, screen_emissive
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]
CREAM = (246, 236, 216)
EMBER = (255, 146, 72)

TOP = [(0, 0), (1520, 0), (1520, 1300), (0, 1300)]
BOTTOM = [(0, 1300), (1520, 1300), (1520, 2701), (0, 2701)]
PLANES = [
    L.PlaneSpec("sky", 0.00, 0.14, fill="full"),
    L.PlaneSpec("city", 0.14, 0.44, radius=60),
    L.PlaneSpec("dragon", 0.30, 1.01, radius=60, region=TOP),     # dragon, queen and the bell tower top
    L.PlaneSpec("crowd", 0.44, 1.01, radius=70, region=BOTTOM),
]
BELL_PIVOT = (282, 1040)
SPRITES = [
    L.SpriteSpec("bell", 2, [(196, 1035), (372, 1035), (386, 1262), (182, 1262)], dmin=0.0,
                 pivot=BELL_PIVOT, fill_own_plane=True),
]
# pose B: the dragon's wings up and the queen's hand higher (sky band, minus the bell tower)
HERO = [(40, 30), (1520, 0), (1520, 1180), (900, 1180), (600, 1260), (395, 1260), (385, 790), (300, 715),
        (140, 680), (40, 700)]
# pose A's left wing tip hangs below HERO's edge, just above the tower roof: without this patch it stayed
# as a grey ghost in the sky once pose B showed (critic, frame 20 on)
WING_TIP = [(135, 690), (250, 700), (232, 768), (206, 796), (176, 798), (150, 760)]
# pose change on "never", on 2s: wings dip (two anticipation drawings), two in-betweens, land on the word
# (name, source pose, k): k < 0 = pose A dipping away from the move; k > 0 = pose A part way to B ("A") or
# pose B drawn k of the way back toward A ("B")
POSE_STEPS = {-8: ("d1", "A", -0.06), -6: ("d2", "A", -0.13), -4: ("i1", "A", 0.5), -2: ("i2", "B", 0.3)}


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_never = ctx.f("never")
        self.f_burned = ctx.f("burned")
        tn = ctx.local(self.f_never)
        self.cam = ParallaxCamera(                              # camera on 1s
            W, H, focus=(W * 0.50, H * 0.40), nearness=nearness,
            zoom=Track([(0, 1.0), (tn, 1.03, "inout"), (d, 1.07, "out")]),
            push=Track([(0, 0.0), (d, 0.08, "inout")]),
            rise=Track([(0, 0.0), (tn, 10.0, "inout"), (d, 40.0, "out")]),
            roll=Track([(0, 0.0), (tn - 0.1, 0.4, "inout"), (tn + 0.5, -1.6, "out"), (d, -1.9, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=[HERO, WING_TIP])
        # bell rings: the clapper strikes at one swing extreme, every 16 frames (on 2s), from the first frame
        self.rings = [ctx.f0 + 2 + 16 * k for k in range(ctx.n // 16 + 1) if ctx.f0 + 2 + 16 * k < ctx.f1 - 2]

    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    @cached_property
    def embers(self):
        return Embers(18, self.lay.W, self.lay.H, seed=11, y_range=(0.45, 0.95), n_range=(0.2, 0.7))

    @cached_property
    def title(self):
        """Three title lines (display type), NEVER in ember, placed low over the crowd's dark coats."""
        x0, y0, x1, y1 = safe_box()
        items = []
        y = 1150
        for text, size, color in [("WHAT IF DAENERYS", 92, CREAM), ("NEVER BURNED", 132, EMBER),
                                  ("KING'S LANDING?", 92, CREAM)]:
            fnt = T.font("display", size)
            tw, th, ox, oy = T.text_size(fnt, text)
            if tw > (x1 - x0):
                fnt = T.font("display", int(size * (x1 - x0) / tw))
                tw, th, ox, oy = T.text_size(fnt, text)
            a = O._text_alpha(text, fnt)
            rgba, pad = T.styled_text_rgba(a, color, seed=len(items) + 1, shadow_off=(4, 6), soft_shadow=12,
                                           grad=0.12 if color == CREAM else 0.18)
            items.append({"rgba": rgba, "x": x0 - pad, "y": y - pad, "kind": text})
            y += th + 14
        # dark dry-brushed band behind the block so it reads over the crowd
        h = y - 1150 + 50
        w = x1 - x0 + 30
        sw = np.zeros((h, w), np.float32)
        cv2.rectangle(sw, (10, 10), (w - 10, h - 10), 1.0, -1)
        n = L.brush_noise(sw.shape, 77, scale=3, angle=0.02, stretch=12)
        sw = np.clip((cv2.GaussianBlur(sw, (0, 0), 6) - 0.5 + n * 0.2) * 3 + 0.5, 0, 1) * 0.62
        band = {"rgba": np.dstack([np.ones((h, w, 3), np.float32) * np.float32([0.08, 0.04, 0.13]), sw]),
                "x": x0 - 20, "y": 1150 - 26}
        return items, band

    def _state(self, f):
        if not self.pose:
            return "A"
        d = (f - f % 2) - self.f_never
        return "B" if d >= 0 else POSE_STEPS.get(d, ("A",))[0]

    @cached_property
    def drawings(self):
        """Dip and in-between drawings: pose A mesh-warped along a dense A->B motion field (DIS flow,
        smoothed). Negative k = the wings dip away from the coming move; positive k = part way to pose B."""
        a, b = self.pose.a_img, self.pose.b
        g8 = lambda x: cv2.resize(cv2.cvtColor((np.clip(x, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY),
                                  None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
        dis = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
        sm = lambda fl: np.dstack([cv2.GaussianBlur(fl[..., c], (0, 0), 8) for c in range(2)])
        fl = {"A": sm(cv2.resize(dis.calc(g8(b), g8(a), None), (a.shape[1], a.shape[0])) / 0.5),   # pulls A toward B
              "B": sm(cv2.resize(dis.calc(g8(a), g8(b), None), (a.shape[1], a.shape[0])) / 0.5)}   # pulls B toward A
        H, W = a.shape[:2]
        gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
        out = {}
        for name, src, k in POSE_STEPS.values():
            img, v = (a if src == "A" else b), fl[src]
            out[name] = cv2.remap(img, gx + k * v[..., 0], gy + k * v[..., 1], cv2.INTER_LINEAR,
                                  borderMode=cv2.BORDER_REFLECT).astype(np.float32)
        out["B"] = b
        return out

    def _bell_angle(self, f):
        th = on2s(f - self.f0)
        return 14.0 * math.cos(2 * math.pi * th / (16 / FPS))

    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        st = self._state(f)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            mine = [s for s in self.lay.sprites if s["plane"] == i]
            if mine or (self.pose and i <= 2):
                rgb, a = rgb.copy(), a.copy()
            if self.pose and i <= 2:              # sky and city too: their soft edges hold bits of pose A's wings
                wr = True                         # whole region in every plane: no pose A colour bleeds at the mask edge
                n = self.pose.nearness(n, a, st, whole_region=wr)
                if st != "A":                     # flat depth over the region: no fold along pose A's wing edge
                    m = self.pose._m(a, n.shape, True)
                    n = (n * (1 - m) + float(np.median(n[m > 0.5])) * m).astype(np.float32) if (m > 0.5).any() else n
                if st != "A":
                    rgb, a = self.pose.apply(rgb, a, "B", src=self.drawings[st], whole_region=wr)
            for s in mine:
                patch, x0, y0 = deform_sprite(s, angle_deg=self._bell_angle(f))
                composite_into(rgb, a, patch, x0, y0)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self.embers.draw(self.cam, th, img, intensity=0.45)
        img = self._rings(img, f)
        img = self._titles(img, f)
        return img, {"pose": st}

    def _rings(self, img, f):
        """Drawn sound rings out of the bell mouth on 2s: three drawings per ring."""
        fh = f - f % 2
        sc = None
        p = (BELL_PIVOT[0] * WORK_SCALE, (BELL_PIVOT[1] + 200) * WORK_SCALE)
        for fr in self.rings:
            k = (fh - fr) // 2
            if 0 <= k < 3:
                sc = sc or ShapeCanvas(img.shape[1], img.shape[0])
                q = self.cam.screen_point(p, 0.4, self.ctx.local(f))
                r = 40 + 34 * k
                for side in (-1, 1):
                    a0 = (-0.55 if side > 0 else math.pi - 0.55)
                    pts = [(q[0] + side * 0 + r * math.cos(a0 + u * 1.1), q[1] + r * math.sin(a0 + u * 1.1))
                           for u in np.linspace(0, 1, 12)]
                    sc.line(pts, 5.0 - 1.4 * k, value=int(255 * (1 - 0.28 * k)))
        if sc is None:
            return img
        c, g = sc.result(glow_sigma=4)
        return screen_emissive(img, c * 0.8, g * 0.8, (1.0, 0.86, 0.55), (1.0, 0.55, 0.20))

    def _titles(self, img, f):
        x0, y0, x1, y1 = safe_box()
        fh = (f - self.f0) - (f - self.f0) % 2
        items, band = self.title
        s = T.pop_scale((fh - 2) / FPS)
        if s is not None:
            r = band["rgba"]
            pr, ox, oy = T.transform_rgba(r, min(1.0, 0.4 + 0.6 * s), 0, origin=(0, r.shape[0] / 2))
            O.seat(img, pr, band["x"] + ox, band["y"] + oy)
        for it, st in zip(items, (2, 6, 10)):
            s = T.pop_scale((fh - st) / FPS)
            if s is None:
                continue
            op = 1.0
            if it["kind"].startswith("NEVER"):        # NEVER flares on the word
                op = {0: 1.0, 2: 0.55, 4: 1.0}.get((f - f % 2) - self.f_never, 1.0)
            r = it["rgba"]
            pr, ox, oy = T.transform_rgba(r, s, 0, origin=(30, r.shape[0] / 2))
            O.seat(img, pr, it["x"] + ox, it["y"] + oy, opacity=op,
                   glow=(1.0, 0.5, 0.2) if it["kind"].startswith("NEVER") and f >= self.f_never else None)
        # small chips: fan-fiction label top-left from the first frames; the canon tag after "burned"
        O.draw_pop(img, O.fan_tag(), x0 - 6, y0 - 8, f, self.f0 + 2)
        O.draw_pop(img, O.data_tag("Season 8, episode 5: the bells", size=30), x0 - 6, 1150 - 120, f, self.f_burned)
        return img

    def finish_args(self, f, info):
        return {"bloom_strength": 0.55}

    def events(self):
        ev = [(self.f_never - 8, "wing_dip", {}), (self.f_never, "dragon_bank", {}), (self.f_burned, "data_tag", {})]
        ev += [(r, "bell", {}) for r in self.rings]
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.city_hum(dur + 0.8), t0 - 0.2, -30)
        snd.bed(A.crowd(dur + 0.6, seed=31), t0, -32, pan=0.2)
        snd.bed(A.drone(dur + 0.8, seed=5), t0, -26)
        for k, r in enumerate(self.rings):            # big low bell on every swing extreme
            snd.sfx(A.bell(196.0, dur=1.8, seed=k + 3), snd.at_frame(r), -16, pan=-0.45)
        # the dragon banks away on "never": a wing beat (low whoosh) and a distant roar
        snd.sfx(A.lowpass(A.whoosh(0.8, seed=19), 900), snd.at_frame(self.f_never - 4), -11, 0.2)
        n = int(1.1 * A.SR)
        tt = A.t_axis(1.1)
        roar = A.lowpass(A.noise(1.1, 23, "pink"), 500) * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * tt)) \
            + 0.3 * A.osc(70 - 18 * tt, 1.1, "saw")
        roar = roar[:n] * A.env_adsr(n, 0.12, 0.2, 0.7, 0.5)
        snd.sfx(A.lowpass(roar, 900), snd.at_frame(self.f_never + 2), -17, 0.3)


def make(ctx):
    return Shot(ctx)
