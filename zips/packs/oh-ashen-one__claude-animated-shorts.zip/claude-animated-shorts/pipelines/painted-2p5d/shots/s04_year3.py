"""Shot 4, Year 3: "The Dothraki get bored. Horse lords do not farm, and there is nobody left to fight."

The khal's whetstone scrapes along the blade on the beats (hand sprite strokes toward the tip on 2s with a
spark at the contact); on "bored" he yawns (pose B) and holds it, back to pose A on "Horse"; the scarecrow's
head drops on "fight". The cooking fire flickers on 2s. YEAR 3 and the lore tag in the calm sky.
Coordinates are px of the upscaled key work/keys/g03_dothraki_key.png (1520 x 2701).
"""
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import WORK_SCALE
from whatif.fx2d import ShapeCanvas, screen_emissive, spark_burst
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("sky", 0.00, 0.095, fill="full"),               # sky, hills, castle, far riders
    L.PlaneSpec("field", 0.095, 0.30, radius=60),                # riders, cart, mud
    L.PlaneSpec("mid", 0.30, 0.48, radius=60),                   # fire, near mud
    L.PlaneSpec("hero", 0.48, 1.01, radius=70),                  # khal, post, scarecrow, fence
]
STONE = (905, 1905)                       # whetstone on the blade (contact point)
SPRITES = [
    # whetstone hand: strokes toward the tip; the forearm stays attached (anchor ramp to the wrist)
    L.SpriteSpec("hand", 3, [(590, 1760), (960, 1790), (975, 1990), (600, 1985), (560, 1880)],
                 dmin=0.45, pivot=(640, 1880), anchor=(960, 1890, 620, 1870), fill_own_plane=True),
    # scarecrow head + hat: hinges at the neck rope, falls on "fight"
    # (tight to hat, face and neck rope: the old envelope also lifted a piece of the right shoulder)
    L.SpriteSpec("head", 3, [(1055, 535), (1215, 548), (1330, 545), (1495, 640), (1480, 712), (1385, 752),
                             (1340, 778), (1326, 800), (1322, 840), (1212, 845), (1200, 798), (1160, 792), (1075, 775)],
                 dmin=0.45, pivot=(1270, 835)),
]
HERO = [(330, 1080), (800, 1080), (800, 1620), (330, 1620)]    # khal's head + face hand, both poses
BLADE_DIR = np.float32([0.62, -0.78])     # along the blade toward the tip near the stone (key px)
FIRE = (60, 1940)
CLONE_DX = 470                            # hole behind the head: cloned from this far left (key px)


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_bored = ctx.f("bored.")
        self.f_horse = ctx.f("Horse")
        self.f_fight = ctx.f("fight.")
        self.f_lore = self.f_horse
        # scrape beats: the stressed words around the yawn
        sc = [self.f0 + 4, ctx.f("Dothraki") + 6, self.f_horse + 4, ctx.f("farm,"), ctx.f("nobody")]
        self.scrapes = [x - x % 2 for x in sc]
        self.cam = ParallaxCamera(
            W, H, focus=(W * 0.45, H * 0.55), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.06, "inout")]),
            push=Track([(0, 0.0), (d, 0.07, "inout")]),
            rise=Track([(0, 0.0), (d, -20.0, "inout")]),
            pan=Track([(0, 0.0), (d, -22.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=HERO, thresh=14.0)
        self.swaps = [(self.f_bored, "B"), (self.f_horse, "A")]

    @cached_property
    def planes(self):
        out = [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]
        # behind the scarecrow head: the generic fills leave a hat-shaped ghost and a push-pull fill smears
        # pale; clone the hills and field from the same rows to the left (they run horizontally) into the
        # field plane, clear the mid plane
        s = self.lay.sprites[self.lay.sprite_index("head")]
        x0, y0, x1, y1 = s["bbox"]
        H, W = out[0]["a"].shape
        hole = np.zeros((H, W), np.float32)
        hole[y0:y1, x0:x1] = s["rgba"][..., 3].astype(np.float32) / 255
        hole = cv2.dilate((hole > 0.05).astype(np.uint8), np.ones((19, 19), np.uint8)).astype(np.float32)
        a1 = out[1]["a"][..., None]
        bg = out[0]["rgb"] * (1 - a1) + out[1]["rgb"] * a1
        sh = int(round(CLONE_DX * WORK_SCALE))
        filled = bg.copy()
        filled[:, sh:] = bg[:, :-sh]
        hs = cv2.GaussianBlur(hole, (0, 0), 6)
        out[1]["rgb"] = (out[1]["rgb"] * (1 - hs[..., None]) + filled * hs[..., None]).astype(np.float32)
        out[1]["a"] = np.maximum(out[1]["a"], hs)
        out[1]["n"] = np.where(hs > 0, np.minimum(out[1]["n"], nearness(np.float32(0.12))), out[1]["n"])
        out[2]["a"] = out[2]["a"] * (1 - hs)
        return out

    def _stroke(self, f):
        """Whetstone offset along the blade (key px): a fast stroke toward the tip, then drawn back."""
        fh = f - f % 2
        for fs in self.scrapes:
            d = fh - fs
            if -2 <= d <= 8:
                return {-2: -6.0, 0: 18.0, 2: 30.0, 4: 27.0, 6: 15.0, 8: 6.0}[d], d
        return 0.0, None

    def _head(self, f):
        """(angle, dy) of the scarecrow head: a small lift, then it drops and swings to rest on 2s."""
        d = (f - f % 2) - self.f_fight
        if d < -2:
            return 0.0, 0.0
        # upright (with a small lift) until the drop, then it lands in one drawing and settles: no
        # half-turned in-between (it read as two hats blended)
        seq = {-2: (0.0, 0.0), 0: (-3.0, -6.0), 2: (46.0, 78.0), 4: (40.0, 68.0), 6: (44.0, 74.0)}
        return seq.get(d, (43.0, 72.0))

    def _head_patch(self, s, ang, dy, pad=160):
        """Rotate the head sprite about its neck pivot on a padded canvas (deform_sprite clips at the bbox)."""
        rgba = s["rgba"].astype(np.float32) / 255 if s["rgba"].dtype == np.uint8 else s["rgba"]
        x0, y0 = s["bbox"][:2]
        big = cv2.copyMakeBorder(rgba, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
        px, py = s["pivot"][0] - x0 + pad, s["pivot"][1] - y0 + pad
        M = cv2.getRotationMatrix2D((float(px), float(py)), float(ang), 1.0)
        M[1, 2] += dy
        out = cv2.warpAffine(big, M, (big.shape[1], big.shape[0]), flags=cv2.INTER_LINEAR,
                             borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        return out, x0 - pad, y0 - pad

    def frame(self, f):
        t = self.ctx.local(f)
        st = PoseSwap.state(f, self.swaps) if self.pose else "A"
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            if i == 3:
                rgb, a = rgb.copy(), a.copy()
                for s in self.lay.sprites:
                    if s["name"] == "hand":
                        off, _ = self._stroke(f)
                        dx, dy = BLADE_DIR * off * WORK_SCALE
                        patch, x0, y0 = deform_sprite(s, dx=float(dx), dy=float(dy))
                    else:
                        ang, dy = self._head(f)
                        patch, x0, y0 = self._head_patch(s, ang, dy * WORK_SCALE)
                    composite_into(rgb, a, patch, x0, y0)
                n = self.pose.nearness(n, pl["a"], st) if self.pose else n
                if self.pose:
                    rgb, a = self.pose.apply(rgb, a, st)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._fire(img, f, t)
        img = self._spark(img, f, t)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Dothraki: horse nomads who neither farm nor sail", self.f_lore)
        return img, {"pose": st}

    def _spark(self, img, f, t):
        off, d = self._stroke(f)
        if d not in (0, 2, 4):
            return img
        p = np.float32(STONE) + BLADE_DIR * off
        q = self.cam.screen_point(p * WORK_SCALE, 0.68, t)
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        spark_burst(sc, q, d // 2, seed=int(f // 2), scale=0.75)
        c, g = sc.result(glow_sigma=5)
        return screen_emissive(img, c, g, (1.0, 0.9, 0.7), (1.0, 0.55, 0.2), opacity=0.9)

    def _fire(self, img, f, t):
        """Cooking fire flicker on 2s: a warm glow that breathes."""
        fh = f - f % 2
        k = 0.5 + 0.5 * np.sin(fh * 1.7) * np.cos(fh * 0.63 + 1.0)
        q = self.cam.screen_point((FIRE[0] * WORK_SCALE, FIRE[1] * WORK_SCALE), 0.45, t)
        H, W = img.shape[:2]
        yy, xx = np.ogrid[0:H, 0:W]
        g = np.exp(-(((xx - q[0]) / 260.0) ** 2 + ((yy - q[1]) / 300.0) ** 2)).astype(np.float32)
        return np.clip(img + g[..., None] * np.float32([0.10, 0.045, 0.012]) * (0.4 + 0.8 * k), 0, 1)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.45}

    def events(self):
        ev = [(fs, "scrape", {}) for fs in self.scrapes]
        return sorted(ev + [(self.f_bored, "yawn", {}), (self.f_horse, "yawn_end", {}),
                            (self.f_lore, "lore_tag", {}), (self.f_fight, "head_drop", {})])

    def sound(self, snd):
        t0, dur = snd.shot_span()
        wind = A.lowpass(A.noise(dur + 0.6, 41, kind="pink"), 900)
        snd.bed(wind / (np.abs(wind).max() + 1e-9), t0 - 0.2, -32, 0.2)
        snd.bed(A.crowd(dur + 0.6, seed=42), t0 - 0.2, -36, -0.3)
        fire = A.bandpass(A.noise(dur + 0.6, 43), 300, 3000) * (0.4 + 0.6 * (A.noise(dur + 0.6, 44) > 1.6))
        snd.bed(fire / (np.abs(fire).max() + 1e-9), t0 - 0.2, -38, -0.7)
        for i, fs in enumerate(self.scrapes):
            n = A.noise(0.32, 45 + i)
            e = A.env_adsr(len(n), 0.01, 0.08, 0.6, 0.12)
            scr = A.bandpass(n, 2600, 7800) * e + 0.25 * A.osc(3150 + 140 * i, 0.32) * A.exp_decay(len(n), 0.09)
            snd.sfx(scr / (np.abs(scr).max() + 1e-9), snd.at_frame(fs), -20, 0.15)
        # the yawn: a low breathy swell
        y = A.lowpass(A.noise(0.9, 50, kind="pink"), 500) * A.env_adsr(int(0.9 * A.SR), 0.25, 0.2, 0.7, 0.35)
        snd.sfx(y / (np.abs(y).max() + 1e-9), snd.at_frame(self.f_bored - 2), -22, -0.2)
        # the head drops: straw rustle then a dull thunk
        snd.sfx(A.swish(0.3, seed=51), snd.at_frame(self.f_fight), -20, 0.5)
        snd.sfx(A.thunk(seed=52), snd.at_frame(self.f_fight + 2), -17, 0.5)


def make(ctx):
    return Shot(ctx)
