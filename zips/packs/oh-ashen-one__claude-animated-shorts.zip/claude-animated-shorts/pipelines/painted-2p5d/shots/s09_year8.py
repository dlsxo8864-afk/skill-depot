"""Shot 9, Year 8: "Across the sea, the cities she freed drift back. Without a dragon overhead, slavery returns
to Essos."

Framed low on the market; the slaver's whip rises on "back" (pose B, anticipation and in-between on 2s); on
"overhead" the camera tilts up into the empty sky where the raised whip hangs; the whip cracks on "slavery" (a
painted 4-point flash at the lash tip and a flinch through the crowd). The chained crowd shuffles on 2s all
through (a private sideways sway/bob warp of the crowd and front planes outside the slaver). YEAR 8 sits in the
standard top-left slot; the lore tag sits under it while its fact is spoken and pops out before the whip rises.
The camera works near the top of the painting (pose B's whip arc reaches the key's top edge) and tilts up with
the whip, so the whole arc stays in frame from "back" to the end.
Coordinates are px of the upscaled key work/keys/g08_essos_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif.camera import ParallaxCamera
from whatif.config import OUT_H, OUT_W, WORK_SCALE
from whatif.fx2d import ShapeCanvas, screen_emissive, spark_burst, star4_poly
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("sky", 0.00, 0.12, fill="full"),
    L.PlaneSpec("city", 0.12, 0.30, radius=60),
    L.PlaneSpec("crowd", 0.30, 0.55, radius=60),
    L.PlaneSpec("front", 0.55, 1.01, radius=70),
]
SPRITES = []
# whip arm, whip and head in both poses (pose B's whip sweeps the sky above the city)
HERO = [(0, 0), (1130, 0), (1130, 840), (620, 900), (560, 1620), (0, 1620)]
# the slaver's body (kept still by the crowd shuffle)
SLAVER = [(0, 0), (1130, 0), (1130, 840), (620, 900), (640, 1500), (700, 2000), (620, 2701), (0, 2701)]
LASH_TIP = (1070, 350)                 # pose B lash tip, key px
GHOST_TIP = [(820, 600), (1120, 600), (1120, 900), (820, 900)]   # pose A's lash tip, sky in pose B (key px)


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_sea = ctx.f("sea,")
        self.f_back = ctx.f("back.")
        self.f_over = ctx.f("overhead")
        self.f_slav = ctx.f("slavery")
        t_over = ctx.local(ctx.f("overhead", even=False))
        t_back = ctx.local(ctx.f("back.", even=False))
        # pose B's whip arc reaches the top of the painting, so the camera works near the top: it starts a
        # little low on the market and tilts up with the whip (landing on "back") so the whole arc is in
        # frame; on "overhead" it cranes up (the near crowd sinks, the empty sky opens) instead of tilting
        z0 = 1.08
        S0 = max(OUT_W / W, OUT_H / H) * z0
        top = OUT_H / 2 / S0                               # focus y that puts the frame top on the key top
        self.cam = ParallaxCamera(
            W, H, focus=Track([(0, (W * 0.42, top + 70)), (t_back - 0.75, (W * 0.42, top + 62)),
                                (t_back + 0.05, (W * 0.42, top), "inout"), (d, (W * 0.44, top))]),
            nearness=nearness,
            zoom=Track([(0, z0), (t_over - 0.1, z0 + 0.02, "inout"), (d, z0 + 0.03, "inout")]),
            push=Track([(0, 0.0), (d, 0.04, "inout")]),
            rise=Track([(0, 0.0), (t_back, 8.0), (t_over - 0.1, 10.0), (t_over + 0.9, 70.0, "inout"),
                        (d, 78.0)]),
            pan=Track([(0, 0.0), (d, -14.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=HERO, thresh=14.0)
        self.swaps = [(self.f_back, "B")]
        if self.pose:
            self._paint_out_ghost_tip()

    def _paint_out_ghost_tip(self):
        """The A->B in-between keeps pose A's lash tip (the thin tip falls outside the hero mask), so it
        hung alone in the sky for two frames: paint the sky of pose B over it in that drawing."""
        b, ab = self.pose.b, self.pose.ab
        m = L.poly_mask(ab.shape[:2], GHOST_TIP, WORK_SCALE).astype(np.float32)
        m = cv2.GaussianBlur(m, (0, 0), 6)[..., None]
        self.pose.ab = (ab * (1 - m) + b * m).astype(np.float32)

    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    # ---------------------------------------------------------------- crowd shuffle
    @cached_property
    def crowd_w(self):
        """Where the shuffle applies (work px): everything below the skyline except the slaver."""
        H, W = self.planes[0]["a"].shape
        m = 1 - L.poly_mask((H, W), SLAVER, WORK_SCALE)
        yy = np.arange(H, dtype=np.float32)[:, None] / WORK_SCALE
        m = m * np.clip((yy - 1250) / 250, 0, 1)
        return cv2.GaussianBlur(m.astype(np.float32), (0, 0), 14)

    @cached_property
    def grid(self):
        H, W = self.planes[0]["a"].shape
        return np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))

    def _shuffle(self, f):
        """Displacement maps on 2s: each body sways a few px sideways and bobs, a new pose every 2 frames
        (held, never interpolated); after the crack the crowd flinches away from the whip."""
        fh = f - f % 2
        r = np.random.default_rng(1000 + fh)
        H, W = self.planes[0]["a"].shape
        gx, gy = self.grid
        ph = r.uniform(0, 2 * math.pi, 3)
        amp = 3.4
        flinch = 0.0
        dc = fh - self.f_slav
        if 0 <= dc <= 10:
            flinch = {0: 5.0, 2: 9.0, 4: 7.0, 6: 4.0, 8: 2.0, 10: 1.0}[dc]
        xs = gx[0] / W
        dx = (amp * np.sin(2 * math.pi * xs * 7.3 + ph[0]) + 1.4 * np.sin(2 * math.pi * xs * 17.0 + ph[1])
              + flinch * (0.6 + 0.4 * np.sin(2 * math.pi * xs * 5 + ph[2])))
        dy = 1.8 * np.abs(np.sin(2 * math.pi * xs * 9.1 + ph[1])) - 0.9
        w = self.crowd_w
        return (gx - dx[None, :] * w).astype(np.float32), (gy - dy[None, :] * w).astype(np.float32)

    @staticmethod
    def _warp(arr, mx, my):
        return cv2.remap(arr, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

    # ---------------------------------------------------------------- crack
    def _crack(self, img, f, t):
        dd = (f - f % 2) - self.f_slav
        if dd not in (0, 2, 4):
            return img
        q = self.cam.screen_point((LASH_TIP[0] * WORK_SCALE, LASH_TIP[1] * WORK_SCALE), 0.02, t)
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        r = {0: 120, 2: 80, 4: 36}[dd]
        sc.fill(star4_poly(q, r, angle=0.35))
        spark_burst(sc, q, dd // 2, seed=31, scale=1.4)
        c, g = sc.result(glow_sigma=7)
        return screen_emissive(img, c, g, (1.0, 0.96, 0.85), (1.0, 0.6, 0.3), opacity=0.95 - 0.2 * (dd // 2))

    # ---------------------------------------------------------------- frame
    def frame(self, f):
        t = self.ctx.local(f)
        st = PoseSwap.state(f, self.swaps) if self.pose else "A"
        mx, my = self._shuffle(f)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            if self.pose:
                n = self.pose.nearness(n, a, st, whole_region=True)
                rgb, a = self.pose.apply(rgb, a, st, whole_region=True)
            if i >= 2:
                rgb, a, n = self._warp(rgb, mx, my), self._warp(a, mx, my), self._warp(n, mx, my)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._crack(img, f, t)
        self.draw_year_tag(img, f)
        # the lore tag sits in the standard slot while its fact is spoken and leaves as the whip starts to
        # rise, so pose B's whip hand and arc are never covered
        self.draw_data_tag(img, f, "Slaver's Bay, freed by\nDaenerys, renamed the\nBay of Dragons", self.f0 + 8,
                           f_out=self.f_back - 6)
        return img, {"pose": st}

    def finish_args(self, f, info):
        return {"bloom_strength": 0.45}

    def events(self):
        return [(self.f0 + 8, "lore_tag", {}), (self.f_back, "whip_up", {}), (self.f_over, "tilt_sky", {}),
                (self.f_slav, "crack", {})]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.crowd(dur + 0.6, seed=91), t0 - 0.2, -29)
        snd.bed(A.room_tone(dur + 0.6, seed=92), t0 - 0.2, -32)
        # chains clink as the crowd shuffles
        for k, fr in enumerate(range(self.f0 + 6, self.f1 - 4, 14)):
            snd.sfx(A.bell(2300 + 170 * (k % 4), 0.12, seed=95 + k), snd.at_frame(fr), -34, 0.3)
        snd.sfx(A.swish(0.30, seed=93), snd.at_frame(self.f_back - 4), -16, -0.5)
        # the crack: a sharp snap with a high tail
        snd.sfx(A.zap(94, dur=0.08, bright=1.4), snd.at_frame(self.f_slav), -13, -0.2)
        snd.sfx(A.swish(0.18, seed=96), snd.at_frame(self.f_slav - 2), -19, -0.2)


def make(ctx):
    return Shot(ctx)
