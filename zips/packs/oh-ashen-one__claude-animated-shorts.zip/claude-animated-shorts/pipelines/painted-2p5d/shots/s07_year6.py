"""Shot 7, Year 6: "There is still only one dragon."

No pose B: everything is animated in code. The dragon lifts its head a little (anticipation on 2s) and
lets out a slow ember breath on "one": glowing embers and dark smoke curl out of the nostrils and drift
over the empty nests, and a warm smoke plume rises from the nostrils and thins over 8 frames. Ash falls
through the whole frame on 2s. A painted counter on the lore tag rolls 3, 2, 1 and stops at 1 on "one"; as it
passes each number an empty nest is ringed with glowing brush embers (irregular dabs, no clean ellipse).
YEAR 6; "Dragons left: 1" (the counter is the number); small tag "Viserion: S7E6. Rhaegal: S8E4."
Coordinates are px of the upscaled key work/keys/g06_dragon_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS, WORK_SCALE
from whatif.fx2d import ShapeCanvas, screen_emissive, tapered_streak_poly
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("sky", 0.00, 0.10, fill="full"),
    L.PlaneSpec("cliffs", 0.10, 0.27, radius=60),
    L.PlaneSpec("dragon", 0.27, 0.52, radius=60),
    L.PlaneSpec("nests", 0.52, 1.01, radius=70),
]
NECK = (900, 1420)
NOSTRIL = (1250, 1552)                 # key px
SPRITES = [
    L.SpriteSpec("head", 2, [(905, 1150), (1180, 1130), (1300, 1380), (1310, 1600), (1120, 1640), (900, 1520)],
                 dmin=0.18, pivot=NECK, anchor=(1220, 1400, 920, 1400)),
]
# two empty nests that get marked as the count drops (key px centre, radius)
NESTS = [((1150, 1640), 105), ((1262, 1915), 150)]


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Ash:
    """Falling ash flecks in world space with parallax (positions on 2s). Not emissive: small grey-violet
    flakes that tumble (their width flickers) as they fall."""

    def __init__(self, n, W, H, seed=7):
        rng = np.random.default_rng(seed)
        self.p0 = np.stack([rng.uniform(0, W, n), rng.uniform(0, H, n)], 1)
        self.near = rng.uniform(0.05, 0.9, n)
        self.vel = np.stack([rng.uniform(10, 50, n), rng.uniform(40, 95, n)], 1) * (0.5 + self.near[:, None])
        self.size = rng.uniform(2.0, 4.2, n) * (0.5 + self.near)
        self.ph = rng.uniform(0, 6.3, n)
        self.light = rng.uniform(0.55, 0.95, n)
        self.W, self.H = W, H

    def draw(self, cam, t, img):
        lay = np.zeros(img.shape[:2], np.float32)
        tone = np.zeros(img.shape[:2], np.float32)
        for i in range(len(self.near)):
            p = self.p0[i] + self.vel[i] * t + np.array([math.sin(t * 1.3 + self.ph[i]) * 18, 0])
            p = np.array([p[0] % self.W, p[1] % self.H])
            q = cam.screen_point(p, self.near[i], t)
            s = self.size[i] * cam.scale_at(self.near[i], t) / 1.2
            wob = abs(math.cos(t * 4 + self.ph[i])) * 0.8 + 0.2
            ax = (max(1, int(s * wob)), max(1, int(s * 0.6)))
            cv2.ellipse(lay, (int(q[0]), int(q[1])), ax, (self.ph[i] * 57) % 180, 0, 360, 1.0, -1, cv2.LINE_AA)
            cv2.ellipse(tone, (int(q[0]), int(q[1])), ax, (self.ph[i] * 57) % 180, 0, 360, self.light[i], -1, cv2.LINE_AA)
        a = (lay * 0.8)[..., None]
        col = np.float32([0.62, 0.56, 0.62]) * np.clip(tone / np.maximum(lay, 1e-3), 0, 1)[..., None]
        return img * (1 - a) + col * a


class Breath:
    """Ember breath: embers streaming from the nostrils with drag and a slow rise, plus dark smoke puffs."""

    def __init__(self, f_start, seed=3, n=70):
        rng = np.random.default_rng(seed)
        self.f_start = f_start
        self.born = f_start - 2 + rng.uniform(0, 20, n)
        self.v = np.stack([rng.uniform(220, 640, n), rng.uniform(60, 420, n)], 1)
        self.size = rng.uniform(1.0, 2.1, n)
        self.ph = rng.uniform(0, 6.3, n)
        self.puffs = [(f_start - 2 + k * 2, rng.uniform(0.7, 1.2), rng.uniform(-0.5, 0.6)) for k in range(10)]

    def smoke(self, img, f, src, scale):
        fh = f - f % 2
        lay = np.zeros(img.shape[:2], np.float32)
        for fb, sz, dv in self.puffs:
            tau = (fh - fb) / FPS
            if tau < 0:
                continue
            c = (src[0] + (170 + 90 * dv) * tau * scale, src[1] + (110 + 80 * dv - 90 * tau) * tau * scale)
            r = (22 + 90 * tau) * sz * scale
            one = np.zeros_like(lay)
            cv2.ellipse(one, (int(c[0]), int(c[1])), (int(r * 1.3), int(r)), 20 * dv, 0, 360,
                        float(max(0.0, 0.5 - 0.3 * tau)), -1, cv2.LINE_AA)
            lay = lay + one * (1 - lay)
        if not lay.any():
            return img
        lay = cv2.GaussianBlur(lay, (0, 0), 10)
        lay = np.round(np.clip(lay, 0, 0.6) * 8) / 8 * 0.7 + lay * 0.3    # stepped, painted density
        a = lay[..., None]
        return img * (1 - a) + np.float32([0.22, 0.12, 0.20]) * a

    def embers(self, img, f, src, scale):
        fh = f - f % 2
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        drawn = False
        for i in range(len(self.born)):
            tau = (fh - self.born[i]) / FPS
            if tau < 0 or tau > 1.6:
                continue
            drag = (1 - math.exp(-tau * 1.4)) / 1.4
            x = src[0] + self.v[i, 0] * drag * scale + math.sin(tau * 5 + self.ph[i]) * 10
            y = src[1] + self.v[i, 1] * drag * scale - 45 * tau * tau * scale
            vel = (self.v[i, 0] * math.exp(-tau * 1.4), self.v[i, 1] * math.exp(-tau * 1.4) - 90 * tau)
            life = max(0.0, 1 - tau / 1.6)
            flick = 0.6 + 0.4 * math.sin(tau * 14 + self.ph[i] * 3)
            sc.fill(tapered_streak_poly((x, y), vel, 14 * self.size[i] * scale, 4.0 * self.size[i] * scale),
                    value=int(255 * life * flick))
            drawn = True
        if not drawn:
            return img
        c, g = sc.result(glow_sigma=4)
        return screen_emissive(img, c, g, (1.0, 0.78, 0.45), (1.0, 0.36, 0.10), opacity=1.0)


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_only = ctx.f("only")
        self.f_one = ctx.f("one")
        self.f_count0 = self.f_only                     # the counter rolls 3 -> 1 between "only" and "one"
        to = ctx.local(self.f_one)
        self.cam = ParallaxCamera(                        # camera on 1s: slow push toward the head
            W, H, focus=(W * 0.62, H * 0.55), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.06, "inout")]),
            push=Track([(0, 0.0), (d, 0.08, "inout")]),
            rise=Track([(0, 0.0), (to, -10.0, "inout"), (d, -16.0, "out")]),
            pan=Track([(0, 0.0), (d, -20.0, "inout")]))
        self.ash = Ash(70, W, H)
        self.breath = Breath(self.f_one)

    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    def _head(self, f):
        """Pose-to-pose on 2s: rest, lift (anticipation, breath in), push down and forward as it exhales,
        settle."""
        d = (f - f % 2) - self.f_one
        if d < -10:
            return 0.0, 0.0
        keys = {-10: (-0.6, -2.0), -8: (-1.4, -4.0), -6: (-2.2, -6.0), -4: (-2.6, -7.0), -2: (-2.0, -5.0),
                0: (1.4, 4.0), 2: (1.8, 5.0), 4: (1.6, 4.0)}
        return keys.get(d, (1.3, 3.0))

    def _count(self, f):
        """3 holds, rolls to 2, holds, rolls to 1 landing on "one" (sampled on 2s)."""
        fh = f - f % 2
        m1, m2 = self._marks
        if fh < m1:
            return float(O.roll_value(f, m1 - 4, m1, 3.0, 2.0)) if fh >= m1 - 4 else 3.0
        if fh < m2:
            return float(O.roll_value(f, m2 - 4, m2, 2.0, 1.0)) if fh >= m2 - 4 else 2.0
        return 1.0

    @cached_property
    def _marks(self):
        """Frames where the counter lands on 2 and on 1 (the second is the sync word "one")."""
        m1 = (self.f_count0 + self.f_one) // 2
        return m1 - m1 % 2, self.f_one

    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            mine = [s for s in self.lay.sprites if s["plane"] == i]
            if mine:
                rgb, a = rgb.copy(), a.copy()
                ang, dy = self._head(f)
                for s in mine:
                    patch, x0, y0 = deform_sprite(s, angle_deg=-ang, dy=dy)
                    composite_into(rgb, a, patch, x0, y0)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        ang, dy = self._head(f)
        src = self.cam.screen_point((NOSTRIL[0] * WORK_SCALE, (NOSTRIL[1] + dy * 2.5) * WORK_SCALE), 0.4, th)
        scale = self.cam.scale_at(0.4, th)
        img = self.breath.smoke(img, f, src, scale)
        img = self._plume(img, f, src, scale)
        img = self._nest_marks(img, f, th)
        img = self.breath.embers(img, f, src, scale)
        img = self._nostril_glow(img, f, src)
        img = self.ash.draw(self.cam, th, img)
        self.draw_year_tag(img, f)
        self._tags(img, f)
        return img, {"count": self._count(f)}

    def _nostril_glow(self, img, f, src):
        d = (f - f % 2) - self.f_one
        k = {-4: 0.25, -2: 0.5, 0: 1.0, 2: 0.9, 4: 0.75, 6: 0.6}.get(d, 0.45 if d > 6 else 0.0)
        if k <= 0:
            return img
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        r = 6 + 5 * k
        sc.fill([(src[0] + r * math.cos(a), src[1] + 0.6 * r * math.sin(a)) for a in np.linspace(0, 6.28, 16)])
        c, g = sc.result(glow_sigma=14)
        return screen_emissive(img, c * k * 0.6, g * k, (1.0, 0.55, 0.25), (1.0, 0.28, 0.06))

    @cached_property
    def _dabs(self):
        """Per nest: 18 brush embers scattered along the ring (angle, radial and vertical jitter, size,
        elongation, rotation, brightness), fixed per nest so the mark holds its shape between drawings."""
        out = []
        for k in range(len(NESTS)):
            rng = np.random.default_rng(90 + k)
            n = 18
            ang = -2.6 + np.sort(rng.uniform(0, 5.9, n))
            out.append(dict(ang=ang, rad=rng.uniform(0.92, 1.18, n), dy=rng.uniform(-0.12, 0.12, n),
                            size=rng.uniform(4.0, 12.0, n), elong=rng.uniform(1.0, 2.6, n),
                            rot=rng.uniform(0, math.pi, n), val=rng.uniform(0.35, 1.0, n),
                            wob=rng.uniform(0, 6.3, (n, 7))))
        return out

    def _nest_marks(self, img, f, th):
        """Embers are dabbed round an empty nest each time the counter passes a number: 18 irregular glowing
        brush dabs on 2s (no clean ellipse), appearing round the ring in 3 drawings, flickering on 2s."""
        fh = f - f % 2
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        drawn = False
        for k, ((cx, cy), r) in enumerate(NESTS):
            fm = self._marks[k]
            if fh < fm:
                continue
            u = min(1.0, (fh - fm + 2) / 6)
            q = self.cam.screen_point((cx * WORK_SCALE, cy * WORK_SCALE), 0.75, th)
            s = self.cam.scale_at(0.75, th) * WORK_SCALE
            D = self._dabs[k]
            fr = np.random.default_rng(1000 * k + fh)            # flicker, new every drawing
            n = len(D["ang"])
            for i in range(int(round(n * u))):
                a_ = D["ang"][i]
                px = q[0] + r * s * 1.12 * D["rad"][i] * math.cos(a_)
                py = q[1] + r * s * (0.5 * D["rad"][i] + D["dy"][i]) * math.sin(a_) + D["dy"][i] * r * s * 0.3
                sz = D["size"][i] * s * (0.85 + 0.3 * fr.uniform())
                rot = D["rot"][i]
                wob = D["wob"][i]
                pts = []
                for j, t_ in enumerate(np.linspace(0, 2 * math.pi, 7, endpoint=False)):
                    rr = sz * (0.65 + 0.35 * math.sin(wob[j]))
                    ex, ey = rr * D["elong"][i] * math.cos(t_), rr * math.sin(t_)
                    pts.append((px + ex * math.cos(rot) - ey * math.sin(rot), py + ex * math.sin(rot) + ey * math.cos(rot)))
                v = D["val"][i] * (0.7 + 0.3 * fr.uniform())
                sc.fill(pts, value=int(255 * v))
                drawn = True
        if not drawn:
            return img
        c, g = sc.result(glow_sigma=6)
        return screen_emissive(img, c * 0.95, g * 0.9, (1.0, 0.68, 0.36), (0.95, 0.28, 0.07))

    def _plume(self, img, f, src, scale):
        """The ember breath made visible: warm smoke puffs leave the nostrils on "one" (one new puff per
        drawing for 8 frames); each rises, swells and thins over 8 frames on 2s, lit warm near the nostril
        and cooling to ash grey as it rises."""
        fh = f - f % 2
        lay = np.zeros(img.shape[:2], np.float32)
        warm = np.zeros(img.shape[:2], np.float32)
        rng = np.random.default_rng(55)
        for k in range(5):
            fb = self.f_one + 2 * k
            age = fh - fb
            jx, jy, js = rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(0.85, 1.2)
            if age < 0 or age > 10:
                continue
            u = age / 10.0
            cx = src[0] + (24 + 70 * u + 20 * jx) * scale
            cy = src[1] + (-16 - 250 * u + 16 * jy) * scale
            r = (40 + 130 * u) * js * scale
            al = (1 - u) ** 1.1 * 0.95
            one = np.zeros_like(lay)
            cv2.ellipse(one, (int(cx), int(cy)), (int(r * 1.25), int(r)), -25 + 30 * jx, 0, 360, 1.0, -1, cv2.LINE_AA)
            lay = np.maximum(lay, one * al)
            warm = np.maximum(warm, one * al * (1 - u) ** 2)
        if not lay.any():
            return img
        n = L.brush_noise(lay.shape, 13 + fh // 2, scale=6, angle=-0.9, stretch=3)
        lay = cv2.GaussianBlur(lay, (0, 0), 14) * (0.75 + 0.25 * n)
        warm = cv2.GaussianBlur(warm, (0, 0), 18)
        lay = np.round(np.clip(lay, 0, 0.85) * 10) / 10 * 0.6 + lay * 0.4     # stepped, painted density
        col = np.float32([0.46, 0.34, 0.36])[None, None] * (1 - warm[..., None]) + \
            np.float32([1.0, 0.56, 0.28])[None, None] * warm[..., None]
        a = lay[..., None]
        out = img * (1 - a) + col * a
        return 1 - (1 - out) * (1 - np.float32([1.0, 0.45, 0.15]) * (warm[..., None] * 0.6))

    @cached_property
    def _tag_base(self):
        return O.data_tag("Dragons left:", size=44)

    def _tags(self, img, f):
        x, y = O.tag_slots()["data"]
        base = self._tag_base
        f_in = self.f0 + 4
        O.draw_pop(img, base, x, y, f, f_in)
        fh = f - f % 2
        if fh >= f_in + 2:
            v = self._count(f) if fh >= self.f_count0 else 3.0
            ctr = O.counter_rgba(v, fmt="{:.0f}", size=84, decimals=0, roll=True, seed=7)
            cy = y + base.shape[0] / 2 - ctr.shape[0] / 2 - 4
            O.draw_pop(img, ctr, x + base.shape[1] - 6, cy, f, f_in + 2, glow=(1.0, 0.45, 0.15) if fh >= self.f_one else None)
        O.draw_pop(img, O.data_tag("Viserion: S7E6. Rhaegal: S8E4.", size=30), x, y + base.shape[0] + 6, f,
                   self.f_only)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.65}

    def events(self):
        m = self._marks
        return [(self.f0 + 4, "count_3", {}), (m[0], "nest_mark", {}), (m[1], "nest_mark", {}),
                (self.f_one - 10, "head_lift", {}), (self.f_one, "ember_breath", {})]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        wind = A.bandpass(A.noise(dur + 1.0, 71, "pink"), 120, 900)
        snd.bed(wind / (np.abs(wind).max() + 1e-6), t0 - 0.3, -28)
        snd.bed(A.drone(dur + 1.0, seed=72), t0 - 0.3, -34)
        # breath in (rising filtered noise) then a long low exhale with ember crackle
        n_in = int(0.4 * A.SR)
        inhale = A.bandpass(A.noise(0.4, 73, "pink"), 200, 1400) * np.linspace(0, 1, n_in) ** 2
        snd.sfx(inhale, snd.at_frame(self.f_one - 10), -24, 0.3)
        ex = A.lowpass(A.noise(1.6, 74, "brown"), 380)
        env = np.minimum(np.linspace(0, 1, len(ex)) * 8, 1) * np.exp(-np.linspace(0, 1.6, len(ex)) / 0.9)
        snd.sfx(ex * env / (np.abs(ex).max() + 1e-6), snd.at_frame(self.f_one), -14, 0.3)
        rng = np.random.default_rng(75)
        for k in range(10):
            snd.sfx(A.tick(76 + k, rng.uniform(1800, 4200)), snd.at_frame(self.f_one) + rng.uniform(0.05, 0.9), -32,
                    rng.uniform(0.0, 0.6))
        for k, (fr, kind, _) in enumerate(self.events()):
            if kind == "nest_mark":
                snd.sfx(A.thunk(seed=80 + k), snd.at_frame(fr), -24, 0.3)
                snd.sfx(A.tick(82 + k, 2600), snd.at_frame(fr), -26, -0.5)
        snd.sfx(A.tick(85, 2000), snd.at_frame(self.f_one), -24, -0.5)


def make(ctx):
    return Shot(ctx)
