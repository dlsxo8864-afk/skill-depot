"""Shot 13, the CTA: "So would you have let her keep the throne, or taken it from her anyway?"

Point of view at the foot of the two thrones: our right hand holds a crown, our left a dagger. The crown
hand lifts on "keep" and the dagger hand on "taken" (pose B painting, split down the middle so each hand
moves on its own word: anticipation dip, one in-between, then the hold), and both hold. The question is
lettered large in the empty sky above the thrones, line by line with the narration; "KEEP HER" lands
under the crown arm when it lifts, "TAKE IT" under the dagger arm. The fan-fiction chip sits top-left.
Every move settles by the last word; the last 2.25 s are a still hold with only the braziers breathing.
Coordinates are px of the upscaled key work/keys/g12_cta_key.png (1520 x 2701).
"""
from functools import cached_property

import cv2
import numpy as np
from PIL import Image, ImageDraw

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera
from whatif.config import FPS, WORK_SCALE, safe_box
from whatif.fx2d import ShapeCanvas, screen_emissive, star4_poly
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]
SC = WORK_SCALE
CREAM, EMBER, GOLD, STEEL = O.CREAM, O.EMBER, (255, 204, 96), (214, 222, 240)

PLANES = [
    L.PlaneSpec("sky", 0.00, 0.06, fill="full"),
    L.PlaneSpec("thrones", 0.06, 0.28, radius=60),
    L.PlaneSpec("hands", 0.28, 1.01, radius=80),
]
# pose B regions (key px): the split runs between the dagger blade (x <= 690) and the crown (x >= 720)
SPLIT_X = 706
DAGGER = [(0, 1040), (SPLIT_X, 1040), (SPLIT_X, 2701), (0, 2701)]
CROWN = [(SPLIT_X, 1150), (1520, 1150), (1520, 2701), (SPLIT_X, 2701)]
GLINT_CROWN = (1000, 1335)          # the crown's centre gem in pose B (key px)
GLINT_BLADE = (668, 1180)           # high on the dagger blade in pose B
# hand + object + sleeve outlines in each pose (key px, generous; refined by where the paintings differ)
# for the drawn in-betweens: the incoming arm slides in from halfway, the outgoing one dips first
ARMS = {
    "crown": {"A": [(690, 1790), (1000, 1770), (1370, 1870), (1390, 2000), (1350, 2200), (1500, 2560), (1520, 2701),
                    (1010, 2701), (950, 2500), (840, 2350), (750, 2200), (690, 2080)],
              "B": [(712, 1290), (900, 1200), (1150, 1180), (1330, 1250), (1330, 1450), (1280, 1600), (1330, 1780),
                    (1520, 2070), (1520, 2701), (1070, 2701), (1020, 2200), (970, 1900), (850, 1690), (750, 1570),
                    (712, 1450)],
              "D": (-15, -560)},
    "dagger": {"A": [(560, 1630), (670, 1630), (650, 1900), (620, 2080), (610, 2200), (570, 2400), (490, 2620),
                     (390, 2701), (0, 2701), (0, 2370), (110, 2190), (320, 2070), (470, 2040)],
               "B": [(640, 1070), (725, 1080), (700, 1300), (700, 1500), (670, 1700), (630, 1910), (530, 1970),
                     (450, 2100), (410, 2400), (340, 2701), (0, 2701), (0, 1990), (150, 1840), (370, 1690),
                     (410, 1500), (490, 1410), (585, 1370)],
               "D": (80, -660)},
}


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def _line_rgba(text, size, color, seed, max_w):
    fnt = T.font("display", size)
    tw, th, ox, oy = T.text_size(fnt, text)
    if tw > max_w:
        fnt = T.font("display", int(size * max_w / tw))
        tw, th, ox, oy = T.text_size(fnt, text)
    a = O._text_alpha(text, fnt)
    rgba, pad = T.styled_text_rgba(a, color, seed=seed, shadow_off=(4, 6), soft_shadow=12,
                                   grad=0.12 if color == CREAM else 0.18)
    return rgba, pad, th


def _label(text, color, seed, pointer_x):
    """A big answer label: display type on a painted plum chip, with a small painted pointer on top
    (at pointer_x, 0..1 of the chip width) aiming up at its hand."""
    a = O._text_alpha(text, T.font("display", 84), min_cap=52)
    t_rgba, pad = T.styled_text_rgba(a, color, seed=seed, shadow_off=(2, 4), soft_shadow=6, shadow_strength=0.6,
                                     grad=0.14)
    w, h = a.shape[1] + 64, a.shape[0] + 34
    chip = O.painted_chip(w, h, seed=seed + 1)
    tip = 34
    canvas = np.zeros((h + tip + 20, w + 20, 4), np.float32)
    tri = Image.new("L", (w + 20, tip + 4), 0)
    cx = int(10 + pointer_x * w)
    ImageDraw.Draw(tri).polygon([(cx - 26, tip + 4), (cx + 26, tip + 4), (cx, 0)], fill=255)
    tri = np.asarray(tri, np.float32) / 255
    sw = O.painted_swatch(w + 20, tip + 4, seed=seed + 2, color=O.PLUM, opacity=0.86, rough=0.2, radius=1)
    sw = sw.copy()
    sw[..., 3] *= tri
    T.over_rgba(canvas, sw, 0, 0)
    T.over_rgba(canvas, chip, 8, tip)
    T.over_rgba(canvas, t_rgba, 8 + 32 - pad, tip + 17 - pad)
    return canvas


class Shot(BaseShot):
    transition = False                       # the episode's last shot: nothing is cut after it

    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, [])
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        self.f_keep = ctx.f("keep")
        self.f_or = ctx.f("or")
        self.f_taken = ctx.f("taken")
        self.f_from = ctx.f("from")
        self.f_last = ctx.f("anyway?", at="e", even=False)
        t_settle = ctx.local(self.f_last)
        # camera on 1s: a slow push toward the thrones that lands (ease out) on the last word, then stops
        self.cam = ParallaxCamera(
            W, H, nearness=nearness, focus=Track([(0, (W * 0.5, H * 0.52)), (t_settle, (W * 0.5, H * 0.49), "out")]),
            zoom=Track([(0, 1.0), (t_settle, 1.045, "out")]),
            push=Track([(0, 0.0), (t_settle, 0.035, "out")]),
            rise=Track([(0, 0.0), (t_settle, -10.0, "out")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=[DAGGER, CROWN])
        self.swaps = {"crown": [(self.f_keep, "B")], "dagger": [(self.f_taken, "B")]}

    # ------------------------------------------------------------ prepared
    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    @cached_property
    def sides(self):
        """Per-pixel weights (work scale) for the crown side and the dagger side of the pose B mask."""
        H, W = self.lay.H, self.lay.W
        x = np.arange(W, dtype=np.float32)[None, :].repeat(H, 0)
        crown = np.clip((x - SPLIT_X * SC) / 6.0 + 0.5, 0, 1).astype(np.float32)
        return {"crown": crown, "dagger": (1 - crown).astype(np.float32)}

    @cached_property
    def arms(self):
        """Per side: arm masks in pose A and pose B (polygon x where the two paintings differ), the clean
        plate with neither arm (A, with B's background where A's arm was) and the lift vector (work px)."""
        A0, B0 = self.pose.a_img, self.pose.b
        H, W = A0.shape[:2]
        la = cv2.cvtColor(A0, cv2.COLOR_RGB2LAB)
        lb = cv2.cvtColor(B0, cv2.COLOR_RGB2LAB)
        diff = cv2.GaussianBlur(np.sqrt((((la - lb) * np.float32([1.0, 0.6, 0.6])) ** 2).sum(2)), (0, 0), 3)
        dm = np.clip((diff - 7.0) / 6.0, 0, 1)
        out = {}
        for side, spec in ARMS.items():
            ms = {}
            for p in ("A", "B"):
                poly = np.zeros((H, W), np.float32)
                cv2.fillPoly(poly, [np.round(np.float32(spec[p]) * SC).astype(np.int32)], 1.0)
                m = cv2.morphologyEx((poly * dm > 0.5).astype(np.uint8), cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
                ff = m.copy()                                         # fill holes: an arm is a solid shape
                cv2.floodFill(ff, np.zeros((H + 2, W + 2), np.uint8), (0, 0), 1)
                m = (m | (1 - ff)).astype(np.float32) * poly
                ms[p] = cv2.GaussianBlur(m, (0, 0), 1.5)
            grown = cv2.GaussianBlur(cv2.dilate((ms["A"] > 0.2).astype(np.uint8), np.ones((15, 15), np.uint8))
                                     .astype(np.float32), (0, 0), 2.5)
            mA = (grown * self.sides[side])[..., None]               # a margin, so no rim of A's crown stays
            clean = A0 * (1 - mA) + B0 * mA
            # where B's arm crosses A's arm neither painting shows the background: fill it from around
            gB = cv2.dilate((ms["B"] > 0.2).astype(np.uint8), np.ones((15, 15), np.uint8)).astype(np.float32)
            both = cv2.GaussianBlur(np.minimum(grown, gB) * self.sides[side], (0, 0), 2.5)
            filled = L.push_pull_fill(clean, (both < 0.05).astype(np.float32))
            nz = L.brush_noise((H, W), 61 if side == "crown" else 62, scale=3, angle=0.5, stretch=7)[..., None]
            clean = clean * (1 - both[..., None]) + filled * (1 + 0.05 * nz) * both[..., None]
            out[side] = {"mA": ms["A"], "mB": ms["B"], "clean": clean.astype(np.float32),
                         "D": np.float32(spec["D"]) * SC}
        return out

    def _inbetween(self, side, st):
        """The drawn in-betweens (work scale): "antAB" = pose A's arm dipping away from the lift (7 %, a
        touch squashed), "AB" = pose B's arm drawn 45 % of the way back down, slightly stretched along the
        move. Returns (rgb, alpha mask) to lay over the nearest plane."""
        ar = self.arms[side]
        A0, B0 = self.pose.a_img, self.pose.b
        H, W = A0.shape[:2]
        D = ar["D"]
        if st == "antAB":
            spr, m, k, sy = A0, ar["mA"], -0.07, 0.97
        else:
            spr, m, k, sy = B0, ar["mB"], 0.55, 1.06
        sh = -D * (1 - k) if st == "AB" else -D * (-k)
        # shift + vertical scale about the arm's top (stretch toward the lift / squash in the dip)
        ys = np.nonzero(m.max(1) > 0.5)[0]
        top = float(ys.min()) if len(ys) else 0.0
        Mt = np.float32([[1, 0, sh[0]], [0, sy, top * (1 - sy) + sh[1]]])
        rgba = np.dstack([spr, m]).astype(np.float32)
        w = cv2.warpAffine(rgba, Mt, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        wa = w[..., 3:4]
        src = ar["clean"] * (1 - wa) + w[..., :3] * wa
        M = np.maximum(np.maximum(ar["mA"], ar["mB"]), w[..., 3])
        M = cv2.GaussianBlur(cv2.dilate(M, np.ones((9, 9), np.uint8)), (0, 0), 3) * self.sides[side]
        return src.astype(np.float32), np.clip(M, 0, 1).astype(np.float32)

    @cached_property
    def flames(self):
        out = []
        for pl in self.planes:
            rgb = pl["rgb"]
            m = ((rgb.max(2) > 0.78) & (rgb[..., 0] > rgb[..., 2] + 0.25)).astype(np.float32) * pl["a"]
            out.append(cv2.GaussianBlur(cv2.dilate(m, np.ones((9, 9), np.uint8)), (0, 0), 10) if m.any() else None)
        return out

    @cached_property
    def flicker(self):
        rng = np.random.default_rng(13)
        H, W = self.lay.H, self.lay.W
        return [cv2.resize(rng.standard_normal((H // 80 + 2, W // 80 + 2)).astype(np.float32), (W, H),
                           interpolation=cv2.INTER_CUBIC) for _ in range(6)]

    @cached_property
    def title(self):
        """The question in four lines, lettered in the sky above the thrones (above both faces)."""
        x0, y0, x1, y1 = safe_box()
        mw = x1 - x0
        out = []
        y = y0 + 66
        spec = [("SO WOULD YOU HAVE LET HER", 66, CREAM, 8, self.f0 + 2),
                ("KEEP THE THRONE,", 120, GOLD, 8, self.f_keep),
                ("OR TAKEN IT", 120, EMBER, 6, self.f_or),
                ("FROM HER ANYWAY?", 66, CREAM, 0, self.f_from)]
        for k, (text, size, color, gap, f_in) in enumerate(spec):
            rgba, pad, th = _line_rgba(text, size, color, seed=40 + k, max_w=mw)
            out.append({"rgba": rgba, "x": x0 - pad, "y": y - pad, "f_in": f_in, "text": text})
            y += th + gap + 14
        self.title_bottom = y
        return out

    @cached_property
    def labels(self):
        x0, y0, x1, y1 = safe_box()
        keep = _label("KEEP HER", GOLD, 60, 0.62)
        take = _label("TAKE IT", STEEL, 70, 0.40)
        yl = y1 - keep.shape[0] - 6
        return [{"rgba": take, "x": x0 - 4, "y": yl, "f_in": self.f_taken + 2, "text": "TAKE IT"},
                {"rgba": keep, "x": x1 - keep.shape[1] + 6, "y": yl, "f_in": self.f_keep + 2, "text": "KEEP HER"}]

    # ------------------------------------------------------------ frame
    def _states(self, f):
        if not self.pose:
            return {"crown": "A", "dagger": "A"}
        return {k: PoseSwap.state(f, v) for k, v in self.swaps.items()}

    def frame(self, f):
        t = self.ctx.local(f)
        fh = f - f % 2
        sts = self._states(f)
        z = self.flicker[(fh // 2) % len(self.flicker)]
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            fl = self.flames[i]
            if fl is not None:                                       # braziers breathe on 2s
                rgb = rgb * (1 + fl[..., None] * (0.10 * np.tanh(z)[..., None] - 0.02))
            if self.pose and i >= 1:
                a0 = a
                for side in ("crown", "dagger"):
                    st = sts[side]
                    if st == "A":
                        continue
                    sw = self.sides[side]
                    if st in ("antAB", "AB"):                    # drawn in-between, nearest plane only
                        if i == len(self.planes) - 1:
                            src, M = self._inbetween(side, st)
                            rgb = rgb * (1 - M[..., None]) + src * M[..., None]
                            a = np.maximum(a, M)
                        continue
                    n = n * (1 - sw) + self.pose.nearness(n, a0, st) * sw
                    rgb, a = self.pose.apply(rgb, a, st, mask_scale=sw)
            rps.append({"rgb": rgb.astype(np.float32), "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._glints(img, f, t)
        self._overlays(img, f)
        return img, {"crown": sts["crown"], "dagger": sts["dagger"]}

    def _glints(self, img, f, t):
        """A drawn 4-point glint where each object lands (crown gem, dagger blade), three drawings on 2s."""
        fh = f - f % 2
        for f_on, p, col, glow in [(self.f_keep, GLINT_CROWN, (1.0, 0.95, 0.80), (1.0, 0.70, 0.30)),
                                   (self.f_taken, GLINT_BLADE, (0.95, 0.97, 1.0), (0.60, 0.70, 1.0))]:
            d = fh - f_on
            if d not in (0, 2, 4):
                continue
            q = self.cam.screen_point((p[0] * SC, p[1] * SC), float(nearness(np.float32(0.42))), t)
            sc = ShapeCanvas(img.shape[1], img.shape[0])
            sc.fill(star4_poly(q, {0: 46, 2: 30, 4: 14}[d], 0.25 + 0.3 * d))
            c, g = sc.result(glow_sigma=7)
            img = screen_emissive(img, c, g, col, glow, opacity=1.0 - 0.15 * d / 2)
        return img

    def _overlays(self, img, f):
        x0, y0, _, _ = safe_box()
        O.draw_pop(img, O.fan_tag(), x0 - 6, y0 - 14, f, self.f0 + 2)
        glow = (0.42, 0.30, 0.70)
        for it in self.title:
            hot = it["text"].startswith(("KEEP", "OR"))
            O.draw_pop(img, it["rgba"], it["x"], it["y"], f, it["f_in"], origin=(30, it["rgba"].shape[0] / 2),
                       glow=(0.9, 0.55, 0.2) if hot else glow)
        for lb in self.labels:
            O.draw_pop(img, lb["rgba"], lb["x"], lb["y"], f, lb["f_in"],
                       origin=(lb["rgba"].shape[1] / 2, lb["rgba"].shape[0] / 2), glow=(0.9, 0.55, 0.2))

    # ------------------------------------------------------------ framework hooks
    def finish_args(self, f, info):
        return {"bloom_strength": 0.45, "vignette": 0.34}

    def events(self):
        ev = [(self.f0 + 2, "fan_tag+line1", {})]
        ev += [(it["f_in"], "line", {"text": it["text"]}) for it in self.title[1:]]
        ev += [(self.f_keep - 4, "crown_anticipation", {}), (self.f_keep, "crown_up", {}),
               (self.f_taken - 4, "dagger_anticipation", {}), (self.f_taken, "dagger_up", {})]
        ev += [(lb["f_in"], "label", {"text": lb["text"]}) for lb in self.labels]
        ev.append((self.f_last + 1, "hold_from", {"hold_s": round((self.f1 - self.f_last - 1) / FPS, 2)}))
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tt = A.t_axis(dur + 0.6)
        snd.bed(A.room_tone(dur + 0.6, seed=131), t0 - 0.2, -30)
        crackle = A.highpass(A.noise(dur + 0.6, 132), 1800) * (A.noise(dur + 0.6, 133) > 2.7)
        fire = A.lowpass(A.noise(dur + 0.6, 134, "pink"), 450) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.6 * tt))
        snd.bed(0.6 * fire + 0.5 * crackle, t0 - 0.2, -31, 0.0)
        snd.sfx(A.thunk(135), snd.at_frame(self.f0 + 2), -26)
        # crown lifts: cloth swish, then a gold shimmer as it lands (right side)
        snd.sfx(A.swish(0.24, seed=136), snd.at_frame(self.f_keep - 4), -20, 0.4)
        shimmer = sum(A.bell(fq, 1.2, seed=137 + k) * g for k, (fq, g) in enumerate([(1318.5, 1.0), (1975.5, 0.6), (2637.0, 0.35)]))
        snd.sfx(shimmer, snd.at_frame(self.f_keep), -24, 0.45)
        # dagger lifts: swish, then a steel ring (left side)
        snd.sfx(A.swish(0.24, seed=140), snd.at_frame(self.f_taken - 4), -19, -0.4)
        snd.sfx(_steel(0.9, seed=141), snd.at_frame(self.f_taken), -20, -0.45)
        for lb in self.labels:
            snd.sfx(A.tick(142, 2400), snd.at_frame(lb["f_in"]), -24, 0.4 if lb["text"] == "KEEP HER" else -0.4)
        snd.sfx(A.hit(seed=143), snd.at_frame(self.f_from), -22)
        snd.sfx(A.bell(196.0, 2.4, seed=144) + 0.5 * A.bell(293.7, 2.4, seed=145), snd.at_frame(self.f_from), -25)


def _steel(dur, seed):
    """A blade being drawn: a bright noise sweep into a thin metallic ring."""
    tt = A.t_axis(dur)
    sweep = A.bandpass(A.noise(dur, seed), 2500, 9000) * np.clip(1 - tt / 0.18, 0, 1) * np.clip(tt / 0.03, 0, 1)
    ring = (A.bell(2093.0, dur, seed=seed + 1) + 0.6 * A.bell(3136.0, dur, seed=seed + 2)) * 0.8
    x = 0.8 * sweep + ring[: len(sweep)]
    return (x / (np.abs(x).max() + 1e-9)).astype(np.float32)


def make(ctx):
    return Shot(ctx)
