"""Shot 6, Year 5: "Bran goes to the Citadel, not the throne, and writes a history that embarrasses almost
everyone."

Pages burst upward out of the open book on "writes" (code-drawn sheets tumbling on 2s); one page rises
and hangs in the air in front of the stair window: its title band is blank, then "Fire & Blood" lettering
fades in on "history"; the lords recoil (pose B: heads back, mouths open) on "embarrasses". Candles
flicker and dust drifts in the window light on 2s. YEAR 5; the lore tag "Bran can see any moment of the
past" while Bran's line starts, then the small tag "Fire and Blood: the words of House Targaryen" from
"history" (one tag on screen at a time). The hanging page curls at its outer edge (cylinder shading, a lit
rim, a folded corner, a wavy hem) and throws a soft shadow, so it reads as paper.
Coordinates are px of the upscaled key work/keys/g05_bran_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera
from whatif.config import FPS, WORK_SCALE
from whatif.fx2d import Embers
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("library", 0.00, 0.12, fill="full"),
    L.PlaneSpec("lords", 0.12, 0.31, radius=60),
    L.PlaneSpec("bran", 0.31, 0.56, radius=60),
    L.PlaneSpec("desk", 0.56, 1.01, radius=70),
]
SPRITES = []
# the three standing lords (and the loose pages around them); Bran's head and shoulders are cut out
RECOIL = [(230, 880), (1520, 860), (1520, 1720), (1180, 1720), (1000, 1560), (880, 1450), (760, 1290),
          (640, 1240), (470, 1270), (380, 1330), (330, 1200), (250, 1120)]
BOOK = (1080, 1900)                     # open book on the lectern (key px), where the pages burst from
TITLE_HOLD = (700, 520)                 # output px, centre of the hanging title page (above the lords)
PAPER = np.float32([0.93, 0.81, 0.66])
INK = np.float32([0.30, 0.10, 0.08])
PAGE_PAD = 44                           # px around the hanging page for its shadow
SHADOW = np.float32([0.10, 0.05, 0.14])


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def _gasp(dur=0.6, seed=0):
    """A small crowd's sharp intake of breath: band-passed noise, quick attack, breathy decay."""
    n = int(dur * A.SR)
    x = A.bandpass(A.noise(dur, seed, "pink"), 500, 3200)
    t = np.arange(n) / A.SR
    env = np.clip(t / 0.05, 0, 1) * np.exp(-np.maximum(t - 0.05, 0) / 0.18)
    return x * env / (np.abs(x).max() + 1e-6)


def _flutter(dur=0.9, seed=0):
    """Paper flurry: a run of short dry rustles."""
    rng = np.random.default_rng(seed)
    out = np.zeros(int(dur * A.SR))
    for k in range(14):
        s = A.swish(rng.uniform(0.05, 0.12), seed=seed + k) * rng.uniform(0.4, 1.0)
        i = int(rng.uniform(0, dur * 0.8) * A.SR)
        out[i:i + len(s)] += s[: len(out) - i]
    return out / (np.abs(out).max() + 1e-6)


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_and = ctx.f("and")
        self.f_writes = ctx.f("writes")
        self.f_history = ctx.f("history")
        self.f_emb = ctx.f("embarrasses")
        self.f_title = self.f_history + 4                 # the lettering starts to come up on the page
        tw, te = ctx.local(self.f_writes), ctx.local(self.f_emb)
        self.cam = ParallaxCamera(                         # camera on 1s: slow push, a lift as pages burst
            W, H, focus=(W * 0.52, H * 0.50), nearness=nearness,
            zoom=Track([(0, 1.0), (te, 1.05, "inout"), (d, 1.075, "out")]),
            push=Track([(0, 0.0), (d, 0.09, "inout")]),
            rise=Track([(0, 0.0), (tw - 0.05, -6.0, "inout"), (tw + 0.25, 14.0, "out"), (d, 30.0, "inout")]),
            pan=Track([(0, 0.0), (d, -14.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=RECOIL, thresh=14.0)
        self.swaps = [(self.f_emb, "B")]
        rng = np.random.default_rng(61)
        n = 15
        self.pages = [dict(f=self.f_writes + 2 * (i % 4), vx=rng.uniform(-760, 760), vy=rng.uniform(-2600, -1700),
                           w=rng.uniform(70, 135), spin=rng.uniform(5, 11) * rng.choice([-1, 1]),
                           rot=rng.uniform(-40, 40), rs=rng.uniform(-260, 260), ph=rng.uniform(0, 6.3))
                      for i in range(n)]

    # ---------------------------------------------------------------- layers
    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    @cached_property
    def flames(self):
        """Per-plane candle-flame weight (bright warm pixels, softened) for the flicker on 2s."""
        out = []
        for pl in self.planes:
            rgb = pl["rgb"]
            lum = rgb.max(2)
            m = ((lum > 0.80) & (rgb[..., 0] > rgb[..., 2] + 0.15)).astype(np.float32) * pl["a"]
            out.append(cv2.GaussianBlur(cv2.dilate(m, np.ones((9, 9), np.uint8)), (0, 0), 9) if m.any() else None)
        return out

    @cached_property
    def flicker(self):
        """A few smooth noise fields; each held frame picks one (candles flicker independently)."""
        rng = np.random.default_rng(5)
        H, W = self.lay.H, self.lay.W
        fields = []
        for _ in range(6):
            z = cv2.resize(rng.standard_normal((H // 90 + 2, W // 90 + 2)).astype(np.float32), (W, H),
                           interpolation=cv2.INTER_CUBIC)
            fields.append(z)
        return fields

    @cached_property
    def _yy(self):
        from whatif.config import OUT_H, OUT_W
        return np.mgrid[0:OUT_H, 0:OUT_W][0].astype(np.float32)

    @cached_property
    def _tex(self):
        from whatif.config import OUT_H, OUT_W
        return L.brush_noise((OUT_H, OUT_W), 77, scale=3, angle=-0.6, stretch=5)[..., None]

    @cached_property
    def dust(self):
        return Embers(26, self.lay.W, self.lay.H, seed=19, y_range=(0.1, 0.75), n_range=(0.1, 0.4))

    @cached_property
    def title_page(self):
        """The hanging page: paper with tooth, ruled border, a title band; and the lettering alpha. The
        sheet curls toward its outer edge (cylinder shading with a lit rim), its hem waves, the lower outer
        corner is folded over (darker back of the sheet), and it carries a soft violet drop shadow.
        Returns rgb, page alpha, lettering alpha and shadow alpha, all padded by PAGE_PAD."""
        w, h = 330, 236
        tooth = T.paper_tooth(h, w, seed=8)[..., None]
        yy = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
        xx = np.linspace(0, 1, w, dtype=np.float32)[None, :, None]
        u = np.clip((xx - 0.60) / 0.12, 0, 1)                   # painted two-tone curl: a shade band ...
        curl = 1.0 - 0.30 * u * u * (3 - 2 * u) - 0.10 * np.clip((xx - 0.72) / 0.28, 0, 1)
        curl = curl + 0.30 * np.exp(-((xx - 0.968) / 0.016) ** 2)                      # ... and a lit rim
        curl = curl * (0.94 + 0.06 * np.clip(xx / 0.12, 0, 1))                         # left edge in shade
        rgb = PAPER * (1 + 0.05 * tooth) * (0.92 + 0.10 * yy) * curl
        a = np.zeros((h, w), np.float32)
        pts = np.float32([[6, 10], [w - 8, 4], [w - 4, h - 12], [10, h - 6]])
        cv2.fillPoly(a, [np.round(pts * 8).astype(np.int32)], 1.0, cv2.LINE_AA, shift=3)
        rule = np.zeros((h, w), np.float32)
        cv2.polylines(rule, [np.round((pts + [[14, 14], [-14, 14], [-14, -14], [14, -14]]) * 8).astype(np.int32)],
                      True, 1.0, 2, cv2.LINE_AA, shift=3)
        for yl in (172, 186, 200):                          # faint text lines under the title
            cv2.line(rule, (40, yl), (w - 44, yl), 0.45, 2, cv2.LINE_AA)
        T.paint_on_surface(rgb, T.rough_alpha(rule, 3, 0.8) * 0.55, INK * 1.3, opacity=0.7, seed=2)
        letters = T.lettering(["FIRE &", "BLOOD"], 62, w - 70, 140, seed=4, font_kind="display", jitter=0.35)
        lt = np.zeros((h, w), np.float32)
        lt[18:158, 35:w - 35] = letters
        # folded lower outer corner: cut it off the sheet, draw the flap (the sheet's back) reflected
        fx0, fy0 = w - 64, h - 2                               # fold line from the bottom edge ...
        fx1, fy1 = w - 2, h - 58                               # ... to the outer edge
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        side = (gx - fx0) * (fy1 - fy0) - (gy - fy0) * (fx1 - fx0)
        beyond = (side < 0).astype(np.float32)                  # the corner past the fold line
        a = a * (1 - beyond)
        dx, dy = fx1 - fx0, fy1 - fy0
        L2 = dx * dx + dy * dy
        tri = np.float32([[fx0, fy0], [fx1, fy1], [0, 0]])
        # the corner (w, h) reflected over the fold line: the flap's tip
        t_ = ((w - fx0) * dx + (h - fy0) * dy) / L2
        px, py = fx0 + t_ * dx, fy0 + t_ * dy
        tri[2] = (2 * px - w, 2 * py - h)
        flap = np.zeros((h, w), np.float32)
        cv2.fillPoly(flap, [np.round(tri * 8).astype(np.int32)], 1.0, cv2.LINE_AA, shift=3)
        back = PAPER * np.float32([0.80, 0.76, 0.80]) * (1 + 0.04 * tooth)
        crease = np.clip(1 - np.abs(side) / (np.sqrt(L2) * 7), 0, 1)[..., None]   # dark along the crease
        rgb = rgb * (1 - 0.35 * crease * (1 - beyond[..., None]))
        rgb = rgb * (1 - flap[..., None]) + back * flap[..., None]
        a = np.maximum(a, flap)
        lt = lt * (1 - flap)
        # wavy hem: the sheet is not a flat card
        wave = (6.0 * np.sin(gx / w * math.pi * 1.6 + 0.4) * (0.3 + 0.7 * gx / w)).astype(np.float32)
        rgb = cv2.remap(rgb.astype(np.float32), gx, gy + wave, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        a = cv2.remap(a, gx, gy + wave, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        lt = cv2.remap(lt, gx, gy + wave, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        P = PAGE_PAD
        padf = lambda x: cv2.copyMakeBorder(x, P, P, P, P, cv2.BORDER_CONSTANT, value=0)
        rgb, a, lt = padf(rgb), padf(a), padf(lt)
        sh = cv2.GaussianBlur(np.roll(a, (26, 18), (0, 1)), (0, 0), 10) * 0.85
        return rgb.astype(np.float32), a, lt, sh

    # ---------------------------------------------------------------- frame
    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        fh = f - f % 2
        st = PoseSwap.state(f, self.swaps) if self.pose else "A"
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            fl = self.flames[i]
            if fl is not None:                              # candles flicker on 2s
                z = self.flicker[(fh // 2) % len(self.flicker)]
                rgb = rgb * (1 + fl[..., None] * (0.10 * np.tanh(z)[..., None] - 0.02))
            if self.pose and i in (1, 2):
                n = self.pose.nearness(n, a, st)
                rgb, a = self.pose.apply(rgb, a, st)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self.dust.draw(self.cam, th * 0.35, img, warm=(0.36, 0.34, 0.62), core=(0.85, 0.84, 1.0),
                             intensity=0.32)
        img = self._pages(img, f)
        img = self._title(img, f)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Bran can see any moment of the past", self.f0 + 8, self.f_and - 4)
        self.draw_data_tag(img, f, "Fire and Blood:\nthe words of House Targaryen", self.f_history)
        return img, {"pose": st}

    def _book_screen(self, f):
        return self.cam.screen_point((BOOK[0] * WORK_SCALE, BOOK[1] * WORK_SCALE), 0.5, self.ctx.local(f))

    def _page_polys(self, c, w, h, rot, flip, bow, split):
        """A curled page as two flat painted shapes: the lit part (u < split) and the shaded fold
        (u > split). The sheet bows (edges follow v = +-1 + bow * u^2), is foreshortened by flip and
        rotated. Returns (lit, fold) polygons in output px."""
        r = math.radians(rot)
        cr, sr = math.cos(r), math.sin(r)

        def pt(u, v):
            x, y = u * w / 2 * flip, (v + bow * u * u) * h / 2
            return (c[0] + x * cr - y * sr, c[1] + x * sr + y * cr)

        def part(u0, u1):
            us = np.linspace(u0, u1, 7)
            return np.float32([pt(u, -1) for u in us] + [pt(u, 1) for u in us[::-1]])
        return part(-1, split), part(split, 1)

    def _pages(self, img, f):
        fh = f - f % 2
        if fh < self.f_writes:
            return img
        b = self._book_screen(f)
        H, W = img.shape[:2]
        lit_c = np.float32([0.96, 0.80, 0.62])                   # candle-lit face (sampled from the key's pages)
        fold_c = np.float32([0.54, 0.37, 0.43])                  # violet shadow side
        lay = np.zeros((H, W, 3), np.float32)
        cov = np.zeros((H, W), np.float32)
        for p in self.pages:
            tau = (fh - p["f"]) / FPS
            if tau < 0:
                continue
            drag = 1 - math.exp(-tau * 1.2)
            x = b[0] + p["vx"] / 1.2 * drag + math.sin(tau * 5 + p["ph"]) * 26
            y = b[1] - 30 + p["vy"] / 1.2 * drag + 150 * tau * tau
            if y < -200 or tau > 1.6:
                continue
            ang = p["spin"] * tau + p["ph"]
            flip = max(abs(math.cos(ang)), 0.18)
            ww = p["w"] * (0.55 + 0.45 * min(1.0, tau * 4))
            bow = 0.35 * math.sin(ang * 0.7 + p["ph"])
            split = 0.55 * math.sin(ang)
            for poly, col in zip(self._page_polys((x, y), ww, ww * 0.74, p["rot"] + p["rs"] * tau, flip, bow, split),
                                 (lit_c, fold_c) if math.cos(ang) > 0 else (fold_c * 0.9, lit_c * 0.85)):
                x0, y0 = np.floor(poly.min(0)).astype(int) - 2
                x1, y1 = np.ceil(poly.max(0)).astype(int) + 2
                xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
                if xb <= xa or yb <= ya:
                    continue
                m = np.zeros((yb - ya, xb - xa), np.float32)
                cv2.fillPoly(m, [np.round((poly - [xa, ya]) * 4).astype(np.int32)], 1.0, cv2.LINE_AA, shift=2)
                edge = m - cv2.erode(m, np.ones((3, 3), np.uint8))
                cc = col * (1 + 0.025 * self._tex[ya:yb, xa:xb]) * (1 - 0.45 * edge[..., None])
                mm = m[..., None]
                lay[ya:yb, xa:xb] = lay[ya:yb, xa:xb] * (1 - mm) + cc * mm
                cov[ya:yb, xa:xb] = np.maximum(cov[ya:yb, xa:xb], m)
        a = cov[..., None]
        return img * (1 - a) + lay * a

    def _title(self, img, f):
        """The hanging page: rises out of the book with the burst, hangs and turns gently on 2s; the
        lettering paints in from blank."""
        fh = f - f % 2
        f_up = self.f_writes + 2
        if fh < f_up:
            return img
        k = Track([(f_up, 0.0), (f_up + 12, 1.0, "out")])(fh)
        b = self._book_screen(f)
        cx = b[0] + (TITLE_HOLD[0] - b[0]) * k
        cy = b[1] + (TITLE_HOLD[1] - b[1]) * k - 40 * math.sin(math.pi * k)
        u = (fh - f_up) / FPS
        ang = (1 - k) * 160 * (1 - k) + 4.0 * math.sin(u * 3.1)
        sc = 0.35 + 0.65 * k
        rgb, a, lt, sh = self.title_page
        rgb = rgb.copy()
        q = Track([(self.f_title, 0.0), (self.f_title + 10, 1.0, "inout")])(fh)
        if q > 0:
            T.paint_on_surface(rgb, lt * q, INK, opacity=0.95, seed=6)
        sh = sh * (1 - a)                                       # page over its own soft shadow
        oa = a + sh
        rgb = (rgb * a[..., None] + SHADOW * sh[..., None]) / np.maximum(oa, 1e-4)[..., None]
        rgba = np.dstack([rgb, np.clip(oa, 0, 1)]).astype(np.float32)
        p, ox, oy = T.transform_rgba(rgba, sc, ang)
        h, w = rgba.shape[:2]
        x0 = cx - w * sc / 2 + ox + (w * sc / 2 - (w / 2) * sc)
        y0 = cy - h * sc / 2 + oy + (h * sc / 2 - (h / 2) * sc)
        # transform_rgba keeps the centre fixed at (w/2, h/2) in patch coordinates
        x0, y0 = cx - w / 2 + ox, cy - h / 2 + oy
        O.seat(img, p, x0, y0, tint=0.16, wrap=0.4, ambient=0.12, glow=(1.0, 0.75, 0.45) if q > 0 else None)
        return img

    def finish_args(self, f, info):
        return {"bloom_strength": 0.55}

    def events(self):
        return [(self.f_writes, "pages", {}), (self.f_history, "data_tag", {}), (self.f_title, "fire_and_blood", {}),
                (self.f_emb, "recoil", {})]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.room_tone(dur + 0.6, seed=61), t0 - 0.2, -30)
        snd.bed(A.drone(dur + 0.6, seed=62), t0 - 0.2, -36)
        # the burst of pages
        snd.sfx(A.whoosh(0.5, seed=63), snd.at_frame(self.f_writes - 2), -22, 0.1)
        snd.sfx(_flutter(1.0, seed=64), snd.at_frame(self.f_writes), -17, 0.15)
        # the title appears: a low bell
        snd.sfx(A.bell(330.0, 1.8, seed=65) + 0.5 * A.bell(495.0, 1.8, seed=66), snd.at_frame(self.f_title), -24, 0.25)
        # the lords recoil: a gasp and a cloth swish
        snd.sfx(_gasp(0.7, seed=67), snd.at_frame(self.f_emb - 2), -19, 0.2)
        snd.sfx(A.swish(0.25, seed=68), snd.at_frame(self.f_emb - 2), -21, 0.3)


def make(ctx):
    return Shot(ctx)
