"""Shot 10, Year 9: "Winter lasts years. With the North gone, the Reach feeds everyone, at the Reach's price."

Snow thickens through the line (private falling-snow particles on 2s, more and bigger flakes as it goes); the
bread price counter rolls up from "Reach" to "price" with the "scenario" chip; on "price" the beam tips toward
the bread (beam rotates about its hub, the two hanging pans follow their hooks, overshoot and settle on 2s) and
coins slide off the rising coin pan and drop. YEAR 9; lore tag "A Westerosi winter can last years" while
"Winter lasts years" is spoken.
Coordinates are px of the upscaled key work/keys/g09_winter_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import WORK_SCALE
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("sky", 0.00, 0.12, fill="full"),
    L.PlaneSpec("castle", 0.12, 0.30, radius=60),
    L.PlaneSpec("market", 0.30, 0.55, radius=60),
    L.PlaneSpec("front", 0.55, 1.01, radius=70),
]
HUB = (845, 735)                       # beam pivot
L_HOOK = (330, 1050)                   # left (bread) hanger hook
R_HOOK = (1290, 515)                   # right (coin) hanger hook


def _gold(dil):
    """mask_fn: the scale's gilded metal (warm, saturated) plus snow lying on it, grown by dil px, so a thin
    chain or the beam takes only itself and not the crowd behind it."""
    def fn(img, depth):
        r, g, b = img[..., 0], img[..., 1], img[..., 2]
        m = ((r - b > 0.10) & (r > 0.30)).astype(np.uint8)
        k = max(3, int(dil * img.shape[1] / 1520) | 1)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
        return cv2.dilate(m, np.ones((k, k), np.uint8)) > 0
    return fn


def _strip(p, q, w):
    """Quad around the segment p-q, w px wide (a chain)."""
    (x0, y0), (x1, y1) = p, q
    dx, dy = x1 - x0, y1 - y0
    n = math.hypot(dx, dy)
    nx, ny = -dy / n * w / 2, dx / n * w / 2
    return [(x0 + nx, y0 + ny), (x1 + nx, y1 + ny), (x1 - nx, y1 - ny), (x0 - nx, y0 - ny)]


SPRITES = [
    L.SpriteSpec("beam", 3, [(205, 960), (380, 890), (790, 650), (800, 600), (880, 590), (1220, 420), (1300, 360),
                             (1380, 400), (1360, 520), (1300, 560), (930, 790), (880, 860), (800, 860),
                             (430, 1090), (250, 1110)], pivot=HUB, mask_fn=_gold(25)),
    L.SpriteSpec("lchain1", 3, _strip((325, 1060), (45, 1880), 56), pivot=L_HOOK, mask_fn=_gold(9)),
    L.SpriteSpec("lchain2", 3, _strip((345, 1060), (650, 1880), 56), pivot=L_HOOK, mask_fn=_gold(9)),
    L.SpriteSpec("lpan", 3, [(0, 1840), (120, 1690), (260, 1660), (520, 1660), (640, 1760), (720, 1850),
                             (720, 1940), (600, 2040), (80, 2040), (0, 1990)], pivot=L_HOOK),
    L.SpriteSpec("rchain1", 3, _strip((1280, 530), (1120, 860), 44), pivot=R_HOOK, mask_fn=_gold(9)),
    L.SpriteSpec("rchain2", 3, _strip((1300, 530), (1450, 860), 44), pivot=R_HOOK, mask_fn=_gold(9)),
    L.SpriteSpec("rpan", 3, [(1095, 870), (1150, 780), (1240, 740), (1360, 740), (1440, 790), (1510, 860),
                             (1500, 930), (1420, 975), (1180, 975), (1100, 930)], pivot=R_HOOK),
]
LEFT = ("lchain1", "lchain2", "lpan")
RIGHT = ("rchain1", "rchain2", "rpan")
GOLD = np.float32([0.95, 0.72, 0.25])
GOLD_DK = np.float32([0.55, 0.32, 0.08])


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Snow:
    """Falling snow on 2s in output px: flakes fall with a sideways drift; `amount` (0..1) sets how many of
    the pool are visible, so the fall thickens over the shot. Near flakes are bigger, faster and softer."""

    def __init__(self, n, W, H, seed):
        r = np.random.default_rng(seed)
        self.W, self.H = W, H
        self.x = r.uniform(-60, W + 60, n)
        self.y = r.uniform(0, H, n)
        self.z = r.uniform(0, 1, n) ** 1.6                 # 0 far .. 1 near
        self.ph = r.uniform(0, 2 * math.pi, n)
        self.order = r.permutation(n)
        self.n = n

    def draw(self, img, t, amount, wind=40.0):
        H, W = img.shape[:2]
        k = int(self.n * float(np.clip(amount, 0, 1)))
        if k <= 0:
            return img
        idx = self.order[:k]
        z = self.z[idx]
        v = 90 + 260 * z
        y = (self.y[idx] + v * t) % (H + 40) - 20
        x = (self.x[idx] + wind * t * (0.4 + z) + 18 * np.sin(t * 1.3 + self.ph[idx])) % (W + 120) - 60
        r = 1.8 + 6.5 * z
        lay = np.zeros((H // 2, W // 2), np.float32)       # drawn at half res, then blurred up: soft paint dabs
        for xi, yi, ri, zi in zip(x, y, r, z):
            cv2.ellipse(lay, (int(xi / 2), int(yi / 2)), (max(1, int(ri / 2)), max(1, int(ri * 0.8 / 2))),
                        float(zi * 40), 0, 360, float(0.55 + 0.45 * zi), -1, cv2.LINE_AA)
        lay = cv2.resize(lay, (W, H), interpolation=cv2.INTER_LINEAR)
        lay = cv2.GaussianBlur(lay, (0, 0), 1.2)
        c = np.float32([0.92, 0.92, 1.0])
        return img * (1 - lay[..., None] * 0.85) + c * lay[..., None] * 0.85


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_winter = ctx.f("Winter")
        self.f_reach = ctx.f("Reach")
        self.f_feeds = ctx.f("feeds")
        self.f_price = ctx.f("price.")
        tp = ctx.local(ctx.f("price.", even=False))
        self.cam = ParallaxCamera(
            W, H, focus=Track([(0, (W * 0.50, H * 0.50)), (d, (W * 0.47, H * 0.53), "inout")]),
            nearness=nearness,
            zoom=Track([(0, 1.0), (tp - 0.3, 1.04, "inout"), (tp + 0.25, 1.075, "out"), (d, 1.085)]),
            push=Track([(0, 0.0), (d, 0.06, "inout")]),
            rise=Track([(0, 0.0), (d, -14.0, "inout")]),
            pan=Track([(0, 0.0), (d, 10.0, "inout")]))
        self.snow = Snow(700, 1080, 1920, seed=91)
        self.snow_amt = Track([(0, 0.12), (ctx.local(self.f_reach), 0.4, "inout"), (d, 1.0, "in")])
        self.coins = self._coin_paths()

    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    # ---------------------------------------------------------------- the tip
    def tip(self, f):
        """Beam angle in degrees on 2s (positive = bread side down): a tremble, then the tip with an
        overshoot and a settle."""
        dd = (f - f % 2) - self.f_price
        if dd < -6:
            return 0.0
        seq = {-6: 0.4, -4: -0.5, -2: 0.6, 0: 3.2, 2: 6.4, 4: 7.8, 6: 6.8, 8: 7.2, 10: 7.4}
        return seq.get(dd, 7.3)

    def _ends(self, ang):
        """Displacement (key px) of each hook when the beam turns by ang degrees about the hub."""
        a = math.radians(ang)
        out = []
        for hx, hy in (L_HOOK, R_HOOK):
            rx, ry = hx - HUB[0], hy - HUB[1]
            # image coords, y down: positive ang turns the left end down (clockwise on screen = negative math)
            nx = rx * math.cos(a) + ry * math.sin(a)
            ny = -rx * math.sin(a) + ry * math.cos(a)
            out.append((nx - rx, ny - ry))
        return out

    def _coin_paths(self):
        """Ten coins: each slides from the heap to the left rim of the coin pan, then falls (key px)."""
        r = np.random.default_rng(7)
        out = []
        for i in range(10):
            out.append({"x": float(r.uniform(1180, 1400)), "y": float(r.uniform(770, 830)),
                        "delay": int(2 * r.integers(1, 9)), "vx": float(r.uniform(-260, -120)),
                        "spin": float(r.uniform(4, 9)), "rad": float(r.uniform(15, 21))})
        return out

    def _draw_coins(self, img, f, t, rdy):
        fh = f - f % 2
        for c in self.coins:
            s = (fh - (self.f_price + 2 + c["delay"])) / 24.0
            if s < 0:
                continue
            rim = 1110.0
            slide_t = max(0.05, (c["x"] - rim) / (-c["vx"]))
            if s < slide_t:
                x, y = c["x"] + c["vx"] * s, c["y"] + 40 * s + rdy
            else:
                u = s - slide_t
                x = rim + c["vx"] * 0.6 * u
                y = c["y"] + 40 * slide_t + rdy + 420 * u + 2600 * u * u
            if y > 2701:
                continue
            q = self.cam.screen_point((x * WORK_SCALE, y * WORK_SCALE), 0.75, t)
            sc = self.cam.scale_at(0.75, t) * WORK_SCALE
            rr = 1.5 * c["rad"] * sc
            squash = abs(math.cos(c["spin"] * s * 2.0)) * 0.75 + 0.25
            ax, ay = int(max(2, rr)), int(max(1, rr * squash))
            cv2.ellipse(img, (int(q[0]), int(q[1])), (ax, ay), 0, 0, 360, GOLD_DK.tolist(), -1, cv2.LINE_AA)
            cv2.ellipse(img, (int(q[0]), int(q[1]) - 1), (max(1, ax - 3), max(1, ay - 2)), 0, 0, 360,
                        GOLD.tolist(), -1, cv2.LINE_AA)
            cv2.ellipse(img, (int(q[0] - ax * 0.3), int(q[1] - ay * 0.35)), (max(1, ax // 4), max(1, ay // 5)),
                        -20, 0, 360, [1.0, 0.95, 0.75], -1, cv2.LINE_AA)
        return img

    # ---------------------------------------------------------------- overlays
    @cached_property
    def unit(self):
        a = O._text_alpha("stags a loaf", T.at_least_cap(T.sans(40, 700), 36), min_cap=36)
        rgba, _ = T.styled_text_rgba(a, O.CREAM, seed=12, shadow_off=(2, 3), soft_shadow=5, grad=0.06)
        return rgba

    @cached_property
    def scen(self):
        return O.scenario_label(size=T.at_least_cap(T.sans(26, 600), 36).size)

    def _line(self, num):
        """The counter line (rolling number + unit) on one dark painted plate, tight to the glyphs."""
        def bounds(rgba):
            cols = np.flatnonzero(rgba[..., 3].max(0) > 0.3)
            rows = np.flatnonzero(rgba[..., 3].max(1) > 0.3)
            return cols[0], cols[-1], rows[0], rows[-1]
        nl, nr, nt, nb = bounds(num)
        ul, ur, ut, ub = bounds(self.unit)
        gap, padx, pady = 22, 30, 18
        w = (nr - nl) + gap + (ur - ul) + 2 * padx
        h = (nb - nt) + 2 * pady
        plate = O.painted_chip(int(w), int(h), seed=93, opacity=0.88)
        canvas = np.zeros((plate.shape[0] + 8, plate.shape[1] + 8, 4), np.float32)
        T.over_rgba(canvas, plate, 0, 0)
        x_num = 8 + padx - nl
        y_num = 8 + pady - nt
        T.over_rgba(canvas, num, int(x_num), int(y_num))
        x_unit = int(x_num + nr + gap - ul)
        y_unit = int(y_num + nb - ub)                         # unit sits on the number's baseline
        T.over_rgba(canvas, self.unit, x_unit, y_unit)
        return canvas

    def _counter(self, img, f):
        f_in = self.f_reach - 2
        if f < f_in:
            return
        v = O.roll_value(f, self.f_reach, self.f_price + 4, 2, 40)
        num = O.counter_rgba(v, fmt="{:,.0f}", size=120, decimals=0, roll=False, seed=7)
        line = self._line(num)
        x, y = 60, 330                                        # left edge of the safe area, off the beam
        O.draw_pop(img, line, x, y, f, f_in, glow=(1.0, 0.75, 0.35))
        O.draw_pop(img, self.scen, x + 6, y + line.shape[0] - 2, f, f_in + 4)

    # ---------------------------------------------------------------- frame
    def frame(self, f):
        t = self.ctx.local(f)
        th = self.f0 / 24.0 + on2s(f - self.f0)
        ang = self.tip(f)
        (ldx, ldy), (rdx, rdy) = self._ends(ang)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            if i == 3:
                rgb, a = rgb.copy(), a.copy()
                for s in self.lay.sprites:
                    if s["name"] == "beam":
                        patch, x0, y0 = deform_sprite(s, angle_deg=-ang)   # deform_sprite: + lifts the left end
                    elif s["name"] in LEFT:
                        patch, x0, y0 = deform_sprite(s, dx=ldx * WORK_SCALE, dy=ldy * WORK_SCALE)
                    else:
                        patch, x0, y0 = deform_sprite(s, dx=rdx * WORK_SCALE, dy=rdy * WORK_SCALE)
                    composite_into(rgb, a, patch, x0, y0)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._draw_coins(img, f, t, rdy)
        img = self.snow.draw(img, th, self.snow_amt(t))
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "A Westerosi winter can last years", self.f_winter + 4)
        self._counter(img, f)
        return np.clip(img, 0, 1).astype(np.float32), {"tip": ang}

    def finish_args(self, f, info):
        return {"bloom_strength": 0.45}

    def events(self):
        return [(self.f_winter + 4, "lore_tag", {}), (self.f_reach - 2, "counter_in", {}),
                (self.f_price, "scale_tips", {}), (self.f_price + 4, "coins_slide", {})]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        wind = A.lowpass(A.noise(dur + 0.6, 101, kind="pink"), 700)
        snd.bed(wind / (np.abs(wind).max() + 1e-9), t0 - 0.2, -27, 0.2)
        snd.bed(A.crowd(dur + 0.6, seed=102), t0 - 0.2, -38, -0.3)
        # the counter ticks as it rolls
        for k, fr in enumerate(range(self.f_reach, self.f_price + 4, 4)):
            snd.sfx(A.tick(103 + k, 2600 + 60 * k), snd.at_frame(fr), -29, -0.5)
        # the beam creaks and the pan lands
        creak = A.bandpass(A.noise(0.5, 120, "brown"), 160, 600) * np.exp(-np.linspace(0, 1, int(0.5 * A.SR)) * 3)
        snd.sfx(creak / (np.abs(creak).max() + 1e-6), snd.at_frame(self.f_price - 4), -22, -0.2)
        snd.sfx(A.thunk(seed=121), snd.at_frame(self.f_price + 4), -18, -0.4)
        # coins chink as they slide and fall
        for k in range(6):
            snd.sfx(A.bell(2800 + 210 * k, 0.18, seed=130 + k), snd.at_frame(self.f_price + 6 + 3 * k), -30, 0.6)


def make(ctx):
    return Shot(ctx)
