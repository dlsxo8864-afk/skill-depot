"""Shot 3, Year 2: "Then the North leaves. Jon promised Sansa independence, and he keeps his word."

The northern third of the carved map separates on "leaves" (sprite cut along the painted crack: dip, then
slides up ~60 px with a 2 deg tilt on 2s, one-frame overshoot, settle; a dark gradient gap opens along the
crack where it sat), a pale crack flash runs along the break and snow dust puffs off the edge; Sansa's chin lifts
(pose B -> key pose) on "word". YEAR 2, "Kingdom of the North" + "scenario" while the North leaves, then the lore tag
(Sansa's S8E6 line) while the promise is spoken. Jon's head fills the standard data slot, so both tags sit
in the calm wall band right of the YEAR tag.
Coordinates are px of the upscaled key work/keys/g02_north_key.png (1520 x 2701).
"""
import math
from functools import cached_property, lru_cache

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import WORK_SCALE
from whatif.fx2d import ShapeCanvas, bolt_points, screen_emissive, tapered_streak_poly
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]

UPPER = [(0, 0), (1520, 0), (1520, 1690), (0, 1690)]
LOWER = [(0, 1690), (1520, 1690), (1520, 2701), (0, 2701)]
PLANES = [
    L.PlaneSpec("wall", 0.00, 0.085, fill="full"),
    L.PlaneSpec("back", 0.085, 0.19, radius=60),                  # Jon, the queen, her chair
    L.PlaneSpec("sansa", 0.19, 1.01, radius=60, region=UPPER),
    L.PlaneSpec("table", 0.19, 1.01, radius=70, region=LOWER),
]

NORTH = [(300, 1700), (450, 1662), (650, 1645), (900, 1636), (1150, 1688), (1300, 1724), (1452, 1728),
         (1462, 1792), (1330, 1892), (1050, 1978), (860, 2012), (640, 2018), (520, 1978), (400, 1902),
         (290, 1822)]
PIVOT = (880, 1990)                                   # the break at the front-left: the piece hinges here
CRACK = [(300, 1830), (420, 1910), (530, 1985), (650, 2020), (860, 2015), (1050, 1982), (1330, 1895)]


def _north_mask(img, depth):
    lum = img.mean(2)
    r, b = img[..., 0], img[..., 2]
    m = (lum > 0.30) | ((r - b > 0.04) & (lum > 0.17))
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    return m.astype(bool)


SPRITES = [L.SpriteSpec("north", 3, NORTH, pivot=PIVOT, mask_fn=_north_mask, fill_own_plane=True)]
TORCHES = [(1095, 700), (1470, 650)]
HERO = [(500, 360), (930, 360), (930, 900), (500, 900)]          # Sansa's head, both poses


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


@lru_cache(maxsize=8)
def tag_w(text, max_text_w, cap=O.TAG_CAP):
    """O.data_tag with a narrower wrap width (the library's is fixed to the standard slot) and an optional
    larger cap height."""
    a = O._wrapped_alpha(text, T.at_least_cap(T.sans(30, 640), cap), max_text_w)
    a = np.maximum(T.rough_alpha(a, 83, 0.35), a * 0.85)
    t_rgba, pad = T.styled_text_rgba(a, O.CREAM, seed=80, shadow_off=(1, 2), soft_shadow=4, shadow_strength=0.45,
                                     grad=0.10)
    w, h = a.shape[1] + 74, a.shape[0] + 34
    chip = O.painted_chip(w, h, seed=81 + len(text))
    canvas = np.zeros((h + 20, w + 20, 4), np.float32)
    T.over_rgba(canvas, chip, -2, -2)
    dot = O.painted_swatch(14, 14, seed=82, color=np.float32(O.TEAL) / 255, opacity=1.0, rough=0.1, radius=1)
    T.over_rgba(canvas, dot, 6 + 22, 6 + h // 2 - 7)
    T.over_rgba(canvas, t_rgba, 6 + 50 - pad, 6 + 17 - pad)
    return canvas


SCENARIO_CAP = 36                                       # matches s05's SCENARIO chip (caps, >= 30 px cap height)


@lru_cache(maxsize=1)
def _scenario_chip():
    """'SCENARIO' in caps on the dark plum plate, sized like s05's chip."""
    size = 26
    while T.cap_height(T.sans(size, 600)) < SCENARIO_CAP:
        size += 1
    return O.scenario_label(size=size, text="SCENARIO")


class SnowDust:
    """Painted snow flecks thrown off the break (positions on 2s, world space with parallax)."""

    def __init__(self, n, f_burst, seed=3):
        rng = np.random.default_rng(seed)
        pts = np.float32(CRACK) * WORK_SCALE
        k = rng.uniform(0, len(pts) - 1.001, n)
        i = k.astype(int)
        u = (k - i)[:, None]
        self.p0 = pts[i] * (1 - u) + pts[i + 1] * u + rng.normal(0, 6, (n, 2))
        self.v = np.stack([rng.normal(0, 110, n), rng.uniform(-380, -120, n)], 1)
        self.delay = rng.integers(0, 4, n) * 2
        self.life = rng.uniform(0.9, 2.0, n)
        self.size = rng.uniform(0.6, 1.5, n)
        self.near = rng.uniform(0.50, 0.66, n)
        self.f_burst = f_burst

    def draw(self, cam, f, t, img):
        fh = f - f % 2
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        drawn = False
        for j in range(len(self.near)):
            age = (fh - self.f_burst - self.delay[j]) / 24.0
            if age < 0 or age > self.life[j]:
                continue
            p = self.p0[j] + self.v[j] * age * (1 - 0.35 * age) + np.float32([0, 90]) * age * age   # puffs, sifts down
            q = cam.screen_point(p, self.near[j], t)
            fade = 1 - age / self.life[j]
            s = self.size[j] * cam.scale_at(self.near[j], t)
            vel = self.v[j] + np.float32([0, 180]) * age
            sc.fill(tapered_streak_poly(q, vel, 8 * s, 7 * s), glow=False, value=int(210 * fade))
            drawn = True
        if not drawn:
            return img
        c, g = sc.result(glow_sigma=5)
        a = np.clip(c * 0.8 + g * 0.5, 0, 1)[..., None] * 0.85
        return img * (1 - a) + np.float32([0.86, 0.90, 0.98]) * a


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_leaves = ctx.f("leaves.")
        self.f_promised = ctx.f("promised")
        self.f_jon = ctx.f("Jon")
        self.f_word = ctx.f("word.")
        tl = (self.f_leaves - self.f0) / 24.0
        self.cam = ParallaxCamera(
            W, H, focus=(W * 0.52, H * 0.45), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.07, "inout")]),
            push=Track([(0, 0.0), (d, 0.06, "inout")]),
            # a small settle on "leaves" (the slide is the impact now; a 15 px one-frame camera kick changed >8 %
            # of the frame)
            rise=Track([(0, 0.0), (tl, -6.0), (tl + 2 / 24, -2.0, "out"), (tl + 6 / 24, -8.0), (d, -26.0, "inout")]),
            pan=Track([(0, 0.0), (d, 12.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=HERO, thresh=14.0)
        # the pose B painting has her chin level and the key has it raised: hold B (level, glaring) and lift the
        # chin to the key's pose on "word", so the move reads as the chin lifting
        self.swaps = [(self.f_word, "A")]
        self.dust = SnowDust(110, self.f_leaves)

    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    def _lift(self, f):
        """(angle, dy) of the northern piece (work px): it sits in the key's place, dips on the frame before
        "leaves", slides up ~60 px with a 2 deg tilt on 2s (230, 232, 234), overshoots for one frame at 236 and
        settles at 238, then holds."""
        keys = {228: (0.0, 3.0), 229: (0.0, 3.0), 230: (-0.6, -20.0), 231: (-0.6, -20.0), 232: (-1.3, -40.0),
                233: (-1.3, -40.0), 234: (-1.85, -56.0), 235: (-1.85, -56.0), 236: (-2.35, -68.0),
                237: (-2.15, -63.0)}
        if f < 228:
            return 0.0, 0.0
        return keys.get(f, (-2.0, -60.0))

    @cached_property
    def north(self):
        """The northern piece on a canvas padded upward (so the slide is never clipped) and the dark gap left
        where it sat: a gradient from the table's shadow colour to near black along the crack, not the key."""
        s = self.lay.sprites[self.lay.sprite_index("north")]
        rgba = s["rgba"].astype(np.float32) / 255
        h, w = rgba.shape[:2]
        pad = 110
        src = np.zeros((h + pad, w, 4), np.float32)
        src[pad:] = rgba
        fp = cv2.dilate((rgba[..., 3] > 0.05).astype(np.uint8), np.ones((7, 7), np.uint8)).astype(np.float32)
        ys = np.arange(h, dtype=np.float32)[:, None]
        rows = np.nonzero(fp.any(1))[0]
        top = np.full(w, h, np.float32)
        bot = np.zeros(w, np.float32)
        for x in range(w):
            c = np.nonzero(fp[:, x] > 0.5)[0]
            if len(c):
                top[x], bot[x] = c.min(), c.max()
        u = np.clip((ys - top[None]) / np.maximum(bot - top, 1)[None], 0, 1)     # 0 far edge .. 1 at the crack
        u = cv2.GaussianBlur(u, (0, 0), 6)
        far, near = np.float32([0.11, 0.10, 0.15]), np.float32([0.025, 0.022, 0.035])
        rgb = far * (1 - u[..., None] ** 1.5) + near * u[..., None] ** 1.5
        n = L.brush_noise((h, w), 61, scale=4, angle=0.1, stretch=8)[..., None]
        rgb = np.clip(rgb * (1 + 0.10 * n), 0, 1)
        a = cv2.GaussianBlur(fp, (0, 0), 2.0)
        return {"s": s, "src": src, "pad": pad, "hole": np.dstack([rgb, a]).astype(np.float32)}

    def _north_patch(self, f):
        nb = self.north
        x0, y0 = nb["s"]["bbox"][:2]
        y0 -= nb["pad"]
        ang, dy = self._lift(f)
        src = nb["src"]
        if abs(ang) < 1e-4 and abs(dy) < 1e-4:
            return src, x0, y0
        H2, W2 = src.shape[:2]
        px, py = PIVOT[0] * WORK_SCALE - x0, PIVOT[1] * WORK_SCALE - y0
        gy, gx = np.mgrid[0:H2, 0:W2].astype(np.float32)
        r = math.radians(ang)
        ca, sa = math.cos(-r), math.sin(-r)
        ux, uy = gx - px, gy - py - dy
        sx = ux * ca - uy * sa + px
        sy = ux * sa + uy * ca + py
        return cv2.remap(src, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0), x0, y0

    def frame(self, f):
        t = self.ctx.local(f)
        st = PoseSwap.state(f, self.swaps, start="B") if self.pose else "A"
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            if i == 3:
                rgb, a = rgb.copy(), a.copy()
                if f >= 228:                       # the gap under the piece (only uncovered once it moves)
                    hx0, hy0 = self.north["s"]["bbox"][:2]
                    composite_into(rgb, a, self.north["hole"], hx0, hy0)
                patch, x0, y0 = self._north_patch(f)
                composite_into(rgb, a, patch, x0, y0)
            if self.pose and i == 2:
                n = self.pose.nearness(n, a, st)
                rgb, a = self.pose.apply(rgb, a, st)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._torches(img, f, t)
        img = self._crack(img, f, t)
        img = self.dust.draw(self.cam, f, t, img)
        self._tags(img, f)
        return img, {"pose": st}

    def _crack(self, img, f, t):
        d = (f - f % 2) - 230
        if d not in (0, 2, 4):
            return img
        rng = np.random.default_rng(11 + d)
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        pts = [self.cam.screen_point((x * WORK_SCALE, y * WORK_SCALE), 0.58, t) for x, y in CRACK]
        for p0, p1 in zip(pts, pts[1:]):
            v = np.float32(p1) - np.float32(p0)
            L_ = float(np.hypot(*v)) + 1e-3
            sc.line(bolt_points(p0, v / L_, L_, 6, rng, jag=0.12), {0: 3.2, 2: 2.2, 4: 1.4}[d])
        c, g = sc.result(glow_sigma=3)
        k = {0: 0.9, 2: 0.55, 4: 0.25}[d]
        return screen_emissive(img, c, g, (0.95 * k, 0.97 * k, 1.0 * k), (0.25 * k, 0.40 * k, 0.70 * k))

    def _torches(self, img, f, t):
        """Wall torches breathe on 2s: warm additive glow around each flame."""
        fh = f - f % 2
        H, W = img.shape[:2]
        yy, xx = np.ogrid[0:H, 0:W]
        for j, (x, y) in enumerate(TORCHES):
            k = 0.5 + 0.5 * math.sin(fh * (1.3 + 0.4 * j) + j) * math.cos(fh * 0.55 + 2 * j)
            q = self.cam.screen_point((x * WORK_SCALE, y * WORK_SCALE), 0.08, t)
            g = np.exp(-(((xx - q[0]) / 90.0) ** 2 + ((yy - q[1]) / 110.0) ** 2)).astype(np.float32)
            img = img + g[..., None] * np.float32([0.16, 0.08, 0.02]) * (0.3 + 0.9 * k)
        return np.clip(img, 0, 1)

    def _tags(self, img, f):
        self.draw_year_tag(img, f)
        x_band = 318
        kn = tag_w("KINGDOM OF THE NORTH", 560, cap=38)
        if O.draw_pop(img, kn, x_band, 112, f, self.f_leaves, self.f_jon):
            O.draw_pop(img, _scenario_chip(), x_band + 8, 112 + kn.shape[0] - 22, f, self.f_leaves + 2, self.f_jon)
        O.draw_pop(img, tag_w("Sansa: ‘The North will remain an independent kingdom’ (S8E6)", 520),
                   x_band, 112, f, self.f_promised)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.45}

    def events(self):
        return [(self.f_leaves - 2, "map_dip", {}), (self.f_leaves, "north_lifts", {}),
                (self.f_promised, "lore_tag", {}), (self.f_word, "chin_up", {})]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.room_tone(dur + 0.6, seed=31), t0 - 0.2, -30)
        wind = A.lowpass(A.noise(dur + 0.6, 32, kind="pink"), 700) if True else None
        snd.bed(wind / (np.abs(wind).max() + 1e-9), t0 - 0.2, -34, -0.3)
        tl = snd.at_frame(self.f_leaves)
        # stone crack: a hard thunk plus a dry splintering burst, then crumbling grit
        snd.sfx(A.thunk(seed=33), tl, -14, 0.1)
        n = A.noise(0.5, 34)
        crack = A.bandpass(n, 1800, 6500) * A.exp_decay(len(n), 0.06)
        snd.sfx(crack / (np.abs(crack).max() + 1e-9), tl, -17, 0.15)
        g = A.noise(1.2, 35)
        grit = A.bandpass(g, 2500, 9000) * A.exp_decay(len(g), 0.35) * (0.5 + 0.5 * (A.noise(1.2, 36) > 1.2))
        snd.sfx(grit / (np.abs(grit).max() + 1e-9), tl + 0.05, -26, 0.2)
        snd.sfx(A.whoosh(0.5, seed=37), tl - 0.12, -24, 0.0)
        # chin lift: a low soft hit and a cloth swish
        snd.sfx(A.swish(0.22, seed=38), snd.at_frame(self.f_word - 2), -22, -0.1)
        snd.sfx(A.hit(seed=39), snd.at_frame(self.f_word), -24, 0.0)


def make(ctx):
    return Shot(ctx)
