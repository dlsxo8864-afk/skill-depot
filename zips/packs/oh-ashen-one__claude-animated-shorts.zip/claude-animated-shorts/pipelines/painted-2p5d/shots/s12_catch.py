"""Shot 12, the catch: "Breaking the wheel ends with the lords choosing a king, almost exactly how the
show ended."

The lords' wheel-table turns one spoke gap (45 deg) on "wheel": an anticipation drawing (it rocks back),
one smeared in-between masked to the wood (inside the rim, the lords' hands and faces and anything raised
above the table excluded), then the landed drawing, which is the painted key itself (8 spokes), held. The seated lords stay put on top of the turning wood. On
"ended" the queen's head tilts (pose B through the standard anticipation / in-between, plus a small
extra rigid head tilt so the change reads at phone size). Torches and the brazier flicker on 2s and
dust drifts in the hall. The quote tag is up from the first word.
Coordinates are px of the upscaled key work/keys/g11_catch_key.png (1520 x 2701).
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif.camera import ParallaxCamera
from whatif.config import FPS, WORK_SCALE, safe_box
from whatif.fx2d import Embers, ShapeCanvas, tapered_streak_poly
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]
SC = WORK_SCALE

# Two planes: the hall (and the queen, who stands at its depth) and the room (wheel + lords). The wheel
# runs from depth 0.31 (far rim) to 0.92 (near rim); one plane keeps the turning wood in one piece.
PLANES = [
    L.PlaneSpec("hall", 0.00, 0.30, fill="full"),
    L.PlaneSpec("room", 0.30, 1.01, radius=70),
]
QUOTE = "Daenerys, season 5:\n'I'm not going to stop the wheel.\nI'm going to break the wheel.'"

# wheel plane: unit circle (rim's inner edge) -> key px, fitted by eye to the far / near / left / right rim
WHEEL_SRC = [(0, -1), (0, 1), (-1, 0), (1, 0)]
WHEEL_DST = [(813, 1290), (654, 2250), (-80, 1650), (1620, 1600)]
R_TURN = 0.86                       # inside this radius the wood turns; the rim ring itself stays
R_HUB = 0.27                        # the hub drum: round, raised above the wheel plane, held still

# the seated lords (key px, generous): they stay put while the wood turns under their hands
LORDS = [
    [(240, 1260), (500, 1170), (600, 1240), (700, 1340), (660, 1380), (580, 1400), (520, 1480), (480, 1560), (260, 1600), (220, 1400)],
    [(0, 1480), (200, 1370), (330, 1420), (350, 1560), (400, 1660), (420, 1760), (260, 1740), (120, 1840), (0, 1840)],
    [(0, 1940), (150, 1640), (330, 1620), (370, 1840), (500, 1840), (500, 1960), (400, 2000), (480, 2120), (500, 2200), (0, 2200)],
    [(460, 2200), (540, 2040), (640, 1940), (680, 1840), (760, 1840), (800, 1940), (880, 2080), (920, 2200), (800, 2240), (600, 2240)],
    [(1030, 1940), (1120, 1800), (1200, 1680), (1360, 1700), (1520, 1760), (1520, 2240), (1200, 2240), (1120, 2160)],
    [(1180, 1480), (1280, 1500), (1340, 1420), (1440, 1380), (1520, 1400), (1520, 1760), (1400, 1740), (1280, 1600), (1200, 1560)],
    [(1060, 1380), (1160, 1240), (1220, 1180), (1320, 1220), (1400, 1360), (1360, 1460), (1280, 1500), (1120, 1540), (1060, 1480)],
]
QUEEN = [(780, 790), (1030, 790), (1030, 1060), (780, 1060)]          # head + shoulders, both poses
NECK = (905, 975)                                                      # head tilt pivot
HEAD = (905, 905, 80)                                                  # head centre + radius for the extra tilt


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, [])
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_wheel = ctx.f("wheel")
        self.f_ended = ctx.f("ended.")
        fw = self.f_wheel
        # (angle deg, smear from deg) per drawing on 2s, relative to the "wheel" frame: an anticipation
        # drawing (rocks back), ONE smeared in-between led at 30 deg, then the landed drawing a full spoke
        # gap on (45 deg), which is the painted key itself, held opaque for the rest of the shot
        self.turn = {-2: (-4.0, None), 0: (30.0, 12.0)}
        self.f_stop = fw + 2
        jolt = self.f_stop / FPS - self.f0 / FPS
        t_almost = ctx.local(ctx.f("almost", even=False))
        t_end = ctx.local(self.f_ended + 6)
        self.cam = ParallaxCamera(
            W, H, nearness=nearness,
            # after the turn the camera drifts in on the queen so her tilt on "ended" reads at phone size
            focus=Track([(0, (W * 0.50, H * 0.53)), (t_almost, (W * 0.51, H * 0.50), "inout"),
                         (t_end, (W * 0.57, H * 0.40), "inout"), (d, (W * 0.57, H * 0.40))]),
            zoom=Track([(0, 1.0), (t_almost, 1.03, "inout"), (t_end, 1.17, "inout"), (d, 1.18)]),
            push=Track([(0, 0.0), (d, 0.05, "inout")]),
            rise=Track([(0, 0.0), (jolt - 0.01, 0.0), (jolt + 0.04, 7.0, "out"), (jolt + 0.30, 0.0, "inout"), (d, 0.0)]),
            pan=Track([(0, 0.0), (d, -10.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=QUEEN, thresh=10.0)
        self.swaps = [(self.f_ended, "B")]

    # ------------------------------------------------------------ prepared
    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    @cached_property
    def wheel(self):
        """Homography (wheel plane -> work px), the turning mask, the lords mask and a source plate with
        the lords filled out of it (so turning wood never carries a lord's sleeve along)."""
        Hm = cv2.getPerspectiveTransform(np.float32(WHEEL_SRC), np.float32(WHEEL_DST) * SC)
        Hi = np.linalg.inv(Hm)
        pl = self.planes[1]
        h, w = pl["a"].shape
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        pts = np.stack([gx, gy, np.ones_like(gx)], -1) @ Hi.T
        u, v = pts[..., 0] / pts[..., 2], pts[..., 1] / pts[..., 2]
        r = np.sqrt(u * u + v * v)
        disk = np.clip((R_TURN - r) / 0.03, 0, 1).astype(np.float32)
        disk *= np.clip((r - R_HUB) / 0.03, 0, 1)            # the hub drum (raised above the plane) stays
        lords = np.zeros((h, w), np.float32)
        cv2.fillPoly(lords, [np.round(np.float32(p) * SC).astype(np.int32) for p in LORDS], 1.0)
        lords = cv2.GaussianBlur(lords, (0, 0), 3)
        valid = ((lords < 0.05) & (pl["a"] > 0.5)).astype(np.float32)
        src = L.push_pull_fill(pl["rgb"], valid)
        n = L.brush_noise((h, w), 37, scale=3, angle=0.4, stretch=6)[..., None]
        src = (pl["rgb"] * valid[..., None] + src * (1 - valid[..., None]) * (1 + 0.04 * n)).astype(np.float32)
        # objects ON the table (lords' hands, sleeves, faces leaning in) sit nearer than the flat wood: fit
        # the wood's depth per row (a low percentile inside the disk) and keep anything raised above it
        d = self.lay.planes[1]["d"].astype(np.float32) / 65535
        inside = disk > 0.5
        wood_d = np.full(h, np.nan, np.float32)
        for y in range(h):
            row = d[y][inside[y]]
            if row.size > 20:
                wood_d[y] = np.percentile(row, 30)
        ok = ~np.isnan(wood_d)
        if ok.any():
            wood_d = np.interp(np.arange(h), np.flatnonzero(ok), wood_d[ok]).astype(np.float32)
            wood_d = cv2.GaussianBlur(wood_d[:, None], (0, 0), 25)[:, 0]
        raised = ((d - wood_d[:, None]) > 0.035).astype(np.float32) * inside
        raised *= (r > R_HUB + 0.10)                            # the hub collar turns with the spokes
        raised = cv2.morphologyEx(raised, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        raised = cv2.dilate(raised, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
        keep = np.maximum(lords, cv2.GaussianBlur(raised, (0, 0), 3))
        wood = (disk * (1 - np.clip(keep, 0, 1))).astype(np.float32)
        return {"H": Hm, "u": u, "v": v, "disk": disk, "lords": lords, "src": src, "wood": wood}

    def _turned(self, deg, smear_from):
        """The room plate with the wood inside R_TURN turned by `deg` (plane degrees), smeared back over
        the arc it just travelled when smear_from is given (a drawn rotational smear, not a camera blur)."""
        wh = self.wheel
        Hm = wh["H"]
        angles = [deg] if smear_from is None else list(np.linspace(smear_from, deg, 6))
        acc = None
        wts = 0.0
        for k, ang in enumerate(angles):
            a = math.radians(-ang)
            ca, sa = math.cos(a), math.sin(a)
            uu = wh["u"] * ca - wh["v"] * sa
            vv = wh["u"] * sa + wh["v"] * ca
            den = Hm[2, 0] * uu + Hm[2, 1] * vv + Hm[2, 2]
            mx = ((Hm[0, 0] * uu + Hm[0, 1] * vv + Hm[0, 2]) / den).astype(np.float32)
            my = ((Hm[1, 0] * uu + Hm[1, 1] * vv + Hm[1, 2]) / den).astype(np.float32)
            s = cv2.remap(wh["src"], mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            wt = 0.25 + 0.75 * ((k + 1) / len(angles)) ** 2 + (1.6 if k == len(angles) - 1 else 0.0)   # crisp lead
            acc = s * wt if acc is None else acc + s * wt
            wts += wt
        return acc / wts

    @cached_property
    def flames(self):
        out = []
        for pl in self.planes:
            rgb = pl["rgb"]
            m = ((rgb.max(2) > 0.78) & (rgb[..., 0] > rgb[..., 2] + 0.25)).astype(np.float32) * pl["a"]
            out.append(cv2.GaussianBlur(cv2.dilate(m, np.ones((9, 9), np.uint8)), (0, 0), 10) if m.any() else None)
        return out

    @cached_property
    def flicker(self):
        rng = np.random.default_rng(12)
        H, W = self.lay.H, self.lay.W
        return [cv2.resize(rng.standard_normal((H // 80 + 2, W // 80 + 2)).astype(np.float32), (W, H),
                           interpolation=cv2.INTER_CUBIC) for _ in range(6)]

    @cached_property
    def dust(self):
        return Embers(30, self.lay.W, self.lay.H, seed=121, y_range=(0.15, 0.7), n_range=(0.05, 0.35))

    # ------------------------------------------------------------ frame
    def _wheel_state(self, f):
        # from the landing on, the painted key wheel is the held drawing: a full spoke gap (45 deg) on from
        # the start it looks exactly like the key, so there is never a turned layer over painted spokes
        dd = (f - f % 2) - self.f_wheel
        return None if dd >= 2 else self.turn.get(dd)

    def _head_tilt(self, rgb, a, st):
        """Extra rigid head tilt over pose B (the painted tilt alone is a few px at phone size)."""
        ang = {"antAB": -1.5, "AB": 2.0, "B": 4.0}.get(st)
        if ang is None:
            return rgb, a
        h, w = a.shape
        cx, cy, rr = HEAD[0] * SC, HEAD[1] * SC, HEAD[2] * SC
        px, py = NECK[0] * SC, NECK[1] * SC
        x0, y0 = int(cx - rr * 1.6), int(cy - rr * 1.6)
        x1, y1 = int(cx + rr * 1.6), int(py + rr * 0.3)
        gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
        wgt = np.clip(1.0 - (np.hypot(gx - cx, (gy - cy) * 0.85) - rr) / (rr * 0.5), 0, 1)
        wgt *= np.clip((py - gy) / (rr * 0.3), 0, 1)                    # the neck base stays attached
        t = math.radians(-ang)
        sx = px + (gx - px) * math.cos(t) - (gy - py) * math.sin(t)
        sy = py + (gx - px) * math.sin(t) + (gy - py) * math.cos(t)
        sx = gx + wgt * (sx - gx)
        sy = gy + wgt * (sy - gy)
        rgb = rgb.copy()
        rgb[y0:y1, x0:x1] = cv2.remap(rgb, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        return rgb, a

    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        fh = f - f % 2
        st = PoseSwap.state(f, self.swaps) if self.pose else "A"
        z = self.flicker[(fh // 2) % len(self.flicker)]
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            fl = self.flames[i]
            if fl is not None:                                       # torches / brazier breathe on 2s
                rgb = rgb * (1 + fl[..., None] * (0.12 * np.tanh(z)[..., None] - 0.02))
            if i == 0 and self.pose:
                n = self.pose.nearness(n, a, st)
                rgb, a = self.pose.apply(rgb, a, st)
                rgb, a = self._head_tilt(rgb, a, st)
            if i == 1:
                ws = self._wheel_state(f)
                if ws is not None:
                    wh = self.wheel
                    turned = self._turned(*ws)
                    k = wh["wood"][..., None]
                    rgb = rgb * (1 - k) + turned * k
            rps.append({"rgb": rgb.astype(np.float32), "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self.dust.draw(self.cam, th * 0.3, img, warm=(0.40, 0.34, 0.60), core=(0.86, 0.82, 1.0), intensity=0.30)
        x0, y0, _, _ = safe_box()
        self.draw_data_tag(img, f, QUOTE, self.f0 + 2, xy=(x0 - 6, y0 - 4))
        ws = self._wheel_state(f)
        return img, {"pose": st, "wheel": None if ws is None else ws[0]}

    def _speed_arcs(self, img, f, t):
        """Dry-brush speed arcs riding the turning wood on the three smeared drawings (2D effect on 2s)."""
        ws = self._wheel_state(f)
        if ws is None or ws[1] is None or ws[0] - ws[1] < 10:
            return img
        deg, d0 = ws
        Hm = self.wheel["H"]
        n_w = float(nearness(np.float32(0.55)))
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        rng = np.random.default_rng(int(f - f % 2))
        for k in range(8):
            for rad in (0.58, 0.78):
                if rng.random() < 0.45:
                    continue
                base = 45.0 * k + 12.0 + 9.0 * rad
                a1 = base + deg
                a0 = base + d0 - 18.0
                th = np.radians(np.linspace(a0, a1, 14) - 90)
                pts = np.stack([rad * np.cos(th), rad * np.sin(th)], 1)
                kp = cv2.perspectiveTransform(np.float32(pts)[None], Hm)[0]
                q = [self.cam.screen_point((x, y), n_w, t) for x, y in kp]
                for j in range(len(q) - 1):                          # tapered: thin tail, full head
                    wdt = 2.0 + 9.0 * (j / (len(q) - 2))
                    sc.line([q[j], q[j + 1]], wdt, glow=False, value=int(120 + 120 * j / (len(q) - 2)))
        c, _ = sc.result(glow_sigma=2)
        c = c[..., None] * 0.42
        col = np.float32([1.0, 0.80, 0.55])
        return (img * (1 - c) + col * c).astype(np.float32)

    # ------------------------------------------------------------ framework hooks
    def finish_args(self, f, info):
        return {"bloom_strength": 0.5}

    def events(self):
        fw = self.f_wheel
        ev = [(self.f0 + 2, "quote_tag", {}), (fw - 2, "wheel_anticipation", {}), (fw, "wheel_turn", {}),
              (self.f_stop, "wheel_stop", {})]
        if self.pose:
            ev += [(fs - 4, "tilt_anticipation", {}) for fs, _ in self.swaps]
            ev += [(fs, "pose_" + to, {"mask_frac": round(self.pose.info["mask_frac"], 4)}) for fs, to in self.swaps]
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.room_tone(dur + 0.6, seed=121), t0 - 0.2, -30)
        snd.bed(A.crowd(dur + 0.6, seed=122), t0 - 0.2, -36, 0.1)
        tt = A.t_axis(dur + 0.6)
        crackle = A.highpass(A.noise(dur + 0.6, 123), 1800) * (A.noise(dur + 0.6, 124) > 2.6)
        fire = A.lowpass(A.noise(dur + 0.6, 125, "pink"), 500) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.7 * tt))
        snd.bed(0.6 * fire + 0.5 * crackle, t0 - 0.2, -31, -0.5)
        fw = self.f_wheel
        snd.sfx(_creak(0.55, seed=126), snd.at_frame(fw - 2), -17, 0.0)     # the wood groans as it rocks back
        snd.sfx(A.whoosh(0.32, seed=127), snd.at_frame(fw), -19, 0.2)         # and sweeps the quarter turn
        snd.sfx(A.thunk(seed=128), snd.at_frame(self.f_stop), -14, 0.0)        # it lands
        snd.sfx(A.hit(seed=129), snd.at_frame(self.f_stop), -27, 0.0)
        snd.sfx(A.swish(0.2, seed=130), snd.at_frame(self.f_ended - 4), -24, 0.3)   # hair / collar on the tilt
        snd.sfx(A.bell(392.0, 1.4, seed=131) + 0.5 * A.bell(587.3, 1.4, seed=132), snd.at_frame(self.f_ended), -26, 0.3)


def _creak(dur, seed):
    """Wooden creak: a slow, wavering low saw pulse train through a resonant band."""
    rng = np.random.default_rng(seed)
    tt = A.t_axis(dur)
    f0 = 70 + 40 * np.sin(2 * np.pi * 2.3 * tt + rng.uniform(0, 6)) + 25 * tt / dur
    ph = 2 * np.pi * np.cumsum(f0) / A_SR
    pulses = np.maximum(np.sin(ph), 0) ** 6
    x = A.bandpass(pulses + 0.15 * A.noise(dur, seed + 1), 180, 1400)
    env = np.clip(tt / 0.04, 0, 1) * np.clip((dur - tt) / 0.15, 0, 1)
    x = x * env
    return (x / (np.abs(x).max() + 1e-9)).astype(np.float32)


A_SR = int(round(len(A.t_axis(1.0))))


def make(ctx):
    return Shot(ctx)
