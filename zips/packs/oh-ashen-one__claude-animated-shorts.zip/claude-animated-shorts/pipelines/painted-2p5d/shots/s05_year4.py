"""Shot 5, Year 4: "The Iron Bank sends its bill. Cersei's debts are hers now, and the bank has its due."

On "bill" the ledger's pages riffle open to the bill (three drawn pages flip right to left on 2s); on
"hers" the coin river surges (a bright wave runs down the river and coins glint); a counter of gold dragons
owed rolls up on the ledger page with the "scenario" chip; on "due" the banker bows (pose B, ledger closed).
Coins glint on 2s through the whole shot. YEAR 4 and the lore tag while Cersei's debt is spoken.
Coordinates are px of the upscaled key work/keys/g04_ironbank_key.png (1520 x 2701).
"""
import math
from functools import cached_property
from pathlib import Path

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera
from whatif.config import ASSETS, WORK_SCALE
from whatif.fx2d import ShapeCanvas, screen_emissive, star4_poly
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("hall", 0.00, 0.075, fill="full"),
    L.PlaneSpec("thrones", 0.075, 0.20, radius=60),            # thrones, queen, king, far lords
    L.PlaneSpec("banker", 0.20, 0.45, radius=60),              # steps, banker, ledger
    L.PlaneSpec("fore", 0.45, 1.01, radius=70),                # foreground coins and lords
]
# ledger corners (key px): outer edges of the left / right page and the spine
LEFT_OUT = ((470, 1265), (440, 1880))
SPINE = ((862, 1300), (870, 1905))
RIGHT_OUT = ((1290, 1235), (1265, 1870))
LEDGER_C = (865, 1560)
HERO = [(300, 1130), (585, 1130), (610, 1235), (1330, 1215), (1330, 1885), (1130, 1885), (1110, 2480),
        (300, 2480)]                                            # banker + ledger, both poses (clear of the lord)
PAGE = np.float32([0.93, 0.84, 0.68])
FEET = (505, 2440)                                              # the banker's feet: pivot of the bow (key px)
PLATES = ASSETS / "plates"
LABEL_CAP = 36                                                  # caption and SCENARIO chip cap height (px)


def _grabcut(img, core_polys, core_lines, prob_poly, bbox):
    """Figure matte (uint8 0/1, work scale) from GrabCut seeded with hand-measured cores (key px)."""
    s = WORK_SCALE
    H, W = img.shape[:2]
    m = np.full((H, W), cv2.GC_BGD, np.uint8)
    reg = np.zeros((H, W), np.uint8)
    cv2.fillPoly(reg, [np.int32(np.float32(HERO) * s)], 1)
    m[reg > 0] = cv2.GC_PR_BGD
    pr = np.zeros((H, W), np.uint8)
    cv2.fillPoly(pr, [np.int32(np.float32(prob_poly) * s)], 1)
    m[(pr > 0) & (reg > 0)] = cv2.GC_PR_FGD
    core = np.zeros((H, W), np.uint8)
    for pts, wid in core_lines:
        cv2.polylines(core, [np.int32(np.float32(pts) * s)], False, 1, int(wid * s))
    for pg in core_polys:
        cv2.fillPoly(core, [np.int32(np.float32(pg) * s)], 1)
    m[core > 0] = cv2.GC_FGD
    x0, y0, x1, y1 = [int(v * s) for v in bbox]
    mm = m[y0:y1, x0:x1].copy()
    src = cv2.cvtColor((np.clip(img[y0:y1, x0:x1], 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
    cv2.grabCut(src, mm, None, np.zeros((1, 65)), np.zeros((1, 65)), 6, cv2.GC_INIT_WITH_MASK)
    fg = np.zeros((H, W), np.uint8)
    fg[y0:y1, x0:x1] = ((mm == 1) | (mm == 3)).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(fg, 8)
    if n > 1:
        fg = (lab == 1 + np.argmax(st[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
    return cv2.morphologyEx(fg, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))


def _plate(name, build):
    """A matte plate in assets/plates/ (built once from the paintings, then reused by every worker)."""
    p = PLATES / f"{STEM}_{name}.png"
    if p.exists():
        return (cv2.imread(str(p), cv2.IMREAD_GRAYSCALE) > 127).astype(np.uint8)
    m = build()
    PLATES.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp.png")
    cv2.imwrite(str(tmp), m * 255)
    tmp.replace(p)
    return m


def _about(img, ang, sy, piv, interp=cv2.INTER_LINEAR):
    """Rotate img by ang degrees (cv2 sense: + = counter-clockwise) and stretch it vertically by sy,
    both about the pivot piv (work px), so the feet stay planted."""
    px, py = piv
    R = cv2.getRotationMatrix2D((float(px), float(py)), float(ang), 1.0)
    S = np.float32([[1, 0, 0], [0, sy, py * (1 - sy)], [0, 0, 1]])
    M = (np.vstack([R, [0, 0, 1]]) @ S)[:2].astype(np.float32)
    return cv2.warpAffine(img, M, (img.shape[1], img.shape[0]), flags=interp, borderMode=cv2.BORDER_CONSTANT,
                          borderValue=0)


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def _coin_mask(img):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    return ((r > 0.72) & (g > 0.50) & (b < 0.55) & (r - b > 0.30)).astype(np.float32)


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, [])
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_bill = ctx.f("bill.")
        self.f_cersei = ctx.f("Cersei's")
        self.f_hers = ctx.f("hers")
        self.f_now = ctx.f("now,")
        self.f_due = ctx.f("due.")
        self.f_b = ctx.f("due.", even=False)                      # pose B lands on the word (frame 571)
        self.flips = [self.f_bill - 6, self.f_bill, self.f_bill + 6]
        self.f_fade = self.f_b - 8                                 # counter fades over 4 frames before the rise
        self.f_count = (self.f_cersei, self.f_fade)
        self.cam = ParallaxCamera(
            W, H, focus=(W * 0.55, H * 0.50), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.07, "inout")]),
            push=Track([(0, 0.0), (d, 0.06, "inout")]),
            rise=Track([(0, 0.0), (d, -22.0, "inout")]),
            pan=Track([(0, 0.0), (d, -10.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=HERO, thresh=14.0)
        bx, by = int(1080 * WORK_SCALE), int(1560 * WORK_SCALE)
        self.page_col = self.planes[2]["rgb"][by - 30:by + 30, bx - 30:bx + 30].reshape(-1, 3).mean(0) * 1.02
        # coin glint sites (work px) with their nearness, sampled from the key's brightest coin pixels
        rng = np.random.default_rng(7)
        pts = []
        for p in self.planes:
            m = _coin_mask(p["rgb"]) * (p["a"] > 0.9)
            ys, xs = np.nonzero(m)
            if len(xs):
                k = rng.choice(len(xs), min(len(xs), 260), replace=False)
                pts += [(xs[j], ys[j], float(p["n"][ys[j], xs[j]])) for j in k]
        self.sites = np.float32(pts)

    # ------------------------------------------------------------------ the bow: A, rise, smear, B
    def _state(self, f):
        """A until 566; the rise (pose A drawn up and leaning back) 567, the book's right half swinging
        shut 568, the book shut against the chest as he tips forward 569 and held for 570 (the smear
        drawing showed two heads), B from 571 (on "due")."""
        if not self.pose or f < self.f_b - 4:
            return "A"
        return {self.f_b - 4: "rise", self.f_b - 3: "close", self.f_b - 2: "tip", self.f_b - 1: "tip"}.get(f, "B")

    @cached_property
    def _mattes(self):
        a, b = self.pose.a_img, self.pose.b
        mb = _plate("matteB", lambda: _grabcut(
            b, [[(690, 1560), (840, 1500), (860, 1820), (740, 1880)]],
            [([(500, 2400), (500, 2050), (560, 1850), (660, 1700), (800, 1560), (940, 1440)], 70)],
            [(330, 1380), (1060, 1330), (1080, 1560), (980, 1900), (820, 1950), (700, 2470), (330, 2470)],
            (200, 1000, 1450, 2600)))
        ma = _plate("matteA", lambda: _grabcut(
            a, [[(500, 1300), (850, 1320), (1250, 1265), (1235, 1840), (860, 1880), (480, 1860)],
                [(1250, 1240), (1326, 1222), (1326, 1878), (1240, 1890)],            # right cover + hand
                [(470, 1840), (880, 1890), (1240, 1850), (1240, 1905), (880, 1950), (470, 1895)]],  # bottom
            [([(500, 2400), (480, 2000), (440, 1600), (420, 1330)], 70)],
            [(320, 1180), (560, 1180), (620, 1240), (1320, 1220), (1320, 1900), (900, 1960), (760, 2470),
             (320, 2470)],
            (200, 1000, 1450, 2600)))
        return ma, mb

    @cached_property
    def _bg(self):
        """Pose B's painting with its banker removed: the stairs run horizontally, so each hole pixel is
        cloned from the same row further right (twice for the widest rows)."""
        _, mb = self._mattes
        bg = self.pose.b.copy()
        hole = cv2.dilate(mb, np.ones((9, 9), np.uint8)).astype(bool)
        dx = int(round(450 * WORK_SCALE))
        for _ in range(3):
            src_ok = np.zeros_like(hole)
            src_ok[:, :-dx] = ~hole[:, dx:]
            take = hole & src_ok
            bg[:, :-dx][take[:, :-dx]] = bg[:, dx:][take[:, :-dx]]
            hole &= ~take
        if hole.any():
            bg = L.push_pull_fill(bg, (~hole).astype(np.float32))
        return bg

    def _fig(self, img, m, ang, sy):
        piv = (FEET[0] * WORK_SCALE, FEET[1] * WORK_SCALE)
        al = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 1.2)
        return _about(img, ang, sy, piv), _about(al, ang, sy, piv)

    @cached_property
    def _base(self):
        """The key's own painting with only the two figures' footprint replaced by pose B's empty stairs, so
        nothing but the banker changes between drawings (pose B's repainted stairs and throne stay out)."""
        ma, _ = self._mattes
        hole = cv2.dilate(ma, np.ones((15, 15), np.uint8)).astype(np.float32)   # only where pose A stood
        hole = cv2.GaussianBlur(hole, (0, 0), 4)[..., None]
        return (self.pose.a_img * (1 - hole) + self._bg * hole).astype(np.float32)

    def _over_base(self, rgb, al):
        return (self._base * (1 - al[..., None]) + rgb * al[..., None]).astype(np.float32), al

    @cached_property
    def rise(self):
        """Anticipation: pose A drawn 3.5 % taller and leaning back 2 degrees about the feet."""
        ma, _ = self._mattes
        return self._over_base(*self._fig(self.pose.a_img, ma, 1.5, 1.025))

    @cached_property
    def close(self):
        """The rise with the book's right half swung up on edge (closing): the right page and cover leave,
        a turning leaf stands at the spine."""
        ma, _ = self._mattes
        s = WORK_SCALE
        img = self.pose.a_img.copy()
        m = ma.astype(np.float32)
        rp = np.float32([(SPINE[0][0] + 6, SPINE[0][1] - 40), (RIGHT_OUT[0][0] + 60, RIGHT_OUT[0][1] - 40),
                         (RIGHT_OUT[1][0] + 60, RIGHT_OUT[1][1] + 50), (SPINE[1][0] + 6, SPINE[1][1] + 50)]) * s
        cut = np.zeros_like(m)
        cv2.fillPoly(cut, [np.round(rp * 4).astype(np.int32)], 1.0, cv2.LINE_AA, shift=2)
        m = m * (1 - cut)
        prgb, pa = self._page_rgba(0.42, m.shape)
        img = img * (1 - pa[..., None]) + prgb * pa[..., None]
        m = np.maximum(m, pa)
        piv = (FEET[0] * s, FEET[1] * s)
        al = _about(cv2.GaussianBlur(m, (0, 0), 1.2), 1.5, 1.025, piv)
        return self._over_base(_about(img, 1.5, 1.025, piv), al)

    @cached_property
    def tip(self):
        """Pose B's banker (book shut) still near upright, 22 degrees back toward pose A."""
        _, mb = self._mattes
        return self._over_base(*self._fig(self.pose.b, mb, 22.0, 1.0))

    @cached_property
    def pose_b(self):
        """Pose B's banker on the key's own background."""
        _, mb = self._mattes
        return self._over_base(*self._fig(self.pose.b, mb, 0.0, 1.0))

    @cached_property
    def smear(self):
        """One smear drawing: pose B swung back toward upright (lead at +10 degrees) with two dragged
        trailing drawings behind it (+19, +15 degrees, motion-blurred, thinner paint)."""
        _, mb = self._mattes
        out = self._base.copy()
        cov = np.zeros(out.shape[:2], np.float32)
        for ang, op, blur in ((19.0, 0.45, 12), (15.0, 0.7, 7), (10.0, 1.0, 0)):
            rgb, al = self._fig(self.pose.b, mb, ang, 1.0)
            if blur:
                k = np.zeros((blur * 2 + 1, blur * 2 + 1), np.float32)
                k[blur, :] = 1.0                                   # drag along the swing (mostly sideways)
                k /= k.sum()
                rgb, al = cv2.filter2D(rgb, -1, k), cv2.filter2D(al, -1, k)
            al = al * op
            out = out * (1 - al[..., None]) + rgb * al[..., None]
            cov = np.maximum(cov, al)
        return out.astype(np.float32), cov

    @cached_property
    def planes(self):
        out = []
        for p in self.lay.planes:
            rgb = p["rgb"].astype(np.float32) / 255
            out.append({"rgb": rgb, "a": p["a"].astype(np.float32) / 255,
                        "n": nearness(p["d"].astype(np.float32) / 65535), "coin": _coin_mask(rgb)})
        return out

    # ------------------------------------------------------------------ the ledger's pages
    def _page_rgba(self, u, shape):
        """One page mid-flip (u 0 = lying on the right page, 1 = on the left), drawn at work scale. The page
        turns about the spine toward the viewer and curls (its outer part lags), so every drawing has body:
        12 strips, each shaded by how much it faces the viewer, scaled up as it comes closer."""
        H, W = shape
        s = WORK_SCALE
        n = 12
        sx = (SPINE[0][0] + SPINE[1][0]) * 0.5
        wp = ((RIGHT_OUT[0][0] + RIGHT_OUT[1][0]) * 0.5 - sx + sx - (LEFT_OUT[0][0] + LEFT_OUT[1][0]) * 0.5) * 0.5
        cy = (SPINE[0][1] + SPINE[1][1]) * 0.5
        half = (SPINE[1][1] - SPINE[0][1]) * 0.5
        lag = 0.9 * math.sin(math.pi * u)
        x, z = 0.0, 0.0
        cols = [(sx, 0.0, 0.0)]
        for k in range(n):
            w = (k + 0.5) / n
            th = math.pi * u - lag * w * 0.8
            x += math.cos(th) * wp / n
            z += math.sin(th) * wp / n
            cols.append((sx + x, z, th))
        rgb = np.zeros((H, W, 3), np.float32)
        a = np.zeros((H, W), np.float32)
        tex = self.page_tex
        for k, ((x0, z0, _), (x1, z1, th)) in enumerate(zip(cols, cols[1:])):
            p0, p1 = 1 + 0.22 * z0 / wp, 1 + 0.22 * z1 / wp
            # page edges tilt like the book (top edge rises toward the outer side on the right page)
            tilt0, tilt1 = (x0 - sx) / wp * 45, (x1 - sx) / wp * 45
            poly = np.float32([(x0, cy - half * p0 - tilt0), (x1, cy - half * p1 - tilt1),
                               (x1, cy + half * p1 - tilt1 * 0.3), (x0, cy + half * p0 - tilt0 * 0.3)]) * s
            # the painted right page itself, strip k mapped onto this strip
            u0, u1 = k / n, (k + 1) / n
            sq = np.float32([self._rp(u0, 0), self._rp(u1, 0), self._rp(u1, 1), self._rp(u0, 1)]) * s
            M = cv2.getPerspectiveTransform(sq, poly)
            bx0, by0 = np.floor(poly.min(0)).astype(int) - 3
            bx1, by1 = np.ceil(poly.max(0)).astype(int) + 3
            bx0, by0, bx1, by1 = max(bx0, 0), max(by0, 0), min(bx1, W), min(by1, H)
            if bx1 <= bx0 or by1 <= by0:
                continue
            T_ = np.float32([[1, 0, -bx0], [0, 1, -by0], [0, 0, 1]]) @ M
            strip = cv2.warpPerspective(tex, T_, (bx1 - bx0, by1 - by0), flags=cv2.INTER_LINEAR,
                                        borderMode=cv2.BORDER_REFLECT)
            m = np.zeros((by1 - by0, bx1 - bx0), np.float32)
            cv2.fillPoly(m, [np.round((poly - [bx0, by0]) * 4).astype(np.int32)], 1.0, cv2.LINE_AA, shift=2)
            face = abs(math.cos(th))
            back = 0.84 if math.cos(th) < 0 else 1.0
            shade = (0.60 + 0.40 * round(face * 4) / 4) * back
            # gutter shadow near the spine, a little light catching the lifted outer edge
            g = 0.80 + 0.20 * min(1.0, (k + 0.5) / n * 2.2) + (0.05 if k == n - 1 else 0.0)
            sub = rgb[by0:by1, bx0:bx1]
            rgb[by0:by1, bx0:bx1] = sub * (1 - m[..., None]) + strip * (shade * g) * m[..., None]
            a[by0:by1, bx0:bx1] = np.maximum(a[by0:by1, bx0:bx1], m)
        edge = cv2.morphologyEx((a > 0.5).astype(np.uint8), cv2.MORPH_GRADIENT, np.ones((3, 3), np.uint8)).astype(np.float32)
        rgb = rgb * (1 - edge[..., None] * 0.7) + np.float32([0.35, 0.18, 0.12]) * edge[..., None] * 0.7
        return rgb.astype(np.float32), a

    def _rp(self, u, v):
        """Point on the painted right page (key px): u 0 = spine, 1 = outer edge; v 0 = top, 1 = bottom."""
        top = np.float32(SPINE[0]) * (1 - u) + np.float32(RIGHT_OUT[0]) * u
        bot = np.float32(SPINE[1]) * (1 - u) + np.float32(RIGHT_OUT[1]) * u
        return top * (1 - v) + bot * v

    @cached_property
    def page_tex(self):
        """The book plane's own painted pixels (paper tooth, warm light), source of the turning pages."""
        return np.ascontiguousarray(self.planes[2]["rgb"])

    def _flip_pages(self, rgb, a, f):
        fh = f - f % 2
        for fs in self.flips:
            d = fh - fs
            if d in (0, 2, 4):
                prgb, pa = self._page_rgba({0: 0.28, 2: 0.52, 4: 0.76}[d], a.shape)
                # the lifted page throws a soft shadow onto the pages under it
                sh = cv2.GaussianBlur(np.roll(pa, (14, 10), (0, 1)), (0, 0), 14) * (1 - pa)
                rgb = rgb * (1 - 0.32 * sh[..., None])
                rgb = rgb * (1 - pa[..., None]) + prgb * pa[..., None]
                a = np.maximum(a, pa)
        return rgb, a

    # ------------------------------------------------------------------ the coin river
    def _surge(self, pl, f):
        """Coin brightness: a wave down the river on "hers" (key y 1000 -> 2700 over 14 frames)."""
        d = (f - f % 2) - self.f_hers
        if d < -2 or d > 22:
            return pl["rgb"]
        H = pl["rgb"].shape[0]
        yc = (1000 + max(d, 0) / 14.0 * 1900) * WORK_SCALE
        y = np.arange(H, dtype=np.float32)[:, None]
        band = np.exp(-((y - yc) / (240 * WORK_SCALE)) ** 2) * (1.0 if d <= 14 else max(0.0, 1 - (d - 14) / 8))
        k = band * 0.55 + 0.10 * max(0.0, 1 - abs(d - 4) / 16)
        return np.clip(pl["rgb"] + pl["coin"][..., None] * k[..., None] * np.float32([0.55, 0.38, 0.10]), 0, 1)

    def frame(self, f):
        t = self.ctx.local(f)
        st = self._state(f)
        src, fa = ({"rise": self.rise, "close": self.close, "tip": self.tip, "smear": self.smear, "B": self.pose_b}[st]
                   if st != "A" else (None, None))
        pst = "AB" if src is not None else st                   # PoseSwap.apply takes any non-A state + src
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = self._surge(pl, f), pl["a"], pl["n"]
            if i == 2 and st == "A":
                rgb, a = self._flip_pages(rgb, a.copy(), f)
            if st != "A" and i in (1, 2, 3):
                n = self.pose.nearness(n, pl["a"], pst, whole_region=True)
                if i == 2 and fa is not None:
                    # the banker's plane: the drawing may reach past the region's edge (the book rising)
                    m = np.maximum(self.pose._m(pl["a"], rgb.shape[:2], True), fa)
                    rgb = (rgb * (1 - m[..., None]) + src * m[..., None]).astype(np.float32)
                    a = np.maximum(np.maximum(a, self.pose.mask), fa).astype(np.float32)
                else:
                    rgb, a = self.pose.apply(rgb, a, pst, src=src, whole_region=True)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._glints(img, f, t)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Cersei borrowed from the Iron Bank to hire the Golden Company: 20,000 men",
                           self.f_cersei)
        self._counter(img, f, t)
        return img, {"pose": st}

    def _glints(self, img, f, t):
        fh = f - f % 2
        rng = np.random.default_rng(fh)
        d = fh - self.f_hers
        rate = 0.05 + (0.22 * max(0.0, 1 - abs(d - 6) / 14) if -2 <= d <= 22 else 0.0)
        pick = rng.random(len(self.sites)) < rate
        if not pick.any():
            return img
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        for x, y, n in self.sites[pick]:
            q = self.cam.screen_point((x, y), n, t)
            r = (7 + 13 * n) * rng.uniform(0.7, 1.3)
            sc.fill(star4_poly(q, r, rng.uniform(0, 0.5)))
        c, g = sc.result(glow_sigma=4)
        return screen_emissive(img, c, g, (1.0, 0.95, 0.75), (1.0, 0.68, 0.22), opacity=0.9)

    @cached_property
    def _labels(self):
        cap = O._text_alpha("gold dragons owed", T.at_least_cap(T.sans(30, 620), LABEL_CAP))
        cap_rgba, _ = T.styled_text_rgba(cap, (92, 40, 24), seed=8, shadow_off=(1, 1), soft_shadow=2,
                                         shadow_strength=0.2, grad=0.04)
        size = 26
        while T.cap_height(T.sans(size, 600)) < LABEL_CAP:
            size += 1
        return cap_rgba, O.scenario_label(size=size, text="SCENARIO")      # caps on the dark plum plate

    def _counter(self, img, f, t):
        """Gold dragons owed: whole digits stepping on 2s (no half-rolled glyphs), the caption and the
        SCENARIO chip; all three fade out over 4 frames (f_fade .. f_fade+3) instead of sliding away."""
        f_in, f_fade = self.f_count
        if f - f % 2 < f_in or f >= f_fade + 4:
            return
        op = 1.0 if f < f_fade else 1.0 - (f - f_fade + 1) / 5.0
        v = O.roll_value(f, f_in + 2, self.f_now + 4, 0, 6_000_000)
        num = O.counter_rgba(v, fmt="{:,.0f}", size=92, color=(92, 40, 24), decimals=0, roll=False, seed=7)
        cap_rgba, sl = self._labels
        q = self.cam.screen_point((LEDGER_C[0] * WORK_SCALE, LEDGER_C[1] * WORK_SCALE), 0.42, t)
        x = int(q[0] - num.shape[1] / 2)
        y = int(q[1] - num.shape[0] / 2 - 50)
        O.draw_pop(img, num, x, y, f, f_in, None, origin=(num.shape[1] / 2, num.shape[0] / 2), opacity=op)
        yc = y + num.shape[0] - 26
        O.draw_pop(img, cap_rgba, int(q[0] - cap_rgba.shape[1] / 2), yc, f, f_in + 2, None, opacity=op)
        O.draw_pop(img, sl, int(q[0] - sl.shape[1] / 2), yc + cap_rgba.shape[0] + 4, f, f_in + 4, None,
                   opacity=op)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.55}

    def events(self):
        return sorted([(fs, "page_flip", {}) for fs in self.flips] +
                      [(self.f_cersei, "lore_tag+counter", {}), (self.f_hers, "coin_surge", {}),
                       (self.f_fade, "counter_fade", {}), (self.f_b - 4, "rise", {}),
                       (self.f_b - 3, "book_shuts", {}), (self.f_b - 2, "tip", {}), (self.f_b - 1, "tip_hold", {}), (self.f_b, "bow", {})])

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.room_tone(dur + 0.6, seed=61), t0 - 0.2, -30)
        snd.bed(A.crowd(dur + 0.6, seed=62), t0 - 0.2, -38, -0.4)
        rng = np.random.default_rng(63)
        # coins: sparse metallic tinkles all through, a cascade on the surge
        for k in range(int(dur * 3)):
            snd.sfx(A.bell(rng.uniform(2400, 4200), 0.25, seed=64 + k), t0 + rng.uniform(0, dur), -38,
                    rng.uniform(-0.7, 0.7))
        th = snd.at_frame(self.f_hers)
        snd.sfx(A.whoosh(0.8, seed=70), th - 0.15, -20, -0.3)
        for k in range(40):
            snd.sfx(A.bell(rng.uniform(2000, 5200), 0.3, seed=80 + k), th + rng.uniform(0, 0.9) ** 1.5, -27,
                    rng.uniform(-0.8, 0.5))
        for fs in self.flips:
            snd.sfx(A.swish(0.16, seed=120 + fs % 7), snd.at_frame(fs), -21, 0.2)
        # counter: ticks on 2s while it rolls
        for fr in range(self.f_count[0] + 2, self.f_now + 4, 2):
            snd.sfx(A.tick(130 + fr % 5, 2600), snd.at_frame(fr), -31, 0.1)
        # the bow: cloth and a closing book thump
        snd.sfx(A.swish(0.3, seed=140), snd.at_frame(self.f_b - 3), -21, 0.0)
        snd.sfx(A.thunk(seed=141), snd.at_frame(self.f_b), -16, 0.0)


def make(ctx):
    return Shot(ctx)
