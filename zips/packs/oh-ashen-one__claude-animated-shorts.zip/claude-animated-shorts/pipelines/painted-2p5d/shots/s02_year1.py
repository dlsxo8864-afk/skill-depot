"""Shot 2, Year 1: "In year one, the queen marries Jon. Targaryens wed family for three centuries, so the
lords barely blink."

The hand-fasting ribbon tightens on "marries" (hands sprite squeezes on 2s, a glint at the knot); the
banner swings in about its rod (on 2s, one-frame overshoot) and lands with dyed dragon and direwolf crests on
"Targaryens"; one lord on the steps
shrugs (pose B) on "blink". YEAR 1 tag and the data tag while the custom is spoken.
Coordinates are px of the upscaled key work/keys/g01_wedding_key.png (1520 x 2701).
"""
import math
from functools import cached_property, lru_cache

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS, WORK, WORK_SCALE
from whatif.fx2d import ShapeCanvas, screen_emissive, star4_poly
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]

PLANES = [
    L.PlaneSpec("sky", 0.00, 0.14, fill="full"),
    L.PlaneSpec("ruins", 0.14, 0.33, radius=60),
    L.PlaneSpec("couple", 0.33, 0.56, radius=60),
    L.PlaneSpec("crowd", 0.56, 1.01, radius=70),
]


def _cream(img, depth):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    m = ((r - b) > 0.05) & (img.mean(2) > 0.38)
    m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    return m.astype(bool)


BANNER_TOP, BANNER_BOT = 128, 1095                 # cloth from under the rod to the pennant point (key px)
KNOT = (748, 1448)
# hiding the cloth shows a grey pennant ghost from the plane hole fill, so the banner never unrolls: it swings
# in about its top attachment (BANNER_PIVOT) over a backing painted from the sky next to the pole
BANNER_PIVOT = (238, 128)
SPRITES = [
    L.SpriteSpec("banner", 1, [(66, 126), (398, 126), (396, 840), (240, 1098), (72, 840)],   # the pennant
                 pivot=(238, 120)),          # no own-plane fill: the refilled sky shows behind the rippling edge
    L.SpriteSpec("hands", 2, [(652, 1382), (842, 1382), (842, 1512), (652, 1512)], pivot=KNOT,
                 fill_own_plane=True),
]
SHRUG = [(420, 1760), (775, 1760), (775, 2290), (420, 2290)]     # the lord on the steps, both poses


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def _crest(key, box, mask_fn, h):
    """A painted crest cut from a key (upscaled key px box), scaled to height h (work px):
    (grey shade 0..1, alpha 0..1)."""
    x0, y0, x1, y1 = box
    im = cv2.cvtColor(cv2.imread(str(WORK / "keys" / f"{key}.png")), cv2.COLOR_BGR2RGB)[y0:y1, x0:x1]
    im = im.astype(np.float32) / 255
    a = np.clip(mask_fn(im, key, box), 0, 1)
    w = int(round(h * (x1 - x0) / (y1 - y0)))
    lum = im.mean(2)
    lum = (lum - np.quantile(lum[a > 0.5], 0.05)) / (np.ptp(lum[a > 0.5]) + 1e-3)
    rs = lambda x: cv2.resize(x.astype(np.float32), (w, h), interpolation=cv2.INTER_AREA)
    return np.clip(rs(lum), 0, 1), cv2.GaussianBlur(rs(a), (0, 0), 0.7)


def _dragon_mask(im, key, box):
    dp = cv2.imread(str(WORK / "keys" / f"{key}_depth.png"), cv2.IMREAD_UNCHANGED).astype(np.float32)
    dp /= dp.max()
    x0, y0, x1, y1 = box
    m = (dp[y0:y1, x0:x1] > 0.15).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    m = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 1.2)
    return m * np.clip(np.linspace(0, 1, x1 - x0, dtype=np.float32) / 0.18, 0, 1)[None]   # neck fades, no hard cut


def _wolf_mask(im, key, box):
    return np.clip((im.mean(2) - 0.30) / 0.12, 0, 1)


# dragon head and neck from the dragon key (facing right), direwolf head from Jon's clasp in this key
# (facing left): desaturated and multiplied into the cloth so they read as dyed heraldry
DRAGON_CREST = ("g06_dragon_key", (760, 1140, 1360, 1600), _dragon_mask)
WOLF_CREST = ("g01_wedding_key", (1095, 1075, 1255, 1225), _wolf_mask)



TAG_X, TAG_TEXT_W = 312, 512                    # data tag clear of the banner; right edge stays inside x 929


@lru_cache(maxsize=2)
def _narrow_tag(text, max_text_w, size=44):
    """O.data_tag with a narrower wrap width, so the tag fits between the banner and the safe area's edge."""
    a = O._wrapped_alpha(text, T.at_least_cap(T.sans(size, 640), O.TAG_CAP), max_text_w)
    a = np.maximum(T.rough_alpha(a, 83, 0.35), a * 0.85)
    t_rgba, pad = T.styled_text_rgba(a, O.CREAM, seed=80, shadow_off=(1, 2), soft_shadow=4, shadow_strength=0.45,
                                     grad=0.10)
    w, h = a.shape[1] + 74, a.shape[0] + 34
    chip = O.painted_chip(w, h, seed=81 + len(text))
    canvas = np.zeros((h + 20, w + 20, 4), np.float32)
    T.over_rgba(canvas, chip, -2, -2)
    dot = O.painted_swatch(14, 14, seed=82, color=np.float32(O.TEAL) / 255, opacity=1.0, rough=0.1, radius=1)
    T.over_rgba(canvas, dot, 6 + 22, 6 + h // 2 - 7)
    T.over_rgba(canvas, t_rgba, 6 + 50 - pad, 6 + 17 - pad)
    return canvas


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_marries = ctx.f("marries")
        self.f_targ = ctx.f("Targaryens")
        self.f_blink = ctx.f("blink.")
        self.f_swing = (118, 124, 125)                           # swing starts, overshoots, settles ("Targaryens")
        self.cam = ParallaxCamera(
            W, H, focus=(W * 0.50, H * 0.52), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.08, "inout")]),
            push=Track([(0, 0.0), (d, 0.07, "inout")]),
            rise=Track([(0, 0.0), (d, -24.0, "inout")]),
            pan=Track([(0, 0.0), (d, -16.0, "inout")]))
        self.pose = PoseSwap.for_shot(ctx, STEM, region=SHRUG, thresh=14.0)   # auto thresh (22) found nothing
        self.swaps = [(self.f_blink, "B")]

    @cached_property
    def planes(self):
        out = [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]
        # sky behind the rolled banner: refill from sky-coloured pixels only (the generic fill pulls in the
        # grey stone pillar beside it and leaves a grey ghost of the banner)
        s = self.lay.sprites[self.lay.sprite_index("banner")]
        x0, y0, x1, y1 = s["bbox"]
        sky = out[0]["rgb"]
        hole = np.zeros(sky.shape[:2], np.float32)
        hole[y0:y1, x0:x1] = s["rgba"][..., 3].astype(np.float32) / 255
        hole = cv2.dilate((hole > 0.05).astype(np.uint8), np.ones((15, 15), np.uint8)).astype(np.float32)
        r, g, b = sky[..., 0], sky[..., 1], sky[..., 2]
        valid = (hole < 0.5) & (b > r - 0.03) & (sky.mean(2) > 0.42)
        filled = L.push_pull_fill(sky, valid.astype(np.float32))
        n = L.brush_noise(sky.shape[:2], 51, scale=4, angle=-0.2, stretch=8)[..., None]
        filled = filled * (1 + 0.05 * n)
        # match the refill to the warm sky in a ring around the cloth (the blue-only source read as a cool ghost)
        ring = (cv2.dilate(hole, np.ones((61, 61), np.uint8)) > 0.5) & (hole < 0.5) & (sky.mean(2) > 0.42)
        inside = hole > 0.5
        if ring.sum() > 200 and inside.any():
            filled = (filled - filled[inside].mean(0)) * 0.6 + sky[ring].mean(0)
        hs = cv2.GaussianBlur(hole, (0, 0), 3)[..., None]
        out[0]["rgb"] = (sky * (1 - hs) + filled * hs).astype(np.float32)
        return out

    @cached_property
    def banner(self):
        """Banner sprite (work px) plus its crest-dyed version."""
        s = self.lay.sprites[self.lay.sprite_index("banner")]
        rgba = s["rgba"].astype(np.float32) / 255
        x0, y0, x1, y1 = s["bbox"]
        painted = rgba.copy()
        cloth = rgba[..., 3]
        # dragon (upper, facing right) above the direwolf (lower, facing left), both under the data tag: the wolf
        # is 1.6x its old size and both are multiplied in strongly enough to read at 360x640
        for (key, box, mfn), cx, cy, h, tint, k_mul in [
                (DRAGON_CREST, 236, 628, int(140 * WORK_SCALE), (0.62, 0.10, 0.11), 0.82),
                (WOLF_CREST, 232, 822, int(240 * WORK_SCALE), (0.16, 0.18, 0.24), 0.94)]:
            shade, al = _crest(key, box, mfn, h)
            ch, cw = al.shape
            sx, sy = int(cx * WORK_SCALE) - x0 - cw // 2, int(cy * WORK_SCALE) - y0 - ch // 2
            sub = painted[sy:sy + ch, sx:sx + cw, :3]
            ink = np.float32(tint) * (0.50 + 0.70 * shade[..., None])       # painted shading kept, desaturated
            k = (k_mul * al * cloth[sy:sy + ch, sx:sx + cw])[..., None]
            sub[:] = sub * (1 - k + k * np.clip(ink, 0, 1))
        return {"s": s, "rgba": rgba, "painted": painted, "y_top": int(BANNER_TOP * WORK_SCALE) - y0}

    @cached_property
    def backing(self):
        """What shows where the swinging cloth uncovers its own footprint: the footprint inpainted from the
        painting next to the pole, opaque in the banner's plane, so the plane hole fill behind (the grey pennant
        ghost) never shows. RGBA patch at the sprite bbox."""
        s = self.banner["s"]
        x0, y0, x1, y1 = s["bbox"]
        key = cv2.cvtColor(cv2.imread(str(WORK / "keys" / "g01_wedding_key.png")), cv2.COLOR_BGR2RGB)
        key = cv2.resize(key, (self.lay.W, self.lay.H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        fp = (self.banner["rgba"][..., 3] > 0.05).astype(np.uint8)
        fp = cv2.dilate(fp, np.ones((17, 17), np.uint8))       # also covers the cloth's dark trim left in the plane
        # inpaint the footprint from the painting around it (tower and wall left of the pole, sky right of it), so
        # its edge continues what surrounds it with no seam; a little stroke texture keeps it painted
        h, w = fp.shape
        m = 60
        X0, Y0 = max(x0 - m, 0), max(y0 - m, 0)
        X1, Y1 = min(x0 + w + m, self.lay.W), min(y0 + h + m, self.lay.H)
        crop = (key[Y0:Y1, X0:X1] * 255).astype(np.uint8)
        mk = np.zeros(crop.shape[:2], np.uint8)
        mk[y0 - Y0:y0 - Y0 + h, x0 - X0:x0 - X0 + w] = fp
        filled = cv2.inpaint(crop, mk, 12, cv2.INPAINT_TELEA).astype(np.float32) / 255
        out = filled[y0 - Y0:y0 - Y0 + h, x0 - X0:x0 - X0 + w]
        n = L.brush_noise(out.shape[:2], 53, scale=4, angle=-0.2, stretch=8)[..., None]
        out = np.clip(out * (1 + 0.04 * n), 0, 1)
        a = np.maximum(cv2.GaussianBlur(fp.astype(np.float32), (0, 0), 3.0), cv2.erode(fp, np.ones((5, 5), np.uint8)))
        return np.dstack([out, a]).astype(np.float32)

    def _swing(self, f):
        """Banner angle (deg, about its top attachment): it hangs blown out at -10 deg, swings in on 2s across
        118-123, overshoots to +2 for one frame at 124 and settles at 125, landing on "Targaryens"."""
        keys = {118: -8.5, 119: -8.5, 120: -5.5, 121: -5.5, 122: -2.0, 123: -2.0, 124: 2.0}
        if f < 118:
            return -10.0 + 0.6 * math.sin((f - f % 2) * 0.35)         # breeze on 2s
        return keys.get(f, 0.0)

    def _dye(self, f):
        return 0.0 if f < 121 else {121: 0.35, 122: 0.35, 123: 0.70, 124: 0.70}.get(f, 1.0)

    def _banner_patch(self, f):
        """The cloth (crest dyed in 121/123/125) rotated about its top attachment, the top edge held on the rod
        by a weight ramp, on a canvas padded right and down so the swung cloth is never clipped. Returns
        (rgba, x0, y0) in plane px."""
        b = self.banner
        k = self._dye(f)
        rgba = b["rgba"] * (1 - k) + b["painted"] * k
        x0, y0 = b["s"]["bbox"][:2]
        h, w = rgba.shape[:2]
        pad_r, pad_b = 140, 40
        src = np.zeros((h + pad_b, w + pad_r, 4), np.float32)
        src[:h, :w] = rgba
        ang = self._swing(f)
        if abs(ang) < 1e-3:
            return src, x0, y0
        px, py = BANNER_PIVOT[0] * WORK_SCALE - x0, BANNER_PIVOT[1] * WORK_SCALE - y0
        H2, W2 = src.shape[:2]
        gy, gx = np.mgrid[0:H2, 0:W2].astype(np.float32)
        a = math.radians(ang)
        ca, sa = math.cos(-a), math.sin(-a)
        ux, uy = gx - px, gy - py
        sx = ux * ca - uy * sa + px
        sy = ux * sa + uy * ca + py
        wgt = np.clip((gy - b["y_top"]) / 90.0, 0, 1)
        wgt = wgt * wgt * (3 - 2 * wgt)
        sx = gx + wgt * (sx - gx)
        sy = gy + wgt * (sy - gy)
        out = cv2.remap(src, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        return out, x0, y0

    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        st = PoseSwap.state(f, self.swaps) if self.pose else "A"
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a, n = pl["rgb"], pl["a"], pl["n"]
            mine = [s for s in self.lay.sprites if s["plane"] == i]
            if mine or (self.pose and i >= 2):
                rgb, a = rgb.copy(), a.copy()
            for s in mine:
                if s["name"] == "banner":
                    x0, y0 = s["bbox"][:2]
                    composite_into(rgb, a, self.backing, x0, y0)
                    patch, bx, by = self._banner_patch(f)
                    composite_into(rgb, a, patch, bx, by)
                else:
                    sc, dy = self._squeeze(f)
                    patch, x0, y0 = deform_sprite(s, scale=sc, dy=dy)
                    composite_into(rgb, a, patch, x0, y0)
            if self.pose and i >= 2:
                n = self.pose.nearness(n, a, st)
                rgb, a = self.pose.apply(rgb, a, st)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._glint(img, f)
        self.draw_year_tag(img, f)
        # right of the banner (its edge stays left of x ~290 through the move) so both crests read in full
        O.draw_pop(img, _narrow_tag("House Targaryen: 300 years of marriages inside the family", TAG_TEXT_W),
                   TAG_X, O.tag_slots()["data"][1], f, self.f_targ)
        return img, {"pose": st}

    def _squeeze(self, f):
        """The ribbon pulls tight on "marries": anticipation, squeeze, settle (on 2s)."""
        d = (f - f % 2) - self.f_marries
        return {-2: (1.01, 3.0), 0: (0.965, -4.0), 2: (0.975, -2.0), 4: (0.985, -1.0)}.get(
            d, (0.985, -1.0) if d > 4 else (1.0, 0.0))

    def _glint(self, img, f):
        d = (f - f % 2) - self.f_marries
        if d not in (0, 2, 4):
            return img
        q = self.cam.screen_point((KNOT[0] * WORK_SCALE, KNOT[1] * WORK_SCALE), 0.45, self.ctx.local(f))
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        r = {0: 34, 2: 22, 4: 12}[d]
        sc.fill(star4_poly(q, r, 0.2 + 0.3 * d))
        c, g = sc.result(glow_sigma=6)
        return screen_emissive(img, c, g, (1.0, 0.95, 0.85), (1.0, 0.70, 0.35), opacity=1.0 - 0.2 * d / 2)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.5}

    def events(self):
        return [(self.f_marries, "ribbon", {}), (self.f_swing[0], "banner_swing", {}), (self.f_swing[1], "overshoot", {}),
                (self.f_swing[2], "crest_full", {}),
                (self.f_targ, "data_tag", {}), (self.f_blink, "shrug", {})]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.crowd(dur + 0.6, seed=41), t0 - 0.2, -30)
        snd.bed(A.room_tone(dur + 0.6, seed=42), t0 - 0.2, -32)
        # wedding chime on "marries" (a fifth, softly)
        snd.sfx(A.bell(523.0, 1.6, seed=5) + 0.6 * A.bell(784.0, 1.6, seed=6), snd.at_frame(self.f_marries), -21, 0.2)
        # cloth swings in, snaps at the overshoot, then a soft tick as the crest lands
        snd.sfx(A.swish(0.35, seed=7), snd.at_frame(self.f_swing[0]), -16, -0.5)
        snd.sfx(A.thunk(seed=8), snd.at_frame(self.f_swing[1]), -24, -0.5)
        snd.sfx(A.tick(9, 2200), snd.at_frame(self.f_swing[2]), -26, -0.5)
        # the shrug: a light cloth swish
        snd.sfx(A.swish(0.22, seed=10), snd.at_frame(self.f_blink - 2), -20, -0.2)


def make(ctx):
    return Shot(ctx)
