# Pipelines

Two CPU-only Python pipelines that turn one key painting per shot plus a narration track into an animated, sound-designed vertical short. Each has a shared library `whatif/`, one module per shot in `shots/`, a `timeline.py` with the episode constants, an entry script with `--shot`, `--frames`, `--assemble`, `--timeline`, `--words`, and an `ADDING_A_SHOT.md` written for a builder who has never seen the code.

| Folder | Look | Episode it shipped | Entry |
| --- | --- | --- | --- |
| `painted-2p5d/` | hand-painted 3D (Fortiche-style): depth planes, camera on 1s, acting on 2s with a painted pose B, 2D effects on 2s, code-drawn overlays, shared style pass | episodes 1 and 3 | `ep03.py` |
| `claymation/` | stop-motion: everything on 2s including the camera, replacement animation (pose A/B/C), physical text objects, miniature depth of field, tactile sound; `STYLE.md` is the critic's rubric | episode 2 | `ep02.py` |

To start an episode: copy a folder to `<episode>/src/`, rename the entry script, put keys in `<episode>/assets/key/` and narration in `<episode>/assets/voice/<voice>/` with a `lines.json`, edit `timeline.py`, then follow `ADDING_A_SHOT.md`. Run from the episode folder with `uv run --python 3.12 --with-requirements src/requirements.txt python src/<entry>.py ...`. Fonts are fetched by `tools/fetch_fonts.py` (OFL and Apache fonts from the Google Fonts repository); the depth model is Depth Anything V2 Small (ONNX, Apache 2.0), downloaded on first use by `tools/depth.py` where present. The shot modules reference the episodes' own paintings and narration, so they are examples of structure, not runnable without those inputs.
