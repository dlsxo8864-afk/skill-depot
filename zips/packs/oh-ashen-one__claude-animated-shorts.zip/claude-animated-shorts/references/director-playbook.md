# Director playbook: running builders and critics on a narrated short

How one directing session turned pre-production (script, narration, key paintings) into a delivered 60 to 70 second episode in about two and a quarter hours, with five builder agents and two critic passes. Written 2026-11-07 after three episodes; the failures are dated at the end because they cost more than anything else.

The director never builds. It writes briefs, inspects files on disk, runs the critic, decides, assembles and delivers.

## Roles

| Role | Model class | Count | Owns |
| --- | --- | --- | --- |
| Director | the strongest reasoning model | 1 | briefs, schedule, disk checks, assembly, delivery |
| Integration builder | strong coding model | 1 | the shared library, timeline, assembly script, docs; one or two shots |
| Shot builders | strong coding model | 4 | two or three shot modules each, nothing else |
| Critic | strong coding model, fresh context | 1 per pass | read-only; frames, measurements, ranked findings |
| Scout | small fast model | as needed | fact checks, lookups |

Five builders at once was the owner's ceiling for this series. Respect whatever ceiling is set; queue the rest and launch one as each finishes.

## The schedule that worked (one episode)

| Clock | Step |
| --- | --- |
| 0:00 | Integration builder ports or freezes the library, builds the hook and year 1, writes `ADDING_A_SHOT.md`. Box: 2 h, checkpoint at 60 min. Finished in 16 min. |
| 0:16 | Four shot builders, three shots each. Box: 2 h, checkpoint at 45 min ("all your shots render, crude is fine"). Finished in 12 to 25 min; two were killed (see failures). |
| 1:10 | Director assembles the rough cut and reads the contact sheet. |
| 1:12 | Critic pass 1 on the full rough cut. Box: 45 min. Returned in 9 to 10 min with 15 ranked findings. |
| 1:25 | Fix round: four shot builders (60 min box) plus the integration builder for library-wide findings (25 min for library changes, then re-render all shots and assemble). |
| 2:00 | Critic pass 2, re-check only: FIXED / PARTLY / NOT FIXED per finding, new regressions, measurements. Box: 30 min. |
| 2:05 | Small round: one or two builders, 20 min box, on whatever the re-check left. |
| 2:15 | Director assembles the final, measures, makes the phone copy, delivers. |

A third critic pass was needed once (episode 2), when a prop removal failed twice.

## Writing a builder brief

Every brief has all of these, in this order:

1. **Ownership.** The exact files the builder may create or edit. Shot builders own only their shot modules (and plates named with their stem). "If you need a library change, work around it in your file and list it in the report."
2. **Hard time box** and a **checkpoint**: "At 45 minutes all three shots must render end to end, crude is fine." "Never more than 15 minutes on one detail." "At the limit, stop, make sure it renders, report."
3. **What to read first**, in order: the adding-a-shot guide, the run command, the shot list rows for their shots, the style text, one finished shot module as the template.
4. **The spec per shot**: key image, pose B image, event and its sync word, overlays, labels for invented figures, the safe area in output pixels, minimum cap height, "not covering the painting's subject".
5. **Verification they must do**: stills at the event frames at full size and at phone size (360x640); for fixes, a numeric check where one exists (per-frame pixel difference outside a cut, mean difference outside the moving region's mask, text cap height in pixels, loudness).
6. **Report format and length**: "under 15 lines: what renders, event frames, departures from the spec, weak spots, library gaps."

For a fix round, paste the critic's findings verbatim with frame numbers and its one-line fix, and add the measurement that proves the fix.

For an integration builder in a fix round: library changes first with a short box (20 to 25 min), then write a `LIBRARY_READY.txt` marker, re-render s13 or whatever it owns, then wait for the shot builders, then re-render every shot older than the marker and assemble.

## Enforcing the time box (the part that actually matters)

A time box written in a brief does nothing by itself. A stuck agent does not report at its limit. The director enforces it:

- Before spawning, arm a background alarm (`sleep 590; echo ALARM` as a background shell command; the harness caps it at ten minutes, so re-arm it every time it fires).
- At every alarm, `ls -lt` the work directory and the shot modules. Look at the newest files, not at the agents' status text.
- No new file from a builder in 30 minutes: stop it and respawn with a tighter brief (shorter box, strict item order, 10-minute render checkpoint, "if a shell command fails twice, write a small Python file and run that instead of fighting quoting"). Both retries in this series finished in 8 to 15 minutes.
- Never block the next phase on a straggler. When a rough cut can be assembled, assemble it and start the critic; the straggler's shot is "the version on disk".
- Interim notices ("waiting for my render") are not progress. Only files are.

## Critic briefs

Pass 1 (full cut, 45 min box, read-only, own scratch folder):

- Material: the cut, the per-shot renders and metadata, the shot list and script, the style text, the key paintings, the narration list, and the previous episode's final as the look reference.
- Method: extract frames with ffmpeg (every 0.25 s plus every frame around each event), view at full size and 360x640; measure loudness, true peak, gap level against speech level, first-word onset, CTA hold, event frame against the sync word's measured time.
- A numbered rubric (the claymation one is `pipelines/claymation/STYLE.md`; the painted one is in the episode 3 critic brief below).
- The builders' self-reported weak spots, to verify.
- Output: at most 15 items ranked by viewer impact, each with shot, frame numbers, what is wrong, the rubric number, and a one-line fix a builder can do in under 20 minutes. Then READY / READY AFTER FIXES 1 to N / NOT READY with the single most important reason. "Harsh and specific; no praise padding."

Pass 2 (re-check, 30 min box): the same findings numbered, FIXED / PARTLY / NOT FIXED with the frame checked, at most five new regressions with frames, measurements, a one-line verdict: SHIP, SHIP AFTER (list, each under 15 minutes), or NOT READY.

Painted-look rubric used for episode 3:

1. Hook: first word within 0.3 s; title legible; the disclaimer tag present on the hook and the end card.
2. Every shot: year tag correct and consistent; one lore or data tag with the spoken fact, shown while spoken, cap height at least 30 px, inside the safe area, not covering faces, hands or the key object.
3. The event lands within 2 frames of its sync word.
4. Pose-to-pose acting: anticipation, in-between, hold; no cross-fade or morph; no ghost of pose A; no background change outside the moving region.
5. Camera on 1s with parallax; no stretched or torn plates at the edges; life and effects on 2s.
6. Painted texture preserved; no plastic smoothing; no bloom beyond the key's own glow; the style pass and colour consistent across cuts.
7. Invented figures carry a "scenario" label.
8. Every on-screen fact and spelling checked against the source material.
9. No likeness of a real performer, no footage, music or logos from the reference.
10. Narration on top; effects on event frames; no pumping in the gaps; hard cuts; the end card holds at least 2.0 s after the last word; total at least the minimum length.

What the critics caught that builders and the director missed: a lore error on a tag (the Great Council of 101 AC chose an heir; 233 AC chose a king), a continent disappearing under a pose swap, a wheel that doubled its spokes, three different hands in one shot, music rising to speech level in every gap, source lines 24 px tall at phone size, a tag covering the crest it was about.

## Delivery

- Master to about -14 LUFS integrated with true peak at or below -1 dBTP; the AAC encode can add 3 dB of peak, so re-master in a loop until the encoded file passes.
- Make a 720x1280 CRF 23 phone copy (15 to 30 MB) for messaging.
- Copy the final, the phone copy and the contact sheet to the agreed cloud folders, then send the phone copy with a short message and the folder names.
- Update the handoff file, commit the code (media stays local and ignored), run a secrets scan on the staged files before every commit, push the task branch.

## Numbers from this series

- Shot render: about 30 s per shot with 6 workers on CPU (painted look); claymation similar.
- Builder report sizes: 130,000 to 280,000 tokens per builder per round.
- Critic pass: 150,000 to 190,000 tokens, 5 to 10 minutes.
- Episode 2 (claymation): rough cut to delivered final in about 2 h 15 min once the director enforced time boxes. Episode 3 (painted): pre-production to delivered final in 2 h 16 min.

## Failures, dated

- **2026-11-07, 11 hours.** The first integration builder polished two shots for eleven hours (placard positions, letter timing) because its brief had no time limit and the director waited for its completion notice. Nothing else moved. Fix: the time box, the checkpoint, and fan-out as soon as the library imports.
- **2026-11-07, 13 hours.** After writing that rule down, the director still waited 13 hours on one shot builder whose last file write was at 04:28, with a finished rough cut on disk since 04:41. The time box in the brief did nothing because nobody enforced it. Fix: the alarm loop, the 30-minute no-file rule, never blocking a phase on a straggler.
- **2026-11-07, two stuck builders.** One looped on shell quoting, one on a shot edit; neither wrote a file for 30 minutes or answered a message. Both were stopped; retries with strict item order finished in minutes.
- **Whole-frame pose swaps.** Pose B paintings used as whole frames swapped backgrounds (a landmass vanished; a map rim moved). Rule: composite pose B only through the moving region's feathered mask over the key A plate, and measure the difference outside the mask (set-level under 1; grain adds about 4 on delivered frames).
- **Code inpainting a removed prop** failed twice on a painted plate (a jigsaw of copied stones, then a brown stain). Asking the image model for a variant of the key with the prop removed and compositing that region worked the first time (`tools/gen_pose_variant.sh <episode> <stem> "<what is removed>" clean`).
- **Image tool paths.** `gen_key_images.sh` changes directory into the episode, so it needs an absolute episode path. Apostrophes inside a `zsh -c "..."` string break the lane; reword the prompt.
- **Speech model names.** Kokoro mispronounced "Daenerys"; phoneme hints in the text to speak fixed it, verified by re-transcribing the line.
