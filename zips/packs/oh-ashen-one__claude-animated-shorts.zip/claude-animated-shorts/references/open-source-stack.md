# Open-source repos to learn from

Reviewed 2026-11-06 from GitHub search, READMEs and license files. Star counts are from that day. Nothing here was installed or run for this review, so claims about output quality are the authors' own.

The use case behind the ranking: narrated "what if" explainer shorts (what if water vanished, what if the world ended tomorrow), made by a coding agent that writes the animation as code.

## Take the method from these

| Repo | Stars | License | What to take |
| --- | --- | --- | --- |
| [lemomo-ai/lemo-opuscar](https://github.com/lemomo-ai/lemo-opuscar) | 12.9k | MIT | 66 film styles written as style prompts and tuned for Claude Opus 5.5. Canvas and WebGL pages rendered frame by frame, scores from free sample libraries, text-to-speech narration, no video model. Read `DIRECTOR.md`, `TECHNIQUE.md` and `styles/` |
| [cth9191/animate](https://github.com/cth9191/animate) | 1.6k | MIT | A story grammar with 8 short-form formats, three approval steps before animating (story, look, storyboard), a line that boils on 2s, shape-morph transitions, and measured delivery checks: cuts on the beat grid, loudness arc, narration pace |
| [vincentsch/explainroo](https://github.com/vincentsch/explainroo) | 0.9k | MIT | Two-file authoring (`script.md` and `scenes.js`) where each drawing appears on a spoken word. Local Kokoro voice with word timings, no account or key |
| [yihui-dev/awesome-opus5-5-videos](https://github.com/yihui-dev/awesome-opus5-5-videos) | 13.9k | MIT | 703 prompts behind code-written videos made with Opus 5.5, with an Explainers section. Use it as a prompt library and a bar for what one prompt can produce |
| [JuneYaooo/rea-video](https://github.com/JuneYaooo/rea-video) | 2.7k | Apache-2.0 | Breaks a reference video down shot by shot: how each shot was made, text and motion timing, a plan to rebuild it. Fits Gate 1 research |
| [HeyChengC/vibe-knowledge-film](https://github.com/HeyChengC/vibe-knowledge-film) | 1.1k | MIT | Two looks for knowledge shorts taken from viral examples, a 30-second sample before the full film, canvas frames captured through Chrome |

## Renderers

| Repo | Stars | License | Notes |
| --- | --- | --- | --- |
| [heygen-com/hyperframes](https://github.com/heygen-com/hyperframes) | 80k | Apache-2.0 | HTML, CSS and seekable animation to deterministic MP4. Ships agent skills and a Claude Code plugin |
| [remotion-dev/remotion](https://github.com/remotion-dev/remotion) | 71k | Remotion License | React to video. Free for individuals and small teams; larger companies need a paid license, so read the terms first |
| [ManimCommunity/manim](https://github.com/ManimCommunity/manim) | 42k | MIT | Math and diagram animation in Python |
| [ahujasid/mcp-for-blender](https://github.com/ahujasid/mcp-for-blender) | 33k | MIT | Drives Blender from an agent, for 3D shots |

## Voice, music and editing

| Repo | Stars | License | Notes |
| --- | --- | --- | --- |
| [hexgrad/kokoro](https://github.com/hexgrad/kokoro) | n/a | Apache-2.0 | Small local text-to-speech model, 54 voices. The default narrator in several repos above |
| [debpalash/VoiceStudio](https://github.com/debpalash/VoiceStudio) | 103k | AGPL-3.0 | Local voice cloning and voice design |
| [multimodal-art-projection/YuE](https://github.com/multimodal-art-projection/YuE) | 13k | Apache-2.0 | Music generation |
| [kajisho5/ffmpeg-skill](https://github.com/kajisho5/ffmpeg-skill) | 4.7k | MIT | 42 FFmpeg tools with an agent contract |

## Whole pipelines, for structure only

| Repo | Stars | License | Notes |
| --- | --- | --- | --- |
| [harry0703/MoneyPrinterTurbo](https://github.com/harry0703/MoneyPrinterTurbo) | 140k | MIT | Topic to short video from stock footage. Useful for the script, voice, subtitle and music stages; the stock-footage look is not what this skill aims for |
| [calesthio/OpenMontage](https://github.com/calesthio/OpenMontage) | 78k | AGPL-3.0 | 12 production pipelines and a large tool set. AGPL: read it for ideas, do not copy code into an MIT project |
| [Vincentwei1021/anything2explainer](https://github.com/Vincentwei1021/anything2explainer) | 3.1k | Custom, with a required notice | Topic to narrated Remotion explainer, with parallel build agents and frame QC against written criteria. Read the license before reusing anything |
| [Alisa0808/vox-director](https://github.com/Alisa0808/vox-director) | 2.7k | MIT | Paper-collage explainers. Two gates worth copying: approve the beat map, then pick the look from the same beat rendered in 3 or 4 themes. Its generation runs on a paid API |
| [kaomei/stickman-video-director](https://github.com/kaomei/stickman-video-director) | 4.5k | MIT | Script to stickman explainer in 10 styles |

## Lists

- [zhuyansen/awesome-claude-video-skills](https://github.com/zhuyansen/awesome-claude-video-skills): 180 video skills and toolkits for coding agents (CC0 list).
- [Vincentwei1021/video-shotcraft](https://github.com/Vincentwei1021/video-shotcraft): 124 Remotion shot recipes for product promos (Apache-2.0).

## What this adds to the skill

Three ideas recur across the best of these and are not yet in `SKILL.md`:

1. **Approve the story before the look.** A numbered beat table with checked facts comes first.
2. **Bake off the look.** Render one beat in three or four looks and pick by eye, before building anything else.
3. **Measure the delivery.** Check cut timing, loudness and narration pace with numbers, on top of comparing frames.
