# Narrated explainer shorts: the pipeline that worked

A recipe for a vertical, narrated "what if" short (about 60 to 70 seconds, 10 to 14 shots) in a named studio's style, built without a video-generation model. Written from a real build; the dated lessons at the end record what went wrong.

Use this when the request is a narrated explainer or list-style short. For a single wordless hero shot, the four gates in `SKILL.md` are enough.

## Order of work

1. **Script** (agree it with the owner before anything is built)
2. **Voice** (the owner picks by ear; record every line at the final pace)
3. **Key paintings** (one per shot, from an image model)
4. **First 10 to 15 seconds** (build two shots end to end and show them)
5. **Remaining shots** (in parallel, on a frozen shared library)
6. **Assembly, critic pass, fixes**

Each step is cheap to redo before the next one starts and expensive after.

## 1. Script

- The hook is the question itself, and the first item follows immediately. No setup line.
- A numbered list by year ("Year 1" to "Year 10") gives the visuals a structure. Put the three most relatable items first.
- The narrator talks to the viewer in full sentences with "you" or "we". A label followed by a statistic ("TikTok. Two billion users.") reads as a slide, not a voice.
- Objective, professional wording. Keep the punch in the pictures.
- Every item needs a link the viewer can follow in one sentence. If you have to explain why the item belongs, rewrite the line so it says so. Cut items that overreach.
- Spoken numbers are real, current and checked at the primary source. Invented figures (a future price) are allowed as a scenario and carry a "scenario" label on screen. Keep a source list.
- Visuals are exaggerated versions of the consequence: cash shovelled into a television, a balance spinning to zero. Money and loss read fastest.
- End with a catch that reframes the list, then a question that makes the viewer choose something.
- Length: count words. A calm read at about 165 words a minute plus 0.4 s between lines turns 160 words into roughly 67 seconds. Ask whether the stated length is a target or a floor.

`templates/explainer-script.md` holds the table format.

## 2. Voice

- The agent cannot hear. Do not pick a voice from pitch or pace measurements: that selects a steady voice, not a human one. Render the same two lines in several voices and let the owner listen.
- Generate at the final pace. Time-stretching a slow take makes the cadence worse.
- About 160 to 175 words a minute. A take at 125 to 155 was called "slow motion".
- One audio file per line, plus a JSON file with the text of each. Spell out what a speech model garbles ("A.I.", "S and P five hundred").
- Transcribe each line for word timestamps; every picture event is pinned to a word.
- A free local model (Kokoro) was preferred over a paid preset voice in this build.

## 3. Key paintings

- One painting per shot. The first is the style key; attach it as a reference to every later prompt and reuse one shared style paragraph word for word.
- Leave every screen, sign, label, receipt and price tag blank in the prompt. All text is drawn in code, where it is exact and can animate.
- Compose for the event: the blank screen faces the camera, the thing that will change (lights, windows) is clearly separable, and the top of the frame stays calm for titles.
- Real stills from the reference show are the bar for the critic. Keep them local and never feed them to the generator.
- Check the size you get back. Different tools returned 1520x2688 and 941x1672 for the same request; upscale on the way in.

## 4. Animating a painting without a video model (2.5D)

All on CPU, in Python with numpy, OpenCV, Pillow and ffmpeg:

1. **Depth**: a small monocular depth model splits the painting into near, middle and far.
2. **Camera on 1s**: layers slide at different speeds as the virtual camera pushes in; gaps behind the foreground are inpainted.
3. **Life on 2s**: small warps of hands, signs and props, updated every second frame and held.
4. **Events in code**: lights dying, a feed scrolling on a phone, a notification, a counter rolling, each painted over the image with the light it casts on nearby surfaces.
5. **Overlays**: titles, year tags, data tags and interfaces, placed in perspective on the blank surfaces.
6. **One finish over everything**: grain that changes on 2s, canvas texture, bloom on emissive areas, vignette.
7. **Sound**: synthesized effects placed on the event frames, narration on top, mastered to about -14 LUFS.

Structure the code as one module per shot on a shared library, with each shot renderable alone and an assemble step. Freeze the shared library before more than one builder works on shots.

What this method cannot do on its own: people move like cut-outs. Two things close most of that gap:

- **A second painted pose per hero.** Give the image model the key painting and ask for "the very next key pose of the same shot", changing only the character and keeping everything else identical. Align it to the key, take only the hero region through a soft mask, and animate hold A, one smear frame, hold B. A wind-up and a thrust make a real action; a walk needs the opposite step. Ask for the acting beat the line needs (a recoil, a shout, a reach), not a small variation.
- **An image-to-video model** for natural continuous motion, with overlays kept in code. Not used in this build.

## 4b. Parallel build

- One integration builder owns the shared library, the timeline and the assembly. Everyone else creates only files named for their own shots.
- Freeze the shared library before the other builders start, and write a short "adding a shot" guide with a template.
- Two shots per builder worked. Every brief names the files the builder may touch, the review rounds required, and the report format.
- Each builder writes local helpers when the shared library lacks something and lists them for hoisting later.
- Shot lengths come from the narration; tell builders the tail may grow slightly so every shot ends on a hold.
- Re-render every shot through the final shared code before assembly, so grade, cuts and label sizes are consistent.

## 4c. What an independent critic caught that the builders did not

Give the critic the shot list as the specification, the style checklist, the real reference stills and an explicit scoring rubric. On the first full cut it found:

- No hero changed pose anywhere: what looked like life was a warp sway.
- A colour wash from the key paintings (35 to 87% purple pixels per frame against at most 9% in the reference stills). Fixed with a per-shot grade toward a warm subject against a cool ambient, protecting colours that carry meaning.
- One picture that contradicted its narration (the "AI" colour filled most of the frame while the line said "under a third").
- An on-screen word that contradicted the narration ("DECLINED" under a line about paying more).
- Every cut being the same blur whip, with near-white frames.
- Labels about 5 px tall at phone size, and invented figures missing their "scenario" label on intermediate values of a rolling counter.
- A sound effect sitting on top of the words it illustrated.

Measure where you can: purple share per frame, label cap height at 360x640, event frame against the measured start of the sync word, voice against bed in the 2 to 5 kHz band.

## 5. Review

- Pull frames at every event and look at them. Check text at 360x640.
- A contact sheet with timestamps per version.
- The agent cannot judge motion feel or sound; say so and let the owner watch.
- Report the weakest things a viewer would notice first, in order.

## What it cost (first two shots, 13.5 s)

- About 181,000 builder tokens and 47 minutes for the first version, including writing the pipeline.
- A re-time to faster narration: about 5 minutes.
- Two key paintings and one voice take: 6 credits on the image service.

Full episode (13 shots, 63 seconds):

- Paintings: 13 keys and 12 second poses from a coding agent's built-in image tool, 2 to 3 minutes each, two at a time. No per-image credits.
- Narration: a local speech model, seconds per line.
- Build: five builders in parallel, roughly 180,000 to 360,000 tokens each per round, about 25 to 45 minutes per round.
- Rounds: prepare the pipeline, build, assemble a rough cut, critic, polish, re-render and assemble. About five hours of wall clock from "go" to the polished cut, most of it rendering and review.

## Lessons log

- **2026-11-06** The owner said "don't start yet" twice while the script was still moving. Six script revisions happened in chat at no build cost. Agree the script first.
- **2026-11-06** The first voice was chosen from measured pitch and steadiness and was rejected as robotic and slow. Offer samples.
- **2026-11-06** Speeding a take up 1.18x fixed the pace and not the cadence. Re-record at the right pace.
- **2026-11-06** A survey claim in the brief ("this generation wants them gone") had no source. The checked number was different, so the claim moved into the visuals and the checked number went on screen.
- **2026-11-06** A pasted-in notification card and clean digital type were the most "stuck on" elements. Give overlays the painting's grain, light and edge softness.
- **2026-11-06** The word-timing tool placed words up to 0.9 s early for a whispered voice. Check sync words against the audio's energy envelope before pinning events to them.
- **2026-11-06** An image tool can paint a convincing second pose from the key painting. That, not better warping, is what made characters act.
- **2026-11-06** A minimum label size enforced in shared code enlarged small text that belonged inside the scene (names in a video-call grid). Let scene text opt out.
- **2026-11-06** A foreground shell command is cut off after ten minutes. Long image batches need to be split or made resumable (skip files that exist).
- **2026-11-06** The owner wanted the rough full cut before any polish, and a faster build with more parallel builders over a simpler one. Offer speed through parallelism, never through lower quality.
- **2026-11-07** Two builders ran 11 and 13 hours on nothing because no one enforced their time boxes; a brief's time box is a hope until the director checks files on a schedule and kills silent builders. Full rule in `director-playbook.md`.
- **2026-11-07** A critic with a numbered rubric found a lore error on screen, whole-frame pose swaps that changed the background, music at speech level in every gap and 24 px source lines. Builders had passed all of them. Two critic passes per episode, ranked with frame numbers, is the minimum.
- **2026-11-07** Pose B paintings are composited only through the moving region's mask over the key plate; as whole frames they swap backgrounds.
- **2026-11-07** Removing a painted prop: code inpainting failed twice; a "prop removed" variant from the image model composited over the region worked first time.
- **2026-11-07** With time boxes enforced, an episode went from pre-production to a delivered final in about 2 h 15 min with five builders and two critic passes.
