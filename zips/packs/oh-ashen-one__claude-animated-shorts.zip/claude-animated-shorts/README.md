# Claude Animated Shorts

A Claude Code skill for making a short animated shot that matches a named show or studio's style, and for writing the brief that drives it.

## About

The skill is called `same-studio-shot`, after its one test: **someone watching should believe it came from the same studio.**

You give Claude a subject and a reference, such as "a mechanical moth waking up on a workbench, in the style of Arcane". Claude writes a structured shot brief, then works through four gates:

1. **Research** how the studio makes the look, and write every defining element down.
2. **Style guide and style frame**: a checklist plus one still, revised beside reference stills until it matches.
3. **Build**: model, texture, light, animate, add effects, composite.
4. **Review**: compare frames with references, list every difference, fix, repeat.

Sound design is part of the shot, not an extra.

The brief format comes from a single shot prompt written by someone else, shared with us without a name attached. If it is yours, open an issue and we will credit you.

## Install

```bash
git clone https://github.com/oh-ashen-one/claude-animated-shorts ~/.claude/skills/same-studio-shot
```

Then ask Claude Code for a shot:

```
Make a 15-second shot of a brass moth waking up on an inventor's workbench, in the style of Arcane.
```

The skill triggers on requests for an animated short, shot or clip "in the style of" a show, film or studio. It also works if you only want the brief written.

## What you need

- Claude Code
- Blender, or another 3D or animation tool Claude can drive
- `ffmpeg` for assembling frames and sound
- Time: the process is built to iterate, not to finish in one pass

## Contents

- `SKILL.md`: the process, the gates and the rules
- `templates/shot-brief.md`: the brief with placeholders
- `examples/spider-verse-courier-drone.md`: a filled-in brief
- `references/narrated-explainer-pipeline.md`: the recipe for narrated explainer shorts, with a lessons log
- `references/director-playbook.md`: running builder and critic agents on one of those shorts
- `references/open-source-stack.md`: open-source repos worth learning from, with licenses
- `templates/explainer-script.md`: the script table for those shorts

## Options

| Option | Choices |
| --- | --- |
| Asset policy | `from-scratch` (default): imitate technique, use nothing you did not create. `licensed`: finished licensed assets allowed, restyled to match |
| Context | `normal` (default) or `clean-room`: ignore memory and earlier chats |
| Tool | Blender by default, anything else if it does the job better |

## Use it fairly

This skill imitates technique. It does not use any studio's characters, logos, music, footage or extracted assets, and this repository contains none. Keep your reference stills private and label what you share as an unofficial style study. This project is not affiliated with Fortiche, Riot Games, Sony Pictures or any other studio named here.

## License

MIT

## What is in this repo

| Path | What |
| --- | --- |
| `SKILL.md` | the skill: brief, four gates, checklist headings, rules |
| `references/narrated-explainer-pipeline.md` | order of work for a narrated list-style short, with a dated lessons log |
| `references/director-playbook.md` | running builder and critic agents: briefs, time boxes, alarm loop, critic rubrics, delivery |
| `pipelines/painted-2p5d/` | CPU-only Python pipeline for the hand-painted 3D look (episodes 1 and 3) |
| `pipelines/claymation/` | CPU-only Python pipeline for the stop-motion look, with its 20-check `STYLE.md` (episode 2) |
| `tools/` | key painting and second-pose generation (coding agent image tool), Kokoro narration recorder |
| `examples/episodes/` | scripts, shot lists, style texts, prompts and episode 1's shot modules for the three finished episodes |
| `templates/` | shot brief and explainer script tables |

Rendered media (paintings, voice, renders) is not in the repo; the pipelines regenerate everything from the prompts and scripts. Episode 3 is unofficial fan content with original character designs.
