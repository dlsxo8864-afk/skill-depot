---
name: same-studio-shot
description: Make a short animated shot (about 5 to 30 seconds) that matches a named show, film or studio's visual and animation style closely enough to pass as that studio's work. Use when asked for an animated short, shot or clip "in the style of <show/film/studio>", to "make it look like <reference>", or to write the prompt or brief for one. Covers writing the shot brief, the research → style guide and style frame → build → review loop, a style checklist of observable pass/fail items, sound design, and reference and asset rules.
---

# Same-Studio Shot

A process for making one short animated shot in the style of a named reference, and for writing the brief that drives it.

## The bar

**Someone watching should believe it came from the same studio.**

Every decision is judged against that test. The test is run by putting your frames next to reference frames and listing what differs. Your own impression of a render is not evidence.

Take the time the shot needs. A finished shot that fails the test is not finished.

## Settings to fix before starting

| Setting | Default | Notes |
| --- | --- | --- |
| Reference | none, must be given | A show or film plus the studio that made it |
| Scene | loose | A subject, a setting and two or three beats. Free to change |
| Length | about 15 seconds | One shot, or two or three cuts at most |
| Format | widescreen, no dialogue | |
| Tool | Blender, or any other tool if superior | |
| Asset policy | `from-scratch` | `from-scratch`: study and imitate anything, use no asset you did not create. `licensed`: finished licensed assets are allowed, restyled to match, with source and license recorded |
| Context | `normal` | `clean-room`: ignore memory and earlier chats, so the look comes from this run's research |
| Sound | full sound design | |

If the user gave only a subject and a reference, pick the defaults, state them in one line and start. Do not interview the user.

## Step 1: write the brief

Fill in `templates/shot-brief.md` and save it as `BRIEF.md` in the project. `examples/` holds a filled-in brief. If the user asked only for the prompt, the brief is the deliverable.

Each part of the brief does one job:

1. **Opening line.** Length, medium, a short descriptor of the look, the reference and its studio in brackets.
2. **Tool line.** A default tool with an escape hatch ("or any other tool if superior"), then format constraints.
3. **Goal.** One top priority, the same-studio test, and explicit permission to spend time.
4. **Scene, marked loose.** A concrete subject, setting and beats, followed by permission to change or replace all of it if something else shows the style better. Pick a scene that exposes the style: a surface that takes paint, a light that switches on, an action with anticipation and a burst, at least one effect.
5. **Process.** The four gates below, in order.
6. **Style elements to match (at minimum).** Six to eight bullets. Each names a property a viewer can check on a frame or a clip and, where possible, what it must not look like ("nothing looks procedural or photographic"). Write these from research, not from memory of the show.
7. **Sound.** One or two sentences on mood and what must be heard.
8. **Closing.** Tool freedom, the asset policy, one consistent style across every layer, and the goal restated.

## Step 2: run the four gates

Do not skip a gate or merge two of them. Each has an exit condition.

### Gate 1: research

- Find how the studio makes the look: interviews, making-of material, artist breakdowns, talks, art books.
- Collect at least ten reference stills at full resolution: a close-up, a wide, an effects-heavy frame, a dark frame, a bright frame. Add short clips for timing.
- Write down every defining element under these headings: surfaces and textures, shading, line work, color, lighting, frame rate and timing, effects, camera, compositing, sound.
- Record the source for each element. Mark anything unconfirmed as a guess.
- Keep reference stills and clips local. Never commit or publish them.

Exit: `STYLE-NOTES.md` with every heading filled.

### Gate 2: style guide and style frame

- Turn the notes into `STYLE.md`, a checklist where each item is a yes/no check on a frame or a clip.
- Make one still: the hero subject in the final set, lit and composited at full resolution.
- Place it beside three or more reference stills at the same size. List every visible difference. Fix them. Repeat.
- Do not animate until the still holds up beside the references. Motion will not hide a look that is wrong in a still.

Exit: a side-by-side sheet whose remaining differences can only be judged in motion.

### Gate 3: build

- Model, texture, light, animate, add effects and composite, following `STYLE.md` item by item.
- Block the key poses first. Judge timing on a low-resolution playblast before any final render.
- Match the reference's frame stepping per layer. Many stylized shows hold characters and objects for two frames while the camera moves every frame.
- Build effects as their own pass, in the technique the studio uses (for example hand-drawn 2D layered over the 3D).
- Composite last and treat the result as one image: 3D, painted textures and effects share grain, color and edge treatment.
- Open the frames you render. Never report on a frame you have not looked at.

Exit: a full-length render with every checklist item attempted.

### Gate 4: review

- Pull frames at the first frame, each key pose, the peak of each effect and the last frame. Watch the clip at full speed for timing.
- Compare with the references side by side. Write the differences, ordered by how fast a viewer would notice each one.
- Fix from the top, re-render, compare again.
- If subagents are available, give a reviewer who has not seen the build a shuffled set of reference frames and output frames, and ask which are which and why. Their reasons are your next fix list.
- Stop when a fresh comparison finds no noticeable difference, or when the remaining differences are ones you have tried to close and could not. List those in the final report.

### Sound

- Build sound after the picture is locked.
- Every visible event gets a sound: contact and movement foley, a designed sound for each effect, room tone for the space, low-end weight on impacts, tails that fit the room.
- Land each sound on the frame where the pose changes.
- Synthesize or record the sounds yourself, or use licensed ones if the asset policy allows. Record the source of each.
- Leave headroom, check for clipping, and listen once on small speakers.

## Narrated explainer shorts

For a narrated, list-style short (a "what if" episode with ten or more shots), follow `references/narrated-explainer-pipeline.md` for the order of work (script, voice, key paintings, first shots, parallel build) and `references/director-playbook.md` for running builders and critics with enforced time boxes. Two finished CPU-only pipelines ship in this repo, each with a shared library, one module per shot, a timeline and an assemble step:

- `pipelines/painted-2p5d/`: hand-painted 3D look (Fortiche-style): depth planes, camera on 1s with parallax, acting on 2s with a painted second pose, 2D effects, code-drawn overlays, synthesized sound. Episodes 1 and 3.
- `pipelines/claymation/`: stop-motion look: everything on 2s including the camera, replacement animation, every piece of text a physical object (clay letters, cards, stamps, year signs), miniature depth of field, tactile sound. Episode 2. Its `STYLE.md` is the 20-check rubric the critic used.

`tools/` holds the key-painting and second-pose scripts (a coding agent's built-in image tool) and the narration recorder (local Kokoro). `examples/episodes/` holds the three scripts, shot lists, style texts and prompts, plus episode 1's shot modules. Start a new episode by copying a pipeline folder to `<episode>/src/`, renaming the entry script, and reading its `README.md` and `ADDING_A_SHOT.md`. `templates/explainer-script.md` is the script table.

## Style checklist headings

`STYLE.md` covers at least these. Word each item as an observable with a negative.

- **Surfaces and textures.** Example: brushstrokes are visible on every surface; nothing looks procedural or photographic.
- **Shading.** Example: light and shadow fall in designed shapes, not realistic falloff.
- **Line work.** Where lines appear, their weight, and where they are absent.
- **Color.** Palette, shadow hue, how saturated the accents are.
- **Lighting.** Key, rim, practical sources, bloom.
- **Timing.** Frame stepping per layer, pose strength, anticipation, smears instead of motion blur if the reference does that.
- **Effects.** Technique, shape language, frame stepping.
- **Camera.** Lens, depth of field, movement, weight on impacts.
- **Compositing.** Filtering, grain, texture over the image.

## Deliverables

- `BRIEF.md`, `STYLE-NOTES.md`, `STYLE.md`
- The style frame and its side-by-side sheets
- The final video with sound
- A differences log: what was found each round, what was fixed, what remains

## Rules

- Keep the whole shot in one style, so the 3D, the textures and the effects read as a single hand-made image.
- Imitate technique. Do not use the studio's characters, logos, music, footage or extracted assets.
- Label shared results as an unofficial style study, not affiliated with the reference's owners.
- Report what still differs. Do not describe a shot as matching when the comparison says otherwise.
- Do not lower the bar to finish sooner.
