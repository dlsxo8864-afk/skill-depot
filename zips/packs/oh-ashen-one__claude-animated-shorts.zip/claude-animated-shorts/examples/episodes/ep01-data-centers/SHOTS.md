# Episode 1 shot list: "What if all data centers disappeared over the next ten years?"

Vertical 1080x1920, 24 fps. Narration: Kokoro `af_nicole` at speed 1.5, one wav per line in `assets/voice/nicole/` with `lines.json`. Gaps between lines: about 0.40 s (0.45 s after the hook). Total must be at least 61 s; expected about 67 s.

Every shot: one key painting in `assets/key/`, camera on 1s with depth parallax, life on 2s, hand-drawn-style 2D effects on 2s, code-drawn overlays for all text and interface, the shared final style pass, synthesized sound placed on the picture's event frames.

Overlay rules:
- Year tag top-left ("YEAR 1" to "YEAR 10"), same design as shot 2.
- One small data tag per shot with the real number, shown while the number is spoken.
- Invented figures carry a small "scenario" label next to them.
- No real brand logos or trademarked interfaces. Brand names appear only as plain text in data tags.
- Text stays out of the bottom 22% and right 14% of the frame, and 6% from the top and left.

| # | File stem | Key image | Narration | Event (sync word) | Overlays |
|---|---|---|---|---|---|
| 0 | s01_hook | hook_protest_key.png | What if all data centers disappeared over the next ten years? | Building lights die ("disappeared") | Title; "This week, 40 of 41 local votes went against data centers" + "CNBC, Nov 4, 2026" |
| 1 | s02_year1 | y01_tiktok_key.png | The first thing you'd notice is your doomscrolling. TikTok's nearly two billion users would get a daily limit. | Notification ("daily"), screen off, windows out | YEAR 1; "TikTok: about 2 billion users (est.)"; notification "You've used your allotted data center time for the day." |
| 2 | s03_year2 | y02_netflix_key.png | Then your Netflix bill. Nineteen ninety-nine today could become forty-nine ninety-nine. | Price ticks up ("forty-nine"); cash shovelled on 2s; fire flares | YEAR 2; big price counter "$19.99" rolling to "$49.99" + "scenario"; bank balance on the phone spinning down to $0.00 |
| 3 | s04_year3 | y03_remote_key.png | If you work from home, like thirty-five million Americans, it's back to the office. | Video-call grid freezes then shatters into the highway ("back") | YEAR 3; opening overlay of a generic video-call grid whose tiles freeze one by one; "35 million Americans work remotely (BLS, 2026)" |
| 4 | s05_year4 | y04_twitch_key.png | If you stream on Twitch, you'd pay to go live. | Paywall appears on the monitor ("pay"); cash sucked into webcam; ring light dies | YEAR 4; on the monitor: "48,211 streamers ahead of you" and a button "Pay $20 to stream now?" + "scenario"; "Twitch: about 6 million streamers a month" |
| 5 | s06_year5 | y05_gaming_key.png | When you log on to play, the servers would be full. | "SERVERS FULL" slams onto every monitor ("full"); controller crumbles | YEAR 5; "SERVERS FULL" on each screen; "Steam record: 43.5 million players at once" |
| 6 | s07_year6 | y06_spotify_key.png | Your Spotify, twelve ninety-nine today, would cost more. | Coin drops into the earbud slot on each beat; price ticks up ("more") | YEAR 6; "$12.99" rolling upward to "$?" + "scenario" |
| 7 | s08_year7 | y07_photos_key.png | So would storing your photos, ninety-nine cents a month today. | Price tags fill in; photos dissolve one by one ("photos") | YEAR 7; tags on the frames show rising prices + "scenario"; "iCloud 50 GB: $0.99 a month today" |
| 8 | s09_year8 | y08_card_key.png | Stores pay about two percent each time you swipe. You'd cover the increase. | Card melts; reader flashes; receipt line grows ("increase") | YEAR 8; receipt lines printed in code with "SWIPE FEE" growing longer than the groceries; "US swipe fees: $198 billion in 2025" |
| 9 | s10_year9 | y09_market_key.png | Your retirement would drop. Seven AI-heavy companies are a third of the S&P 500. | Pillars crack ("seven"); the chart line breaks and falls ("third") | YEAR 9; "7 companies = about a third of the S&P 500"; a jar balance counter dropping |
| 10 | s11_year10 | y10_chatgpt_key.png | And yes, ChatGPT's nine hundred million users would lose it too. | Giant cursor blinks, then breaks into embers ("lose") | YEAR 10; "ChatGPT: 900 million weekly users" |
| 11 | s12_catch | y11_catch_key.png | But data centers were here long before AI, which uses under a third of their power. | Magenta third pulses, then gold two-thirds brighten ("third") | Labels "AI: under a third" on the magenta side and "Everything else" on the gold side; source "IEA, 2026" |
| 12 | s13_cta | y12_cta_key.png | So if you had to give up one thing that isn't AI, what would it be? | Grid of the ten items pops in on 2s; question holds | The question as large text; a 5x2 grid of ten small icons with one-word labels: TikTok, Netflix, Remote work, Twitch, Gaming, Spotify, Photos, Cards, Retirement, ChatGPT |

Transitions: hard cuts on the beat with a whoosh or hit leading in, plus a 2-frame smear or flash frame in the outgoing shot's key colour. End: hold the CTA for at least 1.5 s after the last word.

Sources for the numbers are in the script notes (CNBC, BLS, Streams Charts, SteamDB, MacRumors, Apple, Nilson via Merchants Payments Coalition, S&P weights, OpenAI, IEA).
