# What If shorts: look checklist

Answer each item yes or no on a single frame (F) or on the moving clip (C). Any "no" is a fix before the shot ships.
Written from the two ep01 key paintings and the Arcane reference notes (`~/arcane-reference/NOTES.md`, private, never copied).

## Surfaces and paint
1. **(F) Visible brushwork everywhere.** Every surface, including added slogans, screen content and FX, shows stroke texture at full size; nothing reads as a flat vector fill or smooth airbrush.
2. **(F) No plastic.** The paintings are not sharpened, denoised or smeared; brush strokes keep their original edges after the camera warp (compare a 1:1 crop with the key).
3. **(F) Faceted shading.** Characters keep the key's few hard shadow planes on faces and cloth; no added soft gradients flatten them.
4. **(F) Thin, broken line work.** Edges are soft-painted with only thin, broken dark accents (hair strands, placard edges); no added element has a clean vector outline thicker than the painting's own.

## Colour and light
5. **(F) Coloured shadows.** The darkest areas are deep violet, plum or navy (no pixel group reads neutral grey or pure black, even after a light dies).
6. **(F) One clear key light.** Each shot has one motivated key (hook: teal facade, then orange dusk sky; Year 1: the phone screen) and the subject's lit side follows it.
7. **(F) Warm against cool.** A warm accent (orange sky, embers, lit windows, title colour) sits against a teal or violet ambient, as in the reference's warm-versus-teal split.
8. **(F) Rim light survives.** Magenta or orange rims on hair and shoulders stay visible after every lighting change.
9. **(C) Light changes are motivated.** Every change in light on a surface comes from a visible source changing (strips dying, screen content changing, screen off, windows out) and lands on the same frame.

## Depth and atmosphere
10. **(F) Haze softens distance.** Far planes are lower contrast and tinted by the haze/air colour; close-up backgrounds dissolve into soft bokeh.
11. **(C) Real parallax, no tearing.** Foreground, midground and background slide at different rates; no stretched pixels, holes, doubled edges or halos appear at layer borders during the move.

## Timing and motion
12. **(C) Characters and FX on 2s.** Signs, fists, heads, thumb, sparks, embers and UI pops hold each drawing for 2 frames, with anticipation before big moves and a settle after.
13. **(C) Camera on 1s.** Push-ins and rises are smooth every frame, ease in and out, and never pop.
14. **(C) No motion blur.** Fast moves use a drawn smear frame, not blur trails.

## Effects
15. **(F) Graphic FX shapes.** Sparks, embers and flashes are drawn shapes (tapered streaks, 4-point stars, zig-zag bolts) with a hard bright core and a coloured glow, never round particle dots.

## Type and compositing
16. **(F) One image.** Titles, tags, cards and screen UI carry the same grain, canvas tooth, colour grade and edge softness as the paintings; nothing looks pasted on top.
17. **(F) Safe and legible.** All on-screen text sits inside the safe area (at least 6 % from top and left, out of the bottom 22 % and right 14 %) and reads at 360x640.
18. **(F) Painted-on lettering.** Slogans on signs follow the board's perspective, take the board's light, and look brushed (slightly uneven), not typed.
