"""Shot 5, Year 4 (Twitch): a streamer at a violet monitor. An invented go-live dashboard ticks a queue
("48,211 streamers ahead of you"); on "pay" a paywall button slams onto the screen and the webcam starts
sucking banknotes and coins out of the wallet along the painted arc; the wallet hand jerks with every
pull, the hair is tugged toward the lens, the screen light pumps on the streamer, and the ring light
flickers and dies.

Everything here is local to this shot. Key coordinates are pixels of work/keys/y04_twitch_key.png
(1520x2701). Helpers written locally (candidates for hoisting): clean_key (paint out the painted money
stream and patch the depth), extract_cutouts (pull painted props off a flat colour), CatmullPath,
affine_rgba (anisotropic scale/rotate of an RGBA patch), deform_blend (rigid pose with a lagged
follow-through pose blended by a weight map, plus a drift field), magenta_weight.
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into
from whatif.config import FPS, LAYER_CACHE
from whatif.fx2d import ShapeCanvas, screen_emissive, spark_burst, star4_poly, tapered_streak_poly
from whatif.keyprep import load_rgb
from whatif.screens import ScreenQuad, screen_light
from whatif.shotkit import BaseShot
from whatif.timing import Track, smoothstep

from pathlib import Path

from .s05_year4_pose import (aligned_pose, color_match, diff_mask, half_warp, multi_pose, poly_soft, radial,
                             smooth_field)

STEM = __name__.split(".")[-1]
SC = L.WORK_SCALE
CACHE = LAYER_CACHE / STEM

# ------------------------------------------------------------------ spec (key px)
SCREEN_QUAD = [(209, 769), (1407, 741), (1388, 1395), (204, 1398)]     # TL TR BR BL, BL hidden by the hair
LENS = (772, 709)
WEBCAM_BOX = (676, 650, 852, 752)
RING_BOX = (1290, 880, 1520, 1395)
RING_C = (1405, 1150)
MONEY_BOX = (785, 690, 1238, 1470)                                    # where the painted stream is painted out
TRAIL = [(784, 696), (805, 690), (965, 752), (968, 780), (784, 726)]   # lens trail over the bezel
WALLET_KEEP = [(905, 1630), (930, 1598), (990, 1580), (1060, 1552), (1110, 1520), (1250, 1520), (1270, 1720),
               (1240, 1830), (900, 1830)]
CUTOUTS = {  # painted props on the flat violet screen, re-used as the flying money
    "n_flat": (946, 1023, 1048, 1142), "n_top": (1080, 826, 1167, 886), "n_big": (1062, 1150, 1196, 1275),
    "n_curl": (813, 1268, 945, 1398),
    "c_big": (909, 1174, 970, 1237), "c_a": (1029, 945, 1065, 982), "c_b": (1102, 1043, 1139, 1081),
    "c_side": (1207, 1081, 1238, 1130), "c_c": (1186, 894, 1230, 931), "c_d": (1186, 1230, 1225, 1278),
}
ARC = [(1055, 1610), (1010, 1480), (995, 1340), (1035, 1210), (1110, 1100), (1160, 990), (1130, 880),
       (1025, 800), (905, 748), (805, 714), (LENS[0], LENS[1])]

# pose B (assets/key/y04_twitch_poseB.png): the streamer lunges up at the webcam, one hand grabbing at the cash
POSE_B = Path(__file__).resolve().parents[2] / "assets" / "key" / "y04_twitch_poseB.png"
HERO_B = [  # key px: where either pose of the streamer can be (B's raised arm and wallet, A's head and arm);
            # only pixels that really differ inside it are swapped, the chair and the mic are put back on top
    [(0, 1000), (150, 985), (330, 975), (520, 1005), (640, 1055), (700, 1095), (770, 1060), (795, 1000), (805, 940),
     (830, 898), (852, 858), (880, 842), (906, 832), (928, 838), (1002, 878), (1012, 902), (988, 936), (952, 976),
     (948, 998), (1002, 1028), (1012, 1060), (976, 1082), (900, 1078), (852, 1102), (832, 1160), (812, 1250),
     (830, 1400), (985, 1450), (985, 1240), (1100, 1212), (1292, 1168), (1314, 1250), (1306, 1430), (1292, 1600),
     (1290, 1960), (1250, 2000), (1240, 2440), (600, 2460), (560, 2701), (0, 2701)],
]
CHAIR_A = [(0, 1700), (120, 1712), (220, 1735), (300, 1770), (330, 1810), (355, 1890), (385, 1990), (410, 2070),
           (450, 2140), (500, 2250), (530, 2400), (560, 2460), (650, 2460), (800, 2440), (1000, 2430), (1200, 2440),
           (1320, 2490), (1350, 2701), (0, 2701)]           # pose A's chair back and armrest: stays in front
MIC_A = [(655, 1330), (700, 1318), (738, 1335), (745, 1380), (722, 1410), (712, 1468), (760, 1466), (805, 1488),
         (815, 1560), (800, 1690), (778, 1720), (762, 1760), (700, 1762), (640, 1748), (612, 1700), (622, 1600),
         (648, 1560), (680, 1480), (690, 1410), (655, 1395)]   # pose A's microphone: never moves
# the in-between: points of pose B and how far back toward pose A they were (key px)
AB_PTS = [(400, 1250), (590, 1380), (905, 955), (1150, 1340), (680, 1580), (450, 1900), (1000, 1200),
          (75, 1110), (230, 1760), (720, 2300), (1350, 1900)]
AB_DISP = [(-90, 260), (-200, 270), (-150, 560), (-60, 360), (-180, 260), (-60, 120), (-80, 420),
           (0, 0), (0, 0), (0, 0), (0, 0)]                  # the lamp, chair and desk do not move
B_WALLET = (1150, 1340)          # wallet mouth in pose B
B_WRIST = (792, 1118)
B_FINGERS = (905, 955)
B_HEAD = (390, 1190)
LUNGE_V = (-50.0, 300.0)         # key px from pose B back to where pose A was (smear direction)
ARC_B = [(1148, 1290), (1132, 1180)]                                     # + ARC from (1160, 990) on

PLANES = [
    L.PlaneSpec("room", 0.00, 0.115, fill="full"),
    L.PlaneSpec("monitor", 0.115, 0.20, radius=60),
    L.PlaneSpec("desk", 0.20, 0.36, radius=60),
    L.PlaneSpec("streamer", 0.36, 0.72, radius=70),
    L.PlaneSpec("chair", 0.72, 1.01, radius=80),
]
SPRITES = [
    L.SpriteSpec("arm", 3, [(905, 1630), (930, 1598), (990, 1580), (1060, 1552), (1110, 1525), (1240, 1525),
                            (1266, 1560), (1268, 1725), (1240, 1805), (1172, 1835), (1150, 1905), (1128, 1965),
                            (1112, 2012), (985, 2012), (986, 1950), (1000, 1880), (990, 1835), (918, 1805),
                            (902, 1720)],
                 dmin=0.30, pivot=(1050, 1995), anchor=(1080, 1760, 1050, 2010)),
    L.SpriteSpec("head", 3, [(0, 1212), (60, 1200), (200, 1210), (300, 1222), (365, 1245), (405, 1300),
                             (440, 1338), (520, 1338), (575, 1365), (605, 1440), (602, 1560), (575, 1690),
                             (562, 1782), (535, 1815), (420, 1808), (300, 1790), (150, 1780), (0, 1780)],
                 dmin=0.45, pivot=(445, 1800), anchor=(300, 1300, 430, 1800)),
]


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def magenta_weight(rgb, blur=3):
    """How much of a pixel is lit by the violet screen / pink ring (min(r, b) above g), gated by value."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    w = np.clip((np.minimum(r, b) - g - 0.02) / 0.26, 0, 1) * np.clip((rgb.max(-1) - 0.10) / 0.3, 0, 1)
    return cv2.GaussianBlur(w.astype(np.float32), (0, 0), blur) if blur else w.astype(np.float32)


def unlit_violet(rgb):
    lum = rgb @ np.float32([0.30, 0.50, 0.20])
    return lum[..., None] * np.float32([0.42, 0.30, 0.70]) * 0.70


# ------------------------------------------------------------------ local helpers
def _violet(c):
    r, g, b = c[..., 0], c[..., 1], c[..., 2]
    return (r > 0.5) & (b > 0.78) & (g < 0.40)


def extract_cutouts(key, boxes):
    """Pull painted props off the flat violet screen: alpha from the colour distance to the local screen
    colour, largest blob only, colour un-mixed from the screen. Returns {name: rgba float32 (key px)}."""
    out = {}
    for n, (x0, y0, x1, y1) in boxes.items():
        c = key[y0:y1, x0:x1]
        vi = _violet(c)
        bg = np.median(c[vi], 0) if vi.sum() > 20 else np.float32([0.72, 0.24, 0.96])
        d = np.linalg.norm(c - bg, axis=2)
        a = np.clip((d - 0.07) / 0.16, 0, 1)
        nn, lab, st, _ = cv2.connectedComponentsWithStats((a > 0.5).astype(np.uint8))
        i = 1 + int(np.argmax(st[1:, 4]))
        keep = cv2.dilate((lab == i).astype(np.uint8), np.ones((5, 5), np.uint8))
        keep = cv2.morphologyEx(keep, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8)).astype(np.float32)
        a = a * cv2.GaussianBlur(keep, (0, 0), 1.0)
        rgb = np.clip((c - (1 - a[..., None]) * bg) / np.maximum(a[..., None], 0.3), 0, 1)
        pad = 6
        rgba = np.zeros((y1 - y0 + 2 * pad, x1 - x0 + 2 * pad, 4), np.float32)
        rgba[pad:-pad, pad:-pad] = np.dstack([rgb, a])
        out[n] = rgba
    return out


def _row_fill(img, hole, y0, y1, x0, x1):
    """Fill hole pixels row by row by interpolating between the nearest valid pixels on the same row,
    so horizontal structures (bezels, panel edges) carry straight through."""
    for y in range(y0, y1):
        h = hole[y, x0:x1]
        if not h.any():
            continue
        v = np.where(~h)[0]
        if len(v) < 2:
            continue
        xs = np.arange(x1 - x0)
        for ch in range(3):
            img[y, x0:x1, ch] = np.where(h, np.interp(xs, v, img[y, x0 + v, ch]), img[y, x0:x1, ch])


def clean_key(key_path, depth_path):
    """Paint the static money stream out of the key (it is re-animated as cut-outs) and patch the depth so
    the stream does not become a layer. Cached in work/layers/<stem>/."""
    CACHE.mkdir(parents=True, exist_ok=True)
    kp, dp = CACHE / "clean_key.png", CACHE / "clean_depth.png"
    if kp.exists() and dp.exists() and kp.stat().st_mtime > key_path.stat().st_mtime:
        return kp, dp
    key = load_rgb(key_path)
    H, W = key.shape[:2]
    x0, y0, x1, y1 = MONEY_BOX
    r, g, b = key[..., 0], key[..., 1], key[..., 2]
    lum = key @ np.float32([0.3, 0.5, 0.2])
    money = ~_violet(key) & ~((lum < 0.30) & (b < 0.56))
    zone = np.zeros((H, W), bool)
    zone[y0:y1, x0:x1] = True
    zone[:772] = False                                             # the bezel top: only the lens trail
    zone |= L.poly_mask((H, W), TRAIL) > 0.5
    zone &= ~(L.poly_mask((H, W), WALLET_KEEP) > 0.5)
    money &= zone
    money = cv2.morphologyEx(money.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    money = cv2.dilate(money, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))) > 0
    money &= zone | (L.poly_mask((H, W), TRAIL) > 0.5)
    quad = np.float32(SCREEN_QUAD)
    inside = np.zeros((H, W), np.uint8)
    cv2.fillConvexPoly(inside, np.round(quad).astype(np.int32), 1)
    inside = cv2.erode(inside, np.ones((17, 17), np.uint8)) > 0
    out = key.copy()
    # screen interior: flat painted violet (push-pull from the screen around it)
    scr_valid = ~money & _violet(key)
    filled = L.push_pull_fill(key, scr_valid.astype(np.float32))
    m_in = money & inside
    out[m_in] = filled[m_in]
    # bezel, panel and wall: row fill keeps the horizontal lines; a little push-pull smooths verticals
    m_out = money & ~inside
    tmp = key.copy()
    _row_fill(tmp, m_out, 680, 1480, 640, 1300)
    pp = L.push_pull_fill(key, (~m_out).astype(np.float32))
    out[m_out] = (tmp * 0.8 + pp * 0.2)[m_out]
    # brush texture in the repaint, matched to the plate's stroke energy
    soft = cv2.GaussianBlur(money.astype(np.float32), (0, 0), 1.5)[..., None]
    n = (L.brush_noise((H, W), 41, scale=4.0, angle=-0.3, stretch=5) * 0.7 +
         L.brush_noise((H, W), 42, scale=8.0, angle=1.2, stretch=3) * 0.5)[..., None]
    out = key * (1 - soft) + np.clip(out * (1 + 0.035 * n), 0, 1) * soft
    cv2.imwrite(str(kp), cv2.cvtColor((np.clip(out, 0, 1) * 255 + 0.5).astype(np.uint8), cv2.COLOR_RGB2BGR))
    dep = cv2.imread(str(depth_path), -1).astype(np.float32) / 65535
    md = cv2.dilate(money.astype(np.uint8), np.ones((15, 15), np.uint8))
    dep2 = L.push_pull_fill(dep, (md == 0).astype(np.float32))
    dep = np.where(md > 0, dep2, dep)
    cv2.imwrite(str(dp), (np.clip(dep, 0, 1) * 65535).astype(np.uint16))
    return kp, dp


class CatmullPath:
    """Centripetal-ish Catmull-Rom through points, re-sampled by arc length: p(s), tangent(s), s in 0..1."""

    def __init__(self, pts, n=600):
        P = np.float32(pts)
        P = np.vstack([P[0] * 2 - P[1], P, P[-1] * 2 - P[-2]])
        seg = []
        for i in range(1, len(P) - 2):
            p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
            for t in np.linspace(0, 1, 40, endpoint=False):
                t2, t3 = t * t, t * t * t
                seg.append(0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
                                  (-p0 + 3 * p1 - 3 * p2 + p3) * t3))
        seg.append(P[-2])
        seg = np.float32(seg)
        d = np.r_[0, np.cumsum(np.linalg.norm(np.diff(seg, axis=0), axis=1))]
        u = np.linspace(0, d[-1], n)
        self.p = np.stack([np.interp(u, d, seg[:, 0]), np.interp(u, d, seg[:, 1])], 1)
        self.n = n

    def __call__(self, s):
        i = float(np.clip(s, 0, 1)) * (self.n - 1)
        a = int(i)
        b = min(a + 1, self.n - 1)
        return self.p[a] + (self.p[b] - self.p[a]) * (i - a)

    def tangent(self, s):
        a, b = self(max(0, s - 0.01)), self(min(1, s + 0.01))
        d = b - a
        return d / (np.linalg.norm(d) + 1e-6)


def affine_rgba(rgba, sx, sy, angle_deg):
    """Scale an RGBA patch anisotropically (sx across, sy along) then rotate; returns (patch, cx, cy) with
    (cx, cy) the patch position of the source centre."""
    h, w = rgba.shape[:2]
    a = math.radians(angle_deg)
    R = np.float32([[math.cos(a), -math.sin(a)], [math.sin(a), math.cos(a)]])
    M2 = R @ np.float32([[sx, 0], [0, sy]])
    c = np.float32([w / 2, h / 2])
    corners = (np.float32([[0, 0], [w, 0], [w, h], [0, h]]) - c) @ M2.T
    lo, hi = np.floor(corners.min(0)) - 2, np.ceil(corners.max(0)) + 2
    size = (int(hi[0] - lo[0]), int(hi[1] - lo[1]))
    if size[0] < 2 or size[1] < 2:
        return None, 0, 0
    t = -M2 @ c - lo
    M = np.hstack([M2, t[:, None]]).astype(np.float32)
    out = cv2.warpAffine(rgba, M, size, flags=cv2.INTER_AREA if max(sx, sy) < 1 else cv2.INTER_LINEAR,
                         borderValue=0)
    return out, -lo[0], -lo[1]


def _inverse_pose(gx, gy, pivot, angle_deg, dx, dy, scale=1.0):
    a = math.radians(angle_deg)
    ca, sa = math.cos(-a), math.sin(-a)
    ux, uy = (gx - pivot[0] - dx) / scale, (gy - pivot[1] - dy) / scale
    return ux * ca - uy * sa + pivot[0], ux * sa + uy * ca + pivot[1]


def deform_blend(sprite, pose, lag_pose=None, lag_w=None, drift=None):
    """Like camera.deform_sprite, but parts marked by lag_w (0..1 map, sprite crop size) follow lag_pose
    (an earlier pose: follow-through), and drift=(dx_map, dy_map) adds a smooth extra displacement (hair
    tugged by the suction). Stays continuous, so nothing tears. Returns (rgba, x0, y0)."""
    rgba = sprite["rgba_f"]
    wgt = sprite["w_f"]
    x0, y0, x1, y1 = sprite["bbox"]
    h, w = rgba.shape[:2]
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    gx += x0
    gy += y0
    sx, sy = _inverse_pose(gx, gy, sprite["pivot"], **pose)
    if lag_pose is not None and lag_w is not None:
        lx, ly = _inverse_pose(gx, gy, sprite["pivot"], **lag_pose)
        sx = sx + (lx - sx) * lag_w
        sy = sy + (ly - sy) * lag_w
    if drift is not None:
        sx = sx - drift[0]
        sy = sy - drift[1]
    sx = gx + wgt * (sx - gx) - x0
    sy = gy + wgt * (sy - gy) - y0
    return cv2.remap(rgba, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0), x0, y0


LIGHT = np.float32([-0.35, -0.55, -0.76]) / np.linalg.norm([-0.35, -0.55, -0.76])     # from the monitor, up-left


def _rot(yaw, pitch, roll_deg):
    cy, sy = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)
    r = math.radians(roll_deg)
    cr, sr = math.cos(r), math.sin(r)
    Ry = np.float32([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rx = np.float32([[1, 0, 0], [0, cp, -sp], [0, sp, cp]])
    Rz = np.float32([[cr, -sr, 0], [sr, cr, 0], [0, 0, 1]])
    return Rz @ Rx @ Ry


def card3d(spr, yaw, pitch, roll_deg, k, fold=0.0, thick=0.0):
    """A painted cut-out as a thin card in 3D: tumbling (yaw/pitch/roll), foreshortened in perspective,
    folded along its middle (two halves, each lit by the monitor), back faces darker and cooler, coins with
    a dark edge band when tilted. Returns (rgba, cx, cy): the patch and the patch position of the centre."""
    h, w = spr.shape[:2]
    R = _rot(yaw, pitch, roll_deg)
    F = 3.2 * max(w, h)
    halves = [(0, w // 2), (w // 2, w)] if fold else [(0, w)]
    a = fold / 2
    faces = []
    for x0, x1 in halves:
        src = np.float32([[x0, 0], [x1, 0], [x1, h], [x0, h]])
        loc = []
        for x, y in src:
            lx, ly = x - w / 2, y - h / 2
            lz = abs(lx) * math.sin(a) if fold else 0.0
            lx = lx * math.cos(a) if fold else lx
            loc.append([lx, ly, lz])
        P = np.float32(loc) @ R.T
        dst = P[:, :2] * (F / (F + P[:, 2:3])) * k
        nrm = np.cross(P[1] - P[0], P[3] - P[0])
        nrm = nrm / (np.linalg.norm(nrm) + 1e-6)
        faces.append((float(P[:, 2].mean()), src, dst, nrm))
    allp = np.concatenate([f[2] for f in faces])
    if thick:
        off = (R @ np.float32([0, 0, thick * max(w, h)]))[:2] * k
        allp = np.concatenate([allp, allp + off])
    lo, hi = np.floor(allp.min(0)) - 3, np.ceil(allp.max(0)) + 3
    size = (int(hi[0] - lo[0]), int(hi[1] - lo[1]))
    if size[0] < 3 or size[1] < 3 or k * max(w, h) < 2:
        return None, 0, 0
    out = np.zeros((size[1], size[0], 4), np.float32)
    for z, src, dst, nrm in sorted(faces, key=lambda f: -f[0]):
        front = nrm[2] < 0                                  # facing the camera
        nf = nrm if front else -nrm
        lit = float(max(0.0, nf @ LIGHT))
        Hm = cv2.getPerspectiveTransform(src, (dst - lo).astype(np.float32))
        layers = []
        if thick:                                           # the coin's edge: the same disc pushed back, dark
            Ho = cv2.getPerspectiveTransform(src, (dst + off - lo).astype(np.float32))
            e = cv2.warpPerspective(spr, Ho, size, flags=cv2.INTER_LINEAR, borderValue=0)
            e[..., :3] *= np.float32([0.42, 0.30, 0.40])
            layers.append(e)
        p = cv2.warpPerspective(spr, Hm, size, flags=cv2.INTER_LINEAR, borderValue=0)
        shade = 0.62 + 0.62 * lit
        if front:
            p[..., :3] *= shade
        else:
            p[..., :3] = p[..., :3] * shade * 0.78 * np.float32([0.92, 0.88, 1.08])
        if fold:                                            # paper bends: darker toward the fold crease
            xs = np.linspace(0, 1, size[0], dtype=np.float32)[None, :, None]
            p[..., :3] *= 0.9 + 0.1 * np.abs(xs - 0.5) * 2
        layers.append(p)
        for L_ in layers:
            T.over_rgba(out, L_, 0, 0)
    return out, -lo[0], -lo[1]


def _sum_keys(keys, d):
    """Piecewise-linear value of keys [(frame, value)] at d (0 outside)."""
    if d < keys[0][0] or d > keys[-1][0]:
        return 0.0
    for (a, va), (b, vb) in zip(keys, keys[1:]):
        if a <= d <= b:
            return va + (vb - va) * (d - a) / max(b - a, 1e-6)
    return 0.0


# ------------------------------------------------------------------ the dashboard on the monitor
CW, CH = 1440, 780
PLUM = np.float32([0.15, 0.05, 0.22])
EMBER = np.float32([1.0, 0.58, 0.27])


def _txt(s, fnt, color, seed, shadow=True):
    a = O._text_alpha(s, fnt)
    rgba, pad = T.styled_text_rgba(a, color, seed=seed, shadow_off=(2, 3) if shadow else (0, 0),
                                   soft_shadow=5 if shadow else 1, shadow_strength=0.5 if shadow else 0.0, grad=0.06)
    return rgba, pad


class Dashboard:
    """Invented go-live studio page, painted (brush-streaked fills, toothy type), drawn at CW x CH."""

    def __init__(self, c0):
        self.c0 = np.float32(c0)

    @cached_property
    def base(self):
        yy = np.linspace(0, 1, CH, dtype=np.float32)[:, None, None]
        xx = np.linspace(0, 1, CW, dtype=np.float32)[None, :, None]
        n = L.brush_noise((CH, CW), 301, scale=5, angle=-0.25, stretch=8)[..., None]
        n2 = L.brush_noise((CH, CW), 302, scale=14, angle=0.9, stretch=3)[..., None]
        bg = self.c0 * (1.02 - 0.10 * yy - 0.05 * xx) * (1 + 0.045 * n + 0.03 * n2)
        bg = np.clip(bg, 0, 1).astype(np.float32)
        # top bar: a darker painted band with an OFFLINE chip and a dim GO LIVE button
        bar = O.painted_swatch(CW + 40, 96, seed=311, color=(0.36, 0.10, 0.52), opacity=0.80, rough=0.12, radius=2)
        bg = np.dstack([bg, np.ones((CH, CW), np.float32)])
        T.over_rgba(bg, bar, -20, -12)
        dot = O.painted_swatch(26, 26, seed=312, color=(0.95, 0.28, 0.38), opacity=1.0, rough=0.1, radius=8)
        T.over_rgba(bg, dot, 46, 24)
        t, p = _txt("OFFLINE", T.sans(40, 760), (246, 226, 240), 313)
        T.over_rgba(bg, t, 86 - p, 18 - p)
        btn = O.painted_swatch(250, 64, seed=314, color=(0.30, 0.12, 0.40), opacity=0.9, rough=0.12, radius=10)
        T.over_rgba(bg, btn, 330, 12)
        t, p = _txt("GO LIVE", T.sans(36, 760), (176, 140, 196), 315, shadow=False)
        T.over_rgba(bg, t, 330 + 125 - t.shape[1] // 2 + p - p, 12 + 32 - t.shape[0] // 2)
        # queue card: tucked under the paywall bar, above where the streamer's head reaches in either pose
        card = O.painted_swatch(690, 154, seed=316, color=tuple(PLUM), opacity=0.88, rough=0.16, radius=14)
        T.over_rgba(bg, card, 10, 124)
        t, p = _txt("streamers ahead of you", T.sans(44, 720), (246, 236, 216), 317)
        T.over_rgba(bg, t, 12, 212)
        return bg[..., :3].copy()

    @cached_property
    def button(self):
        fnt = T.sans(62, 800)
        a = O._text_alpha("Pay $20 to stream now?", fnt)
        t, p = T.styled_text_rgba(a, (40, 12, 46), seed=321, shadow_off=(1, 2), soft_shadow=2, shadow_strength=0.25,
                                  grad=0.05)
        w, h = a.shape[1] + 72, a.shape[0] + 44
        sw = O.painted_swatch(w, h, seed=322, color=tuple(EMBER), opacity=1.0, rough=0.12, radius=16)
        hl = O.painted_swatch(w - 40, 14, seed=323, color=(1.0, 0.84, 0.62), opacity=0.7, rough=0.3, radius=3)
        canvas = np.zeros((h + 40, w + 40, 4), np.float32)
        sh = O.painted_swatch(w, h, seed=324, color=(0.10, 0.02, 0.10), opacity=0.55, rough=0.1, radius=16)
        T.over_rgba(canvas, cv2.GaussianBlur(sh, (0, 0), 6), 26, 32)
        T.over_rgba(canvas, sw, 20, 20)
        T.over_rgba(canvas, hl, 40, 28)
        T.over_rgba(canvas, t, 20 + 36 - p, 20 + 22 - p)
        return canvas

    @cached_property
    def scenario(self):
        return O.scenario_label(size=40)

    def draw(self, f, value, pay_d, flash, chip_d=99, chime_d=None):
        """value: queue number; pay_d: frames since the paywall slam (None before); flash 0..1 screen flash."""
        cv = self.base.copy()
        num = O.counter_rgba(value, fmt="{:,.0f}", size=88, decimals=0, roll=False, seed=7)
        rgba = np.zeros((CH, CW, 4), np.float32)
        T.over_rgba(rgba, num, -3, 88)
        T.over(cv, rgba, 0, 0)
        if chip_d >= 0:                                      # invented figures: the scenario chip by the number
            ss = {0: 0.6, 2: 1.12, 4: 0.97}.get(chip_d, 1.0)
            sc = self.scenario
            p, ox, oy = T.transform_rgba(sc, ss, 0, origin=(10, sc.shape[0] / 2))
            T.over(cv, p, 300 + ox, 146 + oy)
        if pay_d is not None:
            cv *= 0.92 if pay_d >= 2 else 0.96                    # the page dims a touch behind the paywall
            s = {0: 0.62, 2: 1.12, 4: 0.96}.get(pay_d, 1.0)
            b = self.button
            if chime_d is not None and chime_d in (0, 2):         # the button pings: a bump and a glint
                s *= {0: 1.07, 2: 0.99}[chime_d]
                b = b.copy()
                b[..., :3] = 1 - (1 - b[..., :3]) * (1 - 0.35 * (1 if chime_d == 0 else 0.4))
            p, ox, oy = T.transform_rgba(b, s, 0)
            bx, by = 2, -16                                       # the paywall takes over the go-live bar
            T.over(cv, p, bx + ox, by + oy)
        if flash > 0:
            cv = cv * (1 + 0.45 * flash) + np.float32([0.10, 0.03, 0.08]) * flash   # brighter, still violet
        return np.clip(cv, 0, 1)


# ------------------------------------------------------------------ the shot
class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        self.key_path = key
        ck, cd = clean_key(key, depth)
        L.build(STEM, ck, cd, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_twitch = ctx.f("Twitch")
        self.f_youd = ctx.f("you'd")
        self.f_pay = ctx.f("pay")
        self.f_live = ctx.f("live")
        # the chime and the ring light's death wait until "live" has been said (they sit in the speech band)
        self.f_live_e = ctx.f("live", at="e")
        self.f_chime = min(self.f_live_e + 6, ctx.f1 - 8)
        # emissions: one coin teased out before "pay", then the stream on every drawing for ~1 s
        self.f_tease = self.f_pay - 14
        fp = self.f_pay
        notes = ["n_flat", "n_top", "n_big", "n_curl"]
        coins = ["c_big", "c_a", "c_b", "c_c", "c_d", "c_side"]
        rng = np.random.default_rng(45)
        plan = [(fp, "c_big")]                       # the teased coin goes first
        for k in range(12):                          # 2-3 pieces per drawing for a second
            fe = fp + 2 * k
            m = 4 if k in (0, 1, 3, 5, 7) else 3
            if k >= 10:
                m = 2
            for j in range(m):
                plan.append((fe, notes[(k + j) % 4] if (k + j) % 3 != 1 else coins[(k * 2 + j) % 6]))
        self.items = []
        for fe, kind in plan:
            note = kind.startswith("n")
            self.items.append({"kind": kind, "f": fe, "life": int(rng.integers(7, 10)) * 2,
                               "phase": rng.uniform(0, 6.28), "side": rng.uniform(-1, 1),
                               "rot0": rng.uniform(-40, 40), "spin": rng.uniform(-30, 30),
                               "flip": rng.uniform(0.9, 1.6) * (1 if rng.random() > 0.5 else -1),
                               "size": rng.uniform(1.25, 1.55) if note else rng.uniform(1.15, 1.4)})
        self.f_pulls = sorted({it["f"] for it in self.items})
        # ring light: flicker on 2s once "live" is over, dead before the cut (tail-proof)
        fr0 = min(max(ctx.f1 - 14, self.f_live_e + 8), ctx.f1 - 8)
        self.f_ring = fr0 - fr0 % 2
        fr = self.f_ring
        self.ring_pat = {fr: 0.25, fr + 2: 1.0, fr + 4: 0.08, fr + 6: 0.0}
        self.f_ring_dead = fr + 6
        self.path = CatmullPath(ARC)
        self.path_b = CatmullPath(ARC_B + ARC[5:])
        # pose to pose: A (anticipation through "pay"), a one-drawing smear, then B held and acted
        self.f_smear = self.f_pay + 2
        self.f_b = self.f_smear + 2
        fo = (W * 0.55, H * 0.47)
        self.cam = ParallaxCamera(
            W, H, focus=self._focus(fo, (W * 0.565, H * 0.455), d), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.10, "inout")]),
            push=Track([(0, 0.0), (d, 0.07, "inout")]),
            rise=Track([(0, 0.0), (d, -14.0, "inout")]))

    def _focus(self, a, b, d):
        tr = Track([(0, a), (d, b, "inout")])
        tp = (self.f_pay - self.f0) / FPS

        def fn(t):
            x, y = tr(t)
            u = t - tp
            if u >= 0:                                       # small jolt when the paywall slams, on 1s
                k = math.exp(-u * 9) * math.sin(u * 55)
                x, y = x + 5 * k, y - 7 * k
            return (x, y)
        return fn

    # ------------------------------------------------------------ prepared
    @cached_property
    def screen(self):
        rgb = self.planes[1]["rgb"]
        return ScreenQuad.from_points(SCREEN_QUAD, rgb.shape, scale=SC, plate_rgb=None, overscan=1.01)

    @cached_property
    def screen_mask(self):
        """Quad minus the ring-light frame and the webcam (same depth as the screen, so masked here)."""
        key = load_rgb(self.key_path, width=self.lay.W)
        Hh, Ww = key.shape[:2]
        m = self.screen.mask.copy()
        occ = np.zeros((Hh, Ww), np.float32)
        for (x0, y0, x1, y1) in (RING_BOX, WEBCAM_BOX):
            x0, y0, x1, y1 = [int(v * SC) for v in (x0, y0, x1, y1)]
            c = key[y0:y1, x0:x1]
            occ[y0:y1, x0:x1] = (~(_violet(c) & (c[..., 0] < 0.86))).astype(np.float32)
        occ = cv2.morphologyEx(occ, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        occ = cv2.GaussianBlur(cv2.dilate(occ, np.ones((3, 3), np.uint8)), (0, 0), 0.8)
        return m * (1 - occ)

    @cached_property
    def planes(self):
        out = []
        for i, p in enumerate(self.lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            pl = {"rgb": rgb, "a": p["a"].astype(np.float32) / 255, "n": nearness(p["d"].astype(np.float32) / 65535)}
            if i >= 1:
                mw = magenta_weight(rgb)
                pl["mw"] = mw
                pl["unlit"] = rgb * (1 - mw[..., None]) + unlit_violet(rgb) * mw[..., None]
            out.append(pl)
        self.rings = {i: self._prep_ring(out[i]) for i in (1, 2)}     # the tubes straddle both bands
        return out

    def _prep_ring(self, pl):
        rgb = pl["rgb"]
        x0, y0, x1, y1 = [int(v * SC) for v in RING_BOX]
        c = rgb[y0:y1, x0:x1]
        r, g, b = c[..., 0], c[..., 1], c[..., 2]
        lum = c.max(-1)
        hot = np.clip((np.minimum(r, b) - 0.58) / 0.14, 0, 1) * np.clip((g - 0.30) / 0.14, 0, 1)
        hot = cv2.dilate(hot.astype(np.float32), np.ones((3, 3), np.uint8))
        hot = np.clip(cv2.GaussianBlur(hot, (0, 0), 1.5) * 1.3, 0, 1)
        tex = c.mean(-1, keepdims=True)
        dead = np.float32([0.25, 0.15, 0.33]) * (0.8 + 0.4 * (tex - tex.mean()) / (tex.std() + 1e-6) * 0.25)
        hot = hot * pl["a"][y0:y1, x0:x1]
        ring = {"box": (x0, y0, x1, y1), "hot": hot[..., None], "dead": dead, "lit": c.copy()}
        # spill of the ring on the right of the room: distance falloff from the ring
        H, W = rgb.shape[:2]
        gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
        d = np.hypot(gx - RING_C[0] * SC, (gy - RING_C[1] * SC) * 0.8)
        self.ring_spill = np.clip(1 - d / (560 * SC), 0, 1) ** 1.5
        return ring

    @cached_property
    def pose_b(self):
        """Pose B at work res. Only the streamer changes: B's pixels are taken where the two paintings really
        differ inside HERO_B; pose A's chair and microphone are put back on top; inside the screen B's violet is
        dropped so the live page shows. Also the one in-between drawing (B pulled halfway back toward A)."""
        W, H = self.lay.W, self.lay.H
        Bk = aligned_pose(self.key_path, POSE_B, CACHE / "poseB_aligned.png")
        B = cv2.resize(Bk, (W, H), interpolation=cv2.INTER_AREA)
        A = load_rgb(self.key_path, width=W)
        reg = poly_soft((H, W), HERO_B, SC)
        M = diff_mask(A, B, reg)
        B = color_match(B, A, M)
        keep = poly_soft((H, W), [CHAIR_A, MIC_A], SC, feather=1.5)
        quad = poly_soft((H, W), [SCREEN_QUAD], SC, feather=1.0)

        def take(img, m, where):
            r, g, b = img[..., 0], img[..., 1], img[..., 2]
            violet = np.clip((np.minimum(r, b) - g - 0.22) / 0.10, 0, 1) * np.clip((b - 0.55) / 0.15, 0, 1)
            return cv2.GaussianBlur(m * (1 - where * violet), (0, 0), 1.2)

        fx, fy = smooth_field((H, W), [(x * SC, y * SC) for x, y in AB_PTS],
                              [(x * SC, y * SC) for x, y in AB_DISP], 230 * SC)
        ab = half_warp(B, fx, fy, 0.5)
        ab_m = M * half_warp(M, fx, fy, 0.5)        # only what came from inside the swapped area
        ab_m = take(ab, ab_m, 1.0)                   # the screen's violet, wherever it was carried, is dropped
        ys, xs = np.nonzero(M > 0.003)
        x0, y0, x1, y1 = int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1
        cr = (slice(y0, y1), slice(x0, x1))

        def unlit(rgb):
            mwt = magenta_weight(rgb)
            return rgb * (1 - mwt[..., None]) + unlit_violet(rgb) * mwt[..., None]

        rgb, abc = B[cr], ab[cr]
        hw = rgb.shape[:2]
        gy = np.mgrid[0:hw[0], 0:hw[1]][0].astype(np.float32) + y0
        upper = np.clip((2250 * SC - gy) / (520 * SC), 0, 1)
        hair = radial(hw, x0, y0, np.float32(B_HEAD) * SC, 110 * SC, 330 * SC) * upper
        # plane 3's depth smoothed over the swapped area, so the camera does not fold along A's old outline
        n3, a3 = self.planes[3]["n"], self.planes[3]["a"]
        w = np.clip(a3, 0.02, 1).astype(np.float32)
        ns = cv2.GaussianBlur(n3 * w, (0, 0), 40) / (cv2.GaussianBlur(w, (0, 0), 40) + 1e-6)
        return {"rgb": rgb, "unlit": unlit(rgb), "a": take(B, M, quad)[cr], "ab": abc, "ab_unlit": unlit(abc),
                "ab_a": ab_m[cr], "M": M, "keep": keep, "rm4": M * (1 - keep),
                "n3": (n3 * (1 - M) + ns * M).astype(np.float32),
                "x0": x0, "y0": y0, "upper": upper, "hair": hair,
                "wallet": radial(hw, x0, y0, np.float32(B_WALLET) * SC, 150 * SC, 330 * SC),
                "hand": radial(hw, x0, y0, np.float32(B_FINGERS) * SC, 105 * SC, 250 * SC)}

    def settle_b(self, fh):
        """The lunge lands past pose B, springs back, then breathes (key px and degrees)."""
        d = fh - self.f_b
        k = _sum_keys([(0, 1.0), (2, -0.35), (4, 0.12), (6, 0.0)], d)
        br = math.sin((fh - self.f0) / FPS * 2 * math.pi * 0.7)
        vx, vy = LUNGE_V
        return {"angle_deg": -1.4 * k + 0.2 * br, "dx": (-0.10 * vx * k) * SC, "dy": (-0.10 * vy * k + 1.5 * br) * SC}

    def wallet_b(self, fh):
        ang = dx = dy = 0.0
        for j, fe in enumerate(self.f_pulls[::2]):
            if fe < self.f_b:
                continue
            g = 0.9 if j % 2 else 0.7
            dd = fh - fe
            dy += g * _sum_keys([(0, -18), (2, 6), (4, -2), (6, 0)], dd)
            dx += g * _sum_keys([(0, -8), (2, 3), (4, 0)], dd)
            ang += g * _sum_keys([(0, 4.0), (2, -1.5), (4, 0.5), (6, 0)], dd)
        return {"angle_deg": ang, "dx": dx * SC, "dy": dy * SC}

    def hand_b(self, fh):
        """The free hand claws at the stream on 2s: grab, open, grab further."""
        d = (fh - self.f_b) // 2
        ang, dx, dy = [(0, 0, 0), (-6, 10, -12), (2, 4, -4), (-5, 14, -16)][d % 4]
        reach = min(max(d, 0) / 8, 1.0)
        return {"angle_deg": ang, "dx": (dx + 10 * reach) * SC, "dy": (dy - 14 * reach) * SC}

    def head_b(self, fh):
        kr = _sum_keys([(0, 0.0), (2, 1.0), (4, 0.4), (8, 0.0)], fh - self.f_ring_dead)    # flinch at the pop
        return {"angle_deg": -2.0 * kr, "dx": -8 * kr * SC, "dy": 5 * kr * SC}

    def pose_state(self, f):
        """"A" (with the lean-back anticipation drawings before the lunge), "AB" (the one in-between), "B"."""
        fh = f - f % 2
        return "B" if fh >= self.f_b else ("AB" if fh >= self.f_smear else "A")

    def pose_b_patch(self, f, ratio, st):
        fh = f - f % 2
        P = self.pose_b
        x0, y0 = P["x0"], P["y0"]
        if st == "AB":                                      # the in-between: one drawing, no cross-fade
            lit = P["ab_unlit"] + (P["ab"] - P["ab_unlit"]) * ratio
            return np.dstack([lit, P["ab_a"]]).astype(np.float32), x0, y0
        lit = P["unlit"] + (P["rgb"] - P["unlit"]) * ratio
        rgba = np.dstack([lit, P["a"]]).astype(np.float32)
        piv = np.float32([700, 2400]) * SC
        up, hair = P["upper"], P["hair"]
        parts = [(up * (1 - hair), piv, self.settle_b(fh)),
                 (up * hair, piv, self.settle_b(fh - 4)),            # the hair follows the lunge late
                 (P["wallet"], np.float32([1010, 1640]) * SC, self.wallet_b(fh)),
                 (P["hand"], np.float32(B_WRIST) * SC, self.hand_b(fh)),
                 (hair, np.float32(B_HEAD) * SC + np.float32([0, 260 * SC]), self.head_b(fh))]
        return multi_pose(rgba, x0, y0, parts), x0, y0

    @cached_property
    def sprites(self):
        res = {}
        for s in self.lay.sprites:
            s2 = dict(s)
            rgba = s["rgba"].astype(np.float32) / 255
            s2["rgba_f"] = rgba
            s2["w_f"] = s["w"].astype(np.float32) / 255
            mw = magenta_weight(rgba[..., :3])
            s2["mw"] = mw
            s2["unlit"] = rgba[..., :3] * (1 - mw[..., None]) + unlit_violet(rgba[..., :3]) * mw[..., None]
            x0, y0, x1, y1 = s["bbox"]
            h, w = rgba.shape[:2]
            gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
            gx += x0
            gy += y0
            if s["name"] == "head":
                # outer hair trails (follow-through); strongest on the loose strands at the back and top
                c = np.float32([360, 1520]) * SC
                r = np.hypot(gx - c[0], (gy - c[1]) * 1.15)
                s2["lag"] = np.clip((r - 150 * SC) / (200 * SC), 0, 1) ** 1.3
                # the suction tugs the top/right hair toward the lens
                top = np.clip((1420 * SC - gy) / (200 * SC), 0, 1) * np.clip((gx - 120 * SC) / (300 * SC), 0, 1)
                s2["tug"] = cv2.GaussianBlur(top * s2["lag"], (0, 0), 6)
            else:
                # the forearm follows the yanked hand a drawing late
                s2["lag"] = np.clip((gy - 1800 * SC) / (160 * SC), 0, 1)
            res[s["name"]] = s2
        return res

    @cached_property
    def cutouts(self):
        key = load_rgb(self.key_path)
        return extract_cutouts(key, CUTOUTS)

    @cached_property
    def dash(self):
        return Dashboard(np.float32([0.74, 0.25, 0.97]))

    @cached_property
    def c_base(self):
        return screen_light(self._canvas(self.f0))

    # ------------------------------------------------------------ state
    def queue_value(self, f):
        """Ticks down in uneven steps on 2s (a queue that barely moves), lands on 48,211 before "pay"."""
        fh = f - f % 2
        steps = max((self.f_pay - 2 - self.f0) // 2, 1)
        k = min(max((fh - self.f0) // 2, 0), steps)
        rng = np.random.default_rng(3)
        drops = rng.integers(0, 3, steps)
        drops = np.round(drops * 25 / max(drops.sum(), 1)).astype(int)
        return 48211 + int(drops.sum() - drops[:k].sum())

    def _canvas(self, f):
        if getattr(self, "_cvc", (None,))[0] == f - f % 2:
            return self._cvc[1]
        fh = f - f % 2
        pay_d = fh - self.f_pay if fh >= self.f_pay else None
        flash = {0: 0.34, 2: 0.10}.get(pay_d, 0.0) if pay_d is not None else 0.0
        cv = self.dash.draw(fh, self.queue_value(fh), pay_d, flash, chip_d=fh - self.f0 + 6,
                            chime_d=fh - self.f_chime if fh >= self.f_chime else None)
        self._cvc = (fh, cv)
        return cv

    def ring_level(self, f):
        fh = f - f % 2
        if fh < self.f_ring:
            return 1.0
        if fh >= self.f_ring_dead:
            return 0.0
        return self.ring_pat.get(fh, 1.0)

    def suction(self, f):
        """0..1 strength of the pull (hair tug, lens glow): builds from "you'd", peaks after "pay"."""
        fh = f - f % 2
        return float(Track([(self.f_youd, 0.0), (self.f_pay - 2, 0.25, "in"), (self.f_pay + 2, 1.0, "out"),
                            (self.f_pay + 26, 1.0), (self.f_pay + 40, 0.4, "inout")])(fh))

    def lens_pulse(self, f):
        """Flash when an item disappears into the lens (on 2s)."""
        fh = f - f % 2
        v = 0.0
        for it in self.items:
            fa = it["f"] + it["life"]
            if fa <= fh < fa + 4:
                v = max(v, 1.0 if fh == fa else 0.45)
        return v

    def arm_pose(self, f):
        fh = f - f % 2
        ang = dx = dy = 0.0
        # anticipation: the hand clutches the wallet back toward the body while he leans back before the lunge
        k = _sum_keys([(self.f_pay - 6, 0), (self.f_pay - 2, 1.0), (self.f_pay, 1.4)], fh)
        ang -= 2.0 * k
        dy += 9 * k
        dx += 4 * k
        # each pull yanks the wallet toward the lens, overshoots back, settles (pose A only shows it before "pay")
        for j, fe in enumerate(self.f_pulls[::2]):          # a hard yank every other drawing
            if fe <= self.f_pay:
                continue
            dd = fh - fe
            g = 0.8 if j % 2 else 0.65
            dy += g * _sum_keys([(0, -15), (2, 5), (4, -2), (6, 0)], dd)
            dx += g * _sum_keys([(0, -5), (2, 2), (4, 0)], dd)
            ang += g * _sum_keys([(0, 3.0), (2, -1.2), (4, 0.4), (6, 0)], dd)
        # the arm is dragged out further while the stream runs, and drops once the wallet is empty
        drag = float(Track([(self.f_pay, 0.0), (self.f_pay + 10, 1.0, "out"), (self.f_pulls[-1] + 2, 1.0),
                            (self.f_pulls[-1] + 10, 0.2, "inout")])(fh))
        dy -= 12 * drag
        dx -= 5 * drag
        ang += 2.5 * drag
        return {"angle_deg": ang, "dx": dx * SC, "dy": dy * SC}

    def head_pose(self, f):
        fh = f - f % 2
        lf = fh - self.f0
        breathe = math.sin(lf / FPS * 2 * math.pi * 0.55)
        # anticipation: two drawings leaning back (down toward us, a little bigger) before the lunge
        lean = _sum_keys([(self.f_pay - 4, 0.0), (self.f_pay - 2, 0.6), (self.f_pay, 1.0)], fh) if fh <= self.f_pay else 0.0
        return {"angle_deg": 4.0 * lean + 0.25 * breathe, "dx": -14 * lean * SC,
                "dy": (28 * lean + 1.2 * breathe) * SC, "scale": 1 + 0.05 * lean}

    # ------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        cv = self._canvas(f)
        c = screen_light(cv)
        ratio = np.clip(1 + 0.75 * (c / np.maximum(self.c_base, 1e-3) - 1), 0.4, 2.0).astype(np.float32)
        bright = float(np.clip(c.mean() / self.c_base.mean(), 0.6, 1.4))
        ratio = ratio * (0.55 + 0.45 * bright)
        pulse = self.lens_pulse(f)
        ratio = ratio * (1 + 0.16 * pulse)
        ring = self.ring_level(f)
        st = self.pose_state(f)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a = pl["rgb"], pl["a"]
            if i >= 1:
                rgb = pl["unlit"] + (pl["rgb"] - pl["unlit"]) * ratio
                if ring < 1:
                    k = (1 - ring) * 0.5 * (self.ring_spill * pl["mw"])[..., None]
                    rgb = rgb * (1 - k) + pl["unlit"] * k
            if i == 1:
                base = rgb
                rgb = rgb.copy()
                a = a.copy()
                self.screen.place(rgb, a, cv, glass=0.22)
                # re-lay the ring frame and webcam (same depth as the screen) over the quad
                occ = (self.screen.mask - self.screen_mask)[..., None]
                rgb = rgb * (1 - occ) + base * occ
                self._ring_into(rgb, ring, 1)
            if i == 2:
                self._ring_into(rgb, ring, 2)
            n = pl["n"]
            if i == 4 and st != "A":
                a = a * (1 - self.pose_b["rm4"])                 # pose A's shoulders go; the chair stays
            elif i == 3:
                rgb = rgb.copy() if rgb is pl["rgb"] else rgb
                a = a.copy()
                rest = st != "A"                                  # under pose B the A sprites sit at rest
                for name, pose, kw in (("arm", self.arm_pose(f), self._arm_lag(f)),
                                       ("head", self.head_pose(f), self._head_lag(f))):
                    s = self.sprites[name]
                    sp = dict(s)
                    lit = s["unlit"] + (s["rgba_f"][..., :3] - s["unlit"]) * ratio
                    if ring < 1 and name == "arm":
                        lit = lit * (1 - 0.2 * (1 - ring) * s["mw"][..., None]) + 0 * lit
                    sp["rgba_f"] = np.dstack([lit, s["rgba_f"][..., 3]])
                    if rest:
                        pose, kw = {"angle_deg": 0.0, "dx": 0.0, "dy": 0.0}, {}
                    patch, x0, y0 = deform_blend(sp, pose, **kw)
                    composite_into(rgb, a, patch, x0, y0)
                if rest:
                    P = self.pose_b
                    o_rgb, o_a = rgb.copy(), a.copy()
                    a *= 1 - P["M"]
                    patch, x0, y0 = self.pose_b_patch(f, ratio, st)
                    composite_into(rgb, a, patch, x0, y0)
                    k = o_a * P["keep"]                           # the chair and the mic, unchanged, on top
                    rgb = rgb * (1 - k[..., None]) + o_rgb * k[..., None]
                    a = a + k * (1 - a)
                    n = P["n3"]
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._money(img, f, t)
        img = self._fx(img, f, t, ring, pulse)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Twitch: about 6 million streamers a month", self.f_twitch, size=38)
        return img, {"pay": f >= self.f_pay}

    def _arm_lag(self, f):
        return {"lag_pose": self.arm_pose(f - 2), "lag_w": self.sprites["arm"]["lag"] * 0.8}

    def _head_lag(self, f):
        s = self.sprites["head"]
        fh = f - f % 2
        su = self.suction(f)
        flutter = math.sin((fh - self.f0) * 1.9) * 0.5 + 0.5
        tug = s["tug"] * su * (0.75 + 0.25 * flutter)
        drift = (tug * 9 * SC, -tug * 7 * SC)
        return {"lag_pose": self.head_pose(f - 4), "lag_w": s["lag"] * 0.9, "drift": drift}

    def _ring_into(self, rgb, ring, i):
        R = self.rings[i]
        x0, y0, x1, y1 = R["box"]
        h = R["hot"]
        seg = rgb[y0:y1, x0:x1]
        # the tubes are light sources: never relit by the screen; lit -> dead with the flicker level
        tube = R["lit"] * ring + R["dead"] * (1 - ring)
        rgb[y0:y1, x0:x1] = seg * (1 - h) + tube * h

    # ------------------------------------------------------------ the money
    def item_state(self, it, f):
        """Position (key px), scale, angle, squash and heat of one flying item at f (on 2s), or None."""
        fh = f - f % 2
        age = fh - it["f"]
        if it is self.items[0] and self.f_tease <= fh < it["f"]:
            # the teased coin: lifts out of the wallet and wobbles, held by the pull before "pay"
            u = (fh - self.f_tease) / max(it["f"] - self.f_tease, 1)
            base = np.float32(ARC[0]) + np.float32([-6, -70]) * min(1.0, u * 1.4)
            wob = math.sin((fh - self.f_tease) * 1.3) * 6
            return {"p": base + np.float32([wob, 0]), "scale": 0.85, "ang": wob * 3, "fx": math.cos(u * 5), "s": 0.0,
                    "yaw": u * 5, "pitch": 0.25 * math.sin(u * 4), "fold": 0.0}
        if age < 0 or age > it["life"]:
            return None
        u = age / it["life"]
        s = u ** 1.2
        if it is self.items[0]:
            s = 0.08 + 0.92 * s
        path = self.path_b if fh >= self.f_smear else self.path
        p = path(s)
        tg = path.tangent(s)
        nrm = np.float32([-tg[1], tg[0]])
        spread = 55 * (1 - s) ** 1.2 * it["side"] + 28 * (1 - s) * math.sin(2 * math.pi * 1.4 * s + it["phase"])
        p = p + nrm * spread
        sz = it["size"] * (1 - 0.86 * s ** 1.4)
        ang = it["rot0"] + it["spin"] * age / 2 + math.degrees(math.atan2(tg[1], tg[0])) * 0.25
        yaw = it["phase"] + it["flip"] * age / 2 * 1.3
        pitch = 0.85 * math.sin(it["phase"] * 1.7 + age * 0.33)
        fold = math.radians(28 + 22 * math.sin(age * 0.9 + it["phase"] * 2.3)) if it["kind"].startswith("n") else 0.0
        return {"p": p, "scale": sz, "ang": ang, "fx": math.cos(yaw), "s": s, "yaw": yaw, "pitch": pitch, "fold": fold}

    def _money(self, img, f, t):
        for it in self.items:
            st = self.item_state(it, f)
            if st is None:
                continue
            spr = self.cutouts[it["kind"]]
            s_dep = 0.36 + (0.14 - 0.36) * st["s"]
            n = float(nearness(np.float32(s_dep)))
            q = self.cam.screen_point(st["p"] * SC, n, t)
            k = self.cam.scale_at(n, t) * SC * st["scale"]
            patch, cx, cy = card3d(spr, st["yaw"], st["pitch"], st["ang"], k, st["fold"],
                                   thick=0.0 if it["kind"].startswith("n") else 0.09)
            if patch is None:
                continue
            heat = smoothstep(0.62, 0.98, st["s"])
            if heat > 0:
                patch[..., :3] = patch[..., :3] * (1 - heat * 0.6) + np.float32([1.0, 0.78, 1.0]) * heat * 0.6
                patch[..., 3] *= 1 - smoothstep(0.88, 1.0, st["s"])
            rim = cv2.dilate(patch[..., 3], np.ones((3, 3), np.uint8)) - patch[..., 3]
            if rim.max() > 0:
                acc = np.zeros_like(patch)
                acc[..., :3] = np.float32([0.16, 0.05, 0.24])
                acc[..., 3] = np.clip(rim, 0, 1) * 0.55
                T.over(img, acc, q[0] - cx, q[1] - cy)
            T.over(img, patch, q[0] - cx, q[1] - cy)
        return img

    def _fx(self, img, f, t, ring, pulse):
        fh = f - f % 2
        H, W = img.shape[:2]
        sc = ShapeCanvas(W, H)
        n_lens = float(nearness(np.float32(0.135)))
        lens = self.cam.screen_point(np.float32(LENS) * SC, n_lens, t)
        su = self.suction(f)
        rng = np.random.default_rng(fh)
        # the lens charges (steady star) and flashes as each item is swallowed
        r = (18 + 26 * su + 46 * pulse) * self.cam.scale_at(n_lens, t)
        if su > 0.02 or pulse > 0:
            sc.fill(star4_poly(lens, r, angle=0.15 * (fh % 4), pinch=0.16))
            sc.fill(star4_poly(lens, r * 0.45, angle=0.78, pinch=0.3))
        # shards: items breaking into pixels as they enter the lens, streaking into it
        for it in self.items:
            st = self.item_state(it, f)
            if st is None or st["s"] < 0.6:
                continue
            p = self.cam.screen_point(st["p"] * SC, float(nearness(np.float32(0.36 - 0.22 * st["s"]))), t)
            d = np.float32(lens) - np.float32(p)
            dl = np.linalg.norm(d) + 1e-6
            for j in range(4):
                o = rng.normal(0, 9, 2)
                q = np.float32(p) + d * rng.uniform(0.15, 0.7) + o
                w = rng.uniform(3, 7)
                sq = np.float32([[-w, -w], [w, -w], [w, w], [-w, w]]) + q
                sc.fill(sq, value=int(255 * rng.uniform(0.6, 1.0)))
        # suction lines: dry tapered streaks along the arc while the stream runs
        if su > 0.3 and False:                       # (speed lines read as scratches; left out)
            for j in range(3):
                s0 = (rng.uniform(0.1, 0.9))
                pth = self.path_b if fh >= self.f_smear else self.path
                p = pth(s0)
                tg = pth.tangent(s0)
                p = p + np.float32([-tg[1], tg[0]]) * rng.uniform(-90, 90) * (1 - s0)
                q = self.cam.screen_point(p * SC, float(nearness(np.float32(0.3 - 0.15 * s0))), t)
                sc.fill(tapered_streak_poly(q, tg, rng.uniform(40, 80) * su, 3), value=int(70 + 50 * su))
        # the ring light pops when it dies
        dd = fh - self.f_ring_dead
        if 0 <= dd <= 4:
            pr = self.cam.screen_point(np.float32([1338, 1290]) * SC, float(nearness(np.float32(0.14))), t)
            spark_burst(sc, pr, dd // 2, seed=77, scale=1.1)
        core, glow = sc.result(glow_sigma=5)
        return screen_emissive(img, core, glow, (1.0, 0.92, 1.0), (0.85, 0.35, 1.0))

    def finish_args(self, f, info):
        return {"bloom_strength": 0.6 if info["pay"] else 0.5}

    # ------------------------------------------------------------ events and sound
    def events(self):
        ev = [(self.f0, "cut", {}), (self.f_twitch, "data_tag", {}), (self.f_tease, "coin_tease", {}),
              (self.f0, "scenario_chip", {}),
              (self.f_pay, "paywall", {}), (self.f_chime, "paywall_chime", {}),
              (self.f_pay - 2, "anticipation", {}), (self.f_smear, "inbetween", {}), (self.f_b, "pose_B", {})]
        for it in self.items:
            ev.append((it["f"], "pull_" + ("note" if it["kind"].startswith("n") else "coin"), {}))
            if it["f"] + it["life"] <= self.f1 - 2:                # nothing lands across the cut
                ev.append((it["f"] + it["life"], "swallow", {}))
        for fr, lv in self.ring_pat.items():
            if lv < 0.5:
                ev.append((fr, "ring_flicker", {}))
        ev.append((self.f_ring_dead, "ring_dead", {}))
        return ev

    def _duck(self, tt, g):
        """Gain over absolute times tt: g while "to go live" is being said (plus its tail), 1 elsewhere."""
        a, b = self.ctx.word("to")["s"] - 0.05, self.ctx.word("live")["e"] + 0.27
        w = np.clip((tt - a) / 0.06, 0, 1) * np.clip((b - tt) / 0.08, 0, 1)
        return 1 - (1 - g) * w

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tail = dur + 0.6
        snd.bed(A.room_tone(tail, seed=51), t0, -30)
        # ring light: a thin mains buzz that stutters with the flicker and stops dead
        tt = A.t_axis(tail) + t0
        lvl = np.array([self.ring_level(int(x * FPS)) for x in tt[::240]])
        lvl = np.repeat(lvl, 240)[:len(tt)]
        gate = A.lowpass(lvl, 60)
        buzz = A.hum(tail, 100.0, seed=52) * 0.6 + A.bandpass(np.sign(A.osc(100.0, tail)), 800, 4000) * 0.12
        snd.bed(buzz * gate, t0, -33, 0.55)
        # lens charge: a rising whine from "you'd" into "pay"
        ta, tb = self.f_youd / FPS, self.f_pay / FPS
        nn = int((tb - ta) * A.SR)
        fr = np.linspace(380, 1150, nn)
        wh = A.osc(fr, nn / A.SR) * np.linspace(0, 1, nn) ** 2 * 0.5 + A.bandpass(A.noise(nn / A.SR, 53), 1500, 5000) * \
            np.linspace(0, 1, nn) ** 3 * 0.3
        snd.sfx(wh, ta, -31, -0.15)
        # suction: a reverse-swept airy roar from "pay" over the stream
        ts = self.f_pay / FPS
        ds = (self.f_pulls[-1] + 20 - self.f_pay) / FPS
        n = int(ds * A.SR)
        x = A.noise(ds, 54, "pink")
        e = np.clip(np.linspace(0, 1, n) * 6, 0, 1) * np.clip((1 - np.linspace(0, 1, n)) * 3, 0, 1)
        roar = (A.bandpass(x, 220, 900) + A.bandpass(x, 4500, 9000) * 0.5) * e     # around the voice, not on it
        roar = roar * self._duck(ts + A.t_axis(ds), 0.25)
        snd.sfx(roar / (np.abs(roar).max() + 1e-9), ts, -23, -0.2)
        snd.sfx(A.whoosh(0.32, seed=55)[::-1].copy(), ts, -19, -0.2)
        # paywall: two-note chime and a low thump under it
        # the lunge: a cloth swish on the smear, the chair knocked back as pose B lands
        snd.sfx(A.highpass(A.swish(0.26, seed=63), 4000), snd.at_frame(self.f_smear), -20, -0.3)
        snd.sfx(A.lowpass(A.thunk(seed=64), 260), snd.at_frame(self.f_b), -23, -0.5)
        # on "pay" only things outside the voice band: a low thump and an airy tick above 5 kHz
        snd.sfx(A.lowpass(A.thunk(seed=58), 320), ts, -14)
        snd.sfx(A.highpass(A.tick(56, 7200), 5200), ts, -24, -0.25)
        # the paywall chime lands once "pay to go live" has been said, on the button's ping
        tc = self.f_chime / FPS
        snd.sfx(A.bell(1318.5, 0.8, seed=56), tc, -22, -0.25)
        snd.sfx(A.bell(1975.5, 1.0, seed=57), tc + 3 / FPS, -23, -0.25)
        snd.sfx(A.tick(59, 2400), (self.f_pay + 4) / FPS, -27, -0.3)
        for k, it in enumerate(self.items):
            te = it["f"] / FPS
            pan = 0.15 + 0.1 * (k % 3)
            dk = 20 * math.log10(float(self._duck(np.float64([te + 0.05]), 0.3)[0]))   # quiet under "go live"
            if it["kind"].startswith("n"):
                snd.sfx(_flutter(0.22, 60 + k), te, -22 + dk, pan)
            else:
                snd.sfx(_clink(61 + k, 1 + (k % 3) * 0.06), te, -21 + dk, pan)
            if it["f"] + it["life"] <= self.f1 - 2:
                tw = (it["f"] + it["life"]) / FPS
                snd.sfx(A.tick(62 + k, 4200), tw, -29 + 20 * math.log10(float(self._duck(np.float64([tw]), 0.3)[0])), -0.3)
        for fr, lv in self.ring_pat.items():
            if lv < 0.5:
                snd.sfx(A.zap(fr, 0.05, 0.5), fr / FPS, -25, 0.6)
        snd.sfx(A.zap(self.f_ring_dead + 5, 0.14, 1.3), self.f_ring_dead / FPS, -19, 0.6)
        snd.sfx(A.soft_click(900, 63), self.f_ring_dead / FPS, -18, 0.6)


def _flutter(dur, seed):
    """Paper flutter: band noise chopped by a fast, uneven flap."""
    n = int(dur * A.SR)
    t = A.t_axis(dur)
    rng = np.random.default_rng(seed)
    flap = np.clip(np.sin(2 * np.pi * (rng.uniform(26, 38) * t + 2 * np.sin(2 * np.pi * 5 * t))), 0, 1) ** 2
    x = A.bandpass(A.noise(dur, seed, "pink"), 1200, 6500) * (0.35 + 0.65 * flap)
    return x * A.env_adsr(n, 0.004, 0.05, 0.6, dur * 0.5) / (np.abs(x).max() + 1e-9)


def _clink(seed, pitch=1.0):
    """Coin clink: a few inharmonic metal partials with fast decays and a tiny contact click."""
    dur = 0.35
    n = int(dur * A.SR)
    out = np.zeros(n)
    for ratio, amp, tau in [(1.0, 1.0, 0.09), (1.47, 0.6, 0.07), (2.09, 0.45, 0.05), (2.81, 0.3, 0.035)]:
        out += amp * A.osc(2350 * pitch * ratio, dur) * A.exp_decay(n, tau)
    out += A.bandpass(A.noise(dur, seed), 3000, 9000) * A.exp_decay(n, 0.003) * 0.8
    return out / (np.abs(out).max() + 1e-9)


def make(ctx):
    return Shot(ctx)
