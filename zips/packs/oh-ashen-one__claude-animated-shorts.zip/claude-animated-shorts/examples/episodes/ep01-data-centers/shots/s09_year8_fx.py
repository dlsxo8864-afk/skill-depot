"""Local helpers written for s09_year8 and s10_year9 (candidates to hoist into whatif/ later).

- Shake: weighted camera shake (focus offset + roll) from impact list, sampled on 1s.
- part_warp: multi-part soft-weighted pose of a sprite crop (overlapping, offset timing between
  body parts: head / shoulders / hands), so figures bend instead of moving as rigid cut-outs.
- goo_rgba: shade an AA coverage mask as painted glossy goo (dark rim, lit body, hard highlight,
  brush streaks, soft painted edge).
- chunk_poly / paint_solid: painted rubble chunks (lit face + shadow face) in plane space.
- haze_puff: a painted dust puff (stepped values, brushy edge) for impacts.
- Sounds: buzzer, drip, printer_burst, trolley_rattle, murmur, stone_crack, rumble, snap_crash,
  coin_clink, glass_crack, sub_hit, wind.
"""
import math

import cv2
import numpy as np
from scipy import signal

from whatif import audio as A
from whatif.layers import brush_noise


# ------------------------------------------------------------------ camera shake
class Shake:
    """Sum of damped impacts. hits: [(t, amp_px, freq_hz, decay_s, roll_deg)]. Each impact starts with a
    hard jolt (down and sideways), then rings out heavily (low frequency, fast decay = weight)."""

    def __init__(self, hits, seed=3):
        rng = np.random.default_rng(seed)
        self.hits = [(t, a, fq, dc, rl, rng.uniform(0, 6.28), rng.choice([-1, 1])) for t, a, fq, dc, rl in hits]

    def __call__(self, t):
        dx = dy = roll = 0.0
        for t0, a, fq, dc, rl, ph, sgn in self.hits:
            u = t - t0
            if u < 0 or u > dc * 6:
                continue
            env = math.exp(-u / dc)
            dy += a * env * math.cos(2 * math.pi * fq * u)                 # first frame: full drop
            dx += a * 0.6 * sgn * env * math.sin(2 * math.pi * fq * 1.37 * u + 0.4)
            roll += rl * sgn * env * math.sin(2 * math.pi * fq * 0.8 * u + 0.9)
        return dx, dy, roll


# ------------------------------------------------------------------ soft multi-part pose
def poly_weight(shape, pts, blur, offset=(0, 0)):
    """Soft weight map (crop space) from a polygon given in plane px, blurred by `blur` px."""
    m = np.zeros(shape, np.float32)
    p = np.round((np.asarray(pts, np.float32) - np.float32(offset)) * 4).astype(np.int32)
    cv2.fillPoly(m, [p], 1.0, cv2.LINE_AA, shift=2)
    return cv2.GaussianBlur(m, (0, 0), blur) if blur > 0 else m


def part_warp(rgba, x0, y0, parts, extra=None):
    """Warp a crop (float RGBA at plane offset x0, y0) by a sum of soft-weighted rigid parts.
    parts: [{"w": weight (h, w), "angle": deg, "dx": px, "dy": px, "pivot": (x, y) plane px}].
    extra: optional (DX, DY) displacement fields added on top (cloth flutter etc.).
    Forward displacement D(p) = sum_k w_k(p) (R_k (p - c_k) + c_k + d_k - p); the inverse is found
    with two fixed-point steps (fine for the few-px poses used here)."""
    h, w = rgba.shape[:2]
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    X, Y = gx + x0, gy + y0
    DX = np.zeros((h, w), np.float32)
    DY = np.zeros((h, w), np.float32)
    for p in parts:
        a = math.radians(p.get("angle", 0.0))
        ca, sa = math.cos(a), math.sin(a)
        px, py = p.get("pivot", (0, 0))
        ux, uy = X - px, Y - py
        fx = ca * ux - sa * uy + px + p.get("dx", 0.0) - X
        fy = sa * ux + ca * uy + py + p.get("dy", 0.0) - Y
        DX += p["w"] * fx
        DY += p["w"] * fy
    if extra is not None:
        DX += extra[0]
        DY += extra[1]
    sx, sy = gx - DX, gy - DY
    for _ in range(2):
        dxs = cv2.remap(DX, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        dys = cv2.remap(DY, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        sx, sy = gx - dxs, gy - dys
    return cv2.remap(rgba, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)


# ------------------------------------------------------------------ painted shapes
def raster(shape, polys, ss=4, circles=()):
    """AA coverage of polygons (and (cx, cy, r) circles) in a (h, w) canvas, supersampled."""
    h, w = shape
    m = np.zeros((h * ss, w * ss), np.uint8)
    for p in polys:
        cv2.fillPoly(m, [np.round(np.asarray(p, np.float32) * ss * 4).astype(np.int32)], 255, cv2.LINE_AA, shift=2)
    for cx, cy, r in circles:
        cv2.circle(m, (int(round(cx * ss * 4)), int(round(cy * ss * 4))), max(1, int(round(r * ss * 4))), 255, -1,
                   cv2.LINE_AA, shift=2)
    return cv2.resize(m.astype(np.float32) / 255, (w, h), interpolation=cv2.INTER_AREA)


def goo_rgba(mask, base, seed=0, light=(-0.55, -0.85), gloss=1.0, edge_soft=0.7, translucency=0.10):
    """Shade an AA coverage mask (h, w) as thick painted goo. Returns float RGBA.
    Dark rim on the shadow side, lit body, a hard specular stroke on the light side, brush streaks."""
    m = mask.astype(np.float32)
    hard = (m > 0.5).astype(np.uint8)
    dist = cv2.distanceTransform(hard, cv2.DIST_L2, 3)
    t = np.clip(dist / 5.0, 0, 1)                                  # 0 at the edge -> 1 inside
    lx, ly = light
    sh = np.float32([[1, 0, lx * 3.0], [0, 1, ly * 3.0]])
    toward = cv2.warpAffine(m, sh, (m.shape[1], m.shape[0]))       # coverage shifted toward the light
    lit_edge = np.clip(m - toward, 0, 1)                           # edge facing the light
    sh2 = np.float32([[1, 0, -lx * 3.0], [0, 1, -ly * 3.0]])
    away = cv2.warpAffine(m, sh2, (m.shape[1], m.shape[0]))
    shadow_edge = np.clip(m - away, 0, 1)
    base = np.asarray(base, np.float32)
    n = brush_noise(m.shape, seed, scale=1.6, angle=1.45, stretch=6.0)
    body = base * (0.70 + 0.30 * t)[..., None] * (1 + 0.07 * n[..., None])
    body = body * (1 - 0.45 * shadow_edge[..., None]) + np.float32([0.30, 0.04, 0.16]) * 0.45 * shadow_edge[..., None]
    # specular: a broken, hard stroke just inside the lit edge
    spec = cv2.GaussianBlur(lit_edge, (0, 0), 0.6) * (t > 0.15) * np.clip(0.6 + 0.6 * n, 0, 1)
    spec = np.clip(spec * 2.2 * gloss, 0, 1)
    hi = np.float32([1.0, 0.86, 0.90])
    rgb = body * (1 - spec[..., None]) + hi * spec[..., None]
    a = cv2.GaussianBlur(m, (0, 0), edge_soft) if edge_soft > 0 else m
    a = np.clip(a * (1 - translucency * t), 0, 1)
    return np.dstack([np.clip(rgb, 0, 1), a]).astype(np.float32)


def over_patch(dst_rgb, rgba, x0, y0, dst_a=None):
    """Alpha-over a float RGBA patch into plane arrays (in place)."""
    h, w = rgba.shape[:2]
    H, W = dst_rgb.shape[:2]
    xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x0 + w, W), min(y0 + h, H)
    if xb <= xa or yb <= ya:
        return
    p = rgba[ya - y0:yb - y0, xa - x0:xb - x0]
    a = p[..., 3:4]
    dst_rgb[ya:yb, xa:xb] = dst_rgb[ya:yb, xa:xb] * (1 - a) + p[..., :3] * a
    if dst_a is not None:
        dst_a[ya:yb, xa:xb] = dst_a[ya:yb, xa:xb] * (1 - a[..., 0]) + a[..., 0]


def chunk_poly(c, r, angle, seed, sides=5, squash=0.75):
    """An irregular rubble chunk polygon around c."""
    rng = np.random.default_rng(seed)
    k = int(sides + rng.integers(0, 2))
    ang = np.sort(rng.uniform(0, 2 * math.pi, k))
    rad = r * rng.uniform(0.65, 1.15, k)
    pts = np.stack([np.cos(ang) * rad, np.sin(ang) * rad * squash], 1)
    ca, sa = math.cos(angle), math.sin(angle)
    pts = pts @ np.float32([[ca, sa], [-sa, ca]])
    return pts + np.float32(c)


def paint_solid(mask, dark, lit, rim, seed, light=(-0.4, -0.9)):
    """Shade a solid chunk: two value planes split across the shape plus a thin coloured rim
    on the lit edge (the crack's magenta or the line's gold)."""
    m = mask.astype(np.float32)
    h, w = m.shape
    ys, xs = np.nonzero(m > 0.3)
    if len(xs) == 0:
        return np.zeros((h, w, 4), np.float32)
    cx, cy = xs.mean(), ys.mean()
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    rng = np.random.default_rng(seed)
    a = rng.uniform(0, math.pi)
    split = ((gx - cx) * math.cos(a) + (gy - cy) * math.sin(a)) > 0
    face = np.where(split[..., None], np.float32(lit), np.float32(dark))
    lx, ly = light
    sh = np.float32([[1, 0, lx * 2.0], [0, 1, ly * 2.0]])
    edge = np.clip(m - cv2.warpAffine(m, sh, (w, h)), 0, 1)
    n = brush_noise((h, w), seed, scale=1.2, angle=0.6, stretch=4)
    rgb = face * (1 + 0.08 * n[..., None])
    rgb = rgb * (1 - edge[..., None]) + np.float32(rim) * edge[..., None]
    return np.dstack([np.clip(rgb, 0, 1), cv2.GaussianBlur(m, (0, 0), 0.6)]).astype(np.float32)


def haze_puff(r, seed, steps=4):
    """Alpha (2r x 2r) of a painted dust puff: lumpy, stepped values, brushy edge."""
    s = int(2 * r) + 4
    rng = np.random.default_rng(seed)
    a = np.zeros((s, s), np.float32)
    for _ in range(6):
        cx, cy = rng.uniform(0.3, 0.7) * s, rng.uniform(0.35, 0.7) * s
        rr = rng.uniform(0.18, 0.32) * s
        cv2.circle(a, (int(cx), int(cy)), int(rr), 1.0, -1)
    a = cv2.GaussianBlur(a, (0, 0), s * 0.06 + 0.5)
    n = brush_noise((s, s), seed + 3, scale=max(1.0, s / 40), angle=-0.3, stretch=4)
    a = np.clip(a * (0.8 + 0.3 * n), 0, 1)
    return np.round(a * steps) / steps * 0.6 + a * 0.4


# ------------------------------------------------------------------ sounds
SR = A.SR


def _n(dur):
    return int(round(dur * SR))


def buzzer(dur=0.42, seed=1, f=146.0):
    """Card-declined buzzer: two harsh square-ish pulses with a nasal band-pass."""
    t = A.t_axis(dur)
    sq = np.sign(np.sin(2 * np.pi * f * t)) * 0.6 + np.sign(np.sin(2 * np.pi * f * 1.5 * t)) * 0.3
    gate = ((t % 0.21) < 0.16).astype(float)
    gate = A.lowpass(gate, 120)
    x = A.bandpass(sq, 300, 3200) * gate
    return x * A.env_adsr(len(t), 0.003, 0.02, 0.9, 0.04)


def drip(seed, pitch=900.0, wet=1.0):
    """Wet drip: a fast upward-gliding resonant blip (the plop) plus a tiny splash tick."""
    n = _n(0.16)
    t = np.arange(n) / SR
    f = pitch * (1 + 1.4 * (1 - np.exp(-t / 0.018)))
    blip = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.028)
    splash = A.bandpass(A.noise(0.16, seed), 2500, 9000) * np.exp(-t / 0.006) * 0.3 * wet
    return (blip + splash) * 0.9


def printer_burst(dur, seed, rate=38.0):
    """Thermal/impact receipt printer chatter: a train of clicks over a buzzy stepper whine."""
    rng = np.random.default_rng(seed)
    n = _n(dur)
    t = np.arange(n) / SR
    x = np.zeros(n)
    k = 0.0
    while k < dur:
        i = int(k * SR)
        x[i:i + 1] += rng.uniform(0.6, 1.0)
        k += 1 / rate * rng.uniform(0.85, 1.15)
    b, a = signal.iirpeak(2600, 3, fs=SR)
    clicks = signal.lfilter(b, a, x) * 1.6 + A.bandpass(x, 4000, 9000) * 2
    whine = np.sign(np.sin(2 * np.pi * 410 * t)) * 0.06
    whine = A.bandpass(whine, 300, 2500)
    return (clicks + whine) * A.env_adsr(n, 0.004, 0.02, 1.0, 0.02)


def trolley_rattle(dur, seed):
    """Shopping-trolley wire rattle: dense metallic ticks with a rolling wobble."""
    rng = np.random.default_rng(seed)
    n = _n(dur)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for _ in range(int(dur * 70)):
        x[rng.integers(0, n)] += rng.uniform(-1, 1)
    out = 0
    for fr in (1800, 2900, 4300, 6100):
        b, a = signal.iirpeak(fr * rng.uniform(0.95, 1.05), 18, fs=SR)
        out = out + signal.lfilter(b, a, x)
    wob = 0.6 + 0.4 * np.sin(2 * np.pi * 7 * t)
    roll = A.lowpass(A.noise(dur, seed + 1), 300) * 0.4
    return (out * 0.5 * wob + roll) * A.env_adsr(n, 0.02, 0.05, 0.8, dur * 0.4)


def murmur(dur, seed=4, sigh=False):
    """Low queue murmur (band-limited babble); with sigh=True a falling collective groan."""
    x = A.crowd(dur, seed)
    x = A.lowpass(x, 900)
    if sigh:
        t = A.t_axis(dur)
        f = 220 * np.exp(-t / 0.7) + 120
        g = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.25 + A.bandpass(A.noise(dur, seed + 5, "pink"), 200, 700) * 0.6
        x = x * 0.6 + g * np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 1.5
    return x


def stone_crack(seed, size=1.0):
    """Deep stone crack: sharp crackle burst, a grinding tail and a low thud."""
    rng = np.random.default_rng(seed)
    dur = 0.9 * size + 0.3
    n = _n(dur)
    t = np.arange(n) / SR
    imp = np.zeros(n)
    k = 0
    for i in range(40):
        k += int(rng.exponential(0.006 * SR))
        if k >= n:
            break
        imp[k] = rng.uniform(-1, 1) * np.exp(-k / (0.25 * SR))
    crackle = A.bandpass(imp, 600, 6000) * 5
    grind = A.bandpass(A.noise(dur, seed + 1, "brown"), 80, 900) * np.exp(-t / (0.35 * size)) * 0.8
    thud = np.sin(2 * np.pi * np.cumsum(70 * np.exp(-t / 0.3) + 32) / SR) * np.exp(-t / 0.22) * 0.9
    return crackle + grind + thud


def rumble(dur, seed=7):
    """Rolling low rumble (brown noise, slow tremolo, sub)."""
    t = A.t_axis(dur)
    x = A.lowpass(A.noise(dur, seed, "brown"), 140, 3)
    trem = 0.7 + 0.3 * np.sin(2 * np.pi * 2.3 * t) * np.sin(2 * np.pi * 0.7 * t + 1)
    sub = np.sin(2 * np.pi * 34 * t) * 0.35
    return (x * trem + sub) / 1.4


def snap_crash(seed=11):
    """The line snapping: a whip-crack transient, a bright metallic shear, then a heavy crash."""
    dur = 2.2
    n = _n(dur)
    t = np.arange(n) / SR
    crack = A.bandpass(A.noise(dur, seed), 1500, 12000) * np.exp(-t / 0.012) * 1.6
    shear_f = 2600 * np.exp(-t / 0.25) + 700
    shear = np.sin(2 * np.pi * np.cumsum(shear_f) / SR) * np.exp(-t / 0.18) * 0.35
    shear += np.sin(2 * np.pi * np.cumsum(shear_f * 1.41) / SR) * np.exp(-t / 0.12) * 0.2
    boom = np.sin(2 * np.pi * np.cumsum(55 * np.exp(-t / 0.5) + 28) / SR) * np.exp(-t / 0.55) * 1.0
    crash = A.lowpass(A.noise(dur, seed + 2, "pink"), 2500) * np.exp(-t / 0.45) * 0.6
    return crack + shear + boom + crash


def sub_hit(seed=5, f0=48.0, dur=0.9):
    n = _n(dur)
    t = np.arange(n) / SR
    body = np.sin(2 * np.pi * np.cumsum(f0 * (1 + 0.8 * np.exp(-t / 0.05))) / SR) * np.exp(-t / (dur * 0.35))
    knock = A.lowpass(A.noise(dur, seed), 400) * np.exp(-t / 0.03) * 0.5
    return body + knock


def coin_clink(seed, f=2900.0):
    """Coin on rock: inharmonic metallic partials, short, with a gritty contact tick."""
    rng = np.random.default_rng(seed)
    dur = 0.5
    n = _n(dur)
    t = np.arange(n) / SR
    x = 0
    for ratio, amp, tau in [(1, 1.0, 0.09), (2.76, 0.6, 0.06), (5.4, 0.35, 0.035), (8.9, 0.2, 0.02)]:
        x = x + amp * np.sin(2 * np.pi * f * ratio * rng.uniform(0.98, 1.02) * t + rng.uniform(0, 6)) * np.exp(-t / tau)
    tick = A.bandpass(A.noise(dur, seed + 1), 2000, 9000) * np.exp(-t / 0.003) * 0.8
    return (x * 0.5 + tick) * A.env_adsr(n, 0.0005, 0.01, 1.0, 0.02)


def glass_crack(seed):
    rng = np.random.default_rng(seed)
    dur = 0.35
    n = _n(dur)
    t = np.arange(n) / SR
    x = np.zeros(n)
    k = 0
    for _ in range(14):
        k += int(rng.exponential(0.008 * SR))
        if k >= n:
            break
        x[k] = rng.uniform(-1, 1)
    b, a = signal.iirpeak(4800, 8, fs=SR)
    return (signal.lfilter(b, a, x) * 2 + A.bandpass(x, 3000, 11000) * 3) * np.exp(-t / 0.12)


def wind(dur, seed=21):
    t = A.t_axis(dur)
    x = A.bandpass(A.noise(dur, seed, "pink"), 250, 1400)
    g = 0.55 + 0.45 * np.sin(2 * np.pi * 0.17 * t + 1) * np.sin(2 * np.pi * 0.05 * t)
    return x * g
