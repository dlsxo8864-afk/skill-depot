"""Shot 9, Year 8: card fees. The card keeps melting onto the reader, the reader declines on "swipe",
the receipt chatters out of the till in jerks with a SWIPE FEE that keeps growing until it is longer
than the groceries (landing on "increase"), its curl runs off down the aisle, and the queue slumps.

Coordinates are key px of work/keys/y08_card_key.png (1520 x 2701); plane space = key px * 0.8.
Local helpers live in s09_year8_fx.py (shared with s10_year9)."""
import math
from functools import cached_property

import cv2
import numpy as np
from PIL import Image, ImageDraw

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera
from whatif.config import FPS, OUT_W, safe_box
from whatif.shotkit import BaseShot
from whatif.timing import Track, even_frame_of

from . import s09_year8_fx as FX
from . import s10_year9_poseb as PB

STEM = "s09_year8"
SC = L.WORK_SCALE


def _goo_card(img, depth):
    """Card and painted goo (pink core plus its dark-red rim), never the bright screen glass behind."""
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    screen = (r > 0.86) & (g < 0.21) & (b < 0.31)
    core = ((b > 0.26) & (r > 0.5) & ~screen).astype(np.uint8)
    core = cv2.morphologyEx(core, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    edge = cv2.dilate(core, np.ones((5, 5), np.uint8)).astype(bool) & (r > 1.6 * g) & ~screen
    m = (core.astype(bool) | edge).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    return m > 0


PLANES = [
    L.PlaneSpec("aisle", 0.0, 0.085, fill="full"),
    L.PlaneSpec("queue", 0.085, 0.20, radius=60),
    L.PlaneSpec("counter", 0.20, 0.45, radius=70),
    L.PlaneSpec("near", 0.45, 1.01, radius=80),
    # the hand: its red-lit rim reads as mid depth; keep all of it in one plane in front of the card
    L.PlaneSpec("hand", 0.15, 1.01, radius=60,
                region=[(0, 1000), (160, 1010), (330, 1080), (470, 1170), (560, 1280), (640, 1400), (660, 1480),
                        (640, 1520), (520, 1528), (335, 1508), (338, 1660), (300, 1720), (0, 1760)]),
]

# queue: one sprite per person (head + shoulders); boundaries between neighbours are shared lines
Q_SPRITES = {
    "q_bun": [(40, 700), (110, 640), (118, 560), (150, 495), (250, 455), (345, 478), (400, 530), (402, 600),
              (395, 660), (382, 700), (380, 760), (405, 850), (300, 870), (120, 870), (35, 820)],
    "q_beanie": [(395, 660), (440, 640), (448, 598), (510, 568), (568, 572), (572, 600), (568, 660), (580, 720),
                 (600, 850), (405, 850), (380, 760), (382, 700)],
    "q_tall": [(570, 500), (612, 482), (690, 488), (712, 520), (708, 640), (718, 700), (752, 740), (762, 850),
               (600, 850), (580, 720), (568, 660), (572, 600)],
    "q_four": [(752, 740), (742, 688), (752, 628), (798, 612), (842, 630), (848, 700), (862, 760), (880, 850),
               (762, 850)],
    "q_five": [(848, 700), (862, 676), (912, 668), (952, 690), (958, 750), (968, 850), (880, 850), (862, 760)],
}
# per person: head polygon, neck pivot, waist pivot, hair polygon (follow-through), reaction lag (frames)
Q_RIG = {
    "q_bun": {"head": [(140, 470), (350, 470), (410, 560), (400, 690), (300, 720), (150, 700), (120, 560)],
              "neck": (300, 720), "waist": (260, 980), "hair": [(150, 470), (330, 470), (360, 560), (150, 560)],
              "lag": 0, "amp": 1.0},
    "q_beanie": {"head": [(440, 570), (580, 570), (585, 700), (520, 740), (395, 740), (395, 660)],
                 "neck": (470, 745), "waist": (470, 1000), "hair": [(380, 650), (450, 650), (450, 745), (380, 745)],
                 "lag": 2, "amp": 0.9},
    "q_tall": {"head": [(575, 485), (712, 485), (712, 630), (650, 650), (580, 630)],
               "neck": (650, 650), "waist": (650, 950), "hair": [(580, 480), (712, 480), (712, 535), (580, 535)],
               "lag": 4, "amp": 0.8},
    "q_four": {"head": [(745, 610), (848, 610), (850, 715), (760, 720)], "neck": (800, 722), "waist": (800, 920),
               "hair": None, "lag": 4, "amp": 0.7},
    "q_five": {"head": [(858, 660), (958, 660), (958, 760), (862, 760)], "neck": (905, 765), "waist": (905, 900),
               "hair": None, "lag": 6, "amp": 0.6},
}

SPRITES = [L.SpriteSpec(n, 1, env, dmin=0.0, pivot=Q_RIG[n]["neck"], fill_own_plane=True) for n, env in Q_SPRITES.items()]
SPRITES.append(L.SpriteSpec("goo", 3, [(338, 1660), (342, 1560), (520, 1508), (870, 1540), (884, 1650), (850, 1800),
                                       (832, 2000), (800, 2064), (560, 2064), (522, 2000), (520, 1928), (470, 1928),
                                       (466, 1812), (400, 1810), (340, 1770)],
                            dmin=0.0, pivot=(600, 1560), mask_fn=_goo_card, fill_own_plane=True))
SPRITES.append(L.SpriteSpec("goo_front", 3, [(452, 2150), (522, 2150), (516, 2470), (458, 2470)],
                            dmin=0.0, pivot=(485, 2150), mask_fn=_goo_card, fill_own_plane=True))

# the near receipt strip: centreline from the printer mouth down over the counter to the floor
STRIP_CENTER = [(877, 1040), (915, 1120), (952, 1195), (985, 1300), (1028, 1385), (1080, 1440), (1140, 1520),
                (1180, 1610), (1205, 1720), (1222, 1850), (1238, 1975)]
STRIP_POLY = [(745, 1025), (1010, 1025), (1080, 1250), (1170, 1380), (1250, 1450), (1330, 1560), (1330, 2010),
              (1130, 2010), (1100, 1700), (1040, 1520), (920, 1440), (850, 1230)]
# the far strip snaking down the aisle (near end first)
AISLE_PATH = [(1496, 1465), (1491, 1402), (1449, 1339), (1365, 1308), (1228, 1276), (1181, 1250), (1239, 1214),
              (1344, 1198), (1391, 1166), (1365, 1130), (1260, 1109), (1144, 1088), (1118, 1056), (1155, 1025),
              (1260, 1009), (1307, 988), (1281, 972), (1207, 956), (1218, 941), (1291, 909), (1344, 888),
              (1307, 883), (1312, 862), (1360, 841)]
AISLE_POLY = [(1100, 820), (1520, 820), (1520, 1520), (1440, 1520), (1350, 1340), (1150, 1330), (1095, 1100)]

SCREEN_C = (520, 2000)
SCREEN_QUAD = [(296, 1872), (768, 1862), (806, 2082), (430, 2112)]   # TL TR BR BL (top right under the goo)            # reader screen centre (red light source)
POOL_C = (628, 2097)
POOL_POLY = [(470, 2086), (520, 2071), (600, 2076), (680, 2070), (742, 2064), (778, 2084), (762, 2110), (700, 2121),
             (620, 2119), (540, 2122), (480, 2111)]
# drip emitters on the card lip: root, length at rest, landing y, period (frames), phase, size
# the key's own painted drips, stretched and snapped on 2s: x, root y, tip y, half width, landing y, period, phase
DRIPS = [
    {"x": 387, "root": 1728, "tip": 1788, "w": 12, "land": 1902, "period": 30, "phase": 6, "sprite": "goo"},
    {"x": 428, "root": 1722, "tip": 1758, "w": 9, "land": 1915, "period": 36, "phase": 22, "sprite": "goo"},
    {"x": 496, "root": 1790, "tip": 1914, "w": 13, "land": 2074, "period": 28, "phase": 0, "sprite": "goo"},
    {"x": 532, "root": 1786, "tip": 1827, "w": 8, "land": 2076, "period": 34, "phase": 16, "sprite": "goo"},
    {"x": 779, "root": 1885, "tip": 1970, "w": 9, "land": 2046, "period": 32, "phase": 26, "sprite": "goo"},
    {"x": 811, "root": 1736, "tip": 1793, "w": 12, "land": 1955, "period": 26, "phase": 12, "sprite": "goo"},
    {"x": 485, "root": 2195, "tip": 2378, "w": 15, "land": 2585, "period": 40, "phase": 30, "sprite": "goo_front"},
]
DROPLET_BOX = (484, 1926, 516, 1994)        # the painted falling drop in the key (reused for every drop)
DROPLET_AT = (499, 1966)

# pose B (assets/key/y08_card_poseB.png): the hand jerked up and back, the card gone to strings of goo
SRC_DIR = L.LAYER_CACHE / f"{STEM}_src"
POSEB_ENV = [(0, 120), (1010, 120), (1010, 1480), (900, 1560), (890, 2000), (830, 2066), (420, 2066), (330, 1960),
             (0, 1960)]
POSEB_KEEP_A = [[(276, 1852), (788, 1842), (826, 2092), (420, 2126)]]   # the live screen stays the shot's own


def _poseb_hero(rgb, d):
    """Pose B's hero: hand, sleeve and strings by depth above the counter; goo by colour on the reader."""
    yy = np.arange(d.shape[0])[:, None]
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    screen = (r > 0.86) & (g < 0.21) & (b < 0.31)
    goo = ((r > 0.5) & (r > 1.5 * g) & (b > 0.2) & ~screen).astype(np.uint8)
    goo = cv2.morphologyEx(goo, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8)) > 0
    return ((d > 0.42) & (yy < 1760)) | (goo & (yy >= 1600))


# matching features of the hand in pose B and pose A (key px) for the in-between mesh warp; the string
# feet on the reader stay put
HAND_B = [(130, 760), (40, 1000), (200, 580), (300, 520), (390, 920), (650, 580), (450, 280), (600, 340), (300, 330)]
HAND_A = [(80, 1110), (60, 1530), (200, 1090), (400, 1130), (510, 1470), (860, 1530), (550, 890), (700, 950), (400, 940)]
HAND_ANCHORS = [(300, 1880), (380, 1850), (470, 1860), (560, 1860), (640, 1870), (700, 1880), (800, 1880), (1000, 1900),
                (1010, 150), (1010, 1100)]

INK = (0.19, 0.13, 0.25)
GROCERIES = [("MILK 2L", "3.49"), ("BREAD", "2.99"), ("EGGS 12", "4.29"), ("APPLES", "5.10")]


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def unlit(rgb):
    lum = rgb @ np.float32([0.30, 0.50, 0.20])
    return lum[..., None] * np.float32([0.50, 0.30, 0.72]) * 0.70


def red_weight(rgb, shape_off=(0, 0)):
    """How much of a surface's colour is the reader's red light, times its distance falloff."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    w = np.clip((r - np.maximum(g, b) - 0.08) / 0.45, 0, 1)
    h, wd = rgb.shape[:2]
    gy, gx = np.mgrid[0:h, 0:wd].astype(np.float32)
    gx += shape_off[0]
    gy += shape_off[1]
    cx, cy = SCREEN_C[0] * SC, SCREEN_C[1] * SC
    prox = np.exp(-(((gx - cx) / (520 * SC)) ** 2 + ((gy - cy) / (470 * SC)) ** 2))
    return cv2.GaussianBlur((w * np.clip(prox * 1.4, 0, 1)).astype(np.float32), (0, 0), 2)


def slump(t, t0):
    """A slump on held drawings: anticipation lift, drop with overshoot, settle."""
    return Track([(t0, 0.0), (t0 + 2 / FPS, -0.3, "inout"), (t0 + 4 / FPS, 1.15, "out"), (t0 + 8 / FPS, 0.93, "inout"),
                  (t0 + 12 / FPS, 1.0, "inout")])(t)


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        self.key_path = key
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        f = lambda w, n=0: ctx.f(w, n)
        self.f_pay, self.f_two, self.f_each = f("pay"), f("two"), f("each")
        self.f_swipe = f("swipe")
        self.f_youd, self.f_cover, self.f_inc = f("You'd"), f("cover"), f("increase")
        self.f_decl = self.f_swipe                      # the reader declines on "swipe"
        # on 2s: held A, the hand presses the card down (anticipation), one in-between drawing, held B
        self.f_ant, self.f_smear, self.f_b = self.f_decl, self.f_decl + 2, self.f_decl + 4
        PB.build_pose_b(key, depth, SRC_DIR, "y08_card_poseB.png", POSEB_ENV, hero_fn=_poseb_hero,
                        exclude=POSEB_KEEP_A, a_mask=self._a_hero_mask(), name="poseB", grow_a=15, feather_a=4.0)
        t_of = lambda fr: (fr - self.f0) / FPS
        self.shake = FX.Shake([(t_of(self.f_inc), 12.0, 6.5, 0.16, 0.45),
                               (t_of(self.f_inc + 8), 4.0, 7.5, 0.10, 0.1)])
        foc = Track([(0, (W * 0.44, H * 0.485)), (t_of(self.f_decl), (W * 0.47, H * 0.475), "inout"),
                     (t_of(self.f_youd), (W * 0.47, H * 0.452), "inout"), (t_of(self.f_inc + 8), (W * 0.445, H * 0.447), "inout"),
                     (d, (W * 0.445, H * 0.447), "inout")])     # hand and receipt both stay in frame
        self.cam = ParallaxCamera(
            W, H, focus=lambda t: tuple(float(a + b) for a, b in zip(foc(t), self.shake(t)[:2])), nearness=nearness,
            zoom=Track([(0, 1.06), (t_of(self.f_decl), 1.10, "inout"), (t_of(self.f_youd), 1.16, "inout"),
                        (t_of(self.f_inc + 8), 1.26, "inout"), (d, 1.29, "inout")]),
            push=Track([(0, 0.0), (d, 0.06, "inout")]),
            rise=Track([(0, 0.0), (d, -16.0, "inout")]),
            roll=lambda t: float(self.shake(t)[2]))
        self._build_feed()

    # ------------------------------------------------------------ timing tables
    def _build_feed(self):
        """Paper fed (canvas units) per drawing: jerks on 2s with pauses. Each burst feeds until its lines
        have cleared the mouth."""
        self.print_canvas
        g_end = self.lines_P["groceries"][1]
        fb = self.fee_blocks
        val0 = 26.0
        plan = []                                                     # (frames, target)
        gro = [fr for k, fr in enumerate(range(self.f_pay, self.f_swipe - 6, 2)) if k % 3 != 2]
        plan.append((gro, g_end + 6))
        plan.append(([self.f_b + 2 * i for i in range(4)], fb[0][1] + 6))   # after the recoil: the till holds still
        plan.append(([self.f_youd + 2 * i for i in range(3)], fb[1][1] + 6))
        plan.append(([self.f_cover + 2 * i for i in range(4)], fb[2][1] + 6))
        plan.append(([self.f_inc + 2 * i for i in range(8)], fb[3][1] + 10))
        moves, val = [], val0
        for frs, target in plan:
            n = len(frs)
            w = np.linspace(1.25, 0.75, n)                             # each burst starts fast, eases out
            w = w / w.sum() * (target - val)
            for fr, st in zip(frs, w):
                moves.append((fr, float(st)))
            val = target
        mv = dict()
        for fr, st in moves:
            mv[fr] = mv.get(fr, 0) + st
        self.feed_moves = sorted(mv.items())
        F = {}
        val = val0
        for fr in range(self.f0 - self.f0 % 2 - 2, self.f1 + 2, 2):
            val += mv.get(fr, 0.0)
            F[fr] = val
        self.F = F
        self.bumps = [self.f_pay, self.f_b, self.f_youd + 4, self.f_inc]

    def feed(self, f):
        return self.F.get(f - f % 2, list(self.F.values())[-1])

    # ------------------------------------------------------------ prepared
    @cached_property
    def key(self):
        k = cv2.cvtColor(cv2.imread(str(self.key_path)), cv2.COLOR_BGR2RGB)
        return cv2.resize(k, (self.lay.W, self.lay.H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255

    @cached_property
    def planes(self):
        out = []
        for i, p in enumerate(self.lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            pl = {"rgb": rgb, "a": p["a"].astype(np.float32) / 255, "n": nearness(p["d"].astype(np.float32) / 65535)}
            if i >= 2:
                pl["rw"] = red_weight(rgb)[..., None]
                pl["un"] = unlit(rgb)
            out.append(pl)
        return out

    @cached_property
    def sprites(self):
        res = {}
        for s in self.lay.sprites:
            rgba = s["rgba"].astype(np.float32) / 255
            x0, y0, x1, y1 = s["bbox"]
            d = {"rgba": rgba, "x0": x0, "y0": y0, "plane": s["plane"]}
            if s["name"] in Q_RIG:
                rig = Q_RIG[s["name"]]
                shp = rgba.shape[:2]
                sc = lambda pts: [(x * SC, y * SC) for x, y in pts]
                d["w_head"] = FX.poly_weight(shp, sc(rig["head"]), 9, (x0, y0))
                # shoulders: everything above the waist, fading out toward it
                gy = np.arange(shp[0], dtype=np.float32)[:, None] + y0
                ny, wy = rig["neck"][1] * SC, rig["waist"][1] * SC
                ramp = np.clip((wy - gy) / (wy - ny), 0, 1) ** 1.3 * np.ones(shp, np.float32)
                d["w_body"] = np.clip(ramp - d["w_head"] * 0.0, 0, 1)
                d["w_hair"] = FX.poly_weight(shp, sc(rig["hair"]), 7, (x0, y0)) if rig["hair"] else None
            if s["name"] in ("goo", "goo_front"):
                d["rw"] = red_weight(rgba[..., :3], (x0, y0))[..., None]
                d["un"] = unlit(rgba[..., :3])
            res[s["name"]] = d
        return res

    # ---- reader screen
    @cached_property
    def screen(self):
        k = self.key
        r, g, b = k[..., 0], k[..., 1], k[..., 2]
        quad = np.float32(SCREEN_QUAD) * SC
        inq = L.poly_mask(k.shape[:2], [tuple(p) for p in quad]) > 0.5
        # the whole glass: the painted drips over it are redrawn by the goo sprite, so the picture must run under them
        m = (((r > 0.80) & (g < 0.30) & (b < 0.36)) | cv2.erode(inq.astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool))
        m = (m & inq).astype(np.uint8)
        # where the new screen picture shows: the bright red glass, softened, not the goo over it
        soft = cv2.GaussianBlur(cv2.dilate(m, np.ones((3, 3), np.uint8)).astype(np.float32), (0, 0), 1.2)
        ys, xs = np.nonzero(soft > 0.01)
        bb = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
        tex = k[bb[1]:bb[3], bb[0]:bb[2]].mean(2)
        tex = tex / max(float(tex[m[bb[1]:bb[3], bb[0]:bb[2]] > 0].mean()), 1e-3)
        CW, CH = 520, 300
        Hm = cv2.getPerspectiveTransform(np.float32([[0, 0], [CW, 0], [CW, CH], [0, CH]]),
                                         quad - np.float32([bb[0], bb[1]]))
        return {"quad": quad, "bbox": bb, "mask": soft[bb[1]:bb[3], bb[0]:bb[2]], "tex": tex, "H": Hm, "CW": CW, "CH": CH}

    @cached_property
    def declined_alpha(self):
        CW, CH = self.screen["CW"], self.screen["CH"]
        fnt = T.font("display", 96)
        im = Image.new("L", (CW, CH), 0)
        # final cut: no "DECLINED" text is drawn at all (director); only the reader's status bar remains
        a = np.asarray(im, np.float32) / 255
        a = T.rough_alpha(a, 33, 0.8)
        bar = np.zeros_like(a)
        cv2.rectangle(bar, (int(CW * 0.12), int(CH * 0.84)), (int(CW * 0.66), int(CH * 0.875)), 1.0, -1)
        return np.clip(a + T.rough_alpha(bar, 34, 1.0) * 0.8, 0, 1)

    def screen_state(self, f):
        """(light ratio, text level, dots) of the reader at frame f, on 2s."""
        fh = f - f % 2
        d = fh - self.f_decl
        if d < 0:
            dots = (fh // 4) % 3
            return 0.62 + 0.04 * ((fh // 2) % 2), 0.0, dots
        if d > 16 and (fh - self.f_inc < 0 or fh - self.f_inc > 4):
            return 1.0 + 0.08 * (((d // 2) % 4) == 0), 0.0, None          # settles to a steady red glow
        seq = {0: (1.75, 1.0), 2: (1.0, 0.5), 4: (1.55, 1.0), 6: (0.85, 0.35), 8: (1.4, 1.0)}
        if d in seq:
            return seq[d][0], seq[d][1], None
        di = fh - self.f_inc
        if 0 <= di <= 4:
            return {0: 1.7, 2: 1.05, 4: 1.45}[di], 1.0, None
        on = ((d // 2) % 4) != 3                     # DECLINED blinks: three drawings on, one off
        return (1.12 if on else 0.80), (1.0 if on else 0.25), None

    def screen_canvas(self, f):
        CW, CH = self.screen["CW"], self.screen["CH"]
        ratio, txt, dots = self.screen_state(f)
        base = np.float32([0.96, 0.13, 0.22])
        hot = np.clip(ratio - 1.0, 0, 1)
        col = np.clip(base * min(ratio, 1.0) + np.float32([0.04, 0.30, 0.22]) * hot * 0.8, 0, 1)
        cv = np.ones((CH, CW, 3), np.float32) * col
        yy = np.linspace(-1, 1, CH, dtype=np.float32)[:, None, None]
        cv *= (1.0 - 0.10 * yy)                                   # glass a touch brighter at the top
        if dots is not None:
            for k in range(3):
                c = (int(CW * (0.38 + 0.12 * k)), int(CH * 0.5))
                lvl = 1.0 if k == dots else 0.45
                cv2.circle(cv, c, 13, tuple(float(v) for v in np.clip(col * 0.4 + np.float32([0.55, 0.40, 0.40]) * lvl, 0, 1)), -1,
                           cv2.LINE_AA)
        if False:
            a = self.declined_alpha[..., None] * txt
            ink = np.float32([1.0, 0.90, 0.86]) if ratio >= 1.0 else np.float32([0.98, 0.62, 0.60])
            glow = cv2.GaussianBlur(self.declined_alpha, (0, 0), 6)[..., None] * txt * 0.5
            cv = 1 - (1 - cv) * (1 - glow * np.float32([1.0, 0.55, 0.5]))
            cv = cv * (1 - a) + ink * a
        return cv, ratio

    # ---- receipt (near strip): paper mask and strip coordinates
    @cached_property
    def receipt(self):
        k = self.key
        H, W = k.shape[:2]
        poly = L.poly_mask((H, W), [(x * SC, y * SC) for x, y in STRIP_POLY]) > 0.5
        lum = k.mean(2)
        sat = k.max(2) - k.min(2)
        paper = (lum > 0.40) & (sat < 0.26) & poly
        paper = cv2.morphologyEx(paper.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
        paper = cv2.morphologyEx(paper, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, stats, _ = cv2.connectedComponentsWithStats(paper)
        i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        paper = (lab == i).astype(np.uint8)
        # fill holes (painted shading inside the strip)
        cnts, _ = cv2.findContours(paper, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        full = np.zeros_like(paper)
        cv2.drawContours(full, cnts, -1, 1, -1)
        full = cv2.erode(full, np.ones((3, 3), np.uint8))
        ys, xs = np.nonzero(full)
        bb = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
        m = full[bb[1]:bb[3], bb[0]:bb[2]].astype(np.float32)
        # project every pixel on the centreline: arc length s and signed side distance d
        C = np.float32(STRIP_CENTER) * SC
        gy, gx = np.mgrid[bb[1]:bb[3], bb[0]:bb[2]].astype(np.float32)
        best = np.full(gx.shape, 1e9, np.float32)
        S = np.zeros_like(gx)
        D = np.zeros_like(gx)
        s_acc = 0.0
        for a, b2 in zip(C[:-1], C[1:]):
            dv = b2 - a
            ln = float(np.linalg.norm(dv))
            e = dv / ln
            u = np.clip(((gx - a[0]) * e[0] + (gy - a[1]) * e[1]) / ln, 0, 1)
            px, py = a[0] + dv[0] * u, a[1] + dv[1] * u
            dist = np.hypot(gx - px, gy - py)
            side = np.sign(e[0] * (gy - a[1]) - e[1] * (gx - a[0]))      # + = right of travel (screen left)
            sel = dist < best
            best = np.where(sel, dist, best)
            S = np.where(sel, s_acc + u * ln, S)
            D = np.where(sel, side * dist, D)
            s_acc += ln
        # per-s strip extent from the mask -> v in [0, 1] across the strip, u along it in strip widths
        nb = int(s_acc // 6) + 1
        sb = np.clip((S // 6).astype(int), 0, nb - 1)
        lo = np.full(nb, np.nan, np.float32)
        hi = np.full(nb, np.nan, np.float32)
        inside = m > 0.5
        for j in range(nb):
            sel = inside & (sb == j)
            if sel.sum() > 3:
                dd = D[sel]
                lo[j], hi[j] = np.percentile(dd, 2), np.percentile(dd, 98)
        idx = np.arange(nb)
        ok = ~np.isnan(lo)
        lo = np.interp(idx, idx[ok], lo[ok])
        hi = np.interp(idx, idx[ok], hi[ok])
        lo = cv2.GaussianBlur(lo[None, :], (0, 0), 2.5)[0]
        hi = cv2.GaussianBlur(hi[None, :], (0, 0), 2.5)[0]
        width = np.maximum(hi - lo, 4)
        Sx = S / 6.0
        lo_p = np.interp(Sx, idx, lo)
        wd_p = np.interp(Sx, idx, width)
        V = np.clip((D - lo_p) / wd_p, -0.2, 1.2)
        # u: integral of ds / width, in units where the strip is 200 wide
        U_tab = np.concatenate([[0], np.cumsum(6.0 / width[:-1])]) * 200.0
        U = np.interp(Sx, idx, U_tab)
        # the mouth: paper above the slot lip is inside the printer
        edge = cv2.GaussianBlur(m, (0, 0), 1.0)
        low = np.clip((1640 * SC - gy) / 50.0, 0, 1)               # where it twists to the floor: no print
        return {"bbox": bb, "m": edge, "U": U.astype(np.float32), "V": V.astype(np.float32),
                "flip": 1.0, "low": low.astype(np.float32)}

    @cached_property
    def print_canvas(self):
        """The receipt in paper-index space: 200 units across, 2 px per unit. Row = paper index P; a higher P
        was printed later and sits nearer the printer mouth (higher on screen). Few, big lines: groceries,
        then SWIPE FEE lines whose amounts keep growing until the fees are longer than the groceries."""
        Wc, S = 200, 2
        P0, P1 = -60, 980
        im = Image.new("L", (Wc * S, (P1 - P0) * S), 0)
        dr = ImageDraw.Draw(im)
        self._p0 = P0

        def text(s_, x, p, size, kind="sans", weight=700, anchor="l", fit=None, height=None):
            """Lay a line at paper index p. fit: max width (units) the line may take; height: stretch the
            glyphs to this many units tall (narrow paper, tall thermal print)."""
            fnt = T.sans(int(size * S), weight) if kind == "sans" else T.font("display", int(size * S))
            tw, th, ox, oy = T.text_size(fnt, s_)
            tile = Image.new("L", (tw + 8, th + 8), 0)
            ImageDraw.Draw(tile).text((4 - ox, 4 - oy), s_, font=fnt, fill=255)
            if fit is not None and tile.width > fit * S:
                tile = tile.resize((int(fit * S), tile.height), Image.LANCZOS)
            if height is not None:
                tile = tile.resize((tile.width, int(height * S)), Image.LANCZOS)
            # the paper hangs toward us, so each line is laid in rotated 180 degrees to read upright on screen
            tile = tile.rotate(180)
            xr = Wc - x
            xx = xr * S - tile.width + 8 if anchor == "l" else xr * S - 8 if anchor == "r" else xr * S - tile.width / 2
            im.paste(255, (int(xx), int((p - P0) * S)), tile)
            return tile.height / S

        text("* CORNER MARKET *", 100, 4, 17, anchor="c", weight=780, fit=180)
        p = 32
        for item, price in GROCERIES:
            text(item, 14, p, 21, weight=700)
            text(price, 182, p, 21, weight=700, anchor="r")
            p += 29
        for x in range(12, 190, 10):
            dr.rectangle([x * S, (p + 2 - P0) * S, (x + 5) * S, (p + 4 - P0) * S], fill=255)
        text("SUBTOTAL", 14, p + 10, 21, weight=820)
        text("15.87", 182, p + 10, 21, weight=820, anchor="r")
        p += 40
        self.lines_P = {"groceries": (32, p)}
        # the fee, reprinted bigger every time: amount first, then its label (the label reads above it)
        blocks = []
        for amount, h_amt, h_lab in (("+$0.32", 44, 40), ("+$1.90", 66, 42), ("+$4.75", 96, 46), ("+$9.50", 170, 54)):
            p += 22
            start = p
            h = text(amount, 100, p, 60, kind="display", anchor="c", fit=184, height=h_amt)
            p += h + 4
            h = text("SWIPE FEE", 100, p, 60, kind="display", anchor="c", fit=180, height=h_lab)
            p += h
            blocks.append((start, p))
        self.fee_blocks = blocks
        self.lines_P["fee"] = (blocks[0][0], p)
        a = np.asarray(im, np.float32) / 255
        a = T.rough_alpha(a, 61, 0.6)
        # thermal print: slightly uneven density across the head
        n = L.brush_noise(a.shape, 62, scale=2.0, angle=0.0, stretch=10)
        return np.clip(a * (0.86 + 0.10 * n), 0, 1)

    # ---- the far strip on the aisle floor (curl that runs off down the aisle)
    @cached_property
    def aisle(self):
        k = self.key
        H, W = k.shape[:2]
        poly = L.poly_mask((H, W), [(x * SC, y * SC) for x, y in AISLE_POLY]) > 0.5
        lum = k.mean(2)
        sat = k.max(2) - k.min(2)
        paper = (lum > 0.40) & (sat < 0.30) & poly
        paper = cv2.morphologyEx(paper.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        ys, xs = np.nonzero(paper)
        pad = 24
        bb = (max(xs.min() - pad, 0), max(ys.min() - pad, 0), min(xs.max() + pad, W), min(ys.max() + pad, H))
        x0, y0, x1, y1 = bb
        pm = cv2.GaussianBlur(paper[y0:y1, x0:x1].astype(np.float32), (0, 0), 0.8)
        grow = cv2.dilate((pm > 0.05).astype(np.uint8), np.ones((7, 7), np.uint8))
        out = {"bbox": bb, "pm": pm}
        dep = cv2.resize(cv2.imread(str(self.key_path).replace(".png", "_depth.png"), -1).astype(np.float32) / 65535,
                         (W, H), interpolation=cv2.INTER_AREA)[y0:y1, x0:x1]
        out["own"] = [(dep < 0.085).astype(np.float32), (dep >= 0.085).astype(np.float32)]
        out["floor"] = []
        for i in (0, 1):
            src = self.planes[i]["rgb"][y0:y1, x0:x1]
            out["floor"].append(L.textured_fill(src, grow == 0, seed=70 + i, amp_scale=0.7))
        path = np.float32(AISLE_PATH) * SC
        seg = np.linalg.norm(np.diff(path, axis=0), axis=1)
        out["path"], out["cum"] = path, np.concatenate([[0], np.cumsum(seg)])
        return out

    def curl_fields(self, f):
        """Lift (px, negative = up) for the aisle paper from every travelling curl at frame f (on 2s)."""
        A_ = self.aisle
        x0, y0, x1, y1 = A_["bbox"]
        fh = f - f % 2
        h, w = y1 - y0, x1 - x0
        lift = np.zeros((h, w), np.float32)
        gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
        total = A_["cum"][-1]
        for fb in self.bumps:
            d = fh - fb
            if d < 0 or d > 26:
                continue
            u = d / 26.0
            s = total * (u ** 0.8)
            j = int(np.searchsorted(A_["cum"], s) - 1)
            j = min(max(j, 0), len(A_["path"]) - 2)
            fr = (s - A_["cum"][j]) / max(A_["cum"][j + 1] - A_["cum"][j], 1e-3)
            c = A_["path"][j] * (1 - fr) + A_["path"][j + 1] * fr
            persp = np.clip((c[1] - 820 * SC) / (650 * SC), 0.15, 1.0)        # nearer = bigger
            amp = 14.0 * persp * (1 - 0.55 * u)
            rad = 70.0 * SC * (0.4 + 0.6 * persp)
            lift -= amp * np.exp(-((gx - c[0]) ** 2 + (gy - c[1]) ** 2) / (2 * rad ** 2))
        return lift

    def _aisle_into(self, rgb, i, f):
        A_ = self.aisle
        lift = self.curl_fields(f)
        if np.abs(lift).max() < 0.3:
            return
        x0, y0, x1, y1 = A_["bbox"]
        own = A_["own"][i]
        pm = A_["pm"] * own
        if pm.max() < 0.05:
            return
        reg = rgb[y0:y1, x0:x1]
        paper = np.dstack([self.planes[i]["rgb"][y0:y1, x0:x1], pm])
        h, w = lift.shape
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        warped = cv2.remap(paper, gx, gy - lift, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
        # the raised paper catches more of the ceiling light and throws a soft shadow where it lay
        k = np.clip(-lift / 10.0, 0, 1)
        kw = cv2.remap(k, gx, gy - lift, cv2.INTER_LINEAR)
        warped[..., :3] = np.clip(warped[..., :3] * (1 + 0.16 * kw[..., None]) + 0.03 * kw[..., None], 0, 1)
        base = reg * (1 - pm[..., None]) + A_["floor"][i] * pm[..., None]
        shadow = cv2.GaussianBlur(pm * k, (0, 0), 3) * 0.45
        base = base * (1 - shadow[..., None]) + np.float32([0.06, 0.05, 0.14]) * shadow[..., None]
        a = warped[..., 3:4]
        rgb[y0:y1, x0:x1] = base * (1 - a) + warped[..., :3] * a

    # ---- drips
    def drip_state(self, e, f):
        """One painted drip at frame f (on 2s): stretch S (key px), falling drop (y, v) or splat."""
        fh = f - f % 2
        P = e["period"]
        grow_n = int(P * 0.6) // 2 * 2
        ph = (fh - self.f0 + e["phase"]) % P
        ph -= ph % 2
        Smax = 0.55 * (e["tip"] - e["root"]) + 26
        out = {"S": 0.0, "drop": None, "splat": None, "Smax": Smax}
        if e["sprite"] == "goo" and fh >= self.f_smear and fh - ph + grow_n >= self.f_smear:
            return out                                                # the card is gone: no new drops
        if ph < grow_n:
            u = ph / grow_n
            out["S"] = Smax * u ** 1.7                                # slow ooze, then the neck lets go
            return out
        d = ph - grow_n
        out["S"] = Smax * {0: 0.30, 2: -0.10, 4: 0.05}.get(d, 0.0)   # recoil past rest, settle
        y0 = e["tip"] + Smax
        g, v0 = 2.6, 5.0
        y = y0 + v0 * d + 0.5 * g * d * d
        if y < e["land"]:
            out["drop"] = (y, v0 + g * d)
        else:
            t_land = (-v0 + math.sqrt(v0 * v0 + 2 * g * (e["land"] - y0))) / g
            dl = d - int(math.ceil(t_land / 2) * 2)
            if 0 <= dl <= 2:
                out["splat"] = dl
        return out

    def first_drop(self, f):
        """The drop already in the air in the key falls into the pool in the first drawings."""
        d = (f - f % 2) - (self.f0 - self.f0 % 2)
        y = DROPLET_AT[1] + 6 * d + 0.5 * 2.6 * d * d
        if y < 2074:
            return {"drop": (y, 6 + 2.6 * d), "splat": None}
        return {"drop": None, "splat": 0 if y < 2074 + 40 else None}

    @cached_property
    def landings(self):
        ev = []
        for j, e in enumerate(DRIPS):
            for f in range(self.f0 - self.f0 % 2, self.f1, 2):
                if self.drip_state(e, f)["splat"] == 0:
                    ev.append((f, j))
        return ev

    @cached_property
    def droplet(self):
        x0, y0, x1, y1 = [int(v * SC) for v in DROPLET_BOX]
        k = self.key[y0:y1, x0:x1]
        m = _goo_card(k, None).astype(np.float32)
        m = cv2.GaussianBlur(m, (0, 0), 0.7)
        return np.dstack([k, m]).astype(np.float32)

    def _drops_into(self, rgb, f, ratio):
        """Falling drops (the key's painted droplet, stretched by speed: a drawn smear) and splats."""
        dl = self.droplet
        h0, w0 = dl.shape[:2]
        items = []
        for e in DRIPS:
            s = self.drip_state(e, f)
            items.append((e, s, e["w"] / 8.5))
        fd = self.first_drop(f)
        items.append(({"x": DROPLET_AT[0], "land": 2074}, fd, 1.5))
        for e, s, k in items:
            if s["drop"] is not None:
                y, v = s["drop"]
                sx, sy = k, k * (1 + 0.035 * v)
                anchor_y = 0.85                                  # the round head leads, the tail trails up
            elif s["splat"] is not None:
                y = e["land"]
                sx, sy = k * (2.0 if s["splat"] == 0 else 2.6), k * (0.40 if s["splat"] == 0 else 0.18)
                anchor_y = 0.9
            else:
                continue
            nw, nh = max(int(w0 * sx), 2), max(int(h0 * sy), 2)
            spr = cv2.resize(dl, (nw, nh), interpolation=cv2.INTER_AREA if sy < 1 else cv2.INTER_LINEAR)
            if s["splat"] == 2:
                spr[..., 3] *= 0.6
            spr[..., :3] = np.clip(spr[..., :3] * (0.8 + 0.2 * min(ratio, 1.6)), 0, 1)
            x = int(e["x"] * SC - nw / 2)
            yy = int(y * SC - nh * anchor_y)
            FX.over_patch(rgb, spr, x, yy)

    def _stretch(self, rgba, x0, y0, f, which):
        """The card keeps melting: a slow overall sag plus each drip oozing longer and snapping back."""
        fh = f - f % 2
        u = (fh - self.f0) / max(self.f1 - self.f0, 1)
        h, w = rgba.shape[:2]
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        xk, yk = (gx + x0) / SC, (gy + y0) / SC
        dy = np.zeros((h, w), np.float32)
        if which == "goo":
            ramp = np.clip((yk - 1600) / 190, 0, 1) ** 1.5
            prof = 0.75 + 0.35 * np.sin((xk - 340) / 520 * math.pi)
            dy += (2.0 + 8.0 * u) * ramp * prof
            if self.f_ant <= f < self.f_smear:                          # pressed with the hand, drip feet hold
                dy += 10.0 * np.clip((1890 - yk) / 260, 0, 1)
        for e in DRIPS:
            if e["sprite"] != which:
                continue
            S = self.drip_state(e, f)["S"]
            if abs(S) < 0.2:
                continue
            bx = np.clip(1 - ((xk - e["x"]) / (1.6 * e["w"])) ** 2, 0, 1) ** 2
            t_ = np.clip((yk - e["root"]) / max(e["tip"] - e["root"], 1), 0, 1)
            dy += S * bx * (t_ * t_ * (3 - 2 * t_))
        if np.abs(dy).max() < 0.05:
            return rgba
        return cv2.remap(rgba, gx, gy - dy * SC, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)

    @cached_property
    def pool_src(self):
        """The key's own painted pool (soft-edged), as a patch in the goo layer's frame."""
        x0, y0 = int(300 * SC), int(1640 * SC)
        x1, y1 = int(900 * SC), int(2640 * SC)
        k = self.key[y0:y1, x0:x1]
        env = FX.poly_weight(k.shape[:2], [(x * SC, y * SC) for x, y in POOL_POLY], 2.0, (x0, y0))
        return np.dstack([k, env]).astype(np.float32)

    def pool_grow(self, f):
        fh = f - f % 2
        n_landed = sum(1 for fl, j in self.landings if fl <= fh and DRIPS[j]["land"] > 2040 and j != 6)
        n_landed += 1 if fh >= self.f0 + 8 else 0                       # the first drop
        return 1 - math.exp(-0.16 * n_landed) + 0.25 * (fh - self.f0) / max(self.f1 - self.f0, 1)

    def _pool(self, grow):
        """Scale the painted pool about its back edge: it spreads forward and sideways, lobes uneven."""
        src = self.pool_src
        h, w = src.shape[:2]
        x0, y0 = int(300 * SC), int(1640 * SC)
        cx, cy = POOL_C[0] * SC - x0, (POOL_C[1] - 18) * SC - y0
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        sx, sy = 1 + 0.55 * grow, 1 + 1.25 * grow
        ang = np.arctan2(gy - cy, gx - cx)
        lobe = 1 + 0.08 * grow * np.sin(3 * ang + 1.0) + 0.05 * grow * np.sin(5 * ang + 2.0)
        mx = cx + (gx - cx) / (sx * lobe)
        my = cy + (gy - cy) / (sy * lobe)
        out = cv2.remap(src, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
        return out

    # ------------------------------------------------------------ pose B (the recoil)
    def _a_hero_mask(self):
        """Key-px mask of everything pose A's hand and card occupy (hand plane + goo sprite)."""
        SRC_DIR.mkdir(parents=True, exist_ok=True)
        if (SRC_DIR / "poseB.npz").exists():
            return None
        W, H = self.lay.W, self.lay.H
        m = (self.lay.planes[4]["a"] > 127).astype(np.uint8)
        for s in self.lay.sprites:
            if s["name"] == "goo":
                x0, y0, x1, y1 = s["bbox"]
                m[y0:y1, x0:x1] |= (s["rgba"][..., 3] > 127).astype(np.uint8)
        k = cv2.imread(str(self.key_path))
        return cv2.resize(m, (k.shape[1], k.shape[0]), interpolation=cv2.INTER_NEAREST) > 0

    @cached_property
    def pose_b(self):
        z = np.load(SRC_DIR / "poseB.npz")
        W, H = self.lay.W, self.lay.H
        rgb = cv2.resize(z["rgb"], (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        al = cv2.resize(z["alpha"], (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        he = cv2.resize(z["hero"], (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        dep = cv2.resize(z["dep"], (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 65535
        ys, xs = np.nonzero(al > 0.004)
        x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
        crop = rgb[y0:y1, x0:x1]
        shp = crop.shape[:2]
        gy = np.arange(shp[0], dtype=np.float32)[:, None] + y0
        u = np.clip((gy / SC - 1080) / (1880 - 1080), 0, 1)
        w_hand = (1 - u * u * (3 - 2 * u)) * np.ones(shp, np.float32)          # hand moves, strings follow less
        w_str = (np.sin(math.pi * u) * (u > 0)) * np.ones(shp, np.float32)       # strings sway most mid-way
        hand_only = he[y0:y1, x0:x1] * np.clip((1150 * SC - gy) / (60 * SC), 0, 1)
        hy, hx = np.nonzero(hand_only > 0.5)
        ma = self.planes[4]["a"] > 0.5
        ay, ax = np.nonzero(ma)
        d = (ax.mean() - (hx.mean() + x0), ay.mean() - (hy.mean() + y0))
        # one smooth nearness for the hand plane (a hard depth edge inside a plane folds under the camera)
        hm = he > 0.5
        nh = nearness(dep)
        n4 = cv2.GaussianBlur(np.where(hm, nh, float(nh[hm].mean())).astype(np.float32), (0, 0), 30)
        return {"rgba": np.dstack([crop, al[y0:y1, x0:x1]]).astype(np.float32), "hand": hand_only.astype(np.float32),
                "x0": int(x0), "y0": int(y0), "n": n4, "d": d, "un": unlit(crop),
                "hero": he[y0:y1, x0:x1].astype(np.float32),
                "rw": red_weight(crop, (x0, y0))[..., None], "w_hand": w_hand, "w_str": w_str}

    def _pose_b_src(self, ratio):
        pb = self.pose_b
        src = pb["rgba"].copy()
        src[..., :3] = pb["un"] + (src[..., :3] - pb["un"]) * (1 + (ratio - 1) * pb["rw"])
        return src

    def _pose_b_bg_into(self, rgb, a, ratio):
        """Pose B's own paint of the counter where pose A's hand and card were (static, on the near plane)."""
        pb = self.pose_b
        bg = self._pose_b_src(ratio)
        bg[..., 3] *= 1 - pb["hero"]
        FX.over_patch(rgb, bg, pb["x0"], pb["y0"], a)

    def _pose_b_plane(self, f, ratio):
        """The hand plane after the recoil: pose B's hand and strings (relit by the reader) with a pop,
        tremble and string sway."""
        pb = self.pose_b
        W, H = self.lay.W, self.lay.H
        fh = f - f % 2
        src = self._pose_b_src(ratio)
        src[..., 3] = pb["hero"]
        x0, y0 = pb["x0"], pb["y0"]
        rgb = np.zeros((H, W, 3), np.float32)
        a = np.zeros((H, W), np.float32)
        hh, ww = src.shape[:2]
        rgb[y0:y0 + hh, x0:x0 + ww] = src[..., :3]                    # straight (not premultiplied) colour
        if self.f_smear <= f < self.f_b:
            # the in-between drawing: pose B's hand mesh-warped halfway back toward where pose A held the card
            # (strings stretched between it and the reader; one opaque drawing on 2s, no cross-fade)
            sc = lambda pts: [(x * SC, y * SC) for x, y in pts]
            mid = [((xa + xb) / 2, (ya + yb) / 2) for (xa, ya), (xb, yb) in zip(HAND_A, HAND_B)]
            st = PB.mesh_warp(src, x0, y0, sc(HAND_B), sc(mid), sc(HAND_ANCHORS))
            FX.over_patch(rgb, st, x0, y0, a)
            return rgb, a
        d = fh - (self.f_b - self.f_b % 2)
        pop = {0: -14.0, 2: 6.0, 4: -2.0}.get(d, 0.0) * SC                 # overshoot up, settle on 2s
        trem = math.sin(fh * 2.3) * 0.9 + (1.5 if d == 0 else 0.0)
        sway = math.sin(2 * math.pi * (fh - self.f_b) / 26.0) * 5.0 * SC
        hand = {"angle": trem, "dx": 0.0, "dy": pop, "pivot": (60 * SC, 820 * SC), "w": pb["w_hand"]}
        strs = {"angle": 0.0, "dx": sway, "dy": 0.0, "pivot": (0.0, 0.0), "w": pb["w_str"]}
        patch = FX.part_warp(src, x0, y0, [hand, strs])
        FX.over_patch(rgb, patch, x0, y0, a)
        return rgb, a

    # ------------------------------------------------------------ poses
    def q_pose(self, name, f):
        rig = Q_RIG[name]
        fh = f - f % 2
        t = (fh - self.f0) / FPS
        lag = rig["lag"] / FPS
        amp = rig["amp"]
        ph = {"q_bun": 0.0, "q_beanie": 1.7, "q_tall": 3.1, "q_four": 4.4, "q_five": 5.2}[name]
        sway = math.sin(2 * math.pi * t / 2.4 + ph)
        sway_late = math.sin(2 * math.pi * (t - 4 / FPS) / 2.4 + ph)
        td = (self.f_b + 2 - self.f0) / FPS + lag
        ti = (self.f_inc + 2 - self.f0) / FPS + lag
        sh = slump(t, td) + slump(t, ti)                         # two clear steps; shoulders lead
        hd = slump(t, td + 2 / FPS) + slump(t, ti + 2 / FPS)     # head follows two frames later
        hr = slump(t, td + 4 / FPS) + slump(t, ti + 4 / FPS)     # hair settles last
        sc = SC * amp
        body = {"angle": 0.5 * sway + 3.4 * sh, "dx": 1.6 * sway * sc, "dy": 24.0 * sh * sc,
                "pivot": (rig["waist"][0] * SC, rig["waist"][1] * SC)}
        head = {"angle": 0.9 * sway_late + 10.0 * hd, "dx": 1.0 * sway_late * sc + 5.0 * hd * sc, "dy": 12.0 * hd * sc,
                "pivot": (rig["neck"][0] * SC, rig["neck"][1] * SC)}
        hair = {"angle": 3.0 * (hr - hd) + 0.6 * math.sin(2 * math.pi * t / 1.1 + ph), "dx": 0.0, "dy": 2.0 * (hr - hd) * sc,
                "pivot": (rig["neck"][0] * SC, rig["neck"][1] * SC)}
        return body, head, hair

    # --------------------------------------------------------------- frame
    def frame(self, f):
        t = self.ctx.local(f)
        fh = f - f % 2
        cv, ratio = self.screen_canvas(f)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a = pl["rgb"], pl["a"]
            if i in (0, 1):
                rgb = rgb.copy()
                self._aisle_into(rgb, i, f)
            if i == 1:
                a = a.copy()
                for name in Q_SPRITES:
                    s = self.sprites[name]
                    body, head, hair = self.q_pose(name, f)
                    parts = [dict(body, w=s["w_body"]), dict(head, w=s["w_head"])]
                    if s["w_hair"] is not None:
                        parts.append(dict(hair, w=s["w_hair"]))
                    patch = FX.part_warp(s["rgba"], s["x0"], s["y0"], parts)
                    FX.over_patch(rgb, patch, s["x0"], s["y0"], a)
            if i in (2, 4):
                rgb = pl["un"] + (rgb - pl["un"]) * (1 + (ratio - 1) * pl["rw"])
            if i == 2:
                self._receipt_into(rgb, f)
            if i == 3:
                a = a.copy()
                rgb = pl["un"] + (rgb - pl["un"]) * (1 + (ratio - 1) * pl["rw"])
                if f >= self.f_smear:
                    self._pose_b_bg_into(rgb, a, ratio)
                self._screen_into(rgb, cv)
                pool = self._pool(self.pool_grow(f))
                pool[..., :3] = np.clip(pool[..., :3] * (0.8 + 0.2 * min(ratio, 1.6)), 0, 1)
                FX.over_patch(rgb, pool, int(300 * SC), int(1640 * SC))
                for name in ("goo", "goo_front"):
                    if name == "goo" and f >= self.f_smear:
                        continue                                    # the card left with the hand (pose B)
                    s = self.sprites[name]
                    g_rgba = s["rgba"].copy()
                    g_rgba[..., :3] = s["un"] + (g_rgba[..., :3] - s["un"]) * (1 + (ratio - 1) * s["rw"])
                    patch = self._stretch(g_rgba, s["x0"], s["y0"], f, name)
                    FX.over_patch(rgb, patch, s["x0"], s["y0"], a)
                self._drops_into(rgb, f, ratio)
            if i == 4 and self.f_ant <= f < self.f_smear:
                M = np.float32([[1, 0, 0], [0, 1, 10 * SC]])                 # the hand presses the card down
                rgb = cv2.warpAffine(rgb, M, (rgb.shape[1], rgb.shape[0]), borderMode=cv2.BORDER_REPLICATE)
                a = cv2.warpAffine(a, M, (a.shape[1], a.shape[0]), borderMode=cv2.BORDER_CONSTANT)
            if i == 4 and f >= self.f_smear:
                rgb, a = self._pose_b_plane(f, ratio)
                rps.append({"rgb": rgb, "a": a, "n": self.pose_b["n"]})
                continue
            rps.append({"rgb": rgb, "a": a, "n": pl["n"]})
        img = self.cam.render(rps, t)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "US swipe fees: $198 billion in 2025", self.f_two)
        self._scenario(img, f)
        return img, {"ratio": ratio}

    def _screen_into(self, rgb, cv):
        sc_ = self.screen
        x0, y0, x1, y1 = sc_["bbox"]
        patch = cv2.warpPerspective(cv, sc_["H"], (x1 - x0, y1 - y0), flags=cv2.INTER_AREA)
        patch = np.clip(patch * (0.55 + 0.45 * sc_["tex"][..., None]), 0, 1)
        m = sc_["mask"][..., None]
        rgb[y0:y1, x0:x1] = rgb[y0:y1, x0:x1] * (1 - m) + patch * m

    def _receipt_into(self, rgb, f):
        R = self.receipt
        x0, y0, x1, y1 = R["bbox"]
        F = self.feed(f)
        pc = self.print_canvas
        S = 2
        mx = R["V"] * 200 * S
        my = (F - R["U"] - self._p0) * S
        ink = cv2.remap(pc, mx.astype(np.float32), my.astype(np.float32), cv2.INTER_LINEAR,
                        borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        ink = cv2.GaussianBlur(ink, (0, 0), 0.55)
        vis = R["m"] * np.clip(R["U"] / 6.0, 0, 1) * ((R["V"] > 0.02) & (R["V"] < 0.98)) * R["low"]
        a = ink * vis
        reg = rgb[y0:y1, x0:x1]
        T.paint_on_surface(reg, a, INK, opacity=0.88, seed=63)

    def _scenario(self, img, f):
        """'scenario' chip beside the growing fee, anchored to the receipt where it leaves the till."""
        if f < self.f_youd:
            return
        t = self.ctx.local(f)
        p = self.cam.screen_point((872 * SC, 1060 * SC), nearness(0.24), t)   # left of the receipt mouth
        chip = O.scenario_label()
        x0, y0, x1, y1 = safe_box()
        x = min(max(p[0] - chip.shape[1] - 8, x0), x1 - chip.shape[1])
        y = min(max(p[1] - chip.shape[0] / 2, y0), y1 - chip.shape[0])
        O.draw_pop(img, chip, x, y, f, self.f_youd)

    # --------------------------------------------------------------- report / sound
    def finish_args(self, f, info):
        return {"bloom_strength": 0.45 + 0.25 * max(0.0, info["ratio"] - 1.0)}

    def events(self):
        ev = [(self.f_two, "data_tag", {}), (self.f_decl, "reader_flash", {}), (self.f_inc, "fee_lands", {}),
              (self.f_smear, "hand_recoils", {}), (self.f_ant, "card_pressed", {}),
              (self.f_youd, "fee_grows", {})]
        for fr, step in self.feed_moves:
            ev.append((fr, "feed_jerk", {"step": step}))
        for fr, j in self.landings:
            ev.append((fr, "drip_lands", {"x": DRIPS[j]["x"] / 1520, "big": float(DRIPS[j]["w"])}))
        ev.append((self.f0 - self.f0 % 2 + 8, "drip_lands", {"x": DROPLET_AT[0] / 1520, "big": 13.0}))
        for fb in self.bumps:
            ev.append((fb, "curl_starts", {}))
        for name in Q_RIG:
            lag = Q_RIG[name]["lag"]
            ev.append((self.f_b + 2 + lag, "queue_slump", {"who": name}))
            ev.append((self.f_inc + 2 + lag, "queue_slump", {"who": name}))
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tail = dur + 0.6
        snd.bed(FX.murmur(tail, seed=14), t0, -30, pan=0.25)
        snd.bed(A.room_tone(tail, seed=15), t0, -30)
        tt = A.t_axis(tail)
        hum = A.hum(tail, 120.0, seed=16) * 0.5 + A.bandpass(A.noise(tail, 17), 6000, 9000) * 0.15
        snd.bed(A.highpass(hum, 200), t0, -38, pan=-0.2)
        for f, kind, info in self.events():
            t = snd.at_frame(f)
            if kind == "feed_jerk":
                big = info["step"] >= 20
                snd.sfx(FX.printer_burst(0.075 if not big else 0.08, seed=f, rate=40 if not big else 52), t,
                        -21 if not big else -17, 0.35)
            elif kind == "reader_flash":
                snd.sfx(FX.buzzer(0.30, seed=1, f=392.0), t, -13, -0.15)
                snd.sfx(A.thunk(seed=2), t, -14, -0.1)
            elif kind == "card_pressed":
                snd.sfx(FX.drip(f + 3, pitch=420), t, -22, -0.3)        # a wet squelch under the thumb
            elif kind == "hand_recoils":
                snd.sfx(A.swish(0.22, 7), t, -18, -0.3)
            elif kind == "fee_lands":
                snd.sfx(A.hit(seed=4), t, -13, 0.2)
                snd.sfx(FX.buzzer(0.2, seed=3, f=130.0), t, -18, -0.15)
            elif kind == "drip_lands":
                pan = float(np.clip((info["x"] - 0.4) * 2, -0.7, 0.4))
                snd.sfx(FX.drip(f, pitch=1250 - 35 * info["big"]), t, -19, pan)
            elif kind == "queue_slump":
                who = info["who"]
                if who in ("q_bun", "q_tall", "q_five"):
                    snd.sfx(FX.trolley_rattle(0.45, seed=f + len(who)), t, -25, {"q_bun": -0.5, "q_tall": 0.0, "q_five": 0.35}[who])
        snd.sfx(FX.murmur(1.4, seed=31, sigh=True), snd.at_frame(self.f_b + 4), -26, 0.2)
        snd.sfx(FX.murmur(1.4, seed=32, sigh=True), snd.at_frame(self.f_inc + 4), -24, 0.2)


def make(ctx):
    return Shot(ctx)
