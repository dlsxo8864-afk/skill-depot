"""Shot 11, Year 10: "And yes, ChatGPT's nine hundred million users would lose it too."

The giant text cursor (a clean vertical bar) in the sky over the data centre holds, blinks twice,
flickers, and on "lose" cracks
into glowing chunks that crumble into embers; the embers rain down with streaked trails and burn out
over the crowd. The cheering crowd in the middle distance keeps bobbing on 2s, unaware; the people
in front tap at their dead phones and stare. Camera: slow push toward the cursor, easing down with
the falling embers, a short shake on the break.
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS
from whatif.fx2d import Embers, ShapeCanvas, painted_haze, screen_emissive, star4_poly, tapered_streak_poly
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]
SC = L.WORK_SCALE

# ------------------------------------------------------------------ spec (key px, 1520 x 2701)
PLANES = [
    L.PlaneSpec("sky", 0.00, 0.05, fill="full"),
    L.PlaneSpec("factory", 0.05, 0.145, fill="full"),
    L.PlaneSpec("crowd", 0.145, 0.36, radius=70, region=[(0, 1180), (1520, 1180), (1520, 2000), (0, 2000)]),
    L.PlaneSpec("front", 0.36, 1.01, radius=80),
]
# hands holding dead phones (pivot at the wrist, the thumb end moves)
SPRITES = [
    L.SpriteSpec("hand_c", 3, [(796, 2478), (850, 2470), (905, 2492), (935, 2550), (965, 2630), (960, 2701),
                               (815, 2701), (795, 2600), (782, 2520)],
                 dmin=0.5, pivot=(905, 2690), anchor=(820, 2500, 915, 2685), fill_own_plane=True),
    L.SpriteSpec("hand_l", 3, [(70, 2205), (150, 2212), (240, 2222), (256, 2290), (205, 2352), (110, 2388), (55, 2335)],
                 dmin=0.4, pivot=(75, 2380), anchor=(235, 2240, 80, 2370), fill_own_plane=True),
    L.SpriteSpec("hand_r", 3, [(1232, 2330), (1330, 2305), (1432, 2318), (1466, 2362), (1424, 2432), (1300, 2474),
                               (1236, 2444)],
                 dmin=0.4, pivot=(1250, 2462), anchor=(1430, 2335, 1255, 2455), fill_own_plane=True),
]
# the girl in front only (pose B repaints the whole crowd; everyone else holds pose A, so nothing else jumps)
HERO = [(440, 1690), (1030, 1690), (1085, 2000), (1045, 2430), (415, 2430), (395, 2000)]
CURSOR_BOX = (560, 120, 980, 760)          # where the cursor and its dripping sparks live
CROWD_BAND = (1240, 1720)                  # rows of the cheering crowd (bob weight 1 at top, low at bottom)
N_SKY = 0.03


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


# ------------------------------------------------------------------ sync
def _plan(ctx):
    f0 = ctx.f0
    f_break = ctx.f("lose")
    f_tag = ctx.f("nine")
    e = f0 + 10 + (f0 + 10) % 2                      # first blink on the 2s grid
    blinks = [(e, e + 8), (ctx.f("million") - 2, ctx.f("million") + 6)]
    flicker = [(f_break - 6, 1.30), (f_break - 4, 0.45), (f_break - 2, 1.45)]
    return {"break": f_break, "tag": f_tag, "blinks": blinks, "flicker": flicker}


class Shot(BaseShot):
    flash_color = (1.0, 0.55, 0.42)          # ember orange-pink, not the violet sky

    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        self.P = _plan(ctx)
        # pose B (y10_chatgpt_poseB.png): the people in front look up and at each other after the break
        self.pose = PoseSwap.for_shot(ctx, STEM, region=HERO, feather=14)
        self.swaps = [(self.P["break"] + 6, "B")]
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        tb = (self.P["break"] - self.f0) / FPS
        self.cam = ParallaxCamera(
            W, H, nearness=nearness,
            focus=Track([(0, (W * 0.5, H * 0.40)), (tb, (W * 0.5, H * 0.42), "inout"), (d, (W * 0.5, H * 0.47), "inout")]),
            zoom=Track([(0, 1.0), (d, 1.075, "inout")]),
            push=Track([(0, 0.0), (d, 0.07, "inout")]),
            rise=Track([(0, 0.0), (d, -16.0, "inout")]),
            pan=lambda t: self._shake(t, 0), roll=lambda t: self._shake(t, 1))

    def _shake(self, t, axis):
        """Short camera shake on the break (1s: every frame), decaying over ~0.4 s."""
        u = t - (self.P["break"] - self.f0) / FPS
        if u < 0 or u > 0.45:
            return 0.0
        e = math.exp(-u * 9)
        return (math.sin(u * 95) * 9 * e) if axis == 0 else (math.sin(u * 70 + 1) * 0.35 * e)

    # ------------------------------------------------------------ prepared plates
    @cached_property
    def planes(self):
        out = []
        for p in self.lay.planes:
            out.append({"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                        "n": nearness(p["d"].astype(np.float32) / 65535)})
        self._prep_cursor(out)
        return out

    def _prep_cursor(self, planes):
        """Split the sky into 'cursor off' + 'cursor light' (bar, halo and dripping sparks)."""
        x0, y0, x1, y1 = [int(v * SC) for v in CURSOR_BOX]
        sky = planes[0]["rgb"]
        Hh, Ww = sky.shape[:2]
        box = np.zeros((Hh, Ww), bool)
        box[y0:y1, x0:x1] = True
        lum = sky.max(2)
        bright = (lum > 0.62) & box
        n, lab, stats, _ = cv2.connectedComponentsWithStats(bright.astype(np.uint8))
        i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        bar = (lab == i).astype(np.uint8)
        bar = cv2.morphologyEx(bar, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
        sparks = (bright & (bar == 0)).astype(np.uint8)
        hard = np.maximum(cv2.dilate(bar, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (141, 141))),
                          cv2.dilate(sparks, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13))))
        soft = np.clip(cv2.GaussianBlur(hard.astype(np.float32), (0, 0), 10) * 1.3, 0, 1)
        off = L.textured_fill(sky, hard < 1, seed=303, amp_scale=0.8)
        off = sky * (1 - soft[..., None]) + off * soft[..., None]
        planes[0]["off"] = off
        planes[0]["diff"] = sky - off
        # sparks that drip over the factory roof (plane 1): small, inpainted locally
        fac = planes[1]["rgb"]
        fs = ((fac.max(2) > 0.55) & box & (planes[1]["a"] > 0.5)).astype(np.uint8)
        fs = cv2.dilate(fs, np.ones((5, 5), np.uint8))
        f8 = (np.clip(fac, 0, 1) * 255).astype(np.uint8)
        foff = cv2.inpaint(f8, fs, 5, cv2.INPAINT_TELEA).astype(np.float32) / 255
        planes[1]["off"] = foff
        planes[1]["diff"] = fac - foff
        ys, xs = np.where(bar > 0)
        # the painted bar is a crumbling, spark-dripping slab; the cursor must read as a TEXT cursor:
        # a clean, crisp vertical bar (about 1:9) with an even glow, drawn over the cleaned sky
        # (moved 110 work px right of the painted slab so the standard data tag never covers it)
        cx, top = float(xs.mean()) + 110.0, float(ys.min())
        bw, bh = 40.0, 372.0
        bx0, bx1, by0, by1 = cx - bw / 2, cx + bw / 2, top + 4, top + 4 + bh
        core = np.zeros((Hh, Ww), np.float32)
        cv2.rectangle(core, (int(round(bx0 * 8)), int(round(by0 * 8))), (int(round(bx1 * 8)), int(round(by1 * 8))),
                      1.0, -1, cv2.LINE_AA, shift=3)
        inner = cv2.GaussianBlur(core, (0, 0), 9)
        halo = cv2.GaussianBlur(core, (0, 0), 46)
        glow = (core[..., None] * np.float32([1.0, 0.97, 0.92])
                + inner[..., None] * np.float32([1.0, 0.78, 0.62]) * 0.75
                + halo[..., None] * np.float32([1.0, 0.55, 0.50]) * 0.95)
        # cursor layer = clean bar replacing the painted one (k scales it: 0 off, 1 on, >1 surge)
        planes[0]["diff"] = np.clip(off + glow, 0, 1) - off
        planes[1]["diff"] = np.zeros_like(planes[1]["diff"])        # no painted sparks: a clean cursor
        self.bar = {"x0": bx0, "x1": bx1, "y0": by0, "y1": by1, "cx": cx, "cy": (by0 + by1) / 2}

    @cached_property
    def crowd_bob(self):
        """Per-pixel bob weight and phase for the crowd plane (people ~60 key px wide)."""
        Hh, Ww = self.lay.H, self.lay.W
        r0, r1 = int(CROWD_BAND[0] * SC), int(CROWD_BAND[1] * SC)
        yy = np.linspace(0, 1, r1 - r0, dtype=np.float32)[:, None]
        wy = np.clip(1.15 - yy * 0.95, 0.15, 1.0) ** 1.3
        rng = np.random.default_rng(11)
        cells = rng.uniform(0, 2 * math.pi, int(Ww / (55 * SC)) + 3)
        xs = np.arange(Ww, dtype=np.float32) / (55 * SC)
        ph = np.interp(xs, np.arange(len(cells)), cells)
        ph = cv2.GaussianBlur(ph[None, :].astype(np.float32), (0, 0), 3)[0]
        amp = rng.uniform(0.6, 1.25, len(cells))
        am = np.interp(xs, np.arange(len(cells)), amp).astype(np.float32)
        gx, gy = np.meshgrid(np.arange(Ww, dtype=np.float32), np.arange(r0, r1, dtype=np.float32))
        return {"r0": r0, "r1": r1, "w": wy * am[None, :], "ph": ph[None, :], "gx": gx, "gy": gy}

    @cached_property
    def haze(self):
        h = painted_haze(int(300 * SC), int(2200 * SC), seed=77, blobs=7, softness=30)
        return h

    @cached_property
    def embers_amb(self):
        return Embers(14, self.lay.W, self.lay.H, seed=21, y_range=(0.35, 0.75), n_range=(0.05, 0.35))

    @cached_property
    def shards(self):
        """The bar cut into slabs with jagged cracks, plus each slab's tumble (working px)."""
        b = self.bar
        rng = np.random.default_rng(5)
        cuts = np.sort(np.concatenate([[b["y0"] - 4, b["y1"] + 4], rng.uniform(b["y0"] + 30, b["y1"] - 30, 6)]))
        x0, x1 = b["x0"] + 2, b["x1"] - 2
        edges = []
        for c in cuts:
            xs = np.linspace(x0, x1, 5)
            ys = c + rng.uniform(-9, 9, 5)
            edges.append(np.stack([xs, ys], 1))
        out = []
        for k in range(len(cuts) - 1):
            top, bot = edges[k], edges[k + 1]
            poly = np.concatenate([top, bot[::-1]]).astype(np.float32)
            c = poly.mean(0)
            out.append({"poly": poly - c, "c": c, "v": np.array([(c[0] - b["cx"]) * 1.2 + rng.normal(0, 70),
                                                                  rng.normal(-40, 50)]),
                        "spin": rng.normal(0, 60), "seed": k})
        return out

    @cached_property
    def ember_sim(self):
        """Embers born from the shards: spawn time, position, velocity, size, life."""
        b = self.bar
        rng = np.random.default_rng(9)
        out = []
        for d, count in [(1, 120), (2, 70), (3, 45)]:
            for _ in range(count):
                y = rng.uniform(b["y0"], b["y1"])
                x = rng.uniform(b["x0"], b["x1"])
                out.append({"t0": d * 2 / FPS, "p": np.array([x + rng.normal(0, 6) * d, y + rng.normal(0, 8) * d]),
                            "v": np.array([(x - b["cx"]) * rng.uniform(2, 5) + rng.normal(0, 210),
                                           rng.normal(-90, 120)]),
                            "size": rng.uniform(0.7, 1.6), "life": rng.uniform(0.55, 1.6),
                            "ph": rng.uniform(0, 6.28), "k": rng.uniform(1.1, 2.0)})
        return out

    # ------------------------------------------------------------ state
    def cursor_k(self, f):
        fh = f - f % 2
        if fh >= self.P["break"]:
            return 0.0
        for a, b in self.P["blinks"]:
            if a <= fh < b:
                return 0.0
        for fk, k in self.P["flicker"]:
            if fh == fk:
                return k
        return 1.0

    def taps(self, name, f):
        """Thumb press angle for a hand at frame f (on 2s): quick presses at its own rhythm."""
        rng = np.random.default_rng({"hand_c": 1, "hand_l": 2, "hand_r": 3}[name])
        beats, t = [], self.f0 + int(rng.integers(2, 10)) * 2
        while t < self.f1:
            beats.append(t)
            t += int(rng.integers(4, 9)) * 2
        fh = f - f % 2
        pose = {0: 1.0, 2: 0.35}
        return sum(pose.get(fh - b, 0.0) for b in beats)

    # ------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        fh = f - f % 2
        pl = self.planes
        k = self.cursor_k(f)
        dim = 0.94 + 0.06 * min(k, 1.0)
        rps = []
        for i, p in enumerate(pl):
            rgb, a = p["rgb"], p["a"]
            if i <= 1:
                rgb = p["off"] + p["diff"] * min(k, 1.0)
                if k > 1:
                    rgb = rgb + np.maximum(p["diff"], 0) * (k - 1)
                if i == 1:
                    rgb = self._haze_into(rgb, th) * dim
            elif i == 2:
                rgb, a = self._bob(p, th)
                rgb = rgb * dim
            else:
                rgb, a = rgb.copy(), a.copy()
                st = PoseSwap.state(f, self.swaps) if self.pose else "A"
                for s in self.lay.sprites:
                    tap = self.taps(s["name"], f) if st == "A" else 0.0     # taps belong to pose A
                    patch, x0, y0 = deform_sprite(s, angle_deg=-4.0 * tap, dy=-3.5 * tap)
                    composite_into(rgb, a, patch, x0, y0)
                if self.pose:
                    n_front = self.pose.nearness(p["n"], p["a"], st)
                    rgb, a = self.pose.apply(rgb, a, st)
            rps.append({"rgb": rgb, "a": a, "n": n_front if (i == 3 and self.pose) else p["n"]})
        img = self.cam.render(rps, t)
        img = self.embers_amb.draw(self.cam, th, img, intensity=0.45)
        if fh >= self.P["break"]:
            img = self._break(img, f, t)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "ChatGPT: 900 million\nweekly users", self.P["tag"], f_out=self.P["break"] - 2)
        return img, {"k": k}

    def _haze_into(self, rgb, th):
        h = self.haze
        rgb = rgb.copy()
        y0 = int(1180 * SC)
        x = int((th * 22) % (h.shape[1] - rgb.shape[1])) if h.shape[1] > rgb.shape[1] else 0
        band = h[:, x:x + rgb.shape[1]][..., None] * 0.30
        rgb[y0:y0 + h.shape[0]] = rgb[y0:y0 + h.shape[0]] * (1 - band) + np.float32([0.36, 0.22, 0.46]) * band
        return rgb

    def _bob(self, p, th):
        """Crowd cheering on 2s: each person-sized column jumps/pumps at its own phase."""
        cb = self.crowd_bob
        r0, r1 = cb["r0"], cb["r1"]
        u = 2 * math.pi * 1.7 * th
        jump = np.maximum(np.sin(u + cb["ph"]), 0) ** 1.4
        dy = -9.0 * SC * cb["w"] * jump
        dx = 2.2 * SC * cb["w"] * np.sin(u * 0.5 + cb["ph"] * 1.7)
        mx, my = cb["gx"] - dx, cb["gy"] - dy
        rgb, a = p["rgb"].copy(), p["a"].copy()
        rgb[r0:r1] = cv2.remap(p["rgb"], mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        a[r0:r1] = cv2.remap(p["a"], mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        return rgb, a

    def _break(self, img, f, t):
        """Cracked bar -> tumbling glowing chunks -> embers raining with streaked trails."""
        fh = f - f % 2
        d = (fh - self.P["break"]) // 2                      # drawing index since the break
        tb = (fh - self.P["break"]) / FPS
        sc = ShapeCanvas(img.shape[1], img.shape[0])
        S = self.cam.scale_at(N_SKY, t)
        b = self.bar
        # flash at the heart of the bar on the break drawing
        if d <= 1:
            cpt = self.cam.screen_point((b["cx"], b["cy"]), N_SKY, t)
            r = (200 if d == 0 else 120) * S
            sc.fill(star4_poly(cpt, r, 0.0, pinch=0.10), value=255 if d == 0 else 150)
            sc.fill(star4_poly(cpt, r * 0.45, math.pi / 4, pinch=0.2), value=255 if d == 0 else 120)
        # shards: in place with cracks (d=0), then tumbling, crumbling, gone (d>=4)
        grow = {0: 1.0, 1: 0.92, 2: 0.66, 3: 0.38}
        if d in grow:
            g = 1400.0
            for sh in self.shards:
                ang = math.radians(sh["spin"] * tb)
                ca, sa = math.cos(ang), math.sin(ang)
                pts = sh["poly"] * grow[d] * (0.93 if d == 0 else 1.0)
                pts = np.stack([pts[:, 0] * ca - pts[:, 1] * sa, pts[:, 0] * sa + pts[:, 1] * ca], 1)
                c = sh["c"] + sh["v"] * tb + np.array([0, 0.5 * g * tb * tb])
                q = np.array([self.cam.screen_point(pp, N_SKY, t) for pp in (pts + c)])
                sc.fill(q, value=int(255 * (1.0, 0.95, 0.8, 0.6)[d]))
        # embers
        g, kd = 2400.0, 1.2
        for e in self.ember_sim:
            u = tb - e["t0"]
            if u < 0 or u > e["life"]:
                continue
            vt = g / kd
            decay = math.exp(-kd * u)
            px = e["p"][0] + e["v"][0] * (1 - decay) / kd + math.sin(u * 5 + e["ph"]) * 6
            py = e["p"][1] + vt * u + (e["v"][1] - vt) * (1 - decay) / kd
            vx, vy = e["v"][0] * decay + math.cos(u * 5 + e["ph"]) * 30, vt + (e["v"][1] - vt) * decay
            q = self.cam.screen_point((px, py), N_SKY + 0.05 * min(u, 1.0), t)
            life = 1 - u / e["life"]
            flick = 0.65 + 0.35 * math.sin(u * 23 + e["ph"] * 3)
            val = life ** 0.7 * flick
            if val < 0.08:
                continue
            spd = math.hypot(vx, vy) * S
            s = e["size"] * S
            sc.fill(tapered_streak_poly(q, (vx, vy), 6 * s + spd * 0.045, 4.2 * s), value=int(255 * val))
            sc.fill(tapered_streak_poly(q, (vx, vy), 10 * s + spd * 0.14, 2.0 * s), value=int(110 * val))
        c, gl = sc.result(glow_sigma=5)
        return screen_emissive(img, c, gl, (1.0, 0.86, 0.72), (1.0, 0.42, 0.36))

    # ------------------------------------------------------------ framework hooks
    def finish_args(self, f, info):
        fh = f - f % 2
        hot = self.P["break"] <= fh < self.P["break"] + 8
        return {"bloom_strength": 0.75 if hot else 0.5 + 0.1 * min(info["k"], 1.0)}

    def events(self):
        ev = [(self.f0, "cut", {})]
        for a, b in self.P["blinks"]:
            ev += [(a, "blink_off", {}), (b, "blink_on", {})]
        for fk, k in self.P["flicker"]:
            ev.append((fk, "flicker", {"k": k}))
        ev.append((self.P["tag"], "data_tag", {}))
        ev.append((self.P["break"], "cursor_break", {}))
        ev.append((self.P["break"] + 6, "ember_rain", {}))
        if self.pose:
            ev += [(fs, "pose_" + to, {}) for fs, to in self.swaps]
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tb = self.P["break"] / FPS
        tt = A.t_axis(dur + 0.6) + t0
        # crowd: cheering bed, chanting swell; it keeps going through the break
        cheer = A.crowd(dur + 0.6, seed=31) * (0.8 + 0.2 * np.sin(2 * np.pi * 0.9 * tt))
        snd.bed(cheer, t0, -24, pan=-0.1)
        snd.bed(A.crowd(dur + 0.6, seed=32), t0, -27, pan=0.35)
        # the cursor's electric presence: a high, thin hum that cuts out on blinks and the break
        gate = np.array([self.cursor_k(int(x * FPS)) for x in tt])
        gate = A.lowpass(np.clip(gate, 0, 1.5), 60)
        snd.bed(A.hum(dur + 0.6, 120.0, seed=33) * gate, t0, -33)
        for a, b in self.P["blinks"]:
            snd.sfx(A.soft_click(2400, a), a / FPS, -24, 0.0)
            snd.sfx(A.soft_click(2900, b), b / FPS, -26, 0.0)
        for fk, k in self.P["flicker"]:
            snd.sfx(A.zap(fk, 0.06, 0.6), fk / FPS, -27)
        snd.sfx(A.tick(self.P["tag"], 2200), self.P["tag"] / FPS, -27, -0.4)
        # the break: crack, glassy burst, then a long crackling ember shower
        snd.sfx(A.zap(7, 0.14, 1.6), tb, -14)
        snd.sfx(_glass_burst(dur=1.1, seed=8), tb, -15)
        snd.sfx(_crackle(dur=1.6, seed=9), tb + 0.05, -21, 0.1)


# ------------------------------------------------------------------ local sounds
def _glass_burst(dur=1.1, seed=8):
    """Bright shatter: a bank of decaying high partials struck at random moments, over a noise burst."""
    rng = np.random.default_rng(seed)
    n = int(dur * A.SR)
    out = np.zeros(n)
    for _ in range(36):
        f = rng.uniform(1800, 7500)
        at = int(abs(rng.normal(0, 0.06)) * A.SR)
        m = n - at
        tone = A.osc(f, m / A.SR) * A.exp_decay(m, rng.uniform(0.05, 0.3)) * rng.uniform(0.2, 1)
        out[at:] += tone
    burst = A.bandpass(A.noise(dur, seed, "white"), 2500, 12000) * A.exp_decay(n, 0.05) * 3
    body = A.lowpass(A.noise(dur, seed + 1, "pink"), 600) * A.exp_decay(n, 0.12)
    x = out / (np.abs(out).max() + 1e-9) + burst + body
    return x / (np.abs(x).max() + 1e-9)


def _crackle(dur=1.6, seed=9):
    """Ember shower: sparse crackles thinning out, with a soft sizzle."""
    rng = np.random.default_rng(seed)
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    imp = np.zeros(n)
    dens = np.exp(-t * 2.2)
    hits = rng.random(n) < dens * 900 / A.SR
    imp[hits] = rng.uniform(-1, 1, hits.sum())
    cr = A.bandpass(imp, 1200, 8000) * 5
    siz = A.bandpass(A.noise(dur, seed + 1), 3000, 9000) * dens * 0.25
    x = cr + siz
    return x / (np.abs(x).max() + 1e-9)


def make(ctx):
    return Shot(ctx)
