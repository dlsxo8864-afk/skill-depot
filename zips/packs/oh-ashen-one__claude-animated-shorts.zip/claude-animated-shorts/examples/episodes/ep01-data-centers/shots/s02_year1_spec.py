"""Layer, sprite and screen geometry for shot 2 (Year 1, doomscrolling). Key-image px (1520x2688)."""
import numpy as np

from whatif.config import ASSETS, LAYER_CACHE
from whatif.layers import PlaneSpec, SpriteSpec

SHOT = "s02_year1"
KEY = ASSETS / "key" / "y01_tiktok_key.png"
DEPTH = LAYER_CACHE / "y01_tiktok_depth.png"


def not_screen(img, depth):
    """Thumb pixels: inside the envelope but not the flat teal screen."""
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    screen = (g > 0.80) & (b > 0.72) & (r < 0.58) & (g - r > 0.3)
    keep = (~screen).astype(np.uint8)
    # fill pin-holes inside the thumb (teal-lit skin must not read as screen)
    import cv2
    keep = cv2.morphologyEx(keep, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
    return keep > 0


PLANES = [
    PlaneSpec("city", 0.0, 0.03, fill="full"),
    PlaneSpec("room", 0.03, 0.27, fill="full"),
    PlaneSpec("kid", 0.27, 0.56, radius=70),
    PlaneSpec("blanket", 0.56, 1.01, radius=80),
]

SPRITES = [
    SpriteSpec("thumb", 2, [(872, 1446), (940, 1424), (1062, 1424), (1104, 1466), (1110, 1545), (1050, 1566),
                            (958, 1560), (884, 1528), (868, 1486)],
               dmin=0.2, pivot=(1150, 1625), anchor=(985, 1480, 1095, 1545), mask_fn=not_screen, fill_own_plane=True),
]

# Window region of the far plane (for the lights-out ripple) and the neon sign we keep lit.
WINDOW_REGION = (690, 0, 1520, 770)
NEON_BOX = (1470, 150, 1520, 480)
