"""Pose-to-pose helpers for s05_year4 and s06_year5 (local, written because no shared pose-swap helper existed
when these shots were polished). A second painted pose (assets/key/<key>_poseB.png, same framing as the key)
is aligned to the upscaled key, only its hero region is taken through a soft mask, and it is posed and smeared
on 2s like a drawn character.

aligned_pose  : Lanczos upscale to the key size + ECC affine alignment on the unchanged background, cached.
hero_mask     : soft union of polygons (key px); inside `refine_quad` pixels failing `keep(rgb)` are dropped.
multi_pose    : one remap for several weighted rigid parts (each part a weight map, pivot and pose).
smear_rgba    : a drawn multi-image smear: the pose repeated back along a per-pixel motion field, fading.
"""
import math

import cv2
import numpy as np

from whatif import layers as L


def aligned_pose(key_path, pose_path, out_png):
    """Pose B as float RGB at the key's size, aligned to it (affine ECC on pixels that did not change)."""
    out_png.parent.mkdir(parents=True, exist_ok=True)
    A8 = cv2.imread(str(key_path))
    if out_png.exists() and out_png.stat().st_mtime > max(pose_path.stat().st_mtime, key_path.stat().st_mtime):
        return cv2.cvtColor(cv2.imread(str(out_png)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    H, W = A8.shape[:2]
    B8 = cv2.resize(cv2.imread(str(pose_path)), (W, H), interpolation=cv2.INTER_LANCZOS4)
    s = 0.25
    a = cv2.cvtColor(cv2.resize(A8, None, fx=s, fy=s, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
    b = cv2.cvtColor(cv2.resize(B8, None, fx=s, fy=s, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
    a, b = a.astype(np.float32) / 255, b.astype(np.float32) / 255
    same = (np.abs(cv2.GaussianBlur(a, (0, 0), 3) - cv2.GaussianBlur(b, (0, 0), 3)) < 0.06).astype(np.uint8)
    M = np.eye(2, 3, dtype=np.float32)
    try:
        _, M = cv2.findTransformECC(a, b, M, cv2.MOTION_AFFINE,
                                    (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6), same, 5)
    except cv2.error:
        M = np.eye(2, 3, dtype=np.float32)
    M[:, 2] /= s
    Bw = cv2.warpAffine(B8, M, (W, H), flags=cv2.INTER_LANCZOS4 | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
    cv2.imwrite(str(out_png), Bw)
    return cv2.cvtColor(Bw, cv2.COLOR_BGR2RGB).astype(np.float32) / 255


def hero_mask(shape, polys, feather=8.0, refine_quad=None, keep=None, refine_feather=1.2):
    """Soft hero mask (key px). Returns (mask, region): region is the plain feathered polygon union (where the
    old pose must be removed), mask additionally drops pixels inside refine_quad that fail keep(rgb)."""
    m = np.zeros(shape[:2], np.float32)
    for p in polys:
        m = np.maximum(m, L.poly_mask(shape[:2], p))
    region = np.clip(cv2.GaussianBlur(m, (0, 0), feather) * 1.15, 0, 1) * (cv2.dilate(m, np.ones((5, 5), np.uint8)) > 0)
    region = cv2.GaussianBlur(region, (0, 0), 1.0)
    mask = region.copy()
    if refine_quad is not None and keep is not None:
        q = L.poly_mask(shape[:2], refine_quad)
        mask = mask * (1 - q * (1 - keep))
        mask = cv2.GaussianBlur(mask, (0, 0), refine_feather)
    return mask.astype(np.float32), region.astype(np.float32)


def _inverse(gx, gy, pivot, angle_deg=0.0, dx=0.0, dy=0.0, scale=1.0):
    a = math.radians(angle_deg)
    ca, sa = math.cos(-a), math.sin(-a)
    ux, uy = (gx - pivot[0] - dx) / scale, (gy - pivot[1] - dy) / scale
    return ux * ca - uy * sa + pivot[0], ux * sa + uy * ca + pivot[1]


def multi_pose(rgba, x0, y0, parts):
    """rgba: crop whose (0,0) sits at plate (x0, y0). parts: [(weight_map, pivot_xy, pose_dict)], all in plate
    px. The displacements of the parts add, each weighted by its map, so overlapping parts stay continuous."""
    h, w = rgba.shape[:2]
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    gx += x0
    gy += y0
    sx, sy = gx.copy(), gy.copy()
    for wmap, pivot, pose in parts:
        if wmap is None:
            continue
        px, py = _inverse(gx, gy, pivot, **{k: float(v) for k, v in pose.items()})
        sx += wmap * (px - gx)
        sy += wmap * (py - gy)
    return cv2.remap(rgba, (sx - x0).astype(np.float32), (sy - y0).astype(np.float32), cv2.INTER_LINEAR,
                     borderMode=cv2.BORDER_CONSTANT, borderValue=0)


def smear_rgba(rgba, vx, vy, steps=((0.0, 1.0), (0.22, 0.62), (0.45, 0.40), (0.7, 0.22)), tint=(0.86, 0.80, 0.98)):
    """Multi-image smear: copies of the drawing displaced back along (vx, vy) (per pixel, crop px), fading
    and simplified (blurred, tinted toward the light), drawn behind the leading drawing."""
    h, w = rgba.shape[:2]
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    out = np.zeros_like(rgba)
    for t, op in sorted(steps, key=lambda s: -s[0]):
        c = cv2.remap(rgba, gx - vx * t, gy - vy * t, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        if t > 0:
            c = cv2.GaussianBlur(c, (0, 0), 1.5 + 4 * t)
            c[..., :3] = c[..., :3] * (1 - 0.35 * t) + np.float32(tint) * 0.35 * t * c[..., 3:4]
        c[..., 3] *= op
        a = c[..., 3:4]
        oa = a + out[..., 3:4] * (1 - a)
        out[..., :3] = (c[..., :3] * a + out[..., :3] * out[..., 3:4] * (1 - a)) / np.maximum(oa, 1e-6)
        out[..., 3:4] = oa
    return out


def radial(shape_hw, x0, y0, c, r_in, r_out, sy=1.0):
    """0..1 weight map over a crop (crop at plate x0, y0): 1 inside r_in of c, 0 beyond r_out (plate px)."""
    h, w = shape_hw
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.hypot(gx + x0 - c[0], (gy + y0 - c[1]) * sy)
    t = np.clip((r_out - d) / max(r_out - r_in, 1e-6), 0, 1)
    return (t * t * (3 - 2 * t)).astype(np.float32)


# ---------------------------------------------------------------- only the hero changes (round 3)
def poly_soft(shape_hw, polys, scale, feather=0.0):
    """Union of polygons (key px, scaled to the plate by `scale`) as a 0..1 map, optionally feathered."""
    m = np.zeros(shape_hw, np.float32)
    for p in polys:
        cv2.fillPoly(m, [np.round(np.float32(p) * scale).astype(np.int32)], 1.0)
    return cv2.GaussianBlur(m, (0, 0), feather) if feather > 0 else m


def diff_mask(a, b, region, min_area=0.004, grow=16, feather=6.0, thresh=None):
    """Soft mask of where the two paintings really differ (Lab distance), inside `region` only, big blobs
    filled solid. a, b: float RGB at the plate size; region: 0..1 map. Everything outside stays pose A."""
    la = cv2.cvtColor(a.astype(np.float32), cv2.COLOR_RGB2LAB)
    lb = cv2.cvtColor(b.astype(np.float32), cv2.COLOR_RGB2LAB)
    d = cv2.GaussianBlur(np.sqrt((((la - lb) * np.float32([1.0, 0.6, 0.6])) ** 2).sum(2)), (0, 0), 5)
    reg = (region > 0.5).astype(np.uint8)
    if thresh is None:
        out = d[reg == 0] if (reg == 0).any() else d
        thresh = float(max(np.median(out) * 3.2, 6.0))
    m = ((d > thresh) & (reg > 0)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25)))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m, 8)
    keep = np.zeros_like(m)
    H, W = m.shape
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] >= min_area * W * H:
            keep[lab == i] = 1
    ff = keep.copy()
    cv2.floodFill(ff, np.zeros((H + 2, W + 2), np.uint8), (0, 0), 1)
    keep = keep | (1 - ff)
    keep = cv2.dilate(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * grow + 1, 2 * grow + 1))) & reg
    soft = cv2.GaussianBlur(keep.astype(np.float32), (0, 0), feather)
    return np.clip(soft * 1.6 - 0.3, 0, 1).astype(np.float32) * np.clip(cv2.GaussianBlur(region, (0, 0), 2), 0, 1)


def color_match(b, a, m, ring_px=40, lo=0.8, hi=1.25):
    """Match b's colour to a in a ring just outside mask m (same light, no seam)."""
    k = (m > 0.5).astype(np.uint8)
    ring = (cv2.dilate(k, np.ones((2 * ring_px + 1, 2 * ring_px + 1), np.uint8)) - k).astype(bool)
    if ring.sum() < 500:
        return b
    ma, sa = a[ring].mean(0), a[ring].std(0) + 1e-3
    mb, sb = b[ring].mean(0), b[ring].std(0) + 1e-3
    return np.clip((b - mb) * np.clip(sa / sb, lo, hi) + ma, 0, 1).astype(np.float32)


def smooth_field(shape_hw, pts, disp, sigma, zero_w=0.08):
    """Dense displacement field from sparse control points (plate px): normalised Gaussian weights with a
    pull toward zero far from every point. Returns (fx, fy) float32."""
    H, W = shape_hw
    s = 0.25                                                   # computed at quarter size, then upscaled
    h, w = max(int(H * s), 2), max(int(W * s), 2)
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32) / s
    num_x = np.zeros((h, w), np.float32)
    num_y = np.zeros((h, w), np.float32)
    den = np.full((h, w), zero_w, np.float32)
    for (px, py), (dx, dy) in zip(pts, disp):
        wt = np.exp(-((gx - px) ** 2 + (gy - py) ** 2) / (2 * sigma ** 2)).astype(np.float32)
        num_x += wt * dx
        num_y += wt * dy
        den += wt
    fx = cv2.resize(num_x / den, (W, H), interpolation=cv2.INTER_CUBIC)
    fy = cv2.resize(num_y / den, (W, H), interpolation=cv2.INTER_CUBIC)
    return fx.astype(np.float32), fy.astype(np.float32)


def half_warp(img, fx, fy, k=0.5):
    """The in-between drawing: content that sits at p in pose B drawn at p + k * field(p) (field points from
    pose B back toward pose A), approximated by sampling img at q - k * field(q)."""
    H, W = img.shape[:2]
    gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
    return cv2.remap(img, gx - k * fx, gy - k * fy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
