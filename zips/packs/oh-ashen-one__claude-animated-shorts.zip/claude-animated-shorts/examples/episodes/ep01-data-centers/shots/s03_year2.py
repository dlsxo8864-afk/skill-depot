"""Shot 3, Year 2: a man shovels cash into a television that is a furnace. Each load lands on a word
("bill", "ninety-nine", "today", the big one on "forty-nine", a last one in the tail): wind-up with
anticipation, a snap thrust with drawn multiples (no blur), bundles and notes fly into the fire and
burn, the fire flares and its light pumps on the man, floor and couch. The price rolls $19.99 ->
$49.99 on "forty-nine" (scenario); the bank balance on the phone on the table steps down with every
load and spins to $0.00.

Key-image px are pixels of work/keys/y02_netflix_key.png (1520 x 2701)."""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS, safe_box
from whatif.keyprep import prepare_key
from whatif.fx2d import ShapeCanvas, screen_emissive, star4_poly, tapered_streak_poly
from whatif.screens import ScreenQuad, light_weight, relight, screen_light, unlit_plate
from whatif.shotkit import BaseShot
from whatif.timing import Track, even_frame_of

from . import s03_year2_kit as K

STEM = "s03_year2"
SC = L.WORK_SCALE

# ------------------------------------------------------------------ spec (key px)
MAN_REGION = [(0, 1000), (90, 950), (300, 840), (450, 790), (470, 745), (560, 730), (700, 790), (715, 900),
              (700, 1010), (735, 1060), (760, 1075), (765, 1210), (700, 1260), (650, 1420), (640, 1560),
              (720, 1720), (790, 1920), (840, 2120), (860, 2330), (0, 2330)]
COUCH_REGION = [(1165, 1590), (1330, 1530), (1520, 1490), (1520, 2701), (860, 2701), (880, 2540), (1060, 2330),
                (1170, 2120), (1180, 1880)]
PLANES = [
    L.PlaneSpec("room", 0.00, 0.20, fill="full"),
    L.PlaneSpec("man", 0.15, 0.60, radius=80, region=MAN_REGION),
    L.PlaneSpec("near", 0.44, 1.01, radius=70),
    L.PlaneSpec("couch", 0.20, 1.01, radius=60, region=COUCH_REGION),
]


def not_fire(img, depth):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    fire = ((r - g > 0.16) & (r > 0.55) & (r - b > 0.30)) | ((r > 0.93) & (g > 0.72) & (b < 0.55) & (r - g > 0.06))
    keep = (~fire).astype(np.uint8)
    keep = cv2.morphologyEx(keep, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    keep = cv2.morphologyEx(keep, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))
    return keep > 0


BLADE_ENV = [(768, 1078), (842, 1066), (900, 1100), (925, 1060), (952, 965), (1062, 892), (1185, 885),
             (1275, 955), (1302, 1012), (1290, 1062), (1238, 1094), (1100, 1140), (1010, 1190), (962, 1206),
             (930, 1176), (880, 1172), (850, 1196), (775, 1200), (760, 1150)]
GRIP = (800, 1125)                         # right hand on the shaft (blade pivot)
SPRITES = [L.SpriteSpec("blade", 1, BLADE_ENV, dmin=0.0, dmax=1.0, pivot=GRIP, mask_fn=not_fire)]

# pose B (assets/key/y02_netflix_poseB.png): the wind-up with a loaded shovel. Only the region where the two
# paintings differ inside HERO_REGION is taken from it (aligned to the key), so the room never pops.
HERO_REGION = [(0, 640), (1000, 640), (1330, 840), (1330, 1260), (1060, 1500), (1060, 2400), (0, 2400)]
# matched landmarks on the two paintings (key px): crown, ear, shoulder, back hand, front hand, elbow,
# blade middle, blade end, waist, knees, feet. The in-between drawing is both paintings mesh-warped halfway.
POSE_PTS_A = [(540, 760), (600, 880), (200, 900), (130, 1300), (780, 1130), (600, 1180), (1120, 1060),
              (1250, 1000), (420, 1450), (120, 1700), (560, 1750), (700, 2050), (40, 2000), (60, 1300), (420, 1215)]
POSE_PTS_B = [(600, 800), (620, 1000), (220, 940), (60, 1440), (340, 1560), (420, 1360), (560, 1580),
              (700, 1560), (440, 1500), (150, 1750), (560, 1800), (740, 2050), (60, 2000), (20, 1430), (200, 1500)]
IB_POSE = {"AB": (-120.0, -2.4, 9.0, -1.2, 0.8),    # (shaft, torso deg, crouch px, head, hair) on the way down
           "BA": (-95.0, -1.6, 6.0, -0.6, -1.0)}     # on the way up into the throw
HOLD_A = 8                                 # frames the thrust pose holds after each impact
B_PIVOT = (450, 1800)                      # pose B hips

TV_INNER = [(722, 742), (1438, 520), (1442, 1215), (758, 1278)]
TV_OUTER = [(700, 722), (1478, 458), (1488, 1228), (705, 1292)]
SHAFT_U = np.float32([0.981, -0.194])        # left hand -> blade
PHONE_SCREEN = [(78, 2238), (191, 2221), (311, 2338), (189, 2362)]
PILE_TOP = (1120, 935)                       # top of the cash pile on the blade
BUNDLES = [(1062, 895, 1182, 968), (972, 958, 1088, 1032), (1128, 955, 1252, 1032), (1036, 1000, 1162, 1072)]
NOTE_ZONE = [(560, 380), (1500, 380), (1500, 1760), (980, 1760), (980, 1440), (700, 1440), (700, 1250), (560, 1250)]
STAND_CASH = (660, 1440, 960, 1545)


VO_ONSETS = {"bill": 0.86, "Nineteen": 1.92, "ninety-nine": 2.21, "today": 2.54, "could": 3.66,
             "forty-nine": 3.92, "ninety-nine.": 4.28}          # s after the take starts (02_netflix.wav)


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


# ------------------------------------------------------------------ motion on 2s
# shaft travel along SHAFT_U (working px) around one load; k = frames from the impact
THRUST = [(-16, 0.0), (-12, -30.0), (-8, -70.0), (-6, -78.0), (-4, -82.0), (-2, -16.0), (0, 36.0), (2, 26.0),
          (4, 10.0), (6, 3.0), (10, 0.0)]
TORSO = [(-16, 0.0), (-12, -1.0), (-8, -2.3), (-4, -2.6), (-2, 0.6), (0, 2.2), (2, 1.6), (6, 0.5), (12, 0.0)]  # deg, leads
CROUCH = [(-16, 0.0), (-8, 7.0), (-4, 9.0), (-2, 2.0), (0, -6.0), (4, -2.0), (10, 0.0)]                          # px down


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        self.key_path = key
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        comp = key.parent.parent / "poses" / "s03_poseB.png"
        self.hero_key = K.pose_b_composite(key, ctx.key.parent / "y02_netflix_poseB.png", comp, HERO_REGION)
        keyB, depthB = prepare_key(comp)
        region_b = K.mask_polygon(self.hero_key)
        planes_b = [PLANES[0], L.PlaneSpec("man", 0.15, 0.60, radius=80, region=region_b), PLANES[2], PLANES[3]]
        L.build(STEM + "_B", keyB, depthB, planes_b, [])
        self.layB = L.Layers(STEM + "_B")
        d = ctx.dur
        # Word onsets measured on the take (band energy, syllable nuclei). The shared aligner spreads the
        # unheard "Nineteen ninety-nine" over the pause after "bill" (0.9 s early), so the sync points
        # come from the take itself, relative to where the line starts (they move with the line).
        wf = lambda w: even_frame_of(ctx.vo_at + VO_ONSETS[w])
        self.f_price = wf("forty-nine")
        self.f_19 = wf("Nineteen")
        # loads: "bill", "Nineteen", the pause after "today", the big one on "forty-nine", one in the tail
        self.impacts = [wf("bill"), self.f_19 + 2, self.f_price - 22, self.f_price, self.f_price + 26]
        self.big = {self.f_price}
        self.f_roll_end = self.f_price + 16
        # $19.99 is today's real price and goes up plain; "scenario" comes in on the first frame the price
        # leaves $19.99 (the invented rise) and stays while any invented figure is on screen
        self.f_scen = next(f for f in range(self.f_price, self.f_roll_end + 1)
                           if round(O.roll_value(f, self.f_price, self.f_roll_end, 19.99, 49.99, ease="inout"), 2) != 19.99)
        self.f_card = self.f_price - 12             # the balance card is up before the big load spins it
        self.balance0 = 1284.50
        f_big = self.f_price - self.f0
        self.cam = ParallaxCamera(
            W, H, focus=Track([(0, (W * 0.50, H * 0.46)), (d, (W * 0.51, H * 0.49), "inout")]), nearness=nearness,
            zoom=lambda t: Track([(0, 1.0), (d, 1.06, "inout")])(t) + self._kick(t, f_big / FPS),
            push=Track([(0, 0.0), (d, 0.05, "inout")]),
            rise=Track([(0, 0.0), (d, -34.0, "inout")]))

    @staticmethod
    def _kick(t, t0):
        """A small zoom punch on the big load, eased on 1s (no pop)."""
        u = t - t0
        if u < 0:
            return 0.0
        return 0.022 * math.sin(min(u / 0.12, 1.0) * math.pi / 2) * math.exp(-max(u - 0.12, 0) / 0.35)

    # ============================================================ prepared
    @cached_property
    def planes(self):
        return self._make_planes(self.lay, store_notes=True)

    @cached_property
    def planes_b(self):
        _ = self.planes
        return self._make_planes(self.layB, store_notes=False)

    @cached_property
    def hero_out(self):
        """Hero mask as a plane (working px) so the camera can map it to the frame for the smear."""
        H, W = self.planes[0]["a"].shape
        m = cv2.resize(np.maximum(self.hero_key, 0), (W, H), interpolation=cv2.INTER_AREA).astype(np.float32)
        return {"rgb": np.repeat(m[..., None], 3, 2), "a": np.ones((H, W), np.float32), "n": self.planes[1]["n"]}

    def _make_planes(self, lay, store_notes):
        out = []
        for i, p in enumerate(lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            pl = {"rgb": rgb, "a": p["a"].astype(np.float32) / 255, "n": nearness(p["d"].astype(np.float32) / 65535)}
            out.append(pl)
        H, W = out[0]["a"].shape
        self.tv_mask = K.soft_poly((H, W), TV_INNER, feather=1.5)
        self.tv_inner_soft = cv2.GaussianBlur(cv2.erode(self.tv_mask, np.ones((17, 17), np.uint8)), (0, 0), 5)
        self.tv_glow = cv2.GaussianBlur(K.soft_poly((H, W), TV_OUTER, feather=0), (0, 0), 60)
        self._cut_notes(out[0], store=store_notes)
        for i, pl in enumerate(out):
            ww = light_weight(pl["rgb"], "warm", blur=4)
            if i == 0:
                ww = ww * (1 - cv2.dilate(self.tv_mask, np.ones((9, 9), np.uint8)))
            pl["ww"] = ww
            pl["un"] = unlit_plate(pl["rgb"], ww, tint=(0.46, 0.30, 0.74), level=0.55)
        # phone light on the table (near plane)
        nr = out[2]
        tw = light_weight(nr["rgb"], "teal", blur=3)
        if store_notes:
            self.phone = ScreenQuad.from_points(PHONE_SCREEN, nr["rgb"].shape, scale=SC, plate_rgb=nr["rgb"], radius=2)
        tw = tw * (1 - cv2.dilate(self.phone.mask, np.ones((7, 7), np.uint8)))
        nr["tw"] = tw
        nr["un_t"] = unlit_plate(nr["rgb"], tw, tint=(0.40, 0.30, 0.62), level=0.6)
        return out

    def _cut_notes(self, pl, store=True):
        """Painted airborne notes in the room plate become sprites (fluttering) and the plate is filled."""
        rgb = pl["rgb"]
        H, W = rgb.shape[:2]
        mx, mn = rgb.max(2), rgb.min(2)
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        note = ((mx - mn) < 0.30) & (mx > 0.36) & (g > b + 0.04) & (g > r - 0.10)
        zone = K.soft_poly((H, W), NOTE_ZONE, feather=0) > 0.5
        x0, y0, x1, y1 = [int(v * SC) for v in STAND_CASH]
        zone[y0:y1, x0:x1] = False
        bx = [int(v * SC) for v in (900, 860, 1320, 1150)]
        zone[bx[1]:bx[3], bx[0]:bx[2]] = False                    # the blade's cash pile (filled plate)
        m = cv2.morphologyEx((note & zone).astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))
        n, lab, stats, cents = cv2.connectedComponentsWithStats(m)
        notes = []
        allm = np.zeros((H, W), np.float32)
        for i in range(1, n):
            x, y, w, h, area = stats[i]
            if area < 260 or area > 9000 or w > 150 or h > 150:
                continue
            mm = (lab == i).astype(np.float32)
            mm = cv2.dilate(mm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
            mm = cv2.GaussianBlur(mm, (0, 0), 0.8)
            pad = 6
            xa, ya, xb, yb = max(x - pad, 0), max(y - pad, 0), min(x + w + pad, W), min(y + h + pad, H)
            patch = np.dstack([rgb[ya:yb, xa:xb], mm[ya:yb, xa:xb]]).astype(np.float32)
            notes.append({"rgba": patch, "c": np.float32([(xa + xb) / 2, (ya + yb) / 2]), "seed": i})
            allm = np.maximum(allm, mm)
        grow = cv2.dilate(allm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
        filled = L.textured_fill(rgb, grow < 0.3, seed=303, amp_scale=0.8)
        pl["rgb"] = rgb * (1 - grow[..., None]) + filled * grow[..., None]
        if store:
            self.air_notes = notes

    @cached_property
    def blade(self):
        s = dict(self.lay.sprites[self.lay.sprite_index("blade")])
        s["rgba_f"] = s["rgba"].astype(np.float32) / 255
        al = cv2.erode(s["rgba_f"][..., 3], np.ones((3, 3), np.uint8))       # drop the fire-coloured rim
        s["rgba_f"][..., 3] = cv2.GaussianBlur(al, (0, 0), 0.7)
        s["ww"] = light_weight(s["rgba_f"][..., :3], "warm", blur=3)
        s["un"] = unlit_plate(s["rgba_f"][..., :3], s["ww"], tint=(0.46, 0.30, 0.74), level=0.55)
        return s

    @cached_property
    def bundles(self):
        """Cash bundles cut from the painted pile (they fly off the blade into the fire)."""
        key = cv2.cvtColor(cv2.imread(str(self.key_path)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
        out = []
        for j, (x0, y0, x1, y1) in enumerate(BUNDLES):
            c = key[y0:y1, x0:x1]
            c = cv2.resize(c, (int((x1 - x0) * SC), int((y1 - y0) * SC)), interpolation=cv2.INTER_AREA)
            h, w = c.shape[:2]
            m = np.zeros((h, w), np.float32)
            cv2.ellipse(m, (w // 2, h // 2), (int(w * 0.46), int(h * 0.40)), -12, 0, 360, 1.0, -1, cv2.LINE_AA)
            nf = not_fire(c, None).astype(np.float32)
            m = cv2.GaussianBlur(m * nf, (0, 0), 0.8)
            out.append(np.dstack([c, m]).astype(np.float32))
        return out

    @cached_property
    def overlays(self):
        x0, y0, x1, y1 = safe_box()
        slots = O.tag_slots()
        return {"counter_xy": (slots["data"][0] + 8, slots["data"][1] - 6)}

    @cached_property
    def streaks(self):
        return [L.brush_noise((960, 760), 500 + i, scale=2.6, angle=-1.47, stretch=7.0) for i in range(3)]

    def bottom_fade(self, h, w, bx0, by0):
        """0 along the screen's bottom bezel rising to 1 a little above it (keeps lick roots hidden)."""
        if getattr(self, "_bf", None) is None:
            q = [np.float32(p) * SC - (bx0, by0) for p in TV_INNER]
            xs = np.arange(w, dtype=np.float32)
            yb = q[3][1] + (q[2][1] - q[3][1]) * (xs - q[3][0]) / (q[2][0] - q[3][0])
            yy = np.arange(h, dtype=np.float32)[:, None]
            self._bf = np.clip((yb[None, :] - yy - 20 * SC) / (110 * SC), 0, 1).astype(np.float32)
        return self._bf

    @cached_property
    def soft_streak(self):
        return L.brush_noise((960, 760), 611, scale=4.0, angle=-1.25, stretch=3.0)

    @cached_property
    def fire_src(self):
        """A strip of the painting's own fire (tiled with mirrored repeats) to fill escaping flames."""
        x0, y0, x1, y1 = [int(v * SC) for v in (1000, 690, 1420, 900)]
        src = self.planes[0]["rgb"][y0:y1, x0:x1]
        w = int((1500 - 600) * SC)
        src = cv2.resize(src, (w, int(src.shape[0] * w / src.shape[1])), interpolation=cv2.INTER_LINEAR)
        tile = np.concatenate([src, src[::-1]] * 4, axis=0)
        return np.ascontiguousarray(tile)

    @cached_property
    def flow(self):
        rng = np.random.default_rng(77)
        n = [cv2.GaussianBlur(rng.standard_normal((1600, 760)).astype(np.float32), (0, 0), 9) for _ in range(2)]
        return [x / (x.std() + 1e-6) for x in n]

    @cached_property
    def embers(self):
        x0, y0 = 600 * SC, 520 * SC
        x1, y1 = 1440 * SC, 1250 * SC
        bursts = [fi - self.f0 for fi in self.impacts]
        return K.SourceEmbers((x0, y0, x1, y1), 0.12, rate=9, life=(14, 34), seed=8,
                              vel=((-110, 20), (-170, -60)), bursts=bursts, burst_n=12,
                              burst_box=(980 * SC, 860 * SC, 1250 * SC, 1050 * SC))

    # ============================================================ state on 2s
    def flare(self, fh):
        """Fire level: rest 0, each load spikes and decays; the big load is larger and longer."""
        v = 0.0
        for fi in self.impacts:
            k = fh - fi
            if k < 0:
                continue
            big = fi in self.big
            peak = 1.0 if big else 0.62
            tau = 14.0 if big else 8.0
            ramp = {0: 0.55, 2: 1.0}.get(k, 1.0)
            v = max(v, peak * ramp * math.exp(-max(k - 2, 0) / tau))
        return v

    def flick(self, fh):
        rng = np.random.default_rng(fh // 2 + 11)
        return float(rng.uniform(-0.05, 0.05))

    def pose(self, fh):
        s = tor = cr = 0.0
        for fi in self.impacts:
            k = fh - fi
            if 0 <= k <= 12:
                g = 1.25 if fi in self.big else 1.0
                s += K.keys_at(THRUST, k) * g
                tor += K.keys_at(TORSO, k + 2) * g         # the torso leads the arms by a drawing
                cr += K.keys_at(CROUCH, k + 2) * g
        # head follows the torso a drawing late; hair trails two drawings late and overshoots
        hd = hr = 0.0
        for fi in self.impacts:
            k = fh - fi
            if not 0 <= k <= 14:
                continue
            g = 1.25 if fi in self.big else 1.0
            hd += K.keys_at(TORSO, k) * g
            hr += (K.keys_at(TORSO, k - 2) - K.keys_at(TORSO, k)) * g
        return s, tor, cr, hd, hr

    def balance(self, fh):
        v = self.balance0
        steps = [19.99, 19.99, 19.99]
        for fi, st in zip(self.impacts[:3], steps):
            if fh >= fi + 2:
                v -= st
        if fh >= self.f_price:
            v = O.roll_value(fh, self.f_price, self.f_roll_end + 2, v, 0.0, ease="in")
        return max(v, 0.0)

    # ============================================================ rig
    @cached_property
    def rig(self):
        H, W = self.planes[1]["a"].shape
        sh = (H, W)
        # hands (and the bit of shaft between them) ride the shaft fully
        lhand = np.maximum(K.soft_poly(sh, [(0, 1225), (70, 1180), (160, 1150), (250, 1185), (345, 1205), (350, 1290),
                                            (240, 1330), (180, 1430), (60, 1440), (0, 1410)], feather=10),
                           K.soft_disc(sh, (130, 1270), 150, 0.6) * K.ramp(sh, (130, 1300), (150, 1080)))
        rarm = K.soft_poly(sh, [(600, 1040), (700, 1040), (775, 1070), (780, 1200), (700, 1240), (610, 1200)], feather=14)
        rarm = rarm * K.ramp(sh, (775, 1130), (600, 1110))                  # forearm stretches toward the elbow
        shaft = np.clip(np.maximum(lhand, rarm), 0, 1)
        # torso: everything above the hips turns about the hips (the legs stay planted)
        torso = K.ramp(sh, (330, 1050), (330, 1560)) * (1 - shaft)
        head = K.soft_disc(sh, (590, 850), 150, 0.5)
        hair = K.soft_poly(sh, [(455, 790), (520, 735), (600, 725), (700, 780), (715, 850), (650, 820), (560, 800)], feather=14)
        hood = K.soft_disc(sh, (360, 900), 120, 0.7) * (1 - head)
        bones = {"shaft": {"w": shaft}, "torso": {"w": torso, "pivot": (330, 1600)},
                 "crouch": {"w": K.ramp(sh, (330, 900), (330, 1700))},
                 "head": {"w": head * (1 - shaft), "pivot": (600, 975)}, "hair": {"w": hair}, "hood": {"w": hood}}
        return K.Rig((0, 680, 900, 2340), sh, bones)

    def man_pose(self, fh, override=None):
        s, tor, cr, hd, hr = self.pose(fh) if override is None else override
        u = SHAFT_U
        return {"shaft": (0.0, u[0] * s, u[1] * s + cr * 0.6),
                "torso": (tor, 0.0, 0.0), "crouch": (0.0, 0.0, cr),
                "head": (hd * 0.8 - tor * 0.4, 0.0, 0.0),
                "hair": (0.0, -hr * 2.2, abs(hr) * 0.8), "hood": (0.0, -hr * 1.4, 0.0)}, s, cr

    # ============================================================ pose-to-pose
    def pose_state(self, f):
        """('A', k) thrust pose k frames after an impact; ('antic', None) one drawing of pose A leaning a
        little further into the fire before the wind-up; ('ib', 'AB'|'BA') the one true in-between
        (a mesh warp halfway between the paintings); ('B', None) the held wind-up."""
        for fi in self.impacts:
            if f == fi - 1:
                return "ib", "BA"
            if fi <= f <= fi + HOLD_A:
                return "A", f - fi
            if f == fi + HOLD_A + 1:
                return "antic", None
            if f == fi + HOLD_A + 2:
                return "ib", "AB"
        return "B", None

    @cached_property
    def man_n(self):
        p = self.planes[1]
        return float(np.median(p["n"][p["a"] > 0.5]))

    def pose_pts(self, pts, t):
        return [self.cam.screen_point((x * SC, y * SC), self.man_n, t) for x, y in pts]

    def next_impact(self, f):
        later = [fi for fi in self.impacts if fi > f]
        return later[0] if later else None

    @cached_property
    def rig_b(self):
        H, W = self.planes_b[1]["a"].shape
        sh = (H, W)
        torso = K.ramp(sh, (450, 900), (450, 1820))
        return K.Rig((0, 640, 1100, 2400), sh, {"torso": {"w": torso, "pivot": B_PIVOT},
                                                "crouch": {"w": K.ramp(sh, (450, 800), (450, 2300))}})

    def b_pose(self, fh):
        """Anticipation inside the held wind-up: he sinks and coils over the last drawings."""
        fn = self.next_impact(fh)
        p = 0.0 if fn is None else float(np.clip((fh - (fn - 12)) / 10.0, 0, 1))
        p = p * p * (3 - 2 * p)
        fp = max([fi for fi in self.impacts if fi <= fh] or [self.f0 - 100])
        k = fh - (fp + HOLD_A + 3)                      # settle into the pose after the recovery in-between
        settle = {0: -5.0, 2: 2.0}.get(k, 0.0)
        g = 1.25 if fn in self.big else 1.0
        return {"torso": (-2.6 * p * g, 0.0, 0.0), "crouch": (0.0, 0.0, (9.0 * p + settle) * g)}

    def frame(self, f):
        st, arg = self.pose_state(f)
        t = (f - self.f0) / FPS
        fh = f - f % 2
        Fl = self.flare(fh)
        if st in ("A", "antic"):
            img = self.render_pose(f, "A", lean=(st == "antic"))
        elif st == "ib":
            # the in-between: the pose being left, mesh-warped halfway to the next one, one solid figure
            # over pose A's room (the set does not move)
            img = self.render_pose(f, "A", ib=arg)
        else:
            # pose B lives only inside the hero mask; the room is always pose A's frame, so it holds still
            img_a = self.render_pose(f, "A")
            img_b = self.render_pose(f, "B")
            m = self.cam.render([self.hero_out], t)[..., 0]
            if st == "B":
                img = K.pose_mix(img_a, img_b, m)
            else:
                img = K.landmark_inbetween(img_a, img_b, m, self.pose_pts(POSE_PTS_A, t),
                                           self.pose_pts(POSE_PTS_B, t), t=0.5)
        img = self.embers.draw(self.cam, fh - self.f0, t, img, intensity=0.85 + 0.4 * Fl)
        self._front_notes(img, fh, t)
        self._overlays(img, f, Fl)
        return img, {"flare": Fl}

    def render_pose(self, f, which, lean=False, ib=None):
        t = (f - self.f0) / FPS
        fh = f - f % 2
        Fl = self.flare(fh)
        light = 1.0 + 0.42 * Fl + self.flick(fh)
        pls = self.planes if which == "A" else self.planes_b
        rps = []
        # ---- room
        p0 = pls[0]
        rgb0 = relight(p0["rgb"], p0["un"], light)
        rgb0 = self._fire(rgb0, fh, Fl)
        self._air_notes(rgb0, fh)
        self._flying(rgb0, fh, into_fire=True)
        self._burst(rgb0, fh)
        rps.append({"rgb": rgb0, "a": p0["a"], "n": p0["n"]})
        # ---- man
        p1 = pls[1]
        rgb1 = relight(p1["rgb"], p1["un"], light)
        n1 = p1["n"]
        if which == "A":
            # the in-between drawing: pose A's painting carried on its rig halfway back toward the wind-up
            # (shaft drawn back and down, torso coiled, knees sunk): one solid figure, nothing else moves
            pose, s, cr = self.man_pose(fh, override=IB_POSE[ib] if ib else None)
            if lean:                                     # anticipation: a touch further into the throw, then back
                tor, dx, dy = pose["torso"]
                pose = dict(pose, torso=(tor + 1.6, dx, dy), crouch=(0.0, 0.0, pose["crouch"][2] + 4.0),
                            head=(pose["head"][0] + 1.0, 0.0, 0.0))
            rgb1, a1 = self.rig.warp([rgb1, p1["a"]], pose)
            self._blade_into(rgb1, a1, fh, s, cr, light)
        else:
            rgb1, a1 = self.rig_b.warp([rgb1, p1["a"]], self.b_pose(fh))
        rps.append({"rgb": rgb1, "a": a1, "n": n1})
        # ---- near (table + phone)
        p2 = pls[2]
        rgb2 = relight(p2["rgb"], p2["un"], light)
        rgb2, a2 = self._phone(rgb2, p2, fh)
        rps.append({"rgb": rgb2, "a": a2, "n": p2["n"]})
        # ---- couch
        p3 = pls[3]
        rps.append({"rgb": relight(p3["rgb"], p3["un"], light), "a": p3["a"], "n": p3["n"]})
        return self.cam.render(rps, t)

    # ------------------------------------------------------------ fire
    def _fire(self, rgb, fh, Fl):
        H, W = rgb.shape[:2]
        bx0, by0 = int(600 * SC), int(150 * SC)
        bx1, by1 = int(1500 * SC), int(1320 * SC)
        box = rgb[by0:by1, bx0:bx1]
        h, w = box.shape[:2]
        tvm = self.tv_mask[by0:by1, bx0:bx1, None]
        tvi = self.tv_inner_soft[by0:by1, bx0:bx1, None]
        # 1) the painted fire boils upward: a flowing displacement field, a new drawing every 2 frames
        n1, n2 = self.flow
        off = int((fh * 7) % 600)
        dx = n1[off:off + h, :w] * (3.0 + 1.5 * Fl)
        dy = n2[off:off + h, :w] * (4.5 + 2.0 * Fl) + 2.0
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        boiled = cv2.remap(box, gx + dx, gy + dy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        lum = boiled.max(2, keepdims=True)
        hot = np.clip((lum - 0.55) / 0.45, 0, 1)
        gain = 0.92 + 0.12 * Fl + self.flick(fh) * 1.5
        boiled = np.clip(boiled * gain + hot * np.float32([0.10, 0.07, 0.02]) * Fl, 0, 1)
        box = box * (1 - tvi) + boiled * tvi
        # 2) hand-drawn tongues over the paint (inside the screen), on 2s
        fc = K.FlameCanvas(w, h)
        rng = np.random.default_rng(fh // 2 * 13 + 5)
        q = [np.float32(p) * SC - (bx0, by0) for p in TV_INNER]          # TL TR BR BL in box px
        P = lambda u, v: q[0] + (q[1] - q[0]) * u + (q[3] - q[0]) * v + (q[2] - q[1] - q[3] + q[0]) * u * v
        big_n = 8
        for i in range(big_n):                    # big licks rising from below the bottom bezel
            u = (i + 0.5) / big_n + rng.uniform(-0.04, 0.04)
            base = P(u, 1.0) + np.float32([0, 60 * SC])
            hh = rng.uniform(330, 560) * SC * (1 + 0.45 * Fl)
            fc.tongue(base, hh, hh * rng.uniform(0.36, 0.5), lean=rng.uniform(-70, 40) * SC,
                      phase=i * 2.3 + (fh // 2) * 0.8, curl=rng.uniform(-70, 70) * SC,
                      fork=rng.uniform(0.5, 1.0) if i % 2 else 0.0)
        for i in range(7):                        # small licks breaking off higher up
            base = P(rng.uniform(0.06, 0.94), rng.uniform(0.35, 0.85))
            hh = rng.uniform(70, 160) * SC * (1 + 0.3 * Fl)
            fc.tongue(base, hh, hh * 0.5, lean=rng.uniform(-30, 20) * SC, phase=rng.uniform(0, 6),
                      curl=rng.uniform(-30, 30) * SC, layers=(0, 1))
        st = self.streaks[(fh // 2) % 3]
        mo, mm, mc = [m * tvm[..., 0] for m in fc.masks(st, rough=0.30)]
        # the licks shape the painted fire itself: brighter inside a lick, a value darker between licks,
        # a hot soft core low in each lick (the paint's own strokes stay visible)
        lick = (cv2.GaussianBlur(mm, (0, 0), 2.5) * 0.6 + mo * 0.4)[..., None]
        core = cv2.GaussianBlur(mc, (0, 0), 5)[..., None]
        core = core * self.bottom_fade(h, w, bx0, by0)[..., None]
        shaped = box * (0.82 + (0.30 + 0.14 * Fl) * lick)
        shaped = 1 - (1 - shaped) * (1 - core * (0.22 + 0.22 * Fl) * K.FIRE_CORE)
        box = box * (1 - tvm) + np.clip(shaped, 0, 1) * tvm
        rgb[by0:by1, bx0:bx1] = box
        # firelight spill on the wall around the set
        g = self.tv_glow[..., None] * (0.10 + 0.22 * Fl)
        rgb[:] = 1 - (1 - rgb) * (1 - g * np.float32([1.0, 0.45, 0.15]))
        return rgb

    def _burst(self, rgb, fh):
        """Impact flash where the load hits the fire: a 4-point flash and torn streaks, 3 drawings."""
        sc = None
        for fi in self.impacts:
            k = (fh - fi) // 2
            if 0 <= k <= 2:
                if sc is None:
                    sc = ShapeCanvas(rgb.shape[1], rgb.shape[0])
                big = 1.35 if fi in self.big else 1.0
                c = np.float32(PILE_TOP) * SC + np.float32([40, -10])
                rng = np.random.default_rng(fi)
                if k == 0:
                    sc.fill(star4_poly(c, 70 * big, rng.uniform(0, 0.5), pinch=0.22), value=200)
                for j in range(8 if k < 2 else 5):
                    a = rng.uniform(-math.pi * 0.92, -math.pi * 0.08)
                    dvec = np.float32([math.cos(a), math.sin(a)])
                    p = c + dvec * (30 + 80 * k + rng.uniform(0, 30)) * big
                    sc.fill(tapered_streak_poly(p, dvec, (54 - 12 * k) * big, (8 - 2 * k) * big), value=255 - 50 * k)
        if sc is not None:
            core, glow = sc.result(glow_sigma=9)
            screen_emissive(rgb, core * 0.85, glow * 1.2, (1.0, 0.80, 0.42), (1.0, 0.42, 0.10))

    # ------------------------------------------------------------ paper
    def _air_notes(self, rgb, fh):
        """The painting's airborne notes keep falling and fluttering (on 2s)."""
        th = (fh - self.f0) / FPS
        for nt in self.air_notes:
            ph = nt["seed"] * 1.7
            fall = 30 * th
            dx = 10 * math.sin(th * 2.2 + ph)
            ang = 9 * math.sin(th * 3.1 + ph)
            sy = 0.72 + 0.28 * math.cos(th * 5.0 + ph)
            p, cx, cy = K.affine_patch(nt["rgba"], ang, 1.0, sy)
            K.over_center(rgb, p, nt["c"][0] + dx, nt["c"][1] + fall, cx, cy)

    def _launches(self):
        """Every load throws bundles and loose notes off the pile."""
        _ = self.planes                               # cuts the painted notes (self.air_notes)
        out = []
        for fi in self.impacts:
            rng = np.random.default_rng(fi * 3 + 1)
            big = fi in self.big
            nb = 4 if big else 2
            for j in range(nb):
                out.append({"f": fi, "kind": "bundle", "src": int(rng.integers(len(BUNDLES))),
                            "p0": np.float32(PILE_TOP) * SC + rng.uniform(-50, 50, 2).astype(np.float32),
                            "v": np.float32([rng.uniform(40, 260), rng.uniform(-480, -260)]) * SC,
                            "spin": rng.uniform(-14, 14), "life": 16 if big else 12, "seed": int(fi + j)})
            for j in range(3 if big else 2):
                into = j > 0
                out.append({"f": fi, "kind": "note", "into": into, "src": int(rng.integers(max(len(self.air_notes), 1))),
                            "p0": np.float32(PILE_TOP) * SC + rng.uniform(-40, 40, 2).astype(np.float32),
                            "v": (np.float32([rng.uniform(-60, 220), rng.uniform(-520, -300)]) if into
                                  else np.float32([rng.uniform(-560, -340), rng.uniform(-620, -440)])) * SC,
                            "spin": rng.uniform(-20, 20), "life": 14 if into else 26, "seed": int(fi * 7 + j)})
        return out

    @cached_property
    def launches(self):
        return self._launches()

    def _flying(self, rgb, fh, into_fire):
        for it in self.launches:
            if it["kind"] == "note" and not it["into"]:
                continue
            k = fh - it["f"]
            if k < 0 or k > it["life"]:
                continue
            tt = k / FPS
            p = it["p0"] + it["v"] * tt + np.float32([0, 0.5 * 1500 * SC * tt * tt])
            depth = min(1.0, k / it["life"])
            scale = 1.0 - 0.45 * depth
            burn = np.clip((k - 2) / (it["life"] - 4), 0, 1)
            if it["kind"] == "bundle":
                src = self.bundles[it["src"]]
                ang = it["spin"] * (k // 2)
                p_rgba, cx, cy = K.affine_patch(src, ang, scale, scale)
            else:
                if not self.air_notes:
                    continue
                src = self.air_notes[it["src"] % len(self.air_notes)]["rgba"]
                ang = it["spin"] * (k // 2)
                sy = math.cos(k * 0.9 + it["seed"])
                p_rgba, cx, cy = K.affine_patch(src, ang, scale, scale * (0.25 + 0.75 * abs(sy)))
            p_rgba, glow = K.burn_patch(p_rgba, float(burn), seed=it["seed"], side=(0.3, -1.0))
            # the paper takes the fire's colour as it goes in
            warm = np.float32([1.0, 0.62, 0.35])
            p_rgba[..., :3] = p_rgba[..., :3] * (1 - 0.45 * depth) + p_rgba[..., :3] * warm * 0.45 * depth
            K.over_center(rgb, p_rgba, p[0], p[1], cx, cy)
            if glow.any():
                x, y = int(round(p[0] - cx)), int(round(p[1] - cy))
                g2 = np.clip(glow * 1.0, 0, 1)
                screen_emissive(rgb, g2, cv2.GaussianBlur(g2, (0, 0), 3) * 1.4, (1.0, 0.85, 0.45), (1.0, 0.4, 0.1), x, y)

    def _front_notes(self, img, fh, t):
        """Notes kicked back toward the camera: they flutter past the man, in front of everything."""
        for it in self.launches:
            if it["kind"] != "note" or it["into"]:
                continue
            k = fh - it["f"]
            if k < 0 or k > it["life"] or not self.air_notes:
                continue
            tt = k / FPS
            p = it["p0"] + it["v"] * tt + np.float32([0, 0.5 * 700 * SC * tt * tt])
            nn = 0.15 + 0.6 * min(1.0, k / it["life"])
            q = self.cam.screen_point(p, nn, t)
            s = self.cam.scale_at(nn, t) * (1.0 + 0.9 * k / it["life"])
            src = self.air_notes[it["src"] % len(self.air_notes)]["rgba"]
            sy = math.cos(k * 0.7 + it["seed"])
            p_rgba, cx, cy = K.affine_patch(src, it["spin"] * (k // 2), s, s * (0.2 + 0.8 * abs(sy)))
            p_rgba = p_rgba.copy()
            # between the camera and the fire: backlit, so mostly shadow with a hot translucent rim
            al = p_rgba[..., 3]
            rim = np.clip(al - cv2.erode(al, np.ones((5, 5), np.uint8)), 0, 1)[..., None]
            p_rgba[..., :3] = p_rgba[..., :3] * np.float32([0.42, 0.36, 0.46]) * (1 - rim) + \
                np.float32([1.0, 0.62, 0.30]) * rim
            glow = np.zeros(p_rgba.shape[:2], np.float32)
            K.over_center(img, p_rgba, q[0], q[1], cx, cy)
            if glow.any():
                x, y = int(round(q[0] - cx)), int(round(q[1] - cy))
                screen_emissive(img, glow, cv2.GaussianBlur(glow, (0, 0), 3) * 1.3, (1.0, 0.85, 0.45), (1.0, 0.4, 0.1), x, y)

    # ------------------------------------------------------------ blade
    def _blade_into(self, rgb, a, fh, s, cr, light):
        bl = self.blade
        base = dict(bl)
        rgba = bl["rgba_f"].copy()
        rgba[..., :3] = relight(rgba[..., :3], bl["un"], light)
        base["rgba"] = rgba
        u = SHAFT_U

        def put(sv, op=1.0):
            dx, dy = u[0] * sv, u[1] * sv + cr * 0.6
            patch, x0, y0 = deform_sprite(base, angle_deg=-0.04 * sv, dx=dx, dy=dy, scale=1.0 - 0.0012 * sv)
            if op < 1:
                patch = patch.copy()
                patch[..., 3] *= op
            composite_into(rgb, a, patch, x0, y0)

        # the cash on the blade goes up in the fire over the held thrust (the bundles fly off it)
        k = min([fh - fi for fi in self.impacts if fh >= fi] or [0])
        burn = float(np.clip((k - 1) / 7.0, 0, 1))
        if burn > 0:
            rgba = rgba.copy()
            cash = self.blade_cash
            al = rgba[..., 3]
            sub = np.dstack([rgba[..., :3], al * cash])
            burned, _ = K.burn_patch(sub, burn, seed=fh // 2, side=(0.2, -1.0))
            rgba[..., 3] = np.maximum(al * (1 - cash), burned[..., 3])
            rgba[..., :3] = burned[..., :3] * cash[..., None] + rgba[..., :3] * (1 - cash[..., None])
            base["rgba"] = rgba
        put(s)

    @cached_property
    def blade_cash(self):
        rgb = self.blade["rgba_f"][..., :3]
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        m = ((g > b + 0.03) & (g > r - 0.12) & (rgb.max(2) > 0.30)).astype(np.float32)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
        m = cv2.dilate(m, np.ones((5, 5), np.uint8))
        return cv2.GaussianBlur(m, (0, 0), 1.5)

    # ------------------------------------------------------------ phone
    @cached_property
    def phone_bg(self):
        cw, ch = 300, 450
        yy = np.linspace(0, 1, ch, dtype=np.float32)[:, None, None]
        bg = np.float32([0.52, 0.90, 0.80]) * (1 - 0.18 * yy) + np.float32([0.0, 0.0, 0.04]) * yy
        n = L.brush_noise((ch, cw), 41, scale=2.5, angle=0.1, stretch=8)[..., None]
        bg = bg * (1 + 0.035 * n)
        return np.ascontiguousarray(np.broadcast_to(bg, (ch, cw, 3))).astype(np.float32)

    def phone_canvas(self, fh):
        cv = self.phone_bg.copy()
        ch, cw = cv.shape[:2]
        v = self.balance(fh)
        zero = v <= 0.004
        # header strip + label bar (no text: shapes read as an app at this size)
        cv[22:70] = cv[22:70] * 0.55 + np.float32([0.10, 0.22, 0.26]) * 0.45
        cv[96:112, 30:150] = np.float32([0.16, 0.30, 0.34])
        col = (140, 30, 46) if zero else (34, 22, 52)
        num = O.counter_rgba(v, fmt="${:,.2f}", size=92, color=col, seed=9)
        sc = min(1.0, (cw - 24) / num.shape[1])
        num = cv2.resize(num, (int(num.shape[1] * sc), int(num.shape[0] * sc)), interpolation=cv2.INTER_AREA)
        T.over(cv, num, (cw - num.shape[1]) / 2, 128)
        # a sparkline that falls with the balance
        frac = v / self.balance0
        pts = [(30 + i * 24, 360 - 70 * frac - 18 * math.sin(i * 1.3) * frac) for i in range(11)]
        cv2.polylines(cv, [np.int32(pts)], False, (0.62, 0.18, 0.26) if frac < 0.5 else (0.14, 0.42, 0.40), 6, cv2.LINE_AA)
        if zero:
            k = fh - (self.f_roll_end + 2)
            flash = {0: 0.55, 2: 0.30, 4: 0.18}.get(k, 0.12)
            cv = cv * (1 - flash) + np.float32([0.95, 0.32, 0.38]) * flash
        return np.clip(cv, 0, 1)

    def _phone(self, rgb, pl, fh):
        a = pl["a"].copy()
        cv = self.phone_canvas(fh)
        c = screen_light(cv)
        ratio = np.clip(1 + 0.75 * (c / np.maximum(self.phone.c0, 1e-3) - 1), 0.3, 1.8).astype(np.float32)
        rgb = pl["un_t"] + (rgb - pl["un_t"]) * ratio
        self.phone.place(rgb, a, cv, glass=0.25)
        return rgb, a

    # ------------------------------------------------------------ overlays
    def _overlays(self, img, f, Fl):
        self.draw_year_tag(img, f)
        fh = f - f % 2
        if fh < self.f_19:
            return
        x, y = self.overlays["counter_xy"]
        v = round(O.roll_value(f, self.f_price, self.f_roll_end, 19.99, 49.99, ease="inout"), 2)
        num = O.counter_rgba(v, size=150, seed=5).copy()
        # the fire under-lights the price: warm on its lower half, pulsing with the flare
        hgt = num.shape[0]
        yy = np.linspace(0, 1, hgt, dtype=np.float32)[:, None, None]
        warm = (0.10 + 0.22 * Fl) * np.clip((yy - 0.35) / 0.65, 0, 1)
        num[..., :3] = np.clip(num[..., :3] * (1 + warm * np.float32([0.25, -0.05, -0.30])), 0, 1)
        # firelight rim on the edges facing the set (right and below), stronger on a flare
        al = num[..., 3]
        sh = np.zeros_like(al)
        sh[:-4, :-5] = al[4:, 5:]
        rim = np.clip(al - sh, 0, 1) * (al > 0.5)
        xx = np.linspace(0.3, 1.0, num.shape[1], dtype=np.float32)[None, :]
        rim = (rim * xx * (0.45 + 0.55 * Fl))[..., None]
        num[..., :3] = num[..., :3] * (1 - rim) + np.float32([1.0, 0.56, 0.24]) * rim
        k = fh - self.f_roll_end
        bump = {0: 1.10, 2: 0.97}.get(k, 1.0)
        if fh < self.f_19 + 6:
            O.draw_pop(img, num, x, y, f, self.f_19)
        else:
            p, ox, oy = T.transform_rgba(num, bump, 0, origin=(20, num.shape[0] / 2))
            T.over(img, p, x + ox, y + oy)
        # the invented rise: its scenario chip is on screen from the first changed digit onward
        if f >= self.f_scen:
            O.draw_pop(img, O.scenario_label(32), x + 22, y + num.shape[0] - 36, f, self.f_scen)
        self._balance_card(img, f, Fl)

    # ------------------------------------------------------------ balance card
    @cached_property
    def card_xy(self):
        x0, y0, x1, y1 = safe_box()
        return x0 + 4, 1150

    def card_rgba(self, v, fh):
        zero = v <= 0.004
        w, h = 560, 290
        card = O.painted_swatch(w, h, seed=121, color=(0.10, 0.05, 0.13), opacity=0.94, rough=0.12, radius=14)
        a_lab = O._text_alpha("Balance", T.sans(30, 600), min_cap=0)
        lab, pad = T.styled_text_rgba(a_lab, (226, 214, 236), seed=122, shadow_off=(1, 1), soft_shadow=2,
                                      shadow_strength=0.35, grad=0.03)
        T.over_rgba(card, lab, 30 - pad, 24 - pad)
        col = (236, 84, 92) if zero else (250, 240, 226)
        num = O.counter_rgba(round(v, 2), fmt="${:,.2f}", size=118, color=col, seed=9)
        sc = min(1.0, (w - 60) / num.shape[1])
        if sc < 1:
            num = cv2.resize(num, (int(num.shape[1] * sc), int(num.shape[0] * sc)), interpolation=cv2.INTER_AREA)
        T.over_rgba(card, num, 24, 66)
        # the line of the balance falling
        frac = v / self.balance0
        pts = [(30 + i * 27, h - 28 - 30 * frac - 7 * math.sin(i * 1.4) * frac) for i in range(11)]
        cv2.polylines(card, [np.int32(pts)], False, (0.86, 0.28, 0.32, 0.95) if frac < 0.6 else (0.30, 0.78, 0.70, 0.95), 5, cv2.LINE_AA)
        if zero:
            k = fh - (self.f_roll_end + 2)
            flash = {0: 0.50, 2: 0.28, 4: 0.14}.get(k, 0.08)
            card[..., :3] = card[..., :3] * (1 - flash) + np.float32([0.95, 0.30, 0.36]) * flash
        out, pad = O.card_with_shadow(card, seed=7, underlight=(1.0, 0.50, 0.20))
        return out, pad

    def _balance_card(self, img, f, Fl):
        fh = f - f % 2
        if fh < self.f_card:
            return
        v = self.balance(fh)
        rgba, pad = self.card_rgba(v, fh)
        x, y = self.card_xy
        # it springs out of the phone on the table (bottom-left)
        O.draw_pop(img, rgba, x - pad, y - pad, f, self.f_card, origin=(pad + 30, rgba.shape[0] - pad))
        O.draw_pop(img, O.scenario_label(32), x + 330, y + 236, f, self.f_card + 2)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.55 + 0.25 * info["flare"], "vignette": 0.34}

    # ------------------------------------------------------------ events + sound
    def events(self):
        ev = [(self.f0, "cut", {})]
        for fi in self.impacts:
            ev.append((fi - 8, "windup", {}))
            ev.append((fi - 1, "thrust", {}))
            ev.append((fi + HOLD_A + 2, "recover", {}))
            ev.append((fi, "load_big" if fi in self.big else "load", {}))
        ev.append((self.f_19, "price_in", {}))
        ev.append((self.f_price, "price_roll", {}))
        ev.append((self.f_roll_end, "price_lands", {}))
        ev.append((self.f_card, "card_pop", {}))
        ev.append((self.f_roll_end + 2, "balance_zero", {}))
        for it in self.launches:
            if it["kind"] == "note" and not it["into"]:
                ev.append((it["f"] + 2, "note_flutter", {}))
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(K.fire_roar(dur + 0.8), t0 - 0.2, -21)
        snd.bed(A.room_tone(dur + 0.5), t0, -32)
        for f, kind, info in self.events():
            t = snd.at_frame(f)
            if kind == "windup":
                snd.sfx(K.scrape(f, 0.26), t, -26, 0.15)
            elif kind == "thrust":
                snd.sfx(A.swish(0.16, f), t, -24, 0.25)
            elif kind == "load":
                snd.sfx(K.whump(f, 1.0), t, -15, 0.2)
                snd.sfx(K.paper_flutter(f + 1, 0.4), t + 0.03, -27, 0.3)
                snd.sfx(A.soft_click(900, f), t, -25, 0.2)
            elif kind == "load_big":
                snd.sfx(K.whump(f, 1.6), t, -11, 0.15)
                snd.sfx(K.paper_flutter(f + 1, 0.6), t + 0.03, -24, 0.3)
            elif kind == "note_flutter":
                snd.sfx(K.paper_flutter(f + 9, 0.5), t, -29, -0.4)
            elif kind == "price_in":
                snd.sfx(A.tick(f, 2400), t, -24, -0.4)
            elif kind == "price_lands":
                snd.sfx(K.register_ching(f), t, -13, -0.2)
            elif kind == "card_pop":
                snd.sfx(A.soft_click(1500, f), t, -22, -0.5)
                snd.sfx(A.tick(f + 3, 3400), t + 0.04, -27, -0.5)
            elif kind == "recover":
                snd.sfx(A.swish(0.14, f), t, -29, 0.1)
            elif kind == "balance_zero":
                snd.sfx(A.thunk(f), t, -18, -0.5)
        # odometer ticks: one per drawing while the price rolls, and quicker phone ticks under it
        prev = None
        for f in range(self.f_price, self.f_roll_end + 2, 2):
            v = round(O.roll_value(f, self.f_price, self.f_roll_end, 19.99, 49.99), 2)
            if v != prev:
                snd.sfx(A.tick(f + 5, 2700 + (f - self.f_price) * 30), snd.at_frame(f), -23, -0.35)
            prev = v
        for f in range(self.f_price, self.f_roll_end + 2, 2):
            snd.sfx(A.tick(f + 77, 4200), snd.at_frame(f) + 0.02, -31, -0.6)


def make(ctx):
    return Shot(ctx)
