"""Shot 2, Year 1: a kid doomscrolling in bed; the phone is the key light. The daily limit
notification lands, the screen dies, then the block's windows go out in a ripple."""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif import ui_phone as U
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.poses import PoseSwap
from whatif.config import FPS, safe_box
from whatif.timing import Track, even_frame_of, on2s

from . import s02_year1_spec as SPEC

SC = L.WORK_SCALE


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def teal_weight(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    tw = np.clip((np.minimum(g, b) - r + 0.02) / 0.22, 0, 1)
    tw = tw * np.clip((rgb.max(2) - 0.08) / 0.25, 0, 1)
    return cv2.GaussianBlur(tw.astype(np.float32), (0, 0), 3)


def unlit(rgb):
    """The same surface with the phone's light removed: deep violet, low value."""
    lum = rgb @ np.float32([0.30, 0.50, 0.20])
    return lum[..., None] * np.float32([0.52, 0.36, 0.78]) * 0.62


SWIPE_FEED = [(0, 0.0), (2, 0.10), (4, 0.52), (6, 0.90), (8, 1.0)]           # frames after swipe start
SWIPE_THUMB = [(-6, 0.0), (-4, -1.8), (-2, -2.2), (0, -1.0), (2, 3.5), (4, 8.5), (6, 9.5), (8, 4.0), (10, 0.0)]
NOTE_DROP = [(0, -1.15), (2, 0.25), (4, -0.06), (6, 0.0)]                     # card y in card heights


def _key_interp(keys, x):
    if x <= keys[0][0]:
        return keys[0][1]
    for (a, va), (b, vb) in zip(keys, keys[1:]):
        if x <= b:
            return va + (vb - va) * (x - a) / (b - a)
    return keys[-1][1]


class Year1Shot:
    name = SPEC.SHOT
    pose = None

    def __init__(self, f0, f1, T_):
        self.f0, self.f1 = f0, f1
        self.f_swipes = [even_frame_of(t) for t in T_["swipes"]]
        self.f_tiktok = even_frame_of(T_["tiktok"])
        self.f_note = even_frame_of(T_["notify"])
        self.f_off = even_frame_of(T_["screen_off"])
        self.f_win = even_frame_of(T_["windows"])
        L.build(SPEC.SHOT, SPEC.KEY, SPEC.DEPTH, SPEC.PLANES, SPEC.SPRITES)
        self.lay = L.Layers(SPEC.SHOT)
        W, H = self.lay.W, self.lay.H
        dur = (f1 - f0) / FPS
        self.cam = ParallaxCamera(
            W, H, focus=Track([(0, (W * 0.5, H * 0.5)), (dur, (W * 0.56, H * 0.53), "inout")]), nearness=nearness,
            zoom=Track([(0, 1.0), (dur, 1.10, "inout")]),
            push=Track([(0, 0.0), (dur, 0.085, "inout")]),
            rise=Track([(0, 0.0), (dur, -18.0, "inout")]))

    # ------------------------------------------------------------ prepared
    @cached_property
    def screen(self):
        """Screen mask (working res, soft, rounded corners) and its quad (TL, TR, BR, BL)."""
        key = cv2.cvtColor(cv2.imread(str(SPEC.KEY)), cv2.COLOR_BGR2RGB)
        H0, W0 = key.shape[:2]
        k = cv2.resize(key, (self.lay.W, self.lay.H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        r, g, b = k[..., 0], k[..., 1], k[..., 2]
        m = ((g > 0.70) & (b > 0.62) & (r < 0.62)).astype(np.uint8)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
        i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        m = (lab == i).astype(np.uint8)
        cnt, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        hull = cv2.convexHull(max(cnt, key=cv2.contourArea))
        full = np.zeros_like(m)
        cv2.fillConvexPoly(full, hull, 1)
        cnt, _ = cv2.findContours(full, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        pts = max(cnt, key=cv2.contourArea)[:, 0, :].astype(np.float32)
        peri = cv2.arcLength(pts[:, None, :], True)
        quad = None
        for eps in np.linspace(0.01, 0.1, 30):
            ap = cv2.approxPolyDP(pts[:, None, :], eps * peri, True)
            if len(ap) == 4:
                quad = ap[:, 0, :].astype(np.float32)
                break
        c = quad.mean(0)
        quad = quad[np.argsort(np.arctan2(quad[:, 1] - c[1], quad[:, 0] - c[0]))]
        quad = np.roll(quad, -int(np.argmin(quad.sum(1))), axis=0)
        # refine each edge with a line fit through the contour's straight middle part, then intersect
        lines = []
        for j in range(4):
            a, b2 = quad[j], quad[(j + 1) % 4]
            d = b2 - a
            ln = np.linalg.norm(d)
            u = ((pts - a) @ d) / (ln * ln)
            e = d / ln
            dist = np.abs(e[0] * (pts[:, 1] - a[1]) - e[1] * (pts[:, 0] - a[0]))
            sel = pts[(u > 0.2) & (u < 0.8) & (dist < 12)]
            vx, vy, x0, y0 = cv2.fitLine(sel, cv2.DIST_HUBER, 0, 0.01, 0.01).ravel()
            lines.append((np.array([x0, y0]), np.array([vx, vy])))
        q = []
        for j in range(4):
            (p1, d1), (p2, d2) = lines[j - 1], lines[j]
            A = np.array([d1, -d2]).T
            s = np.linalg.solve(A, p2 - p1)
            q.append(p1 + d1 * s[0])
        quad = np.float32(q)
        # cover every painted teal pixel (the screen's soft painted edge) so no teal ring survives
        soft = cv2.GaussianBlur(cv2.dilate(full.astype(np.float32), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))), (0, 0), 1.0)
        c0 = k[m > 0].mean(0)                       # the painted screen colour = the reference key light
        cq = quad.mean(0)
        big = cq + (quad - cq) * 1.025                # content overscans the painted screen edge
        Hm = cv2.getPerspectiveTransform(np.float32([[0, 0], [U.CW, 0], [U.CW, U.CH], [0, U.CH]]), big)
        ys, xs = np.where(full > 0)
        bbox = (xs.min() - 8, ys.min() - 8, xs.max() + 9, ys.max() + 9)
        return {"mask": soft, "quad": quad, "c0": c0, "H": Hm, "bbox": bbox}

    @cached_property
    def planes(self):
        out = []
        for i, p in enumerate(self.lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            pl = {"rgb": rgb, "a": p["a"].astype(np.float32) / 255,
                  "n": nearness(p["d"].astype(np.float32) / 65535)}
            if i >= 1:
                tw = teal_weight(rgb)
                if i == 2:
                    tw = tw * (1 - self.screen["mask"])
                pl["tw"] = tw
                pl["unlit_w"] = rgb * (1 - tw[..., None]) + unlit(rgb) * tw[..., None]
            out.append(pl)
        self._prep_city(out[0])
        return out

    def _prep_city(self, pl):
        """Warm windows across the street: masks, an unlit plate, and bokeh (close-up depth of field)."""
        rgb = pl["rgb"]
        Hh, Ww = rgb.shape[:2]
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        # Lit windows: bright warm blobs (strict test for the big ones, local contrast for the faint,
        # haze-tinted ones). g > 0.48 r rejects the magenta neon rim on the window frame.
        lum = 0.3 * r + 0.6 * g + 0.1 * b
        bg = cv2.GaussianBlur(lum, (0, 0), 18 * SC)
        strict = (r - b > 0.08) & (r > 0.36) & (r > g)
        faint = (r - b > 0.03) & (r > 0.26) & (lum - bg > 0.03)
        warm = (strict | faint) & (g > 0.48 * r)
        x0, y0, x1, y1 = [int(v * SC) for v in SPEC.WINDOW_REGION]
        nb = [int(v * SC) for v in SPEC.NEON_BOX]
        region = np.zeros_like(warm)
        region[y0:y1, x0:x1] = True
        region[nb[1]:nb[3], nb[0]:] = False
        warm &= region
        warm = cv2.morphologyEx(warm.astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
        n, lab, stats, cents = cv2.connectedComponentsWithStats(warm)
        wins = []
        for i in range(1, n):
            _, _, ww, hh, area = stats[i]
            # windows are compact blobs; long thin pieces are rim light on the frame
            if area < 25 or max(ww, hh) / max(1, min(ww, hh)) > 4.5 or area / (ww * hh) < 0.3:
                continue
            m = (lab == i).astype(np.uint8)
            m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))  # catch the glow edge
            wins.append({"m": m > 0, "c": cents[i]})
        allm = np.zeros((Hh, Ww), np.float32)
        for w in wins:
            allm[w["m"]] = 1
        grow = cv2.dilate(allm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13)))
        off = L.textured_fill(rgb, grow < 0.5, seed=91, amp_scale=0.6)
        off = rgb * (1 - grow[..., None]) + off * 0.9 * grow[..., None]
        disc = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)).astype(np.float32)
        disc /= disc.sum()
        pl["lit_b"] = cv2.filter2D(rgb, -1, disc)
        pl["off_b"] = cv2.filter2D(off, -1, disc)
        # ripple order: from the left edge of the block outward, two to four windows per drawing
        origin = np.array([x0, (y0 + y1) * 0.55])
        wins.sort(key=lambda w: np.linalg.norm(w["c"] - origin))
        steps = 8
        for j, w in enumerate(wins):
            w["off"] = self.f_win + 2 * int(j * steps / max(len(wins), 1))
            g = cv2.filter2D(cv2.dilate(w["m"].astype(np.float32), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))), -1, disc)
            ys, xs = np.where(g > 0.01)
            w["box"] = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
            w["g"] = g[w["box"][1]:w["box"][3], w["box"][0]:w["box"][2]]
            del w["m"]
        self.windows = wins

    @cached_property
    def thumb(self):
        return self.lay.sprites[self.lay.sprite_index("thumb")]

    @cached_property
    def overlays(self):
        x0, y0, x1, y1 = safe_box()
        yt = O.year_tag(1)
        dt = O.data_tag("TikTok: about 2 billion users (est.)", size=44)
        big = U.notification_rgba(int(x1 - x0 - 20), scale=1.48)
        big, bpad = O.card_with_shadow(big, seed=3, underlight=(0.22, 0.40, 0.95))
        return {"year": (yt, x0 - 10, y0 - 14), "data": (dt, x0 - 6, y0 + yt.shape[0] - 30),
                "big": (big, x0 + 10 - bpad, int(0.165 * 1920) - bpad)}

    # ------------------------------------------------------------ state
    def feed_state(self, f):
        fh = f - f % 2
        pos, smear = 0.0, 0.0
        for k, fs in enumerate(self.f_swipes):
            d = fh - fs
            v = _key_interp(SWIPE_FEED, d)
            pos += v
            if d == 4:
                smear = 0.35
        return pos, smear

    def thumb_angle(self, f):
        fh = f - f % 2
        return sum(_key_interp(SWIPE_THUMB, fh - fs) for fs in self.f_swipes)

    def canvas(self, f):
        if getattr(self, "_cv", (None,))[0] == f:
            return self._cv[1]
        cv = self._canvas(f)
        self._cv = (f, cv)
        return cv

    def _canvas(self, f):
        pos, smear = self.feed_state(f)
        cv = U.feed_canvas(pos, smear)
        if f >= self.f_note:
            note = U.notification_rgba(U.CW - 36, scale=1.0)
            fh = f - f % 2
            yy = _key_interp(NOTE_DROP, fh - self.f_note)
            y = int(30 + yy * note.shape[0])
            T.over(cv, note, 18, y)
            # the rest of the screen dims a touch behind the system card
            cv[y + note.shape[0]:] *= 0.86 if fh - self.f_note >= 2 else 1.0
        return cv

    # --------------------------------------------------------------- frame
    def frame(self, f):
        lf = f - self.f0
        t = lf / FPS
        planes = self.planes
        scr = self.screen
        on = f < self.f_off
        if on:
            cv = self.canvas(f)
            c = U.screen_light(cv)
            ratio = np.clip(1 + 0.75 * (c / np.maximum(scr["c0"], 1e-3) - 1), 0.2, 2.2).astype(np.float32)
            bright = float(np.clip(c.mean() / scr["c0"].mean(), 0.5, 1.2))
            ratio = ratio * (0.6 + 0.4 * bright)
        else:
            ratio = np.zeros(3, np.float32)
        rps = []
        for i, pl in enumerate(planes):
            if i == 0:
                rgb = self._city(f, pl)
            else:
                rgb = pl["unlit_w"] + (pl["rgb"] - pl["unlit_w"]) * ratio
                if not on:
                    rgb = rgb * 0.92
            a = pl["a"]
            n = pl["n"]
            st = "A"
            if self.pose is not None and i == 2 and not on:      # the reaction when the screen dies
                st = PoseSwap.state(f, [(self.f_off + 6, "B")])
            if i == 2:
                a = a.copy()
                rgb = rgb.copy() if rgb is pl["rgb"] else rgb
                if st != "A":                                    # face (eyes wide) before the dead glass
                    n = self.pose.nearness(n, pl["a"], st)
                    rgb, a = self.pose.apply(rgb, a, st, src=self._pose_dark(st))
                self._screen_into(rgb, a, f, on)
                if st == "A":
                    spr = dict(self.thumb)
                    srgba = self.thumb["rgba"].astype(np.float32) / 255
                    tw = teal_weight(srgba[..., :3])[..., None]
                    un = srgba[..., :3] * (1 - tw) + unlit(srgba[..., :3]) * tw
                    srgba[..., :3] = un + (srgba[..., :3] - un) * ratio * (0.92 if not on else 1.0)
                    spr["rgba"] = srgba
                    patch, x0, y0 = deform_sprite(spr, angle_deg=self.thumb_angle(f))
                    composite_into(rgb, a, patch, x0, y0)
                else:                                            # pose B's thumb, lifted off the dead glass
                    hm, hc = self._pose_thumb(st)
                    rgb = rgb * (1 - hm[..., None]) + hc * hm[..., None]
                    a = np.maximum(a, hm)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._overlays(img, f)
        return img, {"on": on}

    def _pose_thumb(self, st):
        """Pose B's thumb over the screen (mask, unlit colour): B's not-screen pixels inside the phone glass."""
        cache = self.__dict__.setdefault("_pose_thumb_cache", {})
        if st not in cache:
            img = self.pose.image(st)
            sc = L.WORK_SCALE
            box = np.zeros(img.shape[:2], np.float32)
            box[int(1250 * sc):int(1800 * sc), int(840 * sc):int(1260 * sc)] = 1
            hm = SPEC.not_screen(img, None).astype(np.float32) * box * (self.screen["mask"] > 0.5)
            hm = cv2.GaussianBlur(cv2.morphologyEx(hm, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)), (0, 0), 1.2)
            hc = unlit(img) * 0.92
            # same brightness as pose A's thumb sprite after screen-off, so the thumb does not flash darker
            sr = self.thumb["rgba"].astype(np.float32) / 255
            tw = teal_weight(sr[..., :3])[..., None]
            ref = (sr[..., :3] * (1 - tw) + unlit(sr[..., :3]) * tw)[sr[..., 3] > 0.5].mean(0)
            cur = hc[hm > 0.5].mean(0) if (hm > 0.5).any() else ref
            hc = np.clip(hc * (ref.mean() / max(float(cur.mean()), 1e-3)), 0, 1)
            cache[st] = (hm, hc)
        return cache[st]

    def _pose_dark(self, st):
        """Pose B (or its in-between) with the screen light removed, like the planes after screen-off."""
        cache = self.__dict__.setdefault("_pose_dark_cache", {})
        if st not in cache:
            img = self.pose.image(st)
            tw = teal_weight(img) * (1 - self.screen["mask"])
            cache[st] = (img * (1 - tw[..., None]) + unlit(img) * tw[..., None]) * 0.92
        return cache[st]

    def _city(self, f, pl):
        rgb = pl["lit_b"].copy()
        fh = f - f % 2
        for w in self.windows:
            if fh >= w["off"]:
                x0, y0, x1, y1 = w["box"]
                g = w["g"][..., None]
                rgb[y0:y1, x0:x1] = rgb[y0:y1, x0:x1] * (1 - g) + pl["off_b"][y0:y1, x0:x1] * g
        return rgb

    def _screen_into(self, rgb, a, f, on):
        scr = self.screen
        x0, y0, x1, y1 = scr["bbox"]
        Tm = np.float32([[1, 0, -x0], [0, 1, -y0], [0, 0, 1]]) @ scr["H"]
        if on:
            cv = self.canvas(f)
            cv = cv * 1.04
        else:
            # dead glass: near-black blue with a faint window reflection sheen
            yy = np.linspace(0, 1, U.CH, dtype=np.float32)[:, None, None]
            xx = np.linspace(0, 1, U.CW, dtype=np.float32)[None, :, None]
            sheen = np.clip(1 - np.abs((xx * 0.8 + yy * 0.5) - 0.45) * 5, 0, 1) * 0.05
            cv = np.float32([0.035, 0.03, 0.06]) + sheen * np.float32([0.6, 0.4, 0.9]) + 0 * yy * xx
        patch = cv2.warpPerspective(cv.astype(np.float32), Tm, (x1 - x0, y1 - y0), flags=cv2.INTER_AREA)
        m = scr["mask"][y0:y1, x0:x1, None]
        # glass: a soft inner edge darkening and a slight cool sheen so the screen sits in the bezel
        edge = cv2.GaussianBlur(cv2.erode(m[..., 0], np.ones((9, 9), np.uint8)), (0, 0), 4)[..., None]
        patch = patch * (0.80 + 0.20 * edge)
        rgb[y0:y1, x0:x1] = rgb[y0:y1, x0:x1] * (1 - m) + patch * m
        a[y0:y1, x0:x1] = np.maximum(a[y0:y1, x0:x1], m[..., 0])

    def _overlays(self, img, f):
        fh = f - f % 2
        yt, x, y = self.overlays["year"]
        s = T.pop_scale((fh - (self.f0 + 2)) / FPS)
        if s is not None:
            p, ox, oy = T.transform_rgba(yt, s, 0, origin=(20, yt.shape[0] / 2))
            O.seat(img, p, x + ox, y + oy)
        dt, x, y = self.overlays["data"]
        f_out = self.f_note - 6
        if self.f_tiktok <= fh < f_out + 6:
            s = T.pop_scale((fh - self.f_tiktok) / FPS)
            if fh >= f_out:                                  # pop out: quick shrink on 2s
                s = {0: 1.06, 2: 0.7, 4: 0.3}.get(fh - f_out, 0.0)
            if s and s > 0.05:
                p, ox, oy = T.transform_rgba(dt, s, 0, origin=(20, dt.shape[0] / 2))
                O.seat(img, p, x + ox, y + oy)
        big, x, y = self.overlays["big"]
        if self.f_note + 2 <= fh < self.f_off:
            d = fh - (self.f_note + 2)
            # springs out of the phone: from the screen top, overshoot, settle
            phone = self.cam.screen_point(self.screen["quad"].mean(0) * np.float32([1, 0.8]), 0.38, (f - self.f0) / FPS)
            keys = {0: (0.35, 0.55), 2: (1.08, 0.96), 4: (0.97, 1.0)}
            sc, k = keys.get(d, (1.0, 1.0))
            cx = x + big.shape[1] / 2
            cy = y + big.shape[0] / 2
            px, py = phone
            tx, ty = px + (cx - px) * k, py + (cy - py) * k
            p, ox, oy = T.transform_rgba(big, sc, 0)
            O.seat(img, p, tx - big.shape[1] / 2 + ox, ty - big.shape[0] / 2 + oy, glow=(0.25, 0.75, 0.85))
        return img

    def finish_args(self, f, info):
        return {"bloom_strength": 0.55 if info["on"] else 0.35}

    def events(self):
        ev = [(self.f0, "cut", {})]
        for fs in self.f_swipes:
            ev.append((fs, "swipe", {}))
        ev.append((self.f_tiktok, "data_tag", {}))
        ev.append((self.f_note, "notify", {}))
        ev.append((self.f_note + 2, "card_pop", {}))
        ev.append((self.f_off, "screen_off", {}))
        offs = sorted({w["off"] for w in self.windows})
        for k, fo in enumerate(offs):
            ev.append((fo, "window_off", {"k": k, "n": len(offs)}))
        return ev


# ------------------------------------------------------------------ episode interface
HOLD_AFTER_RIPPLE = 10       # frames between the last window going dark and the cut


def make(ctx):
    """Year 1 timed from its narration line. Swipes on "thing", "doomscrolling", just after "TikTok's";
    data tag on "TikTok's"; notification on "daily". The tail is laid out backwards from the cut:
    hold, window ripple (8 drawings on 2s) starting 10 frames after the screen dies, which is about
    0.75 s of near silence after the last word (pass 4: the old 0.75 s pause after the screen died read
    as a dead tail)."""
    f_win = ctx.f1 - HOLD_AFTER_RIPPLE - 14
    f_off = f_win - 10
    T_ = {"swipes": [ctx.t("thing") - 0.02, ctx.t("doomscrolling") + 0.02, ctx.t("TikTok's") + 0.20],
          "tiktok": ctx.t("TikTok's"),
          "notify": even_frame_of(ctx.t("daily")) / FPS,
          "screen_off": f_off / FPS,
          "windows": f_win / FPS}
    shot = Year1Shot(ctx.f0, ctx.f1, T_)
    shot.ctx = ctx
    # y01_tiktok_poseB.png (if painted): the kid's face reacts when the screen dies (phone excluded)
    shot.pose = PoseSwap.for_shot(ctx, "s02_year1", region=[(0, 250), (560, 250), (620, 700), (620, 1900), (0, 1900)])
    if (shot.f_off - shot.f_note) / FPS < 0.85:
        print(f"[s02_year1] warning: the limit card shows only {(shot.f_off - shot.f_note) / FPS:.2f} s; "
              f"raise the shot's gap in timeline.py")
    return shot


def _year1_sound(self, snd):
    """Room tone, distant city, swipe ticks, data-tag tick, two-note chime, screen-off thunk, window clicks."""
    from whatif import audio as A
    t_cut = self.f0 / FPS
    dur = (self.f1 - self.f0) / FPS + 0.3
    tt2 = A.t_axis(dur) + t_cut
    rt_gain = np.where(tt2 < self.f_off / FPS, 1.0, 0.45)
    snd.bed(A.room_tone(dur) * A.lowpass(rt_gain, 20), t_cut, -30)
    city_gain = np.clip(1 - (tt2 - self.f_win / FPS) / 1.2, 0.35, 1.0) * np.where(tt2 < self.f_off / FPS, 1.0, 0.6)
    snd.bed(A.city_hum(dur) * A.lowpass(city_gain, 20), t_cut, -31, pan=0.25)
    for f, kind, info in self.events():
        t = f / FPS
        if kind == "swipe":
            snd.sfx(A.tick(f, 3000), t, -19, 0.15)
            snd.sfx(A.swish(0.24, f), t, -29, 0.1)
        elif kind == "data_tag":
            snd.sfx(A.tick(f, 2200), t, -27, -0.4)
        elif kind == "notify":
            snd.sfx(A.bell(1046.5, 0.9), t, -13, 0.1)
            snd.sfx(A.bell(1568.0, 1.1), t + 3 / FPS, -14, 0.1)
        elif kind == "screen_off":
            snd.sfx(A.thunk(), t, -9)
        elif kind == "window_off":
            k = info["k"]
            snd.sfx(A.soft_click(1500 * (0.86 ** k), f), t, -17 - k * 0.8, 0.5 - 0.12 * k)


Year1Shot.sound = _year1_sound
