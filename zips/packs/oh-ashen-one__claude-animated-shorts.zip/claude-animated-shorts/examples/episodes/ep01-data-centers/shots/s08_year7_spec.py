"""Geometry for shot 8 (Year 7, the wall of family photos being dissolved and repossessed). Key-image px of the
upscaled key work/keys/y07_photos_key.png (1520 x 2701)."""
import cv2
import numpy as np

from whatif.layers import WORK_SCALE, PlaneSpec, SpriteSpec

SC = WORK_SCALE

# the tired parent on the floor (lower left) and the phone in their hand; the gloved arms are excluded
PARENT_REGION = [(0, 1560), (600, 1560), (640, 2040), (1520, 2040), (1520, 2701), (0, 2701)]

PLANES = [
    PlaneSpec("wall", 0.0, 1.01, fill="full"),
    PlaneSpec("parent", 0.40, 1.01, radius=80, region=PARENT_REGION),
]

# the photo being lifted off its nail, with the two gloved hands and arms reaching in from the right
LIFT_POLY = [(990, 1074), (1030, 1058), (1062, 1036), (1150, 1034), (1185, 1040), (1296, 1006), (1330, 1046),
             (1390, 1062), (1440, 1080), (1490, 1096), (1520, 1104), (1520, 1272), (1475, 1258), (1425, 1215),
             (1398, 1200), (1400, 1300), (1402, 1372), (1430, 1395), (1480, 1412), (1520, 1420), (1520, 1625),
             (1450, 1580), (1380, 1520), (1310, 1470), (1240, 1446), (1160, 1436), (1075, 1446), (1052, 1420)]
LIFT_PIVOT = (1200, 1230)
LIFT_FRAME_QUAD = [(1000, 1078), (1302, 1015), (1382, 1370), (1070, 1430)]   # outer corners TL TR BR BL
NAILS = [(1057, 1022), (1145, 1024)]
LIFT_WIRE = [(1040, 1036), (1160, 1032), (1190, 1046), (1010, 1078)]


def lift_mask(img, depth):
    """The frame (its quad, a little wider), the hanging wire, and the arms (nearer than the wall)."""
    H, W = img.shape[:2]
    m = np.zeros((H, W), np.uint8)
    q = np.int32([[x * SC, y * SC] for x, y in LIFT_FRAME_QUAD])
    cv2.fillConvexPoly(m, q, 1)
    m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
    cv2.fillConvexPoly(m, np.int32([[x * SC, y * SC] for x, y in LIFT_WIRE]), 1)
    arms = (depth > 0.14).astype(np.uint8)
    arms = cv2.morphologyEx(arms, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    return (m > 0) | (arms > 0)

# price tags: (string top = swing pivot, tag body bbox x0 y0 x1 y1)
TAGS = [
    ((314, 750), (291, 790, 334, 876)),
    ((724, 700), (705, 731, 744, 809)),
    ((1082, 681), (1065, 718, 1102, 793)),
    ((62, 1055), (34, 1095, 87, 1188)),
    ((385, 1298), (363, 1325, 404, 1404)),
    ((751, 1101), (732, 1135, 771, 1211)),
    ((76, 1511), (53, 1546, 95, 1629)),
    ((758, 1484), (737, 1514, 776, 1591)),
    ((533, 1718), (513, 1752, 553, 1831)),
    ((843, 1868), (825, 1910, 867, 1994)),
    ((1137, 1400), (1096, 1437, 1141, 1516)),
    ((1273, 1824), (1252, 1857, 1294, 1954)),
]
LIFT_TAG = 10                     # index of the tag hanging from the lifted photo


def _tag_mask_fn(pivot, box):
    px, py = pivot
    bx0, by0, bx1, by1 = box

    def fn(img, depth):
        H, W = img.shape[:2]
        out = np.zeros((H, W), bool)
        x0, y0, x1, y1 = [int(round(v * SC)) for v in (bx0 - 4, by0 - 4, bx1 + 4, by1 + 4)]
        sub = img[y0:y1, x0:x1]
        cx, cy = (bx0 + bx1) / 2 * SC - x0, ((by0 + by1) / 2 + 8) * SC - y0
        ref = np.median(sub[int(cy) - 6:int(cy) + 6, int(cx) - 4:int(cx) + 4].reshape(-1, 3), 0)
        close = (np.abs(sub - ref).max(2) < 0.13).astype(np.uint8)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(close)
        if n > 1:
            j = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
            cnt, _ = cv2.findContours((lab == j).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            hull = cv2.convexHull(np.concatenate(cnt))
            m = np.zeros_like(close)
            cv2.fillConvexPoly(m, hull, 1)
            m = cv2.dilate(m, np.ones((3, 3), np.uint8))
            out[y0:y1, x0:x1] = m > 0
        # the string: light thread in a narrow strip from the pivot down to the tag
        sx0, sx1 = int((px - 9) * SC), int((px + 9) * SC)
        sy0, sy1 = int((py - 3) * SC), int((by0 + 12) * SC)
        st = img[sy0:sy1, sx0:sx1].max(2)
        thr = np.median(st, 1, keepdims=True) + 0.05
        sm = (st > thr).astype(np.uint8)
        sm = cv2.dilate(sm, np.ones((2, 2), np.uint8))
        out[sy0:sy1, sx0:sx1] |= sm > 0
        return out

    return fn


def tag_envelope(pivot, box):
    px, py = pivot
    bx0, by0, bx1, by1 = box
    return [(min(bx0, px - 10) - 6, py - 4), (max(bx1, px + 10) + 6, py - 4), (max(bx1, px + 10) + 6, by1 + 6),
            (min(bx0, px - 10) - 6, by1 + 6)]


SPRITES = [SpriteSpec("lift", 0, LIFT_POLY, dmin=0.0, pivot=LIFT_PIVOT, mask_fn=lift_mask, fill_own_plane=True)]
for _i, (_p, _b) in enumerate(TAGS):
    SPRITES.append(SpriteSpec(f"tag{_i}", 0, tag_envelope(_p, _b), dmin=0.0, pivot=_p,
                              mask_fn=_tag_mask_fn(_p, _b), fill_own_plane=True))

# photos that dissolve, in order: inner (glass) corners TL TR BR BL
PHOTOS = [
    ("mountain", [(1003, 388), (1392, 405), (1392, 715), (1003, 690)]),
    ("hat", [(606, 832), (935, 848), (935, 1100), (606, 1094)]),
    ("snow", [(606, 1222), (905, 1226), (905, 1488), (606, 1484)]),
    ("dog", [(706, 1628), (1000, 1625), (1000, 1875), (706, 1872)]),
]
EMPTY_TEX_BOX = (1165, 1600, 1360, 1800)      # the already-empty frame's backing: brushy wall paint

# zones where the painting's own teal flecks float (extracted and set drifting)
FLECK_ZONES = [(1180, 280, 1520, 1010), (1000, 740, 1520, 1010), (870, 780, 1010, 1210), (815, 1170, 1000, 1570),
               (880, 1550, 1110, 1995), (960, 1000, 1010, 1600)]

PHONE_BOX = (740, 2080, 960, 2420)
HEAD_POLY = [(0, 1640), (150, 1606), (330, 1616), (450, 1700), (505, 1820), (505, 1960), (470, 2060),
             (380, 2112), (200, 2112), (0, 2085)]
NECK_PIVOT = (330, 2085)
BUN_POLY = [(0, 1630), (120, 1600), (260, 1615), (270, 1700), (180, 1790), (0, 1800)]
BUN_PIVOT = (220, 1790)

# where the carried-off photo hung: the unfaded, paler rectangle under the right-hand nail (upright)
GHOST_RECT = (1000, 1048, 1292, 1392)

# pose B (assets/key/y07_photos_poseB.png): the parent up on the knees, reaching for the photo
POSE_B_REGION = [(0, 1200), (1090, 1200), (1090, 2701), (0, 2701)]
PHONE_B_BOX = (300, 2370, 470, 2580)
HAND_B = (1000, 1300)
SHOULDER_B = (700, 1640)
HEAD_B = (560, 1450)
KNEES_B = (450, 2450)
ARM_B_POLY = [(640, 1560), (900, 1330), (960, 1220), (1080, 1210), (1090, 1400), (980, 1450), (780, 1720),
              (680, 1730)]
