"""Shot 7, Year 6: "Your Spotify, twelve ninety-nine today, would cost more."

A hooded listener in the rain feeds coins into a coin slot built into their earbud. Each push is acted
pose to pose on 2s: the hand winds back (anticipation), one in-between drawing (eyes half shut), then the
second painted pose (finger pressing the coin home, eyes closed) on the clunk, and one in-between back. The
jolts tip coins off the open palm into the puddle. The real price "$12.99" lands on "twelve"; on "would cost"
it rolls up through invented values marked "scenario", and lands on "$?" on "more". Camera on 1s with depth
parallax (opening close on the ear); everything else on 2s.
"""
import math
from functools import cached_property
from pathlib import Path

import cv2
import numpy as np

from whatif import audio as A
from whatif import keyprep
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS, safe_box
from whatif.fx2d import ShapeCanvas, screen_emissive, star4_poly, tapered_streak_poly
from whatif.shotkit import BaseShot
from whatif.timing import Track, even_frame_of, on2s

from . import s07_year6_kit as K
from . import s07_year6_spec as SPEC

STEM = __name__.split(".")[-1]
SC = L.WORK_SCALE
EMBER = (255, 146, 72)


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def P(xy):
    """key px -> plane px"""
    return (xy[0] * SC, xy[1] * SC)


def keyed(keys, fh, default=0.0):
    """Held-drawing lookup: value of the latest key at or before fh (keys: {frame: value}); between two keys
    that are 2 frames apart this is a straight hold, so poses change only on the 2s grid."""
    best = None
    for k in sorted(keys):
        if k <= fh:
            best = keys[k]
        else:
            break
    return default if best is None else best


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, SPEC.PLANES, SPEC.SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        self._timing()
        d = ctx.dur
        # opens close on the ear for the first coin (the coin is ~80 px across there), pulls out to the street
        # after the first clunk, then drifts back in toward the face for the last frantic coins
        tl = lambda fr: (fr - self.f0) / FPS
        p1 = self.pushes[0]
        t_hold, t_out = tl(p1 + 8), tl(p1 + 30)
        u = t_out / d
        foc0 = (W * 0.50, H * 0.50)
        foc1 = P((760, 1180))
        foc_mid = (foc0[0] + (foc1[0] - foc0[0]) * u, foc0[1] + (foc1[1] - foc0[1]) * u)
        foc_ear = P((680, 1030))
        self.cam = ParallaxCamera(
            W, H, nearness=nearness,
            focus=Track([(0, foc_ear), (t_hold, foc_ear), (t_out, foc_mid, "inout"), (d, foc1, "inout")]),
            zoom=Track([(0, 1.8), (t_hold, 1.8), (t_out, 1.02, "inout"), (d, 1.12, "inout")]),
            push=Track([(0, 0.0), (t_out, 0.0), (d, 0.075, "inout")]),
            rise=Track([(0, 0.0), (t_out, 0.0), (d, -16.0, "inout")]))

    # ------------------------------------------------------------------ timing
    def _timing(self):
        ctx = self.ctx
        ons = K.speech_onsets(ctx)
        near = lambda t: min(ons, key=lambda o: abs(o - t))
        self.f_spotify = ctx.f("Spotify")
        # "twelve" starts after a 0.35 s silence: measured onset 29.54 s (frame 709); pop on the 2s frame before it
        on12 = near(K.heard_t(ctx, "$12"))
        self.f_twelve = int(math.floor(on12 * FPS)) // 2 * 2
        self.f_today = even_frame_of(K.heard_t(ctx, "day") - 0.20)
        self.f_would = even_frame_of(near(K.heard_t(ctx, "would") + 0.4))   # after the long pause
        # "more": the script time sits on the "s" of "cost"; the voiced "m" was measured at 31.38 s (frame 753)
        self.f_more = ctx.f("more") + 2
        # five coins: one on "Spotify", one on "today", one in the pause before "would" (less music for it),
        # then two frantic ones on "would" and "more"; the price rolls on "would" and "cost", "$?" on "more"
        p5 = self.f_more
        p4 = min(self.f_would, p5 - 6)
        p3 = min(p4 - 6, max(self.f_today + 12, p4 - 8))
        self.pushes = [self.f_spotify + 4, self.f_today, p3, p4, p5]
        self.f_cost = p4 + 2                                  # "cost" burst measured at 31.05 s (frame 745)
        self.music = [0.40, 0.40, 0.20, 0.10, 0.0]           # seconds of music each coin buys
        self._poses()
        self._coins()

    def _poses(self):
        p1, p2, p3, p4, p5 = self.pushes
        f0 = self.f0
        # raised hand: (dx, dy, angle, coin) with coin in {"rest", "push", "gone"}
        H = {f0: (0, 0, 0, "rest")}
        prev = f0 - 100
        for p in self.pushes:
            gap = p - prev
            if gap >= 12:          # full cycle: reload dip, rest, anticipation, push, clunk, release, settle
                if prev > f0:
                    H.update({p - 10: (12, 9, 1.3, "rest"), p - 8: (3, 2, 0.3, "rest"), p - 6: (0, 0, 0, "rest")})
                else:
                    H.update({p - 6: (2, -1, 0.15, "rest")})
                H.update({p - 4: (26, 10, 2.2, "rest"), p - 2: (-12, 1, -0.5, "push"), p: (-17, 2, -0.8, "gone"),
                          p + 2: (-4, 1, -0.2, "gone"), p + 4: (1, 0, 0.1, "gone"), p + 6: (0, 0, 0, "gone")})
            else:                  # frantic: snap back with a fresh coin, jab it in
                H.update({p - 4: (22, 12, 2.0, "rest"), p - 2: (-6, -3, -0.3, "push"), p: (-17, 2, -0.8, "gone"),
                          p + 2: (-5, 2, -0.2, "gone")})
            prev = p
        H.update({p5 + 2: (-3, 3, 0.0, "gone"), p5 + 4: (3, 6, 0.5, "gone"), p5 + 6: (2, 8, 0.7, "gone"),
                  p5 + 10: (2, 9, 0.8, "gone")})
        self.hand_keys = H
        # pose B (finger pressing the coin home, eyes shut, listening) holds while the paid music plays.
        # Each push: anticipation drawing (p-4, pose A wound back), one in-between drawing on 2s (p-2, eyes half
        # shut), pose B on the clunk; going back: one in-between (eyes half open), then pose A
        self.b_spans = []
        for i, p in enumerate(self.pushes):
            nxt = self.pushes[i + 1] if i + 1 < len(self.pushes) else None
            hold = max(4, 2 * round(self.music[i] * FPS / 2) + 2)
            end = p + 6 if nxt is None else min(p + hold, nxt - 4)
            self.b_spans.append((p, end))
        # head: clockwise degrees about the neck (+ = nod forward/down), plus dy; big enough to read on a phone
        Hd = {f0: (0.0, 0.0)}
        g = 2.2
        for p, m in zip(self.pushes[:4], (1.0, 1.0, 0.45, 0.35)):
            m *= g
            Hd.update({p - 4: (-1.1 * g, -2.5 * g), p - 2: (-0.6 * g, -1 * g),
                       p: (-0.5 * g, -1 * g), p + 2: (1.6 * m, 3 * m), p + 4: (0.6 * m, 1 * m),
                       p + 6: (1.4 * m, 3 * m), p + 8: (0.25 * m, 0), p + 10: (0.0, 0)})
        Hd.update({p5: (-0.8 * g, -3 * g), p5 + 2: (-0.4 * g, -2 * g), p5 + 4: (1.6 * g, 4 * g),
                   p5 + 6: (2.6 * g * 0.8, 7 * g * 0.8), p5 + 8: (2.3 * g * 0.8, 7 * g * 0.8),
                   p5 + 10: (2.45 * g * 0.8, 7 * g * 0.8)})
        self.head_keys = Hd
        # palm: clockwise tilt about the wrist (+ = fingers dip)
        Pm = {f0: 0.0}
        for p in self.pushes[:4]:
            Pm.update({p: -0.7, p + 2: 0.5, p + 4: 0.0})
        for r in (p2 + 2, p4 + 2):             # the jolt tips one coin off the fingers
            Pm.update({r - 2: -1.2, r: 5.0, r + 2: 2.4, r + 4: 0.8, r + 6: 0.0})
        Pm.update({p5: -1.2, p5 + 2: 9.0, p5 + 4: 12.5, p5 + 6: 11.0, p5 + 8: 9.2, p5 + 10: 8.4, p5 + 14: 8.0})
        self.palm_keys = Pm

    def pose_at(self, f):
        """'A' (painted key), 'AB' / 'BA' (one in-between drawing on 2s) or 'B' (second painted pose)."""
        for p, (s, e) in zip(self.pushes, self.b_spans):
            if p - 2 <= f < p:
                return "AB"
            if s <= f < e - 2:
                return "B"
            if e - 2 <= f < e:
                return "BA"
        return "A"

    def _coins(self):
        """Coins tipping off the palm: release frame, start offset, horizontal speed, spin rate, landing."""
        p1, p2, p3, p4, p5 = self.pushes
        rel = [p2 + 2, p4 + 2, p5 + 2, p5 + 4, p5 + 6]
        rng = np.random.default_rng(6)
        g = 4300.0 * SC                                   # plane px / s^2
        y_land = SPEC.PUDDLE_Y * SC
        self.falls = []
        for i, fr in enumerate(rel):
            spread = (-20, 10, -95, 45, -50)[i]               # the last three fan out instead of stacking
            x0 = (SPEC.TIP_FROM[0] + spread + rng.uniform(-12, 12)) * SC
            y0 = (SPEC.TIP_FROM[1] + (0, 0, 10, -15, 25)[i]) * SC
            vx = ((-70, -40, -160, 60, -110)[i] + rng.uniform(-20, 20)) * SC
            vy = rng.uniform(40, 120) * SC
            # fall time to the puddle
            a, b, c = 0.5 * g, vy, y0 - y_land
            tl = (-b + math.sqrt(b * b - 4 * a * c)) / (2 * a)
            f_land = fr + 2 * int(math.ceil(tl * FPS / 2))
            xl = x0 + vx * (f_land - fr) / FPS
            self.falls.append({"rel": fr, "x0": x0, "y0": y0, "vx": vx, "vy": vy, "g": g, "land": f_land,
                               "xl": xl, "yl": y_land + rng.uniform(-10, 12) * SC, "spin0": rng.uniform(-40, 40),
                               "rate": rng.uniform(1.6, 2.6) * (1 if i % 2 else -1), "seed": 100 + i,
                               "r": rng.uniform(50, 57) * SC})

    # ------------------------------------------------------------------ prepared plates
    @cached_property
    def planes(self):
        out = []
        for p in self.lay.planes:
            out.append({"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                        "n": nearness(p["d"].astype(np.float32) / 65535)})
        st, pe = out[0], out[1]
        Hh, Ww = st["a"].shape
        # remove the painted mid-air coins and the frozen splash: ours fall and splash on 2s
        rgb = st["rgb"]
        brass = self._brass(rgb)
        x0, y0, x1, y1 = [int(v * SC) for v in SPEC.SPLASH_BOX]
        sub = rgb[y0:y1, x0:x1]
        white = (sub.min(2) > 0.42) & ((sub.max(2) - sub.min(2)) < 0.22)
        splash = np.zeros((Hh, Ww), np.uint8)
        splash[y0:y1, x0:x1] = cv2.dilate(white.astype(np.uint8), np.ones((7, 7), np.uint8))
        for k, (x0, y0, x1, y1) in enumerate(SPEC.FALLING_COIN_BOXES):
            bx = [int(v * SC) for v in (x0, y0, x1, y1)]
            sub = brass[bx[1]:bx[3], bx[0]:bx[2]]
            n, lab, stats, _ = cv2.connectedComponentsWithStats(sub)
            if n < 2:
                continue
            j = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
            cnt, _ = cv2.findContours((lab == j).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            hull = cv2.convexHull(np.concatenate(cnt))
            m = np.zeros((Hh, Ww), np.uint8)
            cv2.fillConvexPoly(m, hull + np.int32([bx[0], bx[1]]), 1)
            m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25)))
            if k < 2:
                K.inpaint_textured(rgb, m, seed=300 + k, mode="column", grain=0.8)
            else:            # the coin in the puddle and its frozen splash go together; the ripples run sideways
                K.inpaint_textured(rgb, np.maximum(m, splash), seed=300 + k, mode="telea", radius=11, grain=0.5,
                                   angle=0.0)
        # the grey rod between slot and fingertips becomes brass plate (our coin replaces it)
        prgb = pe["rgb"]
        rod = L.poly_mask((Hh, Ww), SPEC.ROD_POLY, SC)
        K.inpaint_textured(prgb, rod > 0.3, seed=320, mode="telea", radius=4, grain=0.5)
        self._paint_slot(prgb)
        # the person plate keeps a soft rim of finger colour around the palm sprite; clear it so the tilting
        # fingers leave clean street behind, not a ghost outline
        sp = self.sprites["palm"]
        x0, y0, x1, y1 = sp["bbox"]
        m = (sp["rgba"][..., 3].astype(np.float32) / 255 > 0.02).astype(np.uint8)
        m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))).astype(np.float32)
        m = m * (sp["w"].astype(np.float32) / 255 > 0.15)
        pe["a"][y0:y1, x0:x1] *= 1 - cv2.GaussianBlur(m, (0, 0), 1.0)
        # phone screen (teal) for the music pulse, and its light spill on the jacket
        x0, y0, x1, y1 = [int(v * SC) for v in SPEC.PHONE_BOX]
        sub = prgb[y0:y1, x0:x1]
        scr = ((sub[..., 1] > 0.55) & (sub[..., 2] > 0.45) & (sub[..., 0] < 0.55)).astype(np.float32)
        scr = cv2.morphologyEx(scr, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
        scr = cv2.GaussianBlur(scr, (0, 0), 1.2)
        pe["phone"] = {"box": (x0, y0, x1, y1), "screen": scr,
                       "spill": np.clip(cv2.GaussianBlur(scr, (0, 0), 26) * 2.2, 0, 1)}
        # wet street shimmer mask (reflections below the shop line)
        x0, y0, x1, y1 = [int(v * SC) for v in SPEC.STREET_SHIMMER]
        yy = np.arange(y0, y1, dtype=np.float32)[:, None]
        ramp = np.clip((yy - y0) / (60 * SC), 0, 1)
        st["shim"] = {"box": (x0, y0, x1, y1), "w": np.broadcast_to(ramp, (y1 - y0, x1 - x0)).astype(np.float32).copy()}
        # head bone weights (head, hood, hair, ear, raised hand) ramping to zero at the shoulders
        hp = [(x * SC, y * SC) for x, y in SPEC.HEAD_POLY]
        xs, ys = zip(*hp)
        bb = (0, max(int(min(ys)) - 40, 0), min(int(max(xs)) + 60, Ww), min(int(max(ys)) + 40, Hh))
        pm = L.poly_mask((bb[3] - bb[1], bb[2] - bb[0]), [(x - bb[0], y - bb[1]) for x, y in hp])
        self.head_w = (bb, K.ramp_weight(bb, pm, P((760, 1180)), P((760, 1575)), blur=26))
        return out

    @staticmethod
    def _paint_slot(rgb):
        """Lengthen the painted coin slot so the big coin fits: a dark groove with a lit lower-right lip."""
        x = SPEC.SLOT_X * SC
        y0, y1 = [v * SC for v in SPEC.SLOT_LONG]
        X0, X1, Y0, Y1 = int(x - 12), int(x + 12), int(y0 - 10), int(y1 + 10)
        gy, gx = np.mgrid[Y0:Y1, X0:X1].astype(np.float32)
        yc = np.clip(gy, y0, y1)
        dist = np.hypot(gx - x, gy - yc)
        end = np.clip(1 - np.abs((gy - (y0 + y1) / 2) / ((y1 - y0) / 2)) ** 6, 0, 1)
        groove = np.clip(2.3 - dist, 0, 1) * (0.55 + 0.45 * end)
        lip = np.clip(1.4 - np.abs(gx - x - 2.6), 0, 1) * (gy > yc - 0.5) * (gy < yc + 0.5) * 0.55
        sub = rgb[Y0:Y1, X0:X1]
        sub[:] = sub * (1 - groove[..., None]) + np.float32([0.09, 0.04, 0.06]) * groove[..., None]
        sub[:] = sub + (np.float32([1.0, 0.86, 0.58]) - sub) * lip[..., None]

    @cached_property
    def poseB(self):
        """Second painted pose, warped onto the key: the street alignment everywhere, blended into a head
        alignment over the face and raised hand (pose B bows the head), then taken only inside the hero region
        (ear, earbud, face, raised hand) through a soft mask. Patch in plane px with its bbox."""
        d = L.LAYER_CACHE / STEM / "poseB"
        src = d / "poseB.png"
        if not src.exists():
            d.mkdir(parents=True, exist_ok=True)
            key = Path(self.ctx.key_paths()[0])
            keyprep.upscale(key.parents[2] / "assets" / "key" / key.name.replace("_key", "_poseB"), src)
        raw = cv2.cvtColor(cv2.imread(str(src)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
        kx0, ky0, kx1, ky1 = 400, 740, 1140, 1600                       # key px; times SC are whole plane px
        X0, Y0, X1, Y1 = [int(round(v * SC)) for v in (kx0, ky0, kx1, ky1)]
        ky, kx = np.mgrid[ky0:ky1, kx0:kx1].astype(np.float32)
        xs, yf, yz = SPEC.HEAD_W_RAMP
        y_full = np.interp(kx[0], xs, yf).astype(np.float32)[None, :]
        y_zero = np.interp(kx[0], xs, yz).astype(np.float32)[None, :]
        u = np.clip((ky - y_full) / (y_zero - y_full), 0, 1)
        w = cv2.GaussianBlur(1 - u * u * (3 - 2 * u), (0, 0), 14)
        Hm, Bm = np.float32(SPEC.HEAD_WARP), np.float32(SPEC.BG_WARP)
        hx = Hm[0, 0] * kx + Hm[0, 1] * ky + Hm[0, 2]
        hy = Hm[1, 0] * kx + Hm[1, 1] * ky + Hm[1, 2]
        bx, by = kx + w * (hx - kx), ky + w * (hy - ky)
        mx = Bm[0, 0] * bx + Bm[0, 1] * by + Bm[0, 2]
        my = Bm[1, 0] * bx + Bm[1, 1] * by + Bm[1, 2]
        patch = cv2.remap(raw, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        rgbB = cv2.resize(patch, (X1 - X0, Y1 - Y0), interpolation=cv2.INTER_AREA)
        # soft hero mask, solid over everything pose A's hand sprite can uncover
        hard = L.poly_mask((Y1 - Y0, X1 - X0), [(x * SC - X0, y * SC - Y0) for x, y in SPEC.HERO_POLY])
        hard = (hard > 0.5).astype(np.uint8)
        hs = self.sprites["hand"]
        hx0, hy0, hx1, hy1 = hs["bbox"]
        Hh, Ww = self.planes[1]["a"].shape
        full = np.zeros((Hh, Ww), np.uint8)
        full[hy0:hy1, hx0:hx1] = (hs["rgba"][..., 3] > 5).astype(np.uint8)
        ha = full[Y0:Y1, X0:X1]
        hard = np.maximum(hard, cv2.dilate(ha, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))))
        sig = 7
        k = 2 * int(2 * sig) + 1
        soft = cv2.GaussianBlur(cv2.dilate(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
                                .astype(np.float32), (0, 0), sig)
        # only the person changes: never let pose B's street, lamp light or rain into the soft edge along the
        # profile (the swap stays inside pose A's own solid silhouette there)
        pa = self.planes[1]["a"][Y0:Y1, X0:X1]
        core = cv2.erode((pa > 0.6).astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))
        core = cv2.GaussianBlur(core.astype(np.float32), (0, 0), 1.5)
        right = np.clip((np.arange(X0, X1, dtype=np.float32) / SC - 930) / 30, 0, 1)[None, :]   # profile side only
        soft *= 1 - right * (1 - core)
        # pose A as drawn (plate with the slot, the hand at rest) for the in-between drawings
        prgb = self.planes[1]["rgb"].copy()
        pa_full = self.planes[1]["a"].copy()
        patch, x0, y0 = deform_sprite(hs)
        composite_into(prgb, pa_full, patch, x0, y0)
        rgbA = prgb[Y0:Y1, X0:X1]
        eye = np.zeros((Y1 - Y0, X1 - X0), np.float32)
        cv2.ellipse(eye, (int(895 * SC - X0), int(930 * SC - Y0)), (int(100 * SC), int(62 * SC)), -12, 0, 360, 1.0, -1)
        eye = cv2.GaussianBlur(eye, (0, 0), 6)
        ab = K.inbetween(rgbA, rgbB, eye)        # eyes half shut
        ba = K.inbetween(rgbB, rgbA, eye)        # eyes half open
        # the hand moves too far for the measured flow, so a mesh warp carries it half way: pose B's hand pulled
        # half back toward pose A's pinch (fingertip fully, fading to nothing at the wrist), and back again
        bb = (X0, Y0, X1, Y1)
        tipA, tipB, wrist = np.float32(P((615, 1000))), np.float32(P((540, 975))), P((680, 1540))

        def carry(img, poly, tip, vec):
            m = L.poly_mask((Y1 - Y0, X1 - X0), [(x * SC - X0, y * SC - Y0) for x, y in poly])
            m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)))
            w = K.ramp_weight(bb, m, tuple(tip), wrist, blur=10)
            flow = np.dstack([-w * vec[0], -w * vec[1]]).astype(np.float32)
            return K.sample_along(img, flow, 1.0)

        ab = carry(ab, SPEC.HAND_B_POLY, tipB, (tipA - tipB) * 0.5)
        ba = carry(ba, SPEC.HAND_POLY, tipA, (tipB - tipA) * 0.5)
        # the plate is see-through where pose A's hand sprite covered a gap to the street: pose B's hand (and
        # the in-between hands) need the plane solid there
        hb = L.poly_mask((Y1 - Y0, X1 - X0), [(x * SC - X0, y * SC - Y0) for x, y in SPEC.HAND_B_POLY])
        solid = np.maximum(cv2.dilate(hb, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21))), ha.astype(np.float32))
        solid = cv2.GaussianBlur(solid, (0, 0), 3.0) * soft
        return {"rgb": rgbB, "AB": ab, "BA": ba, "s": soft, "solid": solid, "bbox": (X0, Y0, X1, Y1)}

    def _paste_B(self, prgb, pa, state="B"):
        B = self.poseB
        X0, Y0, X1, Y1 = B["bbox"]
        src = B["rgb"] if state == "B" else B[state]
        s = B["s"][..., None]
        prgb[Y0:Y1, X0:X1] = prgb[Y0:Y1, X0:X1] * (1 - s) + src * s
        pa[Y0:Y1, X0:X1] = np.maximum(pa[Y0:Y1, X0:X1], B["solid"])

    @staticmethod
    def _brass(rgb):
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        return ((r > 0.26) & (r > g * 1.08) & (r - b > 0.10)).astype(np.uint8)

    @cached_property
    def sprites(self):
        return {s["name"]: s for s in self.lay.sprites}

    @cached_property
    def coin_face(self):
        key = cv2.cvtColor(cv2.imread(str(self.ctx.key_paths()[0])), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
        x0, y0, x1, y1 = SPEC.COIN_TEX_BOX
        c = key[y0:y1, x0:x1]
        s = min(c.shape[:2])
        c = cv2.resize(c, (64, 64), interpolation=cv2.INTER_AREA)
        return c

    @cached_property
    def rain_far(self):
        return K.Rain(260, self.lay.W, self.lay.H, seed=11, speed=(1300, 1900), length=(16, 34), width=(0.9, 1.6),
                      alpha=(0.10, 0.28), slant=-0.09)

    @cached_property
    def rain_near(self):
        return K.Rain(46, 1080, 1920, seed=12, speed=(2600, 3400), length=(60, 120), width=(1.6, 3.0),
                      alpha=(0.06, 0.16), slant=-0.11)

    @cached_property
    def ripples(self):
        """Rain-drop rings on the wet street (plane px): position and the drawing they start on."""
        rng = np.random.default_rng(21)
        x0, y0, x1, y1 = [v * SC for v in (930, 2080, 1520, 2701)]
        n = 90
        return [(rng.uniform(x0, x1), rng.uniform(y0, y1), int(rng.integers(0, 60)) * 2, rng.uniform(0.6, 1.2))
                for _ in range(n)]

    # ------------------------------------------------------------------ poses
    def hand_pose(self, fh):
        dx, dy, ang, coin = keyed(self.hand_keys, fh, (0, 0, 0, "rest"))
        return dx, dy, ang, coin

    def head_pose(self, fh):
        ang, dy = keyed(self.head_keys, fh, (0.0, 0.0))
        th = (fh - self.f0) / FPS
        return ang + 0.22 * math.sin(2 * math.pi * th / 2.3 + 0.4), dy

    def palm_angle(self, fh):
        th = (fh - self.f0) / FPS
        return keyed(self.palm_keys, fh, 0.0) + 0.25 * math.sin(2 * math.pi * th / 1.9 + 1.1)

    def music_level(self, f):
        """0..1 envelope of the muffled music leaking from the earbud (drives phone pulse and plate glow)."""
        lv = 0.0
        for p, md in zip(self.pushes, self.music):
            if md <= 0:
                continue
            t = (f - (p + 2)) / FPS
            if 0 <= t < md:
                beat = 60 / 112
                lv = max(lv, 0.55 + 0.45 * math.exp(-(t % beat) / 0.09))
        return lv

    # ------------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        fh = f - f % 2
        th = on2s(f - self.f0)
        pl = self.planes
        st, pe = pl[0], pl[1]
        # ---------------- street plate
        srgb = st["rgb"].copy()
        self._shimmer(srgb, st, th)
        self.rain_far.draw(srgb, th, cone=self._cone_plane(), gain=1.0, glow_sigma=1.2)
        self._ground_fx(srgb, fh)
        # ---------------- person plate
        prgb, pa = pe["rgb"].copy(), pe["a"].copy()
        lv = self.music_level(fh)
        self._phone(prgb, pe, fh, lv)
        pose = self.pose_at(f)
        hand = self.sprites["hand"]
        if pose == "A":
            dx, dy, ang, coin = self.hand_pose(fh)
            M_hand = K.rot_affine(hand["pivot"], ang, dx * SC, dy * SC)
            self._slot_coin(prgb, pa, M_hand, coin, fh)
            patch, x0, y0 = deform_sprite(hand, angle_deg=ang, dx=dx * SC, dy=dy * SC)
            composite_into(prgb, pa, patch, x0, y0)
        else:
            self._paste_B(prgb, pa, pose)
            if pose == "AB":
                self._coin_inbetween(prgb, fh)
        palm = self.sprites["palm"]
        patch, x0, y0 = deform_sprite(palm, angle_deg=self.palm_angle(fh))
        composite_into(prgb, pa, patch, x0, y0)
        hang, hdy = self.head_pose(fh)
        hang_prev, _ = self.head_pose(fh - 2)
        hang_prev2, _ = self.head_pose(fh - 4)
        hair = self.sprites["hair"]
        wind = 1.1 * math.sin(2 * math.pi * th / 1.6 + 0.8) + 0.5 * math.sin(2 * math.pi * th / 0.7)
        hair_ang = 2.2 * (hang_prev - hang) + 1.2 * (hang_prev2 - hang_prev) + wind
        patch, x0, y0 = deform_sprite(hair, angle_deg=hair_ang)
        composite_into(prgb, pa, patch, x0, y0)
        bb, w = self.head_w
        M_head = K.rot_affine(P(SPEC.NECK_PIVOT), hang, 0.0, hdy * SC)
        K.bone_warp(prgb, pa, [(w, M_head)], bb)
        # ---------------- camera
        img = self.cam.render([{"rgb": srgb, "a": st["a"], "n": st["n"]}, {"rgb": prgb, "a": pa, "n": pe["n"]}], t)
        # ---------------- screen-space FX
        n_head = float(np.median(pe["n"][int(900 * SC):int(1100 * SC), int(500 * SC):int(700 * SC)]))
        slot = K.apply_affine(M_head, P((SPEC.SLOT_X + 2, sum(SPEC.SLOT_Y) / 2)))
        self._slot_fx(img, f, fh, t, slot, n_head, lv)
        self._drips(img, fh, t, M_head, n_head)
        cone = self._cone_screen(t)
        self.rain_near.draw(img, th, cone=cone, gain=1.0, glow_sigma=1.8)
        self._overlays(img, f, t, slot, n_head)
        return img, {"lv": lv}

    # ------------------------------------------------------------------ street
    def _cone_plane(self):
        (ax, ay), dvec, half, reach = SPEC.LAMP_CONE
        d = np.float32(dvec) / np.linalg.norm(dvec)
        return ((ax * SC, ay * SC), (float(d[0]), float(d[1])), half, reach * SC)

    def _cone_screen(self, t):
        (ax, ay), dvec, half, reach = SPEC.LAMP_CONE
        a = self.cam.screen_point(P((ax, ay)), 0.25, t)
        d = np.float32(dvec) / np.linalg.norm(dvec)
        return (a, (float(d[0]), float(d[1])), half, reach * SC * self.cam.scale_at(0.25, t))

    def _shimmer(self, rgb, st, th):
        """Neon reflections on the wet street wobble sideways row by row, a new drawing every 2 frames."""
        x0, y0, x1, y1 = st["shim"]["box"]
        w = st["shim"]["w"]
        k = int(round(th * FPS / 2))
        yy = np.arange(y0, y1, dtype=np.float32)[:, None]
        ph = k * 1.9
        dxr = (2.6 * np.sin(yy * 0.115 + ph) + 1.6 * np.sin(yy * 0.043 - ph * 0.7 + 1.3)
               + 1.0 * np.sin(yy * 0.29 + ph * 1.7)) * (0.5 + 0.5 * (yy - y0) / (y1 - y0))
        gx = np.arange(x0, x1, dtype=np.float32)[None, :]
        mx = (gx + dxr * w).astype(np.float32)
        my = np.broadcast_to(yy, mx.shape).astype(np.float32)
        sub = cv2.remap(rgb, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        # bright neon reflections flicker in value a touch with the ripple
        lum = sub.max(2, keepdims=True)
        sat = lum - sub.min(2, keepdims=True)
        glint = np.clip((lum - 0.45) * 3, 0, 1) * np.clip(sat * 3, 0, 1)
        mod = 1 + 0.10 * np.sin(yy * 0.21 - ph * 1.3 + gx * 0.01)[..., None] * glint * w[..., None]
        rgb[y0:y1, x0:x1] = np.clip(sub * mod, 0, 1)

    def _ground_fx(self, rgb, fh):
        """Rain rings, falling coins, coin splashes and landed coins, drawn into the street plate."""
        cx0, cy0 = int(700 * SC), int(1600 * SC)
        Hh, Ww = rgb.shape[:2]
        sc = ShapeCanvas(Ww - cx0, Hh - cy0, ss=2)
        k = (fh - self.f0) // 2
        any_shape = False
        for (x, y, st, s) in self.ripples:
            d = (k * 2 - st) % 120 // 2
            if d < 4:
                r = (5 + 7 * d) * s
                a0 = 0.15 + 0.4 * ((x * 7) % 1)
                sc.line(K._ellipse_pts(x - cx0, y - cy0, r, r * 0.30, 16, a0, a0 + 2.4), 1.0,
                        value=[80, 60, 40, 22][d])
                any_shape = True
        # coins
        lie = []
        for c in self.falls:
            if fh < c["rel"]:
                continue
            if fh < c["land"]:
                tt = (fh - c["rel"]) / FPS
                x = c["x0"] + c["vx"] * tt
                y = c["y0"] + c["vy"] * tt + 0.5 * c["g"] * tt * tt
                ph = c["spin0"] + 360 * c["rate"] * tt
                flip = math.cos(math.radians(ph))
                spr = K.coin_rgba(c["r"], flip, spin=20 + 25 * math.sin(math.radians(ph * 0.5)), seed=c["seed"],
                                  face=self.coin_face)
                K.paste_rgba(rgb, spr, x, y)
            else:
                d = (fh - c["land"]) // 2
                hop = {0: 0.0, 1: -16 * SC, 2: -6 * SC}.get(d, 0.0)
                flip = {0: 0.55, 1: 0.45, 2: 0.32}.get(d, 0.26)
                lie.append((c, hop, flip, d))
                if d <= 4:
                    K.splash_shapes(sc, (c["xl"] - cx0, c["yl"] - cy0), d, seed=c["seed"], scale=1.25 * SC * 2.3)
                    any_shape = True
        for c, hop, flip, d in lie:
            spr = K.coin_rgba(c["r"] * 1.02, flip, spin=86 + 8 * (c["seed"] % 3), seed=c["seed"], face=self.coin_face)
            if d >= 3:      # settled in the puddle: the lower half is under water, cooler and darker
                h = spr.shape[0]
                yy = np.linspace(0, 1, h, dtype=np.float32)[:, None, None]
                wet = np.clip((yy - 0.45) * 3, 0, 1)
                spr = spr.copy()
                spr[..., :3] = spr[..., :3] * (1 - 0.45 * wet) + np.float32([0.18, 0.16, 0.32]) * 0.45 * wet
            K.paste_rgba(rgb, spr, c["xl"], c["yl"] + hop)
        if any_shape:
            core, glow = sc.result(glow_sigma=2.2)
            screen_emissive(rgb, core * 0.72, glow * 0.55, (0.93, 0.86, 0.80), (0.45, 0.60, 0.95), cx0, cy0)

    # ------------------------------------------------------------------ person
    def _phone(self, rgb, pe, fh, lv):
        ph = pe["phone"]
        x0, y0, x1, y1 = ph["box"]
        th = (fh - self.f0) / FPS
        idle = 0.04 * math.sin(2 * math.pi * th / 1.3)
        g = 1.0 + idle + 0.42 * lv
        sub = rgb[y0:y1, x0:x1]
        s = ph["screen"][..., None]
        sub[:] = sub * (1 - s) + np.clip(sub * g, 0, 1) * s
        spill = ph["spill"][..., None] * (0.06 + 0.30 * lv)
        teal = np.float32([0.30, 0.95, 0.80])
        sub[:] = 1 - (1 - sub) * (1 - teal * spill * (1 - s))

    def _slot_coin(self, rgb, a, M_hand, coin, fh):
        """The big coin pinched in the fingertips; on the push it is already a third of the way into the slot."""
        if coin == "gone":
            return
        cx, cy = K.apply_affine(M_hand, P(SPEC.COIN_REST))
        if coin == "push":
            cx -= 16 * SC
        spr = K.coin_rgba(SPEC.COIN_R * SC, SPEC.COIN_FLIP, spin=6, seed=7, face=self.coin_face,
                          lit=(1.0, 0.80, 0.48))
        spr = spr.copy()
        h, w = spr.shape[:2]
        xs = cx - w / 2 + np.arange(w, dtype=np.float32)
        sx = SPEC.SLOT_X * SC
        clip = np.clip((xs - sx) / 1.2, 0, 1)[None, :]
        spr[..., 3] *= clip
        # a dark lip where the coin enters the slot
        lip = np.exp(-((xs - sx - 1.5) ** 2) / 4.0)[None, :, None]
        spr[..., :3] *= 1 - 0.6 * lip
        # contact shadow on the brass plate (violet, offset away from the lamp)
        sh = spr.copy()
        sh[..., :3] = np.float32([0.16, 0.07, 0.14])
        sh[..., 3] = cv2.GaussianBlur(sh[..., 3], (0, 0), 2.0) * 0.6
        K.paste_rgba(rgb, sh, cx - 4 * SC, cy + 5 * SC)
        K.paste_rgba(rgb, spr, cx, cy, dst_a=a)

    def _coin_inbetween(self, prgb, fh):
        """On the in-between drawing the big coin is half way into the slot (the speed lines trail it)."""
        cx, cy = P(SPEC.COIN_REST)
        cx -= 30 * SC
        spr = K.coin_rgba(SPEC.COIN_R * SC, SPEC.COIN_FLIP, spin=6, seed=7, face=self.coin_face,
                          lit=(1.0, 0.80, 0.48)).copy()
        xs = cx - spr.shape[1] / 2 + np.arange(spr.shape[1], dtype=np.float32)
        spr[..., 3] *= np.clip((xs - SPEC.SLOT_X * SC) / 1.2, 0, 1)[None, :]
        lip = np.exp(-((xs - SPEC.SLOT_X * SC - 1.5) ** 2) / 4.0)[None, :, None]
        spr[..., :3] *= 1 - 0.6 * lip
        K.paste_rgba(prgb, spr, cx, cy)

    # ------------------------------------------------------------------ screen FX
    def _slot_fx(self, img, f, fh, t, slot, n, lv):
        q = self.cam.screen_point(slot, n, t)
        s = self.cam.scale_at(n, t)
        sc = None
        if self.pose_at(f) == "AB":
            # speed lines trailing the coin as it shoots into the slot
            sc = ShapeCanvas(img.shape[1], img.shape[0])
            rng = np.random.default_rng(f)
            for k in range(5):
                off = np.float32([(26 + rng.uniform(0, 22)) * s, (k - 2) * 15 * s + rng.uniform(-4, 4) * s])
                sc.fill(tapered_streak_poly(np.float32(q) + off, np.float32([-1, -0.12]),
                                            rng.uniform(40, 70) * s, 3.2 * s), value=200)
        for p in self.pushes:
            d = fh - p
            if d in (0, 2):
                if sc is None:
                    sc = ShapeCanvas(img.shape[1], img.shape[0])
                r = (40 if d == 0 else 18) * s / 0.9
                a0 = 0.12 + 0.25 * (p % 3)
                sc.fill(star4_poly(q, r, a0, pinch=0.24))
                sc.fill(star4_poly(q, r * 0.45, a0 + math.pi / 4, pinch=0.3))
                if d == 0:
                    rng = np.random.default_rng(p)
                    for k in range(4):
                        aa = rng.uniform(-2.6, 0.6)
                        dv = np.float32([math.cos(aa), math.sin(aa)])
                        sc.fill(tapered_streak_poly(np.float32(q) + dv * 30 * s, dv, 16 * s, 3.2 * s))
        if sc is not None:
            c, g = sc.result(glow_sigma=6)
            screen_emissive(img, c, g, (1.0, 0.95, 0.80), (1.0, 0.58, 0.20))
        if lv > 0:
            # the brass plate warms while the paid music plays
            r = int(60 * s)
            x0, y0 = int(q[0]) - r, int(q[1]) - r
            yy, xx = np.mgrid[-r:r, -r:r].astype(np.float32)
            g = np.exp(-(xx ** 2 / (0.35 * r * r) + yy ** 2 / (0.6 * r * r))) * lv * 0.45
            screen_emissive(img, g * 0, g, (0, 0, 0), (1.0, 0.58, 0.20), x0, y0)

    def _drips(self, img, fh, t, M_head, n):
        """Rain drips forming on the hood rim, stretching and falling on 2s."""
        sc = None
        k = (fh - self.f0) // 2
        for i, (x, y) in enumerate(SPEC.HOOD_DRIPS):
            period = 9 + 3 * i
            d = (k + 4 * i) % period
            px, py = K.apply_affine(M_head, P((x, y)))
            q = self.cam.screen_point((px, py), n, t)
            s = self.cam.scale_at(n, t) / 0.9
            if sc is None:
                sc = ShapeCanvas(img.shape[1], img.shape[0])
            if d < period - 4:
                grow = min(1.0, (d + 1) / (period - 4))
                sc.fill(tapered_streak_poly(np.float32(q) + np.float32([0, 4 * s * grow]), np.float32([0, 1]),
                                            6 * s * grow, 4.2 * s * (0.5 + 0.5 * grow)), value=150)
            else:
                j = d - (period - 4)
                fall = [10, 34, 70, 120][j] * s
                sc.fill(tapered_streak_poly(np.float32(q) + np.float32([0, fall]), np.float32([0, 1]),
                                            (8 + 7 * j) * s, 3.6 * s), value=170 - 30 * j)
        if sc is not None:
            c, g = sc.result(glow_sigma=1.5)
            screen_emissive(img, c * 0.75, g * 0.5, (0.85, 0.80, 0.95), (0.55, 0.45, 0.85))

    # ------------------------------------------------------------------ overlays
    @cached_property
    def layout(self):
        x0, y0, x1, y1 = safe_box()
        sl = O.tag_slots()
        dt = O.data_tag("Spotify, per month today", size=44)
        cy = sl["data"][1] + dt.shape[0] + 6
        return {"counter": (x0 + 4, cy), "data": sl["data"]}

    def _overlays(self, img, f, t, slot, n):
        """The real price, "$12.99", lands plain (no label) on "twelve" under its data tag. On "would" the
        counter jumps to the first invented value and rolls upward; every invented value, and the closing
        "$?" on "more", carries the "scenario" label from its first frame."""
        fh = f - f % 2
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Spotify, per month today", self.f_twelve)
        cx, cy = self.layout["counter"]
        p3, p4, p5 = self.pushes[2:]
        fc = self.f_cost
        if fh < self.f_twelve:
            return
        if fh < p4:
            num = O.counter_rgba(12.99, size=150)
        elif fh < p5:
            v = O.roll_value(f, p4, p4 + 2, 13.49, 15.49, ease="out")
            if fh >= fc:
                v = O.roll_value(f, fc, fc + 2, 15.49, 19.99, ease="out")
            num = O.counter_rgba(v, size=150)
        else:
            num = K.word_rgba("$?", size=190, color=EMBER)
        s, jx = 1.0, 0
        if fh - self.f_twelve in (0, 2):
            s = {0: 1.18, 2: 0.96}[fh - self.f_twelve]
        elif fh >= p5:
            s = {0: 1.22, 2: 0.94, 4: 1.02}.get(fh - p5, 1.0)
            jx = {0: -6, 2: 4, 4: -2}.get(fh - p5, 0)
        elif fh == p4:
            s, jx = 1.08, 3
        elif fh == fc:
            s, jx = 1.05, 3
        p, ox, oy = T.transform_rgba(num, s, 0, origin=(20, num.shape[0] / 2))
        T.over(img, p, cx + ox + jx, cy + oy)
        if fh >= p4:
            lab = O.scenario_label(size=34)
            w_num = O.counter_rgba(18.49, size=150).shape[1] if fh < p5 else num.shape[1]
            # settled from its first frame (the pop already ran): the first invented value is never unlabelled
            O.draw_pop(img, lab, cx + w_num - 34, cy + num.shape[0] - lab.shape[0] - 26, f, p4 - 6)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.55 + 0.15 * info.get("lv", 0.0)}

    # ------------------------------------------------------------------ events + sound
    def events(self):
        ev = [(self.f_twelve, "price_pop", {})]
        for i, p in enumerate(self.pushes):
            ev.append((p - 2, "coin_push", {"i": i}))
            ev.append((p, "coin_clunk", {"i": i}))
            if self.music[i] > 0:
                ev.append((p + 2, "music", {"i": i, "dur": self.music[i]}))
        ev.append((self.pushes[3], "price_roll", {}))
        ev.append((self.f_cost, "price_roll", {}))
        ev.append((self.f_more, "price_unknown", {}))
        for c in self.falls:
            ev.append((c["rel"], "coin_tip", {"x": c["x0"] / self.lay.W}))
            ev.append((c["land"], "coin_splash", {"x": c["xl"] / self.lay.W}))
            ev.append((c["land"] + 2, "coin_bounce", {"x": c["xl"] / self.lay.W}))
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        d = dur + 0.6
        snd.bed(K.rain_bed(d + 0.6), t0 - 0.3, -21)
        snd.bed(K.hood_patter(d), t0, -30, pan=-0.35)
        snd.bed(A.city_hum(d), t0, -35, pan=0.3)
        for f, kind, info in self.events():
            t = snd.at_frame(f)
            if kind == "coin_push":
                snd.sfx(K.coin_slide(42 + info["i"]), t, -27, -0.25)
            elif kind == "coin_clunk":
                snd.sfx(K.coin_clunk(41 + info["i"]), t, -15 + (1.5 if info["i"] >= 2 else 0), -0.3)
            elif kind == "music":
                snd.sfx(K.muffled_music(info["dur"], seed=45 + info["i"]), t, -18, -0.25)
            elif kind == "coin_tip":
                snd.sfx(K.coin_tink(60 + f, pitch=1.15, dur=0.25), t, -28, 0.45)
            elif kind == "coin_splash":
                pan = float(np.clip((info["x"] - 0.5) * 1.6, -0.8, 0.8))
                snd.sfx(K.water_splash(70 + f), t, -19, pan)
                snd.sfx(K.coin_tink(80 + f, pitch=0.9), t, -22, pan)
            elif kind == "coin_bounce":
                pan = float(np.clip((info["x"] - 0.5) * 1.6, -0.8, 0.8))
                snd.sfx(K.coin_tink(90 + f, pitch=0.95, dur=0.2), t, -29, pan)
            elif kind == "price_pop":
                snd.sfx(A.tick(f, 2400), t, -24, -0.4)
            elif kind == "price_roll":
                for j in range(3):
                    snd.sfx(A.tick(f + j, 2800 + 300 * j), t + j * 0.03, -27, -0.4)
            elif kind == "price_unknown":
                snd.sfx(A.thunk(f), t, -17, -0.2)
                snd.sfx(A.tick(f, 1900), t, -23, -0.4)


def make(ctx):
    return Shot(ctx)
