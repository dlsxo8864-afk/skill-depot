"""Shot 8, Year 7: "So would storing your photos, ninety-nine cents a month today."

A hallway wall of framed family photos with blank paper price tags. While the line starts, an unseen marker
writes rising prices onto the tags one after another (each tag jolts and swings on its string). On "photos"
the pictures on the right dissolve one after another into brushstroke flecks that shift from the photo's
colours to teal and drift away on 2s, leaving empty frames and gusting the tags. A pair of gloved hands gives
their photo a small tug, lifts it off its nail and carries it out of frame; the seated parent's head follows
it (the bun lags), and the phone light flickers with every loss. The iCloud data tag lands on "ninety-nine".
Camera on 1s with depth parallax; everything else on 2s.
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS
from whatif.fx2d import screen_emissive
from whatif.shotkit import BaseShot
from whatif.timing import Track, even_frame_of, on2s

from . import s07_year6_kit as K
from . import s08_year7_spec as SPEC

STEM = __name__.split(".")[-1]
SC = L.WORK_SCALE
TEAL = np.float32([0.30, 0.93, 0.86])
INK = (0.14, 0.06, 0.11)
# write order (tag indices) sweeping left to right, then down the right column; prices rise as they go
WRITE_ORDER = [3, 6, 0, 4, 8, 1, 5, 7, 2, 10, 11, 9]
PRICES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 12, 15, 19]
DISSOLVE_LEN = 20
HERO_TAGS = [0, 5, 9]          # the tags that pop out enlarged as they are written
HERO_H = 230                   # output px of an enlarged tag with its string
SAFE = (65, 115, 929, 1498)    # text-safe area: clear of the bottom 22% and right 14%


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def P(xy):
    return (xy[0] * SC, xy[1] * SC)


def keyed(keys, fh, default=0.0):
    best = None
    for k in sorted(keys):
        if k <= fh:
            best = keys[k]
        else:
            break
    return default if best is None else best


def lerp_keys(keys, f):
    ks = sorted(keys)
    if f <= ks[0]:
        return np.float32(keys[ks[0]])
    for a, b in zip(ks, ks[1:]):
        if a <= f <= b:
            u = (f - a) / (b - a)
            return np.float32(keys[a]) * (1 - u) + np.float32(keys[b]) * u
    return np.float32(keys[ks[-1]])


def warp_patch(patch, x0, y0, M, W, H):
    """Forward-affine an RGBA patch living at (x0, y0) in a W x H plane; returns (rgba, xa, ya) or None."""
    h, w = patch.shape[:2]
    c = np.float32([[x0, y0], [x0 + w, y0], [x0 + w, y0 + h], [x0, y0 + h]])
    tc = c @ M[:, :2].T + M[:, 2]
    xa, ya = int(max(math.floor(tc[:, 0].min()) - 1, 0)), int(max(math.floor(tc[:, 1].min()) - 1, 0))
    xb, yb = int(min(math.ceil(tc[:, 0].max()) + 2, W)), int(min(math.ceil(tc[:, 1].max()) + 2, H))
    if xb <= xa or yb <= ya:
        return None
    Ml = M.astype(np.float64).copy()
    Ml[:, 2] = M[:, :2] @ np.float32([x0, y0]) + M[:, 2] - np.float32([xa, ya])
    out = cv2.warpAffine(patch, Ml, (xb - xa, yb - ya), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT,
                         borderValue=0)
    return out, xa, ya


def over(dst, out, xa, ya, opacity=1.0, dst_a=None):
    h, w = out.shape[:2]
    al = out[..., 3:4] * opacity
    dst[ya:ya + h, xa:xa + w] = dst[ya:ya + h, xa:xa + w] * (1 - al) + out[..., :3] * al
    if dst_a is not None:
        dst_a[ya:ya + h, xa:xa + w] = dst_a[ya:ya + h, xa:xa + w] * (1 - al[..., 0]) + al[..., 0]


def mirror_tile(img, h, w):
    """Tile a texture with mirrored copies (no seams) and crop to h x w."""
    blk = np.concatenate([np.concatenate([img, img[:, ::-1]], 1), np.concatenate([img[::-1], img[::-1, ::-1]], 1)], 0)
    ry, rx = h // blk.shape[0] + 1, w // blk.shape[1] + 1
    return np.tile(blk, (ry, rx, 1))[:h, :w]


def ink_text(txt, w, h, seed=0, kind="marker", fill=0.92):
    """Crisp hand-lettered word fitted into a w x h box (4x supersampled, no blobbing at small sizes)."""
    from PIL import Image, ImageDraw
    S = 4
    size = int(h * S)
    while size > 6:
        fnt = T.font(kind, size)
        x0, y0, x1, y1 = ImageDraw.Draw(Image.new("L", (8, 8))).textbbox((0, 0), txt, font=fnt)
        if x1 - x0 <= w * S * fill and y1 - y0 <= h * S * fill:
            break
        size = int(size * 0.92)
    im = Image.new("L", (w * S, h * S), 0)
    ImageDraw.Draw(im).text(((w * S - (x1 - x0)) / 2 - x0, (h * S - (y1 - y0)) / 2 - y0), txt, font=fnt, fill=255)
    a = np.asarray(im, np.float32) / 255
    a = cv2.resize(a, (w, h), interpolation=cv2.INTER_AREA)
    return np.clip(a * 1.15, 0, 1)


def smooth_field(img, valid, step=3):
    """Quadratic colour field fitted to the valid pixels: wall light without the blobs a blur would carry."""
    h, w = valid.shape
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    X, Y = gx / w - 0.5, gy / h - 0.5
    feats = np.stack([np.ones_like(X), X, Y, X * X, X * Y, Y * Y], -1)
    mask = np.zeros_like(valid)
    mask[::step, ::step] = valid[::step, ::step]
    A = feats[mask]
    out = np.zeros_like(img)
    for c in range(3):
        coef, *_ = np.linalg.lstsq(A, img[..., c][mask], rcond=None)
        out[..., c] = feats @ coef
    return np.clip(out, 0, 1).astype(np.float32)


def painted_wall(base, seed, amp=1.0):
    """Layered brush strokes over a colour field, at the painting's own texture strength (~0.1 relative)."""
    h, w = base.shape[:2]
    rng = np.random.default_rng(seed)

    def nz(a):
        return (a - a.mean()) / (a.std() + 1e-6)
    n1 = nz(L.brush_noise((h, w), seed, scale=7.0, angle=-0.35, stretch=5.0))
    n2 = nz(L.brush_noise((h, w), seed + 1, scale=4.0, angle=0.9, stretch=3.0))
    n3 = nz(cv2.GaussianBlur(rng.normal(size=(h, w)).astype(np.float32), (0, 0), 22))
    hue = cv2.GaussianBlur(rng.normal(size=(h, w, 3)).astype(np.float32), (0, 0), 16)
    hue = hue / (hue.std() + 1e-6)
    k = amp * (0.05 * n1 + 0.03 * n2 + 0.05 * n3)
    return np.clip(base * (1 + k[..., None]) + 0.012 * amp * hue, 0, 1).astype(np.float32)


POSE_B_DIR = L.LAYER_CACHE / STEM / "poseB"


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, SPEC.PLANES, SPEC.SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.cam = ParallaxCamera(
            W, H, focus=Track([(0, (W * 0.5, H * 0.5)), (d, P((900, 1330)), "inout")]), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.075, "inout")]),
            push=Track([(0, 0.0), (d, 0.06, "inout")]),
            rise=Track([(0, 0.0), (d, -12.0, "inout")]))
        self._timing()

    # ------------------------------------------------------------------ timing
    def _timing(self):
        ctx = self.ctx
        f0 = self.f0
        # the transcriber marks "photos" on the end of "your"; the voiced "pho" was measured 0.1 s later
        self.f_photos = even_frame_of(K.heard_t(ctx, "photos") + 0.1)
        # "ninety-nine" follows a 0.6 s silence: pop on the 2s frame at its measured onset
        ons = K.speech_onsets(ctx)
        on99 = min(ons, key=lambda o: abs(o - K.heard_t(ctx, "99")))
        self.f_99 = int(math.floor(on99 * FPS + 0.25)) // 2 * 2
        self.f_cents = ctx.f("cents")
        # prices are written while "So would storing your photos" is said: 12 tags in 9 drawings
        a, b = f0 + 4, self.f_photos + 6
        nd = (b - a) // 2
        self.writes = {}
        for k, i in enumerate(WRITE_ORDER):
            self.writes[i] = (a + 2 * int(round(k * nd / (len(WRITE_ORDER) - 1))), PRICES[k])
        self.f_label = b + 2
        self.dissolve = [self.f_photos + 6 * i for i in range(len(SPEC.PHOTOS))]
        self.T = self.f_photos + 10                      # the tug
        T0 = self.T
        self.lift_keys = {f0: (0, 0, 0), T0 - 4: (0, 0, 0), T0 - 2: (-3, 9, -0.9), T0: (5, -12, 0.9),
                          T0 + 2: (7, -18, 1.3), T0 + 4: (24, -42, 2.5), T0 + 6: (72, -102, 4.6),
                          T0 + 8: (152, -192, 7.0), T0 + 10: (262, -302, 9.0), T0 + 12: (392, -424, 10.5),
                          T0 + 14: (540, -562, 11.5), T0 + 16: (700, -720, 12.0), T0 + 40: (700, -720, 12.0)}
        Hd = {f0: (0.0, 0.0)}
        s0 = self.dissolve[0]
        Hd.update({s0 + 2: (0.5, -1.5), s0 + 6: (0.3, -0.5)})
        # pose A (sitting) until the tug: a startled lift, then the anticipation: a crouch with the head ducked,
        # held for two drawings before springing up
        Hd.update({T0 - 6: (1.4, -5.0), T0 - 4: (-2.8, 13.0)})
        self.head_keys = Hd
        self.crouch_keys = {f0: 1.0, T0 - 4: 0.955}
        # pose B (up on the knees, reaching): one in-between drawing on 2s (T0), then the reach follows the photo
        self.f_poseB = T0 + 2
        self.reach_keys = {self.f_poseB: (0.0, 0.0, 0.0), T0 + 4: (1.0, -2.0, -3.0), T0 + 6: (2.0, -4.0, -5.0),
                           T0 + 8: (3.0, -7.0, -7.5), T0 + 10: (3.6, -9.0, -9.0), T0 + 12: (4.0, -10.0, -10.0),
                           T0 + 14: (4.1, -10.0, -10.5), T0 + 16: (3.6, -8.0, -9.0), T0 + 20: (2.4, -4.0, -2.0),
                           T0 + 24: (1.6, -1.0, 4.0), T0 + 28: (1.2, 0.0, 7.0), T0 + 32: (1.3, 0.0, 6.5)}
        self._swing()

    def lift_pose(self, fh):
        dx, dy, ang = keyed(self.lift_keys, fh, (0, 0, 0))
        if fh < self.T - 4:
            th = (fh - self.f0) / FPS
            ang += 0.25 * math.sin(2 * math.pi * th / 1.5)
            dy += 1.5 * math.sin(2 * math.pi * th / 1.5 + 1.0)
        return dx, dy, ang

    def M_lift(self, fh):
        dx, dy, ang = self.lift_pose(fh)
        return K.rot_affine(P(SPEC.LIFT_PIVOT), ang, dx * SC, dy * SC)

    def _swing(self):
        """Each tag is a damped pendulum (degrees, + = bottom swings left). Kicks: the marker writing on it,
        the gust from each dissolving photo, and (for the lifted photo's tag) the hands' acceleration."""
        n = len(SPEC.TAGS)
        rng = np.random.default_rng(5)
        w0 = 2 * math.pi / 0.85
        zeta = 0.09
        ph = rng.uniform(0, 2 * math.pi, n)
        amp = rng.uniform(5, 10, n)
        kicks = {}
        for i, (fw, _) in self.writes.items():
            kicks.setdefault(fw, []).append((i, rng.choice([-1, 1]) * rng.uniform(32, 46)))
        for j, (name, quad) in enumerate(SPEC.PHOTOS):
            cx = np.mean([p[0] for p in quad])
            cy = np.mean([p[1] for p in quad])
            for i, (pv, box) in enumerate(SPEC.TAGS):
                d = math.hypot(pv[0] - cx, pv[1] - cy)
                s = 75 * math.exp(-d / 420)
                if s > 4:
                    kicks.setdefault(self.dissolve[j] + 2, []).append((i, -s * rng.uniform(0.7, 1.3)))
        # pivot track of the lifted photo's tag (per frame, linear between keys) for its inertia
        LT = SPEC.LIFT_TAG
        pv = P(SPEC.TAGS[LT][0])
        fr = np.arange(self.f0 - 48, self.f1 + 20)
        xs = []
        for f in fr:
            dx, dy, ang = lerp_keys(self.lift_keys, f)
            M = K.rot_affine(P(SPEC.LIFT_PIVOT), float(ang), float(dx) * SC, float(dy) * SC)
            xs.append(K.apply_affine(M, pv)[0])
        xs = np.float32(xs)
        ax = np.gradient(np.gradient(xs)) * FPS * FPS
        ax = np.convolve(ax, np.ones(3) / 3, mode="same")
        Lp = 80.0
        th = np.zeros(n)
        om = np.zeros(n)
        sub = 6
        self.swing = {}
        for k, f in enumerate(fr):
            for i, dv in kicks.get(int(f), []):
                om[i] += dv
            t = (f - self.f0) / FPS
            for s in range(sub):
                force = -w0 * w0 * th - 2 * zeta * w0 * om + amp * np.sin(2 * math.pi * t / (1.6 + 0.07 * np.arange(n)) + ph)
                force[LT] += math.degrees(ax[k] / Lp) * 0.8
                om += force / FPS / sub
                th += om / FPS / sub
            th = np.clip(th, -24, 24)
            self.swing[int(f)] = th.copy()

    def dissolve_p(self, j, fh):
        s = self.dissolve[j]
        if fh < s:
            return 0.06 + 0.06 * max(0.0, (fh - self.f0) / max(1, s - self.f0))
        u = min(1.0, (fh - s) / DISSOLVE_LEN)
        return 0.12 + 0.95 * (1 - (1 - u) ** 2)

    def phone_level(self, fh):
        lv = 1.0
        for s in self.dissolve + [self.T + 4]:
            lv *= {0: 0.45, 2: 1.18, 4: 0.72, 6: 1.06}.get(fh - s, 1.0)
        th = (fh - self.f0) / FPS
        return lv * (1 + 0.03 * math.sin(2 * math.pi * th / 1.1))

    # ------------------------------------------------------------------ prepared plates
    @cached_property
    def sprites(self):
        return {s["name"]: s for s in self.lay.sprites}

    @cached_property
    def planes(self):
        out = []
        for p in self.lay.planes:
            out.append({"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                        "n": nearness(p["d"].astype(np.float32) / 65535)})
        wall, par = out
        rgb = wall["rgb"]
        Hh, Ww = rgb.shape[:2]
        tex = self._detail_source(rgb)
        self._fill_behind_lift(rgb, tex)
        self.photos = [self._photo(j, rgb, tex) for j in range(len(SPEC.PHOTOS))]
        self.painted_flecks = self._extract_flecks(rgb)
        self._prep_parent(par)
        self.poseB = self._prep_poseB(rgb, par)
        return out

    def _detail_source(self, rgb):
        x0, y0, x1, y1 = [int(v * SC) for v in SPEC.EMPTY_TEX_BOX]
        t = rgb[y0:y1, x0:x1].copy()
        hp = t - cv2.GaussianBlur(t, (0, 0), 10)
        lum = hp.mean(2, keepdims=True)
        hp = lum + (hp - lum) * 0.5                     # keep the strokes, tame their colour
        return np.clip(hp, -0.08, 0.08).astype(np.float32)

    def _fill_behind_lift(self, rgb, tex):
        """The wall behind the lifted photo and arms, repainted: a smooth light field fitted to the wall beyond
        the painted cast shadows, layered brush strokes at the painting's own texture strength, and the paler,
        unfaded rectangle where the frame hung under its nail, with a line of dust along its top."""
        sp = self.sprites["lift"]
        x0, y0, x1, y1 = sp["bbox"]
        m = (sp["rgba"][..., 3] > 5).astype(np.uint8)
        m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))).astype(np.float32)
        soft = cv2.GaussianBlur(m, (0, 0), 2.0)[..., None]
        pad = 70
        Hh, Ww = rgb.shape[:2]
        X0, Y0, X1, Y1 = max(x0 - pad, 0), max(y0 - pad, 0), min(x1 + pad, Ww), min(y1 + pad, Hh)
        big = rgb[Y0:Y1, X0:X1]
        hole = np.zeros(big.shape[:2], np.float32)
        hole[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0] = m
        lum = big.max(2)
        bright = lum > cv2.GaussianBlur(lum, (0, 0), 7) + 0.03
        ring_hard = cv2.dilate((hole > 0.5).astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (91, 91)))
        far = (ring_hard == 0) & ~bright
        # tags, other frames and flecks are not wall: keep only mid-value, low-chroma wall pixels
        chroma = big.max(2) - big.min(2)
        far &= (chroma < 0.22) & (lum < 0.5)
        # colour field that meets the surrounding wall at the hole's edge, smooth inside (no glow blobs)
        base_big = cv2.GaussianBlur(L.push_pull_fill(big.copy(), far), (0, 0), 16)
        base_big = 0.5 * base_big + 0.5 * cv2.GaussianBlur(smooth_field(big, far), (0, 0), 4) * (
            base_big.mean() / max(float(smooth_field(big, far).mean()), 1e-3))
        sub = rgb[y0:y1, x0:x1]
        base = base_big[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0]
        fill = painted_wall(base, seed=91, amp=0.8) + mirror_tile(tex, y1 - y0, x1 - x0) * 1.0
        # the unfaded rectangle: upright, hung from the right-hand nail
        gx0, gy0, gx1, gy1 = [v * SC for v in SPEC.GHOST_RECT]
        g = np.zeros((y1 - y0, x1 - x0), np.float32)
        cv2.rectangle(g, (int(gx0 - x0), int(gy0 - y0)), (int(gx1 - x0), int(gy1 - y0)), 1.0, -1)
        jag = L.brush_noise(g.shape, 93, scale=2.0, angle=0.0, stretch=6.0)
        gb = cv2.GaussianBlur(g, (0, 0), 3.0)
        g = np.clip(cv2.GaussianBlur(g, (0, 0), 2.2) + 0.25 * jag * gb * (1 - gb) * 4, 0, 1)
        lum_b = base.mean(2, keepdims=True)
        paler = base * 1.22 + (lum_b * 1.22 - base * 1.22) * 0.25 + np.float32([0.020, 0.012, 0.004])
        fill = fill * (1 - g[..., None]) + (painted_wall(paler, seed=94, amp=0.7)) * g[..., None]
        top = np.zeros_like(g)
        cv2.line(top, (int(gx0 - x0) + 2, int(gy0 - y0)), (int(gx1 - x0) - 2, int(gy0 - y0)), 1.0, 2)
        dust = cv2.GaussianBlur(top, (0, 0), 1.3)[..., None] * (0.6 + 0.4 * (jag[..., None] > 0))
        fill = fill * (1 - 0.22 * dust)
        rgb[y0:y1, x0:x1] = np.clip(sub * (1 - soft) + fill * soft, 0, 1)
        self.ghost_g = (x0, y0, g)
        # the nail it hung from: a dark head, a lamp-side glint and a short shadow to the lower right
        nx, ny = P(SPEC.NAILS[1])
        cv2.ellipse(rgb, (int(nx + 3), int(ny + 4)), (5, 3), 30, 0, 360, tuple(float(v) for v in base[0, 0] * 0.55), -1,
                    cv2.LINE_AA)
        cv2.circle(rgb, (int(nx), int(ny)), 4, (0.16, 0.13, 0.12), -1, cv2.LINE_AA)
        cv2.circle(rgb, (int(nx - 1), int(ny - 1)), 1, (0.62, 0.52, 0.40), -1, cv2.LINE_AA)
        # the painted cast shadows of the arms and frame around the hole fade as the photo leaves
        big = rgb[Y0:Y1, X0:X1]
        low = cv2.GaussianBlur(big, (0, 0), 10)
        gain = np.clip((base_big.mean(2) + 0.01) / (low.mean(2) + 0.01), 1.0, 1.9)
        w = cv2.GaussianBlur(ring_hard.astype(np.float32), (0, 0), 14) * (1 - hole)
        self.unshadow = (X0, Y0, (big * ((gain - 1) * w)[..., None]).astype(np.float32))

    def _photo(self, j, rgb, tex):
        name, quad = SPEC.PHOTOS[j]
        q = np.float32([P(p) for p in quad])
        x0, y0 = int(q[:, 0].min()) - 3, int(q[:, 1].min()) - 3
        x1, y1 = int(q[:, 0].max()) + 4, int(q[:, 1].max()) + 4
        h, w = y1 - y0, x1 - x0
        ql = q - np.float32([x0, y0])
        m = L.poly_mask((h, w), [tuple(p) for p in ql])
        Hm = cv2.getPerspectiveTransform(ql, np.float32([[0, 0], [1, 0], [1, 1], [0, 1]]))
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        uv = cv2.perspectiveTransform(np.dstack([gx, gy]).reshape(-1, 1, 2), Hm).reshape(h, w, 2)
        u, v = uv[..., 0], uv[..., 1]
        rng = np.random.default_rng(40 + j)
        nz = cv2.GaussianBlur(rng.normal(size=(h, w)).astype(np.float32), (0, 0), 7)
        nz /= nz.std() + 1e-6
        fine = L.brush_noise((h, w), 50 + j, scale=2.0, angle=0.6, stretch=4.0)
        s = (1 - u) + 0.20 * nz + 0.07 * fine + 0.05 * np.abs(v - 0.5)
        inside = m > 0.5
        lo, hi = np.percentile(s[inside], 1), np.percentile(s[inside], 99.5)
        s = np.clip((s - lo) / (hi - lo), 0, 1)
        orig = rgb[y0:y1, x0:x1].copy()
        # empty frame: bare hardboard backing (fibre streaks, mottling, a paler patch where the print sat, the
        # frame's turn-buttons), lit like the wall beside it, with the moulding's shadow on the top/left
        def samp(box):
            bx0, by0, bx1, by1 = [int(c * SC) for c in box]
            return np.median(rgb[by0:by1, bx0:bx1].reshape(-1, 3), 0)
        boxes = {"mountain": ((938, 420, 978, 680), (1150, 760, 1250, 800)),
                 "hat": ((620, 1135, 900, 1195), (950, 870, 1000, 1100)),
                 "snow": ((650, 1515, 725, 1600), (925, 1250, 960, 1480)),
                 "dog": ((720, 1900, 820, 1990), (1030, 1650, 1100, 1850))}[name]
        cl, cr = samp(boxes[0]), samp(boxes[1])
        uu = np.clip(u, 0, 1)[..., None]
        vv = np.clip(v, 0, 1)[..., None]
        light = cl * (1 - uu) + cr * uu
        lum = light.mean(-1, keepdims=True)
        board_hue = np.float32([0.50, 0.40, 0.31])
        board = board_hue * (lum * 1.25 / board_hue.mean()) * 0.6 + light * 1.1 * 0.4
        def nz(a):
            return (a - a.mean()) / (a.std() + 1e-6)
        fib = nz(L.brush_noise((h, w), 60 + j, scale=2.2, angle=0.0, stretch=10.0))
        mott = nz(cv2.GaussianBlur(rng.normal(size=(h, w)).astype(np.float32), (0, 0), 12))
        strokes = nz(L.brush_noise((h, w), 70 + j, scale=5.0, angle=0.25, stretch=6.0))
        fine = nz(cv2.GaussianBlur(rng.normal(size=(h, w)).astype(np.float32), (0, 0), 0.8))
        empty = board * (1 + (0.022 * fib + 0.045 * mott + 0.03 * strokes + 0.02 * fine)[..., None])
        # paler rectangle where the print pressed against the board, slightly inset
        inset = np.clip(np.minimum.reduce([(uu[..., 0] - 0.05) / 0.02, (0.95 - uu[..., 0]) / 0.02,
                                           (vv[..., 0] - 0.06) / 0.02, (0.94 - vv[..., 0]) / 0.02]), 0, 1)
        empty = empty * (1 + 0.07 * inset[..., None])
        empty = empty * (1 + 0.05 * (0.5 - vv))
        shade = np.clip(1 - 0.42 * np.exp(-vv[..., 0] * 13) - 0.30 * np.exp(-uu[..., 0] * 16), 0.35, 1)
        empty = empty * shade[..., None]
        # turn-buttons: small dark metal tabs on each side holding the board in
        for (bu, bv, horiz) in ((0.5, 0.012, True), (0.5, 0.988, True), (0.012, 0.5, False), (0.988, 0.5, False)):
            d = (np.abs(u - bu) < (0.035 if horiz else 0.012)) & (np.abs(v - bv) < (0.014 if horiz else 0.04))
            dm = cv2.GaussianBlur(d.astype(np.float32), (0, 0), 0.7)[..., None]
            empty = empty * (1 - dm) + np.float32([0.16, 0.14, 0.15]) * (0.6 + 0.8 * lum) * dm
        empty = np.clip(empty, 0, 1).astype(np.float32)
        blur = cv2.GaussianBlur(orig, (0, 0), 2.0)
        # fragments that tear off as the front passes, in the colours of the photo they came from: torn
        # pieces of the actual print (the big ones), brush strokes, dabs and shards
        ys, xs = np.where(inside & (s < 0.995))
        N = 120
        pick = rng.choice(len(xs), N, replace=False)
        px, py = xs[pick].astype(np.float32), ys[pick].astype(np.float32)
        size = np.clip(rng.lognormal(math.log(6.0), 0.55, N), 2.5, 22)
        parts = {
            "x": px + x0, "y": py + y0, "s": s[ys[pick], xs[pick]],
            "col": blur[ys[pick], xs[pick]] * rng.uniform(0.9, 1.18, (N, 1)),
            "size": size, "asp": rng.uniform(0.3, 0.8, N), "ang": rng.uniform(0, math.pi, N),
            "kind": rng.choice(3, N, p=[0.35, 0.4, 0.25]), "curv": rng.uniform(-0.5, 0.5, N),
            "rad": rng.uniform(0.55, 1.0, (N, 7)), "tint": rng.uniform(0.1, 0.45, N),
            "glow": (rng.uniform(0, 1, N) < 0.3).astype(np.float32),
            "spin": rng.uniform(-3, 3, N), "vx": rng.uniform(90, 260, N), "vy": rng.uniform(-160, -10, N),
            "ax": rng.uniform(220, 440, N), "ay": rng.uniform(-240, -80, N), "life": rng.uniform(0.6, 1.4, N),
            "ph": rng.uniform(0, 2 * math.pi, N), "idx": np.arange(N),
        }
        pieces = {}
        for n in np.where(size >= 10)[0]:
            r = int(size[n] * 1.25) + 3
            cx, cy = int(px[n]), int(py[n])
            pp = cv2.copyMakeBorder(orig, r, r, r, r, cv2.BORDER_REFLECT)[cy:cy + 2 * r + 1, cx:cx + 2 * r + 1]
            al = np.zeros(pp.shape[:2], np.float32)
            th = np.sort(rng.uniform(0, 2 * math.pi, 7))
            rr = size[n] * rng.uniform(0.55, 1.0, 7)
            poly = np.int32(np.stack([r + rr * np.cos(th), r + rr * np.sin(th) * rng.uniform(0.5, 0.9)], 1) * 8)
            cv2.fillPoly(al, [poly], 1.0, cv2.LINE_AA, 3)
            rim = np.clip(al - cv2.erode(al, np.ones((3, 3), np.uint8)), 0, 1)[..., None]
            col = np.clip(pp * (1 - rim) + np.clip(pp * 1.35 + 0.12, 0, 1) * rim, 0, 1)   # torn paper edge
            pieces[int(n)] = np.dstack([col, al]).astype(np.float32)
        # birth frame: the drawing on which the front first passes the fleck's origin
        grid = np.arange(self.f0 - 60, self.f1 + 30, 2)
        pg = np.array([self.dissolve_p(j, g) for g in grid])
        idx = np.searchsorted(pg, parts["s"])
        birth = grid[np.clip(idx, 0, len(grid) - 1)].astype(np.float32)
        # flecks that left before the shot starts are already in the air (about half of them)
        pre = parts["s"] < self.dissolve_p(j, self.f0)
        birth[pre] = self.f0 - rng.uniform(0, 1.0, int(pre.sum())) * parts["life"][pre] * FPS
        keep = ~pre | (rng.uniform(0, 1, N) < 0.5)
        for k in parts:
            parts[k] = parts[k][keep]
        parts["birth"] = birth[keep]
        return {"name": name, "box": (x0, y0, x1, y1), "m": m, "s": s, "orig": orig, "empty": empty,
                "parts": parts, "pieces": pieces, "center": (float(q[:, 0].mean()), float(q[:, 1].mean()))}

    def _extract_flecks(self, rgb):
        """Lift the painting's own teal flecks off the wall (they drift from frame 1) and fill under them."""
        Hh, Ww = rgb.shape[:2]
        zone = np.zeros((Hh, Ww), np.uint8)
        for x0, y0, x1, y1 in SPEC.FLECK_ZONES:
            zone[int(y0 * SC):int(y1 * SC), int(x0 * SC):int(x1 * SC)] = 1
        for ph in self.photos:
            x0, y0, x1, y1 = ph["box"]
            mm = cv2.dilate((ph["m"] > 0.3).astype(np.uint8), np.ones((7, 7), np.uint8))
            zone[y0:y1, x0:x1] &= 1 - mm
        for name, sp in self.sprites.items():
            x0, y0, x1, y1 = sp["bbox"]
            mm = cv2.dilate((sp["rgba"][..., 3] > 5).astype(np.uint8), np.ones((5, 5), np.uint8))
            zone[y0:y1, x0:x1] &= 1 - mm
        r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
        lum = rgb.max(2)
        lb = cv2.GaussianBlur(rgb, (0, 0), 7).max(2)
        strict = (g > 0.32) & (b > 0.31) & (r < 0.62 * np.minimum(g, b)) & (lum > lb + 0.05) & (zone > 0)
        loose = (g > 0.26) & (b > 0.26) & (r < 0.72 * np.minimum(g, b)) & (lum > lb + 0.03) & (zone > 0)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(loose.astype(np.uint8), connectivity=8)
        good = np.zeros(n, bool)
        has_strict = np.bincount(lab[strict], minlength=n) > 0
        for i in range(1, n):
            x, y, w, h, area = stats[i]
            longest = max(w, h)
            if not has_strict[i] or area < 5 or area > 2200:
                continue
            if longest > 34 and area / (w * h) < 0.22:       # long thin lines are frame highlights
                continue
            good[i] = True
        sel = good[lab]
        hole = cv2.dilate(sel.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
        src = rgb.copy()
        rng = np.random.default_rng(77)
        comps = []
        for i in np.where(good)[0]:
            x, y, w, h, area = stats[i]
            pad = 3
            xa, ya, xb, yb = max(x - pad, 0), max(y - pad, 0), min(x + w + pad, Ww), min(y + h + pad, Hh)
            mm = (lab[ya:yb, xa:xb] == i).astype(np.float32)
            mm = cv2.dilate(mm, np.ones((3, 3), np.uint8))
            al = cv2.GaussianBlur(mm, (0, 0), 0.7)
            patch = np.dstack([src[ya:yb, xa:xb], al]).astype(np.float32)
            cx, cy = (xa + xb) / 2, (ya + yb) / 2
            comps.append({"p": patch, "x": cx, "y": cy, "vx": rng.uniform(8, 34), "vy": rng.uniform(-26, 4),
                          "ax": rng.uniform(30, 75), "ay": rng.uniform(-45, -12), "ph": rng.uniform(0, 6.3),
                          "area": float(area)})
        K.inpaint_textured(rgb, hole > 0, seed=81, mode="telea", radius=4, grain=0.7)
        return comps

    def _prep_poseB(self, wall_rgb, par):
        """Second painted pose: the parent up on their knees reaching for the photo. Only the parent is taken
        from pose B (soft depth mask, aligned to the key within half a pixel); the wall pose A's parent covered
        is filled from pose B too, so nothing behind them pops."""
        d = POSE_B_DIR
        Hh, Ww = wall_rgb.shape[:2]
        key = cv2.cvtColor(cv2.imread(str(d / "poseB.png")), cv2.COLOR_BGR2RGB)
        rgbB = cv2.resize(key, (Ww, Hh), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        dep = cv2.imread(str(d / "poseB_depth.png"), -1).astype(np.float32) / 65535
        dep = cv2.resize(dep, (Ww, Hh), interpolation=cv2.INTER_AREA)
        reg = np.zeros((Hh, Ww), np.uint8)
        cv2.fillPoly(reg, [np.int32([P(p) for p in SPEC.POSE_B_REGION])], 1)
        hard = ((dep > 0.40) & (reg > 0)).astype(np.uint8)
        hard = cv2.morphologyEx(hard, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        n, lab, stats, _ = cv2.connectedComponentsWithStats(hard)
        if n > 1:
            hard = (lab == 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))).astype(np.uint8)
        guide = cv2.cvtColor(rgbB, cv2.COLOR_RGB2GRAY)
        soft = L.guided_filter(guide, hard.astype(np.float32), 4, 1e-3)
        aB = np.clip((soft - 0.25) / 0.5, 0, 1).astype(np.float32)
        core = cv2.erode(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)))
        dd = cv2.GaussianBlur(L.push_pull_fill(dep, core > 0), (0, 0), 18)
        # the wall behind pose A's parent, from pose B where pose B's parent is not
        aA = par["a"]
        behind = cv2.dilate((aA > 0.03).astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (41, 41)))
        behind = behind.astype(np.float32) * (1 - cv2.dilate(hard, np.ones((9, 9), np.uint8)))
        behind = cv2.GaussianBlur(behind, (0, 0), 6)[..., None]
        wall_rgb[:] = wall_rgb * (1 - behind) + rgbB * behind
        # phone in the lowered hand
        x0, y0, x1, y1 = [int(v * SC) for v in SPEC.PHONE_B_BOX]
        sub = rgbB[y0:y1, x0:x1]
        scr = ((sub.max(2) > 0.62) & (sub[..., 1] >= sub[..., 0])).astype(np.float32)
        scr = cv2.GaussianBlur(cv2.morphologyEx(scr, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)), (0, 0), 1.0)
        pad = 200
        X0, Y0, X1, Y1 = max(x0 - pad, 0), max(y0 - pad, 0), min(x1 + pad, Ww), min(y1 + pad, Hh)
        big = np.zeros((Y1 - Y0, X1 - X0), np.float32)
        big[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0] = scr
        spill = np.clip(cv2.GaussianBlur(big, (0, 0), 45) * 4.0, 0, 1)
        phone = {"box": (x0, y0, x1, y1), "screen": scr, "sbox": (X0, Y0, X1, Y1), "spill": spill * 0.6}
        # bones: the reaching arm about the shoulder, the upper body leaning about the knees
        bb = (0, int(1150 * SC), int(1150 * SC), Hh)
        hb, wb = bb[3] - bb[1], bb[2] - bb[0]
        arm = L.poly_mask((hb, wb), [(x * SC - bb[0], y * SC - bb[1]) for x, y in SPEC.ARM_B_POLY])
        w_arm = K.ramp_weight(bb, arm, P(SPEC.HAND_B), P(SPEC.SHOULDER_B), blur=10)
        whole = np.ones((hb, wb), np.float32)
        w_body = K.ramp_weight(bb, whole, P(SPEC.HEAD_B), P(SPEC.KNEES_B), blur=0)
        return {"rgb": rgbB, "a": aB, "n": nearness(dd), "phone": phone, "bb": bb, "w_arm": w_arm,
                "w_body": w_body, "centroid": np.float32([np.mean(np.where(hard)[1]), np.mean(np.where(hard)[0])])}

    def _prep_parent(self, par):
        prgb = par["rgb"]
        x0, y0, x1, y1 = [int(v * SC) for v in SPEC.PHONE_BOX]
        sub = prgb[y0:y1, x0:x1]
        lum = sub.max(2)
        scr = ((lum > 0.62) & (sub[..., 1] >= sub[..., 0])).astype(np.uint8)
        n, lab, stats, _ = cv2.connectedComponentsWithStats(scr)
        if n > 1:
            j = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
            scr = (lab == j).astype(np.uint8)
        scr = cv2.morphologyEx(scr, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)).astype(np.float32)
        scr = cv2.GaussianBlur(scr, (0, 0), 1.0)
        # light the phone throws: everything the screen reaches on hand, sleeve and cheek
        pad = 260
        Hh, Ww = prgb.shape[:2]
        X0, Y0, X1, Y1 = max(x0 - pad, 0), max(y0 - pad - 220, 0), min(x1 + pad, Ww), min(y1 + pad, Hh)
        big = np.zeros((Y1 - Y0, X1 - X0), np.float32)
        big[y0 - Y0:y1 - Y0, x0 - X0:x1 - X0] = scr
        spill = np.clip(cv2.GaussianBlur(big, (0, 0), 55) * 4.0, 0, 1)
        lit = prgb[Y0:Y1, X0:X1]
        tealness = np.clip((lit[..., 1] + lit[..., 2]) * 0.5 - lit[..., 0] - 0.02, 0, 0.4) / 0.4
        par["phone"] = {"box": (x0, y0, x1, y1), "screen": scr, "sbox": (X0, Y0, X1, Y1),
                        "spill": spill * (0.35 + 0.65 * tealness)}
        hp = [P(p) for p in SPEC.HEAD_POLY]
        xs, ys = zip(*hp)
        bb = (0, max(int(min(ys)) - 40, 0), min(int(max(xs)) + 50, Ww), min(int(max(ys)) + 50, Hh))
        pm = L.poly_mask((bb[3] - bb[1], bb[2] - bb[0]), [(x - bb[0], y - bb[1]) for x, y in hp])
        w_head = K.ramp_weight(bb, pm, P((300, 1800)), P((330, 2110)), blur=24)
        bp = [P(p) for p in SPEC.BUN_POLY]
        bm = L.poly_mask((bb[3] - bb[1], bb[2] - bb[0]), [(x - bb[0], y - bb[1]) for x, y in bp])
        w_bun = K.ramp_weight(bb, bm, P((60, 1630)), P(SPEC.BUN_PIVOT), blur=10)
        self.head_w = (bb, w_head, w_bun)

    @cached_property
    def tag_inks(self):
        """Per tag: (rgba with half the price written, rgba with the whole price) in sprite coordinates."""
        out = {}
        for i, (pv, box) in enumerate(SPEC.TAGS):
            sp = self.sprites[f"tag{i}"]
            base = sp["rgba"].astype(np.float32) / 255
            x0, y0 = sp["bbox"][:2]
            bx0, by0, bx1, by1 = box
            tx0, tx1 = (bx0 + 2) * SC - x0, (bx1 - 2) * SC - x0
            ty0, ty1 = (by0 + 0.28 * (by1 - by0)) * SC - y0, (by1 - 3) * SC - y0
            w, h = int(tx1 - tx0), int(ty1 - ty0)
            fw, val = self.writes[i]
            txt = f"${val}"
            a = ink_text(txt, w, h, seed=200 + i)
            # slight hand-written tilt
            Mr = cv2.getRotationMatrix2D((w / 2, h / 2), float(np.random.default_rng(i).uniform(-8, 6)), 1.0)
            a = cv2.warpAffine(a, Mr, (w, h))
            full = np.zeros(base.shape[:2], np.float32)
            full[int(ty0):int(ty0) + h, int(tx0):int(tx0) + w] = a
            full *= base[..., 3]
            cols = full.sum(0)
            cum = np.cumsum(cols) / max(cols.sum(), 1e-6)
            cut = int(np.searchsorted(cum, 0.42))
            half = full.copy()
            half[:, cut:] = 0
            res = []
            for alpha in (half, full):
                r = base.copy()
                rgbp = r[..., :3].copy()
                T.paint_on_surface(rgbp, alpha, INK, opacity=0.95, seed=300 + i)
                r[..., :3] = rgbp
                res.append(r)
            out[i] = res
        return out

    # ------------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        fh = f - f % 2
        pl = self.planes
        wall, par = pl
        Hh, Ww = wall["a"].shape
        wrgb = wall["rgb"].copy()
        wa = wall["a"].copy()
        k_un = float(np.clip((fh - self.T - 2) / 8, 0, 1))
        if k_un > 0:
            X0, Y0, dlt = self.unshadow
            wrgb[Y0:Y0 + dlt.shape[0], X0:X0 + dlt.shape[1]] += dlt * k_un
        # ---- dissolving photos
        rims = []
        for j, ph in enumerate(self.photos):
            p = self.dissolve_p(j, fh)
            x0, y0, x1, y1 = ph["box"]
            s, m = ph["s"], ph["m"]
            gone = np.clip((p - s) / 0.02, 0, 1) * m
            ahead = np.clip(1 - (s - p) / 0.05, 0, 1) * (s >= p) * m * (p < 1.05)
            tealed = ph["orig"] + (TEAL * 0.8 - ph["orig"]) * (0.55 * ahead[..., None])
            wrgb[y0:y1, x0:x1] = tealed * (1 - gone[..., None]) + ph["empty"] * gone[..., None]
            if p < 1.06:
                rims.append((x0, y0, ahead))
        for x0, y0, band in rims:
            screen_emissive(wrgb, band * 0.35, cv2.GaussianBlur(band, (0, 0), 3.5) * 0.9, tuple(TEAL),
                            (0.25, 0.85, 0.80), x0, y0)
        # ---- tags (on the wall), except the one on the lifted photo
        tag_patches = {}
        sw = self.swing.get(fh, self.swing[max(self.swing)])
        for i in range(len(SPEC.TAGS)):
            sp = self.sprites[f"tag{i}"]
            fw, val = self.writes[i]
            if fh < fw:
                rgba = sp["rgba"]
                scale = 1.0
            else:
                rgba = self.tag_inks[i][0 if fh == fw else 1]
                scale = {0: 1.16, 2: 1.06}.get(fh - fw, 1.0)
            spx = {"rgba": rgba, "w": sp["w"], "bbox": sp["bbox"], "pivot": sp["pivot"]}
            patch, x0, y0 = deform_sprite(spx, angle_deg=float(sw[i]), scale=scale)
            if i == SPEC.LIFT_TAG:
                tag_patches[i] = (patch, x0, y0)
            else:
                composite_into(wrgb, wa, patch, x0, y0)
        # ---- flecks: the painting's own, then the ones tearing off the photos
        self._painted_flecks(wrgb, fh)
        self._new_flecks(wrgb, fh)
        # ---- the lifted photo (shadow on the wall, smear multiples, the photo and arms, its tag)
        self._lift(wrgb, wa, fh, tag_patches[SPEC.LIFT_TAG])
        # ---- parent: pose A (sitting), one smear frame, pose B (reaching)
        lv = self.phone_level(fh)
        if f >= self.f_poseB - 2:
            layers = self._parent_B(f, fh, lv, par)
            img = self.cam.render([{"rgb": wrgb, "a": wa, "n": wall["n"]}] + layers, t)
            self._overlays(img, f, t)
            return img, {"lv": lv}
        prgb, pa = par["rgb"].copy(), par["a"].copy()
        self._phone(prgb, par, lv)
        ang, dy = self.head_pose(fh)
        a1, _ = self.head_pose(fh - 2)
        a2, _ = self.head_pose(fh - 4)
        bun = 2.2 * (a1 - ang) + 1.1 * (a2 - a1)
        bb, w_head, w_bun = self.head_w
        M_head = K.rot_affine(P(SPEC.NECK_PIVOT), ang, 0.0, dy * SC)
        M_bun = K.rot_affine(P(SPEC.BUN_PIVOT), bun, 0.0, 0.0)
        cr = keyed(self.crouch_keys, fh, 1.0)
        if cr != 1.0:                       # the whole figure squashes down toward the floor (anticipation)
            fx, fy = P((420, 2701))
            M_cr = np.float32([[1.0 + (1 - cr) * 0.4, 0, -(1 - cr) * 0.4 * fx], [0, cr, (1 - cr) * fy]])
            y0c = int(min(y for _, y in SPEC.PARENT_REGION) * SC)
            K.bone_warp(prgb, pa, [(np.ones((Hh - y0c, Ww), np.float32), M_cr)], (0, y0c, Ww, Hh))
        K.bone_warp(prgb, pa, [(w_head, M_head), (w_bun, M_bun)], bb)
        img = self.cam.render([{"rgb": wrgb, "a": wa, "n": wall["n"]}, {"rgb": prgb, "a": pa, "n": par["n"]}], t)
        self._overlays(img, f, t)
        return img, {"lv": lv}

    def _parent_B(self, f, fh, lv, par):
        B = self.poseB
        rgb, a = B["rgb"].copy(), B["a"].copy()
        self._phone(rgb, {"phone": B["phone"]}, lv)
        if f < self.f_poseB:
            # the in-between drawing: pose B mesh-warped half way back toward the crouch (body folded forward
            # and down about the knees, the reaching arm half lowered); a single drawing, no ghost of pose A
            M_body = K.rot_affine(P(SPEC.KNEES_B), -7.0, 10 * SC, 70 * SC)
            M_arm = K.rot_affine(P(SPEC.SHOULDER_B), 22.0, 0.0, 0.0)
            K.bone_warp(rgb, a, [(B["w_body"], M_body), (B["w_arm"], M_arm)], B["bb"])
            return [{"rgb": rgb, "a": a, "n": B["n"]}]
        lean, dy, arm = keyed(self.reach_keys, fh, (0.0, 0.0, 0.0))
        th = (fh - self.f0) / FPS
        lean += 0.2 * math.sin(2 * math.pi * th / 1.3)          # breathing hard, on 2s
        M_body = K.rot_affine(P(SPEC.KNEES_B), lean, 0.0, dy * SC)
        M_arm = K.rot_affine(P(SPEC.SHOULDER_B), arm, 0.0, 0.0)
        K.bone_warp(rgb, a, [(B["w_body"], M_body), (B["w_arm"], M_arm)], B["bb"])
        return [{"rgb": rgb, "a": a, "n": B["n"]}]

    def head_pose(self, fh):
        ang, dy = keyed(self.head_keys, fh, (0.0, 0.0))
        th = (fh - self.f0) / FPS
        return ang + 0.18 * math.sin(2 * math.pi * th / 3.1), dy + 1.2 * math.sin(2 * math.pi * th / 3.1 + 0.6)

    # ------------------------------------------------------------------ flecks
    def _painted_flecks(self, rgb, fh):
        tt = (fh - self.f0) / FPS
        tg = max(0.0, (fh - self.f_photos) / FPS)
        k = (fh - self.f0) // 2
        Hh, Ww = rgb.shape[:2]
        for c in self.painted_flecks:
            dx = c["vx"] * tt + 0.5 * c["ax"] * tg * tg
            dy = c["vy"] * tt + 0.5 * c["ay"] * tg * tg
            dist = math.hypot(dx, dy)
            op = float(np.clip(1 - (dist - 140) / 140, 0, 1))
            if op <= 0:
                continue
            glint = 0.88 + 0.22 * math.sin(c["ph"] + k * 1.7)
            p = c["p"]
            if abs(glint - 1) > 0.02:
                p = p.copy()
                p[..., :3] = np.clip(p[..., :3] * glint, 0, 1)
            K.paste_rgba(rgb, p, c["x"] + dx, c["y"] + dy, opacity=op)

    def _new_flecks(self, rgb, fh):
        Hh, Ww = rgb.shape[:2]
        polys, pieces = [], []
        for ph in self.photos:
            q = ph["parts"]
            age = (fh - q["birth"]) / FPS
            live = np.where((age >= 0) & (age < q["life"]))[0]
            for n in live:
                a = float(age[n])
                vx = q["vx"][n] + q["ax"][n] * a
                vy = q["vy"][n] + q["ay"][n] * a
                x = q["x"][n] + q["vx"][n] * a + 0.5 * q["ax"][n] * a * a + 6 * math.sin(3.1 * a + q["ph"][n])
                y = q["y"][n] + q["vy"][n] * a + 0.5 * q["ay"][n] * a * a + 5 * math.cos(2.3 * a + q["ph"][n])
                k_al = min(1.0, a / 0.3)
                tumble = q["ang"][n] + q["spin"][n] * a
                ang = tumble * (1 - k_al) + math.atan2(vy, vx) * k_al
                lf = q["life"][n]
                size = q["size"][n] * (1 - 0.40 * a / lf)
                op = float(np.clip((lf - a) / (0.35 * lf), 0, 1))
                kt = a / lf * q["tint"][n]
                col = q["col"][n] * (1 - kt) + TEAL * kt
                stretch = 1 + min(0.6, math.hypot(vx, vy) / 500) * k_al
                idx = int(q["idx"][n])
                if idx in ph["pieces"]:
                    pieces.append((x, y, math.degrees(ang - q["ang"][n]), size / q["size"][n], op, ph["pieces"][idx], kt))
                else:
                    polys.append((x, y, ang, size * stretch, q["asp"][n] / stretch, col, op, q["glow"][n] * a / lf,
                                  int(q["kind"][n]), q["curv"][n], q["rad"][n]))
        for (x, y, deg, sc, op, pc, kt) in pieces:        # torn pieces of the print itself
            h, w = pc.shape[:2]
            M = cv2.getRotationMatrix2D((w / 2, h / 2), -deg, sc)
            pr = cv2.warpAffine(pc, M, (w, h), flags=cv2.INTER_LINEAR)
            if kt > 0.02:
                pr[..., :3] = pr[..., :3] * (1 - kt) + TEAL * kt
            K.paste_rgba(rgb, pr, x, y, opacity=op)
        if not polys:
            return
        xs = np.float32([p[0] for p in polys])
        ys = np.float32([p[1] for p in polys])
        x0, y0 = int(max(xs.min() - 30, 0)), int(max(ys.min() - 30, 0))
        x1, y1 = int(min(xs.max() + 30, Ww)), int(min(ys.max() + 30, Hh))
        if x1 <= x0 or y1 <= y0:
            return
        h, w = y1 - y0, x1 - x0
        col = np.zeros((h, w, 3), np.uint8)
        alp = np.zeros((h, w), np.uint8)
        glo = np.zeros((h, w), np.uint8)
        S = 16
        tt = np.linspace(-1, 1, 7)
        for (x, y, ang, size, asp, c, op, gl, kind, curv, rad) in polys:
            d = np.float32([math.cos(ang), math.sin(ang)])
            nv = np.float32([-d[1], d[0]])
            a, b = size, max(1.0, size * asp)
            cc = np.float32([x - x0, y - y0])
            if kind == 0:          # shard
                pts = np.float32([cc + a * d + 0.3 * b * nv, cc + 0.2 * a * d + b * nv, cc - a * d - 0.3 * b * nv,
                                  cc - 0.2 * a * d - b * nv])
            elif kind == 1:        # brush stroke: curved spine, loaded head, dry tapering tail
                spine = [cc + a * t * d + nv * curv * a * (1 - t * t) for t in tt]
                wid = [b * (0.25 + 0.75 * math.sqrt(max(0.0, 1 - t * t))) * (1.15 if t > 0 else 0.8) for t in tt]
                pts = np.float32([sp + nv * wd for sp, wd in zip(spine, wid)] +
                                 [sp - nv * wd for sp, wd in zip(spine[::-1], wid[::-1])])
            else:                  # dab: an irregular blot
                th = np.linspace(0, 2 * math.pi, 8)[:-1] + ang
                pts = np.float32([cc + np.float32([math.cos(t_), math.sin(t_)]) * (a * 0.7 * r_)
                                  for t_, r_ in zip(th, rad)])
            ip = np.int32(np.round(pts * S))
            cu = tuple(int(v) for v in np.clip(c * 255, 0, 255))
            cv2.fillPoly(col, [ip], cu, cv2.LINE_AA, 4)
            cv2.fillPoly(alp, [ip], int(255 * op), cv2.LINE_AA, 4)
            if kind != 2 and size > 4:
                hl = np.clip(c * 1.3 + 0.06, 0, 1)
                cv2.line(col, tuple(ip[0]), tuple(ip[1]), tuple(int(v) for v in hl * 255), 1, cv2.LINE_AA, 4)
            if gl > 0.05:
                cv2.fillPoly(glo, [ip], int(255 * op * gl), cv2.LINE_AA, 4)
        al = alp.astype(np.float32)[..., None] / 255
        sub = rgb[y0:y1, x0:x1]
        sub[:] = sub * (1 - al) + col.astype(np.float32) / 255 * al
        g = cv2.GaussianBlur(glo.astype(np.float32) / 255, (0, 0), 4.0)
        screen_emissive(rgb, g * 0, g * 0.6, (0, 0, 0), (0.25, 0.85, 0.80), x0, y0)

    # ------------------------------------------------------------------ lifted photo
    def _lift(self, rgb, a, fh, tagp):
        Hh, Ww = a.shape
        sp = self.sprites["lift"]
        patch = self.lift_rgba
        x0, y0 = sp["bbox"][:2]
        M = self.M_lift(fh)
        off = float(np.clip((fh - self.T) / 4, 0, 1))
        if off > 0:          # off the wall: a soft violet shadow falls down-right of it
            Ms = M.copy()
            Ms[0, 2] += (8 + 10 * off) * SC
            Ms[1, 2] += (10 + 14 * off) * SC
            r = warp_patch(patch, x0, y0, Ms, Ww, Hh)
            if r is not None:
                out, xa, ya = r
                sh = cv2.GaussianBlur(out[..., 3], (0, 0), 6 + 6 * off) * 0.38 * off
                reg = rgb[ya:ya + sh.shape[0], xa:xa + sh.shape[1]]
                reg[:] = reg * (1 - sh[..., None] * (1 - np.float32([0.30, 0.18, 0.36])))
        # smear: drawn multiples between the last drawing and this one while it moves fast
        prev = self.M_lift(fh - 2)
        mv = math.hypot(M[0, 2] - prev[0, 2], M[1, 2] - prev[1, 2])
        if mv > 30 * SC:
            for u, op in ((0.33, 0.20), (0.66, 0.34)):
                Mi = prev * (1 - u) + M * u
                r = warp_patch(patch, x0, y0, Mi.astype(np.float32), Ww, Hh)
                if r is not None:
                    out, xa, ya = r
                    out[..., 3] = cv2.GaussianBlur(out[..., 3], (0, 0), 1.5)
                    over(rgb, out, xa, ya, op)
        r = warp_patch(patch, x0, y0, M, Ww, Hh)
        if r is not None:
            out, xa, ya = r
            over(rgb, out, xa, ya, 1.0, a)
        # its tag rides along (swinging about the string on the frame)
        tp, tx0, ty0 = tagp
        r = warp_patch(tp, tx0, ty0, M, Ww, Hh)
        if r is not None:
            out, xa, ya = r
            over(rgb, out, xa, ya, 1.0, a)

    @cached_property
    def lift_rgba(self):
        return self.sprites["lift"]["rgba"].astype(np.float32) / 255

    # ------------------------------------------------------------------ parent
    def _phone(self, rgb, par, lv):
        ph = par["phone"]
        x0, y0, x1, y1 = ph["box"]
        s = ph["screen"][..., None]
        sub = rgb[y0:y1, x0:x1]
        sub[:] = sub * (1 - s) + np.clip(sub * (0.55 + 0.45 * lv) + 0.06 * (lv - 1), 0, 1) * s
        X0, Y0, X1, Y1 = ph["sbox"]
        k = ph["spill"][..., None] * (lv - 1) * 0.55
        reg = rgb[Y0:Y1, X0:X1]
        reg[:] = np.clip(reg * (1 + k) + np.float32([0.0, 0.05, 0.05]) * np.clip(k, 0, 1), 0, 1)

    # ------------------------------------------------------------------ overlays
    def _overlays(self, img, f, t):
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "iCloud 50 GB: $0.99 a month today", self.f_99)
        self._hero_tags(img, f, t)

    @cached_property
    def hero_spans(self):
        """Three of the tags pop out enlarged as they are written, each with its scenario label."""
        fins = [self.writes[i][0] for i in HERO_TAGS]
        outs = [fins[1] + 2, fins[2], fins[2] + 14]
        return {i: (fi, fo) for i, fi, fo in zip(HERO_TAGS, fins, outs)}

    def hero_card(self, i):
        if not hasattr(self, "_hero_cache"):
            self._hero_cache = {}
        if i in self._hero_cache:
            return self._hero_cache[i]
        sp = self.sprites[f"tag{i}"]
        x0, y0, x1, y1 = sp["bbox"]
        key = cv2.cvtColor(cv2.imread(str(self.ctx.key_paths()[0])), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
        kx0, ky0, kx1, ky1 = [int(round(v / SC)) for v in (x0, y0, x1, y1)]
        crop = key[ky0:ky1, kx0:kx1]
        al = cv2.resize(sp["rgba"][..., 3].astype(np.float32) / 255, (kx1 - kx0, ky1 - ky0), interpolation=cv2.INTER_LINEAR)
        ys, xs = np.where(al > 0.05)
        ya, yb, xa, xb = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        crop, al = crop[ya:yb, xa:xb], al[ya:yb, xa:xb]
        S = HERO_H / crop.shape[0]
        W, H = int(crop.shape[1] * S), HERO_H
        big = cv2.resize(crop, (W, H), interpolation=cv2.INTER_CUBIC)
        bal = np.clip(cv2.resize(al, (W, H), interpolation=cv2.INTER_CUBIC), 0, 1)
        bal = cv2.GaussianBlur(np.clip((bal - 0.35) / 0.3, 0, 1), (0, 0), 0.8)
        # crisp hand-written price on the enlarged paper
        pv, box = SPEC.TAGS[i]
        bx0, by0, bx1, by1 = box
        ox_k, oy_k = kx0 + xa, ky0 + ya
        tx0, tx1 = int((bx0 + 3 - ox_k) * S), int((bx1 - 3 - ox_k) * S)
        ty0, ty1 = int((by0 + 0.30 * (by1 - by0) - oy_k) * S), int((by1 - 4 - oy_k) * S)
        ink = np.zeros((H, W), np.float32)
        tw, th = tx1 - tx0, ty1 - ty0
        a = ink_text(f"${self.writes[i][1]}", tw, th, seed=i)
        Mr = cv2.getRotationMatrix2D((tw / 2, th / 2), float(np.random.default_rng(i).uniform(-8, 6)), 1.0)
        ink[ty0:ty1, tx0:tx1] = cv2.warpAffine(a, Mr, (tw, th))
        rgb = big.copy()
        T.paint_on_surface(rgb, ink * bal, INK, opacity=0.96, seed=400 + i)
        card, pad = O.card_with_shadow(np.dstack([rgb, bal]).astype(np.float32), seed=i)
        origin = ((pv[0] - ox_k) * S + pad, (pv[1] - oy_k) * S + pad)
        self._hero_cache[i] = (card, origin, pad)
        return self._hero_cache[i]

    def _hero_tags(self, img, f, t):
        fh = f - f % 2
        x0s, y0s, x1s, y1s = SAFE
        sw = self.swing.get(fh, self.swing[max(self.swing)])
        lab = O.scenario_label(size=30)
        for i, (fi, fo) in self.hero_spans.items():
            if fh < fi or fh >= fo + 6:
                continue
            card, (ox, oy), pad = self.hero_card(i)
            pv, box = SPEC.TAGS[i]
            n = float(self.planes[0]["n"][int(pv[1] * SC), int(pv[0] * SC)])
            q = self.cam.screen_point(P(pv), n, t)
            ch, cw = card.shape[:2]
            # hang the big tag just up and right of the small one, inside the text-safe area
            x = q[0] + 40 - ox
            y = q[1] - 70 - oy
            x = min(max(x, x0s - pad + 10), x1s - (cw - pad) - lab.shape[1] - 6)
            y = min(max(y, y0s + 150 - pad), y1s - (ch - pad))
            ang = 0.6 * float(sw[i])
            p, dx, dy = T.transform_rgba(card, 1.0, ang, origin=(ox, oy))
            O.draw_pop(img, p, x + dx, y + dy, f, fi, fo, origin=(ox - dx, oy - dy))
            O.draw_pop(img, lab, x + cw - pad + 2, y + oy + (ch - oy) * 0.55, f, fi + 2, fo)

    def finish_args(self, f, info):
        return {"bloom_strength": 0.5 + 0.08 * (info.get("lv", 1.0) - 1)}

    # ------------------------------------------------------------------ events + sound
    def events(self):
        ev = []
        for i, (fw, v) in sorted(self.writes.items(), key=lambda kv: kv[1][0]):
            ev.append((fw, "price_write", {"i": i, "x": SPEC.TAGS[i][0][0] / 1520}))
        for i, (fi, fo) in self.hero_spans.items():
            ev.append((fi, "hero_tag", {"x": SPEC.TAGS[i][0][0] / 1520}))
            ev.append((fi + 2, "scenario", {}))
        for j, s in enumerate(self.dissolve):
            cx = np.mean([p[0] for p in SPEC.PHOTOS[j][1]]) / 1520
            ev.append((s, "dissolve", {"j": j, "x": cx}))
            ev.append((s + 2, "tags_flutter", {"x": cx}))
            ev.append((s, "phone_flicker", {}))
        ev.append((self.T - 2, "tug", {}))
        ev.append((self.T, "nail_scrape", {}))
        ev.append((self.f_poseB, "parent_reach", {}))
        ev.append((self.T + 4, "phone_flicker", {}))
        ev.append((self.T + 6, "lift_away", {}))
        ev.append((self.f_99, "data_tag", {}))
        return sorted(ev, key=lambda e: e[0])

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.room_tone(dur + 0.6), t0, -29)
        for f, kind, info in self.events():
            t = snd.at_frame(f)
            pan = float(np.clip((info.get("x", 0.5) - 0.5) * 1.4, -0.7, 0.7))
            if kind == "price_write":
                snd.sfx(K.marker_squeak(500 + info["i"], dur=0.12), t, -31, pan)
            elif kind == "hero_tag":
                snd.sfx(K.paper_flutter(700 + f, dur=0.2), t, -25, pan)
                snd.sfx(A.tick(f, 2200), t, -26, pan)
            elif kind == "scenario":
                snd.sfx(A.tick(f, 2600), t, -27, 0.2)
            elif kind == "dissolve":
                snd.sfx(K.shimmer(530 + info["j"], dur=0.9), t, -19, pan)
            elif kind == "tags_flutter":
                snd.sfx(K.paper_flutter(560 + f, dur=0.30), t, -24, pan)
            elif kind == "phone_flicker":
                snd.sfx(A.soft_click(3400, f), t, -33, -0.3)
            elif kind == "tug":
                snd.sfx(K.wood_knock(580), t, -17, 0.45)
            elif kind == "nail_scrape":
                snd.sfx(K.nail_scrape(590, dur=0.30), t, -17, 0.35)
            elif kind == "parent_reach":
                snd.sfx(A.swish(0.16, 620), t - 0.04, -27, -0.45)        # sleeve through the air
                snd.sfx(A.thunk(630), t, -29, -0.5)                       # knees onto the floor
            elif kind == "data_tag":
                snd.sfx(A.tick(f, 2400), t, -25, -0.3)
            elif kind == "lift_away":
                snd.sfx(A.swish(0.30, 600), t, -21, 0.6)
                snd.sfx(K.paper_flutter(610, dur=0.25), t + 0.04, -27, 0.6)


def make(ctx):
    return Shot(ctx)
