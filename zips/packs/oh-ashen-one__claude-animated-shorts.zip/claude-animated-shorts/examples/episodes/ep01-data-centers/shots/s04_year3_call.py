"""The opening overlay of shot 4: an invented video-call grid (no real product) whose feeds are cut from the
series' own paintings (screen-lit faces, same brushwork and palette), idling on 2s; the feeds freeze one
by one, painted hairline cracks run across the glass, and the call breaks into painted shards that fly
at the camera and are gone within three drawings.

Output-space (1080 x 1920) drawing; the series grain goes on top (style.finish)."""
import math
from pathlib import Path

import cv2
import numpy as np

from whatif import overlays as O
from whatif import text as T
from whatif.config import OUT_H, OUT_W
from whatif.layers import brush_noise

COLS, ROWS = 2, 3
GRID = (34, 410, 1046, 1640)          # x0, y0, x1, y1 (tiles); every name chip sits at a tile's top, above 78 %
GAP = 14
NAMES = ["Mara", "Dev", "Ines", "Tomas", "Ruth", "Kai"]
UI_BG = np.float32([0.075, 0.045, 0.11])
KEYS = Path(__file__).resolve().parents[2] / "work" / "keys"
POSES = Path(__file__).resolve().parents[2] / "assets" / "key"
# feeds: (key painting, crop box in its 1520-wide key px, crop box of the same person in the painting's
# pose B, aligned to the key; None = no second painting there). Faces lit by their screens, from the series.
FEEDS = [("y10_chatgpt_key.png", (490, 2120, 1090, 2633), (460, 1930, 1060, 2443)),
         ("y05_gaming_key.png", (100, 1150, 700, 1663), (0, 800, 600, 1313)),
         ("y10_chatgpt_key.png", (0, 1790, 560, 2269), (0, 1790, 560, 2269)),
         ("y07_photos_key.png", (520, 320, 910, 654), None),
         ("y10_chatgpt_key.png", (1060, 1820, 1520, 2213), (1060, 1820, 1520, 2213)),
         ("y10_chatgpt_key.png", (820, 1480, 1300, 1891), (820, 1480, 1300, 1891))]


def tile_rects():
    x0, y0, x1, y1 = GRID
    tw = (x1 - x0 - GAP * (COLS - 1)) / COLS
    th = (y1 - y0 - GAP * (ROWS - 1)) / ROWS
    out = []
    for r in range(ROWS):
        for c in range(COLS):
            out.append((int(x0 + c * (tw + GAP)), int(y0 + r * (th + GAP)), int(tw), int(th)))
    return out


def _round_mask(w, h, r):
    m = np.zeros((h, w), np.uint8)
    cv2.rectangle(m, (r, 0), (w - r, h), 255, -1)
    cv2.rectangle(m, (0, r), (w, h - r), 255, -1)
    for cx, cy in ((r, r), (w - r, r), (r, h - r), (w - r, h - r)):
        cv2.circle(m, (cx, cy), r, 255, -1, cv2.LINE_AA)
    return cv2.GaussianBlur(m.astype(np.float32) / 255, (0, 0), 0.8)


_ALIGNED = {}


def _aligned_pose_b(src):
    """The painting's pose B, aligned to its key (cached per painting)."""
    if src not in _ALIGNED:
        from . import s03_year2_kit as K
        key = cv2.imread(str(KEYS / src))
        H, W = key.shape[:2]
        pb = cv2.resize(cv2.imread(str(POSES / src.replace("_key.png", "_poseB.png"))), (W, H), interpolation=cv2.INTER_CUBIC)
        M = K.align_affine(cv2.cvtColor(key, cv2.COLOR_BGR2RGB), cv2.cvtColor(pb, cv2.COLOR_BGR2RGB))
        _ALIGNED[src] = cv2.warpAffine(pb, M, (W, H), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP,
                                       borderMode=cv2.BORDER_REFLECT)
    return _ALIGNED[src]


def _feed_crop(img, box, w, h):
    x0, y0, x1, y1 = box
    crop = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    crop = cv2.resize(crop, (int(w * 1.06), int(h * 1.06)),
                      interpolation=cv2.INTER_AREA if crop.shape[1] > w else cv2.INTER_CUBIC)
    # webcam: a touch of screen light from the front, slightly lifted blacks
    yy = np.linspace(0, 1, crop.shape[0], dtype=np.float32)[:, None, None]
    crop = crop * (1.06 + 0.06 * (1 - yy)) + np.float32([0.02, 0.025, 0.04])
    return np.clip(crop, 0, 1)


class Feed:
    """One webcam feed: a crop of a series painting, breathing on 2s (tiny scale/settle), with a soft
    screen-light lift so the faces read lit from the front. When the call starts failing the person
    reacts: the feed cuts to the same person in the painting's second pose (a different painted
    expression), or, where there is no second painting, a nod/lean-in warp."""

    def __init__(self, w, h, src, box, box_b, seed):
        self.w, self.h = w, h
        self.src = _feed_crop(cv2.imread(str(KEYS / src)), box, w, h)
        self.src_b = _feed_crop(_aligned_pose_b(src), box_b, w, h) if box_b else None
        rng = np.random.default_rng(seed)
        self.ph = float(rng.uniform(0, 6.28))
        self.per = float(rng.uniform(1.2, 2.0))

    def frame(self, th, react_k=None):
        """react_k: drawings since this person reacted (None = not yet)."""
        s = 1.0 + 0.008 * math.sin(th * 2 * math.pi / self.per + self.ph)
        dy = 2.5 * math.sin(th * 2 * math.pi / (self.per * 0.7) + self.ph * 1.7)
        dx = 1.5 * math.sin(th * 3.1 + self.ph)
        rot = 0.4 * math.sin(th * 2.3 + self.ph)
        img = self.src
        if react_k is not None:
            if self.src_b is not None:
                img = self.src_b
                # the cut to the new expression lands with a small start: a lean back, then settle
                s += {0: 0.035, 2: 0.015}.get(react_k - react_k % 2, 0.0)
                dy += {0: -10.0, 2: -4.0}.get(react_k - react_k % 2, 0.0)
            else:
                # a laugh/nod: two quick bobs toward the camera
                bob = {0: 1.0, 2: 0.4, 4: 0.9, 6: 0.3}.get(react_k - react_k % 2, 0.0)
                s += 0.03 * bob
                dy += 12.0 * bob
                rot += 1.2 * bob
        H, W = img.shape[:2]
        M = cv2.getRotationMatrix2D((W / 2, H * 0.4), rot, s)
        M[:, 2] += (dx - (W - self.w) / 2, dy - (H - self.h) / 2)
        return cv2.warpAffine(img, M, (self.w, self.h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


def paint_marks(img, mask, color, seed, glow=0.0):
    """Put flat shapes on as paint: soft broken edges, dry-brush texture, a slight colour wobble."""
    H, W = mask.shape
    ys, xs = np.where(mask > 0.01)
    if len(xs) == 0:
        return img
    x0, x1 = max(xs.min() - 12, 0), min(xs.max() + 13, W)
    y0, y1 = max(ys.min() - 12, 0), min(ys.max() + 13, H)
    m = mask[y0:y1, x0:x1]
    n = brush_noise((max(y1 - y0, 8), max(x1 - x0, 8)), seed, scale=1.5, angle=0.5, stretch=4)[:y1 - y0, :x1 - x0]
    m = cv2.GaussianBlur(m, (0, 0), 1.1)
    m = np.clip(m * (0.78 + 0.45 * n) - 0.08 * (1 - n), 0, 1)
    col = np.float32(color) * (0.9 + 0.2 * n[..., None])
    reg = img[y0:y1, x0:x1]
    if glow:
        g = cv2.GaussianBlur(mask[y0:y1, x0:x1], (0, 0), 6)[..., None] * glow
        reg = 1 - (1 - reg) * (1 - g * np.float32(color))
    img[y0:y1, x0:x1] = reg * (1 - m[..., None]) + col * m[..., None]
    return img


# ------------------------------------------------------------------ the call window
class CallGrid:
    def __init__(self, seed=0):
        self.rects = tile_rects()
        self.people = [Feed(w, h, src, box, box_b, seed * 100 + i * 7 + 3)
                       for i, ((x, y, w, h), (src, box, box_b)) in enumerate(zip(self.rects, FEEDS))]
        self.masks = [_round_mask(w, h, 18) for (x, y, w, h) in self.rects]
        H, W = OUT_H, OUT_W
        n = brush_noise((H // 2, W // 2), 404, scale=3, angle=0.35, stretch=8)
        n = cv2.resize(n, (W, H))[..., None]
        yy = np.linspace(0, 1, H, dtype=np.float32)[:, None, None]
        self.bg = (UI_BG * (1 + 0.22 * n) * (1.15 - 0.3 * yy)).astype(np.float32)
        self.names = []
        for i, nm in enumerate(NAMES):
            a = O._text_alpha(nm, T.sans(28, 620))
            t_rgba, pad = T.styled_text_rgba(a, (240, 232, 222), seed=200 + i, shadow_off=(1, 1), soft_shadow=2,
                                             shadow_strength=0.4, grad=0.03)
            chip = O.painted_swatch(a.shape[1] + 28, a.shape[0] + 18, seed=210 + i, color=(0.06, 0.03, 0.09), opacity=0.72)
            T.over_rgba(chip, t_rgba, 14 - pad, 9 - pad)
            self.names.append(chip)
        a = O._text_alpha("Reconnecting", T.sans(30, 620))
        t_rgba, pad = T.styled_text_rgba(a, (244, 236, 226), seed=230, shadow_off=(1, 1), soft_shadow=2,
                                         shadow_strength=0.4, grad=0.03)
        chip = O.painted_swatch(a.shape[1] + 120, a.shape[0] + 40, seed=231, color=(0.07, 0.035, 0.10), opacity=0.86,
                                radius=24)
        T.over_rgba(chip, t_rgba, 96 - pad, 20 - pad)
        self.reconnect = chip

    def render(self, f_held, lf_held, freeze_at, speaker, react_at=None):
        """Full-frame RGB of the call at a held frame. freeze_at[i] = frame tile i froze (or None);
        react_at[i] = frame person i reacts to the call failing (or None)."""
        img = self.bg.copy()
        react_at = react_at or [None] * len(self.rects)
        for i, ((x, y, w, h), p, m) in enumerate(zip(self.rects, self.people, self.masks)):
            fz = freeze_at[i]
            frozen = fz is not None and f_held >= fz
            tf = fz if frozen else f_held
            ra = react_at[i]
            rk = (tf - ra) if (ra is not None and tf >= ra) else None
            tile = p.frame((tf - (f_held - lf_held)) / 24.0, rk)
            if frozen:
                tile = frozen_look(tile, f_held - fz, seed=i)
            img[y:y + h, x:x + w] = img[y:y + h, x:x + w] * (1 - m[..., None]) + tile * m[..., None]
            if speaker == i and not frozen:
                ring = np.zeros(img.shape[:2], np.float32)
                cv2.rectangle(ring, (x + 3, y + 3), (x + w - 4, y + h - 4), 1.0, 6, cv2.LINE_AA)
                paint_marks(img, ring, (1.0, 0.57, 0.28), seed=40 + f_held // 2, glow=0.5)
            T.over(img, self.names[i], x + 12, y + 12)
            if frozen and f_held - fz >= 4:
                spinner(img, x + w / 2, y + h / 2 - 8, (f_held - fz) // 2)
            if frozen:
                weak_signal(img, x + w - 50, y + 46)
        n_frozen = sum(1 for z in freeze_at if z is not None and f_held >= z)
        if n_frozen >= 2:
            c = self.reconnect
            cx, cy = OUT_W // 2 - c.shape[1] // 2, 1025 - c.shape[0] // 2
            T.over(img, c, cx, cy)
            spinner(img, cx + 50, cy + c.shape[0] / 2, f_held // 2, r=17, dot=4.5)
        return img


def frozen_look(tile, d, seed=0):
    """A frozen feed: on the freeze drawing a torn, blocky glitch; then a cooled, dimmed still."""
    h, w = tile.shape[:2]
    out = tile.copy()
    rng = np.random.default_rng(seed * 31 + d)
    if d < 4:
        small = cv2.resize(out, (max(1, w // 14), max(1, h // 14)), interpolation=cv2.INTER_AREA)
        blocky = cv2.resize(small, (w, h), interpolation=cv2.INTER_NEAREST)
        k = 0.65 if d < 2 else 0.35
        out = out * (1 - k) + blocky * k
        for _ in range(6 if d < 2 else 3):
            y0 = int(rng.integers(0, h - 12))
            hh = int(rng.integers(6, 26))
            sh = int(rng.integers(-28, 28))
            out[y0:y0 + hh] = np.roll(out[y0:y0 + hh], sh, axis=1)
        out[..., 0] = np.roll(out[..., 0], 3, axis=1)
        out[..., 2] = np.roll(out[..., 2], -3, axis=1)
    lum = out @ np.float32([0.3, 0.55, 0.15])
    cool = lum[..., None] * np.float32([0.62, 0.70, 0.92])
    k = min(1.0, 0.35 + 0.15 * d / 2)
    out = out * (1 - k) + cool * k
    if d >= 4:                                   # a soft scrim so the reconnect ring reads as UI
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        r = np.sqrt(((xx - w / 2) / (w * 0.5)) ** 2 + ((yy - h / 2) / (h * 0.5)) ** 2)
        out = out * (0.46 + 0.26 * np.clip(r, 0, 1))[..., None]
    return np.clip(out, 0, 1)


def spinner(img, cx, cy, step, r=34, dot=8.0):
    """'Reconnecting' ring: eight painted dabs, one bright, turning on 2s."""
    H, W = img.shape[:2]
    for lvl in (0.26, 0.5, 0.72, 1.0):
        m = np.zeros((H, W), np.float32)
        for k in range(8):
            lit = (k - step) % 8
            v = 1.0 if lit == 0 else (0.72 if lit == 7 else (0.5 if lit == 6 else 0.26))
            if v != lvl:
                continue
            a = (k / 8) * 2 * math.pi - math.pi / 2
            x, y = cx + math.cos(a) * r, cy + math.sin(a) * r
            rr = dot * (1.15 if lit == 0 else 0.9)
            cv2.ellipse(m, (int(x * 4), int(y * 4)), (int(rr * 4.4), int(rr * 3.6)), math.degrees(a) + 90, 0, 360, 1.0, -1,
                        cv2.LINE_AA, shift=2)
        paint_marks(img, m, (lvl, lvl * 0.96, lvl * 0.92), seed=int(cx) % 97 + int(lvl * 10), glow=0.3 if lvl == 1.0 else 0)


def weak_signal(img, x, y):
    """Three painted signal bars, only the first lit (top-right of a frozen tile)."""
    H, W = img.shape[:2]
    for k in range(3):
        m = np.zeros((H, W), np.float32)
        hh = 8 + 7 * k
        cv2.rectangle(m, (int(x + k * 10), int(y - hh)), (int(x + k * 10 + 6), int(y)), 1.0, -1, cv2.LINE_AA)
        paint_marks(img, m, (0.95, 0.42, 0.36) if k == 0 else (0.30, 0.27, 0.34), seed=60 + k)


# ------------------------------------------------------------------ shatter
class Shatter:
    """Voronoi shards of the call image. crack(k) draws the spreading cracks before the break;
    draw(dst, img, k) composites the flying shards k frames after the break."""

    def __init__(self, center, seed=5, n=46):
        rng = np.random.default_rng(seed)
        W, H = OUT_W, OUT_H
        pts = []
        cx, cy = center
        for i in range(n):
            r = (rng.random() ** 0.8) * 1150
            a = rng.uniform(0, 2 * math.pi)
            pts.append((float(np.clip(cx + math.cos(a) * r * 0.75, 1, W - 2)), float(np.clip(cy + math.sin(a) * r, 1, H - 2))))
        for x in (0, W / 2, W - 1):
            for y in (0, H / 3, 2 * H / 3, H - 1):
                pts.append((float(np.clip(x, 1, W - 2)), float(np.clip(y, 1, H - 2))))
        sub = cv2.Subdiv2D((0, 0, W, H))
        for p in pts:
            sub.insert(p)
        facets, centers = sub.getVoronoiFacetList([])
        self.shards = []
        for poly, c in zip(facets, centers):
            poly = np.clip(np.float32(poly), [0, 0], [W - 1, H - 1])
            x0, y0 = np.floor(poly.min(0)).astype(int)
            x1, y1 = np.ceil(poly.max(0)).astype(int) + 1
            if x1 - x0 < 4 or y1 - y0 < 4:
                continue
            m = np.zeros((y1 - y0, x1 - x0), np.uint8)
            cv2.fillPoly(m, [np.round((poly - (x0, y0)) * 8).astype(np.int32)], 255, cv2.LINE_AA, shift=3)
            d = np.float32(c) - np.float32(center)
            dist = float(np.linalg.norm(d)) + 1e-3
            dirv = d / dist
            speed = rng.uniform(2600, 3800) * (0.55 + 0.45 * min(1.0, 400 / dist))
            self.shards.append({"poly": poly, "box": (x0, y0, x1, y1), "m": m.astype(np.float32) / 255, "c": np.float32(c),
                                "v": dirv * speed + np.float32([rng.uniform(-80, 80), -rng.uniform(150, 420)]),
                                "spin": rng.uniform(-320, 320), "tumble": rng.uniform(5, 14), "grow": rng.uniform(0.35, 0.9),
                                "dist": dist, "delay": 0, "seed": int(rng.integers(1 << 30))})
        self.center = np.float32(center)

    def crack_lines(self, k_from_break):
        """Crack polylines visible k frames before the break (k = -4, -2): grow outward."""
        reach = {-4: 260, -2: 700}.get(k_from_break, 2000)
        lines = []
        for s in self.shards:
            p = s["poly"]
            for a, b in zip(p, np.roll(p, -1, axis=0)):
                mid = (a + b) / 2
                if np.linalg.norm(mid - self.center) < reach:
                    lines.append((a, b))
        return lines

    def draw_cracks(self, img, k_from_break):
        """Painted hairline cracks: jittered strokes of varying width, a lit side and a shadow side, a soft
        glow, and a bruised, light-catching impact point (no vector outline, no star)."""
        H, W = img.shape[:2]
        lit = np.zeros((H, W), np.float32)
        dark = np.zeros((H, W), np.float32)
        rng = np.random.default_rng(91 + k_from_break)
        for a, b in self.crack_lines(k_from_break):
            n = 5
            pts = [a + (b - a) * (j / n) for j in range(n + 1)]
            d = b - a
            nrm = np.float32([-d[1], d[0]]) / (np.linalg.norm(d) + 1e-3)
            pts = [p + nrm * (rng.uniform(-3, 3) if 0 < j < n else 0) for j, p in enumerate(pts)]
            for p, q in zip(pts, pts[1:]):
                wdt = int(rng.integers(1, 3))
                cv2.line(lit, (int(p[0] * 4), int(p[1] * 4)), (int(q[0] * 4), int(q[1] * 4)), float(rng.uniform(0.6, 1.0)),
                         wdt, cv2.LINE_AA, shift=2)
                cv2.line(dark, (int((p[0] + 1.5) * 4), int((p[1] + 1.5) * 4)), (int((q[0] + 1.5) * 4), int((q[1] + 1.5) * 4)),
                         1.0, wdt + 1, cv2.LINE_AA, shift=2)
        n = brush_noise((H // 4, W // 4), 77, scale=2, angle=0.6, stretch=4)
        n = np.clip(0.75 + 0.5 * cv2.resize(n, (W, H)), 0.3, 1.2)
        lit = cv2.GaussianBlur(lit, (0, 0), 0.7) * n
        dark = cv2.GaussianBlur(dark, (0, 0), 1.0)
        glow = cv2.GaussianBlur(lit, (0, 0), 5)
        img[:] = img * (1 - 0.45 * dark[..., None])
        img[:] = img * (1 - lit[..., None] * 0.8) + np.float32([1.0, 0.93, 0.84]) * lit[..., None] * 0.8
        img[:] = 1 - (1 - img) * (1 - glow[..., None] * np.float32([0.75, 0.80, 1.0]) * 0.5)
        # impact bruise: a soft pale burst with a few short splinters
        cx, cy = self.center
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        r = 26 if k_from_break == -4 else 40
        g = np.exp(-(((xx - cx) ** 2 + (yy - cy) ** 2) / (2 * r * r)))[..., None]
        img[:] = 1 - (1 - img) * (1 - g * np.float32([0.95, 0.92, 0.88]) * 0.75)
        return img

    def draw(self, dst, src, k):
        """Composite the shards k frames after the break (k on 2s)."""
        for s in self.shards:
            kk = k - s["delay"]
            x0, y0, x1, y1 = s["box"]
            patch = np.dstack([src[y0:y1, x0:x1], s["m"]])
            if kk < 0:                                   # still in place, slightly offset along the cracks
                off = s["c"] - self.center
                off = off / (np.linalg.norm(off) + 1e-3) * 3
                _put_affine(dst, patch, s["c"] - (x0, y0), s["c"] + off, 0, 1, 1, 1.0)
                continue
            tt = (kk + 1.5) / 24.0
            pos = s["c"] + s["v"] * tt + np.float32([0, 0.5 * 2600 * tt * tt])
            ang = s["spin"] * tt
            sc = 1 + s["grow"] * tt * 6.0                 # they fly at the camera: grow fast
            sx = math.cos(s["tumble"] * tt)
            fade = {0: 1.0, 2: 0.6}.get(kk, 0.0)
            if fade <= 0:
                continue
            _put_affine(dst, patch, s["c"] - (x0, y0), pos, ang, sc * (0.15 + 0.85 * abs(sx)), sc, fade,
                        edge=True, back=sx < 0)
        return dst


def _put_affine(dst, patch, anchor, pos, ang, sx, sy, opacity, edge=False, back=False):
    a = math.radians(ang)
    ca, sa = math.cos(a), math.sin(a)
    M = np.float32([[ca * sx, -sa * sy, 0], [sa * sx, ca * sy, 0]])
    M[:, 2] = np.float32(pos) - M[:, :2] @ np.float32(anchor)
    H, W = dst.shape[:2]
    h, w = patch.shape[:2]
    corners = np.float32([[0, 0, 1], [w, 0, 1], [w, h, 1], [0, h, 1]]) @ M.T
    bx0, by0 = np.floor(corners.min(0)).astype(int)
    bx1, by1 = np.ceil(corners.max(0)).astype(int)
    bx0, by0, bx1, by1 = max(bx0, 0), max(by0, 0), min(bx1, W), min(by1, H)
    if bx1 <= bx0 or by1 <= by0:
        return
    M2 = M.copy()
    M2[:, 2] -= (bx0, by0)
    out = cv2.warpAffine(patch, M2, (bx1 - bx0, by1 - by0), flags=cv2.INTER_LINEAR, borderValue=0)
    rgb, al = out[..., :3], out[..., 3:4] * opacity
    if back:                                             # the glass's back face: dark, cool
        rgb = rgb * 0.62 + np.float32([0.10, 0.10, 0.18])
    if edge:
        # painted glass: a cool sheen across the face, light catching the edges that face the light
        # (upper left) in a broken dry-brush stroke, the far edges in shadow
        A = out[..., 3]
        gx = cv2.Sobel(A, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(A, cv2.CV_32F, 0, 1, ksize=3)
        facing = np.clip((gx * 0.6 + gy * 0.8), 0, None)          # alpha rises toward the lower right: lit rim on top-left
        away = np.clip(-(gx * 0.6 + gy * 0.8), 0, None)
        hh, ww = A.shape
        nn = brush_noise((max(hh, 8), max(ww, 8)), 5 + hh % 17, scale=2, angle=0.7, stretch=5)[:hh, :ww]
        lit = np.clip(cv2.GaussianBlur(facing, (0, 0), 1.2) * (0.7 + 0.6 * nn), 0, 1)[..., None]
        sh = np.clip(cv2.GaussianBlur(away, (0, 0), 1.5), 0, 1)[..., None]
        yy = np.linspace(0, 1, hh, dtype=np.float32)[:, None, None]
        rgb = rgb * (1 + 0.08 * (1 - yy)) + np.float32([0.05, 0.07, 0.10]) * (1 - yy)
        rgb = rgb * (1 - 0.45 * sh)
        rgb = rgb * (1 - lit * 0.75) + np.float32([1.0, 0.90, 0.78]) * lit * 0.75
    reg = dst[by0:by1, bx0:bx1]
    dst[by0:by1, bx0:bx1] = reg * (1 - al) + rgb * al
