"""TEMPLATE shot module. Copy to src/shots/<your stem>.py (e.g. s03_year2.py) and edit.

One file = spec (planes, sprites, measured points) + render code. Everything time-related comes from
ctx (whatif/shotkit.py): frames are GLOBAL, words carry GLOBAL times. Coordinates are pixels of the
upscaled key work/keys/<key name>.png (1520 px wide); keyprep makes it on first use.
"""
from functools import cached_property

import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS
from whatif.fx2d import Embers
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]            # layer cache name = module name (work/layers/<stem>/)

# ------------------------------------------------------------------ spec (key px)
# Depth bands (0 = farthest, 1 = nearest). Look at work/keys/<key>_depth.png to choose them.
PLANES = [
    L.PlaneSpec("far", 0.00, 0.20, fill="full"),     # "full": fill everything behind (sky / back wall)
    L.PlaneSpec("mid", 0.20, 0.55, radius=60),       # radius: how far the plane extends behind occluders
    L.PlaneSpec("near", 0.55, 1.01, radius=70),
]
# Rigid moving parts (on 2s): envelope polygon, plane index, pivot, anchor line (anchored end stays put).
SPRITES = [
    # L.SpriteSpec("hand", 2, [(x, y), ...], dmin=0.3, pivot=(x, y), anchor=(x0, y0, x1, y1)),
]


def nearness(d):
    """Depth -> camera nearness (0 sky .. 1 closest). Shapes how much each plane slides."""
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()                       # upscaled key + CPU depth, cached
        L.build(STEM, key, depth, PLANES, SPRITES)         # delete work/layers/<stem>/ after spec edits
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.cam = ParallaxCamera(                         # camera on 1s: eased over the whole shot
            W, H, focus=(W * 0.5, H * 0.48), nearness=nearness,
            zoom=Track([(0, 1.0), (d, 1.07, "inout")]),
            push=Track([(0, 0.0), (d, 0.08, "inout")]),
            rise=Track([(0, 0.0), (d, -20.0, "inout")]))
        # sync points from the narration (2s grid). Replace with your shot's words.
        w = ctx.words
        self.f_event = ctx.f(w[len(w) // 2]["w"])          # e.g. ctx.f("forty-nine")
        self.f_tag = ctx.f(w[1]["w"])                      # data tag appears while the number is spoken

    @cached_property
    def planes(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]

    @cached_property
    def embers(self):
        return Embers(16, self.lay.W, self.lay.H, seed=7)

    def frame(self, f):
        t = self.ctx.local(f)                              # camera time (1s)
        th = on2s(f - self.f0)                             # character / FX time (2s)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a = pl["rgb"], pl["a"]
            mine = [s for s in self.lay.sprites if s["plane"] == i]
            if mine:
                rgb, a = rgb.copy(), a.copy()
                for s in mine:                             # pose on 2s, anticipation before big moves
                    k = Track([(0, 0.0), (0.4, -0.3, "inout"), (0.55, 1.0, "out"), (0.9, 0.8, "inout")])(th % 1.0)
                    patch, x0, y0 = deform_sprite(s, angle_deg=4 * k, dy=-6 * k)
                    composite_into(rgb, a, patch, x0, y0)
            rps.append({"rgb": rgb, "a": a, "n": pl["n"]})
        img = self.cam.render(rps, t)
        img = self.embers.draw(self.cam, th, img, intensity=0.6)
        # overlays: year tag, one data tag, an invented figure with its scenario label
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Source fact: 123 million (Org, 2026)", self.f_tag, f_out=self.f_event)
        if f >= self.f_event:
            v = O.roll_value(f, self.f_event, self.f_event + 16, 19.99, 49.99)
            num = O.counter_rgba(v, size=140)
            O.draw_pop(img, num, 90, 420, f, self.f_event)
            O.draw_pop(img, O.scenario_label(), 90 + num.shape[1] - 10, 440, f, self.f_event + 4)
        return img, {}

    def finish_args(self, f, info):
        return {"bloom_strength": 0.5}

    def events(self):
        return [(self.f_event, "event", {}), (self.f_tag, "data_tag", {})]

    def sound(self, snd):
        t0, dur = snd.shot_span()
        snd.bed(A.room_tone(dur + 0.5), t0, -30)                       # ambience, ducked under the voice
        snd.sfx(A.hit(seed=3), snd.at_frame(self.f_event), -16)       # lands on the event frame
        snd.sfx(A.tick(5, 2600), snd.at_frame(self.f_tag), -26, -0.3)


def make(ctx):
    return Shot(ctx)
