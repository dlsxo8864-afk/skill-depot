"""Shot 6, Year 5 (gaming): a gaming cafe where every monitor is red. The kid's controller keeps
crumbling to ash (an ember front eats across it, chunks break off and fall, embers and ash flecks rise,
smoke curls up), the teal flame on the cartridge flickers, the players in the back rock with their hands
on their heads. On "full", "SERVERS FULL" slams onto every monitor in perspective, nearest first and
rippling down the row, with a screen flash, a camera jolt and the whole room flinching.

Key coordinates are pixels of work/keys/y05_gaming_key.png (1520x2701). Shared local helpers come from
s05_year4 (deform_blend, affine_rgba, _sum_keys); written here: clean_key (paints out the static painted
embers in the air and lifts the flame off the plate), red_weight, the crumble model.
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into
from whatif.config import FPS, LAYER_CACHE
from whatif.fx2d import ShapeCanvas, painted_haze, screen_emissive, star4_poly, tapered_streak_poly
from whatif.keyprep import load_rgb
from whatif.screens import ScreenQuad, light_weight
from whatif.shotkit import BaseShot
from whatif.timing import Track, smoothstep

from pathlib import Path

from .s05_year4 import _sum_keys, affine_rgba, deform_blend
from .s05_year4_pose import (aligned_pose, color_match, diff_mask, half_warp, multi_pose, poly_soft, radial,
                             smooth_field)

STEM = __name__.split(".")[-1]
SC = L.WORK_SCALE
CACHE = LAYER_CACHE / STEM

# ------------------------------------------------------------------ spec (key px)
CTRL_POLY = [(615, 1830), (700, 1798), (860, 1786), (995, 1828), (1012, 1950), (995, 2100), (880, 2135),
             (700, 2102), (618, 2000)]
EMBER_ZONE = (540, 1520, 1080, 2320)              # painted embers in the air here are painted out
FLAME_BOX = (1150, 1150, 1450, 1625)
FLAME_BASE = (1265, 1600)
CARTRIDGE = (1225, 1610)
SMOKE_FROM = (790, 1820)

# pose B (assets/key/y05_gaming_poseB.png): head thrown back shouting, hands flung open, the controller gone
POSE_B = Path(__file__).resolve().parents[2] / "assets" / "key" / "y05_gaming_poseB.png"
HERO_B = [[(0, 740), (150, 728), (320, 758), (470, 828), (585, 918), (665, 1022), (715, 1150), (732, 1300),
           (705, 1430), (650, 1478), (720, 1505), (790, 1565), (842, 1635), (900, 1695), (980, 1685), (1060, 1695),
           (1120, 1650), (1175, 1655), (1192, 1900), (1122, 2110), (1092, 2270), (1000, 2350), (700, 2420),
           (400, 2480), (0, 2500)]]
FRAGS_B = [(700, 1790), (866, 1790), (866, 1950), (826, 2080), (766, 2200), (726, 2335), (585, 2335), (640, 2150),
           (690, 1980), (700, 1900)]      # the painted falling pieces of pose B: painted out, re-animated
B_HEAD = (300, 1080)
B_NECK = (390, 1460)
B_LHAND = (600, 1660)
B_RHAND = (1010, 1790)
# the in-between: points of pose B and how far back toward pose A they were (key px); zeros hold the room
AB_PTS = [(300, 1000), (430, 1100), (390, 1460), (600, 1660), (1010, 1790), (820, 1950),
          (100, 2400), (700, 2450), (950, 800), (1250, 1300), (60, 640)]
AB_DISP = [(0, 170), (-60, 230), (-40, 180), (-10, 240), (-110, 290), (-60, 200),
           (0, 0), (0, 0), (0, 0), (0, 0), (0, 0)]

PLANES = [
    L.PlaneSpec("back", 0.00, 0.08, fill="full"),
    L.PlaneSpec("row", 0.08, 0.17, radius=50),
    L.PlaneSpec("near", 0.17, 0.33, radius=60),
    L.PlaneSpec("kid", 0.33, 0.63, radius=70),
    L.PlaneSpec("chair", 0.63, 1.01, radius=80),
]
SPRITES = [
    L.SpriteSpec("guy", 2, [(250, 500), (330, 380), (350, 352), (470, 346), (560, 418), (650, 468), (662, 540),
                            (602, 622), (566, 652), (576, 800), (572, 996), (318, 996), (308, 800), (255, 580)],
                 dmin=0.16, pivot=(430, 990), anchor=(430, 430, 430, 960)),
    L.SpriteSpec("head_r", 1, [(1165, 610), (1180, 520), (1240, 466), (1320, 455), (1392, 498), (1412, 580),
                               (1402, 642), (1165, 652)],
                 dmin=0.06, pivot=(1290, 640), anchor=(1290, 470, 1290, 645)),
    L.SpriteSpec("head_m", 1, [(880, 602), (930, 508), (992, 488), (1062, 518), (1112, 580), (1112, 672),
                               (880, 682)],
                 dmin=0.06, pivot=(1000, 672), anchor=(1000, 500, 1000, 675)),
    L.SpriteSpec("kid_head", 3, [(0, 780), (150, 738), (320, 766), (470, 836), (582, 926), (662, 1028),
                                 (712, 1150), (722, 1300), (692, 1420), (612, 1482), (532, 1560), (470, 1640),
                                 (380, 1662), (250, 1642), (120, 1562), (0, 1502)],
                 dmin=0.38, pivot=(330, 1700), anchor=(330, 900, 330, 1660)),
    L.SpriteSpec("hands", 3, [(420, 1830), (560, 1776), (700, 1786), (860, 1756), (1002, 1796), (1062, 1900),
                              (1072, 2100), (1042, 2262), (900, 2292), (760, 2282), (560, 2152), (420, 2082)],
                 dmin=0.31, pivot=(720, 2240), anchor=(760, 1900, 700, 2240)),
]


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def red_weight(rgb, blur=3):
    """How much of a pixel is lit by the red monitors (red above both green and blue), gated by value."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    w = np.clip((r - np.maximum(g, b) - 0.06) / 0.30, 0, 1) * np.clip((rgb.max(-1) - 0.12) / 0.3, 0, 1)
    return cv2.GaussianBlur(w.astype(np.float32), (0, 0), blur) if blur else w.astype(np.float32)


def unlit_red(rgb):
    lum = rgb @ np.float32([0.40, 0.40, 0.20])
    return lum[..., None] * np.float32([0.50, 0.30, 0.62]) * 0.78


def _red_screen(r, g, b):
    return (r > 0.75) & (g < 0.35) & (b < 0.40)


def clean_key(key_path, depth_path):
    """Paint out the static painted embers floating in the air (they are re-animated) and lift the teal
    flame off the plate (it is redrawn every drawing). Writes the clean key and the flame layer."""
    CACHE.mkdir(parents=True, exist_ok=True)
    kp, fp = CACHE / "clean_key.png", CACHE / "flame.npz"
    if kp.exists() and fp.exists() and kp.stat().st_mtime > key_path.stat().st_mtime:
        return kp, depth_path
    key = load_rgb(key_path)
    H, W = key.shape[:2]
    out = key.copy()
    # embers: small orange blobs outside the controller body
    x0, y0, x1, y1 = EMBER_ZONE
    c = key[y0:y1, x0:x1]
    r, g, b = c[..., 0], c[..., 1], c[..., 2]
    em = ((r > 0.6) & (g > 0.25) & (b < 0.30) & (r - b > 0.35)).astype(np.uint8)
    ctrl = L.poly_mask((H, W), CTRL_POLY)[y0:y1, x0:x1] > 0.5
    em[ctrl] = 0
    n, lab, st, _ = cv2.connectedComponentsWithStats(em)
    keep = np.zeros_like(em)
    for i in range(1, n):
        if st[i, 4] < 140:
            keep[lab == i] = 1
    keep = cv2.dilate(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))
    u8 = (np.clip(c, 0, 1) * 255).astype(np.uint8)
    inp = cv2.inpaint(u8, keep, 6, cv2.INPAINT_TELEA).astype(np.float32) / 255
    soft = cv2.GaussianBlur(keep.astype(np.float32), (0, 0), 1.2)[..., None]
    out[y0:y1, x0:x1] = c * (1 - soft) + inp * soft
    # flame: teal light strength -> alpha; the plate behind is inpainted from the desk and stand around it
    fx0, fy0, fx1, fy1 = FLAME_BOX
    c = out[fy0:fy1, fx0:fx1].copy()
    tw = light_weight(c, "teal", blur=0)
    lumc = c.max(-1)
    a = np.clip((tw - 0.15) / 0.5, 0, 1) * np.clip((lumc - 0.30) / 0.25, 0, 1)
    a = cv2.GaussianBlur(a, (0, 0), 0.8)
    hole = (cv2.dilate((a > 0.05).astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))))
    # the cartridge itself stays on the plate
    cx, cy = CARTRIDGE
    hole[cy - fy0 - 22:, :] = 0
    u8 = (np.clip(c, 0, 1) * 255).astype(np.uint8)
    behind = cv2.inpaint(u8, hole, 9, cv2.INPAINT_TELEA).astype(np.float32) / 255
    n2 = L.brush_noise(behind.shape[:2], 77, scale=4, angle=-0.4, stretch=5)[..., None]
    behind = np.clip(behind * (1 + 0.04 * n2), 0, 1)
    hs = cv2.GaussianBlur(hole.astype(np.float32), (0, 0), 1.5)[..., None]
    out[fy0:fy1, fx0:fx1] = c * (1 - hs) + behind * hs
    np.savez_compressed(fp, rgb=(c * 255).astype(np.uint8), a=(a * 255).astype(np.uint8))
    cv2.imwrite(str(kp), cv2.cvtColor((np.clip(out, 0, 1) * 255 + 0.5).astype(np.uint8), cv2.COLOR_RGB2BGR))
    return kp, depth_path


# ------------------------------------------------------------------ the error screen
SW, SH = 900, 560
CREAM = (255, 240, 226)


class ErrorScreen:
    """A red error page: brushy red field, left-aligned SERVERS / FULL, a painted warning sign at right."""

    def __init__(self, c0):
        self.c0 = np.float32(c0)

    @cached_property
    def base(self):
        yy = np.linspace(0, 1, SH, dtype=np.float32)[:, None, None]
        n = L.brush_noise((SH, SW), 501, scale=5, angle=-0.3, stretch=8)[..., None]
        n2 = L.brush_noise((SH, SW), 502, scale=12, angle=1.0, stretch=3)[..., None]
        return np.clip(self.c0 * (1.02 - 0.08 * yy) * (1 + 0.04 * n + 0.03 * n2), 0, 1).astype(np.float32)

    @cached_property
    def text(self):
        canvas = np.zeros((SH, SW, 4), np.float32)
        band = O.painted_swatch(SW + 60, 330, seed=503, color=(0.40, 0.02, 0.07), opacity=0.80, rough=0.16, radius=4)
        T.over_rgba(canvas, band, -30, 100)
        for s, size, y, seed in (("SERVERS", 170, 108, 504), ("FULL", 196, 262, 505)):
            a = O._text_alpha(s, T.font("display", size), tracking=4)
            rgba, pad = T.styled_text_rgba(a, CREAM, seed=seed, shadow=(70, 4, 14), shadow_off=(5, 6), soft_shadow=10,
                                           grad=0.10)
            T.over_rgba(canvas, rgba, 46 - pad, y - pad)
        # warning sign: a painted cream triangle with a red bar and dot
        tri = np.zeros((SH, SW), np.float32)
        cx, cy, r = 700, 282, 102
        pts = np.float32([[cx, cy - r], [cx + r * 0.95, cy + r * 0.72], [cx - r * 0.95, cy + r * 0.72]])
        cv2.fillPoly(tri, [np.round(pts * 8).astype(np.int32)], 1.0, cv2.LINE_AA, shift=3)
        tri = T.rough_alpha(tri, 506, 0.8)
        mark = np.zeros((SH, SW), np.float32)
        cv2.rectangle(mark, (cx - 11, cy - 52), (cx + 11, cy + 22), 1.0, -1)
        cv2.circle(mark, (cx, cy + 48), 13, 1.0, -1)
        mark = T.rough_alpha(cv2.GaussianBlur(mark, (0, 0), 1.0), 507, 0.8)
        trgba, pad = T.styled_text_rgba(tri, CREAM, seed=508, shadow=(70, 4, 14), shadow_off=(5, 6), soft_shadow=10)
        T.over_rgba(canvas, trgba, -pad, -pad)
        canvas[..., :3] = canvas[..., :3] * (1 - mark[..., None]) + np.float32([0.62, 0.04, 0.10]) * mark[..., None]
        return canvas

    @cached_property
    def text_mid(self):
        """Second monitor: seen edge-on, so the type is painted wide (perspective squeezes it back) and fills
        the screen: SERVERS over a huge FULL."""
        canvas = np.zeros((SH, SW, 4), np.float32)
        band = O.painted_swatch(SW + 60, SH - 40, seed=513, color=(0.40, 0.02, 0.07), opacity=0.78, rough=0.16, radius=4)
        T.over_rgba(canvas, band, -30, 20)
        y = 34
        for s_, hgt, seed in (("SERVERS", 170, 514), ("FULL", 300, 515)):
            a = O._text_alpha(s_, T.font("display", 200), tracking=6)
            a = cv2.resize(a, (int(SW * 0.9), hgt), interpolation=cv2.INTER_AREA)
            rgba, pad = T.styled_text_rgba(a, CREAM, seed=seed, shadow=(70, 4, 14), shadow_off=(8, 6), soft_shadow=8,
                                           grad=0.10)
            T.over_rgba(canvas, rgba, SW * 0.05 - pad, y - pad)
            y += hgt + 26
        return canvas

    @cached_property
    def text_far(self):
        """Far monitors: only shapes (a warning sign and two bars of 'text') that read as the same page."""
        canvas = np.zeros((SH, SW, 4), np.float32)
        a = np.zeros((SH, SW), np.float32)
        cx, cy, r = SW * 0.5, SH * 0.30, 120
        pts = np.float32([[cx, cy - r], [cx + r * 1.05, cy + r * 0.8], [cx - r * 1.05, cy + r * 0.8]])
        cv2.fillPoly(a, [np.round(pts * 8).astype(np.int32)], 1.0, cv2.LINE_AA, shift=3)
        cv2.rectangle(a, (int(SW * 0.12), int(SH * 0.62)), (int(SW * 0.88), int(SH * 0.74)), 1.0, -1)
        cv2.rectangle(a, (int(SW * 0.25), int(SH * 0.80)), (int(SW * 0.75), int(SH * 0.90)), 1.0, -1)
        a = T.rough_alpha(a, 516, 0.8)
        rgba, pad = T.styled_text_rgba(a, CREAM, seed=517, shadow=(70, 4, 14), shadow_off=(6, 6), soft_shadow=8)
        T.over_rgba(canvas, rgba, -pad, -pad)
        return canvas

    def draw(self, d, blink=1.0, kind="near"):
        """d = frames since this screen's slam (None before); kind: near, mid or far layout."""
        cv = self.base.copy()
        if d is None:
            return cv
        s = {0: 1.18, 2: 0.95, 4: 1.02}.get(d, 1.0)
        flash = {0: 0.34, 2: 0.10}.get(d, 0.0)
        txt = {"near": self.text, "mid": self.text_mid, "far": self.text_far}[kind]
        p, ox, oy = T.transform_rgba(txt, s, 0, origin=(SW * 0.42, SH * 0.5))
        T.over(cv, p, ox, oy, opacity=blink if d >= 6 else 1.0)
        if flash:                                                  # a hot red-white flash, two drawings
            cv = 1 - (1 - cv) * (1 - np.float32([1.0, 0.55, 0.50]) * flash)
        return np.clip(cv, 0, 1)


# ------------------------------------------------------------------ the shot
class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        self.key_path = key
        ck, cd = clean_key(key, depth)
        self.depth_path = depth
        L.build(STEM, ck, cd, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_play = ctx.f("play")
        self.f_servers = ctx.f("servers")
        self.f_full = ctx.f("full")
        self.f_log = ctx.f("log")
        self.f_tag_out = self.f_full - 2               # the tag clears so the players' reaction reads on "full"
        # pose to pose: A flinches on "full", one smear drawing, then pose B held and acted
        self.f_smear = self.f_full + 2
        self.f_b = self.f_smear + 2
        fo0, fo1 = (W * 0.56, H * 0.50), (W * 0.58, H * 0.52)
        tr = Track([(0, fo0), (d, fo1, "inout")])
        tf = (self.f_full - self.f0) / FPS

        def focus(t):
            x, y = tr(t)
            u = t - tf
            if u >= 0:                                       # the jolt when the screens slam, on 1s
                k = math.exp(-u * 7.5) * math.sin(u * 62)
                x, y = x - 7 * k, y + 10 * k
            return (x, y)

        def roll(t):
            u = t - tf
            return 0.55 * math.exp(-u * 7.5) * math.sin(u * 50 + 0.6) if u >= 0 else 0.0

        self.cam = ParallaxCamera(W, H, focus=focus, nearness=nearness,
                                  zoom=Track([(0, 1.0), (d, 1.085, "inout")]),
                                  push=Track([(0, 0.0), (d, 0.075, "inout")]),
                                  rise=Track([(0, 0.0), (d, -16.0, "inout")]), roll=roll)

    # ------------------------------------------------------------ prepared
    @cached_property
    def planes(self):
        out = []
        for i, p in enumerate(self.lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            pl = {"rgb": rgb, "a": p["a"].astype(np.float32) / 255, "n": nearness(p["d"].astype(np.float32) / 65535)}
            if i >= 1:
                rw = red_weight(rgb)
                pl["rw"] = rw
                pl["unlit"] = rgb * (1 - rw[..., None]) + unlit_red(rgb) * rw[..., None]
            out.append(pl)
        # teal spill of the flame on the desk (plane 2), to flicker with the flame
        p2 = out[2]
        Hh, Ww = p2["rgb"].shape[:2]
        gy, gx = np.mgrid[0:Hh, 0:Ww].astype(np.float32)
        dist = np.hypot(gx - FLAME_BASE[0] * SC, (gy - FLAME_BASE[1] * SC) * 1.6)
        p2["teal"] = (light_weight(p2["rgb"], "teal") * np.clip(1 - dist / (260 * SC), 0, 1))[..., None]
        return out

    @cached_property
    def screens(self):
        """Every red monitor: quad from its red pixels, the plane it lives in, ripple order (nearest first)."""
        key = load_rgb(self.key_path, width=self.lay.W)
        dep = cv2.imread(str(self.depth_path), -1).astype(np.float32) / 65535
        dep = cv2.resize(dep, (self.lay.W, self.lay.H), interpolation=cv2.INTER_AREA)
        r, g, b = key[..., 0], key[..., 1], key[..., 2]
        m = _red_screen(r, g, b).astype(np.uint8)
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        res = []
        for i in range(1, n):
            x, y, w, h, a = st[i]
            # monitors: big enough, above the desk, not the hair rim on the far left
            if a < 600 * SC * SC or y > 1000 * SC or x < 200 * SC or h < 30 * SC:
                continue
            mm = lab == i
            sq = ScreenQuad.detect(np.where(mm[..., None], key, 0), _red_screen, dilate=5, overscan=1.02)
            dd = float(np.median(dep[mm]))
            plane = next(k for k, p in enumerate(PLANES) if p.dmin <= dd < p.dmax)
            res.append({"sq": sq, "plane": plane, "area": a, "cx": cen[i][0]})
        res.sort(key=lambda s: -s["area"])
        for k, s in enumerate(res):
            s["f"] = self.f_full + 2 * k
            s["kind"] = "near" if k == 0 else ("mid" if k == 1 else "far")
        return res

    @cached_property
    def error_screen(self):
        return ErrorScreen(np.float32([0.97, 0.15, 0.24]))

    @cached_property
    def sprites(self):
        res = {}
        for s in self.lay.sprites:
            s2 = dict(s)
            rgba = s["rgba"].astype(np.float32) / 255
            s2["rgba_f"] = rgba
            s2["w_f"] = s["w"].astype(np.float32) / 255
            rw = red_weight(rgba[..., :3])
            s2["rw"] = rw
            s2["unlit"] = rgba[..., :3] * (1 - rw[..., None]) + unlit_red(rgba[..., :3]) * rw[..., None]
            x0, y0, x1, y1 = s["bbox"]
            h, w = rgba.shape[:2]
            gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
            gx += x0
            gy += y0
            if s["name"] == "kid_head":
                c = np.float32([380, 1300]) * SC
                rr = np.hypot(gx - c[0], (gy - c[1]) * 1.1)
                s2["lag"] = np.clip((rr - 200 * SC) / (280 * SC), 0, 1) ** 1.2
            elif s["name"] == "guy":
                s2["lag"] = np.clip((560 * SC - gy) / (160 * SC), 0, 1)     # arms and head trail the torso
            else:
                s2["lag"] = None
            if s["name"] == "hands":
                s2["ctrl"] = L.poly_mask((self.lay.H, self.lay.W), [(x * SC, y * SC) for x, y in CTRL_POLY])[y0:y1, x0:x1]
                c3 = rgba[..., :3]
                skin = (c3[..., 0] > 0.33) & (c3[..., 0] - c3[..., 2] > 0.05) & (c3.max(-1) > 0.36)
                skin = cv2.morphologyEx(skin.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
                skin = cv2.GaussianBlur(cv2.dilate(skin, np.ones((5, 5), np.uint8)).astype(np.float32), (0, 0), 1.5)
                s2["ctrl"] = s2["ctrl"] * (1 - np.clip(skin, 0, 1))
                # what is behind the controller: the lap and the dark under the desk, continued from the
                # surrounding plate (never the hands) so a broken-away piece shows the room, not a hole
                key = load_rgb(CACHE / "clean_key.png", width=self.lay.W)[y0:y1, x0:x1]
                cm = L.poly_mask((self.lay.H, self.lay.W), [(x * SC, y * SC) for x, y in CTRL_POLY])[y0:y1, x0:x1]
                cm = cv2.dilate(cm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
                valid = ((cm < 0.1) & (skin < 0.1)).astype(np.float32)
                beh = L.textured_fill(key, valid, 61)
                s2["behind"] = cv2.GaussianBlur(beh, (0, 0), 2.0) * 0.82
                s2["gx"], s2["gy"] = gx / SC, gy / SC             # key px of every crop pixel
                rng = np.random.default_rng(9)
                s2["edge_noise"] = cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), 6)
                s2["edge_noise"] /= s2["edge_noise"].std() + 1e-6
                # which breakable piece every controller pixel belongs to (nearest cell, wobbly borders)
                P = np.float32([c["p"] for c in self.cells])
                kx, ky = gx / SC + s2["edge_noise"] * 7, gy / SC + s2["edge_noise"] * 5
                best = np.full((h, w), np.inf, np.float32)
                lab = np.full((h, w), len(P), np.int32)
                for j, (px, py) in enumerate(P):
                    d2 = (kx - px) ** 2 + (ky - py) ** 2
                    m = d2 < best
                    best[m] = d2[m]
                    lab[m] = j
                lab[best > 34 ** 2] = len(P)
                s2["cell"] = lab
                s2["speck"] = np.clip(cv2.GaussianBlur(rng.standard_normal((h, w)).astype(np.float32), (0, 0), 0.7)
                                      * 1.8 - 1.6, 0, 1)
            res[s["name"]] = s2
        return res

    @cached_property
    def pose_b(self):
        Bk = aligned_pose(self.key_path, POSE_B, CACHE / "poseB_aligned.png").copy()
        # paint out the falling pieces painted into pose B (they are re-animated as FX)
        fm = L.poly_mask(Bk.shape[:2], FRAGS_B)
        u8 = (np.clip(Bk, 0, 1) * 255).astype(np.uint8)
        med = cv2.medianBlur(u8, 31).astype(np.float32) / 255
        r, g, b = Bk[..., 0], Bk[..., 1], Bk[..., 2]
        skin = (r > 0.5) & (g > 0.33) & (r - b > 0.08)
        frag = ((np.abs(Bk - med).max(-1) > 0.07) | ((r - b > 0.18) & (r > 0.3))) & ~skin & (fm > 0.5)
        frag = cv2.dilate(frag.astype(np.uint8), np.ones((7, 7), np.uint8)) * (fm > 0.5)
        Bk = cv2.inpaint(u8, frag.astype(np.uint8), 7, cv2.INPAINT_TELEA).astype(np.float32) / 255
        W, H = self.lay.W, self.lay.H
        B = cv2.resize(Bk, (W, H), interpolation=cv2.INTER_AREA)
        A = load_rgb(self.key_path, width=W)
        # only the gamer changes: B's pixels where the paintings really differ inside HERO_B, pose A elsewhere
        M = diff_mask(A, B, poly_soft((H, W), HERO_B, SC))
        B = color_match(B, A, M)
        fx, fy = smooth_field((H, W), [(x * SC, y * SC) for x, y in AB_PTS],
                              [(x * SC, y * SC) for x, y in AB_DISP], 230 * SC)
        ab = half_warp(B, fx, fy, 0.5)                   # the one in-between drawing, B halfway back to A
        ab_m = M              # the room behind both paintings is the same, so the stretch fills the whole area
        ys, xs = np.nonzero(M > 0.003)
        x0, y0, x1, y1 = int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1
        rgb, abc = B[y0:y1, x0:x1], ab[y0:y1, x0:x1]
        rw, rwa = red_weight(rgb), red_weight(abc)
        hw = rgb.shape[:2]
        gy = np.mgrid[0:hw[0], 0:hw[1]][0].astype(np.float32) + y0
        upper = np.clip((2450 * SC - gy) / (450 * SC), 0, 1)
        head = radial(hw, x0, y0, np.float32(B_HEAD) * SC, 260 * SC, 520 * SC) * upper
        hair = head * np.clip((1060 * SC - gy) / (220 * SC), 0, 1)
        n3, a3 = self.planes[3]["n"], self.planes[3]["a"]
        w = np.clip(a3, 0.02, 1).astype(np.float32)
        ns = cv2.GaussianBlur(n3 * w, (0, 0), 40) / (cv2.GaussianBlur(w, (0, 0), 40) + 1e-6)
        return {"rgb": rgb, "a": M[y0:y1, x0:x1], "unlit": rgb * (1 - rw[..., None]) + unlit_red(rgb) * rw[..., None],
                "ab": abc, "ab_a": ab_m[y0:y1, x0:x1],
                "ab_unlit": abc * (1 - rwa[..., None]) + unlit_red(abc) * rwa[..., None],
                "M": M, "n3": (n3 * (1 - M) + ns * M).astype(np.float32),
                "x0": x0, "y0": y0, "upper": upper, "head": head, "hair": hair,
                "lhand": radial(hw, x0, y0, np.float32(B_LHAND) * SC, 120 * SC, 270 * SC),
                "rhand": radial(hw, x0, y0, np.float32(B_RHAND) * SC, 110 * SC, 250 * SC)}

    def _vback(self):
        """Per-pixel vector from pose B back to where pose A was (crop px): the head came up from lower right,
        the hands came up from the lap."""
        P = self.pose_b
        hx, hy = np.float32([100, 170]) * SC
        bx, by = np.float32([-40, 250]) * SC
        w = P["head"]
        return (w * hx + (1 - w) * bx) * P["upper"], (w * hy + (1 - w) * by) * P["upper"]

    def pose_state(self, f):
        """"A" (with the flinch-down anticipation drawings on "full"), "AB" (the one in-between), "B"."""
        fh = f - f % 2
        return "B" if fh >= self.f_b else ("AB" if fh >= self.f_smear else "A")

    def pose_b_patch(self, f, ratio):
        fh = f - f % 2
        P = self.pose_b
        x0, y0 = P["x0"], P["y0"]
        if fh < self.f_b:                                   # the in-between: one drawing, no cross-fade
            lit = P["ab_unlit"] + (P["ab"] - P["ab_unlit"]) * ratio
            return np.dstack([lit, P["ab_a"]]).astype(np.float32), x0, y0
        lit = P["unlit"] + (P["rgb"] - P["unlit"]) * ratio
        rgba = np.dstack([lit, P["a"]]).astype(np.float32)
        vx, vy = self._vback()
        d = fh - self.f_b
        # overshoot past B and settle, then a shout that shakes the head on 2s, trembling hands
        k = _sum_keys([(0, 1.0), (2, -0.35), (4, 0.12), (6, 0.0)], d)
        gy, gx = np.mgrid[0:vx.shape[0], 0:vx.shape[1]].astype(np.float32)
        if k:
            rgba = cv2.remap(rgba, gx + 0.12 * k * vx, gy + 0.12 * k * vy, cv2.INTER_LINEAR,
                             borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        shake = [0.0, -2.4, 1.4, -1.8, 0.8][(d // 2) % 5] if d >= 0 else 0.0
        shake_l = [0.0, -2.4, 1.4, -1.8, 0.8][(max(d - 2, 0) // 2) % 5]
        rng = np.random.default_rng(fh)
        tl, tr_ = rng.uniform(-1, 1, 3), rng.uniform(-1, 1, 3)
        lift = -min(max(d, 0) / 16, 1.0) * 12
        neck = np.float32(B_NECK) * SC
        parts = [(P["head"] - P["hair"], neck, {"angle_deg": shake, "dy": 1.5 * math.sin(d * 1.3) * SC}),
                 (P["hair"], neck, {"angle_deg": shake_l * 1.3, "dy": 1.5 * math.sin((d - 2) * 1.3) * SC}),
                 (P["lhand"], np.float32([520, 1960]) * SC,
                  {"angle_deg": 2.5 * tl[0], "dx": 3 * tl[1] * SC, "dy": (3 * tl[2] + lift) * SC}),
                 (P["rhand"], np.float32([960, 2050]) * SC,
                  {"angle_deg": 2.5 * tr_[0], "dx": 3 * tr_[1] * SC, "dy": (3 * tr_[2] + lift) * SC})]
        return multi_pose(rgba, x0, y0, parts), x0, y0

    @cached_property
    def flame(self):
        z = np.load(CACHE / "flame.npz")
        rgb = z["rgb"].astype(np.float32) / 255
        a = z["a"].astype(np.float32) / 255
        x0, y0, x1, y1 = FLAME_BOX
        s = SC
        rgb = cv2.resize(rgb, (round((x1 - x0) * s), round((y1 - y0) * s)), interpolation=cv2.INTER_AREA)
        a = cv2.resize(a, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_AREA)
        return {"rgb": rgb, "a": a, "x0": round(x0 * s), "y0": round(y0 * s)}

    @cached_property
    def cells(self):
        """Pieces of the controller that break off: a jittered grid over its right two-thirds."""
        rng = np.random.default_rng(14)
        cells = []
        for y in range(1790, 2150, 28):
            for x in range(690, 1030, 28):
                p = np.float32([x + rng.uniform(-8, 8), y + rng.uniform(-8, 8)])
                if cv2.pointPolygonTest(np.float32(CTRL_POLY), (float(p[0]), float(p[1])), True) < -12:
                    continue
                cells.append({"p": p, "jit": int(rng.integers(0, 4)) * 2, "r": rng.uniform(19, 25),
                              "seed": int(rng.integers(1 << 30)), "spin": rng.uniform(-40, 40),
                              "vx": rng.uniform(-50, 30)})
        for c in cells:
            c["f"] = self.loss_frame(c["p"][0] + (c["p"][1] - 1950) * 0.12)
        return cells

    @cached_property
    def haze(self):
        return painted_haze(520, 160, seed=31, blobs=6, softness=16)

    # ------------------------------------------------------------ state
    def front_x(self, f):
        """Key-px x of the ember front eating leftward across the controller (on 2s)."""
        fh = f - f % 2
        return float(Track([(self.f0, 880.0), (self.f_full, 800.0, "linear"), (self.f_full + 30, 655.0, "in")])(fh))

    def loss_x(self, f):
        """Key-px x behind which the ash has broken away (lags the ember front)."""
        return float(Track([(self.f0, 1030.0), (self.f_full, 920.0, "linear"), (self.f1 + 10, 770.0, "in")])(f))

    def loss_frame(self, x):
        for f in range(self.f0 + self.f0 % 2, self.f1 + 60, 2):          # even frames: the 2s grid
            if self.loss_x(f) <= x:
                return f
        return self.f1 + 60

    def flame_state(self, f):
        fh = (f - f % 2) // 2
        rng = np.random.default_rng(1000 + fh)
        return {"h": rng.uniform(0.9, 1.14), "sway": rng.uniform(-1, 1), "lum": rng.uniform(0.85, 1.15), "k": fh}

    def flash(self, f):
        fh = f - f % 2
        v = 0.0
        for k, s in enumerate(self.screens):
            d = fh - s["f"]
            amp = 1.0 if k == 0 else 0.35 / k
            v += amp * {0: 1.0, 2: 0.3}.get(d, 0.0)
        return v

    def blink(self, f):
        fh = f - f % 2
        return 0.82 if ((fh - self.f_full) // 2) % 5 == 4 else 1.0

    def guy_pose(self, f):
        fh = f - f % 2
        t = (fh - self.f0) / FPS
        rock = math.sin(t * 2 * math.pi / 1.1)
        k = float(Track([(self.f_full - 4, 0.0), (self.f_full - 2, -0.35, "inout"), (self.f_full + 2, 1.0, "out"),
                         (self.f_full + 6, 0.8, "inout"), (self.f_full + 16, -0.5, "inout"),
                         (self.f_full + 24, -0.4, "inout")])(fh))
        return {"angle_deg": 1.8 * rock - 5.5 * k, "dx": (2 * rock - 5 * k) * SC, "dy": (-13 * k) * SC}

    def seated_pose(self, f, phase, k0):
        fh = f - f % 2
        t = (fh - self.f0) / FPS
        bob = math.sin(t * 2 * math.pi / 0.9 + phase)
        k = _sum_keys([(0, 0.0), (2, 1.0), (6, 0.5), (12, 0.2), (40, 0.2)], fh - k0)
        return {"angle_deg": 1.8 * bob - 5 * k, "dx": 2.5 * bob * SC, "dy": (-11 * k + 2 * bob) * SC}

    def kid_pose(self, f):
        fh = f - f % 2
        t = (fh - self.f0) / FPS
        br = math.sin(t * 2 * math.pi * 0.6)
        # anticipation: the slam makes him flinch down into his shoulders, two drawings, before the head snaps back
        k = _sum_keys([(self.f_full - 4, 0.0), (self.f_full - 2, 0.6), (self.f_full, 1.0)], fh) if fh <= self.f_full else 0
        return {"angle_deg": -2.5 * k + 0.2 * br, "dx": 8 * k * SC, "dy": (26 * k + 1.2 * br) * SC,
                "scale": 1 - 0.03 * k}

    def hands_pose(self, f):
        fh = f - f % 2
        rng = np.random.default_rng(fh)
        tr = rng.uniform(-1, 1, 2) * 1.4
        k = _sum_keys([(self.f_full - 4, 0.0), (self.f_full - 2, 0.6), (self.f_full, 1.0)], fh) if fh <= self.f_full else 0
        return {"angle_deg": 1.2 * k + 0.15 * tr[0], "dx": (tr[0] + 4 * k) * SC, "dy": (tr[1] + 14 * k) * SC}

    # ------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        fh = f - f % 2
        fl = self.flash(f)
        after = 1.0 if fh >= self.f_full + 4 else 0.0
        ratio = np.float32([1 + 0.45 * fl + 0.03 * after, 1 + 0.10 * fl + 0.06 * after, 1 + 0.10 * fl + 0.06 * after])
        fs = self.flame_state(f)
        rps = []
        for i, pl in enumerate(self.planes):
            rgb, a = pl["rgb"], pl["a"]
            if i >= 1:
                rgb = pl["unlit"] + (pl["rgb"] - pl["unlit"]) * ratio
            mine = [s for s in self.screens if s["plane"] == i]
            spr = [n for n, s in self.sprites.items() if s["plane"] == i]
            if mine or spr or i == 2:
                rgb = rgb.copy() if rgb is pl["rgb"] else rgb
                a = a.copy()
            for s in mine:
                if fh < s["f"]:
                    continue                                    # the painted red screen until its slam
                cv = self.error_screen.draw(fh - s["f"], self.blink(f), s["kind"])
                s["sq"].place(rgb, a, cv, glass=0.18)
            if i == 2:
                rgb = rgb * (1 + (fs["lum"] - 1) * 0.9 * pl["teal"])
                self._flame_into(rgb, a, f, fs)
            swapped = fh >= self.f_smear
            n = pl["n"]
            if swapped and i in (3, 4):
                rgb = rgb.copy() if rgb is pl["rgb"] else rgb
                a = a.copy()
            if swapped and i == 4:
                a *= 1 - self.pose_b["M"]
            for name in spr:
                self._sprite_into(rgb, a, name, f, ratio, rest=swapped and name in ("kid_head", "hands"))
            if swapped and i == 3:                       # under pose B the A sprites sit at rest
                a *= 1 - self.pose_b["M"]
                patch, x0, y0 = self.pose_b_patch(f, ratio)
                composite_into(rgb, a, patch, x0, y0)
                n = self.pose_b["n3"]
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        img = self._crumble_fx(img, f, t)
        img = self._flame_fx(img, f, t, fs)
        if fl > 0:                                                   # the room flashes red with the slam
            k = min(fl, 1.0) * 0.12
            img = 1 - (1 - img) * (1 - np.float32([1.0, 0.10, 0.08]) * k)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, "Steam record: 43.5 million players at once", self.f_play, self.f_tag_out, size=38)
        return img, {"flash": fl}

    def _sprite_into(self, rgb, a, name, f, ratio, rest=False):
        s = self.sprites[name]
        sp = dict(s)
        lit = s["unlit"] + (s["rgba_f"][..., :3] - s["unlit"]) * ratio
        alpha = s["rgba_f"][..., 3]
        if name == "hands" and not rest:
            lit, alpha = self._crumble(lit, alpha, s, f)
        sp["rgba_f"] = np.dstack([lit, alpha])
        if name == "guy":
            pose, kw = self.guy_pose(f), {"lag_pose": self.guy_pose(f - 2), "lag_w": s["lag"] * 0.8}
        elif name == "head_r":
            pose, kw = self.seated_pose(f, 0.0, self.screens[0]["f"] + 4), {}
        elif name == "head_m":
            pose, kw = self.seated_pose(f, 2.1, self.screens[0]["f"] + 2), {}
        elif name == "kid_head":
            pose, kw = self.kid_pose(f), {"lag_pose": self.kid_pose(f - 4), "lag_w": s["lag"] * 0.9}
        else:
            pose, kw = self.hands_pose(f), {}
        if rest:
            pose, kw = {"angle_deg": 0.0, "dx": 0.0, "dy": 0.0}, {}
        pose = {k: float(v) for k, v in pose.items()}
        if "lag_pose" in kw:
            kw["lag_pose"] = {k: float(v) for k, v in kw["lag_pose"].items()}
            kw["lag_w"] = kw["lag_w"].astype(np.float32)
        patch, x0, y0 = deform_blend(sp, pose, **kw)
        composite_into(rgb, a, patch, x0, y0)

    def _crumble(self, lit, alpha, s, f):
        """Ash creeps left behind a broken ember front; where pieces have fallen out, a charred cavity
        with a cooling ember lip is left (the hand-held shape stays readable)."""
        fh = f - f % 2
        fx = self.front_x(f)
        gx = s["gx"] + s["edge_noise"] * 16
        ctrl = s["ctrl"]
        burnt = np.clip((gx - fx) / 14, 0, 1) * ctrl
        lum = lit.mean(-1, keepdims=True)
        ash = np.float32([0.26, 0.22, 0.27]) * (0.7 + 0.8 * lum) + s["speck"][..., None] * np.float32([0.42, 0.38, 0.40])
        lit = lit * (1 - burnt[..., None] * 0.85) + ash * burnt[..., None] * 0.85
        # the front: glowing patches, not a line (broken by a second noise that shifts on 2s)
        brk = np.clip(np.roll(s["edge_noise"], (fh // 2) * 7, axis=0) * 0.9 + 0.35, 0, 1)
        band = np.exp(-((gx - fx - 6) / 13) ** 2) * ctrl * brk
        flick = 0.8 + 0.2 * math.sin(fh * 1.7)
        lit = lit * (1 - 0.35 * band[..., None]) + band[..., None] * np.float32([0.95, 0.30, 0.06]) * 0.85 * flick
        hot = np.clip(band * 1.4 - 0.95, 0, 1)
        lit = lit + hot[..., None] * np.float32([0.5, 0.42, 0.25]) * flick
        # cracks behind the front glow on and off
        crack = np.clip(s["edge_noise"] * 2 - 2.2, 0, 1) * burnt * (0.5 + 0.5 * math.sin(fh * 0.9 + 1))
        lit = lit + crack[..., None] * np.float32([1.0, 0.36, 0.08]) * 0.7
        # pieces gone: whole Voronoi pieces, and only from the outer edge inward (the silhouette is eaten,
        # never holed); a hot lip where ash meets the break, dust crumbs on the remaining crust
        fallen = np.array([fh >= c["f"] for c in self.cells] + [False])
        gone = fallen[s["cell"]].astype(np.float32) * (ctrl > 0.3)
        gone = cv2.GaussianBlur(gone, (0, 0), 0.9)
        lip = np.clip(cv2.GaussianBlur(gone, (0, 0), 2.5) - gone, 0, 1) * 3.0 * (ctrl > 0.3)
        lit = lit * (1 - gone[..., None]) + s["behind"] * gone[..., None]
        lit = lit + lip[..., None] * np.float32([1.0, 0.40, 0.08]) * 0.9 * flick
        return np.clip(lit, 0, 1.4), alpha

    def _flame_into(self, rgb, a, f, fs):
        fl = self.flame
        frgb, fa = fl["rgb"], fl["a"]
        h, w = fa.shape
        gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
        by = FLAME_BASE[1] * SC - fl["y0"]
        bx = FLAME_BASE[0] * SC - fl["x0"]
        up = np.clip((by - gy) / by, 0, 1)                 # 0 at the base, 1 at the tips
        k = fs["k"]
        wave = np.sin(gy * 0.045 - k * 1.9) * 7 + np.sin(gy * 0.11 + k * 2.7) * 3
        sx = gx - (wave + fs["sway"] * 10) * up ** 1.4
        sy = by - (by - gy) / fs["h"]
        p = cv2.remap(np.dstack([frgb, fa]), sx.astype(np.float32), sy.astype(np.float32), cv2.INTER_LINEAR,
                      borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        x0, y0 = fl["x0"], fl["y0"]
        seg = rgb[y0:y0 + h, x0:x0 + w]
        pa = p[..., 3:4]
        rgb[y0:y0 + h, x0:x0 + w] = seg * (1 - pa) + np.clip(p[..., :3] * fs["lum"], 0, 1) * pa
        a[y0:y0 + h, x0:x0 + w] = np.maximum(a[y0:y0 + h, x0:x0 + w], pa[..., 0])

    def _flame_fx(self, img, f, t, fs):
        """Teal tongues breaking off the flame tips, on 2s."""
        H, W = img.shape[:2]
        sc = ShapeCanvas(W, H)
        rng = np.random.default_rng(fs["k"] * 7 + 3)
        n = float(nearness(np.float32(0.26)))
        s = self.cam.scale_at(n, t) * SC
        for j in range(2):
            p = np.float32([rng.uniform(1290, 1390), rng.uniform(1240, 1330)])
            q = self.cam.screen_point(p * SC, n, t)
            sc.fill(tapered_streak_poly(q, (rng.uniform(-0.3, 0.3), -1), rng.uniform(20, 38) * s, rng.uniform(5, 8) * s),
                    value=int(rng.uniform(90, 170)))
        core, glow = sc.result(glow_sigma=5)
        lum = fs["lum"]
        return screen_emissive(img, core * 0.7, glow * 0.8, np.float32([0.7, 1.0, 0.92]) * lum,
                               np.float32([0.1, 0.85, 0.7]) * lum)

    def _crumble_fx(self, img, f, t):
        fh = f - f % 2
        H, W = img.shape[:2]
        n = float(nearness(np.float32(0.35)))
        s = self.cam.scale_at(n, t) * SC
        hp = self.hands_pose(f) if fh < self.f_smear else {"dx": 0.0, "dy": 0.0}
        off = np.float32([hp["dx"], hp["dy"]])
        # smoke: a painted haze ribbon curling up from the burning edge
        hz = self.haze
        fx = self.front_x(f)
        src = np.float32([fx + 40, 1830]) * SC + off
        q = self.cam.screen_point(src, n, t)
        scroll = int((fh - self.f0) * 6) % hz.shape[0]
        a = np.roll(hz, -scroll, axis=0)
        a = cv2.resize(a, (int(a.shape[1] * s * 1.25), int(a.shape[0] * s * 1.25)))
        yy = np.linspace(0, 1, a.shape[0], dtype=np.float32)[:, None]
        xx = np.linspace(0, 1, a.shape[1], dtype=np.float32)[None, :]
        a = a * np.clip(yy * 1.6, 0, 1) * np.clip((1 - yy) * 6, 0, 1) * np.clip(np.sin(np.pi * xx), 0, 1) ** 1.5 * 0.30
        a = a * (1 - smoothstep(self.f_b, self.f_b + 14, fh) * 0.7)
        smoke = np.dstack([np.ones_like(a)[..., None] * np.float32([0.42, 0.34, 0.40]), a])
        T.over(img, smoke, q[0] - a.shape[1] * 0.5, q[1] - a.shape[0])
        # falling chunks (painted dark pieces, on 2s, gravity and tumble)
        for c in self.cells:
            age = fh - c["f"]
            if age < 0 or age > 26 or c["f"] >= self.f_smear:      # later pieces drop with the controller
                continue
            tt = age / FPS
            p = c["p"] + np.float32([c["vx"] * tt, 60 * tt + 900 * tt * tt])
            q = self.cam.screen_point(p * SC + off, n, t)
            rr = c["r"] * s * 0.9
            rng = np.random.default_rng(c["seed"])
            ang = np.sort(rng.uniform(0, 2 * math.pi, 6)) + math.radians(c["spin"] * age / 2)
            rad = rr * rng.uniform(0.6, 1.0, 6)
            pts = np.stack([np.cos(ang) * rad, np.sin(ang) * rad], 1)
            sz = int(rr * 2 + 8)
            patch = np.zeros((sz, sz, 4), np.float32)
            cv2.fillPoly(patch, [np.round((pts + sz / 2) * 8).astype(np.int32)], (0.30, 0.24, 0.29, 1.0), cv2.LINE_AA,
                         shift=3)
            yy2 = np.linspace(1.2, 0.55, sz, dtype=np.float32)[:, None, None]       # lit top, shaded underside
            patch[..., :3] *= yy2
            patch[..., 3] = cv2.GaussianBlur(patch[..., 3], (0, 0), 0.6)
            rim = np.clip(patch[..., 3] - cv2.erode(patch[..., 3], np.ones((3, 3), np.uint8)), 0, 1)
            heat = max(0.0, 1 - age / 8) * 0.6
            patch[..., :3] += rim[..., None] * np.float32([1.0, 0.40, 0.10]) * heat
            T.over(img, np.clip(patch, 0, 1), q[0] - sz / 2, q[1] - sz / 2, opacity=1 - smoothstep(18, 26, age))
        img = self._dropped(img, f, t)
        # rising embers (emissive streaks) and ash flecks, from the front line
        sc = ShapeCanvas(W, H)
        flakes = []
        for e in range(34):
            rng = np.random.default_rng(e * 31 + 5)
            life = int(rng.integers(8, 14)) * 2
            period = life + int(rng.integers(0, 5)) * 2
            ph = fh - self.f0 + int(rng.integers(0, period // 2)) * 2
            age = ph % period
            born = fh - age
            rng = np.random.default_rng((e * 31 + 5) * 1000 + ph // period)       # new path each cycle
            if age > life or (e >= 24 and born < self.f_full):     # extra embers once the screens slam
                continue
            tt = age / FPS
            x0 = self.front_x(born) + rng.uniform(-10, 60)
            y0 = rng.uniform(1820, 2060)
            vy = -rng.uniform(90, 200)
            p = np.float32([x0 + math.sin(tt * rng.uniform(4, 8) + e) * 18 + rng.uniform(-30, 30) * tt, y0 + vy * tt])
            q = self.cam.screen_point(p * SC + off, n, t)
            if e % 3 == 2:
                flakes.append((q, rng, age))
                continue
            fl = 0.55 + 0.45 * math.sin(age * 1.3 + e)
            sc.fill(tapered_streak_poly(q, (math.sin(tt * 5 + e) * 0.4, -1), (10 + 8 * fl) * s * 1.4, 4.2 * s * 1.3),
                    value=int(255 * fl * (1 - age / (life + 1)) ** 0.5))
        core, glow = sc.result(glow_sigma=3)
        img = screen_emissive(img, core, glow * 0.9, (1.0, 0.78, 0.45), (1.0, 0.42, 0.10))
        for q, rng, age in flakes:
            w_ = rng.uniform(3, 6) * s * 1.4
            ang = rng.uniform(0, 3.14) + age * 0.4
            pts = np.float32([[math.cos(ang + k * 1.7) * w_, math.sin(ang + k * 1.7) * w_ * 0.6] for k in range(4)])
            sz = int(w_ * 2 + 6)
            patch = np.zeros((sz, sz, 4), np.float32)
            cv2.fillPoly(patch, [np.round((pts + sz / 2) * 8).astype(np.int32)], (0.55, 0.50, 0.52, 0.9), cv2.LINE_AA,
                         shift=3)
            T.over(img, patch, q[0] - sz / 2, q[1] - sz / 2)
        return img

    @cached_property
    def dropped_piece(self):
        """What is left of the controller when the hands fly open: the crumbling crust as one piece (work px)."""
        s = self.sprites["hands"]
        f = self.f_smear - 2
        lit, alpha = self._crumble(s["rgba_f"][..., :3].copy(), s["rgba_f"][..., 3], s, f)
        fallen = np.array([f >= c["f"] for c in self.cells] + [False])
        keep = (s["ctrl"] > 0.3) & ~fallen[s["cell"]]
        keep = cv2.morphologyEx(keep.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
        a = cv2.GaussianBlur(keep.astype(np.float32), (0, 0), 0.8) * alpha
        ys, xs = np.nonzero(a > 0.02)
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        rgba = np.dstack([np.clip(lit, 0, 1), a])[y0:y1, x0:x1].astype(np.float32)
        bx, by = s["bbox"][:2]
        return {"rgba": rgba, "c": np.float32([bx + (x0 + x1) / 2, by + (y0 + y1) / 2])}

    def _dropped(self, img, f, t):
        """The controller falls away on 2s: tossed up as the hands fly open, tumbling down out of frame,
        shedding embers."""
        fh = f - f % 2
        age = fh - self.f_smear
        if age < 0 or age > 24:
            return img
        tt = age / FPS
        P = self.dropped_piece
        n = float(nearness(np.float32(0.36)))
        p = P["c"] + np.float32([-60 * tt, -220 * tt + 2600 * tt * tt]) * SC
        q = self.cam.screen_point(p, n, t)
        k = self.cam.scale_at(n, t)
        patch, cx, cy = affine_rgba(P["rgba"], k, k * (1 - 0.25 * min(tt * 3, 1)), -35 * age / 2)
        if patch is not None:
            T.over(img, patch, q[0] - cx, q[1] - cy)
        H, W = img.shape[:2]
        sc = ShapeCanvas(W, H)
        rng = np.random.default_rng(fh + 77)
        for j in range(6):                                   # embers torn off the falling piece
            o = rng.uniform(-50, 50, 2) * k
            sc.fill(tapered_streak_poly((q[0] + o[0], q[1] + o[1] - 20 * k), (rng.uniform(-0.3, 0.3), -1),
                                        rng.uniform(14, 28) * k, 4.5 * k), value=int(rng.uniform(140, 255)))
        core, glow = sc.result(glow_sigma=3)
        return screen_emissive(img, core, glow * 0.9, (1.0, 0.78, 0.45), (1.0, 0.42, 0.10))

    def finish_args(self, f, info):
        return {"bloom_strength": 0.55 + 0.25 * min(info["flash"], 1.0)}

    # ------------------------------------------------------------ events and sound
    def events(self):
        ev = [(self.f0, "cut", {}), (self.f_play, "data_tag", {}), (self.f_tag_out, "data_tag_out", {}),
              (self.f_full - 2, "anticipation", {}), (self.f_smear, "inbetween", {}), (self.f_b, "pose_B", {})]
        for k, s in enumerate(self.screens):
            ev.append((s["f"], "slam", {"k": k, "x": s["cx"] / self.lay.W}))
        ev.append((self.f_full, "error_buzz", {}))
        for c in self.cells:
            if c["f"] < self.f_smear:
                ev.append((c["f"], "chunk", {"x": float(c["p"][0]) / 1520}))
        ev.append((self.f_smear, "controller_drop", {}))
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tail = dur + 0.8
        snd.bed(A.room_tone(tail, seed=71), t0, -31)
        snd.bed(A.crowd(tail, seed=72), t0, -38, -0.3)                      # the cafe murmur, far back
        dr = A.drone(tail, seed=73)
        nn = len(dr)
        tt = A.t_axis(tail) + t0
        swell = 0.55 + 0.45 * smoothstep_arr(tt, self.f_servers / FPS, self.f_full / FPS)
        snd.bed(A.lowpass(dr, 900) * swell * A.env_adsr(nn, 0.25, 0.1, 1.0, 0.4), t0, -22)
        # controller crackle: sparse impulses through a band, denser as the front speeds up
        snd.sfx(_crackle(tail, 74, t0, self), t0, -25, -0.1)
        # slams: nearest loudest, each further one quieter, smaller and further left
        for k, s in enumerate(self.screens):
            ts = s["f"] / FPS
            g = -11 - 3.2 * k
            pan = float(np.clip((s["cx"] / self.lay.W - 0.5) * 1.3, -0.8, 0.8))
            snd.sfx(_slam(80 + k, 1.0 - 0.07 * k), ts, g, pan)
        snd.sfx(_buzzer(1.0), snd.at_frame(self.f_full), -18, 0.3)
        # the reaction: a cloth snap on the smear (kept above the voice band), the dropped controller's ash
        snd.sfx(A.highpass(A.swish(0.24, seed=76), 4000), snd.at_frame(self.f_smear), -21, -0.3)
        snd.sfx(A.lowpass(A.thunk(seed=77), 300), snd.at_frame(self.f_b), -22, -0.2)
        # the teal flame: a soft breathy flutter whose level follows the drawn flicker, drawing by drawing
        fl = A.bandpass(A.noise(tail, 75, "pink"), 180, 1400)
        lv = np.zeros(len(fl))
        for f in range(self.f0 - self.f0 % 2, self.f1 + 24, 2):
            i0 = int((f / FPS - t0) * A.SR)
            if 0 <= i0 < len(lv):
                lv[i0:i0 + int(2 / FPS * A.SR)] = self.flame_state(f)["lum"] - 0.8
        lv = A.lowpass(lv, 30)
        snd.bed(fl * np.clip(lv, 0, None) * 2.5, t0, -30, 0.45)
        for c in self.cells:
            if c["f"] < self.f_smear:
                snd.sfx(A.soft_click(600 + (c["seed"] % 500), c["seed"] % 997), c["f"] / FPS, -30, -0.1)
        # the dropped controller: a gritty crumbling rush as it tumbles away
        cr = A.highpass(A.bandpass(A.noise(0.5, 78), 3000, 9000) * A.exp_decay(int(0.5 * A.SR), 0.15), 2500)
        snd.sfx(cr / (np.abs(cr).max() + 1e-9), snd.at_frame(self.f_smear), -24, -0.1)


def smoothstep_arr(x, a, b):
    t = np.clip((x - a) / max(b - a, 1e-6), 0, 1)
    return t * t * (3 - 2 * t)


def _slam(seed, pitch=1.0):
    """Heavy slam: a sub thump, a hard transient and a short metallic ring of the monitor frame."""
    dur = 0.7
    n = int(dur * A.SR)
    f = np.linspace(70 * pitch, 32 * pitch, n)
    body = A.osc(f, dur) * A.exp_decay(n, 0.14)
    crack = A.bandpass(A.noise(dur, seed), 600, 6000) * A.exp_decay(n, 0.012) * 0.9
    ring = (A.osc(420 * pitch, dur) * 0.5 + A.osc(663 * pitch, dur) * 0.3) * A.exp_decay(n, 0.06) * 0.25
    x = body + crack + ring
    return x / (np.abs(x).max() + 1e-9)


def _buzzer(level):
    """Error buzzer: two harsh square-ish blasts."""
    dur = 0.55
    t = A.t_axis(dur)
    sq = np.sign(A.osc(118.0, dur)) * 0.6 + np.sign(A.osc(176.0, dur)) * 0.4
    gate = ((t < 0.2) | ((t > 0.27) & (t < 0.5))).astype(float)
    x = A.lowpass(sq, 3200) * A.lowpass(gate, 200) * level
    return x / (np.abs(x).max() + 1e-9)


def _crackle(dur, seed, t0, shot):
    rng = np.random.default_rng(seed)
    n = int(dur * A.SR)
    tt = A.t_axis(dur) + t0
    dens = np.where(tt < shot.f_full / FPS, 9.0, 22.0)
    imp = (rng.random(n) < dens / A.SR) * rng.uniform(-1, 1, n)
    x = A.bandpass(imp, 1200, 7000) * 5 + A.lowpass(A.noise(dur, seed + 1, "pink"), 500) * 0.05
    return x / (np.abs(x).max() + 1e-9)


def make(ctx):
    return Shot(ctx)
