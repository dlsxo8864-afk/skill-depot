"""Geometry for shot 7 (Year 6, Spotify coin-slot earbud in the rain). Key-image px of the upscaled key
work/keys/y06_spotify_key.png (1520 x 2701)."""
import cv2
import numpy as np

from whatif.layers import PlaneSpec, SpriteSpec

# Everything nearer than the street, except the wet ground beside the jacket at the bottom right.
PERSON_REGION = [(0, 0), (1520, 0), (1520, 2015), (1100, 2030), (1060, 2701), (0, 2701)]

PLANES = [
    PlaneSpec("street", 0.0, 1.01, fill="full"),
    PlaneSpec("person", 0.43, 1.01, radius=80, region=PERSON_REGION),
]

# raised hand pushing the coin (thumb + index pinch at the earbud), traced along the painted outline
HAND_POLY = [(586, 984), (612, 976), (645, 976), (684, 983), (722, 994), (760, 1008), (790, 1026), (806, 1046),
             (809, 1080), (802, 1112), (794, 1140), (812, 1164), (842, 1194), (864, 1230), (870, 1270),
             (860, 1302), (842, 1332), (816, 1372), (792, 1412), (772, 1452), (758, 1492), (748, 1530),
             (640, 1536), (528, 1530), (513, 1470), (510, 1400), (514, 1330), (523, 1270), (538, 1220),
             (553, 1170), (566, 1120), (574, 1070), (577, 1030), (580, 1000)]

# open palm with the coin stack (depth separates it from the street between the fingers)
PALM_POLY = [(935, 1640), (1100, 1625), (1300, 1630), (1520, 1650), (1520, 1835), (1440, 1905), (1330, 1965),
             (1200, 2012), (1060, 2025), (965, 1995), (935, 1900)]

# loose back hair hanging behind the jaw (depth says "street", so it needs its own sprite to stay on the head)
HAIR_POLY = [(1005, 1080), (1090, 1085), (1170, 1180), (1192, 1350), (1180, 1610), (1060, 1615), (1030, 1450),
             (1003, 1250)]


def hair_mask(img, depth):
    """Dark navy strands, not the lit street behind them."""
    mx = img.max(2)
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    m = ((mx < 0.33) & (b > r + 0.02)).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    return m > 0


SPRITES = [
    SpriteSpec("hand", 1, HAND_POLY, dmin=0.0, pivot=(650, 1530), anchor=(600, 990, 650, 1525), fill_own_plane=True),
    SpriteSpec("palm", 1, PALM_POLY, dmin=0.45, pivot=(965, 1880), anchor=(1470, 1720, 975, 1875)),
    SpriteSpec("hair", 1, HAIR_POLY, dmin=0.0, dmax=0.40, pivot=(1020, 1120), anchor=(1125, 1590, 1020, 1130),
               mask_fn=hair_mask),
]

# coin slot on the earbud (brass plate) and the painted grey "rod" we replace with a real coin
SLOT_X = 557.0                  # the slot line the coin disappears into
SLOT_Y = (975.0, 1008.0)        # the painted slot
SLOT_LONG = (944.0, 1026.0)     # the slot we paint over it, long enough for the big coin
COIN_R = 38.0                   # coin radius (key px): a big arcade token so it reads on a phone
COIN_FLIP = 0.86
COIN_REST = (SLOT_X + COIN_R * COIN_FLIP + 4.0, 984.0)   # pinched, its left edge just touching the slot
ROD_POLY = [(559, 981), (603, 983), (603, 1003), (559, 1003)]
PLATE_C = (570.0, 985.0)        # brass plate centre / radii
PLATE_R = (31.0, 46.0)

# painted coins in mid-air / mid-splash to remove from the street plate (we animate our own)
FALLING_COIN_BOXES = [(1172, 2025, 1272, 2138), (1100, 2205, 1232, 2328), (1160, 2362, 1300, 2478)]
SPLASH_BOX = (1080, 2330, 1345, 2495)
COIN_TEX_BOX = (1180, 2030, 1266, 2132)       # coin A: a near face-on painted coin, used as face texture
COIN_LIE = (1035, 2505)                       # coin already lying on the ground (stays)

# where coins leave the palm, and where they land (the puddle)
TIP_FROM = (1268, 1935)
PUDDLE_Y = 2235
PUDDLE_X = (1150, 1320)

PHONE_BOX = (60, 1830, 390, 2160)
LAMP = (1150, 345)
LAMP_CONE = ((1150, 345), (-0.42, 1.0), 0.42, 1900)
HOOD_DRIPS = [(486, 596), (574, 626), (648, 600), (300, 700)]
NEON_PINK = (1262, 880)
STREET_SHIMMER = (900, 1760, 1520, 2701)      # wet street region for reflection shimmer (x0, y0, x1, y1)

HEAD_POLY = [(0, 430), (300, 440), (520, 380), (760, 420), (980, 560), (1100, 760), (1140, 1000), (1140, 1250),
             (1100, 1450), (900, 1560), (700, 1600), (520, 1560), (300, 1500), (0, 1450)]
NECK_PIVOT = (780, 1560)

# ---- pose B (assets/key/y06_spotify_poseB.png): finger pressing the coin home, eyes closed.
# BG_WARP maps key px -> pose-B px so the street lines up (ECC affine on the street, cc 0.93).
# HEAD_WARP maps key px -> background-aligned pose-B px so the head lines up (pose B bows the head about 6.5
# degrees; ECC affine on ear, eye, brow and nose, cc 0.87). The head warp is blended in with HEAD_W_RAMP so the
# wrist and collar stay where the street alignment put them.
BG_WARP = [[0.9606657, 0.0010289, 59.628284], [0.0013049, 0.9999828, -0.6813381]]
HEAD_WARP = [[1.0153699, -0.1113613, 54.598129], [0.1127355, 0.9651191, -34.427132]]
HEAD_W_RAMP = ([400, 760, 880, 1200], [1130, 1130, 1395, 1395], [1545, 1545, 1585, 1585])  # x, y full, y zero
# the hero region taken from pose B: ear, earbud, face and the raised hand (hood, jacket and street stay)
HERO_POLY = [(425, 800), (560, 768), (760, 756), (900, 768), (1010, 815), (1100, 900), (1125, 1100), (1110, 1300),
             (1040, 1420), (930, 1450), (850, 1500), (810, 1560), (640, 1566), (500, 1562), (476, 1400),
             (466, 1200), (436, 1100), (418, 950)]
# pose B's raised hand once warped onto the key (for the smear multiples)
HAND_B_POLY = [(495, 960), (540, 940), (590, 975), (690, 1085), (800, 1160), (885, 1225), (910, 1310), (885, 1410),
               (810, 1510), (790, 1540), (640, 1530), (612, 1440), (612, 1300), (615, 1160), (560, 1080), (495, 1010)]
