"""Shot 1, hook: protest at the data center; the building's light strips die on "disappeared"."""
import math
from functools import cached_property

import cv2
import numpy as np
from PIL import Image, ImageDraw

from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.poses import PoseSwap
from whatif.config import FPS, OUT_W, safe_box
from whatif.fx2d import Embers, ShapeCanvas, painted_haze, screen_emissive, spark_burst
from whatif.timing import Track, even_frame_of, on2s, smoothstep

from . import s01_hook_spec as SPEC

CREAM = (246, 236, 216)
EMBER_ORANGE = (255, 146, 72)


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def teal_weight(rgb, blur=5.0):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    tw = np.clip((np.minimum(g, b) - r - 0.02) / 0.25, 0, 1)
    tw = tw * np.clip((rgb.max(2) - 0.10) / 0.3, 0, 1)
    return cv2.GaussianBlur(tw.astype(np.float32), (0, 0), blur) if blur else tw


def dusk_grade(rgb, w, darken=0.86):
    """What the scene looks like once the teal light is gone: cool, dark blue-violet."""
    lum = rgb @ np.float32([0.30, 0.55, 0.15])
    target = lum[..., None] * np.float32([0.56, 0.55, 0.95]) * 0.80
    k = (w * 0.9)[..., None]
    return (rgb * (1 - k) + target * k) * darken


def pump(t, period, phase, amp_y, amp_ang):
    """Chant pump on held poses: rest, anticipation dip, snap up, settle, hold, drop back."""
    u = ((t + phase) % period) / period
    tr = Track([(0.0, (0.0, 0.0)), (0.26, (0.0, 0.0)), (0.36, (0.35, 0.35), "inout"),
                (0.44, (-1.0, -1.05), "out"), (0.52, (-0.85, -0.9), "inout"),
                (0.80, (-0.8, -0.85), "linear"), (1.0, (0.0, 0.0), "inout")])
    a, y = tr(u)
    return a * amp_ang, y * amp_y


CROWD_B = [[(0, 1540), (1520, 1540), (1520, 2701), (0, 2701)],     # near crowd (key px) for pose B
           [(380, 1540), (400, 1400), (475, 1230), (492, 1095), (635, 1095), (605, 1300), (585, 1540)]]   # + its raised left arm
# pose B repaints the mid-crowd placards blank: hand-letter them like the key's (key px, pose B positions)
FAR_PLACARDS_B = {
    "far2": {"bbox": (650, 1570, 815, 1735), "lines": ["NO!"]},
    "far3": {"bbox": (1120, 1612, 1270, 1765), "lines": ["NOT HERE"]},
}


class HookShot:
    name = SPEC.SHOT
    pose = None
    swaps = ()

    def __init__(self, f0, f1, t_disappear, t_sub=2.30):
        self.f0, self.f1 = f0, f1
        self.t_sub = t_sub                                  # subtitle pop (on "over")
        self.f_die = even_frame_of(t_disappear + 0.02)      # first strip dies on the word onset
        L.build(SPEC.SHOT, SPEC.KEY, SPEC.DEPTH, SPEC.PLANES, SPEC.SPRITES)
        self.lay = L.Layers(SPEC.SHOT)
        W, H = self.lay.W, self.lay.H
        dur = (f1 - f0) / FPS
        self.cam = ParallaxCamera(
            W, H, focus=(W * 0.52, H * 0.42), nearness=nearness,
            # punch-in over the first 12 frames (camera on 1s), then a slow drift in
            zoom=Track([(0, 1.0), (12 / FPS, 1.06, "out"), (dur, 1.115, "inout")]),
            push=Track([(0, 0.0), (12 / FPS, 0.05, "out"), (dur, 0.10, "inout")]),
            rise=Track([(0, 0.0), (12 / FPS, 14.0, "out"), (dur, 52.0, "inout")]))

    # ------------------------------------------------------------ prepared
    @cached_property
    def planes(self):
        lay = self.lay
        out = []
        for p in lay.planes:
            rgb = p["rgb"].astype(np.float32) / 255
            out.append({"rgb": rgb, "a": p["a"].astype(np.float32) / 255,
                        "n": nearness(p["d"].astype(np.float32) / 65535),
                        "tw": teal_weight(rgb)})
        # far placard scrawls go straight into the building plate
        for k, spec in SPEC.FAR_PLACARDS.items():
            self._paint_placard(out[1]["rgb"], None, spec, seed=sum(map(ord, k)), paint=(0.10, 0.05, 0.10), size_scale=1.0)
        for p in out[2:]:
            p["dead"] = dusk_grade(p["rgb"], p["tw"])
        return out

    @cached_property
    def sprites(self):
        """Sprites with slogans painted onto the cardboard faces."""
        res = []
        for s in self.lay.sprites:
            s2 = dict(s)
            rgba = s["rgba"].astype(np.float32) / 255
            if s["name"] in SPEC.PLACARDS:
                spec = SPEC.PLACARDS[s["name"]]
                paint = (0.55, 0.06, 0.08) if s["name"] == "plac_C" else (0.07, 0.04, 0.09)
                self._paint_placard(rgba[..., :3], s["bbox"], spec, seed=len(res) * 7 + 3, paint=paint, alpha=rgba[..., 3])
            s2["rgba_f"] = rgba
            s2["tw"] = teal_weight(rgba[..., :3])
            res.append(s2)
        return res

    def _paint_placard(self, rgb, bbox, spec, seed, paint, alpha=None, size_scale=1.0):
        """Find the cardboard face inside bbox and hand-letter the slogan onto it in perspective."""
        sc = L.WORK_SCALE
        x0, y0, x1, y1 = [int(v * sc) for v in spec["bbox"]]
        if bbox is not None:                       # rgb is a sprite crop: shift into crop coords
            ox, oy = bbox[0], bbox[1]
        else:
            ox, oy = 0, 0
        region = rgb[y0 - oy:y1 - oy, x0 - ox:x1 - ox]
        r, g, b = region[..., 0], region[..., 1], region[..., 2]
        if bbox is None:     # far placards are pale lavender cards against the haze
            lum = region.mean(2)
            card = (np.minimum(g, b) - r < 0.06) & (lum > 0.2) & ((region.max(2) - region.min(2)) < 0.2)
        else:
            card = (r > g * 1.02) & (r > b * 0.95) & (r > 0.28) & (g > 0.18)
        if alpha is not None:
            card &= alpha[y0 - oy:y1 - oy, x0 - ox:x1 - ox] > 0.5
        card = cv2.morphologyEx(card.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
        card = cv2.morphologyEx(card, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        n, lab, stats, _ = cv2.connectedComponentsWithStats(card)
        if n < 2:
            return
        k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        cnt, _ = cv2.findContours((lab == k).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cnt = max(cnt, key=cv2.contourArea)
        quad = None
        peri = cv2.arcLength(cnt, True)
        for eps in np.linspace(0.01, 0.08, 15):
            ap = cv2.approxPolyDP(cnt, eps * peri, True)
            if len(ap) == 4:
                quad = ap[:, 0, :].astype(np.float32)
                break
        if quad is None:
            quad = cv2.boxPoints(cv2.minAreaRect(cnt)).astype(np.float32)
        # order TL, TR, BR, BL
        c = quad.mean(0)
        ang = np.arctan2(quad[:, 1] - c[1], quad[:, 0] - c[0])
        quad = quad[np.argsort(ang)]                       # starts at TL going clockwise (y down)
        s = quad.sum(1)
        quad = np.roll(quad, -int(np.argmin(s)), axis=0)
        # inset for margins (the left-hand board's left edge is cut by the frame: bias text right)
        # usable face: fractions along the board (TL->TR and TL->BL); keeps paint off the edges and,
        # for boards cut by the frame edge, inside the part that stays in shot during the push-in
        u0, u1 = spec.get("u", (0.1, 0.9))
        v0, v1 = spec.get("v", (0.12, 0.88))
        P = lambda u, v: quad[0] + (quad[1] - quad[0]) * u + (quad[3] - quad[0]) * v + \
            (quad[2] - quad[1] - quad[3] + quad[0]) * u * v
        q = np.float32([P(u0, v0), P(u1, v0), P(u1, v1), P(u0, v1)])
        wq = int(np.linalg.norm(q[1] - q[0]))
        hq = int(np.linalg.norm(q[3] - q[0]))
        lines = spec["lines"]
        size = hq / (len(lines) * 1.25) * spec.get("size", 1.0) * size_scale
        a = T.lettering(lines, size, max(wq, 8), max(hq, 8), seed=seed)
        a = T.warp_to_quad(a, q, region.shape[:2])
        T.paint_on_surface(region, a, paint, opacity=0.9, seed=seed)

    @cached_property
    def strips(self):
        """Teal light-strip sections on the building plate, with death order and glow footprints."""
        p1 = self.planes[1]
        rgb = p1["rgb"]
        hsv = cv2.cvtColor((rgb * 255).astype(np.uint8), cv2.COLOR_RGB2HSV)
        hmask = (hsv[..., 0] >= 72) & (hsv[..., 0] <= 95) & (hsv[..., 1] > 90) & (hsv[..., 2] > 150)
        H, W = hmask.shape
        allowed = np.zeros_like(hmask)
        allowed[:int(SPEC.STRIP_MAX_Y * L.WORK_SCALE)] = True       # facade strips and vents only, not the haze
        for x0, y0, x1, y1 in SPEC.LAMPS:
            sc = L.WORK_SCALE
            allowed[int(y0 * sc):int(y1 * sc), int(x0 * sc):int(x1 * sc)] = True
        hmask &= allowed
        m = cv2.morphologyEx(hmask.astype(np.uint8), cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 5)))
        n, lab, stats, cents = cv2.connectedComponentsWithStats(m)
        secs = []
        for i in range(1, n):
            x, y, w, h, area = stats[i]
            if area < 40:
                continue
            chunks = max(1, int(round(w / 95)))
            for c in range(chunks):
                cx0 = x + w * c // chunks
                cx1 = x + w * (c + 1) // chunks
                sub = (lab[y:y + h, cx0:cx1] == i)
                if sub.sum() < 20:
                    continue
                secs.append({"bbox": (cx0, y, cx1, y + h), "mask": sub, "cx": (cx0 + cx1) / 2, "cy": y + h / 2})
        rng = np.random.default_rng(21)
        # death order: a wave rolling across the facade from left to right, upper floors slightly first
        for s in secs:
            s["key"] = s["cx"] / W * 0.75 + s["cy"] / H * 0.35 + rng.uniform(-0.06, 0.06)
        secs.sort(key=lambda s: s["key"])
        span_frames = 22
        pats = [[1, 0.15, 1, 0.1], [0.3, 1, 0.1, 0.8], [1, 0.05, 0.7, 0.1], [0.5, 0.05, 1, 0.2]]
        for i, s in enumerate(secs):
            s["pattern"] = list(pats[int(rng.integers(len(pats)))])
            # the first section is killed outright ON the word "disappeared" (with a hit); the rest
            # flicker from the next drawing and die in a wave rolling across the facade
            s["die"] = self.f_die + 2 + 2 * len(s["pattern"]) + 2 * int(round(i / max(len(secs) - 1, 1) * span_frames / 2))
            # glow footprint (soft area that goes dark with the section)
            pad = 26
            bx0, by0, bx1, by1 = s["bbox"]
            gx0, gy0, gx1, gy1 = max(bx0 - pad, 0), max(by0 - pad, 0), min(bx1 + pad, W), min(by1 + pad, H)
            g = np.zeros((gy1 - gy0, gx1 - gx0), np.float32)
            g[by0 - gy0:by1 - gy0, bx0 - gx0:bx1 - gx0] = s["mask"]
            core = cv2.dilate(g, np.ones((3, 3), np.uint8))
            g = np.maximum(core, cv2.GaussianBlur(g, (0, 0), 8) * 1.6)
            s["glow"] = np.clip(g, 0, 1)
            s["gbox"] = (gx0, gy0, gx1, gy1)
        if secs:
            first = max(secs[:6], key=lambda s: s["mask"].sum())         # a big, visible one, early in the wave
            first["pattern"], first["die"] = [], self.f_die
        self.f_dark = max(s["die"] for s in secs) if secs else self.f_die
        # the plate with every strip dead: strips refilled from the facade around them, then dusk-graded
        allm = np.zeros((H, W), np.float32)
        for s in secs:
            x0, y0, x1, y1 = s["bbox"]
            allm[y0:y1, x0:x1] = np.maximum(allm[y0:y1, x0:x1], s["mask"])
        allm = cv2.dilate(allm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
        allm = cv2.GaussianBlur(allm, (0, 0), 1.0)
        # facade colour comes from OUTSIDE each light fixture (a vent's dark slats would otherwise
        # pull the fill to black), so dead fixtures sit at the wall's value, a step darker
        block = cv2.morphologyEx((allm > 0.05).astype(np.uint8), cv2.MORPH_CLOSE,
                                 cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)))
        block = cv2.dilate(block, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))
        filled = cv2.GaussianBlur(L.push_pull_fill(rgb, block == 0), (0, 0), 3)
        detail = (rgb.mean(2, keepdims=True) - cv2.GaussianBlur(rgb, (0, 0), 2).mean(2, keepdims=True))
        # a dead tube keeps its painted structure, just unlit: the slats read as small cool value steps
        lum = rgb.mean(2, keepdims=True)
        slat = np.clip((lum - 0.25) / 0.5, 0, 1)
        dead_strip = filled * (0.68 + 0.22 * slat) * np.float32([0.96, 0.98, 1.06]) + detail * 0.25
        off = rgb * (1 - allm[..., None]) + dead_strip * allm[..., None]
        halo = np.clip(cv2.GaussianBlur(allm, (0, 0), 24) * 1.3, 0, 1) * cv2.GaussianBlur(p1["tw"], (0, 0), 6) * 0.7
        off = off * (1 - halo[..., None]) + dusk_grade(off, p1["tw"], darken=1.0) * halo[..., None]
        p1["off"] = off
        p1["dusk_lit"] = dusk_grade(rgb, p1["tw"])
        p1["dusk_off"] = dusk_grade(off, np.maximum(p1["tw"], allm))
        return secs

    def state(self, f, s):
        """Section brightness (1 lit .. 0 dead) at frame f, on 2s."""
        fh = f - f % 2
        k = (fh - s["die"]) // 2 + len(s["pattern"])
        if k < 0:
            return 1.0
        if k >= len(s["pattern"]):
            return 0.0
        return s["pattern"][int(k)] if fh < s["die"] else 0.0

    @cached_property
    def haze_tex(self):
        H, W = self.lay.H, self.lay.W
        return painted_haze(int(H * 0.30), int(W * 1.6), seed=5, blobs=7, softness=36)

    @cached_property
    def embers(self):
        return Embers(30, self.lay.W, self.lay.H, seed=4, y_range=(0.30, 0.80), n_range=(0.08, 0.55))

    @cached_property
    def title(self):
        x0, y0, x1, y1 = safe_box()
        items = []
        y = y0 + 6
        for text, size, color, gap in [("WHAT IF ALL DATA CENTERS", 72, CREAM, 6),
                                       ("DISAPPEARED", 150, EMBER_ORANGE, 2),
                                       ("OVER THE NEXT 10 YEARS?", 72, CREAM, 20)]:
            fnt = T.font("display", size)
            tw, th, ox, oy = T.text_size(fnt, text)
            if tw > (x1 - x0):
                fnt = T.font("display", int(size * (x1 - x0) / tw))
                tw, th, ox, oy = T.text_size(fnt, text)
            pim = Image.new("L", (tw + 4, th + 4), 0)
            ImageDraw.Draw(pim).text((2 - ox, 2 - oy), text, font=fnt, fill=255)
            a = np.asarray(pim, np.float32) / 255
            rgba, pad = T.styled_text_rgba(a, color, seed=len(items) + 1, shadow_off=(4, 6), soft_shadow=12,
                                           grad=0.12 if color == CREAM else 0.18)
            items.append({"rgba": rgba, "x": x0 - pad, "y": y - pad, "h": th, "kind": text})
            y += th + gap + (8 if size > 100 else 10)
        # subtitle on a painted swatch, then the source line
        sub_f = T.at_least_cap(T.sans(38, 760))
        lines = T.wrap(sub_f, "This week, 40 of 41 local votes went against data centers", (x1 - x0) - 76)
        blocks = []
        yy = y + 10
        for ln in lines:
            blocks.append((ln, sub_f, CREAM, yy))
            yy += int(sub_f.size * 1.3)
        src_f = T.at_least_cap(T.sans(31, 560))          # source line: min cap height 30 px
        blocks.append(("CNBC, Nov 4, 2026", src_f, (214, 200, 222), yy + 6))
        sub_items = []
        for ln, fnt, col, yl in blocks:
            tw, th, ox, oy = T.text_size(fnt, ln)
            pim = Image.new("L", (tw + 4, th + 8), 0)
            ImageDraw.Draw(pim).text((2 - ox, 2 - oy), ln, font=fnt, fill=255)
            a = np.asarray(pim, np.float32) / 255
            rgba, pad = T.styled_text_rgba(a, col, seed=11 + len(sub_items), shadow_off=(2, 3), soft_shadow=6,
                                           shadow_strength=0.6, grad=0.06)
            sub_items.append({"rgba": rgba, "x": x0 + 22 - pad, "y": yl - pad, "h": th})
        # swatch: a dry-brushed dark band behind the subtitle block
        sw_h = int(yy + 44 - (y + 10)) + 26
        sw_w = min(int(max(it["rgba"].shape[1] for it in sub_items) + 24), x1 - x0 + 6)
        sw = np.zeros((sw_h, sw_w), np.float32)
        cv2.rectangle(sw, (10, 10), (sw_w - 10, sw_h - 10), 1.0, -1)
        n = L.brush_noise(sw.shape, 77, scale=3, angle=0.02, stretch=12)
        sw = cv2.GaussianBlur(sw, (0, 0), 4)
        sw = np.clip((sw - 0.5 + n * 0.18) * 4 + 0.5, 0, 1) * 0.72
        sw_rgba = np.dstack([np.ones_like(sw)[..., None] * np.float32([0.10, 0.05, 0.16]), sw])
        swatch = {"rgba": sw_rgba, "x": x0, "y": y - 2}
        return items, sub_items, swatch

    # --------------------------------------------------------------- frame
    def frame(self, f):
        """Render global frame f (f0 <= f < f1). Returns float32 RGB (pre-finish)."""
        lf = f - self.f0
        t = lf / FPS                    # camera time, on 1s
        th = on2s(lf)                   # character/effect time, on 2s
        planes = self.planes
        secs = self.strips
        sprites = self.sprites
        # global teal-death progress (haze, rims), on 2s
        fh = f - f % 2
        p = smoothstep(self.f_die + 2, self.f_dark + 10, fh)
        render_planes = []
        for i, pl in enumerate(planes):
            rgb = pl["rgb"]
            a = pl["a"].copy()
            if i == 1:
                M = np.zeros(rgb.shape[:2], np.float32)
                for s in secs:
                    st = self.state(f, s)
                    if st < 1:
                        gx0, gy0, gx1, gy1 = s["gbox"]
                        M[gy0:gy1, gx0:gx1] = np.maximum(M[gy0:gy1, gx0:gx1], s["glow"] * (1 - st))
                Mk = M[..., None]
                base = rgb * (1 - Mk) + pl["off"] * Mk
                dusk = pl["dusk_lit"] * (1 - Mk) + pl["dusk_off"] * Mk
                rgb = base * (1 - p) + dusk * p
                rgb = self._haze(rgb, th, p)
                rgb = self._sparks(rgb, f)
            elif i > 1:
                w = (p * pl["tw"])[..., None]
                rgb = rgb * (1 - w) + pl["dead"] * w
            else:
                rgb = rgb * (1 - 0.10 * p)
            for s in sprites:
                if s["plane"] != i:
                    continue
                pose = self._pose(s["name"], th)
                tmp = dict(s)
                rgba = s["rgba_f"].copy()
                w = (p * s["tw"])[..., None]
                rgba[..., :3] = rgba[..., :3] * (1 - w) + dusk_grade(rgba[..., :3], s["tw"]) * w
                tmp["rgba"] = rgba
                patch, x0, y0 = deform_sprite(tmp, **pose)
                composite_into(rgb, a, patch, x0, y0)
            n = pl["n"]
            if self.pose is not None and i >= 2:       # pose B of the crowd (hook_protest_poseB.png)
                st = PoseSwap.state(f, self.swaps, anticipation=0)   # a crowd reacts with no wind-up
                if st != "A":
                    src = self.pose.image(st)
                    tw = (p * teal_weight(src))[..., None]
                    src = src * (1 - tw) + dusk_grade(src, teal_weight(src)) * tw
                    n = self.pose.nearness(n, pl["a"], st)
                    rgb, a = self.pose.apply(rgb, a, st, src=src, hero_alpha=self._hero_alpha(st))
            render_planes.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(render_planes, t)
        img = self.embers.draw(self.cam, th, img, intensity=1.0 - 0.25 * p)
        img = self._titles(img, f)
        return img, {"teal_dead": p}

    def _hero_alpha(self, st):
        """Coverage of a pose drawing: the near-crowd band is solid; in the raised-arm polygon only the arm
        (not the teal haze painted around it) is opaque, so the live haze keeps moving behind it."""
        cache = self.__dict__.setdefault("_ha_cache", {})
        if st not in cache:
            img = self.pose.image(st)
            H, W = img.shape[:2]
            sc = L.WORK_SCALE
            yy = np.arange(H, dtype=np.float32)[:, None] / sc
            solid = np.clip((yy - 1640) / 160.0, 0, 1) * np.ones((1, W), np.float32)   # solid crowd below
            body = np.clip((0.45 - teal_weight(img, blur=1.5)) * 4, 0, 1)            # people, not haze
            # around the mid-crowd placards pose B's drawing is solid, so pose A's lettered cards on the
            # plate behind (slightly elsewhere) never show through as a doubled edge
            for spec in list(SPEC.FAR_PLACARDS.values()) + list(FAR_PLACARDS_B.values()):
                x0, y0, x1, y1 = spec["bbox"]
                if y1 > 1540:
                    cv2.rectangle(body, (int((x0 - 30) * sc), int((y0 - 30) * sc)), (int((x1 + 30) * sc), int((y1 + 30) * sc)), 1.0, -1)
            body = cv2.GaussianBlur(body, (0, 0), 2.0)
            cache[st] = np.maximum(solid, body)
        return cache[st]

    def _pose(self, name, th):
        # pass 4: real pose changes from the first drawing (the critic saw nothing move for 1.6 s):
        # placards and fists pump hard on the chant, phased so one is always mid-move
        if name == "plac_L":
            a, y = pump(th, 1.00, 0.62, 30, 4.5)
            return {"angle_deg": a, "dy": y}
        if name == "plac_C":
            a, y = pump(th, 1.00, 0.95, 26, -4.0)
            return {"angle_deg": a, "dy": y}
        if name == "plac_R":
            a, y = pump(th, 1.00, 0.30, 24, 3.4)
            return {"angle_deg": a, "dy": y}
        if name == "fist_C":
            a, y = pump(th, 0.50, 0.70, 36, -6.0)
            return {"angle_deg": a, "dy": y}
        if name == "fist_R":
            a, y = pump(th, 0.50, 0.92, 24, 5.0)
            return {"angle_deg": a, "dy": y}
        if name == "head_beanie":           # turns to the building as the lights die, then back
            k = Track([(0, 0.0), (0.25, 0.0), (0.42, 1.0, "out"), (1.30, 1.0), (1.46, -0.7, "out"), (2.6, -0.7),
                       (2.76, 0.4, "out")])(th)
            return {"angle_deg": -2.6 * k, "dx": 7.0 * k}
        if name == "head_curly":
            k = Track([(0, 0.0), (0.5, 0.0), (0.66, 1.0, "out"), (1.6, 1.0), (1.76, -0.5, "out"), (3.0, -0.5)])(th)
            return {"angle_deg": 2.8 * k, "dx": -5.0 * k, "dy": 2.5 * k}
        return {}

    def _haze(self, rgb, th, p):
        """Painted teal haze bands drifting across the street, fading out as the power dies."""
        tex = self.haze_tex
        H, W = rgb.shape[:2]
        h = tex.shape[0]
        y0 = int(H * 0.50)
        off = int((th * 22) % (tex.shape[1] - W))
        a = tex[:, off:off + W] * 0.30 * (1 - 0.8 * p)
        lit = np.float32([0.30, 0.86, 0.76])
        dim = np.float32([0.20, 0.22, 0.38])
        col = lit * (1 - p) + dim * p
        seg = rgb[y0:y0 + h]
        rgb[y0:y0 + h] = seg * (1 - a[..., None]) + (1 - (1 - seg) * (1 - col)) * a[..., None]
        return rgb

    def _sparks(self, rgb, f):
        fh = f - f % 2
        sc = None
        for s in self.strips:
            d = (fh - s["die"]) // 2
            if 0 <= d <= 2:
                if sc is None:
                    sc = ShapeCanvas(rgb.shape[1], rgb.shape[0])
                spark_burst(sc, (s["cx"], s["cy"]), int(d), seed=int(s["cx"] * 7 + s["cy"]), scale=0.9)
        if sc is not None:
            c, g = sc.result(glow_sigma=5)
            screen_emissive(rgb, c, g, (0.92, 1.0, 0.97), (0.25, 0.95, 0.85))
        return rgb

    def _titles(self, img, f):
        items, sub_items, swatch = self.title
        lf = f - self.f0
        fh = lf - lf % 2
        starts = [4, 8, 12]
        for it, st in zip(items, starts):
            u = (fh - st) / FPS
            s = T.pop_scale(u)
            if s is None:
                continue
            op = 1.0
            if it["kind"] == "DISAPPEARED":
                d = (f - f % 2) - self.f_die
                flick = {0: 0.25, 2: 1.0, 4: 0.15, 6: 0.85, 8: 0.35}
                op = flick.get(d, 1.0)
            r = it["rgba"]
            pr, ox, oy = T.transform_rgba(r, s, 0, origin=(30, r.shape[0] / 2))
            O.seat(img, pr, it["x"] + ox, it["y"] + oy, opacity=op)
        st_sub = even_frame_of(self.t_sub)
        u = (fh - st_sub) / FPS
        s = T.pop_scale(u)
        if s is not None:
            r = swatch["rgba"]
            pr, ox, oy = T.transform_rgba(r, 1.0 if s >= 1 else min(1.0, 0.3 + s * 0.7), 0, origin=(0, r.shape[0] / 2))
            O.seat(img, pr, swatch["x"] + ox, swatch["y"] + oy)
            for k, it in enumerate(sub_items):
                u2 = (fh - st_sub - 2 * k) / FPS     # first line lands with the swatch, no empty bar
                s2 = T.pop_scale(u2)
                if s2 is None:
                    continue
                r = it["rgba"]
                pr, ox, oy = T.transform_rgba(r, s2, 0, origin=(20, r.shape[0] / 2))
                O.seat(img, pr, it["x"] + ox, it["y"] + oy)
        return img

    def events(self):
        """Picture events for the sound mix and sync table: (frame, kind, info)."""
        ev = []
        for s in self.strips:
            ev.append((s["die"], "strip_die", {"x": s["cx"] / self.lay.W}))
            for k in range(len(s["pattern"])):
                fr = s["die"] - 2 * (len(s["pattern"]) - k)
                prev = 1.0 if k == 0 else s["pattern"][k - 1]
                if s["pattern"][k] < prev - 0.3:
                    ev.append((fr, "flicker", {"x": s["cx"] / self.lay.W}))
        return ev


# ------------------------------------------------------------------ episode interface
def make(ctx):
    """Hook timed from its narration line: strips die on "disappeared", subtitle pops on "over"."""
    # Word starts measured from the take's energy (sync audit, pass 3): the aligner put "disappeared"
    # at 1.10 s and "over" at 1.70 s, but "disappeared" starts after the d-closure at 1.34 s and
    # "over" after the pause at 2.28 s (seconds into 00_hook.wav).
    shot = HookShot(ctx.f0, ctx.f1, ctx.vo_at + 1.34, ctx.vo_at + 2.28 + 0.04)
    shot.ctx = ctx
    # pose B of the near crowd, if the director has painted it: they react as the lights die
    shot.pose = PoseSwap.for_shot(ctx, SPEC.SHOT, region=CROWD_B)
    if shot.pose is not None:
        for img in (shot.pose.b, shot.pose.ab):
            for k, spec in FAR_PLACARDS_B.items():
                shot._paint_placard(img, None, spec, seed=sum(map(ord, k)), paint=(0.10, 0.05, 0.10))
        for k, spec in SPEC.FAR_PLACARDS.items():       # the anticipation drawing is pose A's placards
            shot._paint_placard(shot.pose.ant_ab, None, spec, seed=sum(map(ord, k)), paint=(0.10, 0.05, 0.10))
    # one clear reaction: heads snap up to the dying facade just after the first strip dies, and hold
    shot.swaps = [(shot.f_die + 6, "B")]
    return shot


def _hook_sound(self, snd):
    """Drone, the building's hum powering down with a pitch drop, crowd bed, zaps on each strip."""
    from whatif import audio as A
    t_start, t_end = self.f0 / FPS, self.f1 / FPS
    d1 = t_end - t_start + 0.6
    snd.bed(A.drone(d1) * A.env_adsr(int(round(d1 * A.SR)), 0.5, 0.1, 1.0, 0.55), t_start, -21)
    t_die, t_dark = self.f_die / FPS, (self.f_dark + 10) / FPS
    tt = A.t_axis(t_end - t_start + 0.2) + t_start
    f0 = np.where(tt < t_die, 58.0, 58.0 - 36.0 * np.clip((tt - t_die) / (t_dark - t_die), 0, 1) ** 0.7)
    amp = np.where(tt < t_die, 1.0, np.clip(1 - (tt - t_die) / (t_dark - t_die + 0.15), 0, 1) ** 1.5)
    snd.bed(A.lowpass(A.hum(len(tt) / A.SR, f0) * amp, 1200), t_start, -19)
    dc = t_end - t_start + 0.3
    snd.bed(A.crowd(dc) * A.env_adsr(int(round(dc * A.SR)), 0.3, 0.1, 1.0, 0.3), t_start, -29, pan=-0.1)
    snd.bed(A.crowd(dc, seed=13), t_start, -31, pan=0.3)
    by_frame = {}
    for f, kind, info in self.events():
        by_frame.setdefault((f, kind), []).append(info.get("x", 0.5))
    for (f, kind), xs in sorted(by_frame.items()):
        pan = float(np.clip((np.mean(xs) - 0.5) * 1.4, -0.8, 0.8))
        if kind == "flicker":
            snd.sfx(A.zap(f, 0.05, 0.6), f / FPS, -24 + min(len(xs), 4), pan)
        elif f == self.f_die:            # the first strip is killed ON "disappeared": a hit with the zap
            snd.sfx(A.hit(seed=41), f / FPS, -12, pan)
            snd.sfx(A.zap(f + 1000, 0.14, 1.6), f / FPS, -16, pan)
        else:
            snd.sfx(A.zap(f + 1000, 0.11, 1.2), f / FPS, -20 + min(len(xs), 6) * 0.8, pan)


HookShot.sound = _hook_sound
