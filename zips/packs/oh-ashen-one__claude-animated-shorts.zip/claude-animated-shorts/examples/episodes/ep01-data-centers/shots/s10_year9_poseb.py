"""Pose B for s10_year9 (the flinch): align the second painted pose to the key and cut its hero region.

Pose B (assets/key/y09_market_poseB.png) has the same framing as the key but differs slightly everywhere;
only the person (and the ground she uncovers) is taken from it, through a soft mask, after aligning it to
the key on the background (affine ECC). Also used as the local stand-in for a shared pose-swap helper."""
import json
from pathlib import Path

import cv2
import numpy as np

from whatif import layers as L
from whatif.config import ASSETS
from whatif.keyprep import prepare_key


def align_affine(a_rgb, b_rgb, mask, scale=0.25):
    """Affine warp (2x3, full-res px) taking B onto A, fitted on the masked background (ECC)."""
    ga = cv2.cvtColor((a_rgb * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
    gb = cv2.cvtColor((b_rgb * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
    sa = cv2.resize(ga, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA).astype(np.float32)
    sb = cv2.resize(gb, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA).astype(np.float32)
    sm = (cv2.resize(mask.astype(np.uint8), (sa.shape[1], sa.shape[0]), interpolation=cv2.INTER_NEAREST) > 0).astype(np.uint8)
    sa = cv2.GaussianBlur(sa, (0, 0), 1.5)
    sb = cv2.GaussianBlur(sb, (0, 0), 1.5)
    M = np.eye(2, 3, dtype=np.float32)
    crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6)
    try:
        _, M = cv2.findTransformECC(sa, sb, M, cv2.MOTION_AFFINE, crit, sm, 5)
    except cv2.error:
        M = np.eye(2, 3, dtype=np.float32)
    M = M.copy()
    M[:, 2] /= scale
    return M                              # maps A coords -> B coords (use with WARP_INVERSE_MAP)


def build_pose_b(key_path, depth_path, out_dir, src_name, envelope, coin_holes=(), dmin=0.42, hero_fn=None,
                 a_region=None, exclude=(), name="poseB", a_mask=None, grow_a=31, feather_a=7.0):
    """Write out_dir/poseB.npz: aligned B (key px) RGB, its hero alpha (feathered union of A and B hero),
    and the B-hero-only alpha (for smear echoes). Returns the npz path."""
    out = Path(out_dir) / f"{name}.npz"
    if out.exists():
        return out
    up_b, dep_b = prepare_key(ASSETS / "key" / src_name)
    a = cv2.cvtColor(cv2.imread(str(key_path)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    b = cv2.cvtColor(cv2.imread(str(up_b)), cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    H, W = a.shape[:2]
    if b.shape[:2] != (H, W):
        b = cv2.resize(b, (W, H), interpolation=cv2.INTER_LANCZOS4)
    da = cv2.resize(cv2.imread(str(depth_path), -1).astype(np.float32) / 65535, (W, H))
    db = cv2.resize(cv2.imread(str(dep_b), -1).astype(np.float32) / 65535, (W, H))
    env = L.poly_mask((H, W), envelope) > 0.5
    hf = hero_fn or (lambda rgb, d: d > dmin)
    hero_a = env & (a_mask if a_mask is not None else hf(a, da))
    hero_b0 = env & hf(b, db)
    bg = ~cv2.dilate((hero_a | hero_b0).astype(np.uint8), np.ones((41, 41), np.uint8)).astype(bool)
    M = align_affine(a, b, bg)
    flags = cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP
    b = cv2.warpAffine(b, M, (W, H), flags=flags, borderMode=cv2.BORDER_REFLECT)
    db = cv2.warpAffine(db, M, (W, H), flags=flags, borderMode=cv2.BORDER_REFLECT)
    hero_b = env & hf(b, db)
    hero_b = cv2.morphologyEx(hero_b.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8)).astype(bool)
    # coins hanging in B's air are removed (the shot animates its own)
    holes = np.zeros((H, W), np.uint8)
    for cx, cy, r in coin_holes:
        cv2.circle(holes, (int(cx), int(cy)), int(r), 1, -1)
    if holes.any():
        b = L.textured_fill(b, (holes == 0).astype(np.float32), seed=301)
        hero_b &= holes == 0
    # B's hero, plus (dilated) the place A's hero leaves empty, where B's painted background shows
    ha = hero_a & (L.poly_mask((H, W), a_region) > 0.5) if a_region else hero_a
    ua = cv2.dilate(ha.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (grow_a, grow_a))).astype(np.float32)
    for poly in exclude:
        ua *= 1 - (L.poly_mask((H, W), poly) > 0.5)
    ua = cv2.GaussianBlur(ua, (0, 0), feather_a)
    ub = cv2.GaussianBlur(cv2.dilate(hero_b.astype(np.uint8), np.ones((5, 5), np.uint8)).astype(np.float32), (0, 0), 2.0)
    if a_region is None and not exclude and grow_a == 31:
        ub = cv2.GaussianBlur(cv2.dilate(hero_b.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31))).astype(np.float32), (0, 0), 7)
    alpha = np.maximum(ua, ub) * env
    hero_soft = cv2.GaussianBlur(hero_b.astype(np.float32), (0, 0), 1.2)
    np.savez_compressed(out, rgb=(b * 255 + 0.5).astype(np.uint8), alpha=(alpha * 255 + 0.5).astype(np.uint8),
                        hero=(hero_soft * 255 + 0.5).astype(np.uint8), M=M,
                        dep=(np.clip(db, 0, 1) * 65535 + 0.5).astype(np.uint16))
    (Path(out_dir) / f"{name}.json").write_text(json.dumps({"M": M.tolist()}))
    return out


def mesh_warp(rgba, x0, y0, src_pts, dst_pts, anchors=(), step=8):
    """In-between drawing: warp a crop (float, at plane offset x0, y0) so the features at src_pts land on
    dst_pts while the anchors stay put (thin-plate spline, evaluated on a coarse grid). Plane px."""
    from scipy.interpolate import RBFInterpolator
    h, w = rgba.shape[:2]
    ctrl = np.float64(list(dst_pts) + list(anchors))
    disp = np.float64([(sx - dx, sy - dy) for (sx, sy), (dx, dy) in zip(src_pts, dst_pts)] + [(0, 0)] * len(anchors))
    rbf = RBFInterpolator(ctrl, disp, kernel="thin_plate_spline", smoothing=1.0)
    gy, gx = np.mgrid[0:h + step:step, 0:w + step:step]
    pts = np.column_stack([gx.ravel() + x0, gy.ravel() + y0]).astype(np.float64)
    d = rbf(pts).reshape(gy.shape + (2,)).astype(np.float32)
    D = cv2.resize(d, (gx.shape[1] * step, gy.shape[0] * step), interpolation=cv2.INTER_LINEAR)[:h, :w]
    my, mx = np.mgrid[0:h, 0:w].astype(np.float32)
    return cv2.remap(rgba, mx + D[..., 0], my + D[..., 1], cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
