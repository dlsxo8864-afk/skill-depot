"""Shot 12, the catch: "But data centers were here long before AI, which uses under a third of
their power."

A slow steady push down the server aisle. The magenta racks on the left (AI) pulse hard, like a
heartbeat; the gold racks on the right are warm-lit the whole time; the technician at the far end
turns around; on "third" the magenta drops back (never recoloured: the AI racks stay magenta, just
dimmer) and the gold side brightens in a wave that runs down the aisle away from us, so from "third"
on gold light covers at least 1.5x the pixels magenta does. The wet floor's reflections follow each
side's light and shimmer on 2s throughout. Labels: "AI: under a third" on the magenta (left) side,
"Everything else" on the gold (right) side, source "IEA, 2026" under it.
"""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into
from whatif.config import FPS, safe_box
from whatif.screens import light_weight, unlit
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]
SC = L.WORK_SCALE

# ------------------------------------------------------------------ spec (key px, 1520 x 2701)
PLANES = [
    L.PlaneSpec("far", 0.00, 0.075, fill="full"),
    L.PlaneSpec("mid", 0.075, 0.22, fill="full"),
    L.PlaneSpec("racks", 0.22, 0.50, radius=70),
    L.PlaneSpec("near", 0.50, 1.01, radius=80),
]
SPRITES = []
VANISH = (767, 1560)                                     # aisle vanishing point
FLOOR = [(0, 2083), (533, 1663), (1034, 1615), (1520, 2003), (1520, 2701), (0, 2701)]
GOLD_RACKS = [(950, 560), (1520, 480), (1520, 2060), (1060, 1660), (985, 1560)]
GOLD_FLOOR = [(800, 1640), (1520, 1980), (1520, 2701), (900, 2701)]   # the gold side's wet floor
MAG_FLOOR = [(0, 2083), (720, 1640), (800, 2701), (0, 2701)]
TECH_BOX = (722, 1478, 822, 1668)                       # the technician, feet at the bottom edge
TECH_FLOOR_Y = 1663
MAGENTA = np.float32([0.98, 0.36, 0.80])
GOLD = np.float32([1.00, 0.66, 0.30])


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


def _sync(ctx):
    f_third = ctx.f("third")
    beats = list(range(ctx.f0 + 4, f_third - 4, 16))
    return {"third": f_third, "under": ctx.f("under"), "turn": ctx.f("AI,"), "beats": beats,
            "else": f_third + 6, "source": f_third + 10}


class Shot(BaseShot):
    flash_color = (1.0, 0.68, 0.32)          # the gold the shot ends on

    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        self.S = _sync(ctx)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        vp = (VANISH[0] * SC, VANISH[1] * SC)
        self.cam = ParallaxCamera(
            W, H, nearness=nearness, focus=(vp[0], vp[1] - 40 * SC),
            zoom=Track([(0, 1.0), (0.5, 1.006, "in"), (d, 1.115, "linear")]),
            push=Track([(0, 0.0), (0.5, 0.006, "in"), (d, 0.10, "linear")]),
            rise=Track([(0, 0.0), (d, -10.0, "linear")]))

    # ------------------------------------------------------------ prepared plates
    @cached_property
    def planes(self):
        Hh, Ww = self.lay.H, self.lay.W
        gold_region = cv2.GaussianBlur(L.poly_mask((Hh, Ww), [(x * SC, y * SC) for x, y in GOLD_RACKS]), (0, 0), 20)
        gold_floor = cv2.GaussianBlur(L.poly_mask((Hh, Ww), [(x * SC, y * SC) for x, y in GOLD_FLOOR]), (0, 0), 30)
        mag_floor = cv2.GaussianBlur(L.poly_mask((Hh, Ww), [(x * SC, y * SC) for x, y in MAG_FLOOR]), (0, 0), 30)
        out = []
        for i, p in enumerate(self.lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            if i == 0:
                rgb = self._prep_tech(rgb)
            wm = light_weight(rgb, "magenta", blur=2)
            ww = light_weight(rgb, "warm", blur=2)
            lum = rgb @ np.float32([0.3, 0.55, 0.15])
            # the gold side's panels take the warm spill too, not only the amber lamps
            ww = np.maximum(ww, gold_region * np.clip((lum - 0.10) / 0.4, 0, 1) * 0.8) * (1 - wm)
            base_un = unlit(rgb)
            d = p["d"].astype(np.float32) / 65535
            warm_r = gold_region * np.clip((lum - 0.06) / 0.3, 0, 1) * (1 - wm)
            # the wet floor on the gold side reflects gold; on the AI side the magenta reflection follows
            # the AI racks' pulse (it is part of lit_m) and is muted where it spills past the centre line
            warm_r = np.maximum(warm_r, gold_floor * np.clip((lum - 0.04) / 0.3, 0, 1) * 0.85 * (1 - wm))
            wm = wm * (1 - 0.6 * gold_floor)
            hsv = cv2.cvtColor(np.clip(rgb, 0, 1), cv2.COLOR_RGB2HSV)
            pink = np.clip((hsv[..., 1] - 0.15) / 0.2, 0, 1) * \
                ((hsv[..., 0] > 285) & (hsv[..., 0] < 350)).astype(np.float32)
            fm = cv2.GaussianBlur(mag_floor * pink, (0, 0), 2) * (1 - wm)        # the AI racks' floor reflection
            out.append({"rgb": rgb, "a": p["a"].astype(np.float32) / 255, "n": nearness(d), "d": d,
                        "lit_m": (rgb - base_un) * wm[..., None], "lit_g": (rgb - base_un) * ww[..., None],
                        "ww": ww, "lit_fm": (rgb - base_un) * fm[..., None],
                        "warm_r": warm_r, "to_warm": np.clip(lum[..., None] * GOLD * 1.45, 0, 1) - rgb})
        return out

    def _prep_tech(self, rgb):
        """Lift the technician (and his reflection) off the far plate; keep his body as a sprite."""
        x0, y0, x1, y1 = [int(v * SC) for v in TECH_BOX]
        fy = int(TECH_FLOOR_Y * SC)
        c = rgb[y0:y1, x0:x1]
        lum = c @ np.float32([0.3, 0.55, 0.15])
        bg = cv2.GaussianBlur(c, (0, 0), 20)
        body = lum < (bg @ np.float32([0.3, 0.55, 0.15])) - 0.06
        rim = ((c.max(2) - c.min(2)) > 0.30) & (np.abs(c - bg).max(2) > 0.12)
        m = (body | rim).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
        n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
        keep = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        m = (lab == keep).astype(np.float32)
        alpha = np.clip(cv2.GaussianBlur(m, (0, 0), 0.8) * 1.3, 0, 1)
        self.tech = {"rgba": np.dstack([c.copy(), alpha]), "x0": x0, "y0": y0, "fy": fy,
                     "cx": float((np.where(m > 0)[1]).mean())}
        # clean plate: inpaint the body and the painted reflection under it
        hole = np.zeros(rgb.shape[:2], np.uint8)
        hole[y0:y1, x0:x1] = cv2.dilate(m.astype(np.uint8), np.ones((7, 7), np.uint8))
        refl = cv2.flip(hole[y0:y1, x0:x1], 0)[: min(y1 - y0, hole.shape[0] - fy)]
        hole[fy:fy + refl.shape[0], x0:x1] = np.maximum(hole[fy:fy + refl.shape[0], x0:x1],
                                                         cv2.dilate(refl, np.ones((9, 9), np.uint8)))
        r8 = (np.clip(rgb, 0, 1) * 255).astype(np.uint8)
        clean = cv2.inpaint(r8, hole, 7, cv2.INPAINT_TELEA).astype(np.float32) / 255
        noise = L.brush_noise(rgb.shape[:2], 41, scale=2, angle=0.0, stretch=6)[..., None] * 0.012
        hf = cv2.GaussianBlur(hole.astype(np.float32), (0, 0), 2)[..., None]
        return clean * (1 - hf) + (clean + noise) * hf

    @cached_property
    def floor(self):
        """Floor mask (soft) and the ripple geometry for the reflection shimmer."""
        Hh, Ww = self.lay.H, self.lay.W
        m = L.poly_mask((Hh, Ww), [(x * SC, y * SC) for x, y in FLOOR])
        m = cv2.GaussianBlur(m, (0, 0), 6)
        r0 = int(min(y for _, y in FLOOR) * SC) - 10
        yh = VANISH[1] * SC
        ys = np.arange(r0, Hh, dtype=np.float32)
        s = np.clip((ys - yh) / (Hh - yh), 0, 1)
        gx, gy = np.meshgrid(np.arange(Ww, dtype=np.float32), ys)
        return {"m": m[r0:], "r0": r0, "s": s[:, None], "gx": gx, "gy": gy, "ys": ys[:, None]}

    # ------------------------------------------------------------ light state
    def k_magenta(self, f):
        fh = f - f % 2
        if fh >= self.S["third"]:
            return {0: 0.50}.get(fh - self.S["third"], 0.42)    # drops back on the word
        k = 0.78
        for b in self.S["beats"]:
            k = max(k, {0: 1.95, 2: 1.35, 4: 1.75, 6: 1.15}.get(fh - b, 0.0))
        return k

    def wave_passed(self, d, f):
        """0..1 per pixel: has the gold wave (camera -> far end, from "third") reached this depth."""
        u = (f - f % 2 - self.S["third"]) / 14.0
        if u < 0:
            return np.zeros_like(d)
        return 1 / (1 + np.exp(-(d - (1.0 - u * 1.1)) / 0.035))

    def k_gold(self, d, f):
        """Gold gain per pixel: a warm wave running from the camera (depth 1) to the far end (0)."""
        fh = f - f % 2
        u = (fh - self.S["third"]) / 14.0
        if u < 0:
            return 1.0
        front = 1.0 - u * 1.1
        passed = 1 / (1 + np.exp(-(d - front) / 0.035))
        crest = np.exp(-((d - front) / 0.07) ** 2)
        return 1.0 + 1.0 * passed + 1.1 * crest

    def tech_pose(self, f):
        fh = f - f % 2
        poses = [1.0, 0.82, 0.5, -0.42, -0.78, -0.95, -1.0]
        i = (fh - self.S["turn"]) // 2
        return poses[0] if i < 0 else poses[min(i, len(poses) - 1)]

    # ------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        km = self.k_magenta(f)
        gold_on = f - f % 2 >= self.S["third"]
        rps = []
        for i, p in enumerate(self.planes):
            rgb = p["rgb"] + (km - 1) * p["lit_m"] + (min((km / 0.78) ** 1.8, 1.8) - 1) * p["lit_fm"]   # reflection follows the racks
            warm = 0.75                                   # the gold side is gold-lit from the first frame
            if gold_on:
                kg = self.k_gold(p["d"], f)[..., None]
                rgb = rgb + (kg - 1) * p["lit_g"] + (kg - 1) * p["ww"][..., None] * GOLD * 0.20
                warm = warm + 0.35 * self.wave_passed(p["d"], f)[..., None]
            rgb = rgb + warm * p["warm_r"][..., None] * p["to_warm"]
            if i == 0:
                rgb = rgb.copy()
                self._tech_into(rgb, f)
            rgb = self._shimmer(rgb, th)
            rps.append({"rgb": rgb, "a": p["a"], "n": p["n"]})
        img = self.cam.render(rps, t)
        self._labels(img, f)
        return img, {"km": km, "gold": gold_on}

    def _tech_into(self, rgb, f):
        tc = self.tech
        sx = self.tech_pose(f)
        p = tc["rgba"]
        h, w = p.shape[:2]
        M = np.float32([[sx, 0, tc["cx"] * (1 - sx)], [0, 1, 0]])
        q = cv2.warpAffine(p, M, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
        if sx < 0:
            q = q.copy()
            q[..., :3] = _swap_rims(q[..., :3])
        a = q[..., 3:4]
        x0, y0 = tc["x0"], tc["y0"]
        rgb[y0:y0 + h, x0:x0 + w] = rgb[y0:y0 + h, x0:x0 + w] * (1 - a) + q[..., :3] * a
        # his reflection on the wet floor: the posed body mirrored at the feet, darker and softer
        fy = tc["fy"]
        rq = cv2.flip(q[: fy - y0], 0)
        rh = min(rq.shape[0], rgb.shape[0] - fy)
        rq = cv2.GaussianBlur(rq[:rh], (0, 0), 1.2)
        fade = np.linspace(0.55, 0.0, rh, dtype=np.float32)[:, None, None]
        ra = rq[..., 3:4] * fade
        rgb[fy:fy + rh, x0:x0 + w] = rgb[fy:fy + rh, x0:x0 + w] * (1 - ra) + rq[..., :3] * 0.7 * ra

    def _shimmer(self, rgb, th):
        """Wet-floor reflections wobble sideways on 2s; ripples get longer and wider toward camera."""
        fl = self.floor
        r0 = fl["r0"]
        s = fl["s"]
        ph = th * 2 * math.pi * 1.3
        lam = 5 + 36 * s
        dx = (0.5 + 3.2 * s) * np.sin(fl["ys"] / lam * 2 * math.pi * 0.35 + ph) \
            + (0.3 + 1.4 * s) * np.sin(fl["gx"] / (60 + 90 * s) + fl["ys"] / lam * 1.7 - ph * 1.6)
        mx = fl["gx"] + dx * fl["m"]
        out = rgb.copy()
        band = cv2.remap(rgb, mx.astype(np.float32), fl["gy"], cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        lum = band @ np.float32([0.3, 0.55, 0.15])
        glint = 1 + 0.10 * np.clip((lum - 0.35) / 0.4, 0, 1) * np.sin(fl["ys"] * 0.9 + ph * 2.3 + fl["gx"] * 0.02)
        out[r0:] = band * glint[..., None]
        return out

    # ------------------------------------------------------------ labels
    @cached_property
    def label_rgba(self):
        return {"ai": _label("AI: under a third", MAGENTA, 56, seed=3),
                "else": _label("Everything else", GOLD, 56, seed=4),
                "src": _source("IEA, 2026")}

    def _labels(self, img, f):
        x0, y0, x1, y1 = safe_box()
        L_ = self.label_rgba
        # each label on its own side of the aisle: AI over the magenta racks (left), the rest over the gold
        O.draw_pop(img, L_["ai"], x0 - 6, 300, f, self.S["under"], glow=MAGENTA * 0.6)
        ex = x1 - L_["else"].shape[1] + 6
        O.draw_pop(img, L_["else"], ex, 520, f, self.S["else"], glow=GOLD * 0.6)
        O.draw_pop(img, L_["src"], x1 - L_["src"].shape[1] + 6, 520 + L_["else"].shape[0] - 4, f, self.S["source"])

    # ------------------------------------------------------------ framework hooks
    def finish_args(self, f, info):
        return {"bloom_strength": 0.45 + 0.15 * max(info["km"] - 1, 0) + (0.12 if info["gold"] else 0.0)}

    def events(self):
        ev = [(self.f0, "cut", {})]
        ev += [(b, "magenta_pulse", {}) for b in self.S["beats"]]
        ev.append((self.S["turn"], "tech_turn", {}))
        ev.append((self.S["under"], "label_ai", {}))
        ev.append((self.S["third"], "gold_wave", {}))
        ev += [(self.S["third"] + 2 * k, "wave_step", {"k": k}) for k in range(1, 7)]
        ev.append((self.S["else"], "label_else", {}))
        ev.append((self.S["source"], "source", {}))
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tt = A.t_axis(dur + 0.8)
        fans = A.lowpass(A.noise(dur + 0.8, 51, "pink"), 1800) * 0.5 + A.bandpass(A.noise(dur + 0.8, 52), 3000, 6000) * 0.06
        snd.bed(fans, t0, -27)
        snd.bed(A.hum(dur + 0.8, 60.0, seed=53), t0, -30)
        # the magenta side: a heartbeat of low thumps that stops on "third"
        for b in self.S["beats"]:
            snd.sfx(A.thunk(b), b / FPS, -17, -0.35)
            snd.sfx(A.thunk(b + 1), (b + 4) / FPS, -21, -0.35)
        snd.sfx(A.soft_click(900, 4), self.S["turn"] / FPS, -30, 0.0)          # boot scuff as he turns
        snd.sfx(A.tick(self.S["under"], 2000), self.S["under"] / FPS, -26, -0.4)
        # the gold wave: a warm swell and a cascade of bells running away down the aisle
        tg = self.S["third"] / FPS
        swell = _warm_swell(1.6)
        snd.sfx(swell, tg - 0.05, -20, 0.25)
        for k, freq in enumerate([523.3, 659.3, 784.0, 880.0, 1046.5, 1174.7, 1318.5]):
            snd.sfx(A.bell(freq, 0.8, seed=k), tg + k * 2 / FPS, -22 - 1.2 * k, 0.35 - 0.05 * k)
        snd.sfx(A.tick(self.S["else"], 2400), self.S["else"] / FPS, -26, 0.4)


# ------------------------------------------------------------------ local helpers
def _swap_rims(rgb):
    """After the turn the magenta rim belongs on his other side: swap magenta and gold rim light."""
    wm = light_weight(rgb, "magenta", blur=0)[..., None]
    ww = light_weight(rgb, "warm", blur=0)[..., None]
    lum = (rgb @ np.float32([0.3, 0.55, 0.15]))[..., None]
    as_gold = np.clip(lum * GOLD * 1.5, 0, 1)
    as_mag = np.clip(lum * MAGENTA * 1.5, 0, 1)
    return rgb * (1 - wm - ww) + as_gold * wm + as_mag * ww


def _label(text, color, size, seed):
    """Scene label: a painted plum chip with a swatch of the side's light colour and cream type."""
    a = O._text_alpha(text, T.sans(size, 680))
    t_rgba, pad = T.styled_text_rgba(a, O.CREAM, seed=seed, shadow_off=(1, 2), soft_shadow=4,
                                     shadow_strength=0.45, grad=0.05)
    w, h = a.shape[1] + 110, a.shape[0] + 48
    chip = O.painted_chip(w, h, seed=seed + 10)
    canvas = np.zeros((h + 20, w + 20, 4), np.float32)
    T.over_rgba(canvas, chip, -2, -2)
    sw = O.painted_swatch(36, 36, seed=seed + 20, color=color, opacity=1.0, rough=0.12, radius=2)
    T.over_rgba(canvas, sw, 6 + 28, 6 + h // 2 - 18)
    T.over_rgba(canvas, t_rgba, 6 + 84 - pad, 6 + 24 - pad)
    return canvas


def _source(text):
    a = O._text_alpha(text, T.at_least_cap(T.sans(44, 600), O.TAG_CAP))
    t_rgba, pad = T.styled_text_rgba(a, (226, 214, 196), seed=7, shadow_off=(1, 1), soft_shadow=3,
                                     shadow_strength=0.35, grad=0.03)
    w, h = a.shape[1] + 34, a.shape[0] + 18
    chip = O.painted_chip(w, h, seed=17, opacity=0.74)
    canvas = np.zeros((h + 12, w + 12, 4), np.float32)
    T.over_rgba(canvas, chip, -2, -2)
    T.over_rgba(canvas, t_rgba, 6 + 17 - pad, 6 + 9 - pad)
    return canvas


def _warm_swell(dur):
    """A major chord that blooms and settles (detuned saws through a low-pass that opens)."""
    t = A.t_axis(dur)
    x = 0
    for f in (130.8, 164.8, 196.0, 261.6):
        x = x + A.osc(f, dur, "saw") + A.osc(f * 1.004, dur, "saw")
    env = np.clip(t / 0.25, 0, 1) * np.exp(-np.clip(t - 0.4, 0, None) * 1.6)
    x = A.lowpass(x, 1400) * env
    return x / (np.abs(x).max() + 1e-9)


def make(ctx):
    return Shot(ctx)
