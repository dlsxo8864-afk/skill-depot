"""Local helpers for s07_year6 and s08_year7 (candidates to hoist into whatif/ later).

- heard_t:            word onsets from the transcriber's own timestamps when the script alignment
                      had to interpolate (e.g. "$12.99" for "twelve ninety-nine")
- inpaint_textured:   remove a painted object from a plate (Telea or column fill) and re-grain the hole
- bone_warp:          smooth "puppet" warp of a plane (rgb + alpha) by weighted affine bones, so heads,
                      hair and hands bend instead of moving as rigid cut-outs
- rot_affine:         2x3 forward affine: rotate about a pivot, then translate
- coin_rgba:          a painted brass coin at any flip / spin, supersampled, with rim, lit edge, texture
- word_rgba:          display-font text styled exactly like overlays.counter_rgba (for "$?")
- Rain:               rain streaks on 2s, in plane space (with parallax) and screen space, lit by a lamp cone
- splash_shapes:      drawn splash crowns, droplets and ripple rings (graphic FX, on 2s)
- sounds:             rain bed, coin clunk / tink / splash, muffled music burst, paper flutter, marker
                      squeak, dissolve shimmer, wood knock, nail scrape
"""
import math
from functools import lru_cache

import cv2
import numpy as np

from whatif import audio as A
from whatif import text as T
from whatif.config import FPS
from whatif.fx2d import ShapeCanvas, tapered_streak_poly
from whatif.layers import brush_noise, push_pull_fill


# ------------------------------------------------------------------ timing
def heard_t(ctx, token, n=0):
    """Global start time (s) of the n-th transcriber word whose text starts with `token` (case-insensitive)."""
    import timeline as TL
    info = TL.analyse_lines()[ctx.wav.name]
    hits = [w for w in info["heard_words"] if w["w"].lower().strip(",.?!").startswith(token.lower())]
    return ctx.vo_at + hits[n]["s"]


def speech_onsets(ctx, floor_db=-22.0, min_gap=0.08):
    """Onsets (global s) of voiced bursts in this shot's narration (10 ms RMS above floor re. peak)."""
    import soundfile as sf
    x, sr = sf.read(ctx.wav, always_2d=True)
    m = x.mean(1)
    w = int(0.01 * sr)
    n = len(m) // w
    r = np.sqrt((m[: n * w].reshape(n, w) ** 2).mean(1))
    d = 20 * np.log10(r / r.max() + 1e-9)
    on = d > floor_db
    out, last_off = [], -1.0
    for i in range(1, n):
        if on[i] and not on[i - 1]:
            t = i * 0.01
            if t - last_off >= min_gap or not out:
                out.append(ctx.vo_at + t)
        if not on[i] and on[i - 1]:
            last_off = i * 0.01
    return out


# ------------------------------------------------------------------ plate surgery
def inpaint_textured(rgb, hole, seed, mode="telea", radius=7, grain=1.0, angle=1.5708):
    """Fill `hole` (bool/float HxW) in float rgb (in place) and add brush grain matched to the plate.
    mode 'telea' = OpenCV Telea; 'column' = vertical interpolation (keeps vertical streak reflections)."""
    hole = (hole > 0.5).astype(np.uint8)
    if not hole.any():
        return rgb
    ys, xs = np.where(hole)
    pad = 24
    y0, y1 = max(ys.min() - pad, 0), min(ys.max() + pad + 1, rgb.shape[0])
    x0, x1 = max(xs.min() - pad, 0), min(xs.max() + pad + 1, rgb.shape[1])
    sub = rgb[y0:y1, x0:x1]
    hm = hole[y0:y1, x0:x1]
    if mode == "column":
        fill = sub.copy()
        for c in range(sub.shape[1]):
            col = hm[:, c]
            if not col.any():
                continue
            idx = np.where(col)[0]
            # contiguous runs
            runs = np.split(idx, np.where(np.diff(idx) > 1)[0] + 1)
            for r in runs:
                a, b = r[0] - 1, r[-1] + 1
                ca = sub[max(a, 0), c] if a >= 0 else sub[min(b, sub.shape[0] - 1), c]
                cb = sub[min(b, sub.shape[0] - 1), c] if b < sub.shape[0] else ca
                u = np.linspace(0, 1, len(r) + 2)[1:-1, None]
                fill[r, c] = ca * (1 - u) + cb * u
        # soften across columns inside the hole only (column fill alone looks combed)
        sm = cv2.GaussianBlur(fill, (0, 0), 1.6)
        fill = np.where(hm[..., None] > 0, fill * 0.45 + sm * 0.55, sub)
    else:
        u8 = (np.clip(sub, 0, 1) * 255).astype(np.uint8)
        fill = cv2.inpaint(u8, hm, radius, cv2.INPAINT_TELEA).astype(np.float32) / 255
        pp = push_pull_fill(sub, hm == 0)
        fill = np.where(hm[..., None] > 0, fill * 0.6 + pp * 0.4, sub)
    hp = sub - cv2.GaussianBlur(sub, (0, 0), 3)
    v = hm == 0
    amp = float(np.sqrt((hp[v] ** 2).mean())) if v.any() else 0.02
    n = brush_noise(hm.shape, seed, scale=3.0, angle=angle, stretch=6.0)
    soft = cv2.GaussianBlur(hm.astype(np.float32), (0, 0), 1.2)[..., None]
    fill = fill + (n[..., None] * amp * 0.9 * grain) * (hm[..., None] > 0)
    rgb[y0:y1, x0:x1] = np.clip(sub * (1 - soft) + fill * soft, 0, 1)
    return rgb


def rot_affine(pivot, deg=0.0, dx=0.0, dy=0.0, scale=1.0):
    """Forward 2x3 affine (y-down image coords): rotate clockwise by deg about pivot, scale, then translate."""
    a = math.radians(deg)
    c, s = math.cos(a) * scale, math.sin(a) * scale
    px, py = pivot
    return np.float32([[c, -s, px - c * px + s * py + dx], [s, c, py - s * px - c * py + dy]])


def apply_affine(M, p):
    return (M[0, 0] * p[0] + M[0, 1] * p[1] + M[0, 2], M[1, 0] * p[0] + M[1, 1] * p[1] + M[1, 2])


def bone_warp(rgb, a, bones, bbox):
    """Warp a plane in place by smoothly weighted affine bones (linear blend skinning in 2D).
    bones: [(weight float32 (y1-y0, x1-x0) over bbox, M 2x3 forward affine)], bbox (x0, y0, x1, y1) plane px.
    The inverse map is solved with two fixed-point steps, exact enough for the few-pixel moves we use."""
    x0, y0, x1, y1 = bbox
    gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    dx = np.zeros_like(gx)
    dy = np.zeros_like(gy)
    for w, M in bones:
        if w is None:
            continue
        fx = M[0, 0] * gx + M[0, 1] * gy + M[0, 2]
        fy = M[1, 0] * gx + M[1, 1] * gy + M[1, 2]
        dx += w * (fx - gx)
        dy += w * (fy - gy)
    if not (np.abs(dx).max() > 0.05 or np.abs(dy).max() > 0.05):
        return
    sx, sy = gx - dx, gy - dy
    for _ in range(2):
        ddx = cv2.remap(dx, sx - x0, sy - y0, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        ddy = cv2.remap(dy, sx - x0, sy - y0, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        sx, sy = gx - ddx, gy - ddy
    new_rgb = cv2.remap(rgb, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    new_a = cv2.remap(a, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    rgb[y0:y1, x0:x1] = new_rgb
    a[y0:y1, x0:x1] = new_a


def dense_flow(src, dst, scale=0.5):
    """Farneback flow from src to dst (float RGB 0..1): a point p in src moves to p + flow(p)."""
    g = lambda x: (cv2.cvtColor(np.clip(cv2.resize(x, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA), 0, 1),
                                cv2.COLOR_RGB2GRAY) * 255).astype(np.uint8)
    f = cv2.calcOpticalFlowFarneback(g(src), g(dst), None, 0.5, 6, 41, 5, 7, 1.5, cv2.OPTFLOW_FARNEBACK_GAUSSIAN)
    return cv2.resize(f, (src.shape[1], src.shape[0]), interpolation=cv2.INTER_LINEAR) / scale


def sample_along(img, flow, k):
    """img sampled at p + k * flow(p) (k = 0.5 pulls an incoming pose halfway back toward the outgoing one)."""
    H, W = img.shape[:2]
    gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    return cv2.remap(img, gx + k * flow[..., 0], gy + k * flow[..., 1], cv2.INTER_LINEAR,
                     borderMode=cv2.BORDER_REFLECT)


def inbetween(a, b, morph_mask=None):
    """One in-between drawing halfway from pose a to pose b (same size, float): b stretched halfway back along
    the measured motion (a single drawing, no ghosting); inside morph_mask (0..1, e.g. an eyelid) a true
    two-way morph, so an eye is drawn half shut instead of popping."""
    fl = dense_flow(a, b)
    out = sample_along(b, fl, 0.5)
    if morph_mask is not None:
        mid = 0.5 * sample_along(a, fl, -0.5) + 0.5 * out
        m = morph_mask[..., None] if out.ndim == 3 else morph_mask
        out = out * (1 - m) + mid * m
    return out.astype(np.float32)


def ramp_weight(shape_bbox, poly_mask, p_full, p_zero, blur=12.0):
    """Weight over a bbox: polygon mask (already cropped) times a smoothstep ramp from 1 at p_full to 0 at p_zero."""
    x0, y0, x1, y1 = shape_bbox
    gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    d = np.float32([p_zero[0] - p_full[0], p_zero[1] - p_full[1]])
    u = ((gx - p_full[0]) * d[0] + (gy - p_full[1]) * d[1]) / float(d @ d)
    u = np.clip(u, 0, 1)
    r = 1 - u * u * (3 - 2 * u)
    m = cv2.GaussianBlur(poly_mask.astype(np.float32), (0, 0), blur) if blur else poly_mask
    return (r * m).astype(np.float32)


# ------------------------------------------------------------------ drawn objects
def coin_rgba(r, flip=1.0, spin=0.0, seed=0, lit=(1.0, 0.72, 0.38), ss=4, face=None):
    """Painted brass coin: disc of radius r (px) squashed to |flip| across its spin axis, rotated by spin (deg).
    Rim ring, lamp-lit upper-right edge, dark lower-left edge, a soft highlight stroke and stroke grain.
    face: optional RGB texture (square) painted onto the disc. Returns float32 RGBA (straight alpha)."""
    flip = float(np.clip(abs(flip), 0.06, 1.0))
    R = int(math.ceil(r)) + 4
    S = 2 * R * ss
    yy, xx = np.mgrid[0:S, 0:S].astype(np.float32)
    cx = cy = S / 2
    a = math.radians(spin)
    ux = ((xx - cx) * math.cos(a) + (yy - cy) * math.sin(a)) / (r * ss)
    uy = (-(xx - cx) * math.sin(a) + (yy - cy) * math.cos(a)) / (r * ss)
    # the coin is a disc in its own plane: ux along the flip axis is compressed
    ex = ux / flip
    rr = np.sqrt(ex * ex + uy * uy)
    disc = (rr <= 1.0).astype(np.float32)
    # the coin's thickness: the face ellipse swept back along the flip axis (seen as a dark band edge-on)
    thick = 0.13 * math.sqrt(max(0.0, 1 - flip * flip)) + 0.02
    side = np.zeros_like(disc)
    for k in np.linspace(0.0, 1.0, 5):
        e2 = (ux + thick * k) / flip
        side = np.maximum(side, (np.sqrt(e2 * e2 + uy * uy) <= 1.0).astype(np.float32))
    alpha = np.maximum(disc, side)
    base = np.float32([0.78, 0.53, 0.20])
    rim = np.float32([0.45, 0.26, 0.10])
    shade = np.float32([0.30, 0.16, 0.12])
    light_dir = np.float32([0.75, -0.65])          # lamp up-right
    lam = np.clip((xx - cx) / (r * ss) * light_dir[0] + (yy - cy) / (r * ss) * light_dir[1], -1, 1)[..., None]
    col = base * (0.82 + 0.30 * lam) + np.float32(lit) * 0.18 * np.clip(lam, 0, 1)
    if face is not None:
        f = cv2.resize(face, (S, S), interpolation=cv2.INTER_AREA)
        col = col * 0.35 + f * 0.65 * (0.9 + 0.25 * lam)
    ring = ((rr > 0.80) & (rr <= 1.0)).astype(np.float32)[..., None]
    col = col * (1 - ring * 0.45) + rim * ring * 0.45
    # lit rim crescent on the upper-right, dark lower-left
    cres = np.clip((rr - 0.78) / 0.22, 0, 1)[..., None] * np.clip(lam, 0, 1) * 0.9
    col = col + (np.float32(lit) * 0.95 - col) * cres * disc[..., None]
    sidecol = shade + (rim - shade) * np.clip(lam + 0.4, 0, 1)
    col = np.where(disc[..., None] > 0, col, sidecol)
    # highlight stroke across the face
    hl = np.exp(-((ux * 0.8 + uy * 0.6 - 0.25) ** 2) / 0.012) * disc * flip
    col = col + np.float32([1.0, 0.86, 0.6]) * hl[..., None] * 0.35
    n = brush_noise((S, S), seed, scale=2.0 * ss, angle=spin * 0.017 + 0.4, stretch=5)
    col = col * (1 + 0.07 * n[..., None])
    out = np.dstack([np.clip(col, 0, 1), alpha]).astype(np.float32)
    out = cv2.resize(out, (2 * R, 2 * R), interpolation=cv2.INTER_AREA)
    out[..., 3] = cv2.GaussianBlur(out[..., 3], (0, 0), 0.5)
    return out


def paste_rgba(dst_rgb, rgba, cx, cy, dst_a=None, opacity=1.0, mode="over"):
    """Place an RGBA patch centred at (cx, cy) (float px) into dst (in place). mode 'over' or 'screen'."""
    h, w = rgba.shape[:2]
    x0 = int(round(cx - w / 2))
    y0 = int(round(cy - h / 2))
    H, W = dst_rgb.shape[:2]
    xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x0 + w, W), min(y0 + h, H)
    if xb <= xa or yb <= ya:
        return
    p = rgba[ya - y0:yb - y0, xa - x0:xb - x0]
    al = p[..., 3:4] * opacity
    reg = dst_rgb[ya:yb, xa:xb]
    if mode == "screen":
        dst_rgb[ya:yb, xa:xb] = 1 - (1 - reg) * (1 - p[..., :3] * al)
    else:
        dst_rgb[ya:yb, xa:xb] = reg * (1 - al) + p[..., :3] * al
    if dst_a is not None:
        dst_a[ya:yb, xa:xb] = dst_a[ya:yb, xa:xb] * (1 - al[..., 0]) + al[..., 0]


@lru_cache(maxsize=8)
def word_rgba(text, size=150, color=(246, 236, 216), seed=5):
    """Display-font word styled like overlays.counter_rgba (same font, shadow, gradient, tooth)."""
    from PIL import Image, ImageDraw
    fnt = T.font("display", size)
    ch = int(size * 1.18)
    _, th0, _, oy0 = T.text_size(fnt, "0")
    base_y = (ch - th0) / 2 - oy0
    tw, th, ox, oy = T.text_size(fnt, text)
    im = Image.new("L", (tw + 8, ch), 0)
    ImageDraw.Draw(im).text((4 - ox, base_y), text, font=fnt, fill=255)
    a = np.asarray(im, np.float32) / 255
    rgba, _ = T.styled_text_rgba(a, color, seed=seed, shadow_off=(4, 6), soft_shadow=10, grad=0.14)
    return rgba


# ------------------------------------------------------------------ rain
class Rain:
    """Rain streaks held on 2s. Positions live in a W x H space; `cone` = (apex xy, dir xy, half-angle rad,
    reach px) gives the lamp-lit streaks their warm colour. Draw into a plane (pre-camera) or onto the frame."""

    def __init__(self, n, W, H, seed, speed=(1500, 2300), length=(26, 60), width=(1.0, 2.2), slant=-0.10,
                 alpha=(0.10, 0.30)):
        rng = np.random.default_rng(seed)
        self.W, self.H = W, H
        self.x = rng.uniform(-0.1 * W, 1.1 * W, n)
        self.y = rng.uniform(0, H, n)
        self.v = rng.uniform(*speed, n)
        self.L = rng.uniform(*length, n)
        self.w = rng.uniform(*width, n)
        self.al = rng.uniform(*alpha, n)
        self.slant = slant
        self.ph = rng.uniform(0, 1, n)

    def positions(self, t):
        y = (self.y + self.v * t) % (self.H * 1.1) - self.H * 0.05
        x = self.x + self.slant * (self.v * t)
        x = (x + 0.1 * self.W) % (1.2 * self.W) - 0.1 * self.W
        return x, y

    def draw(self, dst, t, cone=None, warm=(1.0, 0.70, 0.40), cool=(0.62, 0.58, 0.92), gain=1.0,
             mapper=None, mask=None, glow_sigma=1.4):
        """t: held time (s). mapper: optional f(x, y) -> (x, y, scale) into dst coords (camera)."""
        H, W = dst.shape[:2]
        xs, ys = self.positions(t)
        cw = ShapeCanvas(W, H, ss=2)
        cc = ShapeCanvas(W, H, ss=2)
        d = np.float32([self.slant, 1.0])
        d /= np.linalg.norm(d)
        for i in range(len(xs)):
            x, y, s = xs[i], ys[i], 1.0
            if mapper is not None:
                x, y, s = mapper(x, y)
            if x < -40 or x > W + 40 or y < -80 or y > H + 80:
                continue
            k = 0.0
            if cone is not None:
                (ax, ay), (cdx, cdy), half, reach = cone
                vx, vy = (xs[i] - ax), (ys[i] - ay)
                dist = math.hypot(vx, vy) + 1e-3
                cosang = (vx * cdx + vy * cdy) / dist
                ang = math.acos(max(-1.0, min(1.0, cosang)))
                k = math.exp(-(ang / half) ** 2) * max(0.0, 1 - dist / reach) ** 0.8
            val = int(255 * min(1.0, self.al[i] * gain * (1 + 1.6 * k)))
            if val < 6:
                continue
            p = np.float32([x, y])
            poly = tapered_streak_poly(p, d, self.L[i] * s, self.w[i] * s)
            (cw if k > 0.25 else cc).fill(poly, value=val)
        for canv, col in ((cw, warm), (cc, cool)):
            c, g = canv.result(glow_sigma=glow_sigma)
            if mask is not None:
                c, g = c * mask, g * mask
            src = np.clip(np.float32(col) * (c[..., None] * 0.9 + g[..., None] * 0.35), 0, 1)
            dst[:] = 1 - (1 - dst) * (1 - src)
        return dst


def splash_shapes(sc, p, drawing, seed, scale=1.0, persp=0.32):
    """One drawing of a drop/coin splash into a ShapeCanvas: 0 crown, 1 lifted droplets, 2 falling droplets
    + first ring, 3-4 rings. p = impact point (canvas px), persp = ground ellipse aspect."""
    rng = np.random.default_rng(seed)
    x, y = p
    s = scale
    if drawing == 0:
        for k in range(7):
            a = math.pi * (0.12 + 0.76 * k / 6) + rng.uniform(-0.08, 0.08)
            dvec = np.float32([math.cos(a) * 1.0, -math.sin(a) * 1.4])
            base = np.float32([x + math.cos(a) * 9 * s, y - 2 * s])
            sc.fill(tapered_streak_poly(base + dvec * 16 * s * rng.uniform(0.8, 1.3), dvec,
                                        rng.uniform(14, 24) * s, rng.uniform(3.0, 4.5) * s))
        sc.line(_ellipse_pts(x, y, 14 * s, 14 * s * persp, 18, 0.2, 2.9), 1.4 * s, value=200)
    elif drawing == 1:
        for k in range(6):
            a = math.pi * (0.10 + 0.8 * k / 5) + rng.uniform(-0.1, 0.1)
            r = rng.uniform(26, 40) * s
            q = np.float32([x + math.cos(a) * r * 0.9, y - math.sin(a) * r * 1.2 - 6 * s])
            dvec = np.float32([math.cos(a), -math.sin(a) * 1.3])
            sc.fill(tapered_streak_poly(q, dvec, rng.uniform(7, 12) * s, rng.uniform(3.2, 4.4) * s))
        sc.line(_ellipse_pts(x, y, 24 * s, 24 * s * persp, 18, 0.1, 2.6), 1.2 * s, value=170)
        sc.line(_ellipse_pts(x, y, 24 * s, 24 * s * persp, 10, 3.6, 5.2), 1.0 * s, value=110)
    elif drawing == 2:
        for k in range(5):
            a = math.pi * (0.1 + 0.8 * k / 4) + rng.uniform(-0.1, 0.1)
            r = rng.uniform(34, 50) * s
            q = np.float32([x + math.cos(a) * r, y - math.sin(a) * r * 0.6])
            sc.fill(tapered_streak_poly(q, np.float32([math.cos(a) * 0.3, 1.0]), rng.uniform(5, 9) * s, 3.0 * s), value=210)
        sc.line(_ellipse_pts(x, y, 34 * s, 34 * s * persp, 18, 0.3, 2.8), 1.1 * s, value=140)
        sc.line(_ellipse_pts(x, y, 34 * s, 34 * s * persp, 10, 3.5, 5.6), 1.0 * s, value=90)
    elif drawing in (3, 4):
        r = (44 if drawing == 3 else 56) * s
        sc.line(_ellipse_pts(x, y, r, r * persp, 18, 0.2, 2.7), 1.0 * s, value=100 if drawing == 3 else 55)
        sc.line(_ellipse_pts(x, y, r * 0.6, r * 0.6 * persp, 12, 3.4, 5.9), 1.0 * s, value=80 if drawing == 3 else 40)


def _ellipse_pts(x, y, rx, ry, n=40, a0=0.0, a1=2 * math.pi):
    t = np.linspace(a0, a1, n)
    return np.stack([x + rx * np.cos(t), y + ry * np.sin(t)], 1).astype(np.float32)


# ------------------------------------------------------------------ sounds
def _env(n, a, d):
    return A.env_adsr(n, a, 0.0, 1.0, d)


def rain_bed(dur, seed=31):
    """Steady rain: airy hiss + dense small drops + low wash."""
    rng = np.random.default_rng(seed)
    n = int(round(dur * A.SR))
    hiss = A.bandpass(A.noise(dur, seed, "pink"), 1500, 9000) * 0.35
    wash = A.lowpass(A.noise(dur, seed + 1, "brown"), 300) * 0.45
    drops = np.zeros(n)
    k = int(dur * 380)
    pos = rng.integers(0, n, k)
    drops[pos] = rng.uniform(-1, 1, k) * rng.uniform(0.2, 1.0, k) ** 2
    drops = A.bandpass(drops, 2000, 7500) * 1.6
    am = 1 + 0.12 * np.sin(2 * np.pi * 0.17 * np.arange(n) / A.SR)
    return (hiss + wash + drops) * am


def hood_patter(dur, seed=33):
    """Closer, sparse drops ticking on a fabric hood."""
    rng = np.random.default_rng(seed)
    n = int(round(dur * A.SR))
    x = np.zeros(n)
    k = int(dur * 60)
    pos = rng.integers(0, n, k)
    x[pos] = rng.uniform(0.3, 1.0, k)
    x = A.bandpass(x, 700, 3000) * 3
    return A.lowpass(x, 3500)


def coin_clunk(seed=41):
    """Coin dropping into a mechanism: click, metal ring, then the latch thunk."""
    n = int(0.45 * A.SR)
    t = np.arange(n) / A.SR
    click = A.bandpass(A.noise(0.45, seed), 2500, 9000) * A.exp_decay(n, 0.004) * 0.8
    ring = sum(a * np.sin(2 * np.pi * f * t + i) * A.exp_decay(n, tau)
               for i, (f, a, tau) in enumerate([(2350, 0.30, 0.07), (3710, 0.22, 0.05), (5230, 0.14, 0.03), (6890, 0.08, 0.02)]))
    k = int(0.035 * A.SR)
    latch = np.zeros(n)
    th = A.thunk(seed)[: n - k] * 0.9
    latch[k:k + len(th)] = A.lowpass(th, 1400)
    tick2 = np.zeros(n)
    k2 = int(0.05 * A.SR)
    tk = A.tick(seed + 1, 1700)
    tick2[k2:k2 + len(tk)] = tk * 0.5
    return click + ring * 0.6 + latch + tick2


def coin_slide(seed=42):
    """Coin edge scraping into the slot (short)."""
    n = int(0.09 * A.SR)
    x = A.bandpass(A.noise(0.09, seed), 3000, 7500)
    return x * np.sin(np.linspace(0, np.pi, n)) ** 2 * 0.6


def coin_tink(seed=43, pitch=1.0, dur=0.35):
    """Small coin clink (on other coins / pavement)."""
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    rng = np.random.default_rng(seed)
    x = sum(a * np.sin(2 * np.pi * f * pitch * rng.uniform(0.97, 1.03) * t) * A.exp_decay(n, tau)
            for f, a, tau in [(3100, 0.5, 0.06), (4870, 0.35, 0.04), (7020, 0.2, 0.025), (2210, 0.25, 0.09)])
    x += A.bandpass(A.noise(dur, seed), 3000, 9000) * A.exp_decay(n, 0.003) * 0.5
    return x


def water_splash(seed=44, size=1.0):
    """Coin hitting a puddle: plop body + droplet spray."""
    dur = 0.5
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    f = 900 * size ** -0.3 * np.exp(-t * 9) + 250
    plop = np.sin(2 * np.pi * np.cumsum(f) / A.SR) * A.exp_decay(n, 0.05) * 0.5
    spray = A.bandpass(A.noise(dur, seed, "pink"), 1200, 8000) * A.env_adsr(n, 0.002, 0.05, 0.35, 0.3) * 0.6
    rng = np.random.default_rng(seed)
    drops = np.zeros(n)
    for _ in range(14):
        i = int(rng.uniform(0.04, 0.35) * A.SR)
        tk = A.tick(int(rng.integers(1e6)), rng.uniform(2500, 6000))
        drops[i:i + len(tk)] += tk[: n - i] * rng.uniform(0.1, 0.35)
    return plop + spray + drops


def muffled_music(dur, seed=45, cutoff=900):
    """A burst of a song heard leaking from an earbud: kick, bass, a minor chord stab, hats; muffled, then cut."""
    n = int(round(dur * A.SR))
    t = np.arange(n) / A.SR
    bpm = 112
    beat = 60 / bpm
    out = np.zeros(n)
    for k in range(int(dur / beat) + 1):
        i = int(k * beat * A.SR)
        m = min(n - i, int(0.3 * A.SR))
        if m <= 0:
            break
        tt = np.arange(m) / A.SR
        kick = np.sin(2 * np.pi * np.cumsum(110 * np.exp(-tt * 28) + 45) / A.SR) * np.exp(-tt / 0.11)
        out[i:i + m] += kick
    bass = A.lowpass(A.osc(55.0, dur, "saw"), 220) * 0.35 * (0.6 + 0.4 * np.sin(2 * np.pi * t / beat) ** 2)
    chord = sum(A.osc(f, dur, "saw") for f in (220.0, 261.6, 329.6, 440.0)) * 0.12
    chord = A.lowpass(chord, 1200) * (0.5 + 0.5 * (np.sin(np.pi * t / (beat / 2)) ** 8))
    hats = A.bandpass(A.noise(dur, seed), 6000, 10000) * (np.sin(np.pi * t / (beat / 2)) ** 16) * 0.25
    x = out * 0.9 + bass + chord + hats
    x = A.lowpass(A.highpass(x, 120), cutoff, 4)          # through the earbud shell, from outside
    e = np.ones(n)
    r = int(0.006 * A.SR)
    e[:r] = np.linspace(0, 1, r)
    e[-r:] = np.linspace(1, 0, r)                         # hard cut when the paid time runs out
    return x * e


def paper_flutter(seed=51, dur=0.22):
    """A paper tag flicking on its string."""
    n = int(dur * A.SR)
    rng = np.random.default_rng(seed)
    x = A.bandpass(A.noise(dur, seed, "pink"), 1800, 7000)
    flut = np.abs(np.sin(2 * np.pi * rng.uniform(16, 26) * np.arange(n) / A.SR + rng.uniform(0, 3))) ** 3
    return x * flut * A.env_adsr(n, 0.01, 0.03, 0.7, dur * 0.6)


def marker_squeak(seed=52, dur=0.16):
    """Felt marker writing a short price on paper."""
    n = int(dur * A.SR)
    rng = np.random.default_rng(seed)
    t = np.arange(n) / A.SR
    f = rng.uniform(1700, 2400) * (1 + 0.15 * np.sin(2 * np.pi * rng.uniform(5, 9) * t))
    tone = np.sin(2 * np.pi * np.cumsum(f) / A.SR) * 0.15
    scr = A.bandpass(A.noise(dur, seed), 2500, 6500) * 0.5
    strokes = (np.sin(2 * np.pi * rng.uniform(9, 14) * t) > -0.2).astype(float)
    strokes = A.lowpass(strokes, 60)
    return (tone + scr) * strokes * A.env_adsr(n, 0.005, 0.02, 0.8, 0.03)


def shimmer(seed=53, dur=1.0):
    """A photo dissolving into flecks: rising cloud of glassy grains plus air."""
    n = int(dur * A.SR)
    rng = np.random.default_rng(seed)
    out = np.zeros(n)
    for k in range(40):
        st = rng.uniform(0.0, 0.65) * dur
        ln = rng.uniform(0.05, 0.22)
        f = rng.uniform(1800, 5200) * (1 + 0.6 * st / dur)
        m = int(ln * A.SR)
        i = int(st * A.SR)
        m = min(m, n - i)
        tt = np.arange(m) / A.SR
        g = np.sin(2 * np.pi * f * tt) * np.sin(np.pi * tt / ln) ** 2 * rng.uniform(0.2, 0.6)
        out[i:i + m] += g
    air = A.bandpass(A.noise(dur, seed + 1, "pink"), 3000, 9000) * np.sin(np.linspace(0, np.pi, n)) ** 1.5 * 0.4
    return (out * 0.5 + air) * A.env_adsr(n, 0.02, 0.1, 0.8, 0.45)


def wood_knock(seed=54):
    n = int(0.2 * A.SR)
    t = np.arange(n) / A.SR
    body = (np.sin(2 * np.pi * 210 * t) * 0.6 + np.sin(2 * np.pi * 480 * t) * 0.3) * A.exp_decay(n, 0.025)
    click = A.bandpass(A.noise(0.2, seed), 900, 4000) * A.exp_decay(n, 0.004)
    return body + click * 0.6


def nail_scrape(seed=55, dur=0.28):
    """Picture wire dragging off a nail: gritty scrape with a short metallic squeal."""
    n = int(dur * A.SR)
    t = np.arange(n) / A.SR
    grit = A.bandpass(A.noise(dur, seed), 1200, 4200) * (0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 37 * t)))
    f = np.linspace(2600, 1900, n)
    sq = np.sin(2 * np.pi * np.cumsum(f) / A.SR) * 0.25 * np.sin(np.linspace(0, np.pi, n)) ** 2
    ping = np.sin(2 * np.pi * 3900 * t) * A.exp_decay(n, 0.05) * 0.2
    return (grit * 0.8 + sq) * A.env_adsr(n, 0.01, 0.04, 0.8, 0.08) + ping
