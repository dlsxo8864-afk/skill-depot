"""Local helpers for shots s03_year2 and s04_year3 (candidates to hoist into whatif/ later).

    Rig            2D skinning warp of a painted plane: soft weight maps + per-bone rotate/translate,
                   inverse-mapped so a body bends (shoulders lead, hands follow, hair trails) instead of
                   sliding as a rigid cut-out.
    flame masks    hand-drawn flame tongues (outer / mid / core) with dry-brushed, streaked edges.
    paint_fire     lays those masks into a plate as paint plus a little emissive glow.
    affine_patch   rotate + non-uniform scale an RGBA patch (paper flutter = squash on one axis).
    burn_patch     paper burning away from one side: char band, glowing edge, then gone.
    SourceEmbers   embers emitted from a region, drifting up, posed on 2s, drawn as tapered streaks.
    sounds         fire roar, whump, scrape, paper flutter, register ching, glitch, shatter, footsteps,
                   horn, traffic rumble (numpy only, seeded).
All coordinates are working-plate px (key px * WORK_SCALE) unless a name says key px.
"""
import math

import cv2
import numpy as np

from whatif import audio as A
from whatif.config import WORK_SCALE
from whatif.fx2d import ShapeCanvas, screen_emissive, tapered_streak_poly
from whatif.layers import brush_noise

SC = WORK_SCALE


# ------------------------------------------------------------------ masks
def kp(pts):
    """Key px -> working px (list of points)."""
    return [(x * SC, y * SC) for x, y in pts]


def soft_poly(shape, pts_key, feather=6.0):
    m = np.zeros(shape, np.uint8)
    cv2.fillPoly(m, [np.round(np.float32(kp(pts_key)) * 8).astype(np.int32)], 255, cv2.LINE_AA, shift=3)
    m = m.astype(np.float32) / 255
    return cv2.GaussianBlur(m, (0, 0), feather * SC) if feather else m


def soft_disc(shape, c_key, r_key, feather=0.5):
    """Disc of radius r with a soft edge (feather as a fraction of r)."""
    H, W = shape
    gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
    d = np.sqrt((gx - c_key[0] * SC) ** 2 + (gy - c_key[1] * SC) ** 2) / (r_key * SC)
    return np.clip((1 - d) / max(feather, 1e-3), 0, 1).astype(np.float32)


def ramp(shape, p0_key, p1_key):
    """1 at p0 falling smoothly to 0 at p1 (projection on the p0->p1 line)."""
    H, W = shape
    gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
    p0 = np.float32(p0_key) * SC
    p1 = np.float32(p1_key) * SC
    d = p1 - p0
    u = np.clip(((gx - p0[0]) * d[0] + (gy - p0[1]) * d[1]) / float(d @ d), 0, 1)
    return (1 - u * u * (3 - 2 * u)).astype(np.float32)


# ------------------------------------------------------------------ skinning warp
class Rig:
    """Bones over a box of a plane. bones: {name: {"w": weight (full plane HxW), "pivot": key px}}.
    pose: {name: (angle_deg, dx, dy)} in working px; displacement = sum_i w_i * (T_i(x) - x).
    Positive angle turns clockwise on screen (y down)."""

    def __init__(self, box_key, shape, bones):
        H, W = shape
        x0, y0, x1, y1 = [int(round(v * SC)) for v in box_key]
        self.box = (max(x0, 0), max(y0, 0), min(x1, W), min(y1, H))
        x0, y0, x1, y1 = self.box
        gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
        self.gx, self.gy = gx, gy
        self.bones = {}
        for k, b in bones.items():
            self.bones[k] = {"w": b["w"][y0:y1, x0:x1].astype(np.float32),
                             "pivot": np.float32(b.get("pivot", (0, 0))) * SC}

    def field(self, pose):
        DX = np.zeros_like(self.gx)
        DY = np.zeros_like(self.gy)
        for k, p in pose.items():
            if k not in self.bones:
                continue
            ang, dx, dy = (tuple(p) + (0.0, 0.0, 0.0))[:3]
            b = self.bones[k]
            w = b["w"]
            if abs(ang) > 1e-4:
                a = math.radians(ang)
                ca, sa = math.cos(a), math.sin(a)
                px, py = b["pivot"]
                ux, uy = self.gx - px, self.gy - py
                ddx = ux * ca - uy * sa - ux + dx
                ddy = ux * sa + uy * ca - uy + dy
            else:
                ddx, ddy = dx, dy
            DX += w * ddx
            DY += w * ddy
        return DX, DY

    def warp(self, arrays, pose):
        """arrays: list of full-plane arrays (HxW or HxWxC). Returns warped copies."""
        x0, y0, x1, y1 = self.box
        DX, DY = self.field(pose)
        lx, ly = self.gx - x0, self.gy - y0
        sx, sy = lx - DX, ly - DY
        for _ in range(2):                                    # fixed-point inverse of p = q + d(q)
            DXs = cv2.remap(DX, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            DYs = cv2.remap(DY, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            sx, sy = lx - DXs, ly - DYs
        out = []
        for arr in arrays:
            o = arr.copy()
            o[y0:y1, x0:x1] = cv2.remap(np.ascontiguousarray(arr[y0:y1, x0:x1]), sx, sy, cv2.INTER_LINEAR,
                                        borderMode=cv2.BORDER_REPLICATE)
            out.append(o)
        return out

    def point(self, name_pose, p_key, pose):
        """Where a key-px point goes under the pose (forward map, for attaching FX)."""
        x0, y0, _, _ = self.box
        DX, DY = self.field(pose)
        x, y = p_key[0] * SC, p_key[1] * SC
        ix, iy = int(np.clip(x - x0, 0, DX.shape[1] - 1)), int(np.clip(y - y0, 0, DX.shape[0] - 1))
        return x + DX[iy, ix], y + DY[iy, ix]


def keys_at(keys, x):
    """Piecewise-linear lookup in [(x, v), ...] with smooth (cosine) easing between keys."""
    if x <= keys[0][0]:
        return keys[0][1]
    for (a, va), (b, vb) in zip(keys, keys[1:]):
        if x <= b:
            u = (x - a) / (b - a) if b > a else 1.0
            u = 0.5 - 0.5 * math.cos(math.pi * u)
            return va + (vb - va) * u
    return keys[-1][1]


# ------------------------------------------------------------------ flames
def tongue_pts(base, h, w, lean, phase, n=22, curl=0.0):
    """A flame lick: the centre line rises from base with an S-sway that grows toward the tip and a
    curl at the end; the body bulges low (teardrop) and draws out to a fine whipping point."""
    bx, by = base
    c = []
    for i in range(n + 1):
        s = i / n
        cx = bx + lean * s * s + math.sin(phase + 4.2 * s) * w * 0.55 * s ** 1.3 + curl * s ** 3
        cy = by - h * s
        c.append((cx, cy))
    c = np.float32(c)
    d = np.gradient(c, axis=0)
    d /= np.linalg.norm(d, axis=1, keepdims=True) + 1e-6
    nrm = np.stack([-d[:, 1], d[:, 0]], 1)
    s = np.linspace(0, 1, n + 1, dtype=np.float32)
    prof = np.clip(np.sin(np.pi * np.clip(s * 0.88 + 0.12, 0, 1)), 0, 1) ** 0.6 * np.clip(1 - s, 0, 1) ** 0.55
    prof *= 1 + 0.18 * np.sin(phase * 1.7 + 9 * s)
    hw = (w * 0.5 * prof)[:, None]
    left = c - nrm * hw
    right = c + nrm * hw
    return np.concatenate([left, right[::-1]]).astype(np.float32)


class FlameCanvas:
    """Accumulates flame tongues (three nested value masks) in a local box, at 2x for AA."""

    def __init__(self, w, h, ss=2):
        self.w, self.h, self.ss = int(w), int(h), ss
        self.m = [np.zeros((self.h * ss, self.w * ss), np.uint8) for _ in range(3)]

    def tongue(self, base, h, w, lean=0.0, phase=0.0, curl=0.0, value=255, fork=0.0, layers=(0, 1, 2)):
        """One lick (outer, mid and core nested); fork > 0 splits a second, thinner tip off the side."""
        spec = [(1.0, 1.0), (0.74, 0.58), (0.46, 0.30)]
        for k in layers:
            fh, fw = spec[k]
            b = (base[0], base[1] + h * 0.03 * k)
            pts = tongue_pts(b, h * fh, w * fw, lean * fh, phase + 0.35 * k, curl=curl * fh)
            cv2.fillPoly(self.m[k], [np.round(pts * self.ss * 8).astype(np.int32)], value, cv2.LINE_AA, shift=3)
            if fork and k < 2:
                c = tongue_pts(b, h * fh, w * fw, lean * fh, phase + 0.35 * k, curl=curl * fh)
                n = len(c) // 2
                mid = (c[int(n * 0.45)] + c[len(c) - 1 - int(n * 0.45)]) / 2
                p2 = tongue_pts(tuple(mid), h * fh * 0.55 * fork, w * fw * 0.45, fork * w * 0.9, phase + 2.0,
                                curl=-curl * 0.5)
                cv2.fillPoly(self.m[k], [np.round(p2 * self.ss * 8).astype(np.int32)], value, cv2.LINE_AA, shift=3)

    def blob(self, c, r, k=0, value=255):
        cv2.circle(self.m[k], (int(c[0] * self.ss * 8), int(c[1] * self.ss * 8)), int(r * self.ss * 8), value, -1,
                   cv2.LINE_AA, shift=3)

    def masks(self, streak=None, rough=0.25):
        out = []
        for k, m in enumerate(self.m):
            a = cv2.resize(m.astype(np.float32) / 255, (self.w, self.h), interpolation=cv2.INTER_AREA)
            if streak is not None:
                s = streak[:self.h, :self.w]
                soft = cv2.GaussianBlur(a, (0, 0), 1.4)
                a = np.clip((soft - 0.5 + s * rough) * 2.6 + 0.5, 0, 1) * np.clip(a * 3, 0, 1)
            out.append(a)
        return out


FIRE_OUTER = np.float32([0.86, 0.22, 0.07])
FIRE_MID = np.float32([1.0, 0.52, 0.12])
FIRE_CORE = np.float32([1.0, 0.92, 0.62])


def paint_fire(dst, masks, x0, y0, opacity=1.0, glow=0.5, outer=FIRE_OUTER, mid=FIRE_MID, core=FIRE_CORE):
    """Lay the flame masks into dst (float RGB) at (x0, y0): opaque-ish paint layers, then a soft
    emissive bloom from the core so the flames light what is around them."""
    mo, mm, mc = masks
    h, w = mo.shape
    H, W = dst.shape[:2]
    xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x0 + w, W), min(y0 + h, H)
    if xb <= xa or yb <= ya:
        return dst
    sl = (slice(ya - y0, yb - y0), slice(xa - x0, xb - x0))
    reg = dst[ya:yb, xa:xb]
    for m, col, op in ((mo, outer, 0.82), (mm, mid, 0.92), (mc, core, 1.0)):
        a = (m[sl] * op * opacity)[..., None]
        reg = reg * (1 - a) + col * a
    if glow:
        g = cv2.GaussianBlur(mm, (0, 0), 10) * 0.7 + cv2.GaussianBlur(mc, (0, 0), 26) * 0.6
        g = np.clip(g[sl] * glow * opacity, 0, 1)[..., None]
        reg = 1 - (1 - reg) * (1 - g * np.float32([1.0, 0.55, 0.2]))
    dst[ya:yb, xa:xb] = reg
    return dst


# ------------------------------------------------------------------ patches
def affine_patch(rgba, angle=0.0, sx=1.0, sy=1.0, pad=None):
    """Rotate by angle (deg, clockwise on screen) and scale x/y (in the patch's own frame).
    Returns (patch, cx, cy): cx, cy = where the source centre lands inside the new patch."""
    h, w = rgba.shape[:2]
    pad = int(max(h, w) * max(abs(sx), abs(sy), 1.0) * 0.75) if pad is None else pad
    a = math.radians(angle)
    ca, sa = math.cos(a), math.sin(a)
    M = np.float32([[ca * sx, -sa * sy, 0], [sa * sx, ca * sy, 0]])
    c = np.float32([w / 2, h / 2])
    out_c = np.float32([pad, pad])
    M[:, 2] = out_c - M[:, :2] @ c
    out = cv2.warpAffine(rgba, M, (2 * pad, 2 * pad), flags=cv2.INTER_LINEAR, borderValue=0)
    return out, pad, pad


def over_center(dst_rgb, rgba, cx, cy, ccx, ccy, opacity=1.0, dst_a=None):
    """Alpha-over a patch so that its point (ccx, ccy) lands at (cx, cy)."""
    x, y = int(round(cx - ccx)), int(round(cy - ccy))
    h, w = rgba.shape[:2]
    H, W = dst_rgb.shape[:2]
    xa, ya, xb, yb = max(x, 0), max(y, 0), min(x + w, W), min(y + h, H)
    if xb <= xa or yb <= ya:
        return
    p = rgba[ya - y:yb - y, xa - x:xb - x]
    a = p[..., 3:4] * opacity
    dst_rgb[ya:yb, xa:xb] = dst_rgb[ya:yb, xa:xb] * (1 - a) + p[..., :3] * a
    if dst_a is not None:
        dst_a[ya:yb, xa:xb] = dst_a[ya:yb, xa:xb] * (1 - a[..., 0]) + a[..., 0]


def burn_patch(rgba, b, seed=0, side=(1.0, -0.3)):
    """Paper burning: b in 0..1 = how far the burn front has crossed the patch from `side`.
    Returns (rgba, glow mask) where glow marks the burning edge (emissive)."""
    h, w = rgba.shape[:2]
    if b <= 0:
        return rgba, np.zeros((h, w), np.float32)
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    d = np.float32(side) / (np.linalg.norm(side) + 1e-6)
    u = ((gx / w - 0.5) * d[0] + (gy / h - 0.5) * d[1]) + 0.5            # 0 far side .. 1 burning side
    n = brush_noise((h, w), seed, scale=max(3.0, w / 7), angle=0.4, stretch=1.5) * 0.07
    front = u + n - (1.05 - 1.25 * b)                                     # > 0: burnt
    out = rgba.copy()
    gone = np.clip(front / 0.03, 0, 1)
    char = np.clip(1 - np.abs(front + 0.07) / 0.09, 0, 1)
    edge = np.clip(1 - np.abs(front + 0.005) / 0.045, 0, 1)
    edge = cv2.GaussianBlur(edge, (0, 0), max(0.8, w / 90))
    out[..., :3] = out[..., :3] * (1 - 0.8 * char[..., None]) + np.float32([0.10, 0.04, 0.06]) * 0.8 * char[..., None]
    out[..., 3] = out[..., 3] * (1 - gone)
    glow = edge * (rgba[..., 3] > 0.3)
    return out, glow.astype(np.float32)


# ------------------------------------------------------------------ embers from a source
class SourceEmbers:
    """Embers born at points inside a source box (working px) at a steady rate plus bursts; each
    rises with drift and wobble for its life. Positions are analytic in frame time (posed on 2s)."""

    def __init__(self, box, nearness, rate=6.0, life=(14, 30), seed=3, vel=((-40, 30), (-120, -60)), bursts=(),
                 burst_n=14, burst_box=None):
        rng = np.random.default_rng(seed)
        x0, y0, x1, y1 = box
        self.items = []
        n_total = 600
        for i in range(n_total):
            born = i * (24.0 / rate) - 40                      # frames; some already airborne at the cut
            self.items.append(self._make(rng, (x0, y0, x1, y1), born, life, vel, nearness))
        for fb in bursts:
            bb = burst_box or box
            for _ in range(burst_n):
                it = self._make(rng, bb, fb + rng.uniform(0, 3), life, ((-160, 160), (-260, -60)), nearness)
                it["size"] *= 1.3
                self.items.append(it)

    @staticmethod
    def _make(rng, box, born, life, vel, nearness):
        x0, y0, x1, y1 = box
        return {"p": np.float32([rng.uniform(x0, x1), rng.uniform(y0, y1)]), "born": born,
                "life": rng.uniform(*life), "v": np.float32([rng.uniform(*vel[0]), rng.uniform(*vel[1])]),
                "size": rng.uniform(0.7, 1.4), "ph": rng.uniform(0, 6.28), "n": nearness, "wob": rng.uniform(0.6, 1.6)}

    def draw(self, cam, lf_held, t_cam, dst, intensity=1.0, warm=(1.0, 0.42, 0.12), core=(1.0, 0.8, 0.5), frame_start=0):
        sc = ShapeCanvas(dst.shape[1], dst.shape[0])
        any_ = False
        for it in self.items:
            age = lf_held - it["born"]
            if age < 0 or age > it["life"]:
                continue
            tt = age / 24.0
            p = it["p"] + it["v"] * tt + np.float32([math.sin(tt * 6 * it["wob"] + it["ph"]) * 10, 0])
            v = it["v"] + np.float32([math.cos(tt * 6 * it["wob"] + it["ph"]) * 60, 0])
            q = cam.screen_point(p, it["n"], t_cam)
            fade = min(1.0, age / 3.0) * (1 - (age / it["life"]) ** 2)
            flick = 0.6 + 0.4 * math.sin(lf_held * 1.3 + it["ph"] * 3)
            s = it["size"] * cam.scale_at(it["n"], t_cam)
            val = int(255 * np.clip(fade * flick, 0, 1))
            if val < 30:
                continue
            sc.fill(tapered_streak_poly(q, v, 10 * s, 3.2 * s), value=val)
            any_ = True
        if not any_:
            return dst
        c, g = sc.result(glow_sigma=3)
        return screen_emissive(dst, c * 0.95, g * 0.9, np.asarray(core) * intensity, np.asarray(warm) * intensity)


# ------------------------------------------------------------------ sounds
SR = A.SR


def _n(d):
    return int(round(d * SR))


def fire_roar(dur, seed=31):
    """Fireplace bed: low rumble, mid 'breath' noise with slow surges, and sparse crackle pops."""
    rng = np.random.default_rng(seed)
    t = A.t_axis(dur)
    rumble = A.lowpass(A.noise(dur, seed, "brown"), 140) * 0.9
    surge = 0.6 + 0.4 * A.lowpass(rng.standard_normal(len(t)), 1.5) * 8
    breath = A.bandpass(A.noise(dur, seed + 1, "pink"), 250, 1800) * np.clip(surge, 0.2, 1.4) * 0.5
    crack = np.zeros(len(t))
    for _ in range(int(dur * 14)):
        i = rng.integers(0, len(t) - 2000)
        crack[i:i + 1] += rng.uniform(-1, 1) * rng.uniform(0.4, 1.0)
    crack = A.bandpass(crack, 1500, 7000) * 3.0 + A.bandpass(crack, 400, 1500) * 1.5
    x = rumble + breath + crack * 0.45
    return x / (np.abs(x).max() + 1e-9)


def whump(seed=32, big=1.0):
    """Fire catching a load: low thump, a rushing noise swell and a crackly tail."""
    d = 1.1 + 0.4 * big
    n = _n(d)
    f = np.linspace(70, 34, n)
    body = A.osc(f, d) * A.exp_decay(n, 0.12 * (1 + 0.3 * big))
    rush = A.bandpass(A.noise(d, seed, "pink"), 180, 2600) * (A.env_adsr(n, 0.02, 0.15, 0.5, 0.7)) * A.exp_decay(n, 0.45 * big)
    rng = np.random.default_rng(seed)
    crack = np.zeros(n)
    for _ in range(int(30 * big)):
        i = int(rng.uniform(0.03, 0.8) * n)
        crack[i] += rng.uniform(-1, 1)
    crack = A.bandpass(crack, 1800, 8000) * 2.5 * A.exp_decay(n, 0.5)
    x = body * 1.1 + rush * 1.6 + crack * 0.5
    return x / (np.abs(x).max() + 1e-9)


def scrape(seed=33, dur=0.32):
    """Shovel blade dragging over cash/metal: band noise with a gritty AM."""
    n = _n(dur)
    rng = np.random.default_rng(seed)
    x = A.bandpass(A.noise(dur, seed, "white"), 900, 5200)
    grit = np.clip(A.lowpass(rng.standard_normal(n), 60) * 6, 0, None)
    e = np.sin(np.linspace(0, np.pi, n)) ** 1.5
    return x * (0.4 + grit) * e


def paper_flutter(seed=34, dur=0.45):
    """Banknotes fluttering: fast irregular flaps of crisp band noise."""
    n = _n(dur)
    rng = np.random.default_rng(seed)
    flaps = np.zeros(n)
    t = 0.0
    while t < dur * 0.9:
        i = _n(t)
        L = _n(rng.uniform(0.012, 0.03))
        flaps[i:i + L] += np.hanning(L)[: len(flaps[i:i + L])] * rng.uniform(0.5, 1.0)
        t += rng.uniform(0.025, 0.06)
    x = A.bandpass(A.noise(dur, seed + 1), 1800, 9000) * flaps
    return x * np.linspace(1, 0.4, n)


def register_ching(seed=35):
    """Cash-register hit: drawer clunk, a bright two-bell ching and a small coin rattle."""
    d = 1.4
    n = _n(d)
    clunk = A.thunk(seed) * 0.8
    bell = A.bell(2093.0, 1.25) * 0.6 + A.bell(2637.0, 1.25) * 0.5
    bell = np.pad(np.concatenate([np.zeros(_n(0.03)), bell]), (0, n))[:n]
    rng = np.random.default_rng(seed)
    rat = np.zeros(n)
    for _ in range(10):
        i = int(rng.uniform(0.05, 0.35) * SR)
        rat[i] += rng.uniform(-1, 1)
    rat = A.bandpass(rat, 3000, 9000) * 2
    out = np.zeros(n)
    out[: len(clunk)] += clunk
    out += bell + rat * 0.4
    return out / (np.abs(out).max() + 1e-9)


def glitch(seed=36, dur=0.16):
    """Video-call freeze: a bit-crushed buzz burst with stutters."""
    n = _n(dur)
    rng = np.random.default_rng(seed)
    f = rng.uniform(300, 900)
    x = np.sign(A.osc(f, dur, "saw")) * 0.5 + A.bandpass(A.noise(dur, seed), 1500, 6000) * 0.6
    steps = np.repeat(rng.uniform(-1, 1, n // 400 + 1), 400)[:n]
    x = np.round((x + steps * 0.3) * 4) / 4
    gate = np.repeat((rng.random(n // 1200 + 1) > 0.3).astype(float), 1200)[:n]
    return x * gate * A.env_adsr(n, 0.002, 0.03, 0.7, dur * 0.3)


def shatter(seed=37, dur=1.6):
    """Glass/screen shatter: a sharp crack, a bright noise burst and many tinkling shards."""
    n = _n(dur)
    rng = np.random.default_rng(seed)
    crack = A.bandpass(A.noise(dur, seed), 1200, 12000) * A.exp_decay(n, 0.05) * 1.4
    body = A.osc(np.linspace(140, 60, n), dur) * A.exp_decay(n, 0.08) * 0.8
    tink = np.zeros(n)
    for _ in range(60):
        i = int(rng.uniform(0.01, 0.9) * n * rng.uniform(0.3, 1.0))
        L = _n(rng.uniform(0.05, 0.25))
        fr = rng.uniform(2500, 7500)
        seg = A.osc(fr, L / SR) * A.exp_decay(L, rng.uniform(0.01, 0.05)) * rng.uniform(0.2, 0.7)
        tink[i:i + L] += seg[: len(tink[i:i + L])]
    x = crack + body + tink * 0.6
    return x / (np.abs(x).max() + 1e-9)


def crack_tick(seed=38):
    """A single hairline crack: tiny sharp click with a glassy ring."""
    n = _n(0.12)
    x = A.bandpass(A.noise(0.12, seed), 3000, 11000) * A.exp_decay(n, 0.006)
    x += A.osc(5200 + seed % 7 * 300, 0.12) * A.exp_decay(n, 0.02) * 0.3
    return x


def footstep(seed=39, soft=True):
    """Slipper on asphalt: a soft low scuff."""
    n = _n(0.22)
    x = A.lowpass(A.bandpass(A.noise(0.22, seed, "pink"), 120, 2200), 1600)
    e = A.env_adsr(n, 0.006, 0.05, 0.35, 0.12)
    thud = A.osc(np.linspace(110, 60, n), 0.22) * A.exp_decay(n, 0.03) * 0.5
    return x * e + thud


def horn(seed=40, dur=0.7, f=330.0):
    """A distant car horn (two detuned square-ish tones, band-limited, far away)."""
    n = _n(dur)
    x = np.tanh(3 * (A.osc(f, dur) + 0.8 * A.osc(f * 1.26, dur)))
    x = A.bandpass(x, 300, 2400) * A.env_adsr(n, 0.02, 0.05, 0.9, 0.12)
    return A.lowpass(x, 1800)


def traffic_rumble(dur, seed=41):
    """Idling gridlock: engine idle beat, low rumble, faint far horns of the city."""
    t = A.t_axis(dur)
    idle = A.lowpass(A.noise(dur, seed, "brown"), 90) * (0.75 + 0.25 * np.sin(2 * np.pi * 11 * t) ** 2)
    hum = A.bandpass(A.noise(dur, seed + 1, "pink"), 120, 600) * 0.35
    x = idle + hum
    return x / (np.abs(x).max() + 1e-9)


# ------------------------------------------------------------------ second painted pose (pose B)
def align_affine(key_rgb, other_rgb, width=380):
    """Affine that maps the other painting onto the key (ECC on small greyscale copies), full-res 2x3."""
    H, W = key_rgb.shape[:2]
    h = round(H * width / W)
    g1 = cv2.cvtColor(cv2.resize(key_rgb, (width, h), interpolation=cv2.INTER_AREA), cv2.COLOR_RGB2GRAY).astype(np.float32)
    g2 = cv2.cvtColor(cv2.resize(other_rgb, (width, h), interpolation=cv2.INTER_AREA), cv2.COLOR_RGB2GRAY).astype(np.float32)
    M = np.eye(2, 3, dtype=np.float32)
    try:
        _, M = cv2.findTransformECC(g1, g2, M, cv2.MOTION_AFFINE,
                                    (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-6), None, 5)
    except cv2.error:
        M = np.eye(2, 3, dtype=np.float32)
    M = M.copy()
    M[:, 2] *= W / width
    return M                                    # other(x') = M @ key(x): sample other at M x


def pose_b_composite(key_path, pose_path, out_path, region_key, thresh=0.10, grow=25, feather=12, extra_key=(),
                     close=41, min_area=4000):
    """Write the key with the hero region taken from pose B (aligned to the key) and return the soft hero
    mask (key px). The mask is where the two paintings differ, inside region_key, grown and feathered,
    plus any extra polygons; outside it the key is untouched, so the background never pops."""
    from pathlib import Path
    out_path = Path(out_path)
    key = cv2.cvtColor(cv2.imread(str(key_path)), cv2.COLOR_BGR2RGB)
    H, W = key.shape[:2]
    pb = cv2.cvtColor(cv2.imread(str(pose_path)), cv2.COLOR_BGR2RGB)
    pb = cv2.resize(pb, (W, H), interpolation=cv2.INTER_CUBIC)
    M = align_affine(key, pb)
    pb = cv2.warpAffine(pb, M, (W, H), flags=cv2.INTER_CUBIC | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REFLECT)
    k = cv2.GaussianBlur(key.astype(np.float32) / 255, (0, 0), 3)
    b = cv2.GaussianBlur(pb.astype(np.float32) / 255, (0, 0), 3)
    d = np.abs(k - b).max(2)
    m = (d > thresh).astype(np.uint8)
    reg = np.zeros((H, W), np.uint8)
    cv2.fillPoly(reg, [np.int32(region_key)], 1)
    m = m & reg
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close, close)))
    m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * grow + 1, 2 * grow + 1)))
    cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)       # no holes in a body
    m = np.zeros_like(m)
    cv2.drawContours(m, [c for c in cs if cv2.contourArea(c) > min_area], -1, 1, -1)
    for poly in extra_key:
        cv2.fillPoly(m, [np.int32(poly)], 1)
    m = m & cv2.dilate(reg, np.ones((15, 15), np.uint8))
    ms = cv2.GaussianBlur(m.astype(np.float32), (0, 0), feather)
    if not out_path.exists():
        out_path.parent.mkdir(parents=True, exist_ok=True)
        comp = key.astype(np.float32) * (1 - ms[..., None]) + pb.astype(np.float32) * ms[..., None]
        cv2.imwrite(str(out_path), cv2.cvtColor(np.clip(comp + 0.5, 0, 255).astype(np.uint8), cv2.COLOR_RGB2BGR))
    return ms


def mask_polygon(mask, level=0.3, eps=6.0):
    """Outline (key px list) of the largest region of a soft mask, for a PlaneSpec region."""
    cs, _ = cv2.findContours((mask > level).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    c = max(cs, key=cv2.contourArea)
    c = cv2.approxPolyDP(c, eps, True)
    return [(float(x), float(y)) for x, y in c[:, 0]]


def smear_between(img_from, img_to, mask, vec, copies=2, seed=0):
    """One drawn smear drawing between two held poses (output px): the new pose stretched back toward the
    old one (its trailing side drags along the motion), one faint drawn multiple of the old pose, and
    torn dry-brush streaks only on the stretched figure."""
    H, W = mask.shape
    m = np.clip(mask, 0, 1)
    ys, xs = np.where(m > 0.3)
    if len(xs) == 0:
        return img_to
    vx, vy = vec
    L2 = math.hypot(vx, vy) + 1e-6
    ux, uy = vx / L2, vy / L2
    gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
    proj = gx * ux + gy * uy
    pv = xs * ux + ys * uy
    lo, hi = float(np.percentile(pv, 2)), float(np.percentile(pv, 98))
    g = np.clip((proj - lo) / max(hi - lo, 1.0), 0, 1)               # 0 trailing .. 1 leading
    ms = cv2.GaussianBlur(m, (0, 0), 6)
    k = ms * (1 - g) ** 1.3 * 0.75
    out = cv2.remap(img_to, gx + vx * k, gy + vy * k, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    km = cv2.remap(m, gx + vx * k, gy + vy * k, cv2.INTER_LINEAR)[..., None]
    out = out * (1 - (1 - km) * ms[..., None] * 0.0) 
    out = out * (1 - m[..., None] * 0.18) + img_from * m[..., None] * 0.18
    ang = math.atan2(vy, vx)
    n = brush_noise((H // 4, W // 4), seed, scale=2.0, angle=ang, stretch=14)
    n = cv2.resize(n, (W, H))[..., None]
    return np.clip(out * (1 + 0.07 * n * km), 0, 1)


def pose_mix(img_a, img_b, mask):
    """Pose B only inside the hero mask (output px); everything outside is pose A's frame, so the set holds."""
    m = np.clip(mask, 0, 1)[..., None]
    return img_a * (1 - m) + img_b * m


def mesh_inbetween(img_a, img_b, mask, t=0.5, scale=0.5, margin=48, mix=None):
    """A true in-between of two held poses (output px): dense flow A<->B inside the hero mask (DIS, CPU),
    both drawings warped part of the way toward each other and mixed, composited over pose A through
    the mask. I_t(x) = (1-t) A(x - t F_ab(x)) + t B(x - (1-t) F_ba(x))."""
    H, W = mask.shape
    ys, xs = np.where(mask > 0.05)
    if len(xs) == 0:
        return img_a
    x0, x1 = max(int(xs.min()) - margin, 0), min(int(xs.max()) + margin, W)
    y0, y1 = max(int(ys.min()) - margin, 0), min(int(ys.max()) + margin, H)
    A = img_a[y0:y1, x0:x1].astype(np.float32)
    B = img_b[y0:y1, x0:x1].astype(np.float32)
    h, w = A.shape[:2]
    sw, sh = max(int(w * scale), 8), max(int(h * scale), 8)
    g = lambda im: cv2.resize((np.clip(cv2.cvtColor(im, cv2.COLOR_RGB2GRAY), 0, 1) * 255).astype(np.uint8), (sw, sh),
                              interpolation=cv2.INTER_AREA)
    ga, gb = g(A), g(B)
    dis = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
    up = lambda fl: cv2.resize(fl, (w, h), interpolation=cv2.INTER_LINEAR) / scale
    f_ab, f_ba = up(dis.calc(ga, gb, None)), up(dis.calc(gb, ga, None))
    gy, gx = np.mgrid[0:h, 0:w].astype(np.float32)
    aw = cv2.remap(A, gx - t * f_ab[..., 0], gy - t * f_ab[..., 1], cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    bw = cv2.remap(B, gx - (1 - t) * f_ba[..., 0], gy - (1 - t) * f_ba[..., 1], cv2.INTER_LINEAR,
                   borderMode=cv2.BORDER_REFLECT)
    s = t if mix is None else mix                # mix 0/1: one painting carried halfway, no double image
    mid = aw * (1 - s) + bw * s
    out = img_a.copy()
    m = np.clip(mask[y0:y1, x0:x1], 0, 1)[..., None]
    out[y0:y1, x0:x1] = A * (1 - m) + mid * m
    return out


def _tps_map(src, dst, shape, step=8):
    """Thin-plate spline taking points `src` to `dst` (x, y), evaluated over an image of `shape` (H, W):
    returns map_x, map_y with dst = f(src) at every pixel (for cv2.remap with the grid as src)."""
    src = np.float64(src)
    dst = np.float64(dst)
    n = len(src)
    U = lambda r2: np.where(r2 > 0, r2 * np.log(np.maximum(r2, 1e-12)) * 0.5, 0.0)
    d2 = ((src[:, None, :] - src[None, :, :]) ** 2).sum(-1)
    Kx = U(d2)
    P = np.hstack([np.ones((n, 1)), src])
    L = np.zeros((n + 3, n + 3))
    L[:n, :n] = Kx + np.eye(n) * 1e-3
    L[:n, n:] = P
    L[n:, :n] = P.T
    Y = np.zeros((n + 3, 2))
    Y[:n] = dst
    coef = np.linalg.solve(L, Y)
    H, W = shape
    gy, gx = np.mgrid[0:H + step:step, 0:W + step:step].astype(np.float64)
    g = np.stack([gx.ravel(), gy.ravel()], 1)
    r2 = ((g[:, None, :] - src[None, :, :]) ** 2).sum(-1)
    out = U(r2) @ coef[:n] + coef[n] + g[:, :1] * coef[n + 1] + g[:, 1:] * coef[n + 2]
    mx = out[:, 0].reshape(gx.shape).astype(np.float32)
    my = out[:, 1].reshape(gx.shape).astype(np.float32)
    mx = cv2.resize(mx, (gx.shape[1] * step, gx.shape[0] * step), interpolation=cv2.INTER_LINEAR)[:H, :W]
    my = cv2.resize(my, (gx.shape[1] * step, gx.shape[0] * step), interpolation=cv2.INTER_LINEAR)[:H, :W]
    return mx, my


def landmark_inbetween(img_a, img_b, mask, pts_a, pts_b, t=0.5, margin=60, mix=None):
    """A true in-between drawing (output px) from matched landmarks of the two poses (head, hands,
    blade, hips, knees, feet): both paintings are mesh-warped (thin-plate spline) to the landmarks'
    halfway positions and mixed, inside the hero mask; outside the mask the frame is pose A's.
    `mix` is the share of pose B in the mix (default t)."""
    H, W = mask.shape
    ys, xs = np.where(mask > 0.05)
    if len(xs) == 0:
        return img_a
    x0, x1 = max(int(xs.min()) - margin, 0), min(int(xs.max()) + margin, W)
    y0, y1 = max(int(ys.min()) - margin, 0), min(int(ys.max()) + margin, H)
    pa = np.float32(pts_a) - (x0, y0)
    pb = np.float32(pts_b) - (x0, y0)
    pm = pa * (1 - t) + pb * t
    h, w = y1 - y0, x1 - x0
    anchors = [(0, 0), (w / 2, 0), (w, 0), (w, h / 2), (w, h), (w / 2, h), (0, h), (0, h / 2)]
    src = np.vstack([pm, anchors])
    A = img_a[y0:y1, x0:x1].astype(np.float32)
    B = img_b[y0:y1, x0:x1].astype(np.float32)
    ax, ay = _tps_map(src, np.vstack([pa, anchors]), (h, w))
    bx, by = _tps_map(src, np.vstack([pb, anchors]), (h, w))
    aw = cv2.remap(A, ax, ay, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    bw = cv2.remap(B, bx, by, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    s = t if mix is None else mix
    mid = aw * (1 - s) + bw * s
    # the mask of the in-between: both poses' masks carried along with their drawings
    m = np.clip(mask[y0:y1, x0:x1], 0, 1)
    out = img_a.copy()
    out[y0:y1, x0:x1] = A * (1 - m[..., None]) + mid * m[..., None]
    return out


def tps_warp_layers(arrs, pts_from, pts_to, alpha_index=1, margin=160):
    """Mesh-warp a layer (rgb, alpha, ... in the same px) so that landmarks at `pts_from` move to `pts_to`
    (thin-plate spline, edges of the working box pinned). Used for the in-between drawing: one painting
    carried halfway to the other pose, as a single solid figure."""
    a = arrs[alpha_index]
    H, W = a.shape[:2]
    ys, xs = np.where(a > 0.02)
    pf, pt = np.float32(pts_from), np.float32(pts_to)
    allx = np.concatenate([xs, pf[:, 0], pt[:, 0]])
    ally = np.concatenate([ys, pf[:, 1], pt[:, 1]])
    x0, x1 = max(int(allx.min()) - margin, 0), min(int(allx.max()) + margin, W)
    y0, y1 = max(int(ally.min()) - margin, 0), min(int(ally.max()) + margin, H)
    h, w = y1 - y0, x1 - x0
    anchors = [(0, 0), (w / 2, 0), (w, 0), (w, h / 2), (w, h), (w / 2, h), (0, h), (0, h / 2)]
    mx, my = _tps_map(np.vstack([pt - (x0, y0), anchors]), np.vstack([pf - (x0, y0), anchors]), (h, w))
    out = []
    for arr in arrs:
        o = arr.copy()
        o[y0:y1, x0:x1] = cv2.remap(np.ascontiguousarray(arr[y0:y1, x0:x1]), mx, my, cv2.INTER_LINEAR,
                                    borderMode=cv2.BORDER_REPLICATE)
        out.append(o)
    return out
