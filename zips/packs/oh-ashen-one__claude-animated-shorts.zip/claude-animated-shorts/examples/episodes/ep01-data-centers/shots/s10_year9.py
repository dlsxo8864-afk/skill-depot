"""Shot 10, Year 9: the market. "Your retirement would drop. Seven AI-heavy companies are a third of the S&P 500."

On "drop" the jar in the woman's hands cracks further, coins spill and the balance counter beside it dips.
On "Seven" magenta cracks race up the 7 pillars one after another (flash at each tip, painted rubble and dust
on 2s, a small weighted shake each). On "third" the gold chart line sags over the gap, snaps in the middle,
and its segments hinge and fall with streaked trails into the fog, pair by pair outward, while the gold light
on the plain and the pillar tops dies; the counter plummets and the jar spills.

Everything that moves is the key's own paint: the cracks are the key's painted cracks (removed from a clean
plate, then revealed), the line segments are cut from the key (the already-broken span is bridged with a
mirrored copy of its neighbour), the coins are the key's own falling coins.
Coordinates are key px of work/keys/y09_market_key.png (1520 x 2701); plane space = key px * 0.8.
Local helpers live in s09_year8_fx.py (shared with s09_year8)."""
import json
import math
from functools import cached_property
from pathlib import Path

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif.camera import ParallaxCamera
from whatif.config import FPS, safe_box
from whatif.fx2d import ShapeCanvas, screen_emissive, star4_poly, tapered_streak_poly, bolt_points
from whatif.shotkit import BaseShot
from whatif.timing import Track

from . import s09_year8_fx as FX
from . import s10_year9_poseb as PB

STEM = "s10_year9"
SC = L.WORK_SCALE
SRC_DIR = L.LAYER_CACHE / f"{STEM}_src"           # clean plate + cut-out paint (rebuilt when missing)

# ------------------------------------------------------------------ measured spec (key px)
# top edge of the gold chart line; the band below it (front face) is THICK(x) deep
LINE_TOP = [(-40, 1082), (0, 1056), (120, 979), (165, 997), (265, 925), (325, 944), (470, 832), (560, 862),
            (760, 747), (965, 876), (1115, 775), (1185, 795), (1330, 678), (1385, 692), (1520, 595), (1560, 568)]
BREAK_SPAN = 8                                    # span LINE_TOP[8] -> LINE_TOP[9] is broken in the key
SNAP_AT = 0.5                                     # where it snaps (fraction along that span)


def thick(x):
    return 48.0 + 24.0 * np.clip(np.asarray(x, np.float32) / 1520.0, 0, 1)


def line_y(x):
    xs, ys = zip(*LINE_TOP)
    return np.interp(x, xs, ys)


# pillars: crack region (x0, y0, x1, y1) and the top x where each pillar holds the line
PILLARS = [
    {"x": 140, "box": (40, 1060, 175, 1420)},
    {"x": 295, "box": (195, 1010, 345, 1330)},
    {"x": 515, "box": (420, 960, 575, 1380)},
    {"x": 740, "box": (610, 880, 800, 1400)},
    {"x": 960, "box": (850, 960, 1010, 1430)},
    {"x": 1150, "box": (1070, 1010, 1200, 1420)},
    {"x": 1360, "box": (1290, 930, 1450, 1450)},
]
GAP_POLY = [(790, 760), (930, 800), (905, 1000), (880, 1200), (872, 1560), (800, 1560), (800, 1200), (800, 980)]
DEBRIS_BOX = (700, 760, 1010, 1600)
AIR_COINS = [(788, 2114, 24), (771, 2166, 22), (823, 2232, 24)]   # x, y, radius of the coins mid-air in the key
JAR_MOUTH = (770, 2000)                         # where the coins leave the jar (its tilted rim, right side)
# matching features of the figure in pose B and pose A (key px) for the in-between mesh warp
ARM_B = [(270, 1530), (480, 1530), (660, 1610), (690, 1900), (600, 1960), (530, 1880), (500, 1720), (470, 1655),
         (290, 1650)]                             # pose B's raised arm (sleeve and hand), key px
FIG_B = [(260, 1780), (200, 1820), (380, 1590), (600, 1740), (500, 1980), (540, 2100), (460, 1860)]
FIG_A = [(340, 1720), (260, 1740), (620, 2060), (540, 2010), (680, 2000), (700, 2140), (460, 1860)]
FIG_ANCHORS = [(100, 2450), (400, 2450), (650, 2450), (0, 2700), (800, 2700), (0, 1450), (900, 1450), (1000, 2200)]
JAR_MOUTH_B = (598, 2085)                       # pose B: the jar clutched to her chest, coins slip out at her hand
POSEB_ENV = [(0, 1450), (880, 1450), (880, 2250), (700, 2480), (560, 2701), (0, 2701)]
POSEB_COINS = [(620, 2130, 30), (655, 2208, 30)]
JAR_POLY = [(575, 1925), (690, 1895), (800, 1935), (812, 2110), (700, 2140), (585, 2120)]
FOG_Y = (1470, 1640)                            # the fog band the falling pieces vanish into

DATA_TAG = "7 companies = about a third of the S&P 500"

# ------------------------------------------------------------------ planes / sprites
PLANES = [
    L.PlaneSpec("sky", 0.00, 0.05, fill="full"),
    L.PlaneSpec("pillars", 0.05, 0.125, radius=60),
    L.PlaneSpec("ground", 0.125, 0.45, radius=80),
    L.PlaneSpec("near", 0.45, 1.01, radius=80),
]
WOMAN_ENV = [(60, 1640), (170, 1560), (330, 1560), (420, 1700), (520, 1860), (600, 1870), (700, 1870),
             (830, 1910), (850, 2140), (720, 2240), (620, 2300), (620, 2700), (0, 2700), (0, 1900)]
SPRITES = [
    L.SpriteSpec("woman", 3, WOMAN_ENV, dmin=0.45, pivot=(330, 2600)),
]
# rig (key px): head/bun, shoulders, arms + jar; shawl fringe flutters on the lit edge
RIG = {
    "head": [(150, 1590), (330, 1570), (380, 1700), (360, 1810), (250, 1840), (120, 1760)],
    "neck": (300, 1810),
    "arms": [(380, 1900), (560, 1880), (830, 1900), (850, 2150), (600, 2280), (420, 2200)],
    "elbow": (430, 2050),
    "fringe": [(20, 1950), (120, 1830), (200, 1880), (130, 2150), (40, 2300), (0, 2300)],
    "waist": (330, 2450),
}


def nearness(d):
    return np.clip(d / 0.85, 0, 1) ** 0.75


# ------------------------------------------------------------------ clean plate and cut-out paint
def _band_mask(shape, x_from, x_to, pad_top=14, pad_bot=12, grow=0):
    """Polygon of the line band between x_from and x_to (key px), as float mask (grow: extra top pad
    toward the right, where the line is nearer and its glow wider)."""
    xs = np.linspace(x_from, x_to, max(int(abs(x_to - x_from) / 6), 2))
    top = [(x, float(line_y(x)) - pad_top - grow * max(x, 0) / 1520) for x in xs]
    bot = [(x, float(line_y(x) + thick(x)) + pad_bot) for x in xs[::-1]]
    return L.poly_mask(shape, top + bot)


def _magenta(k):
    r, g, b = k[..., 0], k[..., 1], k[..., 2]
    return (r > 0.5) & (b > 0.32) & (g < 0.36) & (r > g + 0.22)


def _gold(k):
    r, g, b = k[..., 0], k[..., 1], k[..., 2]
    return (r > 0.62) & (b < 0.45) & (r > b + 0.28)


def _unmix(k, f, glow=(1.0, 0.66, 0.32)):
    """Alpha and colour of a glow over a known background f, so that f*(1-a) + c*a == k."""
    G = np.float32(glow)
    gf = G - f
    a = np.clip(((k - f) * gf).sum(-1) / np.maximum((gf * gf).sum(-1), 1e-4), 0, 1)
    c = np.clip(f + (k - f) / np.maximum(a, 0.08)[..., None], 0, 1)
    return a, c


def row_reflect_fill(img, hole, fallback, solid):
    """Fill each horizontal run of `hole` by mirroring the paint on both sides into it (blended across the
    run), so a painted-out crack keeps the surrounding brushwork instead of a smooth smear. Sources must be
    `solid` and not hole; otherwise the `fallback` fill is used."""
    out = img.copy()
    H, W = hole.shape
    ok = solid & ~hole
    for y in np.nonzero(hole.any(1))[0]:
        row = hole[y]
        d = np.diff(np.concatenate([[0], row.astype(np.int8), [0]]))
        starts, ends = np.nonzero(d == 1)[0], np.nonzero(d == -1)[0]
        for a, b in zip(starts, ends):
            xs = np.arange(a, b)
            w = b - a
            lx = np.clip(2 * a - 1 - xs, 0, W - 1)
            rx = np.clip(2 * b - 1 - xs, 0, W - 1)
            lok, rok = ok[y, lx], ok[y, rx]
            t = ((xs - a + 0.5) / w)[:, None]
            L_, R_ = img[y, lx], img[y, rx]
            fb = fallback[y, xs]
            L_ = np.where(lok[:, None], L_, np.where(rok[:, None], R_, fb))
            R_ = np.where(rok[:, None], R_, np.where(lok[:, None], L_, fb))
            out[y, xs] = L_ * (1 - t) + R_ * t
    return out


def prep(key_path, depth_path):
    """Build (once) the clean plate and the cut-out paint layers, in key px."""
    SRC_DIR.mkdir(parents=True, exist_ok=True)
    done = SRC_DIR / "done.json"
    if done.exists():
        return
    bgr = cv2.imread(str(key_path))
    k = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    H, W = k.shape[:2]
    dep = cv2.resize(cv2.imread(str(depth_path), -1).astype(np.float32) / 65535, (W, H), interpolation=cv2.INTER_LINEAR)
    gy, gx = np.mgrid[0:H, 0:W]
    r_, g_, b_ = k[..., 0], k[..., 1], k[..., 2]
    below_band = gy > line_y(gx) + thick(gx) + 30

    # 1. cracks: the magenta paint on the pillars, its hot orange cores and its glow halo
    pil = np.zeros((H, W), bool)
    for p in PILLARS:
        x0, y0, x1, y1 = p["box"]
        pil[y0:y1, x0:x1] = True
    pil &= below_band
    crack = (_magenta(k) & pil).astype(np.uint8)
    crack = cv2.morphologyEx(crack, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
    near_c = cv2.dilate(crack, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))).astype(bool)
    warm = (r_ > b_ + 0.06) & (r_ > g_ + 0.12) & (r_ > 0.36)
    crack_hole = (cv2.dilate(crack, np.ones((3, 3), np.uint8)).astype(bool) | (near_c & warm & pil))
    crack_hole = cv2.dilate(crack_hole.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
    wide = cv2.dilate(crack, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))).astype(bool) & pil
    pink = (r_ > g_ + 0.16) & (r_ > 0.33)
    crack_hole |= wide & pink

    # 2. debris: in the gap anything that is not sky; in the sky between all pillars, the small dark chunks
    gap = L.poly_mask((H, W), GAP_POLY) > 0.5
    skyc = (b_ > r_ + 0.06) & (g_ < 0.33) & (b_ > 0.33)
    deb = gap & ~skyc
    x0, y0, x1, y1 = DEBRIS_BOX
    win = np.zeros((H, W), bool)
    win[y0:y1, x0:x1] = True
    deb |= win & _gold(k) & below_band
    zone = (gy > 880) & (gy < 1600)
    ns = (~(skyc & (dep < 0.05)) & zone).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(ns, 8)
    small = np.zeros(n, bool)
    small[1:] = stats[1:, cv2.CC_STAT_AREA] < 2500
    deb |= small[lab] & zone
    deb = cv2.dilate(deb.astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool)

    # 3. the coins in mid-air
    coins = np.zeros((H, W), np.uint8)
    for cx, cy, r in AIR_COINS:
        cv2.circle(coins, (cx, cy), r + 14, 1, -1)

    # --- clean plate (everything but the line band)
    hole = crack_hole | deb | (coins > 0)
    pp = L.textured_fill(k, (~hole).astype(np.float32), seed=91)
    # cracks: mirror the pillar's own paint across each crack (twice: rows, then columns of what is left)
    solid = dep > 0.055
    clean = row_reflect_fill(k, crack_hole, pp, solid)
    clean = np.where((deb | (coins > 0))[..., None], pp, clean)
    # a light smoothing only inside the old crack (the mirror seam), and no pink left anywhere near it
    sm = cv2.GaussianBlur(clean, (0, 0), 1.2)
    hm = cv2.GaussianBlur(crack_hole.astype(np.float32), (0, 0), 1.5)[..., None]
    clean = clean * (1 - 0.5 * hm) + sm * 0.5 * hm
    zone = cv2.dilate(crack, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (71, 71))).astype(np.float32)
    wz = cv2.GaussianBlur(zone, (0, 0), 12) * (dep > 0.055)
    # the cracks' glow lit the pillar paint around them (a soft magenta wash): take the low-frequency
    # difference to the unlit pillar paint away, keep the brushwork
    pil_ok = (dep > 0.055).astype(np.float32)
    blur = cv2.GaussianBlur(clean * pil_ok[..., None], (0, 0), 10) / np.maximum(cv2.GaussianBlur(pil_ok, (0, 0), 10), 1e-3)[..., None]
    base = L.push_pull_fill(blur, ((dep > 0.055) & (zone < 0.5)).astype(np.float32))
    base = cv2.GaussianBlur(base, (0, 0), 8)
    delta = np.clip(blur - base, 0, None) * np.float32([1.0, 0.0, 0.6])     # the wash added red and some blue
    clean = clean - delta * (0.9 * wz)[..., None]
    cr, cg = clean[..., 0], clean[..., 1]
    clean[..., 0] = cr - np.clip(cr - (cg + 0.085), 0, None) * wz
    # what is left of the wash is violet mottling: pull the hue of the pillar paint around the old cracks to
    # the pillars' own blue-grey (Lab a/b from the untouched pillar paint), keep its lightness and brushwork
    zc = cv2.dilate(crack, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (111, 111))).astype(np.float32)
    wc = np.clip(cv2.GaussianBlur(zc, (0, 0), 14) * 1.3, 0, 1) * (dep > 0.055)
    lab = cv2.cvtColor(np.clip(clean, 0, 1).astype(np.float32), cv2.COLOR_RGB2Lab)
    ok = ((dep > 0.055) & (zc < 0.5) & pil).astype(np.float32)
    ab = cv2.GaussianBlur(lab[..., 1:] * ok[..., None], (0, 0), 25) / np.maximum(cv2.GaussianBlur(ok, (0, 0), 25), 1e-3)[..., None]
    ab = L.push_pull_fill(ab, (cv2.GaussianBlur(ok, (0, 0), 25) > 0.05).astype(np.float32))
    ab = cv2.GaussianBlur(ab.astype(np.float32), (0, 0), 10)
    lab[..., 1:] = lab[..., 1:] * (1 - 0.85 * wc[..., None]) + ab * 0.85 * wc[..., None]
    clean = cv2.cvtColor(lab, cv2.COLOR_Lab2RGB)
    # the line band: sky behind, pillar columns end in a ragged broken stump just inside the band
    band_hole = _band_mask((H, W), -60, 1580, pad_top=30, pad_bot=26, grow=26) > 0.3
    band_hole |= gap & (gy < 1010)
    xs = np.arange(W)
    yb = (line_y(xs) + thick(xs) + 26).astype(int)
    probe = clean[np.clip(yb + 14, 0, H - 1), xs]
    pillar_col = np.array([dep[min(yb[x] + 12, H - 1), x] > 0.06 for x in xs])
    pillar_col &= ~((probe[:, 2] > probe[:, 0] + 0.06) & (probe[:, 1] < 0.33))
    pillar_col &= ~((xs > 790) & (xs < 905))
    pillar_col = cv2.morphologyEx(pillar_col.astype(np.uint8)[None], cv2.MORPH_OPEN, np.ones((1, 9), np.uint8))[0] > 0
    rng = np.random.default_rng(5)
    jag = np.cumsum(rng.normal(0, 3.5, W)).astype(np.float32)
    jag = cv2.GaussianBlur(jag[None], (0, 0), 2.0)[0]
    jag = jag - cv2.GaussianBlur(jag[None], (0, 0), 30)[0]
    carve = np.abs(jag) * 1.4 + 4 + 10 * ((xs // 17) % 3 == 0)        # broken, chipped tops
    stump = np.zeros((H, W), bool)
    for x in np.nonzero(pillar_col)[0]:
        stump[yb[x]:int(yb[x] + carve[x]), x] = True
    hole2 = band_hole | stump
    # sky behind the line: the line's glow halo goes with the line, so the sky within reach of it is
    # rebuilt from the sky further away
    dist = cv2.distanceTransform((~band_hole).astype(np.uint8), cv2.DIST_L2, 5)
    warm_sky = cv2.dilate(((r_ > b_ - 0.04) & (dep < 0.05) & (gy < 1000)).astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
    sky_zone = ((dist < 95) | warm_sky) & (dep < 0.05) & ~pil
    hole2 = hole2 | sky_zone
    valid = skyc & (dep < 0.045) & ~hole2 & (gy < 1300)
    sky_fill = L.textured_fill(k, valid.astype(np.float32), seed=93)
    plate_band = sky_fill
    band_hole = hole2
    # painted broken tops: a pale top face catching the sky, a dark shadow under it
    for x in np.nonzero(pillar_col)[0]:
        y0_ = int(yb[x] + carve[x])
        if y0_ + 10 >= H:
            continue
        clean[y0_:y0_ + 3, x] = clean[y0_:y0_ + 3, x] * 0.35 + np.float32([0.46, 0.40, 0.66]) * 0.65
        clean[y0_ + 3:y0_ + 9, x] = clean[y0_ + 3:y0_ + 9, x] * 0.55 + np.float32([0.07, 0.06, 0.15]) * 0.45
    soft = cv2.GaussianBlur(band_hole.astype(np.float32), (0, 0), 1.5)[..., None]
    clean = clean * (1 - soft) + plate_band * soft

    # --- cut-out paint
    crack_a = cv2.GaussianBlur(crack_hole.astype(np.float32), (0, 0), 1.0)
    cv2.imwrite(str(SRC_DIR / "crack.png"), (np.dstack([bgr, crack_a * 255])).astype(np.uint8))
    core = cv2.GaussianBlur(_band_mask((H, W), -60, 1580, pad_top=1, pad_bot=3), (0, 0), 1.0)
    ga, gc = _unmix(k, clean)
    ga = ga * band_hole
    la = np.maximum(core, ga)
    la[:, 776:950] = 0                       # the broken span is rebuilt from its mirrored neighbour
    lc = np.where(core[..., None] > ga[..., None], k, gc)
    lc_bgr = cv2.cvtColor((lc * 255 + 0.5).astype(np.uint8), cv2.COLOR_RGB2BGR)
    cv2.imwrite(str(SRC_DIR / "line.png"), np.dstack([lc_bgr, (la * 255 + 0.5).astype(np.uint8)]))
    for i, (cx, cy, r) in enumerate(AIR_COINS):
        R = r + 10
        c = bgr[cy - R:cy + R + 1, cx - R:cx + R + 1]
        kk = k[cy - R:cy + R + 1, cx - R:cx + R + 1]
        m = np.zeros(c.shape[:2], np.uint8)
        cv2.circle(m, (R, R), R - 1, 1, -1)
        m = (m > 0) & (kk[..., 0] > kk[..., 2] + 0.03)
        m = cv2.morphologyEx(m.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        cv2.imwrite(str(SRC_DIR / f"coin{i}.png"),
                    np.dstack([c, cv2.GaussianBlur(m.astype(np.float32), (0, 0), 0.8) * 255]).astype(np.uint8))
    cv2.imwrite(str(SRC_DIR / "clean.png"), cv2.cvtColor((np.clip(clean, 0, 1) * 255 + 0.5).astype(np.uint8),
                                                          cv2.COLOR_RGB2BGR))
    done.write_text(json.dumps({"ok": True}))


# ------------------------------------------------------------------ small helpers
def pose_into(dst_rgb, dst_a, rgba, x0, y0, angle=0.0, pivot=(0, 0), dx=0.0, dy=0.0, sx=1.0, sy=1.0):
    """Alpha-over a crop (at plane offset x0, y0) rotated by `angle` deg about `pivot` (plane px), scaled
    (sx, sy) about the pivot, then moved by (dx, dy). Only the destination bbox is warped."""
    h, w = rgba.shape[:2]
    a = math.radians(angle)
    ca, sa = math.cos(a), math.sin(a)
    px, py = pivot
    # forward p' = R S (p - P) + P + d
    Mlin = np.float32([[ca * sx, -sa * sy], [sa * sx, ca * sy]])
    t = np.float32([px + dx, py + dy]) - Mlin @ np.float32([px - x0, py - y0])
    corners = np.float32([[0, 0], [w, 0], [w, h], [0, h]]) @ Mlin.T + t
    H, W = dst_rgb.shape[:2]
    bx0, by0 = int(max(math.floor(corners[:, 0].min()) - 2, 0)), int(max(math.floor(corners[:, 1].min()) - 2, 0))
    bx1, by1 = int(min(math.ceil(corners[:, 0].max()) + 2, W)), int(min(math.ceil(corners[:, 1].max()) + 2, H))
    if bx1 <= bx0 or by1 <= by0:
        return
    M = np.hstack([Mlin, (t - np.float32([bx0, by0]))[:, None]]).astype(np.float32)
    out = cv2.warpAffine(rgba, M, (bx1 - bx0, by1 - by0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    FX.over_patch(dst_rgb, out, bx0, by0, dst_a)


def unlit(rgb):
    """The same paint with the gold light gone: darker, violet, a little desaturated."""
    lum = rgb.mean(-1, keepdims=True)
    return np.clip(lum * np.float32([0.45, 0.42, 0.75]) * 0.8 + rgb * 0.10, 0, 1)


def gold_weight(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    w = np.clip((r - b - 0.10) / 0.32, 0, 1) * np.clip((r - 0.30) / 0.30, 0, 1)
    return cv2.GaussianBlur(w.astype(np.float32), (0, 0), 2.0)


def ease_out(u):
    u = min(max(u, 0.0), 1.0)
    return 1 - (1 - u) ** 2


SPANS = list(range(1, 14))                       # span j joins LINE_TOP[j] -> LINE_TOP[j+1]


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        prep(key, depth)
        self.key_path, self.depth_path = key, depth
        L.build(STEM, SRC_DIR / "clean.png", depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        f = lambda w, n=0: ctx.f(w, n)
        self.f_your, self.f_ret, self.f_drop = f("Your"), f("retirement"), f("drop.")
        self.f_seven, self.f_comp = f("Seven"), f("companies")
        self.f_third, self.f_sp, self.f_500 = f("third"), f("S&P"), f("500.")
        self.crack_t = [self.f_seven + 4 * i for i in range(len(PILLARS))]
        self.f_smear, self.f_b = self.f_third + 2, self.f_third + 4   # held A, one in-between drawing, held B
        PB.build_pose_b(key, depth, SRC_DIR, "y09_market_poseB.png", POSEB_ENV, coin_holes=POSEB_COINS,
                        grow_a=15, feather_a=4.0)
        self.sag_t = self.f_third - 8
        # spans: hinge start per span (pairs outward from the break, 4 frames apart)
        self.hinge_t = {}
        for j in SPANS:
            dj = abs(j - BREAK_SPAN)
            self.hinge_t[j] = self.f_third if dj == 0 else self.f_third + 4 * dj
        t_of = lambda fr: (fr - self.f0) / FPS
        hits = [(t_of(self.f_drop + 2), 3.0, 9.0, 0.08, 0.06)]
        for i, tc in enumerate(self.crack_t):
            hits.append((t_of(tc), 3.0 + 0.9 * i, 9.5, 0.09, 0.08 + 0.02 * i))
        hits.append((t_of(self.f_third), 17.0, 6.0, 0.20, 0.65))
        for fr, j in self.span_landings:
            hits.append((t_of(fr), 4.5 + (3.5 if abs(j - BREAK_SPAN) <= 1 else 0.0), 5.5, 0.15, 0.25))
        self.shake = FX.Shake(hits, seed=9)
        foc = Track([(0, (W * 0.50, H * 0.530)), (t_of(self.f_seven), (W * 0.50, H * 0.505), "inout"),
                     (t_of(self.f_third), (W * 0.49, H * 0.495), "inout"), (d, (W * 0.47, H * 0.530), "inout")])
        self.cam = ParallaxCamera(
            W, H, focus=lambda t: tuple(float(a + b) for a, b in zip(foc(t), self.shake(t)[:2])), nearness=nearness,
            zoom=Track([(0, 1.07), (d, 1.15, "inout")]),
            push=Track([(0, 0.0), (d, 0.07, "inout")]),
            rise=Track([(0, 0.0), (d, -18.0, "inout")]),
            roll=lambda t: float(self.shake(t)[2]))

    @cached_property
    def tag_size(self):
        """Largest data-tag size whose right edge stays left of 86 % of the frame width."""
        x0 = O.tag_slots()["data"][0]
        for size in range(44, 30, -1):
            if x0 + O.data_tag(DATA_TAG, size=size).shape[1] <= 0.86 * 1080 - 8:
                return size
        return 30

    # ------------------------------------------------------------ cached paint
    @cached_property
    def planes(self):
        out = []
        for i, p in enumerate(self.lay.planes):
            rgb = p["rgb"].astype(np.float32) / 255
            pl = {"rgb": rgb, "a": p["a"].astype(np.float32) / 255, "n": nearness(p["d"].astype(np.float32) / 65535)}
            pl["gw"] = (gold_weight(rgb) * (0.6 if i == 3 else 1.0))[..., None]
            pl["un"] = unlit(rgb)
            out.append(pl)
        return out

    def _load_rgba(self, name):
        im = cv2.imread(str(SRC_DIR / name), -1)
        im = cv2.resize(im, None, fx=SC, fy=SC, interpolation=cv2.INTER_AREA)
        rgba = im.astype(np.float32) / 255
        rgba[..., :3] = rgba[..., 2::-1]
        return rgba

    @cached_property
    def woman(self):
        s = [x for x in self.lay.sprites if x["name"] == "woman"][0]
        rgba = s["rgba"].astype(np.float32) / 255
        x0, y0, x1, y1 = s["bbox"]
        shp = rgba.shape[:2]
        sc = lambda pts: [(x * SC, y * SC) for x, y in pts]
        gy = np.arange(shp[0], dtype=np.float32)[:, None] + y0
        wy = RIG["waist"][1] * SC
        body = np.clip((wy - gy) / (wy - 1600 * SC), 0, 1) ** 1.2 * np.ones(shp, np.float32)
        d = {"rgba": rgba, "x0": x0, "y0": y0,
             "w_body": body,
             "w_head": FX.poly_weight(shp, sc(RIG["head"]), 10, (x0, y0)),
             "w_arms": FX.poly_weight(shp, sc(RIG["arms"]), 12, (x0, y0)),
             "w_fringe": FX.poly_weight(shp, sc(RIG["fringe"]), 14, (x0, y0))}
        d["gw"] = gold_weight(rgba[..., :3])[..., None] * 0.6
        d["un"] = unlit(rgba[..., :3])
        return d

    @cached_property
    def cracks(self):
        """Per pillar: crop of the key's painted cracks (working px) and its pixel heights."""
        full = self._load_rgba("crack.png")
        out = []
        for p in PILLARS:
            x0, y0, x1, y1 = [int(v * SC) for v in p["box"]]
            c = full[y0:y1, x0:x1].copy()
            ys, xs = np.nonzero(c[..., 3] > 0.5)
            out.append({"rgba": c, "x0": x0, "y0": y0, "y1": y1, "pts": np.stack([xs + x0, ys + y0], 1) if len(xs) else None})
        return out

    @cached_property
    def spans(self):
        """Line span crops (working px), the broken span rebuilt from its mirrored neighbour."""
        line = cv2.imread(str(SRC_DIR / "line.png"), -1).astype(np.float32) / 255
        line[..., :3] = line[..., 2::-1].copy()
        Hk, Wk = line.shape[:2]
        # bridge: mirror span 7 (560 -> 760) about the peak onto 760 -> 965, small similarity fix
        A = np.float32(LINE_TOP[8])
        B = np.float32(LINE_TOP[7]) - A
        B[0] = -B[0]
        Bt = np.float32(LINE_TOP[9]) - A
        s_ = float(np.linalg.norm(Bt) / np.linalg.norm(B))
        th = math.atan2(Bt[1], Bt[0]) - math.atan2(B[1], B[0])
        R = np.float32([[math.cos(th), -math.sin(th)], [math.sin(th), math.cos(th)]]) * s_
        Mlin = R @ np.float32([[-1, 0], [0, 1]])
        src = line.copy()
        colm = np.zeros(Wk, np.float32)
        colm[LINE_TOP[7][0] + 2:LINE_TOP[8][0] + 30] = 1
        src[..., 3] *= colm[None]
        M = np.hstack([Mlin, (A - Mlin @ A)[:, None]]).astype(np.float32)
        bridge = cv2.warpAffine(src, M, (Wk, Hk), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
        out = {}
        for j in SPANS:
            xa = -60 if j == 1 else LINE_TOP[j][0]
            xb = 1580 if j == 13 else LINE_TOP[j + 1][0]
            colw = np.zeros(Wk + 200, np.float32)
            colw[max(xa, -100) + 100:xb + 100 + 1] = 1
            colw = cv2.GaussianBlur(colw[None], (0, 0), 1.2)[0][100:Wk + 100]
            srcl = bridge if j == BREAK_SPAN else line
            ytop = int(min(line_y(xa), line_y(xb)) - 130)
            ybot = int(max(line_y(xa) + thick(xa), line_y(xb) + thick(xb)) + 110)
            ytop, ybot = max(ytop, 0), min(ybot, Hk)
            xa_, xb_ = max(xa - 4, 0), min(xb + 5, Wk)
            crop = srcl[ytop:ybot, xa_:xb_].copy()
            crop[..., 3] *= colw[xa_:xb_][None]
            crop = cv2.resize(crop, None, fx=SC, fy=SC, interpolation=cv2.INTER_AREA)
            # sub-pieces for the break span: two halves, snapped in the middle
            out[j] = {"rgba": crop, "x0": int(round(xa_ * SC)), "y0": int(round(ytop * SC)),
                      "a": (max(xa, 0) * SC, float(line_y(max(xa, 0)) + thick(max(xa, 0)) * 0.5) * SC),
                      "b": (min(xb, 1520) * SC, float(line_y(min(xb, 1520)) + thick(min(xb, 1520)) * 0.5) * SC)}
        # split the break span
        sp = out[BREAK_SPAN]
        cw = sp["rgba"].shape[1]
        xm = (LINE_TOP[8][0] + SNAP_AT * (LINE_TOP[9][0] - LINE_TOP[8][0])) * SC - sp["x0"]
        gx = np.arange(cw, dtype=np.float32)
        jag = np.clip((gx - xm) / 2.0 + 0.5, 0, 1)
        left, right = sp["rgba"].copy(), sp["rgba"].copy()
        left[..., 3] *= (1 - jag)[None]
        right[..., 3] *= jag[None]
        xmk = LINE_TOP[8][0] + SNAP_AT * (LINE_TOP[9][0] - LINE_TOP[8][0])
        mid = (xmk * SC, float(line_y(xmk) + thick(xmk) * 0.5) * SC)
        out["8a"] = dict(sp, rgba=left, b=mid)
        out["8b"] = dict(sp, rgba=right, a=mid)
        self.snap_pt = mid
        return out

    @cached_property
    def coin_sprites(self):
        return [self._load_rgba(f"coin{i}.png") for i in range(len(AIR_COINS))]

    @cached_property
    def chunk_bank(self):
        """Painted rubble chunks (pillar stone with a magenta rim, and gold line shards)."""
        bank = {"stone": [], "gold": []}
        for i in range(10):
            r = 5 + (i * 7) % 10
            s = int(r * 3)
            m = FX.raster((s, s), [FX.chunk_poly((s / 2, s / 2), r, 0.0, seed=40 + i, sides=5)])
            bank["stone"].append(FX.paint_solid(m, (0.10, 0.09, 0.21), (0.26, 0.21, 0.42), (1.0, 0.32, 0.72), seed=40 + i))
            g = FX.paint_solid(m, (0.55, 0.26, 0.12), (1.0, 0.70, 0.32), (1.0, 0.93, 0.70), seed=60 + i)
            bank["gold"].append(g)
        return bank

    # ------------------------------------------------------------ timing tables
    def span_state(self, j, f):
        """(angle deg, pivot, dx, dy, alpha, dim, falling speed) of span j (int or '8a'/'8b') at frame f."""
        fh = f - f % 2
        jj = BREAK_SPAN if j in ("8a", "8b") else j
        sp = self.spans[j]
        left_side = (j == "8a") or (isinstance(j, int) and j < BREAK_SPAN)
        piv = sp["a"] if left_side else sp["b"]                 # the outer end is the hinge
        sgn = 1.0 if left_side else -1.0                        # the inner end drops
        t0 = self.hinge_t[jj]
        ang, dx, dy, alpha, dim, v = 0.0, 0.0, 0.0, 1.0, 0.0, 0.0
        if j in ("8a", "8b") and self.sag_t <= fh < t0:
            u = (fh - self.sag_t) / (t0 - self.sag_t)
            ang = sgn * (4.5 * u * u + 0.6 * ((fh // 2) % 2))   # sag, trembling on 2s
        if fh >= t0:
            dt = fh - t0
            hinge = 6 if j not in ("8a", "8b") else 4
            if dt <= hinge:
                u = dt / hinge
                ang = sgn * ((4.5 if j in ("8a", "8b") else -2.0) * (1 - u) + 30.0 * u * u)
                if j not in ("8a", "8b") and dt == 0:
                    ang = sgn * -2.5                            # anticipation: a small lift before it gives
            else:
                tf = dt - hinge
                g = 2.4
                ang = sgn * (30.0 + 3.2 * tf - 0.03 * tf * tf)
                dy = 0.5 * g * tf * tf + 2.0 * tf
                dx = -sgn * 1.4 * tf                            # pieces fall outward, away from the break
                v = g * tf + 2.0
                cy = piv[1] + dy
                alpha = float(np.clip(1 - (cy / SC - FOG_Y[0]) / (FOG_Y[1] - FOG_Y[0]), 0, 1))
            dim = float(np.clip(dt / 18.0, 0, 1))
        return ang, piv, dx, dy, alpha, dim, v

    def span_ids(self):
        return [j for j in SPANS if j != BREAK_SPAN] + ["8a", "8b"]

    @cached_property
    def span_landings(self):
        """(frame, span) when each falling piece hits the fog band (impact = dust, sub hit, shake)."""
        out = []
        for j in self.span_ids():
            for fr in range(self.f_third, self.f1 + 40, 2):
                ang, piv, dx, dy, a, dim, v = self.span_state(j, fr)
                if (piv[1] + dy) / SC >= FOG_Y[0] + 30:
                    out.append((fr, BREAK_SPAN if j in ("8a", "8b") else j))
                    break
        return out

    def light(self, f):
        """Remaining gold light (1 = the line all lit), with the snap's flash."""
        fh = f - f % 2
        ls = []
        for j in self.span_ids():
            ang, piv, dx, dy, a, dim, v = self.span_state(j, f)
            ls.append(a * (1 - 0.85 * dim))
        L_ = float(np.mean(ls))
        if fh == self.f_third:
            L_ += 0.7
        elif fh == self.f_third + 2:
            L_ += 0.3
        return L_

    @cached_property
    def coins(self):
        """Coin flights: start frame, start pos (working px), velocity, spin, landing y, sprite index."""
        rng = np.random.default_rng(12)
        fl = []
        # the three already falling in the key carry on from where they hang
        for i, (cx, cy, r) in enumerate(AIR_COINS):
            fl.append({"t0": self.f0 - self.f0 % 2 - 2 * (i + 1), "p": (cx * SC, cy * SC - 14 * (i + 1)),
                       "v": (0.9 + 0.2 * i, 2.0 + 0.5 * i), "spin": 0.45 + 0.1 * i, "phase": 0.6 * i,
                       "land": (2475 + 35 * i) * SC, "spr": i})
        starts = [self.f_drop + 2, self.f_drop + 6, self.f_drop + 10]
        starts += [self.f_b + 1 + 2 * k for k in range(10)]
        starts += [self.f_500 + 4 * k for k in range(3)]
        for k, t0 in enumerate(starts):
            mouth = JAR_MOUTH_B if t0 >= self.f_b else JAR_MOUTH
            fl.append({"t0": t0, "p": (mouth[0] * SC + rng.uniform(-6, 10), mouth[1] * SC + rng.uniform(-4, 8)),
                       "v": (rng.uniform(0.6, 2.4), rng.uniform(0.5, 2.0)), "spin": rng.uniform(0.35, 0.7),
                       "phase": rng.uniform(0, 3), "land": rng.uniform(2440, 2590) * SC, "spr": k % 3})
        return fl

    def coin_state(self, c, f):
        """(x, y, x-scale, lying, bounced) of a coin at frame f; None before it leaves."""
        fh = f - f % 2
        dt = fh - c["t0"]
        if dt < 0:
            return None
        g = 1.25
        x0, y0 = c["p"]
        vx, vy = c["v"]
        y_land = c["land"]
        # time to land
        disc = vy * vy + 2 * g * (y_land - y0)
        tl = (-vy + math.sqrt(max(disc, 0))) / g
        if dt < tl:
            x = x0 + vx * dt
            y = y0 + vy * dt + 0.5 * g * dt * dt
            return x, y, abs(math.cos(c["phase"] + c["spin"] * dt)) * 0.85 + 0.15, False
        # one small bounce, then it lies flat
        db = dt - tl
        xl = x0 + vx * tl
        if db < 6:
            hb = 3.0 * db - 0.5 * db * db
            return xl + 0.5 * vx * db, y_land - max(hb, 0) * 2.0, abs(math.cos(c["phase"] + c["spin"] * (tl + db))) * 0.7 + 0.3, False
        return xl + 0.5 * vx * 6, y_land, 1.0, True

    @cached_property
    def coin_landings(self):
        out = []
        for i, c in enumerate(self.coins):
            prev = None
            for fr in range(c["t0"], self.f1 + 30, 2):
                s = self.coin_state(c, fr)
                if s is None:
                    continue
                if prev is not None and s[1] >= c["land"] - 0.5 and prev[1] < c["land"] - 0.5:
                    out.append((fr, i))
                    break
                prev = s
        return [(fr, i) for fr, i in out if self.f0 <= fr < self.f1 + 8]

    def counter_value(self, f):
        fh = f - f % 2
        v = 184212.0
        if fh >= self.f_drop:
            v -= (184212.0 - 171860.0) * ease_out((fh - self.f_drop) / 10)
        if fh >= self.f_third:
            v -= (171860.0 - 118430.0) * ease_out((fh - self.f_third + 2) / 24)   # first drop on the word
        if fh >= self.f_500:
            v -= 2105.0 * ease_out((fh - self.f_500) / 10)
        return v

    # ------------------------------------------------------------ jar cracks
    @cached_property
    def jar_cracks(self):
        """Branching crack polylines on the jar glass (key px): set 0 grows on "drop", set 1 on "third"."""
        rng = np.random.default_rng(31)
        sets = []
        for origin, dirs, lens in [((688, 1992), [(1, 0.25), (-0.45, 1), (0.35, -1)], (50, 85)),
                                   ((738, 2052), [(1, -0.5), (-1, 0.15), (0.2, 1), (-0.3, -1), (0.9, 0.6)], (60, 115))]:
            lines = []
            for d in dirs:
                pts = bolt_points(origin, d, rng.uniform(*lens), 6, rng, jag=0.5)
                lines.append(pts)
                k = rng.integers(2, 4)                         # one branch off the middle
                bd = np.float32(d) + rng.uniform(-0.9, 0.9, 2)
                lines.append(bolt_points(pts[k], bd, rng.uniform(*lens) * 0.45, 3, rng, jag=0.5))
            sets.append(lines)
        return sets

    def _draw_jar_cracks(self, rgba, x0, y0, f):
        fh = f - f % 2
        prog = [np.clip((fh - self.f_drop + 2) / 6, 0, 1), np.clip((fh - self.f_third) / 6, 0, 1)]
        if prog[0] <= 0:
            return rgba
        jx0, jy0 = int(560 * SC) - x0, int(1880 * SC) - y0
        jw, jh = int(280 * SC), int(280 * SC)
        ss = 3
        core = np.zeros((jh * ss, jw * ss), np.uint8)
        for si, lines in enumerate(self.jar_cracks):
            u = float(prog[si])
            if u <= 0:
                continue
            for pts in lines:
                n = max(int(round(len(pts) * u)), 1 if u > 0 else 0)
                p = (np.asarray(pts[:max(n, 2)], np.float32) * SC - np.float32([x0 + jx0, y0 + jy0])) * ss
                cv2.polylines(core, [np.round(p * 8).astype(np.int32)], False, 255, max(1, int(1.3 * ss)), cv2.LINE_AA, shift=3)
        c = cv2.resize(core.astype(np.float32) / 255, (jw, jh), interpolation=cv2.INTER_AREA)
        jm = FX.poly_weight((jh, jw), [(x * SC, y * SC) for x, y in JAR_POLY], 1.5, (x0 + jx0, y0 + jy0))
        c *= jm
        shadow = np.roll(np.roll(c, 1, 0), 1, 1) * 0.45
        reg = rgba[jy0:jy0 + jh, jx0:jx0 + jw]
        reg[..., :3] = reg[..., :3] * (1 - shadow[..., None]) + np.float32([0.10, 0.08, 0.18]) * shadow[..., None]
        reg[..., :3] = reg[..., :3] * (1 - 0.85 * c[..., None]) + np.float32([0.90, 0.94, 1.0]) * 0.85 * c[..., None]
        return rgba

    # ------------------------------------------------------------ poses
    def woman_parts(self, f):
        fh = f - f % 2
        t = (fh - self.f0) / FPS
        fl = lambda t0, lag=0: flinch(t, (t0 - self.f0 + lag) / FPS)
        d1, d2 = fl(self.f_drop + 2), fl(self.f_third + 2)
        h1, h2 = fl(self.f_drop + 2, 2), fl(self.f_third + 2, 2)
        a1, a2 = fl(self.f_drop, 0), fl(self.f_third, 0)
        br = math.sin(2 * math.pi * t / 3.2)
        sc = SC
        body = {"angle": 0.35 * br + 0.8 * d1 + 1.6 * d2, "dx": -1.0 * d2 * sc, "dy": (1.5 * br + 4 * d1 + 8 * d2) * sc,
                "pivot": (RIG["waist"][0] * sc, RIG["waist"][1] * sc)}
        head = {"angle": 0.5 * math.sin(2 * math.pi * (t - 0.12) / 3.2) + 2.5 * h1 + 6.0 * h2,
                "dx": (2.0 * h2) * sc, "dy": (2.0 * h1 + 5.0 * h2) * sc,
                "pivot": (RIG["neck"][0] * sc, RIG["neck"][1] * sc)}
        trem = 0.0
        if fh >= self.f_drop:
            trem = (0.35 + (0.5 if fh >= self.f_third else 0.0)) * math.sin(fh * 2.3)
        arms = {"angle": trem + 1.8 * a1 + 3.5 * a2, "dx": 0.0, "dy": (3 * a1 + 7 * a2) * sc,
                "pivot": (RIG["elbow"][0] * sc, RIG["elbow"][1] * sc)}
        return body, head, arms, t

    # ------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        fh = f - f % 2
        Lt = self.light(f)
        Lr = 0.16 + 0.84 * Lt
        rps = []
        for i, pl in enumerate(self.planes):
            rgb = pl["un"] + (pl["rgb"] - pl["un"]) * (1 + (Lr - 1) * pl["gw"])
            a = pl["a"]
            if i == 1:
                a = a.copy()
                rgb = np.ascontiguousarray(rgb)
                self._cracks_into(rgb, a, fh)
                self._rubble_into(rgb, a, fh)
                self._line_into(rgb, a, fh)
                self._fog_puffs_into(rgb, a, fh)
            if i == 3:
                a = a.copy()
                self._woman_into(rgb, a, f, Lr)
                self._coins_into(rgb, a, fh, Lr)
            rps.append({"rgb": rgb, "a": a, "n": pl["n"]})
        img = self.cam.render(rps, t)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, DATA_TAG, self.f_seven, size=self.tag_size)
        self._counter(img, f)
        return img, {"light": Lt}

    def _cracks_into(self, rgb, a, fh):
        sc_ = None
        for i, (p, c) in enumerate(zip(PILLARS, self.cracks)):
            dt = fh - self.crack_t[i]
            if dt < 0:
                continue
            u = ease_out(min((dt + 2) / 6, 1.0))
            rgba = c["rgba"].copy()
            h, w = rgba.shape[:2]
            gy = np.arange(h, dtype=np.float32)[:, None] + c["y0"]
            gx = np.arange(w, dtype=np.float32)[None, :]
            front = c["y1"] - u * (c["y1"] - c["y0"]) - 4
            jag = 9 * np.sin(gx * 0.09 + i * 1.7) + 5 * np.sin(gx * 0.23 + i)
            m = np.clip((gy - front - jag) / 5.0, 0, 1)
            rgba[..., 3] *= m
            if dt <= 6:                                      # white-hot just behind the racing tip
                hot = np.clip(1 - (gy - front) / 34.0, 0, 1)[..., None] * (1.0 - dt / 10)
                rgba[..., :3] = rgba[..., :3] + (np.float32([1.0, 0.86, 0.95]) - rgba[..., :3]) * hot * 0.75
            k = {6: 1.35, 8: 1.18}.get(dt, 1.0) * (1 + 0.05 * math.sin(fh * 1.3 + i))
            rgba[..., :3] = np.clip(rgba[..., :3] * k, 0, 1)
            FX.over_patch(rgb, rgba, c["x0"], c["y0"], a)
            if dt <= 4 and c["pts"] is not None:              # a star flash at the tip as it runs
                pts = c["pts"]
                sel = pts[pts[:, 1] >= front + 4]
                if len(sel):
                    tip = sel[np.argmin(sel[:, 1])]
                    r = {0: 34, 2: 24, 4: 12}[dt]
                    self._flash(rgb, tip, r, (1.0, 0.9, 0.97), (1.0, 0.26, 0.70), seed=i * 7 + dt, glow=10 + r * 0.4)

    def _flash(self, rgb, c, r, core_rgb, glow_rgb, seed, glow=12.0, opacity=1.0):
        S = int(r * 6 + glow * 6)
        x0, y0 = int(c[0] - S / 2), int(c[1] - S / 2)
        sc = ShapeCanvas(S, S)
        rng = np.random.default_rng(seed)
        sc.fill(star4_poly((S / 2, S / 2), r, rng.uniform(0, 0.7)))
        sc.fill(star4_poly((S / 2, S / 2), r * 0.5, 0.78, pinch=0.3))
        core, gl = sc.result(glow_sigma=glow)
        screen_emissive(rgb, core, gl, core_rgb, glow_rgb, x0, y0, opacity)

    @cached_property
    def rubble(self):
        """Chunk flights: stone from each pillar's crack, gold shards from the snap."""
        out = []
        for i, c in enumerate(self.cracks):
            if c["pts"] is None:
                continue
            rng = np.random.default_rng(100 + i)
            px = PILLARS[i]["x"] * SC
            for k in range(7):
                q = c["pts"][rng.integers(len(c["pts"]))]
                side = 1.0 if q[0] >= px - 10 else -1.0
                out.append({"t0": self.crack_t[i] + 2 + 2 * (k % 3), "p": (float(q[0]), float(q[1])),
                            "v": (side * rng.uniform(0.8, 2.6), rng.uniform(-2.0, 0.3)), "g": 1.25,
                            "spin": rng.uniform(-18, 18), "kind": "stone", "i": int(rng.integers(10)),
                            "s": rng.uniform(0.7, 1.25)})
        rng = np.random.default_rng(300)
        for k in range(14):
            out.append({"t0": self.f_third + 2 * (k % 3), "p": None, "v": (rng.uniform(-4.5, 4.5), rng.uniform(-6.0, -0.5)),
                        "g": 1.3, "spin": rng.uniform(-25, 25), "kind": "gold", "i": int(rng.integers(10)),
                        "s": rng.uniform(0.6, 1.2)})
        return out

    def _rubble_into(self, rgb, a, fh):
        for r in self.rubble:
            dt = fh - r["t0"]
            if dt < 0:
                continue
            p0 = r["p"] if r["p"] is not None else self.snap_pt
            x = p0[0] + r["v"][0] * dt
            y = p0[1] + r["v"][1] * dt + 0.5 * r["g"] * dt * dt
            fade = float(np.clip(1 - (y / SC - FOG_Y[0]) / (FOG_Y[1] - FOG_Y[0]), 0, 1))
            if fade <= 0 or y > rgb.shape[0]:
                continue
            spr = self.chunk_bank[r["kind"]][r["i"]].copy()
            spr[..., 3] *= fade
            if r["kind"] == "gold":
                Lg = float(np.clip(1 - dt / 20, 0.25, 1))
                spr[..., :3] *= np.float32([0.45 + 0.55 * Lg, 0.25 + 0.75 * Lg, 0.30 + 0.70 * Lg])
            h, w = spr.shape[:2]
            vy = r["v"][1] + r["g"] * dt
            stretch = 1 + min(abs(vy) / 30.0, 0.5)               # a drawn smear along the fall, no blur
            pose_into(rgb, a, spr, int(x - w / 2), int(y - h / 2), angle=r["spin"] * dt, pivot=(x, y),
                      sx=r["s"], sy=r["s"] * stretch)
        # dust puffs where the stone breaks out
        for i, c in enumerate(self.cracks):
            dt = fh - self.crack_t[i] - 2
            if dt < 0 or dt > 10 or c["pts"] is None:
                continue
            rng = np.random.default_rng(500 + i)
            for k in range(3):
                q = c["pts"][rng.integers(len(c["pts"]))]
                rad = 12 + 3.0 * dt
                al = self._puff(int(rad), 600 + i * 3 + k)
                op = 0.38 * (1 - dt / 12)
                patch = np.dstack([np.broadcast_to(np.float32([0.40, 0.34, 0.56]), al.shape + (3,)), al * op]).astype(np.float32)
                FX.over_patch(rgb, patch, int(q[0] - al.shape[1] / 2 + 0.5 * dt * (1 if k % 2 else -1)),
                              int(q[1] - al.shape[0] / 2 + 0.6 * dt), a)

    def _puff(self, r, seed):
        key = (r, seed)
        cache = self.__dict__.setdefault("_puffs", {})
        if key not in cache:
            cache[key] = cv2.GaussianBlur(FX.haze_puff(r, seed).astype(np.float32), (0, 0), max(r / 14, 1.0))
        return cache[key]

    def _span_rgba(self, j, dim, al):
        """The span's own paint; as it falls the gold deepens toward amber (it keeps its texture and glow)."""
        rgba = self.spans[j]["rgba"]
        if dim <= 0 and al >= 1:
            return rgba
        rgba = rgba.copy()
        k = np.float32([1.0, 0.80, 0.70]) ** dim * (1 - 0.30 * dim)
        rgba[..., :3] = rgba[..., :3] * k
        rgba[..., 3] *= al
        return rgba

    def _line_into(self, rgb, a, fh):
        sc = None
        rng = np.random.default_rng(fh)
        for j in self.span_ids():
            ang, piv, dx, dy, al, dim, v = self.span_state(j, fh)
            if al <= 0:
                continue
            sp = self.spans[j]
            if v > 3.0:                                       # drawn streaks trailing off the burning top edge
                if sc is None:
                    sc = ShapeCanvas(rgb.shape[1], rgb.shape[0], ss=1)
                rot = math.radians(ang)
                ex0, ey0 = sp["a"]
                ex1, ey1 = sp["b"]
                pa = self.span_state(j, fh - 2)
                for u, lk in ((0.18, 3.6), (0.5, 2.4), (0.8, 3.0)):
                    ux = ex0 + (ex1 - ex0) * u - piv[0]
                    uy = ey0 + (ey1 - ey0) * u - piv[1] - 10
                    qx = math.cos(rot) * ux - math.sin(rot) * uy + piv[0] + dx
                    qy = math.sin(rot) * ux + math.cos(rot) * uy + piv[1] + dy
                    vel = (dx - pa[2] + 0.001, max(dy - pa[3], 1.0))
                    ln = min(v * lk * (0.85 + 0.3 * rng.random()), 170)
                    sc.fill(tapered_streak_poly((qx, qy), vel, ln, (12.0 + 5 * rng.random()) * al),
                            value=int(150 * al * (1 - 0.5 * dim)))
            pose_into(rgb, a, self._span_rgba(j, dim, al), sp["x0"], sp["y0"], angle=ang, pivot=piv, dx=dx, dy=dy)
        if sc is not None:
            core, gl = sc.result(glow_sigma=7)
            screen_emissive(rgb, core * 0.5, gl * 0.7, (1.0, 0.80, 0.46), (1.0, 0.50, 0.12))
        dt = fh - self.f_third
        if 0 <= dt <= 4:                                      # the snap: a gold flash
            r = {0: 120, 2: 70, 4: 30}[dt]
            self._flash(rgb, self.snap_pt, r, (1.0, 0.84, 0.50), (1.0, 0.55, 0.12), seed=77 + dt, glow=22 + r * 0.4)
            if dt <= 2:
                R = 260 if dt == 0 else 170
                S = 2 * R
                yy, xx = np.mgrid[0:S, 0:S].astype(np.float32)
                disc = np.exp(-((xx - R) ** 2 + (yy - R) ** 2) / (2 * (R * 0.42) ** 2)).astype(np.float32)
                screen_emissive(rgb, np.zeros_like(disc), disc * (0.9 if dt == 0 else 0.5), (0, 0, 0), (1.0, 0.62, 0.2),
                                int(self.snap_pt[0] - R), int(self.snap_pt[1] - R))

    def _fog_puffs_into(self, rgb, a, fh):
        for fr, j in self.span_landings:
            dt = fh - fr
            if dt < 0 or dt > 14:
                continue
            xa = self.spans[j if j != BREAK_SPAN else "8a"]["a"][0]
            xb = self.spans[j if j != BREAK_SPAN else "8b"]["b"][0]
            cx = (xa + xb) / 2 + (-1 if j < BREAK_SPAN else 1) * 40
            rad = int(40 + 6 * dt)
            al = self._puff(rad, 700 + j)
            op = 0.75 * (1 - dt / 16)
            patch = np.dstack([np.broadcast_to(np.float32([0.36, 0.62, 0.64]), al.shape + (3,)), al * op]).astype(np.float32)
            FX.over_patch(rgb, patch, int(cx - al.shape[1] / 2), int((FOG_Y[0] + 10) * SC - al.shape[0] * 0.6 - 1.5 * dt), a)
            if dt <= 2:                                       # the last gold of the piece flares in the fog
                self._flash(rgb, (cx, (FOG_Y[0] + 30) * SC), 20 - 6 * dt, (1.0, 0.85, 0.6), (1.0, 0.45, 0.15),
                            seed=900 + j, glow=10, opacity=0.8)

    @cached_property
    def pose_b(self):
        z = np.load(SRC_DIR / "poseB.npz")
        W, H = self.lay.W, self.lay.H
        rgb = cv2.resize(z["rgb"], (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        al = cv2.resize(z["alpha"], (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        he = cv2.resize(z["hero"], (W, H), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        ys, xs = np.nonzero(al > 0.004)
        x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
        crop = rgb[y0:y1, x0:x1]
        hy, hx = np.nonzero(he > 0.5)
        ca = np.nonzero(self.woman["rgba"][..., 3] > 0.5)
        cA = (ca[1].mean() + self.woman["x0"], ca[0].mean() + self.woman["y0"])
        cB = (hx.mean(), hy.mean())
        shp = crop.shape[:2]
        gy = np.arange(shp[0], dtype=np.float32)[:, None] + y0
        body = np.clip((2450 * SC - gy) / (2450 * SC - 1560 * SC), 0, 1) ** 1.1 * np.ones(shp, np.float32)
        arm = FX.poly_weight(shp, [(x * SC, y * SC) for x, y in [(250, 1540), (520, 1520), (560, 1700), (420, 1760), (280, 1700)]],
                             14, (x0, y0))
        arm_up = FX.poly_weight(shp, [(x * SC, y * SC) for x, y in ARM_B], 5, (x0, y0))
        return {"w_arm_up": arm_up, "rgba": np.dstack([crop, al[y0:y1, x0:x1]]).astype(np.float32),
                "hero": np.dstack([crop, he[y0:y1, x0:x1]]).astype(np.float32),
                "x0": int(x0), "y0": int(y0), "d": (cA[0] - cB[0], cA[1] - cB[1]),
                "gw": gold_weight(crop)[..., None] * 0.6, "un": unlit(crop), "w_body": body, "w_arm": arm}

    def _pose_b_into(self, rgb, a, f, Lr):
        pb = self.pose_b
        fh = f - f % 2
        t = (f - self.f0) / FPS
        src = pb["rgba"].copy()
        src[..., :3] = pb["un"] + (src[..., :3] - pb["un"]) * (1 + (Lr - 1) * pb["gw"])
        if self.f_smear <= f < self.f_b:
            # the in-between drawing (on 2s): pose B's figure mesh-warped halfway back to pose A, the arm
            # half raised, head half turned, jar half pulled in; the uncovered ground stays pose B's paint
            bg = src.copy()
            bg[..., 3] *= (1 - pb["hero"][..., 3]) * (1 - pb["w_arm_up"])   # nothing of B's arm stays behind
            FX.over_patch(rgb, bg, pb["x0"], pb["y0"], a)
            he = src.copy()
            he[..., 3] = pb["hero"][..., 3]
            # the arm is a rigid part rotated about the shoulder, still on its way up; the body leans halfway
            # back toward pose A
            x0, y0 = pb["x0"], pb["y0"]
            arm = he.copy()
            arm[..., 3] *= pb["w_arm_up"]
            body = he.copy()
            body[..., 3] *= 1 - pb["w_arm_up"]
            Mb = np.float32([[1, 0, 0], [0, 1, 4 * SC]])
            hh, ww = he.shape[:2]
            body = cv2.warpAffine(body, Mb, (ww, hh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
            px, py = 560 * SC - x0, 1900 * SC - y0
            Ma = cv2.getRotationMatrix2D((px, py), 28.0, 0.93)
            arm = cv2.warpAffine(arm, Ma, (ww, hh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
            FX.over_patch(rgb, body, x0, y0, a)
            FX.over_patch(rgb, arm, x0, y0, a)
            return
        # held pose B: overshoot and settle on 2s, then a trembling raised arm, breathing, shawl in the wind
        d = fh - (self.f_b - self.f_b % 2)
        pop = {0: -7.0, 2: 3.0, 4: -1.0}.get(d, 0.0) * SC
        br = math.sin(2 * math.pi * t / 2.6)
        body = {"angle": 0.3 * br, "dx": 0.0, "dy": pop + 1.2 * br * SC, "pivot": (330 * SC, 2450 * SC)}
        arm = {"angle": 1.1 * math.sin(fh * 2.7) + (2.5 if d == 0 else 0.0), "dx": 0.0, "dy": 0.0,
               "pivot": (470 * SC, 1760 * SC)}
        bg = src.copy()
        bg[..., 3] *= 1 - pb["hero"][..., 3]                        # the ground she uncovered holds still
        FX.over_patch(rgb, bg, pb["x0"], pb["y0"], a)
        he = src.copy()
        he[..., 3] = pb["hero"][..., 3]
        patch = FX.part_warp(he, pb["x0"], pb["y0"], [dict(body, w=pb["w_body"]), dict(arm, w=pb["w_arm"])])
        FX.over_patch(rgb, patch, pb["x0"], pb["y0"], a)

    def _woman_into(self, rgb, a, f, Lr):
        if f >= self.f_smear:
            return self._pose_b_into(rgb, a, f, Lr)
        wmn = self.woman
        body, head, arms, t = self.woman_parts(f)
        src = wmn["rgba"].copy()
        src[..., :3] = wmn["un"] + (src[..., :3] - wmn["un"]) * (1 + (Lr - 1) * wmn["gw"])
        src = self._draw_jar_cracks(src, wmn["x0"], wmn["y0"], f)
        fh = f - f % 2
        h, w = src.shape[:2]
        gy = np.arange(h, dtype=np.float32)[:, None]
        tw = (fh - self.f0) / FPS
        gust = 1.0 + (1.2 if fh >= self.f_third else 0.0) * math.exp(-max(fh - self.f_third, 0) / 30)
        DX = wmn["w_fringe"] * (2.2 * gust * np.sin(2 * math.pi * tw / 0.75 + gy * 0.035)).astype(np.float32)
        DY = wmn["w_fringe"] * (0.8 * gust * np.cos(2 * math.pi * tw / 0.75 + gy * 0.035)).astype(np.float32)
        parts = [dict(body, w=wmn["w_body"]), dict(head, w=wmn["w_head"]), dict(arms, w=wmn["w_arms"])]
        patch = FX.part_warp(src, wmn["x0"], wmn["y0"], parts, extra=(DX, DY))
        FX.over_patch(rgb, patch, wmn["x0"], wmn["y0"], a)

    def _coins_into(self, rgb, a, fh, Lr):
        for c in self.coins:
            s = self.coin_state(c, fh)
            if s is None:
                continue
            x, y, xs, lying = s
            spr = self.coin_sprites[c["spr"]]
            h, w = spr.shape[:2]
            if lying:
                pose_into(rgb, a, spr, int(x - w / 2), int(y - h / 2), angle=8.0, pivot=(x, y), sx=1.15, sy=0.42)
            else:
                sm = 1.0 + min(max(c["v"][1] + 1.25 * (fh - c["t0"]), 0) / 40.0, 0.35)
                pose_into(rgb, a, spr, int(x - w / 2), int(y - h / 2), angle=c["phase"] * 30, pivot=(x, y), sx=xs, sy=sm)

    def _counter(self, img, f):
        if f < self.f_ret:
            return
        fh = f - f % 2
        t = self.ctx.local(f)
        v = self.counter_value(f)
        falling = (0 <= fh - self.f_drop <= 12) or (0 <= fh - self.f_third <= 26)
        col = (255, 128, 112) if falling else (246, 236, 216)
        num = O.counter_rgba(round(v), fmt="${:,.0f}", size=78, color=col, decimals=0, roll=False)
        p = self.cam.screen_point((805 * SC, 1915 * SC), nearness(0.6), t)
        x0, y0, x1, y1 = safe_box()
        x = min(max(p[0] + 8, x0), x1 - num.shape[1])
        y = min(max(p[1] - num.shape[0] * 0.75, y0), y1 - num.shape[0] - 34)
        O.draw_pop(img, num, x, y, f, self.f_ret)
        chip = O.scenario_label()
        O.draw_pop(img, chip, x + 6, y + num.shape[0] - 8, f, self.f_ret)

    # --------------------------------------------------------------- report / sound
    def finish_args(self, f, info):
        return {"bloom_strength": 0.42 + 0.18 * min(info["light"], 1.6)}

    def events(self):
        ev = [(self.f_seven, "data_tag", {}), (self.f_drop, "counter_dips", {}), (self.f_drop, "jar_cracks", {}),
              (self.f_third, "jar_cracks", {"big": 1}), (self.sag_t, "line_sags", {}), (self.f_third, "line_snaps", {}),
              (self.f_third, "counter_plummets", {}), (self.f_smear, "woman_flinches", {})]
        for i, tc in enumerate(self.crack_t):
            ev.append((tc, "pillar_cracks", {"i": i, "x": PILLARS[i]["x"] / 1520}))
        for fr, j in self.span_landings:
            ev.append((fr, "segment_lands", {"span": j, "x": LINE_TOP[j][0] / 1520}))
        for j in SPANS:
            if j != BREAK_SPAN:
                ev.append((self.hinge_t[j], "segment_gives", {"span": j}))
        for fr, i in self.coin_landings:
            ev.append((fr, "coin_lands", {"i": i}))
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tail = dur + 0.8
        snd.bed(FX.wind(tail, seed=21), t0, -27, pan=-0.1)
        snd.bed(A.drone(tail, seed=22), t0, -36)
        snd.sfx(FX.rumble(3.2, seed=23), snd.at_frame(self.f_seven), -20, 0.0)
        snd.sfx(FX.rumble(3.6, seed=24), snd.at_frame(self.f_third), -15, 0.0)
        for f, kind, info in self.events():
            t = snd.at_frame(f)
            if kind == "pillar_cracks":
                pan = float(np.clip((info["x"] - 0.5) * 1.6, -0.8, 0.8))
                snd.sfx(FX.stone_crack(seed=40 + info["i"], size=0.8 + 0.1 * info["i"]), t, -15 + 0.6 * info["i"], pan)
                snd.sfx(FX.sub_hit(seed=50 + info["i"], f0=52.0, dur=0.5), t, -22, 0.0)
            elif kind == "line_sags":
                snd.sfx(FX.stone_crack(seed=61, size=0.5), t, -24, 0.0)
            elif kind == "line_snaps":
                snd.sfx(FX.snap_crash(seed=11), t, -9, 0.0)
                snd.sfx(FX.sub_hit(seed=5, f0=44.0, dur=1.2), t, -10, 0.0)
            elif kind == "segment_lands":
                pan = float(np.clip((info["x"] - 0.5) * 1.6, -0.8, 0.8))
                snd.sfx(FX.sub_hit(seed=70 + info["span"], f0=40.0 + 2 * (info["span"] % 4), dur=0.8), t, -15, pan)
                snd.sfx(A.lowpass(FX.stone_crack(seed=80 + info["span"], size=1.3), 1800), t, -21, pan)
            elif kind == "segment_gives":
                snd.sfx(FX.stone_crack(seed=90 + info["span"], size=0.45), t, -26, 0.0)
            elif kind == "coin_lands":
                cl = FX.coin_clink(seed=100 + info["i"], f=2600.0 + 180 * (info["i"] % 5))
                snd.sfx(cl, t, -9, 0.25 + 0.1 * (info["i"] % 3))
                snd.sfx(FX.coin_clink(seed=140 + info["i"], f=3400.0 + 150 * (info["i"] % 4)), t + 0.07, -16, 0.3)
            elif kind == "jar_cracks":
                snd.sfx(FX.glass_crack(seed=120 + info.get("big", 0)), t, -15 if info.get("big") else -18, 0.0)
            elif kind == "woman_flinches":
                snd.sfx(A.swish(0.22, seed=7), t, -18, -0.3)
            elif kind == "counter_dips":
                snd.sfx(A.tick(130, 1900), t, -24, 0.2)


def flinch(t, t0):
    """A flinch on held drawings: small lift (anticipation), drop past the pose, settle."""
    return Track([(t0, 0.0), (t0 + 2 / FPS, -0.3, "inout"), (t0 + 4 / FPS, 1.15, "out"), (t0 + 8 / FPS, 0.92, "inout"),
                  (t0 + 12 / FPS, 1.0, "inout")])(t)


def make(ctx):
    return Shot(ctx)
