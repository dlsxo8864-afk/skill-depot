"""Shot 4, Year 3: remote work ends. Open on an invented video-call grid (painted people in their homes,
idling on 2s). From "home" the tiles freeze one by one (glitch drawing, then a cooled still and a
reconnect spinner). Hairline cracks on the two drawings before "back", and on "back" the call shatters
into shards that fly at the camera, revealing a gridlocked highway where a pajama crowd trudges to the
office: the walker in front bobs, rolls, swings his dead laptop and his steaming mug; the crowd bobs
with offset phases; brake lights flick on; exhaust haze drifts. Data tag on "thirty-five".

Key-image px are pixels of work/keys/y03_remote_key.png (1520 x 2701)."""
import math
from functools import cached_property

import cv2
import numpy as np

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif.camera import ParallaxCamera
from whatif.config import FPS, OUT_W, safe_box
from whatif.keyprep import prepare_key
from whatif.layers import brush_noise
from whatif.screens import ScreenQuad, dead_glass
from whatif.shotkit import BaseShot
from whatif.timing import Track, even_frame_of

from . import s03_year2_kit as K
from . import s04_year3_call as C

STEM = "s04_year3"
SC = L.WORK_SCALE

# ------------------------------------------------------------------ spec (key px)
MAN_REGION = [(560, 955), (880, 955), (960, 1150), (1040, 1400), (1080, 1555), (1150, 1575), (1210, 1790),
              (1110, 1865), (905, 1885), (905, 2140), (875, 2205), (772, 2215), (768, 2395), (800, 2445),
              (792, 2522), (700, 2538), (608, 2512), (590, 2450), (612, 2300), (604, 2240), (598, 2330),
              (588, 2432), (566, 2562), (492, 2628), (418, 2612), (390, 2530), (414, 2440), (438, 2340),
              (440, 2168), (330, 2152), (292, 1905), (255, 1885), (255, 1700), (318, 1500), (380, 1200)]
PLANES = [
    L.PlaneSpec("sky", 0.00, 0.065, fill="full"),
    L.PlaneSpec("far", 0.065, 0.30, radius=50),
    L.PlaneSpec("mid", 0.30, 0.64, radius=70),
    L.PlaneSpec("near", 0.64, 1.01, radius=60),
    L.PlaneSpec("man", 0.58, 1.01, radius=90, region=MAN_REGION),
]
SPRITES = []
LAPTOP_SCREEN = [(719, 1607), (983, 1571), (1050, 1753), (770, 1820)]
MUG_TOP = (392, 1772)
MID_MUGS = [((272, 1236), 0), ((1150, 1240), 3)]          # (key px, mid-person index)
# brake lights: pairs of tail-lamp points (key px) and the plane they sit in
# tail-lamp pairs on the painted car rears (key px), one pair per car, just under each rear window
BRAKES = [(250, 1000), (412, 1001), (340, 914), (545, 900), (94, 883), (262, 874), (452, 880), (565, 872),
          (352, 850), (437, 848), (941, 949), (1091, 939), (1160, 980), (1341, 967), (1068, 908), (1205, 900),
          (1305, 925), (1452, 915), (1245, 880), (1385, 872), (995, 880), (1113, 872), (1170, 860), (1300, 856),
          (958, 853), (1025, 851)]
# the walkers only: the edge cars and the far jam stay out of the pose-B mask
HERO_REGION = [(150, 1000), (540, 860), (1000, 860), (1380, 980), (1380, 1900), (1520, 2000), (1520, 2701),
               (0, 2701), (0, 1900), (150, 1700)]
# pose B (the walkers on the opposite step), measured on work/poses/s04_poseB.png
MUG_TOP_B = (312, 1562)
MID_MUGS_B = [(298, 1226), (1160, 1226)]
LAPTOP_SCREEN_B = [(821, 1643), (1000, 1552), (1090, 1695), (900, 1786)]
EXHAUST = [(270, 1012), (360, 925), (110, 893), (960, 960), (1180, 990), (1085, 918), (1325, 935), (1010, 890)]   # tailpipes
# mid-crowd people (soft boxes, key px): box, head y, phase
MID_PEOPLE = [((0, 1000, 330, 1900), 0.0), ((300, 1005, 565, 1520), 1.7), ((560, 1000, 760, 1300), 3.1),
              ((840, 950, 1150, 1620), 4.2), ((1110, 960, 1520, 1900), 2.4), ((990, 930, 1120, 1200), 5.3)]
CROWD = [(560, 790), (820, 790), (1060, 1110), (330, 1110)]     # far crowd corridor (heads bob)
PUFFS = [((215, 765), 70), ((445, 805), 55), ((1130, 810), 90), ((1350, 760), 60), ((600, 830), 50)]

# measured from the take (s after the wav starts): energy onsets
VO_ONSETS = {"home": 0.62, "thirty-five": 1.68, "it's": 3.62, "back": 3.78, "office": 4.02}


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        wf = lambda w: even_frame_of(ctx.vo_at + VO_ONSETS[w])
        self.f_home = wf("home")
        self.f_tag = wf("thirty-five")
        self.f_back = wf("back")
        # the call holds until "back": people react on 2s as the feeds freeze one after another, a
        # reconnecting chip comes up, cracks run on the last two drawings and the glass breaks on "back"
        g = lambda fr: fr - (fr - self.f0) % 2                 # the shot's drawing grid (holds start at f0)
        self.f_break = g(self.f_back)
        self.freeze_at = [None] * 6
        self.react_at = [None] * 6
        for tile, (fz, ra) in {3: (427, 421), 0: (445, 433), 5: (459, 439), 1: (471, 451), 4: (483, 463),
                               2: (491, 469)}.items():
            # times are set against the call's start (f0 = 413 in v4) and the break, so they move with the line
            self.freeze_at[tile] = g(self.f0 + fz - 413)
            self.react_at[tile] = g(self.f0 + ra - 413)
        self.speaker = 4
        self.c0 = self.f_break                      # the walk: pose A lands on the reveal
        # pose B: the walkers on the opposite step, taken through a soft mask aligned to the key
        comp = key.parent.parent / "poses" / "s04_poseB.png"
        self.hero_key = K.pose_b_composite(key, ctx.key.parent / "y03_remote_poseB.png", comp, HERO_REGION,
                                           thresh=0.12, grow=16, feather=8, close=61, min_area=3000)
        keyB, depthB = prepare_key(comp)
        L.build(STEM + "_B", keyB, depthB, PLANES[:4], [])
        self.layB = L.Layers(STEM + "_B")
        tb = (self.f_break - self.f0) / FPS
        d = ctx.dur                                 # the move comes to rest on the last drawing (a hold to end on)
        self.cam = ParallaxCamera(
            W, H, focus=Track([(0, (W * 0.50, H * 0.47)), (d, (W * 0.50, H * 0.50), "inout")]),
            nearness=nearness,
            zoom=Track([(0, 1.0), (tb, 1.0), (d, 1.09, "inout")]),
            push=Track([(0, 0.0), (tb, 0.0), (d, 0.07, "inout")]),
            rise=Track([(0, 0.0), (tb, 0.0), (d, -30.0, "inout")]))

    # ------------------------------------------------------------------ cached pieces
    @cached_property
    def planes(self):
        out = []
        for p in self.lay.planes:
            out.append({"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                        "n": nearness(p["d"].astype(np.float32) / 65535)})
        return out

    @cached_property
    def planes_b(self):
        return [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                 "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.layB.planes]

    @cached_property
    def hero_w(self):
        H, W = self.lay.H, self.lay.W
        return cv2.resize(self.hero_key, (W, H), interpolation=cv2.INTER_AREA).astype(np.float32)

    @cached_property
    def hero_out(self):
        m = self.hero_w
        return {"rgb": np.repeat(m[..., None], 3, 2), "a": np.ones_like(m), "n": self.planes[3]["n"]}

    @cached_property
    def settle_w(self):
        """Who sinks on a landing: the walkers (hero mask), from the head down to just above the feet."""
        sh = (self.lay.H, self.lay.W)
        return self.hero_w * K.ramp(sh, (0, 1500), (0, 2380))

    @cached_property
    def call(self):
        return C.CallGrid(seed=1)

    @cached_property
    def shatter(self):
        return C.Shatter((540, 1025), seed=5, n=34)

    @cached_property
    def shard_src(self):
        img = self.call.render(self.f_break - 2, self.f_break - 2 - self.f0, self.freeze_at, self.speaker, self.react_at)
        return self.shatter.draw_cracks(img, -2)

    @cached_property
    def rig(self):
        sh = (self.lay.H, self.lay.W)
        body = K.ramp(sh, (0, 1950), (0, 2420))
        head = K.soft_disc(sh, (700, 1050), 150, 0.45)
        hair = head * K.ramp(sh, (700, 990), (700, 1110))
        arm_l = K.soft_poly(sh, [(250, 1380), (500, 1330), (520, 1700), (470, 1900), (250, 1900)], 10) * \
            K.ramp(sh, (390, 1850), (480, 1360))
        laptop = K.soft_poly(sh, [(690, 1560), (1010, 1540), (1210, 1790), (1110, 1870), (740, 1860)], 8)
        arm_r = np.maximum(laptop, K.soft_poly(sh, [(860, 1300), (1010, 1300), (1040, 1600), (900, 1600)], 10) *
                           K.ramp(sh, (950, 1580), (930, 1330)))
        leg_l = K.soft_poly(sh, [(380, 2180), (610, 2180), (600, 2640), (380, 2640)], 6) * \
            K.ramp(sh, (470, 2600), (520, 2190))
        leg_r = K.soft_poly(sh, [(600, 2190), (800, 2190), (810, 2560), (595, 2560)], 6) * \
            K.ramp(sh, (690, 2500), (690, 2200))
        hem = K.soft_poly(sh, [(300, 1900), (920, 1900), (920, 2230), (300, 2230)], 12) * \
            K.ramp(sh, (0, 2170), (0, 1880))
        bones = {"body": {"w": body, "pivot": (640, 1960)}, "head": {"w": head, "pivot": (700, 1170)},
                 "hair": {"w": hair}, "arm_l": {"w": arm_l, "pivot": (490, 1300)},
                 "arm_r": {"w": arm_r, "pivot": (930, 1260)}, "leg_l": {"w": leg_l, "pivot": (520, 2230)},
                 "leg_r": {"w": leg_r}, "hem": {"w": hem}}
        return K.Rig((240, 900, 1260, 2701), sh, bones)

    @cached_property
    def mid_rig(self):
        sh = (self.lay.H, self.lay.W)
        out = []
        for (x0, y0, x1, y1), ph in MID_PEOPLE:
            w = K.soft_poly(sh, [(x0, y0), (x1, y0), (x1, y1), (x0, y1)], 14) * \
                (0.30 + 0.70 * K.ramp(sh, (0, y0 + 80), (0, y1)))
            out.append((w, ph, (x0 + x1) / 2 * SC, (y0 + 150) * SC))
        tot = np.maximum(sum(w for w, *_ in out), 1.0)
        return [(w / tot, ph, cx, cy) for w, ph, cx, cy in out]

    @cached_property
    def crowd_field(self):
        sh = (self.lay.H, self.lay.W)
        m = K.soft_poly(sh, CROWD, 10)
        rng = np.random.default_rng(12)
        ph = cv2.resize(rng.uniform(0, 2 * math.pi, (sh[0] // 24 + 1, sh[1] // 18 + 1)).astype(np.float32),
                        (sh[1], sh[0]), interpolation=cv2.INTER_CUBIC)
        return m, ph

    @cached_property
    def haze(self):
        H, W = self.lay.H, self.lay.W
        rng = np.random.default_rng(71)
        n1 = cv2.GaussianBlur(rng.normal(0, 1, (H // 4, W // 4)).astype(np.float32), (0, 0), 7)
        n2 = cv2.GaussianBlur(rng.normal(0, 1, (H // 4, W // 4)).astype(np.float32), (0, 0), 3)
        n = n1 / (n1.std() + 1e-6) + 0.35 * n2 / (n2.std() + 1e-6)
        n = cv2.resize(cv2.resize(n, (W // 4, H // 8)), (W, H), interpolation=cv2.INTER_CUBIC) * 0.5
        yy = np.arange(H, dtype=np.float32)[:, None] / SC
        band = np.clip((yy - 600) / 120, 0, 1) * np.clip((1180 - yy) / 160, 0, 1)
        xx = np.linspace(0, 1, W, dtype=np.float32)[None, :]
        col = (np.float32([1.0, 0.62, 0.55]) * (1 - xx)[..., None] + np.float32([0.60, 0.78, 0.80]) * xx[..., None])
        return n.astype(np.float32), band.astype(np.float32), col.astype(np.float32)

    @cached_property
    def puff_w(self):
        sh = (self.lay.H, self.lay.W)
        return sum(K.soft_disc(sh, c, r, 0.6) for c, r in PUFFS)

    @cached_property
    def laptop_quad(self):
        return ScreenQuad.from_points(LAPTOP_SCREEN, (self.lay.H, self.lay.W), scale=SC, radius=2)

    @cached_property
    def laptop_quad_b(self):
        return ScreenQuad.from_points(LAPTOP_SCREEN_B, (self.lay.H, self.lay.W), scale=SC, radius=2)

    @cached_property
    def tag_size(self):
        x0, _, x1, _ = safe_box()
        for s in (44, 40, 36, 34, 32, 30, 28):
            if O.data_tag(TAG, size=s).shape[1] <= x1 - x0 + 30:
                return s
        return 26

    # ------------------------------------------------------------------ motion
    def walk_state(self, f):
        """Two painted poses a step apart: A held, one in-between drawing, B held, one in-between."""
        if f < self.c0:
            return "A", 0
        p = (f - self.c0) % 24
        if p <= 10:
            return "A", p
        if p == 11:
            return "ib", "AB"
        if p <= 22:
            return "B", p - 12
        return "ib", "BA"

    def settle(self, k):
        """Landing on a held pose: sink, rise a touch past, settle (px, down positive)."""
        return {0: 6.0, 2: 2.5, 4: -1.5}.get(k - k % 2, 0.0)

    def walk(self, fh, k=0):
        st = self.settle(k)
        lag = self.settle(k - 2)
        return {"body": (0.0, 0.0, st), "head": (0.6 * (lag - st), 0.0, 0.0),
                "hair": (0.0, 0.0, 1.4 * lag - st), "arm_l": (-1.2 * lag, 0.0, 0.0), "arm_r": (1.0 * lag, 0.0, 0.0),
                "hem": (0.0, 2.0 * lag, 0.0)}

    def _settle_warp(self, rgb, a, dy):
        if abs(dy) < 0.01:
            return rgb, a
        H, W = a.shape
        gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
        sy = gy - self.settle_w * dy
        return (cv2.remap(rgb, gx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE),
                cv2.remap(a, gx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE))

    def _mid_warp(self, rgb, a, fh):
        H, W = a.shape
        DX = np.zeros((H, W), np.float32)
        DY = np.zeros((H, W), np.float32)
        for k, (w, ph, cx, cy) in enumerate(self.mid_rig):
            u = (fh - self.c0) / 22.0 + ph / (2 * math.pi)
            DY += w * (3.6 * math.cos(4 * math.pi * u))
            DX += w * (1.6 * math.sin(2 * math.pi * u))
        gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
        sx, sy = gx - DX, gy - DY
        return (cv2.remap(rgb, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE),
                cv2.remap(a, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE))

    def _far_warp(self, rgb, a, fh):
        m, ph = self.crowd_field
        H, W = a.shape
        DY = m * 2.4 * np.cos(2 * math.pi * fh / 20.0 + ph)
        # exhaust puffs boil and creep up on 2s
        rng = np.random.default_rng(fh // 2)
        bx = cv2.resize(rng.normal(0, 1, (H // 40 + 1, W // 40 + 1)).astype(np.float32), (W, H), interpolation=cv2.INTER_CUBIC)
        by = cv2.resize(rng.normal(0, 1, (H // 40 + 1, W // 40 + 1)).astype(np.float32), (W, H), interpolation=cv2.INTER_CUBIC)
        pw = self.puff_w
        DX = pw * bx * 2.2
        DY = DY + pw * (by * 2.2 - 0.25 * ((fh - self.f0) % 24))
        gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
        sx, sy = gx - DX, gy - DY
        return (cv2.remap(rgb, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE),
                cv2.remap(a, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE))

    def _haze(self, rgb, th):
        n, band, col = self.haze
        H, W = band.shape
        gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
        sx = gx - 14.0 * th
        sy = gy + 5.0 * th
        nn = cv2.remap(n, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        al = np.clip(nn * 0.8 + 0.15, 0, 1) ** 1.4 * band * 0.30
        return rgb * (1 - al[..., None]) + col * al[..., None]

    @cached_property
    def exhaust_n(self):
        d = cv2.imread(str(self.ctx.key_paths()[1]), -1).astype(np.float32) / 65535
        return [float(nearness(np.float32(np.median(d[y - 3:y + 4, x - 3:x + 4])))) for x, y in EXHAUST]

    def _exhaust(self, img, fh, t):
        """Idling tailpipes: brushy puffs that swell, lift and thin out, lit red by the brake lamps (on 2s).
        Drawn in output px after the camera so they hang in the air over the jam."""
        H, W = img.shape[:2]
        for j, (x, y) in enumerate(EXHAUST):
            n = self.exhaust_n[j]
            px, py = self.cam.screen_point((x * SC, y * SC), n, t)
            sc = self.cam.scale_at(n, t) * SC
            for gen in range(3):
                age = (fh - self.f0 + 12 * gen + 5 * j) % 36            # a new puff every 12 frames per pipe
                age -= age % 2
                u = age / 36.0
                cx = px - sc * (50 * u + 10 * math.sin(u * 5 + j))
                cy = py - sc * (110 * u)
                r = sc * (14 + 62 * u)
                x0, y0, x1, y1 = int(cx - 1.6 * r), int(cy - 1.6 * r), int(cx + 1.6 * r) + 1, int(cy + 1.6 * r) + 1
                x0, y0, x1, y1 = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
                if x1 - x0 < 2 or y1 - y0 < 2:
                    continue
                gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
                d = np.sqrt((gx - cx) ** 2 + ((gy - cy) * 1.25) ** 2) / r
                oy, ox = (j * 61 + gen * 17) % 300, (j * 29 + gen * 83) % 300
                nz = self.puff_noise[oy:oy + (y1 - y0), ox:ox + (x1 - x0)]
                if nz.shape != d.shape:
                    nz = cv2.resize(nz, (x1 - x0, y1 - y0))
                al = np.clip((1 - d) * 1.5 + 0.45 * (nz - 0.5), 0, 1) ** 1.3 * (0.68 * math.sin(math.pi * min(1.0, u * 1.1)))
                col = np.float32([0.80, 0.58, 0.64]) * (1 - u) + np.float32([0.58, 0.56, 0.70]) * u
                img[y0:y1, x0:x1] = img[y0:y1, x0:x1] * (1 - al[..., None]) + col * al[..., None]
        return img

    @cached_property
    def puff_noise(self):
        n = brush_noise((600, 600), 88, scale=3, angle=-0.9, stretch=3)
        return n.astype(np.float32)

    def brake_level(self, i, fh):
        # on "back" every brake light in the jam flares, near to far, one drawing apart
        car = i // 2
        kb = fh - self.f_back
        if 0 <= kb - 2 * (car % 3) <= 12:
            return 1.7
        rng = np.random.default_rng(300 + car)
        period = int(rng.integers(10, 16)) * 2
        off = int(rng.integers(2, 4)) * 2
        start = int(rng.integers(0, period // 2)) * 2
        k = (fh - self.f0 - start) % period
        return 0.3 if k < off else 1.0

    @cached_property
    def brake_planes(self):
        d = cv2.imread(str(self.ctx.key_paths()[1]), -1).astype(np.float32) / 65535
        out = []
        for x, y in BRAKES:
            dv = float(np.median(d[y - 3:y + 4, x - 3:x + 4]))
            out.append(max(i for i, p in enumerate(PLANES[:4]) if p.dmin <= dv))
        return out

    def _brakes(self, rgb, plane_i, fh):
        H, W = rgb.shape[:2]
        for i, ((x, y), pi) in enumerate(zip(BRAKES, self.brake_planes)):
            if pi != plane_i:
                continue
            lv = self.brake_level(i, fh)
            cx, cy = x * SC, y * SC
            r = 3.8
            x0, y0, x1, y1 = int(cx - 60), int(cy - 40), int(cx + 60), int(cy + 50)
            x0, y0, x1, y1 = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
            gy, gx = np.mgrid[y0:y1, x0:x1].astype(np.float32)
            d2 = ((gx - cx) / (r * 1.5)) ** 2 + ((gy - cy) / r) ** 2
            core = (np.exp(-d2 * 1.4) * lv)[..., None]
            halo = (np.exp(-d2 / 14.0) * lv)[..., None]
            wide = (np.exp(-(((gx - cx) / 40) ** 2 + ((gy - cy - 8) / 26) ** 2)) * lv * lv)[..., None]
            reg = rgb[y0:y1, x0:x1]
            reg = 1 - (1 - reg) * (1 - np.clip(halo * 0.8 + wide * 0.26, 0, 1) * np.float32([1.0, 0.10, 0.10]))
            core = np.clip(core, 0, 1)
            hot = np.clip(core * 1.6 - 0.6, 0, 1) * min(1.0, lv)
            reg = reg * (1 - core) + np.float32([0.98, 0.16, 0.12]) * core
            reg = reg * (1 - hot) + np.float32([1.0, 0.78, 0.66]) * hot
            rgb[y0:y1, x0:x1] = reg
        return rgb

    def _laptop(self, rgb, a, fh, quad):
        """The dead screen: the painted dark glass stays; a sky reflection slides over it as he walks
        and an empty-battery glyph blinks."""
        cw, ch = 300, 200
        canvas = np.zeros((ch, cw, 4), np.float32)
        s = ((fh - self.f0) / 50.0) % 1.5 - 0.25
        yy = np.linspace(0, 1, ch, dtype=np.float32)[:, None]
        xx = np.linspace(0, 1, cw, dtype=np.float32)[None, :]
        band = np.clip(1 - np.abs((xx * 0.9 + yy * 0.45) - s) * 6, 0, 1) ** 1.5
        canvas[..., :3] = np.float32([0.62, 0.52, 0.78])
        canvas[..., 3] = band * 0.16
        if ((fh - self.f0) // 8) % 2 == 0:
            g = np.zeros((ch, cw), np.float32)
            bx, by = int(cw * 0.30) - 30, int(ch * 0.42) - 15
            cv2.rectangle(g, (bx, by), (bx + 56, by + 30), 1.0, 3, cv2.LINE_AA)
            cv2.rectangle(g, (bx + 56, by + 9), (bx + 62, by + 21), 1.0, -1, cv2.LINE_AA)
            cv2.rectangle(g, (bx + 6, by + 6), (bx + 11, by + 24), 1.0, -1, cv2.LINE_AA)
            g = cv2.GaussianBlur(g, (0, 0), 0.7)
            canvas[..., :3] = canvas[..., :3] * (1 - g[..., None]) + np.float32([0.86, 0.18, 0.20]) * g[..., None]
            canvas[..., 3] = np.maximum(canvas[..., 3], g * 0.85)
        patch, x0, y0 = quad.warp(canvas)
        al = patch[..., 3:4] * quad.mask[y0:y0 + patch.shape[0], x0:x0 + patch.shape[1], None]
        reg = rgb[y0:y0 + patch.shape[0], x0:x0 + patch.shape[1]]
        rgb[y0:y0 + patch.shape[0], x0:x0 + patch.shape[1]] = reg * (1 - al) + patch[..., :3] * al

    # ------------------------------------------------------------------ frame
    def render_pose(self, f, which, k):
        t = self.ctx.local(f)
        fh = f - (f - self.f0) % 2
        th = (fh - self.f0) / FPS
        dy = self.settle(k)
        pls = self.planes if which == "A" else self.planes_b
        rps = []
        for i, pl in enumerate(pls):
            rgb, a = pl["rgb"], pl["a"]
            if i == 0:
                rgb = self._brakes(rgb.copy(), 0, fh)
            elif i == 1:
                rgb, a = self._far_warp(rgb, a, fh)
                rgb = self._haze(rgb, th)
                rgb = self._brakes(rgb, 1, fh)
            elif i == 2:
                rgb = self._brakes(rgb.copy(), 2, fh)
                rgb, a = self._settle_warp(rgb, a, dy * 0.6)
            elif i == 3:
                if which == "B":                                # the walker in front lives here in pose B
                    rgb, a = rgb.copy(), a.copy()
                    self._laptop(rgb, a, fh, self.laptop_quad_b)
                rgb, a = self._settle_warp(rgb, a, dy)
            elif i == 4:
                rgb, a = rgb.copy(), a.copy()
                self._laptop(rgb, a, fh, self.laptop_quad)
                rgb, a = self.rig.warp([rgb, a], self.walk(fh, k))
            rps.append({"rgb": rgb, "a": a, "n": pl["n"]})
        img = self.cam.render(rps, t)
        self._exhaust(img, fh, t)
        self._steam(img, fh, t, which, k)
        return img

    def highway(self, f):
        st, arg = self.walk_state(f)
        if st == "A":
            return self.render_pose(f, "A", arg)
        # pose B lives only inside the walkers' mask; road, cars, sky and lamps are always pose A's frame
        t = self.ctx.local(f)
        k = arg if st == "B" else 10
        img_a = self.render_pose(f, "A", 10 if st == "B" else k)
        img_b = self.render_pose(f, "B", k)
        m = self.cam.render([self.hero_out], t)[..., 0]
        if st == "B":
            return K.pose_mix(img_a, img_b, m)
        # the in-between: a mesh warp halfway between the two paintings inside the mask
        # (the pose being left, carried halfway along the measured flow: one solid set of walkers)
        return K.mesh_inbetween(img_a, img_b, m, t=0.5, mix=0.0 if arg == "AB" else 1.0)

    def _steam(self, img, fh, t, which="A", k=0):
        th = (fh - self.f0) / FPS
        n_man = float(nearness(np.float32(0.72)))
        if which == "A":
            x, y = self.rig.point("arm_l", MUG_TOP, self.walk(fh, k))
        else:
            x, y = MUG_TOP_B[0] * SC, MUG_TOP_B[1] * SC + self.settle(k)
        p = self.cam.screen_point((x, y), n_man, t)
        K_steam(img, p, self.cam.scale_at(n_man, t) * 1.1, th, seed=1)
        mugs = [m for m, _ in MID_MUGS] if which == "A" else MID_MUGS_B
        n_mid = float(nearness(np.float32(0.55)))
        for j, (kxy, ph) in enumerate(zip(mugs, (0.0, 2.0))):
            p = self.cam.screen_point((kxy[0] * SC, kxy[1] * SC + 0.6 * self.settle(k)), n_mid, t)
            K_steam(img, p, self.cam.scale_at(n_mid, t) * 0.75, th + ph, seed=5 + j)

    def frame(self, f):
        fh = f - (f - self.f0) % 2
        lf = fh - self.f0
        info = {"phase": "call"}
        if fh < self.f_break:
            img = self.call.render(fh, lf, self.freeze_at, self.speaker, self.react_at)
            if fh >= self.f_break - 4:
                self.shatter.draw_cracks(img, fh - self.f_break)
            # the whole call sags darker as it dies
            dead = sum(1 for z in self.freeze_at if z is not None and fh >= z) / 6
            img = img * (1 - 0.10 * dead)
        else:
            info["phase"] = "road"
            img = self.highway(f)
            k = fh - self.f_break
            if k <= 2:                                      # impact light from the break point
                yy, xx = np.mgrid[0:img.shape[0], 0:img.shape[1]].astype(np.float32)
                cx, cy = self.shatter.center
                g = np.exp(-(((xx - cx) / 420) ** 2 + ((yy - cy) / 520) ** 2))[..., None] * (0.45 if k == 0 else 0.2)
                img = 1 - (1 - img) * (1 - g * np.float32([1.0, 0.95, 0.9]))
            if k <= 0:                                      # one drawing of flying glass, then the road is clear
                self.shatter.draw(img, self.shard_src, k)
        self.draw_year_tag(img, f)
        self.draw_data_tag(img, f, TAG, self.f_tag, size=self.tag_size)
        return img, info

    def finish_args(self, f, info):
        if info.get("phase") == "call":
            return {"bloom_strength": 0.30, "vignette": 0.26}
        return {"bloom_strength": 0.55, "vignette": 0.32}

    def events(self):
        ev = []
        for i, z in enumerate(self.freeze_at):
            if z is not None:
                ev.append((z, "freeze", {"tile": i}))
        ev.append((self.f_tag, "data_tag", {}))
        ev += [(self.f_break - 4, "crack", {}), (self.f_break - 2, "crack", {}), (self.f_break, "shatter", {})]
        k = 1
        while self.c0 + 12 * k < self.f1:
            ev.append((self.c0 + 12 * k, "step", {"foot": "L" if k % 2 == 0 else "R"}))
            k += 1
        ev += [(self.f_break + 22, "horn", {"f": 262.0, "pan": 0.6}), (self.f_back, "brakes", {}),
               (self.f_back, "horn", {"f": 330.0, "pan": -0.5}), (self.f_back + 4, "horn", {"f": 294.0, "pan": 0.3})]
        return sorted(ev, key=lambda e: e[0])

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tb = snd.at_frame(self.f_break)
        # the call: a room and a murmur of voices that thins out as tiles freeze
        call_len = tb - t0 + 0.05
        snd.bed(_faded(A.room_tone(call_len + 0.1, seed=12), 0.02, 0.05), t0, -33)
        snd.bed(call_murmur(call_len, [snd.at_frame(z) - t0 for z in self.freeze_at if z is not None]), t0, -31)
        # the highway: idling gridlock swells in under the shatter
        tail = (self.f1 / FPS + 1.4) - tb
        snd.bed(_faded(K.traffic_rumble(tail + 0.3), 0.12, 0.4), tb - 0.05, -20)
        snd.bed(_faded(A.city_hum(tail, seed=14), 0.2, 0.4), tb, -30)
        for f, kind, info in self.events():
            t = snd.at_frame(f)
            if kind == "freeze":
                col = info["tile"] % 3
                snd.sfx(K.glitch(f + info["tile"], 0.13), t, -27, (col - 1) * 0.45)
            elif kind == "data_tag":
                snd.sfx(A.tick(f, 2600), t, -26, -0.4)
            elif kind == "crack":
                snd.sfx(K.crack_tick(f), t, -19, 0.0)
            elif kind == "shatter":
                snd.sfx(K.shatter(f, 1.6), t, -11, 0.0)
                snd.sfx(A.thunk(f), t, -18, 0.0)
            elif kind == "step":
                snd.sfx(K.footstep(f), t, -22, -0.15 if info["foot"] == "L" else 0.15)
                # the crowd's steps, scattered around his
                for j in range(3):
                    snd.sfx(K.footstep(f * 7 + j), t + 0.06 + 0.09 * j, -31, (j - 1) * 0.6)
            elif kind == "horn":
                snd.sfx(K.horn(f, 0.55, info["f"]), t, -30 if f != self.f_back else -22, info["pan"])
            elif kind == "brakes":
                # air brakes letting go all down the jam: a hiss that rolls from near to far
                for j in range(3):
                    hs = A.bandpass(A.noise(0.5, 70 + j, "white"), 2500, 7000)
                    snd.sfx(_faded(hs, 0.01, 0.35), t + 0.08 * j, -24 - 4 * j, (j - 1) * 0.5)


TAG = "35 million Americans work remotely (BLS, 2026)"


def _faded(x, a, r):
    n = len(x)
    e = np.ones(n)
    na, nr = max(1, int(a * A.SR)), max(1, int(r * A.SR))
    e[:na] = np.linspace(0, 1, na)
    e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr))
    return x * e


def call_murmur(dur, freeze_times):
    """Far-off meeting chatter: band-limited voice-like bursts; each frozen tile takes some away."""
    n = int(round(dur * A.SR))
    x = A.bandpass(A.noise(dur, 61, "pink"), 250, 2600)
    n = len(x)
    t = np.arange(n) / A.SR
    syl = 0.5 + 0.5 * np.sin(2 * np.pi * 4.6 * t + 2.0 * np.sin(2 * np.pi * 0.7 * t))
    syl2 = 0.5 + 0.5 * np.sin(2 * np.pi * 3.1 * t + 1.3)
    alive = np.ones(n)
    for ft in freeze_times:
        alive -= (t >= ft) / 7.0
    e = (syl ** 2 * 0.7 + syl2 ** 3 * 0.5) * np.clip(alive, 0.08, 1)
    return _faded(x[:n] * e[:len(x)], 0.05, 0.03)


def K_steam(img, p, s, th, seed=0):
    """Rising steam wisps above a mug: soft, thin, swaying strokes (on 2s), drawn in output px."""
    H, W = img.shape[:2]
    hgt = 150 * s
    x0, y0 = int(p[0] - 60 * s), int(p[1] - hgt - 20 * s)
    x1, y1 = int(p[0] + 60 * s), int(p[1] + 6)
    if x1 <= 0 or y1 <= 0 or x0 >= W or y0 >= H:
        return
    cw, ch = x1 - x0, y1 - y0
    m = np.zeros((ch, cw), np.float32)
    rng = np.random.default_rng(seed)
    for k in range(3):
        ph = rng.uniform(0, 6.28)
        off = (k - 1) * 9 * s
        pts = []
        N = 18
        for j in range(N):
            u = j / (N - 1)
            sway = (6 + 14 * u) * s * math.sin(3.2 * u * math.pi - 3.0 * th + ph) + 8 * s * u * math.sin(0.9 * th + ph)
            pts.append((p[0] - x0 + off * (1 - u * 0.6) + sway, p[1] - y0 - u * hgt * (0.8 + 0.25 * k / 2)))
        for j in range(N - 1):
            u = j / (N - 1)
            wgt = math.sin(math.pi * min(1.0, u * 1.25)) * (1 - u) ** 0.4
            th_px = max(1, int((2 + 7 * u) * s))
            a, b = pts[j], pts[j + 1]
            cv2.line(m, (int(a[0] * 4), int(a[1] * 4)), (int(b[0] * 4), int(b[1] * 4)), float(wgt), th_px, cv2.LINE_AA, shift=2)
    m = cv2.GaussianBlur(m, (0, 0), 2.2 * s + 0.5)
    m = np.clip(m * 0.42, 0, 0.42)
    xa, ya, xb, yb = max(x0, 0), max(y0, 0), min(x1, W), min(y1, H)
    mm = m[ya - y0:yb - y0, xa - x0:xb - x0, None]
    reg = img[ya:yb, xa:xb]
    img[ya:yb, xa:xb] = 1 - (1 - reg) * (1 - mm * np.float32([0.92, 0.90, 0.98]))


def make(ctx):
    return Shot(ctx)
