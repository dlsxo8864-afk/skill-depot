"""Shot 13, the question: "So if you had to give up one thing that isn't AI, what would it be?"

A kid on a rooftop ledge, dead phone in hand, boots dangling over the city. The question is lettered
large in the open sky (the hook title's design, bookending the episode); ten small hand-drawn icons
with one-word labels pop into a 5 x 2 grid on 2s; after the last word the few windows still lit in
the city go out one by one and the frame holds for 2 s. The ChatGPT tile's cursor keeps blinking.
"""
import math
from functools import cached_property

import cv2
import numpy as np
from PIL import Image, ImageDraw

from whatif import audio as A
from whatif import layers as L
from whatif import overlays as O
from whatif import text as T
from whatif.camera import ParallaxCamera, composite_into, deform_sprite
from whatif.config import FPS, OUT_H, OUT_W, safe_box
from whatif.fx2d import painted_haze
from whatif.poses import PoseSwap
from whatif.shotkit import BaseShot
from whatif.timing import Track, on2s

STEM = __name__.split(".")[-1]
SC = L.WORK_SCALE
EMBER_ORANGE = (255, 146, 72)

# ------------------------------------------------------------------ spec (key px, 1520 x 2701)
PLANES = [
    L.PlaneSpec("sky", 0.00, 0.095, fill="full"),
    L.PlaneSpec("city", 0.095, 0.30, fill="full"),
    L.PlaneSpec("kid", 0.30, 0.80, radius=80),
    L.PlaneSpec("roof", 0.80, 1.01, radius=80),
]
SPRITES = [
    L.SpriteSpec("boot_l", 2, [(600, 2330), (700, 2330), (722, 2420), (726, 2542), (650, 2548), (603, 2492), (596, 2400)],
                 dmin=0.45, pivot=(652, 2180), anchor=(660, 2540, 652, 2330), fill_own_plane=True),
    L.SpriteSpec("boot_r", 2, [(735, 2330), (810, 2320), (832, 2420), (866, 2500), (866, 2582), (800, 2592), (730, 2542),
                               (724, 2440)],
                 dmin=0.45, pivot=(786, 2180), anchor=(800, 2565, 790, 2330), fill_own_plane=True),
    L.SpriteSpec("phone_hand", 2, [(664, 2112), (762, 2118), (802, 2230), (797, 2304), (738, 2312), (688, 2262), (666, 2180)],
                 dmin=0.45, pivot=(702, 2108), anchor=(765, 2295, 702, 2120), fill_own_plane=True),
]
# pose B (y12_cta_poseB.png): the kid hunches. Hull of both poses (key px); the depth split put the
# edge of his hood partly in the sky and city planes, so the swap is applied to those planes too.
KID = [(452, 1480), (542, 1475), (601, 1505), (1015, 2193), (1015, 2646), (1005, 2662), (463, 2665), (447, 2655),
       (405, 1811), (405, 1550), (423, 1502)]
WINDOW_REGION = (0, 1500, 1520, 2100)        # city rows where lit windows are searched (key px)

ITEMS = [("TikTok", "feed"), ("Netflix", "tv"), ("Remote\nwork", "laptop"), ("Twitch", "live"), ("Gaming", "pad"),
         ("Spotify", "phones"), ("Photos", "photo"), ("Cards", "card"), ("Retirement", "jar"), ("ChatGPT", "chat")]


def nearness(d):
    return np.clip(d / 0.9, 0, 1) ** 0.8


# ------------------------------------------------------------------ hand-drawn icons
def _wob(rng, pts, amt):
    return [(x + rng.normal(0, amt), y + rng.normal(0, amt)) for x, y in pts]


def _icon(kind, S=256, seed=0):
    """Line icon drawn at S px (2x): returns (line alpha, accent alpha) float32 in 0..1. Generic
    drawings only; no logos. Lines wobble slightly like a quick ink drawing."""
    rng = np.random.default_rng(seed)
    ln = Image.new("L", (S, S), 0)
    ac = Image.new("L", (S, S), 0)
    d, e = ImageDraw.Draw(ln), ImageDraw.Draw(ac)
    w = max(8, S // 15)                      # a loaded brush, not a pen line
    s = S / 256

    def P(*xy):
        return [(x * s, y * s) for x, y in xy]

    def poly(dr, pts, width=w, closed=True):
        pts = _wob(rng, P(*pts), 1.2 * s)
        if closed:
            pts = pts + [pts[0]]
        dr.line(pts, fill=255, width=width, joint="curve")

    def rrect(dr, box, r, width=w, fill=None):
        x0, y0, x1, y1 = [v * s for v in box]
        dr.rounded_rectangle((x0, y0, x1, y1), radius=r * s, outline=255, width=width, fill=fill)

    if kind == "feed":                      # phone with a vertical feed: play mark and a note
        rrect(d, (78, 30, 178, 226), 18)
        d.line(P((112, 44), (144, 44)), fill=255, width=w // 2 + 2)
        poly(e, [(114, 100), (150, 124), (114, 148)], width=w)
        e.ellipse([(138 * s, 168 * s), (156 * s, 184 * s)], fill=255)
        e.line(P((154, 176), (154, 146), (166, 150)), fill=255, width=w // 2 + 2)
        d.line(P((98, 200), (158, 200)), fill=255, width=w // 2)
    elif kind == "tv":                      # television on a stand with a play mark
        rrect(d, (34, 54, 222, 182), 14)
        d.line(P((104, 182), (92, 214)), fill=255, width=w)
        d.line(P((152, 182), (164, 214)), fill=255, width=w)
        d.line(P((80, 214), (176, 214)), fill=255, width=w)
        poly(e, [(110, 92), (154, 118), (110, 144)], width=w)
    elif kind == "laptop":                  # laptop with a 2 x 2 video-call grid
        rrect(d, (52, 52, 204, 160), 10)
        d.line(P((30, 176), (226, 176)), fill=255, width=w)
        d.line(P((30, 176), (44, 196), (212, 196), (226, 176)), fill=255, width=w, joint="curve")
        for cx, cy in [(92, 82), (164, 82), (92, 130), (164, 130)]:
            e.ellipse([((cx - 9) * s, (cy - 15) * s), ((cx + 9) * s, (cy + 3) * s)], fill=255)
            e.pieslice([((cx - 20) * s, (cy + 4) * s), ((cx + 20) * s, (cy + 36) * s)], 180, 360, fill=255)
        d.line(P((128, 60), (128, 152)), fill=255, width=w // 2)
        d.line(P((60, 106), (196, 106)), fill=255, width=w // 2)
    elif kind == "live":                    # webcam with signal arcs and a live dot
        d.ellipse([(88 * s, 70 * s), (168 * s, 150 * s)], outline=255, width=w)
        d.ellipse([(114 * s, 96 * s), (142 * s, 124 * s)], outline=255, width=w)
        d.line(P((128, 150), (128, 186)), fill=255, width=w)
        d.line(P((92, 196), (164, 196)), fill=255, width=w)
        for r in (62, 86):
            d.arc([((128 - r) * s, (110 - r) * s), ((128 + r) * s, (110 + r) * s)], 200, 250, fill=255, width=w // 2 + 2)
            d.arc([((128 - r) * s, (110 - r) * s), ((128 + r) * s, (110 + r) * s)], 290, 340, fill=255, width=w // 2 + 2)
        e.ellipse([(186 * s, 168 * s), (212 * s, 194 * s)], fill=255)
    elif kind == "pad":                     # game controller: d-pad and two buttons
        pts = [(58, 96), (198, 96), (226, 178), (204, 196), (170, 160), (86, 160), (52, 196), (30, 178)]
        poly(d, pts)
        d.line(P((84, 116), (84, 144)), fill=255, width=w)
        d.line(P((70, 130), (98, 130)), fill=255, width=w)
        e.ellipse([(160 * s, 112 * s), (178 * s, 130 * s)], fill=255)
        e.ellipse([(180 * s, 132 * s), (198 * s, 150 * s)], fill=255)
    elif kind == "phones":                  # headphones with a note
        d.arc([(46 * s, 50 * s), (210 * s, 214 * s)], 180, 360, fill=255, width=w)
        rrect(d, (38, 132, 82, 206), 14)
        rrect(d, (174, 132, 218, 206), 14)
        e.ellipse([(110 * s, 150 * s), (132 * s, 170 * s)], fill=255)
        e.line(P((130, 160), (130, 112), (148, 120)), fill=255, width=w // 2 + 3)
    elif kind == "photo":                   # framed picture: mountains and a sun
        rrect(d, (40, 56, 216, 200), 10)
        poly(d, [(56, 182), (108, 112), (140, 150), (162, 128), (200, 182)], closed=False)
        e.ellipse([(160 * s, 76 * s), (190 * s, 106 * s)], fill=255)
    elif kind == "card":                    # payment card: stripe and chip
        rrect(d, (34, 66, 222, 190), 14)
        d.line(P((34, 96), (222, 96)), fill=255, width=w + 4)
        rrect(e, (56, 118, 92, 146), 5, width=w // 2 + 2)
        d.line(P((110, 164), (196, 164)), fill=255, width=w // 2)
    elif kind == "jar":                     # savings jar with coins
        poly(d, [(84, 70), (172, 70), (172, 84), (186, 104), (186, 206), (70, 206), (70, 104), (84, 84)])
        d.line(P((90, 56), (166, 56)), fill=255, width=w)
        for cx, cy in [(104, 186), (138, 186), (170, 186), (120, 164), (154, 164), (136, 142)]:
            e.ellipse([((cx - 14) * s, (cy - 9) * s), ((cx + 14) * s, (cy + 9) * s)], outline=255, width=w // 2 + 2)
    elif kind == "chat":                    # speech bubble with a text cursor (the cursor blinks)
        poly(d, [(40, 60), (216, 60), (216, 168), (112, 168), (78, 204), (82, 168), (40, 168)])
        d.line(P((66, 104), (150, 104)), fill=255, width=w // 2 + 1)
        d.line(P((66, 132), (124, 132)), fill=255, width=w // 2 + 1)
        e.rectangle([(162 * s, 90 * s), (174 * s, 146 * s)], fill=255)
    la = np.asarray(ln, np.float32) / 255
    aa = np.asarray(ac, np.float32) / 255
    return la, aa


def _brush(alpha, seed, angle=0.6):
    """Turn a drawn line alpha into a dry-brush mark: ragged bristle edges, pressure variation and
    small skips where the brush runs dry (crisp threshold, no blur)."""
    a = cv2.GaussianBlur(alpha, (0, 0), 1.4)
    n = L.brush_noise(alpha.shape, seed, scale=1.4, angle=angle, stretch=9)
    big = L.brush_noise(alpha.shape, seed + 1, scale=7, angle=angle, stretch=3)
    m = np.clip((a - 0.5 + 0.16 * n - 0.10 * np.clip(big - 0.8, 0, None)) * 4.0 + 0.5, 0, 1)
    m = m * np.clip((a - 0.12) * 5.0, 0, 1)            # bristle breakup only along the stroke, no speckle
    return m * np.clip(0.82 + 0.10 * big, 0.6, 1.0)


def _paint_rgba(alpha, color, seed, angle=0.6):
    """A brush mark in `color` (0-255) with the painting's texture: value streaks along the stroke."""
    h, w = alpha.shape
    n = L.brush_noise((h, w), seed + 7, scale=2.0, angle=angle, stretch=14)
    rgb = np.float32(color)[None, None, :] / 255 * (0.92 + 0.07 * n[..., None])
    return np.dstack([np.clip(rgb, 0, 1), alpha]).astype(np.float32)


def _tile(name, kind, idx, size=132, cursor_on=True):
    """One CTA item: the icon as cream dry-brush marks with an ember accent, straight on the night
    sky (no box), a soft dark under-glow for legibility, and a large label (min cap height)."""
    S = size * 2
    la, aa = _icon(kind, S, seed=idx)
    if kind == "chat" and not cursor_on:
        aa = aa * 0
    ang = 0.5 + 0.3 * math.sin(idx * 1.7)
    la = cv2.resize(_brush(la, 300 + idx, ang), (size, size), interpolation=cv2.INTER_AREA)
    aa = cv2.resize(_brush(aa, 400 + idx, ang), (size, size), interpolation=cv2.INTER_AREA)
    lines = [O._text_alpha(ln, T.font("display", 40), min_cap=34) for ln in name.split("\n")]   # condensed so 5 fit; cap 34 px (11 px at 360)
    step = lines[0].shape[0] + 6
    lab = np.zeros((step * (len(lines) - 1) + lines[-1].shape[0], max(x.shape[1] for x in lines)), np.float32)
    for k, ln in enumerate(lines):                                 # centred lines
        ox = (lab.shape[1] - ln.shape[1]) // 2
        lab[k * step:k * step + ln.shape[0], ox:ox + ln.shape[1]] = ln
    lab_rgba, lp = T.styled_text_rgba(lab, O.CREAM, seed=30 + idx, shadow_off=(2, 3), soft_shadow=6,
                                      shadow_strength=0.75, grad=0.04)
    pad = 24
    H = size + 2 * pad + lab_rgba.shape[0] - 2 * lp + 10
    W = max(size + 2 * pad, lab_rgba.shape[1])
    canvas = np.zeros((H, W, 4), np.float32)
    cx = (W - size) // 2
    # under-glow: the ink's own shape, blurred, in deep night blue (reads on any sky, no box)
    both = np.maximum(la, aa)
    sh = np.zeros((H, W), np.float32)
    sh[pad + 4:pad + 4 + size, cx + 2:cx + 2 + size] = both
    sh = np.clip(cv2.GaussianBlur(sh, (0, 0), 7) * 1.6, 0, 1) * 0.62
    shadow = np.dstack([np.broadcast_to(np.float32([0.03, 0.04, 0.08]), (H, W, 3)), sh])
    T.over_rgba(canvas, shadow, 0, 0)
    T.over_rgba(canvas, _paint_rgba(la, O.CREAM, idx, ang), cx, pad)
    T.over_rgba(canvas, _paint_rgba(aa, EMBER_ORANGE, idx + 50, ang), cx, pad)
    T.over_rgba(canvas, lab_rgba, (W - lab_rgba.shape[1]) // 2, size + 2 * pad - lp - 8)
    return canvas


def _title_line(text, size, color, seed, max_w):
    fnt = T.font("display", size)
    tw, th, ox, oy = T.text_size(fnt, text)
    if tw > max_w:
        fnt = T.font("display", int(size * max_w / tw))
        tw, th, ox, oy = T.text_size(fnt, text)
    pim = Image.new("L", (tw + 4, th + 4), 0)
    ImageDraw.Draw(pim).text((2 - ox, 2 - oy), text, font=fnt, fill=255)
    a = np.asarray(pim, np.float32) / 255
    rgba, pad = T.styled_text_rgba(a, color, seed=seed, shadow_off=(4, 6), soft_shadow=12,
                                   grad=0.12 if color == O.CREAM else 0.18)
    return rgba, pad, th


class Shot(BaseShot):
    def __init__(self, ctx):
        super().__init__(ctx)
        key, depth = ctx.key_paths()
        L.build(STEM, key, depth, PLANES, SPRITES)
        self.lay = L.Layers(STEM)
        W, H = self.lay.W, self.lay.H
        d = ctx.dur
        self.f_line1 = ctx.f("if")
        self.f_line2 = ctx.f("one")
        self.f_grid = ctx.f("thing")
        self.f_q = ctx.f("what")
        self.f_last = ctx.f("be?", at="e")
        self.pose = PoseSwap.for_shot(ctx, STEM, region=KID)
        self.swaps = [(self.f_line2 + 6, "B")]                 # he sinks lower as the question builds
        self.cam = ParallaxCamera(
            W, H, nearness=nearness, focus=Track([(0, (W * 0.5, H * 0.47)), (d, (W * 0.5, H * 0.45), "inout")]),
            zoom=Track([(0, 1.0), (d, 1.05, "out")]),
            push=Track([(0, 0.0), (d, 0.055, "out")]),
            rise=Track([(0, 0.0), (d, -12.0, "out")]))

    # ------------------------------------------------------------ prepared
    @cached_property
    def planes(self):
        out = [{"rgb": p["rgb"].astype(np.float32) / 255, "a": p["a"].astype(np.float32) / 255,
                "n": nearness(p["d"].astype(np.float32) / 65535)} for p in self.lay.planes]
        self._prep_windows(out)
        return out

    def _prep_windows(self, planes):
        """Find the city's lit windows (both far planes), make 'off' plates, order them for lights-out."""
        self.windows = []
        x0, y0, x1, y1 = [int(v * SC) for v in WINDOW_REGION]
        for pi in (0, 1):
            pl = planes[pi]
            rgb = pl["rgb"]
            r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
            lum = 0.3 * r + 0.6 * g + 0.1 * b
            bg = cv2.GaussianBlur(lum, (0, 0), 12)
            warm = (r - b > 0.06) & (r > 0.28) & (r > g) & (lum - bg > 0.03) & (pl["a"] > 0.5)
            reg = np.zeros_like(warm)
            reg[y0:y1, x0:x1] = True
            # anything the kid / ledge plane covers (its rim light is not a window)
            reg &= cv2.dilate((planes[2]["a"] > 0.3).astype(np.uint8), np.ones((15, 15), np.uint8)) == 0
            warm = (warm & reg).astype(np.uint8)
            # blobs closer than ~20 key px are one window (panes of the same frame)
            groups = cv2.dilate(warm, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (17, 17)))
            n, lab, stats, cents = cv2.connectedComponentsWithStats(groups)
            grow = np.zeros(rgb.shape[:2], np.float32)
            found = []
            for i in range(1, n):
                m = ((lab == i) & (warm > 0)).astype(np.uint8)
                area = int(m.sum())
                if area < 4:
                    continue
                m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
                grow = np.maximum(grow, m)
                found.append({"m": m, "c": cents[i], "plane": pi, "area": area})
            if not found:
                continue
            off = L.textured_fill(rgb, grow < 0.5, seed=60 + pi, amp_scale=0.5)
            off = off * np.float32([0.92, 0.94, 1.0])
            pl["off"] = off
            for w in found:
                g_ = cv2.GaussianBlur(w["m"].astype(np.float32), (0, 0), 2.0)
                ys, xs = np.where(g_ > 0.01)
                w["box"] = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
                w["g"] = g_[w["box"][1]:w["box"][3], w["box"][0]:w["box"][2]]
                del w["m"]
                self.windows.append(w)
        # out one by one after the last word: the small far lights first (quick), the two big
        # windows last with more room, the final one ~0.5 s before the end
        self.windows.sort(key=lambda w: w["area"])
        f = self.f_last + 4
        for k, w in enumerate(self.windows):
            w["off_f"] = f
            f += 10 if w["area"] > 40 else 6
        over = self.windows[-1]["off_f"] - (self.f1 - 12) if self.windows else 0
        if over > 0:
            for w in self.windows:
                w["off_f"] -= over + over % 2

    @cached_property
    def haze(self):
        return painted_haze(int(420 * SC), int(2400 * SC), seed=91, blobs=8, softness=34)

    @cached_property
    def title(self):
        x0, y0, x1, y1 = safe_box()
        mw = x1 - x0
        out = []
        y = y0 + 20
        for text, size, color, gap, key in [("IF YOU HAD TO GIVE UP", 70, O.CREAM, 4, "l1"),
                                            ("ONE THING THAT ISN'T AI,", 70, O.CREAM, 10, "l2"),
                                            ("WHAT WOULD IT BE?", 150, EMBER_ORANGE, 0, "q")]:
            rgba, pad, th = _title_line(text, size, color, seed=len(out) + 21, max_w=mw)
            out.append({"rgba": rgba, "x": x0 - pad, "y": y - pad, "key": key})
            y += th + gap + 16
        self.title_bottom = y
        return out

    @cached_property
    def tiles(self):
        """Ten brush-drawn items in a 5 x 2 grid (the specification), in narration order."""
        _ = self.title                                   # sets title_bottom
        x0, y0, x1, y1 = safe_box()
        cols = 5
        pitch = (x1 - x0) / cols
        y = self.title_bottom + 30
        out = []
        rows = [ITEMS[0:5], ITEMS[5:10]]
        i = 0
        for r, row in enumerate(rows):
            rh = 0
            for c, (name, kind) in enumerate(row):
                rgba = _tile(name, kind, i, size=118)
                cx = x0 + pitch * (c + 0.5)
                out.append({"rgba": rgba, "x": cx - rgba.shape[1] / 2, "y": y, "f_in": self.f_grid + 2 * i,
                            "kind": kind, "name": name})
                rh = max(rh, rgba.shape[0])
                i += 1
            y += rh + 6
        self.chat_off = _tile("ChatGPT", "chat", 9, size=118, cursor_on=False)
        return out

    # ------------------------------------------------------------ frame
    def frame(self, f):
        t = self.ctx.local(f)
        th = on2s(f - self.f0)
        fh = f - f % 2
        rps = []
        for i, p in enumerate(self.planes):
            rgb, a, n = p["rgb"], p["a"], p["n"]
            st = PoseSwap.state(f, self.swaps) if self.pose else "A"
            if self.pose and i <= 2:
                n = self.pose.nearness(n, a, st)
            if i <= 1:
                rgb = self._windows_into(p, i, fh)
                if self.pose:                    # his old outline also bled into the planes behind him
                    rgb, a = self.pose.apply(rgb, a, st)
                if i == 1:
                    rgb = self._haze_into(rgb, th)
                rgb = self._twinkle(rgb, th) if i == 0 else rgb
            if i == 2:
                rgb, a = rgb.copy(), a.copy()
                for s in self.lay.sprites:
                    patch, x0, y0 = deform_sprite(s, **(self._pose(s["name"], th) if st == "A" else {}))
                    composite_into(rgb, a, patch, x0, y0)
                if self.pose:
                    rgb, a = self.pose.apply(rgb, a, st)
            rps.append({"rgb": rgb, "a": a, "n": n})
        img = self.cam.render(rps, t)
        self._overlays(img, f, t)
        n_out = sum(1 for w in self.windows if fh >= w["off_f"])
        return img, {"windows_out": n_out}

    def _pose(self, name, th):
        if name == "boot_r":                 # slow idle swing of the dangling boots
            return {"angle_deg": 3.2 * math.sin(th * 2 * math.pi / 2.6 + 0.4)}
        if name == "boot_l":
            return {"angle_deg": 2.4 * math.sin(th * 2 * math.pi / 2.6 + 2.1)}
        if name == "phone_hand":             # the dead phone dangles and turns a touch
            return {"angle_deg": 1.6 * math.sin(th * 2 * math.pi / 3.1 + 1.0)}
        return {}

    def _windows_into(self, p, pi, fh):
        if "off" not in p:
            return p["rgb"]
        rgb = p["rgb"].copy()
        for w in self.windows:
            if w["plane"] != pi:
                continue
            d = fh - w["off_f"]
            if d < 0:
                continue
            k = {0: 0.55, 2: 0.85}.get(d, 1.0)          # a short flicker as it dies, on 2s
            x0, y0, x1, y1 = w["box"]
            g = w["g"][..., None] * k
            rgb[y0:y1, x0:x1] = rgb[y0:y1, x0:x1] * (1 - g) + p["off"][y0:y1, x0:x1] * g
        return rgb

    def _haze_into(self, rgb, th):
        h = self.haze
        rgb = rgb.copy()
        y0 = int(1640 * SC)
        x = int((th * 18) % (h.shape[1] - rgb.shape[1]))
        band = h[:, x:x + rgb.shape[1]][..., None] * 0.26
        seg = rgb[y0:y0 + h.shape[0]]
        col = np.float32([0.16, 0.42, 0.42])
        rgb[y0:y0 + h.shape[0]] = seg * (1 - band) + (1 - (1 - seg) * (1 - col)) * band
        return rgb

    @cached_property
    def stars(self):
        sky = self.planes[0]["rgb"]
        top = sky[: int(sky.shape[0] * 0.45)]
        bg = cv2.GaussianBlur(top, (0, 0), 6)
        m = ((top.max(2) - bg.max(2)) > 0.15).astype(np.uint8)
        n, lab, stats, cents = cv2.connectedComponentsWithStats(m)
        rng = np.random.default_rng(3)
        return [(c, rng.uniform(0, 6.28)) for c, st in zip(cents[1:], stats[1:]) if st[cv2.CC_STAT_AREA] < 30]

    def _twinkle(self, rgb, th):
        if not self.stars:
            return rgb
        rgb = rgb.copy()
        for (cx, cy), ph in self.stars:
            k = 0.75 + 0.45 * math.sin(th * 5.0 + ph)
            x, y = int(cx), int(cy)
            sl = rgb[max(y - 3, 0):y + 4, max(x - 3, 0):x + 4]
            bg = sl.min(axis=(0, 1))
            rgb[max(y - 3, 0):y + 4, max(x - 3, 0):x + 4] = bg + (sl - bg) * k
        return rgb

    def _overlays(self, img, f, t):
        fh = f - f % 2
        # the lettering hangs in the sky: it drifts with the sky as the camera pushes (half rate)
        z = self.cam.zoom(t)
        C = np.float32([OUT_W / 2, OUT_H * 0.45])

        def drift(x, y, h, w):
            c = np.float32([x + w / 2, y + h / 2])
            c2 = C + (c - C) * (1 + 0.5 * (z - 1))
            return c2[0] - w / 2, c2[1] - h / 2

        glow = (0.42, 0.30, 0.70)
        starts = {"l1": self.f_line1, "l2": self.f_line2, "q": self.f_q}
        for it in self.title:
            x, y = drift(it["x"], it["y"], it["rgba"].shape[0], it["rgba"].shape[1])
            O.draw_pop(img, it["rgba"], x, y, f, starts[it["key"]], origin=(30, it["rgba"].shape[0] / 2),
                       glow=(0.9, 0.45, 0.2) if it["key"] == "q" else glow)
        for tl in self.tiles:
            rgba = tl["rgba"]
            if tl["kind"] == "chat" and fh >= tl["f_in"] + 8 and (fh // 6) % 2 == 1:
                rgba = self.chat_off                     # the cursor in the chat bubble blinks
            x, y = drift(tl["x"], tl["y"], rgba.shape[0], rgba.shape[1])
            O.draw_pop(img, rgba, x, y, f, tl["f_in"], origin=(rgba.shape[1] / 2, rgba.shape[0] * 0.45), glow=glow)

    # ------------------------------------------------------------ framework hooks
    def finish_args(self, f, info):
        return {"bloom_strength": 0.45, "vignette": 0.36}

    def events(self):
        ev = [(self.f0, "cut", {}), (self.f_line1, "line1", {}), (self.f_line2, "line2", {})]
        ev += [(tl["f_in"], "icon", {"name": tl["name"]}) for tl in self.tiles]
        ev.append((self.f_q, "question", {}))
        ev += [(w["off_f"], "window_off", {"k": k}) for k, w in enumerate(self.windows)]
        if self.pose:
            ev += [(fs, "pose_" + to, {}) for fs, to in self.swaps]
        return ev

    def sound(self, snd):
        t0, dur = snd.shot_span()
        tt = A.t_axis(dur + 1.5)
        wind = A.bandpass(A.noise(dur + 1.5, 71, "pink"), 250, 1600) * (0.55 + 0.45 * np.sin(2 * np.pi * 0.18 * tt + 1) ** 2)
        fade = np.clip((dur + 1.4 - tt) / 1.2, 0, 1)
        snd.bed(wind * fade, t0, -27, pan=-0.2)
        snd.bed(A.city_hum(dur + 1.5, seed=72) * fade, t0, -33, pan=0.3)
        snd.sfx(A.thunk(81), self.f_line1 / FPS, -24)
        snd.sfx(A.thunk(82), self.f_line2 / FPS, -24)
        # each icon lands with a small pitched pop (a rising pentatonic run)
        scale = [523.3, 587.3, 659.3, 784.0, 880.0, 1046.5, 1174.7, 1318.5, 1568.0, 1760.0]
        for k, tl in enumerate(self.tiles):
            ft = tl["f_in"] / FPS
            snd.sfx(A.tick(k + 90, 2600), ft, -25, -0.6 + 0.13 * k)
            snd.sfx(A.bell(scale[k], 0.35, seed=k), ft, -29, -0.6 + 0.13 * k)
        snd.sfx(A.hit(seed=83), self.f_q / FPS, -17)
        snd.sfx(A.bell(261.6, 1.8, seed=84), self.f_q / FPS, -24)
        for k, w in enumerate(self.windows):
            snd.sfx(A.soft_click(1300 * (0.88 ** k), 95 + k), w["off_f"] / FPS, -20 - k, 0.4 - 0.25 * k)


def make(ctx):
    return Shot(ctx)
