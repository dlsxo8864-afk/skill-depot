"""Layer, sprite and placard geometry for shot 1 (hook). Coordinates are key-image px (1520x2688)."""
from whatif.config import ASSETS, LAYER_CACHE
from whatif.layers import PlaneSpec, SpriteSpec

SHOT = "s01_hook"
KEY = ASSETS / "key" / "hook_protest_key.png"
DEPTH = LAYER_CACHE / "hook_protest_depth.png"

PLANES = [
    PlaneSpec("sky", 0.0, 0.035, fill="full"),
    PlaneSpec("building", 0.035, 0.13, fill="full"),
    PlaneSpec("midcrowd", 0.13, 0.38, radius=60),
    PlaneSpec("nearcrowd", 0.38, 0.70, radius=70),
    PlaneSpec("foreground", 0.70, 1.01, radius=70),
]

SPRITES = [
    SpriteSpec("plac_L", 3, [(0, 820), (70, 832), (455, 995), (385, 1405), (200, 1395), (140, 1530), (60, 1530), (0, 1480)],
               dmin=0.30, dmax=0.52, pivot=(95, 1600), anchor=(120, 1420, 100, 1528)),
    SpriteSpec("plac_C", 2, [(715, 1290), (1095, 1235), (1085, 1505), (965, 1508), (968, 1665), (878, 1665), (880, 1525), (720, 1560)],
               dmin=0.17, pivot=(918, 1650), anchor=(918, 1560, 918, 1655)),
    SpriteSpec("plac_R", 2, [(1190, 1350), (1520, 1378), (1520, 1665), (1392, 1655), (1375, 1705), (1332, 1705), (1328, 1645), (1185, 1645)],
               dmin=0.17, pivot=(1355, 1710), anchor=(1355, 1630, 1355, 1700)),
    SpriteSpec("fist_C", 2, [(490, 1345), (632, 1345), (635, 1475), (575, 1545), (545, 1640), (415, 1640), (462, 1515)],
               dmin=0.2, pivot=(455, 1660), anchor=(530, 1500, 462, 1625)),
    SpriteSpec("fist_R", 2, [(1022, 1582), (1098, 1586), (1098, 1662), (1055, 1722), (1012, 1745), (985, 1702), (1018, 1648)],
               dmin=0.115, pivot=(1000, 1765), anchor=(1045, 1660, 1005, 1738)),
    SpriteSpec("head_beanie", 2, [(735, 1695), (995, 1695), (1005, 1900), (965, 1965), (760, 1965), (728, 1880)],
               dmin=0.25, pivot=(862, 2010), anchor=(862, 1880, 862, 1962)),
    SpriteSpec("head_curly", 2, [(492, 1785), (702, 1778), (708, 1962), (508, 1992)],
               dmin=0.17, pivot=(600, 2060), anchor=(600, 1925, 600, 1988)),
]

# Placard faces for slogans: approximate quads (TL, TR, BR, BL) refined at build time.
PLACARDS = {
    "plac_L": {"bbox": (0, 830, 450, 1400), "lines": ["NO MORE", "DATA", "CENTERS"], "size": 1.0, "u": (0.30, 0.95)},
    "plac_C": {"bbox": (715, 1240, 1095, 1560), "lines": ["PULL THE", "PLUG"], "size": 1.0, "u": (0.17, 0.94)},
    "plac_R": {"bbox": (1185, 1350, 1520, 1650), "lines": ["NO MORE", "DATA", "CENTERS"], "size": 1.0, "u": (0.06, 0.78)},
}
# Small far placards get quick scrawls painted straight into the building plane.
FAR_PLACARDS = {
    "far1": {"bbox": (330, 1520, 442, 1630), "lines": ["UNPLUG"]},
    "far2": {"bbox": (645, 1615, 790, 1725), "lines": ["NO!"]},
    "far3": {"bbox": (1120, 1635, 1255, 1730), "lines": ["NOT HERE"]},
}

# Light strips live on the facade above this key-image y; street lamps are listed explicitly.
STRIP_MAX_Y = 1150
LAMPS = [(1200, 1110, 1320, 1180), (300, 1395, 415, 1440), (1070, 1535, 1150, 1565), (670, 1560, 720, 1585), (1020, 1460, 1070, 1480)]
