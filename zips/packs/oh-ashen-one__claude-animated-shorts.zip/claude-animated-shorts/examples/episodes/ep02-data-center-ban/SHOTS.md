# Episode 2 shot list: "What if every state banned new data centers?"

Vertical 1080x1920, 24 fps container. Look: stop-motion claymation (see `prompts/_style.txt`). Narration: Kokoro `af_nicole` at speed 1.5, one wav per line in `assets/voice/nicole/` with `lines.json`. Total at least 61 s; expected about 70 s.

## How claymation differs from episode 1

- Everything is on 2s, including the camera: the whole picture updates 12 times a second, as if each frame were photographed. No smooth camera moves, no motion blur, no bloom.
- Acting is replacement animation: each shot has a key image (pose A) and one or more painted pose variants (`<stem>_poseB.png`, sometimes `_poseC.png`). Swap between held poses, with one in-between where it helps. Small squash and stretch, blinks and wobbles are welcome.
- Stop-motion tells: tiny light flicker between frames, slight jitter of props that were "touched", clay surfaces that crawl a little.
- Miniature photography: shallow depth of field, a little lens vignette, fine sensor grain. No painterly texture.
- All added text and interface elements are physical things in the set: clay letters, paper cut-outs on sticks, cardboard signs, rubber stamps, with real-looking contact shadows and the scene's light. Year tags are little clay or card signposts. Nothing may look like a digital caption.
- Sound is tactile and playful: clay squelches, wood knocks, paper rustles, small percussion, a light plucked or whistled bed. Narration always on top.

## Overlay rules

- Year sign in the top-left of each year shot ("YEAR 1" to "YEAR 10"), one design reused.
- One data card per shot with the real number, shown while it is spoken.
- Invented figures carry a small "scenario" stamp.
- No real brand logos, flags or trademarked interfaces. Brand and place names appear only as plain text on cards.
- Text stays out of the bottom 22% and right 14% of the frame, 6% from the top and left; minimum cap height 30 px at 1080 wide.
- The key images are about 941x1672 or 992x1586: fit them to 1080x1920 by scaling and cropping or extending, never by stretching.

| # | File stem | Key image | Narration | Event (sync word) | Cards and signs |
|---|---|---|---|---|---|
| 0 | s01_hook | y00_hook_key.png | What if every state banned new data centers? | The data center slides the rest of the way into the ballot box and the slot snaps shut ("banned"); crowd jumps | Title in clay letters: the question; card: "This month, 40 of 41 local votes went against data centers" + "CNBC, Nov 4, 2026"; placards lettered "NOT HERE", "NO MORE" |
| 1 | s02_year1 | y01_chatbot_key.png | The first thing you'd notice is your chatbot. ChatGPT's nine hundred million users would have nowhere new to go. | The ticket machine spits the ticket ("chatbot"); the number is stamped on it ("nowhere") | YEAR 1; card "ChatGPT: 900 million weekly users"; on the ticket: "You are number 2,000,000 in line" + scenario stamp; laptop screen shows a simple invented chat box with "Please wait" |
| 2 | s03_year2 | y02_cloud_key.png | Then the cloud would cost more. Only one point four percent of data center space is empty. | Gavel slams ("more"); paddles shoot up | YEAR 2; card "Empty data center space: 1.4%, a record low (CBRE, 2026)"; paddles show rising bids with a scenario stamp |
| 3 | s04_year3 | y03_power_key.png | Your power bill would climb more slowly. Data centers drove most of a record price jump on the biggest grid. | The meter disc slows from a blur to a crawl ("slowly"); the family exhales | YEAR 3; card "63% of the 2025-26 capacity price jump on PJM, the largest US grid (market monitor)"; the bill in the father's hand gets a smaller total with a scenario stamp |
| 4 | s05_year4 | y04_water_key.png | Your town would keep more water. Data centers drank seventeen billion gallons in one year. | The straw is yanked out with a pop ("water"); the reservoir refills; ducks jump in | YEAR 4; card "17.4 billion gallons in 2023 (Berkeley Lab)" |
| 5 | s06_year5 | y05_cranes_key.png | But the cranes would stop on a fifty billion dollar a year building boom. | Cranes jerk to a halt and the loads swing ("stop"); workers slump | YEAR 5; card "Data center construction: over $50 billion a year (Census data, 2026)" |
| 6 | s07_year6 | y06_taxes_key.png | Your property taxes could rise. In one Virginia county, data centers pay almost half. | The bill shoots out of the mailbox and unrolls down the street ("rise") | YEAR 6; card "Loudoun County, Virginia: almost half of property tax revenue"; figures printed down the bill with a scenario stamp |
| 7 | s08_year7 | y07_retire_key.png | Your retirement would feel it. Five companies are spending eight hundred billion dollars on this. | The five towers step off the see-saw ("five"); the piggy bank end crashes down and coins burst out | YEAR 7; card "5 companies, about $800 billion in 2026" |
| 8 | s09_year8 | y08_move_key.png | And the data centers wouldn't vanish. They'd move, to places like Abu Dhabi. | The queue shuffles forward on each beat; the gate stamp comes down ("move") | YEAR 8; departures board in clay letters: "ABU DHABI", "5 GW campus planned"; boarding passes stamped |
| 9 | s10_year9 | y09_china_key.png | China wouldn't pause. It plans twenty-eight more gigawatts by twenty thirty. | Right side builds in fast replacement steps while the left side only gathers dust ("pause") | YEAR 9; card "China: 28 GW more planned by 2030 (Rystad)"; small card signs "HERE" on the left and "CHINA" on the right |
| 10 | s11_year10 | y10_abroad_key.png | By year ten, your photos, your bank and your AI could live in another country. | Photos ("photos"), coins ("bank") and the speech bubble ("AI") leave the phone one after another along the cable | YEAR 10; scenario stamp |
| 11 | s12_catch | y11_catch_key.png | A ban wouldn't end data centers. It would decide where they're built. | The hand lifts the model ("end") and carries it across ("where") | Card: "The demand does not go away: data center power use is set to double by 2030 (IEA)" |
| 12 | s13_cta | y12_cta_key.png | So where would you rather have them: your town, or another country? | The hand wobbles toward the town ("town") then toward the far shore ("country") and stops in the middle | The question in clay letters in the sky; small card signs "YOUR TOWN" and "ANOTHER COUNTRY" |

Transitions: hard cuts, as in stop-motion. A one-frame "hand in frame" or a clapper-style flash is allowed sparingly. End: hold the CTA at least 2.0 s after the last word.
