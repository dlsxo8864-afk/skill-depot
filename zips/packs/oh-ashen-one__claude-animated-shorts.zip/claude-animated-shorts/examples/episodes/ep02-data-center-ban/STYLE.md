# Episode 2 claymation look: yes/no checks

Written from the key images in `assets/key/` (warm practical lamps, saturated plasticine characters,
knitted and wood textures, blue-hour skies) and general stop-motion practice. There are no real-film
reference stills on disk; judge against the key images. Every check must be "yes" in the shot's stills
(full size and 360x640) and preview.

1. On 2s: does every pixel, including the camera, change only on even frames (12 pictures per second)?
2. Is the camera locked off or moved only in small, uneven hand nudges (no smooth dolly, zoom <= ~5 %)?
3. Does every pose change go through held poses (anticipation and/or one in-between, then a hold),
   never a cross-fade or a morph?
4. In region-mode shots, does everything outside the character region stay identical between poses
   (no colour pop, no seam around the swapped area)?
5. Is a reframing pose played as a clean cut on the beat, with a camera knock on that exposure?
6. Are the stop-motion tells present but subtle: lamp flicker about 1 %, clay crawl on characters, a rare
   one-exposure bump, touched props settling slightly off where they were?
7. Miniature lens: is the subject sharp, the background softer and near foreground clearly soft (shallow
   depth of field), with a gentle vignette and fine grain, and NO bloom or glow halos?
8. Is the colour the key's own (no added grade, no paint, canvas or watercolour texture)?
9. Is every piece of text a physical object in the set (clay letters, card, paper, cardboard, wood, ink
   printed or stamped on a surface, or a backlit printed insert in a screen)? Nothing reads as a caption.
10. Does each added object cast a contact or hang shadow in the direction of the key's light, take the
    scene's light colour, and sit in the depth of field like its neighbours?
11. Do clay letters show bevels, thumbprints, a visible side wall and soft satin highlights (not glossy
    plastic, not glitter, not flat vector type)?
12. Do cards and paper show cut edges, fibre, a slight bow and ink that soaks in (uneven density)?
13. Does ink printed or stamped on a bent surface (ticket, bill, placard) follow that surface's curve or
    perspective?
14. Is all readable text inside x 65-929, y 115-1498 (output px) with cap height >= 30 px, and legible at
    360x640?
15. Does the YEAR sign appear top left, lowered on its threads two frames after the cut (same design in
    every year shot)?
16. Does the one data card per shot arrive by hand (threads, a stick or set down) on or just before its
    spoken number, and stay long enough to read?
17. Are invented figures marked with a SCENARIO rubber stamp, and are there no real logos, flags or
    trademarked interfaces?
18. Sound: does every visible physical action have a tactile sound (squelch, knock, rustle, stamp), with
    the narration always clearly on top?
19. Are cuts between shots hard cuts (no dissolves, no wipes; a one-frame hand-in-frame flash at most)?
20. CTA only: does the picture hold at least 2.0 s after the last word, with the question in clay letters
    and the two card signs "YOUR TOWN" / "ANOTHER COUNTRY" readable at 360x640?
21. Does a swapped pose leave no ghost of the outgoing pose on smooth backgrounds (sky, walls): no pale
    or dark blob where the old pose was?
