# Episode 2: "What if every state banned new data centers?"

Format: vertical 9:16, at least 61 seconds. Narration: Kokoro af_nicole, speed 1.5. Look: claymation (plasticine stop-motion in the manner of Aardman): visible fingerprints and tool marks in the clay, slightly wonky handmade miniature sets, replacement animation on 2s, practical miniature lighting, shallow depth of field.

Angle: neither for nor against. Some things get better, some get worse, and the data centers do not vanish; they move.

| # | Narration | Visual (exaggerated consequence) | On screen | Source |
| --- | --- | --- | --- | --- |
| Hook | What if every state banned new data centers? | A clay ballot box swallows a clay data center whole; a clay crowd cheers | "This month, 40 of 41 local votes went against data centers" | CNBC, 4 Nov 2026 |
| Year 1 | The first thing you'd notice is your chatbot. ChatGPT's nine hundred million users would have nowhere new to go. | A clay person at a laptop; a ticket machine spits out a queue ticket with an absurd number; the queue wraps around the block | "ChatGPT: 900 million weekly users"; ticket "You are number 2,000,000 in line" (scenario) | OpenAI, Feb 2026 |
| Year 2 | Then the cloud would cost more. Only one point four percent of data center space is empty. | An auctioneer selling the last empty server rack to a room of frantic clay bidders waving cash | "Vacancy: 1.4%, a record low" | CBRE, H1 2026 |
| Year 3 | Your power bill would climb more slowly. Data centers drove most of a record price jump on the biggest grid. | A clay electricity meter spinning wildly slows down; a family unclenches | "63% of the 2025-26 capacity price increase (PJM market monitor)" | PJM Independent Market Monitor, reported by Utility Dive and others; $9.3 billion |
| Year 4 | Your town would keep more water. Data centers drank seventeen billion gallons in one year. | A giant clay drinking straw is pulled out of the town reservoir; the water level rises; ducks return | "17.4 billion gallons in 2023" | Berkeley Lab, 2024 |
| Year 5 | But the cranes would stop on a fifty billion dollar a year building boom. | Clay construction cranes freeze mid-swing; workers put down tools and sit on a half-built wall | "Data center construction: over $50 billion a year" | Census via ABC, Apr 2026 |
| Year 6 | Your property taxes could rise. In one Virginia county, data centers pay almost half. | A homeowner opens the mailbox and a tax bill unrolls down the street | "Loudoun County, VA: almost half of property tax revenue" | Loudoun County budget |
| Year 7 | Your retirement would feel it. Five companies are spending eight hundred billion dollars on this. | A clay piggy bank on a seesaw with five giant clay towers; the towers step off and the piggy bank drops | "About $800 billion in 2026" | Company guidance, Q3 2026 |
| Year 8 | And the data centers wouldn't vanish. They'd move, to places like Abu Dhabi. | Clay server racks with little suitcases queue at an airport gate and board a plane | "Abu Dhabi: a 5 gigawatt campus planned" | G42 / OpenAI announcement |
| Year 9 | China wouldn't pause. It plans twenty-eight more gigawatts by twenty thirty. | Two clay building sites side by side: one frozen and dusty, one stacking racks at double speed | "China: 28 GW more by 2030" | Rystad Energy, 2026 |
| Year 10 | By year ten, your photos, your bank and your AI could live in another country. | A clay phone on a table; its photos, coins and a chat bubble fly out and cross an ocean on a tiny cable | "scenario" | Inference, labelled |
| Catch | A ban wouldn't end data centers. It would decide where they're built. | A clay hand moves a data center model across a tabletop map from one country to another | | |
| CTA | So where would you rather have them: your town, or another country? | The model hovers between a little clay town and a far shore; a clay hand hesitates | The question as clay letters | |

Word count: about 185. Expected length: about 66 to 70 seconds (episode 1 ran 64 s on 163 words).

Scenario figures: the queue number, and the Year 10 line.

Checked 2026-11-06: the 63% figure is the market monitor's estimate for the 2025-26 capacity auction ($9.3 billion), confirmed across several reports. It is driven largely by forecast data center load, and later auctions show lower shares (38% for 2028-29), so the line says "a record price jump", not "the last".
