# Episode 3: "What if Daenerys never burned King's Landing?"

Format: vertical 9:16, at least 61 seconds. Narration: Kokoro af_nicole, speed 1.5. Look: the hand-painted 3D style of episode 1 (Arcane, Fortiche). Unofficial fan content: original stylized character designs, no actor likenesses, no HBO footage, music or logos; a small "unofficial fan fiction" card on the hook.

Premise (owner, 2026-11-06): Daenerys spares the city, Jon does not kill her, Bran is not made king, she and Jon rule together. The ten years after, accurate to the books and the show, neither good nor bad.

Angle: ruling is harder than conquering, and every lore thread that was left hanging comes due: the Iron Bank, the North, the Dothraki, the single dragon, the empty cradle.

| # | Narration | Visual (exaggerated consequence) | On screen | Lore basis |
| --- | --- | --- | --- | --- |
| Hook | What if Daenerys never burned King's Landing? | The bells ring; Drogon banks away from the Red Keep; a silver-haired queen on dragonback holds her hand up; the city stands | "Unofficial fan fiction" card | S8E5 |
| Year 1 | In year one, the queen marries Jon. Targaryens wed family for three centuries, so the lords barely blink. | A wedding on the steps of the Great Sept's ruins; a dragon-and-direwolf banner unrolls; two crowns | "House Targaryen: 300 years of sibling and cousin marriages" | Targaryen custom (Aegon I wed both sisters; Aerys II wed his sister Rhaella) |
| Year 2 | Then the North leaves. Jon promised Sansa independence, and he keeps his word. | Sansa in a grey crown; a map of Westeros with the top third tearing away along the Neck | "Kingdom of the North: the first realm to leave" (scenario) | Sansa's stated goal through S8; the North gets it in canon |
| Year 3 | The Dothraki get bored. Horse lords do not farm, and there is nobody left to fight. | Thousands of riders milling in a muddy Reach field; a bored khal sharpening a sword against a scarecrow | "Dothraki: horse nomads who neither farm nor sail" | Dothraki culture; the khalasar survived the Long Night in part |
| Year 4 | The Iron Bank sends its bill. Cersei's debts are hers now, and the bank has its due. | A tiny grey banker on the Iron Throne's steps with a ledger taller than he is; coins flow out of the Red Keep | "Cersei borrowed from the Iron Bank to hire the Golden Company: 20,000 men" | S7E7, S8E1; the Iron Bank "will have its due" |
| Year 5 | Bran goes to the Citadel, not the throne, and writes a history that embarrasses almost everyone. | Bran in a maester's library, pages flying; scandalised lords reading over his shoulder | "The Three-Eyed Raven: can see any moment of the past" | Bran's power; Sam at the Citadel |
| Year 6 | There is still only one dragon. | Drogon alone on the Dragonmont, the sky full of empty nests | "Dragons left: 1" | Viserion and Rhaegal are dead |
| Year 7 | And no heir. A witch told the queen she would never bear a child, and the lords are counting. | An empty cradle in the throne room; lords on their fingers; a Great Council summons nailed up | "Mirri Maz Duur's prophecy" | AGOT; S1 |
| Year 8 | Across the sea, the cities she freed drift back. Without a dragon overhead, slavery returns to Essos. | A slaver's whip rising again over a market in Volantis; Meereen's pyramid in the distance | "Slaver's Bay, renamed the Bay of Dragons, 303 AC" | ADWD; S6 |
| Year 9 | Winter lasts years. With the North gone, the Reach feeds everyone, at the Reach's price. | A loaf of bread on a scale against a pile of gold; snow at the city gates | "A Westerosi winter can last years" (price: scenario) | Seasons in ASOIAF |
| Year 10 | By year ten, with no heir, Jon and Daenerys call a Great Council to choose who rules next. | The lords of Westeros in the Dragonpit, voting; Jon and Dany watch from the side | "Great Council of 101 AC: the last time the lords chose" | Great Council of 101 AC |
| Catch | Breaking the wheel ends with the lords choosing a king, almost exactly how the show ended. | The wheel from her speech, now a council table | | S5 "break the wheel"; S8E6 |
| CTA | So would you have let her keep the throne, or taken it from her anyway? | Dany and Jon on the two thrones; the viewer's point of view holds a dagger in one hand and a crown in the other | The question as large text | |

Word count: about 190. Expected length: about 70 seconds.

Scenario figures: the North leaving in year 2 (canon does it in year 1 under Bran), the bread price.

Lore check (scout, 2026-11-07): no stated Dothraki count survives the show, so the Year 3 card states culture, not a number; the Iron Bank card uses the Golden Company loan (show beat); Mirri Maz Duur's line is a prophecy the show never resolved, so the narration says "a witch told her", not "cannot"; the Great Council of 101 AC is the precedent; the in-world history is Fire & Blood by Archmaester Gyldayn (Bran's card may nod to it).
