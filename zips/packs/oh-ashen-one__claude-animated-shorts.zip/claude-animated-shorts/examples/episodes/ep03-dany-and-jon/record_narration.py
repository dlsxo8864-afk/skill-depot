import sys, json, numpy as np, soundfile as sf
from kokoro import KPipeline
out=sys.argv[1]; SPEED=1.5
lines=[
("00_hook","What if Daenerys never burned King's Landing?","What if Daenerys never burned King's Landing?"),
("01_wedding","In year one she marries Jon. Targaryens wed family for three centuries, so the lords barely blink.",None),
("02_north","Then the North leaves. Jon promised Sansa independence, and he keeps his word.",None),
("03_dothraki","The Dothraki get bored. Horse lords do not farm, and there is nobody left to fight.",None),
("04_ironbank","The Iron Bank sends its bill. Cersei's debts are hers now, and the bank has its due.",None),
("05_bran","Bran goes to the Citadel, not the throne, and writes a history that embarrasses almost everyone.",None),
("06_dragon","There is still only one dragon.",None),
("07_cradle","And no heir. A witch told the queen she would never bear a child, and the lords are counting.",None),
("08_essos","Across the sea, the cities she freed drift back. Without a dragon overhead, slavery returns to Essos.",None),
("09_winter","Winter lasts years. With the North gone, the Reach feeds everyone, at the Reach's price.",None),
("10_council","By year ten, with no heir, Jon and Daenerys call a Great Council to choose who rules next.",None),
("11_catch","Breaking the wheel ends with the lords choosing a king, almost exactly how the show ended.",None),
("12_cta","So would you have let her keep the throne, or taken it from her anyway?",None),
]
pipe=KPipeline(lang_code='a', device='cpu')
meta=[]; tot=0; words=0
for name,script,spoken in lines:
    audio=np.concatenate([np.asarray(a) for _,_,a in pipe(spoken or script, voice='af_nicole', speed=SPEED)])
    sf.write(f"{out}/{name}.wav", audio, 24000)
    d=len(audio)/24000; n=len(script.split()); tot+=d; words+=n
    meta.append({"file":f"{name}.wav","script":script,"tts_text":spoken or script,"seconds":round(d,2),"words":n})
    print(f"{name:12} {d:5.2f}s {n:3d}w")
json.dump({"voice":"kokoro af_nicole","speed":SPEED,"lines":meta},open(f"{out}/lines.json","w"),indent=1)
print("TOTAL speech",round(tot,2),"s",words,"words",round(words/tot*60),"wpm")
