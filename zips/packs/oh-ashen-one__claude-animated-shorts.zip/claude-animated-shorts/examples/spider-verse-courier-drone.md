# Example brief: courier drone, Spider-Verse style

A filled-in `templates/shot-brief.md`. The style bullets are a starting list; Gate 1 research confirms or corrects them.

---

An around 12-second 3D animated shot in the comic-book style of Spider-Man: Into the Spider-Verse (Sony Pictures Imageworks).

Made in Blender, or any other tool if superior. Widescreen, no dialogue.

GOAL

The top priority is replicating Into the Spider-Verse's visual and animation style as perfectly as possible, in every way. Someone watching should believe it came from the same studio.

Take as much time and effort as needed. Replicate the technique and look perfectly.

SCENE (loose — adapt freely)

A cat-sized courier drone covered in peeling stickers weaves between rooftop water towers at dusk. It clips an antenna, tumbles, then snaps upright in a burst of ink lines and flies straight at the camera. Change the details, framing, or action if something else shows off the style better. You can animate something else completely if it will look closer to Into the Spider-Verse.

PROCESS

1. RESEARCH: Before building anything, study Into the Spider-Verse's style in depth. Find references and breakdowns of Imageworks' technique (interviews, making-of material, artist breakdowns). Write down every defining element: textures, shading, line work, color, lighting, frame rate, effects, camera, compositing.

2. STYLE GUIDE: Turn that into a written checklist and a small style frame (a single still image) before animating. Compare it side by side with reference stills and revise until it matches.

3. BUILD: Model, texture, light, and animate following the checklist.

4. REVIEW: Compare frames against Into the Spider-Verse references repeatedly. List every difference you can see and fix it. Repeat until no noticeable differences remain.

STYLE ELEMENTS TO MATCH (at minimum)

- Printed-comic surfaces: halftone dots and hatching carry the tone; no smooth photographic gradients.

- Drawn ink lines on forms and edges, placed where an artist would put them, not a uniform outline.

- Animation on 2s for the drone, with held poses, snappy spacing and smears; no motion blur anywhere. Camera moves smooth on 1s.

- Out-of-focus areas shown as offset, misregistered color like a misprinted page, not lens blur.

- Hand-drawn 2D effects (action lines, impact bursts, dot patterns) layered over the 3D on 2s.

- Saturated dusk palette: warm sky against cool shadow, neon accents, flat graphic shadow shapes.

- Comic framing: bold angles, a clear silhouette on every pose, a hit of weight on the antenna impact.

SOUND

Punchy, cinematic sound design that matches the action and mood. Rotor whine that bends with each turn, a metallic clip on the antenna, a held beat of near silence in the tumble, and a hard accent on the recovery.

Make everything as good as possible: animation, models, textures, effects, lighting, and sound. Use any tools or programs needed. You may study references online and imitate techniques, but do not directly use assets you did not create. Keep the whole shot in one consistent style so every layer feels like a single hand-crafted image.

You can use a different process than outlined here, or animate something other than described, but it should look as close as possible to Into the Spider-Verse.
