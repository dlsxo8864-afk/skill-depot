An around [LENGTH]-second [MEDIUM] shot in the [LOOK DESCRIPTOR] style of [REFERENCE] ([STUDIO]).

Made in [DEFAULT TOOL], or any other tool if superior. [FORMAT], [DIALOGUE RULE].

GOAL

The top priority is replicating [REFERENCE]'s visual and animation style as perfectly as possible, in every way. Someone watching should believe it came from the same studio.

Take as much time and effort as needed. Replicate the technique and look perfectly.

SCENE (loose — adapt freely)

[SUBJECT] [SETTING]. [BEAT 1: stillness or setup]. [BEAT 2: the change]. [BEAT 3: the burst or release]. Change the details, framing, or action if something else shows off the style better. You can animate something else completely if it will look closer to [REFERENCE].

PROCESS

1. RESEARCH: Before building anything, study [REFERENCE]'s style in depth. Find references and breakdowns of [STUDIO]'s technique (interviews, making-of material, artist breakdowns). Write down every defining element: textures, shading, line work, color, lighting, frame rate, effects, camera, compositing.

2. STYLE GUIDE: Turn that into a written checklist and a small style frame (a single still image) before animating. Compare it side by side with reference stills and revise until it matches.

3. BUILD: Model, texture, light, and animate following the checklist.

4. REVIEW: Compare frames against [REFERENCE] references repeatedly. List every difference you can see and fix it. Repeat until no noticeable differences remain.

STYLE ELEMENTS TO MATCH (at minimum)

- [SURFACES: what every surface looks like; what it must not look like.]

- [SHADING: how light and shadow shapes are drawn; what they must not look like.]

- [TIMING: frame stepping for characters/objects and for the camera; poses, anticipation, smears.]

- [EFFECTS: technique, frame stepping, shape language.]

- [COLOR AND LIGHT: palette, shadow color, accents, rim light, bloom.]

- [COMPOSITING: filtering, grain, texture over the image.]

- [CAMERA: lens, depth of field, movement, weight on impacts.]

SOUND

[MOOD] sound design that matches the action and mood. [WHAT MUST BE HEARD.]

Make everything as good as possible: animation, models, textures, effects, lighting, and sound. Use any tools or programs needed. [ASSET POLICY — from-scratch: "You may study references online and imitate techniques, but do not directly use assets you did not create." / licensed: "Finished licensed assets are allowed if restyled to match; record each source and license."] Keep the whole shot in one consistent style so every layer feels like a single hand-crafted image.

[CONTEXT — clean-room only: "Do not use memory or previous chats."]

You can use a different process than outlined here, or animate something other than described, but it should look as close as possible to [REFERENCE].
