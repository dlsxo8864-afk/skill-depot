# [EPISODE TITLE = THE HOOK QUESTION]

Format: vertical 9:16, at least [61] seconds. Narration: [voice], about 165 words a minute. Look: [REFERENCE] ([STUDIO]).

| # | Narration (full sentences, "you" or "we") | Visual (exaggerated consequence) | On screen (real number, or scenario) | Source |
| --- | --- | --- | --- | --- |
| Hook | [The what-if question.] | | | |
| Year 1 | [The first thing you'd notice...] | | | |
| Year 2 | | | | |
| ... | | | | |
| Year 10 | | | | |
| Catch | [The fact that reframes the list.] | | | |
| CTA | [A question that makes the viewer choose.] | | | |

Word count: [n]. Estimated length: [n / 165 x 60 + 0.4 x gaps] seconds.

Scenario figures (invented, labelled on screen): [list].

Numbers still to confirm at the primary source: [list].
