# Install

## As a Claude Code plugin (recommended)

From a terminal (while the repo is private, you need access to it):

```
claude plugin marketplace add woreksami/shortsmith
claude plugin install shortsmith@shortsmith
```

From a local copy instead: `claude plugin marketplace add /path/to/shortsmith`, then the same install line.

Restart the session. The skills appear as `/shortsmith`, `/shorts-new`, `/shorts-fix`, `/shorts-qa` and `/shorts-publish`.

## One-time machine setup

1. **Python packages:** `pip install --user numpy scipy pillow faster-whisper`
2. **ffmpeg:** `winget install Gyan.FFmpeg` (or set `FFMPEG_DIR`).
3. **Unity 6 + Unity Hub,** signed in. Batch rendering needs the Hub's licence.
4. **MCP for Unity:** in Unity, Package Manager → + → git URL `https://github.com/CoplayDev/unity-mcp.git?path=/MCPForUnity#main`, then Window → MCP for Unity → Transport **Stdio**, port 6400 → Start Session. It needs `uv` (`winget install astral-sh.uv`).
5. **Sketchfab token:** Claude asks for it once and stores it as the user environment variable `SKETCHFAB_API_TOKEN`. Rotate it after big download sessions.
6. **Optional, Blender:** `winget install BlenderFoundation.Blender`.

Check the scripts:

```
python skills/shortsmith/scripts/voice_timing.py --selftest
python skills/shortsmith/scripts/mix_audio.py --selftest
python skills/shortsmith/scripts/assemble.py --selftest
```
