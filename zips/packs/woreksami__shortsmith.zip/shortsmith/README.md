# Shortsmith

**Studio-grade, ultra-realistic 3D YouTube Shorts, made by Claude in Unity (with optional Blender).**
The workflow takes a video from the idea to an upload-ready file. Every lesson from shipped videos is built in as a hard rule.

It works for any channel and niche (engineering, military, cars, space, history, science...). On first run, Claude sets up a short **channel profile** with your niche, format, tone, voice and branding, and every video follows it.

It was built from four real Shorts: a roundabout explainer, a diverging diamond interchange, the A-10's gun and the SR-71 that leaked fuel on purpose. Every correction made on those is now a rule, a check or a tool here, so your first video starts where those finished.

## What it does

| Phase | You | Claude |
|---|---|---|
| Idea | describe your channel once, pick a topic, approve the script | pitches one idea with a scroll-stopping hook, writes and fact-checks the script |
| Voice | record it (ElevenLabs, any TTS, or your own voice) | word-timestamps it; every cut locks to the words |
| Assets | paste your Sketchfab token once; say if you want Blender work | searches, triages (4K textures, sane materials, real origin), downloads, fixes and credits |
| Look | approve the hero frames | lights and grades each location at final quality |
| Shots | approve the review sheet | builds every shot: physical motion, real construction, fluids, plumes, crashes, chase-plane cameras |
| Pacing | approve the low-res preview with sound | sub-cuts, whooshes, impacts, a hook in frame 1 |
| Sound | listen | real recordings, ducked under the voice, an effects stem for your edit |
| Final | watch and post | an offline render at 2160×3840 with motion blur and depth of field, a CRF 14 master and an automated QA gate |
| Publish | upload | title, description, licence-correct credits, music picks |

## Commands

- `/shortsmith`: the whole pipeline. It also triggers on "make a short", "render it" and similar.
- `/shorts-new`: start a new video (idea, hook, script, fact check, setup).
- `/shorts-fix`: when it isn't good enough. Root-cause diagnosis plus a fix across the whole video.
- `/shorts-qa`: the automated and visual quality gate.
- `/shorts-publish`: title, description, credits, branding.

## Requirements

- Windows or macOS, a decent GPU (an RTX 3060 is plenty), 40 GB or more of free disk.
- Unity 6 (URP) with Unity Hub signed in, plus [MCP for Unity](https://github.com/CoplayDev/unity-mcp) (stdio, port 6400).
- Python 3.10+ with `numpy scipy pillow faster-whisper`, and ffmpeg.
- Optional: Blender 4.x, and a Sketchfab account (free) for its API token.

## Install

```
claude plugin marketplace add woreksami/shortsmith
claude plugin install shortsmith@shortsmith
```

Then see [INSTALL.md](INSTALL.md) for the one-time machine setup.

## What's inside

```
skills/shortsmith/SKILL.md            the method: non-negotiables, workflow, gates
skills/shortsmith/references/         channel profiles, hall of shame, pipeline, script, timing, Unity, rendering,
                                      cinematography, effects, assets, Blender, audio, QA, publish
skills/shortsmith/scripts/            voice_timing, sketchfab, polyhaven, mix_audio, sfx_synth,
                                      assemble, qa_video, contact_sheet
skills/shortsmith/unity/              ShortFilm (offline renderer), ShotKit, ShortCli, shaders
skills/shortsmith/blender/            fix_asset.py (headless cleanup, scale, bevel, export)
skills/shorts-new|fix|qa|publish/     entry points
```

## Licence

MIT. Third-party models and sounds you download keep their own licences. Credit them, and the publish step does that for you.
