# Rendering: the offline film renderer

Real-time playback and Unity Recorder are for nothing. Every final frame is posed and rendered on its own by `unity/ShortFilm.cs`, which is why the quality holds no matter how heavy the scene is.

## How ShortFilm works

- **Shot table:** `<EP>_timing.csv` gives the start and end of each shot. Each shot is registered in `<EP>Shots.Register` with `(scenePath, Pose, Wipe?)`.
- **Frame k shows time `k / Fps`.** For each of `SubFor(shot)` sub-frames spread over a 180° shutter, it calls `pose(t, cam, 0)`, renders to a 2160×3840 ARGBHalf target with 4× MSAA, and accumulates. The result is true motion blur that is consistent at any speed.
- **Output:** PNGs to `Recordings/<EP>Frames/f%05d.png`. `assemble.py` downscales to 1080×1920 with lanczos, which is 2× supersampling.
- **Layered wipes:** a shot with `Wipe` renders layer 0 and layer 1 and composites them behind a soft, glowing front (`FilmPasses` pass 1). Use these sparingly (see `effects.md`).
- **`Still(n, t, path)`** renders one review frame at final quality.
- **`-preview`** gives 540×960, 1 sub-sample and every second frame, for pacing previews.

## Motion blur sub-samples, per shot

| Content | SubFor |
|---|---|
| Static and slow camera | 4 |
| Fast fly-by, whip pan, shake | 8 |
| Falling drops or debris, sparks, fast tracers | 16 |
| Spinning rotors, barrels or wheels close up | 24 to 32 |

Too few samples shows as strobing and stepping ("the spinning barrels looked like some BS spinning"). Render time scales linearly, so spend samples only where they're needed.

## Depth of field

Use Gaussian mode with high-quality sampling (bokeh mode crawls on fine edges and flickers). `ShortFilm.Look(cam, pos, target, fov)` focuses on the target automatically. The background blur ramps from `focus × farStart` to `focus × farEnd`:
- outdoors: farStart 2.2, farEnd 9;
- studio: farStart 1.25, farEnd 4.

Macro shots should have shallow focus, because it reads as a real lens.

## Light, shadow and colour

- **Shadow distance per scene:**
  - a city to the horizon: 1,600 m;
  - studio: about 90 m;
  - macro: a few metres, for crisp contact shadows.
  Use 4 cascades.
- **Ambient occlusion:** turn on SSAO with a strong, but not muddy, intensity. Undersides and corners need contact darkness.
- **Bounce light:** URP has no GI in this pipeline, so fake it. Add a weak warm directional light from below for sunlit ground bouncing onto dark undersides (the "GroundBounce" light: intensity about 0.3, no shadows).
- **Sky:** use a real HDRI (Poly Haven) rotated so its sun matches the directional light, or `AltitudeSky.shader` for altitude. Call `DynamicGI.UpdateEnvironment()` when the sky changes, and only then.
- **Grade:** use HDR grading (ACES or Neutral), slight warmth at golden hour, chromatic aberration about 0.06, and a subtle vignette. **No film grain:** it becomes per-frame noise that reads as flicker after compression.
- **Light the subject.** Golden hour with the sun behind the camera on the subject's lit side. A dark subject (a black jet, a dark belly) needs a rim light and a lit background. Too-dark frames were a repeated weakness, so check the mean luminance in QA.
- **Exposure discipline:** a studio rig sized for a 32 m jet will blow out a 30 cm match. Scale light intensity per shot (as `StudioOnly` did, with ×0.5 for the macro).

## Materials

- Use PBR everywhere, with albedo, normal and roughness at the least.
- Texel density must hold at the closest camera distance. 4K textures on hero models, 2K on mid-ground objects.
- **Metallic is a physical fact, not a look.** Paint is 0. Bare titanium is about 0.75 with albedo about 0.42. Chrome is about 1.
- Break up repetition with macro variation (a second, larger-scale noise multiply), decals for wear and stains, and tint per instance.
- Glass needs real transparency and reflections, or the cockpit reads as a black blob.

## Flicker and temporal stability

The causes seen so far: film grain, bokeh depth of field, live wind or clocks, thin geometry at 1× resolution, and sub-pixel specular highlights. The cures: 2× supersampling, MSAA, Gaussian depth of field, `f(t)` everything, and a little roughness on very smooth thin edges.

Measure with `qa_video.py`, which reports the share of pixels whose frame-to-frame luminance change exceeds a threshold on static-camera shots. The A-10 went from 8.6% to 5.6% on the studio jet. Aim for under 5% on static shots.

## Speed budget

Typical rates: a full city wide shot takes 0.7 s per frame; a 16-sample drip shot about 4 s; and roughly 25 to 45 minutes for a full 60 s video. Before a full render, time 10 frames of every shot (`-shots N` with a short range) and fix outliers. Anything per-frame that doesn't depend on `t` must be cached: meshes, routes, probe bakes and material lookups.

## Fast final vs full quality

| | Fast final | Full quality |
|---|---|---|
| Flags | `-w 1080 -h 1920 -sub 2 -step 2` | none |
| Output | 1080×1920, 30 fps, no supersampling; the episode's fast shots (SubFor ≥ 10) get 2 sub-frames, the rest 1 | 2160×3840 downscaled, 60 fps, full SubFor |
| Time for ~60 s | about 30 min | 2 to 9 hours |
| Assemble | `--fps 30 --src-fps 60 --hold` | default |

`-step 2` renders every second 60 fps frame. Shots that start on an odd frame leave single gaps, which `--hold` fills with the previous frame. On a phone the fast final is hard to tell apart. Offer both, with times, at the pacing gate.

**Crash triage:** a D3D12 `8007000e` / "upload buffer too small" crash is out of GPU memory, usually from mesh particles (see hall of shame 9g). Render in chunks (`-shots 1-8`, `-shots 9-21`) and look for `shot N done` in the log to see where it died.

## Encoding (assemble.py)

`ffmpeg -framerate 60 -i %05d.png -i mix.wav -vf scale=1080:1920:flags=lanczos -c:v libx264 -profile:v high -preset slow -crf 14 -pix_fmt yuv420p -r 60 -c:a aac -b:a 256k -t <D>`

The result is 50 to 150 MB for 60 s. That's fine for YouTube, which re-encodes anyway, and a high-bitrate source survives it best. Missing frames abort the final assembly. Previews fill them with black, and that is flagged.
