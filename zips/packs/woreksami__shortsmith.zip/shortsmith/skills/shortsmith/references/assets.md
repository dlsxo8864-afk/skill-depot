# Assets: finding, triaging, fixing, crediting

## Sources (free first)

| Source | What | Licence | How |
|---|---|---|---|
| Sketchfab | hero models: vehicles, aircraft, buildings, props | CC BY (credit), CC0, Sketchfab Standard (check terms) | `scripts/sketchfab.py`, needs the director's API token |
| Poly Haven | PBR textures, HDRIs, some models | CC0 | `scripts/polyhaven.py`, no account needed |
| Unity Asset Store | trees, characters, packs | Asset Store EULA | the director signs in and accepts; Claude imports |
| Wikimedia Commons / Freesound | real sound recordings | CC0 / CC BY / CC BY-SA | download directly; **check what the file actually is** |
| Blender (built by Claude) | anything missing, or upgrades | yours | `blender.md` |

## Sketchfab token: ask, store, never show

1. At the start of the asset phase, if `SKETCHFAB_API_TOKEN` isn't set, ask the director once. Tell them where to find it: sketchfab.com → Settings → Password & API → API Token.
2. Store it for this machine without printing it:
   - **Windows:** `[Environment]::SetEnvironmentVariable('SKETCHFAB_API_TOKEN','<token>','User')`, then set `$env:` for the current shell.
   - **macOS/Linux:** add `export SKETCHFAB_API_TOKEN=...` to `~/.profile`.
3. Never echo it, log it, put it in a URL, commit it or write it into project files.
4. After downloads are done, remind them once: "regenerate your Sketchfab token, since it passed through chat."

## Searching and triage (do this before committing to a model)

```
python scripts/sketchfab.py search "SR-71 blackbird" --license by --max-faces 800000
python scripts/sketchfab.py info <uid>
python scripts/sketchfab.py download <uid> --out Assets/Models/<name> --credits CREDITS.md
```

Score every candidate:
- **Download the gltf zip, not the glb.** Sketchfab's "glb" download is re-compressed to 1K textures even when the model has 4K maps (a 4 MB glb against an 18 MB gltf for the same truck). `sketchfab.py` defaults to gltf. After any download, check the real image sizes inside the files.
- **Texture resolution:** 4K for anything that gets a close-up. 1K textures stretched over a 16 m fuselage go soft. Check the archive's texture sizes after download (`info` lists the archive formats and sizes).
- **Normal map present.** No normal map means flat, CG-looking surfaces.
- **Materials sane:** metallic and roughness that make physical sense (see the A-10's metallic = 1 bug).
- **Geometry:** correct proportions, separate moving parts (wheels, gear, control surfaces, canopy), and a closed mesh where it matters. 100k to 1M triangles for a hero model is fine offline.
- **Era and accuracy:** the right variant, markings and weapons for the story.
- **Origin:** avoid obvious game rips (War Thunder, GTA). If the source is unclear, say so to the director.
- **Read the uploader's description.** It is the fastest rip detector: "from the game ...", or "uploaded to annoy these sellers" (re-uploaded paid models). Skip those, however good they look.
- **AI-generated meshes:** material or node names like `tripo_mat_*` / `tripo_node_*` (Tripo3D), Meshy or Luma mean a generated blob with fused wheels and melted details. Reject them for anything on camera.
- **Render a close-up before committing.** Thumbnails hide toy proportions. Do one wide and one close-up line-up render under the episode's sky (`<EP>Look.Build` pattern: a saved scene and saved materials, plus its own Volume, never the project default).
- **Licence:** CC BY or CC0 preferred. Note the exact attribution string.
- **Brands:** generic vehicles for hero shots. Branded cars are OK as background traffic, never as the subject.

Look at the thumbnail *and* render it in your scene before deciding. When nothing good exists (a Baghdad mosque, a seated pilot), **cut or re-frame the shot.** Never place a fake.

## Import and fix (Unity)

- **glb via glTFast.** Put it under `Assets/Models/<name>/`.
- **Scale to real dimensions:** measure the bounds and scale to the known length (SR-71 32.7 m, A-10 16.3 m, a car about 4.6 m).
- **Axis and tilt:** align by the real long axis (`ShotKit.AlignLongAxis` uses the farthest-apart vertices) and decide which end is the front or head.
- **Pivots:** the ground contact sits at y = 0. Vehicles get their pivot at the rear-axle centre; aircraft at the main-gear contact for takeoff.
- **Material audit:** check every material for metallic, smoothness, normal strength, base-map tint, double-sided foliage and glass transparency. Fix in code so rebuilds keep the fix.
- **Moving parts:** find or split wheels, rotors, gear and canopy. If the model is one mesh, cut by bounds or vertex groups (or in Blender).
- **Gear-up variant:** use a triangle cut below the gear line, or hide the gear objects.
- **Instancing dressing:** hundreds of copies are fine. Vary tint, rotation and scale so repetition doesn't read.

## Textures (Poly Haven)

```
python scripts/polyhaven.py tex concrete_floor_worn_001 --res 4k --out Assets/PolyHaven
python scripts/polyhaven.py hdri kloofendal_48d_partly_cloudy --res 4k --out Assets/PolyHaven
```

Use albedo, normal (GL), roughness and AO. Set tiling to real-world size (most Poly Haven sets cover about 1–2 m per tile). Break repetition with a large-scale variation multiply and decals. Never use a "rusty" texture where the real material is clean (bare titanium is clean grey).

## Credits

- Add each asset to `CREDITS.md` the moment it's downloaded: `- "Title" by author (licence), URL, used for: ...`.
- Mark assets you dropped as **unused**. The publish step credits only what is on screen or audible.
- CC BY and CC BY-SA require the credit in the description, every upload.
