# Unity setup and gotchas

Tested on Unity 6 (6000.x) with URP on Windows 11 (RTX 3060, 32 GB RAM). macOS works too; paths differ.

## New project

- Create a URP 3D project. If it was created from the command line, the director must use **Unity Hub → Add → Add project from disk** and select the folder itself.
- Add these packages to `Packages/manifest.json` (you can edit it yourself):
  - `com.unity.cloud.gltfast` for glb/gltf import from Sketchfab;
  - `com.unity.splines` for roads and paths;
  - `com.unity.timeline` only if a Timeline is genuinely needed. The offline renderer doesn't need it.
- In the URP asset, use HDR, MSAA 4×, soft shadows, 4 cascades and a high shadow-map resolution (4096). `ShortFilm.Realism` sets the shadow distance per scene.
- Colour space is Linear. Tonemapping is ACES or Neutral in the volume, set by look development, with no film grain.

## MCP bridge (Claude ↔ Unity)

- Install the package with **Window → Package Manager → + → Install package from git URL**:
  `https://github.com/CoplayDev/unity-mcp.git?path=/MCPForUnity#main`
  Auto mode may block Claude from fetching GitHub code. If so, the director adds it, or approves the prompt.
- It needs `uv`. After installing `uv` (`winget install astral-sh.uv`), quit Unity Hub fully (tray icon → Quit) so Unity sees the new PATH.
- **Transport must be Stdio, port 6400.** HTTP Local wants port 8080, which Steam often holds. Claude's project `.mcp.json` launches the server itself. In Unity: **Window → MCP for Unity → Transport: Stdio → Start Session**.
- A session only picks up MCP tools when it starts. After setup, open a **new** Code session in the project folder.
- If several Unity instances are connected, use `set_active_instance`.
- Through MCP, prefer `execute_code` or editor scripts with `[MenuItem]` for builds. Read the console after every compile.

## Batch mode is the production path

- **Render, build and stills all run headless:**
  `"<Unity.exe>" -batchmode -projectPath "<proj>" -executeMethod ShortCli.Render -use <EP>Shots.Use [-shots 3-5] [-preview] -logFile Recordings/render.log`
- **Batch mode needs a licence:** Unity Hub must be installed, running and signed in. Otherwise Unity exits with code 198 and "No valid Unity Editor license found". Check `-logFile` before assuming a code bug. If the Hub is closed, ask the director to open it, or start it yourself.
- **Compile check without a licence:** Unity's own Roslyn compiles the editor scripts against the Unity DLLs:
  `"<Editor>/Data/NetCoreRuntime/dotnet.exe" "<Editor>/Data/DotNetSdk/sdk/<ver>/Roslyn/bincore/csc.dll" -t:library -r:<Editor>/Data/Managed/UnityEngine/*.dll -r:Library/ScriptAssemblies/Unity.RenderPipelines.*.Runtime.dll ...`
  This catches errors before a long batch run.
- The same project can't be open in the editor and in batch mode at once. Save, close the editor (or ask the director to), and then run batch.
- `EditorApplication.Exit` sometimes hangs. Kill only the processes whose path is under `Hub\Editor` for this project.
- Run long renders with `run_in_background`. Count output PNGs for progress. Never poll faster than about once a minute.

## Gotchas that cost hours

- **Terrain and procedural meshes not saved:**
  - Generated meshes must be saved as assets (`AssetDatabase.CreateAsset`).
  - For TerrainData, call `SetHeights` and then `SetDirty` + `SaveAssets`.
  - **Always** verify by reopening the scene from disk.
- **The build deletes generated folders:** an episode build that wipes `Assets/Generated/<EP>` also wipes dependent scenes. Rebuild them in dependency order (episode, then studio).
- **Stale compiled code after a refresh:** check the `Library/ScriptAssemblies/Assembly-CSharp-Editor.dll` timestamp against your edit before trusting a batch run.
- **Destroyed `Texture2D` after a scene load in MCP code:** create runtime textures and render textures with `HideFlags.HideAndDontSave`.
- **Pink materials from older packs:** convert to URP/Lit (Edit → Rendering → Materials → Convert) or rebuild the material in code. Drop any model that still renders pink.
- **The near clip hides macro subjects:** use 0.004 m for anything 30 cm from the lens.
- **Log bloat:** no `Debug.Log` or warnings in per-frame code. Check that `Editor.log` stays under 100 MB.
- **Reflection probes:** use realtime + ViaScripting and call `RenderProbe()` once per shot setup, not per frame, unless the subject moves through it.
- **The project's default volume profile can carry old overrides** (a leftover depth of field blurred a whole test render). Every episode scene gets its own Volume asset with explicit settings.
- **Throwaway `execute_code` scenes lose their in-memory materials on any domain reload** (refresh or compile), so the ground turns into a mirror. Build test scenes from an editor script that saves its scene and material assets.
- **NaN pixels** (invalid normals on generated geometry) become white blobs under bloom. Recalculate normals and tangents, and clamp HDR in the film pass.
- **Unity Asset Store packs:** the director must sign in and accept the EULA. In the built-in browser, Google sign-in popups fail, so offer their Chrome. After "Add to My Assets", Claude can download and import through Package Manager → My Assets.
- **Heavy scenes** (170k objects) make the editor laggy, but don't affect the offline render. If editing hurts, hide distant dressing in the editor and enable it at render.
