# Audio: sound design that doesn't sound synthetic

The voice leads; effects sell the physics underneath it. The director called the synthesized beeps "those same annoying sound effects", and one "real" recording turned out to be a man saying "Blinker". Both are now rules.

## Sources, in order of preference

1. **Real recordings** (Wikimedia Commons, Freesound, BBC Sound Effects with its licence checked). Jets: Work With Sounds (CC BY 4.0) has superb Saab Draken passes and run-ups. Traffic: "Cars passing over bridge" (public domain).
   **Pixabay sound effects** (Pixabay Content Licence: free, no credit needed, but credit the author in `CREDITS.md` anyway) had everything a truck episode needed: jake brakes, air brakes, diesel pass-bys, gravel and highway beds. Its CDN returns 403 to curl and the browser's blob download doesn't reach the disk. What works: run a small local receiver (`http.server`, POST of plain `.mp3` names only, port 8765), open `http://127.0.0.1:8765/` in the built-in browser and `fetch()` each file there, POSTing the bytes to the receiver. Don't try to get around the 403 any other way.
2. **Real recordings, processed:** pitch, stretch, layer, EQ and reverb.
3. **Synthesis** (`scripts/sfx_synth.py`) only for abstract things: reveal shimmers, UI ticks, sub-bass thumps, whooshes on cuts, relay clicks. Never for engines, crashes or voices.

## Verify every recording before it goes in (the Blinker rule)

- Read the source page, not just the filename. Wikimedia has thousands of *pronunciation* files (`Teker`, `LL-Q...`, "De-...ogg") that are a person saying a word.
- Run `python scripts/qa_video.py --sfx path/to/file_or_stem.wav`. It transcribes with whisper and fails if it hears words.
- Check the waveform envelope and spectrum. A turn-signal relay is two sharp clicks per cycle at about 1.4 Hz, not a 1-second blob.
- Note the licence in `CREDITS.md` with the exact author string.

## Building the mix (`scripts/mix_audio.py`)

You write a cue file (`Tools/<ep>_cues.json`) with the duration, beds and cues. The script:
- loads the voice, resampled to 48 kHz stereo;
- lays beds (traffic, wind, cabin roar) with per-shot level automation, near or far, so the bed changes with the camera, low-passed when far;
- places cues at times (impacts, passes, ticks) with gain, pan, pitch and stretch;
- adds a **whoosh on every cut** (from the timing CSV), varied per cut and quiet;
- applies light outdoor reverb;
- keeps effects about 8–10 dB under speech, ducking a further about 8 dB while words are spoken;
- writes `mix.wav` and `sfx_stem.wav` at exactly the video length and asserts it;
- **warns when the same sample is placed twice within 3 s without variation.**

## What every Short needs

- **A whoosh into each cut** and a bigger one into the hook.
- **Something physical under each visual beat:**
  - drips: a plip each, with variation;
  - metal: ticks and creaks as it heats;
  - reveals: a matched rise;
  - impacts: a sub-bass thump, the transient, then debris.
- **Fly-bys at full volume** where the subject rips past the lens, with Doppler (pitch drop through the pass and a stereo sweep).
- **Slow-motion audio:** stretched with a pitch drop, plus a whoosh into the slowdown.
- **Silence as a tool:** drop everything for about 0.4 s before the biggest impact or payoff line.
- **The end:** a final hit or swell that lands on the last word.

## Levels and delivery

- `mix_audio.py` fades every trimmed clip (10 ms in, `fade_out` per cue, default 0.12 s). Clips cut mid-sound click without it. Give long tails (air brakes, pass-bys) a `fade_out` of 0.6–1.0 s.
- `assemble.py` runs loudnorm then a limiter, because loudnorm alone overshot to −0.4 dBTP.

- **Final mix:** about −14 LUFS integrated, true peak ≤ −1 dBTP. `qa_video.py` measures it with ffmpeg ebur128.
- Always deliver `sfx_stem.wav` too. The director adds music in their editor (CapCut, Premiere, DaVinci...) and may rebalance.

## Music (the director adds it)

Suggest the mood, BPM and where it should swell. Recommend: YouTube Audio Library ("no attribution" filter, can't be claimed), Pixabay Music or Mixkit (free, no credit), Kevin MacLeod (CC BY, with credit). Mixing tips: music 15–20 dB under the voice, a silence or drop at the main impact, and a swell on the payoff line.

## Listening honestly

You can't hear. So say what you checked (levels, waveforms, cue times, the speech-detection result), and ask the director to listen, especially to the crash and anything that was synthesized.
