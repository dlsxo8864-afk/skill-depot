# Story and script

## What these Shorts are

These are 30 to 60 s vertical explainers. Each one presents a weird or counter-intuitive fact about something real (a machine, a structure, a place, an event, a natural phenomenon), then builds the explanation step by step, in photoreal 3D. Two proven shapes:

- **Build-up explainer:** *problem → fix → new problem → better fix → payoff line.* It can end on a signature line like "...and congratulations. You've built a ___." Examples: roundabouts, the diverging diamond interchange.
- **Paradox breakdown:** *shocking claim → the machine → the engineering reason → the story or twist.* Examples: the A-10's gun slows the plane down, the SR-71 leaked fuel on purpose.

Which shape, tone and signature line to use comes from the channel profile (`channels.md`). These are the two proven so far; the profile can define others.

## The hook (the first sentence and first frame)

The roundabout video flopped mainly because it opened on a calm drone shot and "Two roads cross, so you put up a traffic light". Nothing happened in the first 2 s.

- **The first sentence is the strangest true claim, said in under 2 s:** "This spy plane leaked fuel all over the runway. By design." / "When this jet fires its gun, the whole plane slows down." / "This highway makes you drive on the wrong side of the road. On purpose."
- **Structure:** subject + violation of expectation + "on purpose", "by design" or a twist.
- **The first frame *shows* the claim, already moving.** Fuel dropping from the belly, the gun firing, cars on the wrong side.
- **The title equals the hook,** so the promise is kept instantly.

## Retention structure

- A new piece of information every 3 to 5 s; a visual change every 1.5 to 2.5 s.
- At about 40–60% through, a **turn**: "But...", "Here's the problem...", or a new danger.
- Use **numbers on screen** as readouts: Mach 3.2, 316 °C, 26 → 14, 80,000 ft. Animate them ticking.
- **Payoff in the last 3 s:** a twist ("bought from the very country it was spying on"), a callback, or the "congratulations" line. End on a hard image, never a fade to nothing.
- Leave room for a beat before the payoff. Ask for a pause in the recording.

## Script rules

- **Length:** 140 to 165 words, about 55 to 59 s at an ElevenLabs conversational pace. Never over 60 s.
- **Sentences:** short and spoken, one idea each. Write numbers as spoken words ("three hundred degrees") so the voice reads them right.
- **Every line must be filmable.** If you can't picture the shot, rewrite the line.
- **No filler** ("basically", "in fact", "interestingly"). No rhetorical "Did you know".
- **Real people:** use names only with care. Never depict their face; use a generic helmet, an over-the-shoulder shot or a silhouette.
- **Brands:** real car brands appeared in DDI traffic as background. Avoid logos in hero shots and never imply endorsement.

## Fact checking (mandatory before the gate)

For every factual claim, find two independent sources. Present a table: claim | status (solid / softened / cut) | sources. Soften to the defensible version: "over 300 °C" rather than "316 °C", and "almost entirely titanium" rather than "93%". Put exact numbers on screen only when solid. Accuracy details matter to this audience, so fix visual inaccuracies too: unit markings, the right weapons, and amber (not red) caution lights.

## Voiceover (ElevenLabs, any TTS, or a real voice)

- The director records it, with the voice named in the channel profile. Match the voice to the tone: confident and expressive for dramatic hardware, casual and light for satisfying explainers.
- Tell them: plain voice MP3, no music; a fast, punchy first line; a short pause before the payoff line; and re-generate any line that's mispronounced.
- The MP3's length becomes the video's length. Don't ask them to hit an exact duration.

## Topic selection

Pick topics with:
1. a one-sentence paradox;
2. visible physical mechanics that 3D can show better than stock footage;
3. a set you can build at hero quality, with one or two locations and a studio;
4. available assets: check Sketchfab for the hero model's quality *before* pitching.

Pitch one idea with a title, why it works, the script and shot ideas, rather than a menu of ten.
