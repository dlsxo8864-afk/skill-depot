# QA: the gate you run on yourself

Nothing reaches the director until it passes this. "I didn't check X" is acceptable to say; "it's top notch" without checking is not.

## Automated: `scripts/qa_video.py`

```
python scripts/qa_video.py Recordings/<EP>_Short.mp4 --dur 59.04 --fps 60 --sfx Assets/Audio/<EP>/sfx_stem.wav --sheet Captures/<EP>_final_sheet.jpg
```

| Check | Fails when |
|---|---|
| Container | not 1080×1920, wrong fps, duration ≠ voiceover ±1 frame, frame count off, duplicated or dropped frames |
| Black or blank frames | mean luminance < 0.04 for any frame (missing render, black fill) |
| Dark frames | more than 1 s of consecutive frames with mean luminance < 0.12 (the "dark belly" weakness) |
| Flicker | frame-to-frame change > 5% of pixels on low-motion stretches |
| Frozen video | identical consecutive frames for > 0.5 s outside intended holds |
| Loudness | integrated outside −16 to −12 LUFS, or true peak > −1 dBTP |
| Speech in effects | whisper hears words in the sfx stem (the Blinker rule) |

It also writes a contact sheet at 2 fps. **Look at every tile.**

## Human eye: per shot, on the contact sheet and the frames

- **Hook:** frame 0 is striking, lit and moving, and the claim is on screen within 1.5 s.
- **Subject:** big, lit side toward the camera, in focus, and readable at thumbnail size.
- **Physics:**
  - nothing floats (check ground contact at every wheel, foot, pier and spill);
  - nothing clips (cars, the tail through the runway, a camera inside geometry);
  - gravity looks right;
  - spins look like spins, not strobes.
- **Materials:** no flat grey metal-mirrors, no rust where it should be clean, no blown-out whites, no pink, no stretched textures, no visible tiling.
- **Background:** designed. No stray HDRI objects, no empty void where a world should be, no test objects left in.
- **Scale and accuracy:** real proportions, correct variant, markings and colours (amber caution lights, the right number of engines and weapons).
- **Pace:** a visual change at least every 2.5 s, sub-cuts in long shots, a whoosh on cuts.
- **Text and readouts:** correct numbers, units and spelling, inside the safe zone, and they appear on the spoken word.
- **Continuity across cuts:** time of day, damage state, gear up or down, burner state.
- **The end:** the last frame is a strong image and the audio lands.

## Before a full render

- Every shot has been approved on the review sheet; the pacing preview has been approved.
- 10 frames have been timed per shot, and none is unexpectedly slow.
- The scene was reopened from disk and the ground contact checked.
- Disk has 40 GB or more free and `Editor.log` is small.
- Sub-samples are set per shot (spinning or falling content uses 16 or more).

## Report template (delivery)

1. The path, duration, resolution, fps, frame count and size.
2. What changed (bullets, in the director's words where possible).
3. What's still weak (honest, specific).
4. What you checked and how; what you did *not* check (for example, "haven't watched end to end with sound").
5. Next step or decision for the director.
