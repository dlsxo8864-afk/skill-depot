# Cinematography for retention

The viewer is on a phone, with the sound often on, and is one thumb-flick from leaving. Every frame must be readable at phone size within 0.5 s.

## Composition (9:16)

- **Subject big.** The hero fills a third to two thirds of the frame height. A tiny jet against the sun read as "too small". Keep it big even as it leaves.
- **Safe zones:** keep the subject and readouts out of the bottom 20% (title and description UI) and the right 12% (buttons). Readouts sit at 72–82% height, centred.
- **One idea per frame.** If the line is "panels expand", the frame is the panels, close up.
- **Light separates the subject from the background:** a lit subject on a darker background, or a silhouette against a bright one. Never dark on dark.
- **Designed backgrounds.** Inserts and macros get a void, a bench with a black flag, or a soft-focus set. Never an accidental HDRI.

## Camera motion that reads as real

- **Every shot moves, with a motivation:** a push-in on a reveal, an orbit for a hero model, a dolly past foreground objects for parallax, and chase-plane drift for flight.
- **Air-to-air:** the subject rides turbulence with `ShotKit.Fly`, and the camera ship floats on its own with `ShotKit.ChaseFloat`. They are never welded together.
- **Moves that start fast and settle:** `ShotKit.Fast` (ease-out cubic) for whip-ins, and `Ease` (smoothstep) for calm moves.
- **Shake** (`ShotKit.Shake`) only on energy: gun bursts, afterburner slams, impacts, low passes. Use about 0.3–0.8°.
- **Things rip past the lens:** a fly-by from a static camera (5–20 m off the path), and the takeoff blasting past a low runway-side camera. These are the highest-energy shots you have. Put one in the first third.
- **Focal length:** wide (40–60° vertical FOV) and close for drama. Long lens (10–20°) for compression and impacts walking up a street. Macro (25–30°) with a near clip of 0.004.

## Pace

- **Cut cadence:** 1.5 to 2.5 s average. Never hold one move for more than about 3.5 s without a sub-cut or a major event in frame.
- **The sub-cut pattern** inside one voice line:
  1. wide, establishing the action;
  2. tight on the detail;
  3. the payoff or impact.
  Example (SR-71 shot 13): wide as the missile climbs, a cut to tight on the burner slam, then wide as the missile falls away.
- **Calm is not slow:** the DDI re-cut slowed the *camera* (fewer whip moves) while keeping the *information* changing. "Too fast" and "boring" are both pace failures, and they have opposite fixes.
- **Cut on action:** cut as the subject crosses the frame or an impact happens, and put a whoosh on the cut.
- **The hook needs three cuts in about 5 s:** a hard push-in, a detail and a payoff.

## Shot design checklist (per shot)

- What is the *one* thing the viewer must see? Is it big, lit and in focus?
- What moves in frame besides the camera?
- Where is the light, and is the subject on its lit side?
- What's in the background, and was it designed?
- Does anything float, clip, intersect the ground or look weightless?
- Is the frame readable at 360×640 (thumbnail size)?

## Recurring shot recipes

- **Hero orbit, studio:** an 8–15° per second orbit, a slight push, a rim light from behind, and a reflective floor or a dark void.
- **Macro insert:** near clip 0.004, FOV 25–30, a shallow Gaussian depth of field, and lights scaled down.
- **X-ray or heat-map reveal:** the camera orbits while the effect sweeps; the "hot" glow leads with the nose and leading edges.
- **Assembly or exploded view:** parts fly home in sequence (`Assemble` pattern, staggered over the line) under a fast sweep, brightly lit.
- **Size comparison:** objects side by side, a low camera slowly dollying between them, with a person or car for scale.
- **Readout shot:** a clean background region where the number sits; the number ticks on the stressed word.
- **Crash:** a wide setup (horn), a slow-mo ramp to about 30% right before impact, the impact frame with debris, then a held aftermath.
