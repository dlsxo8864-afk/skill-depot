# Effects: what worked and how

Every effect is deterministic, `f(t)`. Particles are written per frame with `ParticleSystem.SetParticles` from t, never simulated live. Physics, when needed, is baked once with a fixed seed into keyframes.

## Construction and "building" (the build-up explainer's signature)

- **The good version:** real construction in the world. Footings appear, columns rise, pier caps set, girders lower on a crane path with a slight swing, the deck pours from one end, asphalt rolls out along the spline, and markings paint on. Each element eases in over 0.6–1.2 s, staggered, with a little settle or overshoot.
- **Reveal shader** (`RevealLit.shader` + `RevealController.cs`): a front sweeps through an object in height, path (spline) or radial mode, with a soft dissolve edge and an optional thin glow. Use it for "appear" moments: an island growing out from the centre, lights fading away, a town spreading as the camera pulls back. It may also run in reverse to dissolve something out.
- **Bad (never):** a full-screen 2D laser line sweeping across the frame. It's cheap and screen-space.
- **Sound:** each structure gets its own matched sound (rising shimmer, rumble, pops, a whoosh across, plucks, a swell for the big one), timed to the reveal's duration. Never repeat the same one back to back.

## Liquids (fuel, water)

- **Surface:** `FuelPool.shader`, a planar mirror (`ShotKit.Reflect` renders a mirrored camera into `_PlanarReflTex`), Fresnel, ripple-normal distortion, a tint, and a thin-film rainbow only at thin edges. The wet stain around the spill is matte (smoothness about 0.3), *not* a second mirror.
- **Drips:** come from raycast seam points on the real mesh. Each runs its own cycle:
  1. the bead swells (period 0.8–1.9 s);
  2. it necks and lets go;
  3. it falls with `y = ½gt²`;
  4. a small crown splash and an expanding ring.
  Drops are small emissive spheres that pick up the sky they refract. Use SubFor 16 so they streak.
- **Splash and rings:** flattened torus rings whose radius grows ∝ √t and whose alpha fades; 4–8 droplets on ballistic arcs.
- **Colour:** JP-7 or kerosene is pale straw-amber (tint about (.75, .55, .25)), never orange paint and never grey.

## Fire, exhaust, afterburners

- **Afterburner:** `Plume.shader` is a ray-marched volume in a box proxy. It has a white-hot core, a translucent orange body, a blue lip mantle and 7 shock diamonds that fade downstream. The flicker comes from noise driven by the global `_T`, which you set every sub-frame with `Shader.SetGlobalFloat("_T", t)`. Burner level k scales length (0.45 + 0.55k) and intensity (0.5 to 1.5).
- **Match or candle flame:** a camera-facing card with a blue root and yellow core, a tiny point light 3–4 cm away (low intensity), a black char growing on the head, and a wisp of smoke when it goes out.
- **Muzzle blast, slow-mo:** a flash card, an expanding gas ring, smoke puffs and the round leaving.

## Smoke, dust, trails

- **Missile and contrail smoke:** particles laid along the flight path, recomputed each frame from t. Size grows with age, wind drift and curl are applied, and alpha fades. Grey about 0.6, sorted by distance. See `ShotKit.LayTrail`.
- **Gun smoke and impact dust:** lumpy, billowing puffs with sunlight baked into the texture (the smoke texture generator), rising and spreading. Each impact goes flash, then dark debris, then a dust column.
- **Burning-city columns:** tall, slow, leaning with the wind.

## Crashes and debris

Bake a real physics simulation once (with a fixed seed, using the seeded RNG everywhere, *including* debris rotations) into keyframes. Slow-mo ramps to about 30% just before impact. Use 40–70 pieces of glass, plastic and paint plus one big chunk. Tyre marks draw in behind skids. The sound is a slowed metal crunch with pitch drop, glass, debris clatter and a horn before.

## Skies

- **Ground:** a Poly Haven HDRI (2K–4K) rotated so its sun matches the directional light, plus fog for distance haze.
- **Altitude** (`AltitudeSky.shader`): an analytic atmosphere with a curved Earth, deep blue zenith, horizon haze band, sun disc and glow, and a cloud sea about 20 km below. The cloud sea uses footprint-filtered fbm (no aliasing) and parallax from the camera position, so clouds stream past at the true speed. Set `_SunDir` and `_SunColor` from the sun light.

## Explainer looks

- **X-ray** (`XRay.shader`): Fresnel-edged translucent skin, revealing internals (the gun or cables lighting up from stick to tail).
- **Heat map** (`Heat.shader`): cold blue to glowing orange, driven by a per-vertex "hotness" (nose and leading edges first), with a ticking temperature readout.
- **Arrows and forces:** solid 3D arrows scaled to real numbers (recoil vs thrust). Use a deep, saturated colour; a light blue arrow was hard to see.
- **Readouts:** drawn at assembly (`assemble.py` overlays), not in 3D, unless the number is physically part of the scene.

## Aircraft specifics

- **Gear:** remove it in flight by cutting triangles whose minimum y is below the gear-bay line, or by hiding the gear sub-objects. Check from below.
- **Takeoff:** rotate about the main-gear contact. Cap pitch at the tail clearance (`ShotKit.MaxPitchAboutPivot`) until the wheels leave the runway.
- **Refuelling:** a straight-flying tanker with its gear up. The boom (build it if the model lacks one) reaches the receptacle, then swings clear on disconnect. The receiver sinks away, then lights its burners.
- **Missile intercept:** a curved boost from below (Bézier), burnout, then drag and gravity arcing it behind a jet that accelerates away.
