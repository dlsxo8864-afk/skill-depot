# Publishing: title, description, credits, branding, delivery

## Title

- **Equal to the hook:** paradox plus "on purpose" or "by design". Under about 60 characters. Add a relevant hashtag only if it fits naturally (#SR71).
- **Proven:**
  - "This Spy Plane Leaked Fuel on the Runway. On Purpose."
  - "The A-10's Gun Is So Powerful It Slows the Plane Down"
  - "Why This Highway Makes You Drive on the Wrong Side"
- Give one pick and two alternates for A/B testing. Never clickbait beyond what the video shows.

## Description (ready to paste)

```
<Hook sentence restated.>

<2–4 sentences: the engineering explanation, with the key numbers.>

<Optional: the twist/story line.>

#<Topic> #<Subject> #<Category> #Engineering #Shorts

3D models (Sketchfab, CC BY 4.0 unless noted):
- "<Title>" by <author>
...
Sound (<source>):
- "<Title>" by <author> (<licence>)
Textures and HDRIs: Poly Haven (CC0).
```

- Build the credits from `CREDITS.md`, **used assets only**. CC BY and CC BY-SA need these lines on every upload that uses them.
- Use 5 to 8 hashtags, always with #Shorts.

## Channels

- Read the channel profile in the project's `CLAUDE.md` (`channels.md`): tone, hashtags, signature line and branding come from there.
- If the user has no channel yet, help name it. Pick names about the channel's *whole* niche, not the first video. Check that the name and handle are free.
- **Branding** (banner, profile picture, channel description) represents the **whole channel**, never one episode. Banner prompts: 2560×1440 with the important content inside the central 1546×423. Profile picture: 800×800, readable as a tiny circle, no text.

## Music

The director adds it in the edit; see `audio.md`.

## Delivering files

- The deliverable is `Recordings/<EP>_Short.mp4` at full quality. Give the absolute path.
- **No compressed "phone copies".** If the file is over the send limit, say so in one line ("too big to send from here, it's on the PC at ...").
- Also point to `sfx_stem.wav` for their edit.
- After delivery, offer to clean up big frame folders (they are 12–20 GB each) once the director confirms the upload.
