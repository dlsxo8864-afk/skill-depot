# Blender: building and upgrading assets (optional, ask first)

At the start of each video, ask the director:

> "Want me to also build or upgrade assets in Blender this time? (e.g. a hero model that doesn't exist on Sketchfab, a better cockpit, cutaway geometry, construction parts, re-baked 4K textures). It adds build time, but gets exactly what the shot needs."

If yes, Blender work happens headless from the command line (`blender -b -P script.py -- args`). Interactive steps are only for the director to look, if they want. The Unity MCP server also exposes a `blender_bridge` tool when configured. Prefer the command line, because it is reproducible.

## When Blender is worth it

- **No good model exists:** a specific building, a cutaway, a mechanism (gun drum, gear bay), construction-stage parts (rebar, formwork, girders), or a seated pilot.
- **A good-shape model has bad surfaces:** re-UV, bake 4K normal and AO from a high-poly version, or add bevels so edges catch light (sharp CG edges are a giveaway).
- **Splitting a single-mesh model into moving parts:** wheels, gear, control surfaces, canopy, panels for an exploded view.
- **Cleanup:** merge by distance, recalc normals, remove interior junk, decimate to a sane count, apply transforms, fix the origin.
- **Damage and wear:** dents, scorch, fluid streaks, edge wear via a baked curvature mask.

## The standard pass: `blender/fix_asset.py`

```
blender -b -P blender/fix_asset.py -- --in model.glb --out Assets/Models/x/x_fixed.glb --length 32.7 --axis y --decimate 0.5 --bevel 0.004
```

It imports glb, gltf, fbx or obj and joins everything per object. It applies transforms, merges by distance, recalculates normals and applies shade auto-smooth (30°). It optionally decimates and adds a weighted-normal bevel. It scales so the longest dimension equals `--length` metres, sets the origin to bottom-centre, and exports glb with materials and textures. It prints the bounds and triangle counts so you can verify.

## Modelling to a quality bar

- **Real reference first:** blueprints and photos. Dimensions in metres.
- **Bevel every hard edge** (2–5 mm at real scale) and use weighted normals. This is the single biggest step away from "CG".
- **Texel density:** at least 1024 px per metre on close-up surfaces. Hero parts get their own 4K set.
- **Materials:** Principled BSDF only (it maps cleanly to URP Lit via glTF). Bake procedural detail to image textures before export, because glTF won't carry node trees.
- **Separate objects** for anything that moves or reveals in sequence, with sensible names (`Pier_01`, `Girder_03`), so the shot code can drive them.
- Model what the camera sees, then stop. Hidden faces waste time.

## Rendering inside Blender (rarely)

The DDI post-mortem considered moving to Blender Cycles for ray-traced lighting. The verdict: the Unity offline renderer, used properly, met the bar, and Unity holds the traffic, crash and timing systems. Use Cycles for single insert shots only, such as a macro needing true caustics or refraction. Render at 2160×3840 PNG on the same frame numbering, and composite in `assemble.py`.

## Import into Unity

Export glb, import via glTFast, then do the same material audit as any Sketchfab model (`assets.md`). Credit yourself (no licence line needed) and note any CC sources you used inside Blender.
