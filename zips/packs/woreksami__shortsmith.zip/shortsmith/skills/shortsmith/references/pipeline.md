# Pipeline: idea to upload

`EP` is a short episode code, for example `SR71` or `DDI`. Project layout:

```
<Project>/
  CLAUDE.md                  # project brief: goal, channel profiles (references/channels.md), rules
  CREDITS.md                 # every downloaded asset/sound, with licence; mark unused ones
  <EP>_timing.csv            # shot,start,end,voice,visual (source of truth for timing)
  Assets/Audio/<EP>/         # voiceover.mp3, words.json, real/ (recordings), mix.wav, sfx_stem.wav
  Assets/Editor/<EP>Episode.cs  # builds the location scene(s), saved to Assets/Scenes/<EP>*.unity
  Assets/Editor/<EP>Shots.cs    # Use() + Register(): one pose function per shot, pure f(t)
  Assets/Editor/ShortFilm.cs, ShotKit.cs, ShortCli.cs   # from this skill's unity/
  Assets/Shaders/            # from this skill's unity/shaders/
  Tools/                     # copies of this skill's scripts/ + <ep>_sfx cue file
  Recordings/<EP>Frames/     # f00000.png ... (60 fps, 2160x3840)
  Recordings/<EP>_Short.mp4  # the deliverable
```

## Phase 0: Preflight (no gate, but do all of it)

- **Unity is open** with the MCP bridge connected. If it isn't, see `unity-setup.md`.
- **Required packages:** URP, `com.unity.cloud.gltfast` (glb import), Splines, and Timeline if needed. Recorder is *not* used for finals.
- **Python packages:** `numpy scipy pillow faster-whisper`, installed with `pip install --user`.
- **ffmpeg is on PATH:** `winget install Gyan.FFmpeg` on Windows. Record the full path in `CLAUDE.md`.
- **Disk:** at least 40 GB free. A 60 s 4K PNG sequence is about 12 to 20 GB. Check that `Editor.log` is under 100 MB.
- **Tokens:** read the Sketchfab token from the `SKETCHFAB_API_TOKEN` env var. If it's missing and assets are needed, ask once.
- **Blender:** if the director wants Blender work, find `blender.exe` (Program Files, Steam or winget). If it's missing, offer `winget install BlenderFoundation.Blender`.

## Phase 1: Idea, hook, script (GATE)

Follow `story-and-script.md`. Deliver:

- the title promise;
- the script, about 140 to 165 words for 55 to 59 s;
- a hook-frame description;
- a shot-idea list;
- a fact-check table with sources, each claim marked solid or softened.

**Wait for approval.** Then tell the director exactly what to record. Include the ElevenLabs tips: a fast, punchy first line, a beat before the payoff, and a plain voice MP3 with no music.

## Phase 2: Voiceover and timing

When the MP3 arrives (often as an `@path` in Downloads), copy it to `Assets/Audio/<EP>/voiceover.mp3` and run:

```
python scripts/voice_timing.py Assets/Audio/<EP>/voiceover.mp3 --script script.md --out Assets/Audio/<EP>
```

This writes `words.json`, checks the transcript against the script (and flags mismatched words), lists the pauses and drafts cut points. Write `<EP>_timing.csv` by hand from that draft using the rules in `voiceover-timing.md`.

Show the director the shot table: number, time, line, visual. This is not a hard gate, so keep working while they read it.

## Phase 3: Assets

Ask the Blender question if you haven't already. Then follow `assets.md`:

1. List every on-camera object and the shots it appears in, at what size on screen. That size sets the quality it needs.
2. Search Sketchfab and Poly Haven. Triage on texture resolution, polygon count, materials, licence and origin.
3. Download, import, fix (scale, axis, materials, pivots), or use Blender (`blender.md`).
4. Add every asset to `CREDITS.md` immediately, with its exact title, author, licence and URL.

## Phase 4: Look development (GATE)

For each location (outdoor set, studio, altitude), build **one hero frame at final quality**, rendered through `ShortFilm.Still` (2× supersampling, motion blur, depth of field). Set the lighting, sky, materials and colour here, not later.

Send the stills with a frank self-critique: what's strong, what's weak, and what you'll fix. **Wait for approval of the look.**

## Phase 5: Build every shot

In `<EP>Shots.cs`, each shot is `Pose(double t, Camera cam, int layer)`. It positions everything for time `t` and nothing else. Use `ShotKit` helpers. Use sub-cuts inside long shots (`cinematography.md`). Use effects from `effects.md`.

**Time 10 frames per shot.** Anything over about 3 s per frame needs a reason.

## Phase 6: Review sheet (GATE)

Render one still per shot at its most important moment, plus extras for sub-cuts:

```
Unity.exe -batchmode -projectPath <proj> -executeMethod ShortCli.Stills -use <EP>Shots.Use -stills 1@0.8,1@2.0,2@6.1 -out Captures/<EP>_review -logFile -
python scripts/contact_sheet.py Captures/<EP>_review --out Captures/<EP>_sheet.jpg --cols 4
```

Look at every frame yourself first, using `qa-checklist.md`, and fix what fails *before* sending. Send the sheet with an honest list: strong shots, weak shots, and the plan for the weak ones. **Wait for approval.**

## Phase 7: Pacing preview with sound (GATE)

```
Unity.exe -batchmode ... -executeMethod ShortCli.Render -use <EP>Shots.Use -preview -logFile Recordings/preview.log
python scripts/assemble.py --frames Recordings/<EP>Frames_preview --audio Assets/Audio/<EP>/mix.wav --dur <D> --fps 30 --out Recordings/<EP>_pacing_preview.mp4 --preview
```

A preview renders at 540×960 and 30 fps with 1 sub-sample, in minutes. The director judges rhythm, cut timing and readability here. That is cheap to change now and expensive after the full render.

The preview **always** carries the full sound mix (Phase 8 runs first). At this gate, also quote the full render: time 10 frames per shot, then give the time and file size for both the fast final (1080×1920, 30 fps, about 30 min) and full quality (4K/60 supersampled, often hours). The director picks; default to the fast final. Never reveal a multi-hour render only after they've said "go".

## Phase 8: Sound

Follow `audio.md`: real recordings in `Assets/Audio/<EP>/real/`, a cue list, `mix_audio.py`, and speech detection on the stem. It goes into the preview, so the director hears it at the Phase 7 gate.

## Phase 9: Full render, assembly, QA

1. Close the editor, or render with a second batch instance if the project allows it. Kill stuck editors by their path under `Hub\Editor`. `EditorApplication.Exit` sometimes hangs.
2. Run the render in the background:
   ```
   Unity.exe -batchmode -projectPath <proj> -executeMethod ShortCli.Render -use <EP>Shots.Use -logFile Recordings/render.log
   ```
   Fast final (the default unless the director chose full quality):
   ```
   Unity.exe -batchmode -projectPath <proj> -executeMethod ShortCli.Render -use <EP>Shots.Use -w 1080 -h 1920 -sub 2 -step 2 -out Recordings/<EP>Frames_fast -logFile Recordings/render.log
   python scripts/assemble.py --frames Recordings/<EP>Frames_fast --audio Assets/Audio/<EP>/mix.wav --dur <D> --fps 30 --src-fps 60 --hold --out Recordings/<EP>_Short.mp4
   ```
   Report progress by counting PNGs: done out of total, seconds per frame, ETA.
3. Assemble with `scripts/assemble.py` (overlays, audio and an exact duration) at CRF 14.
4. Run `python scripts/qa_video.py Recordings/<EP>_Short.mp4 --dur <D> --sfx Assets/Audio/<EP>/sfx_stem.wav`, then fix and re-run until it passes.
5. Watch the file. At minimum, pull a contact sheet at 2 fps and check every frame. Play the audio stem and check the cue list against `words.json`. Tell the director exactly what you watched.

If only some shots change, re-render only those (`-shots 6` or `-shots 10-13`) and re-assemble.

## Phase 10: Delivery

- Give the path: `Recordings/<EP>_Short.mp4`, with its duration, resolution, fps, frame count and size.
- Say what changed, what's still weak, and what you didn't verify.
- Give the title, description and credits (`publish.md`), generated from `CREDITS.md` for *used* assets only.
- If assets were downloaded, remind the director to rotate the Sketchfab token.
- Never make a compressed phone copy. If the file is too big to send, say so in one line.
