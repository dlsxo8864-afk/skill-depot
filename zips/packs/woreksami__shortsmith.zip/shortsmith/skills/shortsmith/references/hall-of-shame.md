# Hall of shame: every mistake, and the rule it created

Every entry below shipped, or nearly shipped, to a director who expected studio quality. Each one cost a re-render, a lost evening or the director's trust. The quotes are theirs, verbatim. Read all of this before every video. If you catch yourself about to do any of these, stop.

The pattern behind almost all of them is the same: **Claude judged the work by its own code and test stills instead of by what a viewer would see in the final file.** The fix is always the same too: look at the actual frames, from the actual saved scene, in motion, with sound, before calling it done.

---

## 1. "Animation, graphics, quality looks like a 2009 game man. What the heck"
*(diverging-diamond video, first cut)*

Everything below went wrong at once, and each item is now a rule.

- **"thin roads in the sky... the roads are floating without any real structure."** The terrain heights never saved to disk. The live editor looked right, but the batch render loaded flat ground 12 m below every road.
  **Rule:** always render in batch mode from the saved scene. After every build, reopen the scene from disk and check ground contact under every structure. Terrain `heightmap` changes need `SetHeights` *then* the TerrainData asset saved (`EditorUtility.SetDirty(terrainData)` + `AssetDatabase.SaveAssets()`).
- **"no real structure for anything."** The bridge was a flat strip, and the ramps were painted ribbons.
  **Rule:** real engineering anatomy. Footings, columns, pier caps, girders, deck thickness, abutments, wing walls, embankments, cut slopes, curbs, barriers, shoulders, signage. If it would exist in the real thing and the camera can see it, it exists.
- **"the building is not what I wanted."** A giant laser line swept across the screen. That's a cheap 2D wipe, not construction.
  **Rule:** build in the world. Piers rise, girders swing in on a crane path, the deck pours, asphalt rolls out along the road. Reveal shaders are for subtle "appearing" moments, never a substitute for construction.
- **"trees flicker in insane speeds."** Leaf sway ran on Unity's real clock while each frame took 0.5 to 20 s to render.
  **Rule:** no wind zones, no `Time.time`, nothing live. Everything is `f(t)`.
- **"everything is just ultra fast."** The video had 21 shots in 58 s, all with big whip moves, so the viewer never got to look at anything.
  **Rule:** pace means changing *information* often, not shaking the camera. Hold a readable composition long enough to land the line (about 1.2 s minimum), then cut.
- **"those same annoying sound effects."** Synthesized beeps and whooshes, and the same sample repeated back to back.
  **Rule:** real recordings first. Never place the same sample twice within about 3 s without varying pitch, length or layering.
- **Root cause:** the world was too big and too thin (4 km, 5 interchanges, 680 cars), code was written blind, and the full video was rendered from rough stills.
  **Rule:** use hero sets, show finished-quality stills, and pass every gate.

## 2. "what the hell is that production quality, the matchstick, the plane flying physics, the physics in general... the sky, NO!!! the fuel leaking from thin air"
*(SR-71 video, first cut)*

- **Sky:** it was a flat striped gradient with a brown smear, and the director called it "the sky, NO!!!".
  **Rule:** an altitude shot needs a real atmosphere: a curved horizon, deep blue overhead, a bright haze band, and a cloud sea far below with parallax at the true speed. See `unity/shaders/AltitudeSky.shader`.
- **Flight physics:** the jets were welded to the camera.
  **Rule:** the subject rides turbulence, `ShotKit.Fly`, and the camera ship floats and lags on its own, `ShotKit.ChaseFloat`. Climbs actually pitch. Tankers fly straight with their gear up. Disconnects sink away.
- **"fuel leaking from thin air":** drops spawned in mid-air, with no source.
  **Rule:** every particle has a physical origin. Raycast real seam points on the mesh. Each drop swells as a bead, necks, falls under gravity (`t = sqrt(2h/g)`), splashes and leaves a ring.
- **"the fuel should be a fuel color":** grey and orange blobs, and ghost rectangles.
  **Rule:** liquids are mirrors with a tint. Use the planar reflection (`FuelPool.shader` + `ShotKit.Reflect`), Fresnel, ripple normals and a thin-film sheen at the edges.
- **The match:** the flame floated beside the stick (the model was imported tilted), it was invisible (near clip 0.3 m), then over-exposed (the light was too close).
  **Rule:** align imported props by their real long axis (`ShotKit.AlignLongAxis`). Set the near clip for macros to 0.004 m. Size lights for the subject's scale.

## 3. "idk why you put the matchstick dropping into the fuel on some weird ass background"
The macro shot sat in front of a hangar HDRI full of parked planes.
**Rule:** macro and insert shots get a controlled set: a dark void or a bench with a black flag behind, environment reflections off, and the reflection probe on solid clear. The background is designed, never "whatever the HDRI had".

## 4. "the takeoff it was weird tail went thru the airstrip"
The jet rotated about its centre, so the tail dug into the runway.
**Rule:** aircraft rotate about the main-gear contact. Cap pitch by the tail clearance measured from the mesh (`ShotKit.MaxPitchAboutPivot`). Check every ground-contact moment frame by frame at the contact time.

## 5. "needs more action. the viewer retention will be horrible, not much going on boring"
Shots held one slow move for 3 to 6 s.
**Rule:** two or three sub-cuts inside any shot over about 2.5 s: wide, then tight, then the payoff. Things rip *past* the lens. Add whoosh-on-cut, burner-slam cuts and impact frames. Make a pacing preview with sound before the full render.

## 6. "the fuel like tears tracking ain't it it breaks everything"
The camera rode down with a falling drop, and it read as a dark frame with a streak.
**Rule:** don't make a tiny fast object the camera's subject in a dark frame. Frame a lit, readable composition, put the camera on the lit side (the sun behind the camera), and let the small thing happen inside the frame. Track a falling object only when it is big in frame for the whole move, with something readable behind it.

## 7. "I think this really looks weird and not nice"
**Rule:** when the director says "weird", hunt for the uncanny detail: wrong scale, wrong material, wrong motion, wrong background, something floating, something clipping. Fix *all* of them, not only the one that was named.

## 8. "the plane model is low quality, paint job weird... flickering on footage"
*(A-10)*

- **Low-res model:** its textures were capped at 1K, which went soft in close-ups.
  **Rule:** hero models need 4K PBR with a normal map. Check texture resolution *before* choosing a model. A swap later costs a re-fit and a full re-render.
- **"the lighting on some parts make the plane literally gray":** the model author had set the whole airframe to metallic = 1. Bare metal gets no diffuse light, so it mirrored a grey sky.
  **Rule:** audit every imported material. Painted surfaces are metallic 0 with smoothness 0.3 to 0.5. Only real bare metal is metallic (titanium about 0.75, chrome about 1).
- **Flicker:** caused by film grain, bokeh depth of field and 1× resolution.
  **Rule:** remove film grain, use Gaussian depth of field, render at 2× and downscale with lanczos. Measure flicker with `scripts/qa_video.py`.
- **Spinning barrels strobed:** 4 motion-blur samples aren't enough for 6 rev/s.
  **Rule:** set sub-samples per shot. Use 16 to 32 for anything that spins or falls fast.
- **The pilot was a standing model chopped at the chest:** "cut in half, floating".
  **Rule:** never butcher a model to fake a pose. Change the shot (for example, over the shoulder) so the missing part is never on camera.
- **"why is the A-10 in the banner, just because it's our first video doesn't mean the channel should be revolving around it."**
  **Rule:** channel branding is about the channel, never one episode.

- **The hidden cause of soft textures:** Sketchfab's default "glb" download is re-compressed to 1K textures. Models listed with 4K maps arrive at 1K.
  **Rule:** download the gltf zip (the `sketchfab.py` default) and check the real image sizes after every download.

## 9. "some cars literally phase through others"
*(roundabout)*
**Rule:** simulate every car pair across the whole timeline with real footprints and rotation, and delay any car that would clip. Only scripted collisions may touch. Also, "fix the farmland grass... it's a town mate": dress the world densely where the camera looks (houses, mailboxes, power poles, signs, lamps), not just the hero object.

## 9b. "why are those houses in the ditches? not a normal I-70 man"
*(runaway truck ramp)*
Buildings were scattered at random over whatever ground was left: in the creek hollow below the highway and on slopes.
**Rule:** settlements follow how places are really built. A level valley floor at road grade, reached by an exit and a frontage road, with a street grid. Commercial buildings go by the exit, and houses sit on lots facing streets, with driveways and yard trees. Flatten the terrain for the town first, then place on the grid. Never scatter buildings on raw terrain, and check every building for ground contact.

## 9c. "everything is lagging, the truck is shaking and the camera shaking rapidly, literally unwatchable"
*(runaway truck ramp, first pacing preview)*
Three causes stacked up:
1. **Paths snapped to whole metres.** The road and ramp positions were looked up from 1 m samples without interpolation, so the truck and every camera following it jumped 0.3–1 m at a time.
   **Rule:** every path lookup interpolates (fractional station → lerp between samples). Check it by placing an object at s and s+0.25: they must differ.
2. **Camera shake at 27 Hz.** That's faster than 30 or 60 fps can show, so it strobes into jitter.
   **Rule:** shake runs at 4–8 Hz, decays within half a second, stays under 0.4°, and only lands on real impacts.
3. **The truck bouncing at about 4 Hz** with large pitch.
   **Rule:** suspension motion is 1–2 Hz and a few centimetres.

Also make the pacing preview with motion blur on (3 sub-frames), or the preview itself reads as lag.

## 9d. "the road ... is buried inside a hill"
Terrain obeyed the highway's cut limit and the ramp's fill limit at the same time. Where they conflicted it averaged them, burying one road and floating the other on a slab with a wall.
**Rule:** diverge roads enough that their earthworks don't fight (the ramp now peels off at 10°). On a conflict, a road surface always wins over a slope. Then audit from the saved scene: the ground is never above any lane, and never more than a few cm below a road's edge.

## 9e. "are we gonna ignore that it's just flying?" / "car flipped here"
- **The truck floated.** It was placed level at one point on a 7% grade, so the front wheels hung in the air and the trailer's tail sank into the road.
  **Rule:** vehicles sit on their axles. Sample the ground at the front and rear axles (the tractor's pitch comes from those two points), pivot the trailer on the kingpin, and rest it on its own tandem. Check a low side angle on every slope.
- **A parked car leaned.** Imported cars were oriented by guessing from bounding boxes.
  **Rule:** use car prefabs that were built and checked once (nose on +z, wheels on y=0, real length), placed with the same two-point pitch.
- **A stray "exit ramp" cut across the highway.** It was a straight line between two points that ignored the curve between them.
  **Rule:** road geometry follows the road network. Never a lerp between two points. If a connection isn't designed properly, leave it out.
- **The town was identical houses dotted over a big lawn, with streets ending in grass.**
  **Rule:**
  - real blocks: houses back to back, about 70 m between streets;
  - perimeter streets, so every street ends at another street;
  - yard trees of more than one species;
  - if model variety is thin, keep the town small in frame and in haze.

## 9f. A purple haze over the town, and a vertical line through the sky
- **Purple haze:** the commercial building models (glTF) came with their own point and spot lights, neon emissive materials and see-through "light beam" meshes. In daylight they bloomed into a violet wash.
- **Milky first frame:** the first frame rendered after a scene load came out washed out and tinted, because ambient light, reflections and post-processing history had not settled.
- **Sky line:** a mipmapped panoramic HDRI showed a vertical seam where the panorama wraps.

**Rule:**
- strip every imported model on import: destroy its `Light` components, and destroy renderers named or textured spotlight, neon, beam or glow;
- replace emissive materials with non-emissive copies;
- after any scene load, render a few warm-up frames and discard them (`ShortFilm.WarmUp`);
- turn mipmaps off on panoramic sky textures.

## 9g. The render killed the GPU twice
Gravel spray drew every pebble with Unity's default sphere mesh, which has 515 vertices. At 3,500 pebbles that's 1.8 million vertices rebuilt every frame. The upload buffer overflowed (d3d12 error 8007000e), the device died, and the render crashed in the same shot even in a fresh process.

**Rule:**
- mesh particles get a low-poly mesh: under 30 vertices. A faceted chip also reads more like gravel than a sphere does.
- when a batch render dies, find the shot it died in (`shot N done` in the log) and the cause, before simply retrying it.

## 9h. "the trees sticking out dude look at the frames look at what you record"
Trees poked through roads, and a town street was broken. Claude was reviewing its own code, not the rendered frames.
**Rule:** after every build, render the review stills and actually look at each one at full size before saying anything works. Scattered props (trees, rocks, poles) get a keep-out mask along every road, ramp, lot and driveway, and a check that no prop touches a road surface.

## 9i. "and no sound effects at all?"
*(runaway truck ramp)* The pacing preview went to the director with only the voice. The sound pass had been quietly skipped.
**Rule:** sound is not optional and never comes "later". The pacing preview (Phase 7) always has the full effects mix in it. If you skip anything, say so up front, never wait to be caught.

## 9j. "9 FUCKING HOURS??? WHAT????" / "I NEED IT DONE IN 20 MINUTES AT MOST"
The full render was set to 4K, 60 fps with 16 sub-frames on the fast shots, and the time was only quoted after the director said "render now". The 1080×1920, 30 fps fast final (`-w 1080 -h 1920 -sub 2 -step 2`, then `assemble.py --hold`) took 30 minutes and looked fine on a phone.
**Rule:**
- time the render (10 frames per shot) at the pacing gate and quote the full-render time and file size **before** the director says go, with two options: fast final (1080/30, about 30 min) and full quality (4K/60 supersampled, hours);
- default to the fast final unless the director picks the long one;
- quote honest times. When 20 minutes is impossible, say "about 40" and why, never promise what you can't hit;
- Unity locks the project, so only one batch render runs at a time. You cannot parallelise by opening a second instance.

## 9k. "the video is still horrible no matter what, but it's whatever it was a lesson"
*(runaway truck ramp, final verdict)* Every gate was passed and every flagged bug was fixed, and the video still didn't work. The world was too ambitious for what can be built from code: a mountain interstate on a 7% grade, a cut slope, a valley town, an arrester bed and a sunset, all generated procedurally with a handful of downloaded models. Most of the time went on correctness (floating trucks, buried roads, houses in ditches, lag) instead of on looks. What was left was plain asphalt and grass in the build-up shots, bland construction, a hazy sunset, plain barrels and visible terrain steps. The director had to find the problems; Claude kept fixing them one at a time.
**Rule:**
- **choose the topic by what can be built at top quality.** Before pitching, ask: can the hero set come from real, high-quality assets (a ready environment, a real terrain heightmap, 4K PBR models)? A big landscape generated from code will read as a game prototype, however much it's polished;
- **the look-dev gate is a real gate.** If the hero frame is not something a viewer would stop scrolling for, change the concept, the set or the assets right there. Don't build 21 shots on top of a weak look and hope polish will save it;
- **one small hero set beats a big world.** Every extra location (town, valley, sunset) is another place for an uncanny detail to hide;
- **find the defects before the director does.** Review every still against `qa-checklist.md` as if you were the angriest viewer, and list them yourself.

## 10. The "Blinker" sound
A Wikimedia file named `Blinker.ogg` was a man *saying the word "Blinker"* (a German pronunciation recording). It looped under the narration for 6 s and shipped.
**Rule:** never trust a sound by its filename. Read the source page (pronunciation recordings, voice memos and music beds are common). Run speech detection on every recording and on the final effects stem: `qa_video.py --sfx`. Any detected words in the effects track fail QA.

## 11. Unity's MP4 encoder "pretty much fucked up the beginning of the vid"
Unity's built-in encoder wrote about 8 Mbps H.264, which smeared the detailed fields.
**Rule:** render a PNG sequence (or ProRes) and encode with ffmpeg: libx264, `-crf 14`, `-preset slow`, `yuv420p`, lanczos downscale.

## 12. A 25.8 GB log froze the director's PC
A warning was logged with a stack trace thousands of times per frame.
**Rule:** never log inside the per-frame path. Before a long render, check `Editor.log` size and free disk space. Clean old frame folders after delivery.

## 13. A render ran at 20 s per frame
A reveal made 340 cars recompute their routes every sub-frame.
**Rule:** time 10 frames of every shot before a full render. Cache anything that doesn't depend on `t`.

## 14. "You work completely different than in the last project"
After a context reset, Claude drifted: it wrote huge code blind and skipped reviews.
**Rule:** this skill *is* the method. After any context compaction, re-read this file and `pipeline.md`, then say which phase you're in.

## 15. Asking the director for things you could do yourself, or doing things that are theirs
- **Do yourself:** downloads, imports, material fixes, MCP config, ffmpeg, Python packages.
- **Theirs, so ask:** signing in (never type their password), accepting EULAs or Terms, purchases, recording the voiceover, posting.
- **Help them without blocking:** when Google sign-in fails in the built-in browser, offer Chrome. When Unity's menus confuse them, give exact clicks and offer to do it from code instead.
