# Voiceover timing

The voiceover sets the clock. Every cut, reveal, impact and readout lands on a word time measured from the MP3.

## Get word timestamps

```
python scripts/voice_timing.py Assets/Audio/<EP>/voiceover.mp3 --script script.md --out Assets/Audio/<EP>
```

It uses faster-whisper (`small.en`, int8 on CPU; about a minute) and writes:
- `words.json`: `[[start, end, "word"], ...]`
- `voice48k.wav`: a 48 kHz stereo copy, for mixing
- printed duration (2 decimals): **this is the video length**
- a word-by-word diff against the script: fix the script or ask for a re-record if words were dropped or changed
- the pauses longer than 0.18 s, the natural cut points
- a draft `timing.csv` that splits at sentence ends and pauses, targeting shots of 1.8 to 3.5 s

## Rules for cut points

- **Cut in the breath before a phrase,** about 0.05 to 0.1 s before the first word of the line that needs the new image. Never cut mid-word.
- **The shot shows what is being said.** The visual for "panels expand" is on screen *while* "expand" is spoken, not after.
- **Accent words inside the shot:** schedule reveals, impacts and number ticks on the stressed word (for example, the crash on "head-on" at 20.24 s, the reveal on "swap" at 22.94 s). Put these as comments in the shot code: `// "swap" 22.94`.
- **Sub-cuts:** a shot longer than about 2.5 s gets internal cuts (wide → tight → payoff). These stay inside the CSV row and are coded in the pose function.
- **The last shot runs exactly to the voiceover's end.** A frame count is `round(dur * fps)`; say so if it rounds (for example, 56.19 s at 30 fps comes out 56.20 s).

## timing.csv format

```
shot,start,end,voice,visual
1,0.00,4.94,"This spy plane leaked fuel all over the runway, by design.","Hook: dawn, low under the Blackbird; JP-7 drips from the belly seams into a slick; hard push-in"
```

- Times use 2 decimals; `end` of shot n equals `start` of shot n+1.
- The `visual` column is a real shot description that the code implements.
- `ShortFilm` reads this file. Cuts land on `round(start * fps)`.

## Overlays and readouts

Numbers that tick (Mach, °C, mm, a 26 → 14 counter, a place tag) are drawn at assembly time by `assemble.py` from an overlay JSON. Their timing follows the same word times. Each value is a function of t that eases between word-anchored times, so the number lands exactly as the word is spoken.
