# Channel profiles: works for any channel

Shortsmith is not tied to any channel or niche. Each user's channels live in a **channel profile**, which every phase reads: script tone, format, voice, pacing, branding and hashtags.

## Where profiles live

Add a `## Channels` section to the project's `CLAUDE.md` (create the file if needed), one block per channel:

```
## Channels
### <Channel name>
- Niche: <what the channel covers, e.g. everyday engineering / military hardware / space / cars / history>
- Format: <build-up explainer | paradox breakdown | story-driven | comparison | your own>
- Tone: <curious and satisfying | confident and cinematic | dry and funny | ...>
- Signature line or ending: <e.g. "congratulations, you've built a ___" | none>
- Voice: <TTS service + voice name, or "I record it myself">
- Look: <bright daytime, game-like realism | moody cinematic | clean studio | ...>
- Branding: <colours, logo motifs; branding is about the channel, never one episode>
- Hashtags: <3-5 channel-level tags>
- Never: <topics, styles or claims this channel avoids>
```

## First run (no profile yet)

Ask once, in a single AskUserQuestion: the channel name, its niche, and the tone (offer the formats below as options). Fill the rest with sensible defaults from the niche, write the profile to `CLAUDE.md`, show it to the user in three lines, and carry on. Don't block on a perfect profile. It gets refined as the user reacts to scripts and renders. Write every preference they express later ("less funny", "always end on the hero shot") into the profile.

## Proven formats (pick per channel, or mix)

- **Build-up explainer:** *problem → fix → new problem → better fix → payoff line.* Structures assemble on screen piece by piece. It suits infrastructure, inventions and everyday objects. Example ending: "...and congratulations, you've built a ___."
- **Paradox breakdown:** *shocking true claim → the machine or thing → the engineering reason → story or twist.* It suits vehicles, weapons, machines and science. Example hooks: "When this jet fires its gun, the whole plane slows down." / "This spy plane leaked fuel on the runway. On purpose."
- **Story-driven:** a real event told in beats (setup, crisis, the engineering or the decision that mattered, outcome), with the 3D showing what cameras never caught.
- **Comparison or scale:** two things side by side with real numbers, and a surprise at the end.

## Example profiles (from the videos this plugin was built on)

These are examples only. Never assume a user has these channels.

- **"Why We Built"**:
  - niche: everyday engineering;
  - format: build-up explainer;
  - tone: curious and satisfying;
  - signature: "congratulations, you've built a ___";
  - voice: a casual, light male TTS voice;
  - look: bright daytime farmland or suburbs.
- **"Hardpoint"**:
  - niche: military hardware;
  - format: paradox breakdown or story-driven;
  - tone: confident and cinematic, with strict accuracy;
  - voice: a confident, expressive male TTS voice;
  - look: dawn airbases, altitude, studio teardowns.
