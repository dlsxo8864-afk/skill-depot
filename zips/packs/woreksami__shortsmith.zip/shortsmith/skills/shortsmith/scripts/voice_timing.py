"""Voiceover -> word timestamps, script check, pauses and a draft timing.csv. The voiceover is the master clock.

usage: python voice_timing.py voiceover.mp3 --out Assets/Audio/EP [--script script.md] [--min 1.8] [--max 3.5] [--model small.en]
       python voice_timing.py --selftest
writes <out>/words.json ([[start, end, word], ...]), <out>/voice48k.wav, <out>/draft_timing.csv
"""
import argparse
import csv
import difflib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import tool, run  # noqa: E402

LEAD = .08  # cut this long before the first word of a new phrase (in the breath, never mid-word)
sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # Windows consoles default to cp1252



def norm_words(text):
    return re.findall(r"[a-z0-9']+", text.lower().replace("’", "'"))


def transcribe(path, model):
    from faster_whisper import WhisperModel
    m = WhisperModel(model, device="cpu", compute_type="int8")
    segs, info = m.transcribe(path, word_timestamps=True, language="en")
    words = [[round(w.start, 2), round(w.end, 2), w.word.strip()] for s in segs for w in s.words]
    return words, round(info.duration, 2)


def draft_cuts(words, dur, lo=1.8, hi=3.5):
    """Greedy shot boundaries: prefer sentence ends, then the longest pause, inside [lo, hi] seconds per shot."""
    cands = []  # (time, score)
    for i in range(1, len(words)):
        gap = words[i][0] - words[i - 1][1]
        sentence = words[i - 1][2][-1:] in ".?!"
        clause = words[i - 1][2][-1:] in ",;:"
        score = gap * 10 + (3 if sentence else 1 if clause else 0)
        if gap >= .12 or sentence or clause:
            cands.append((round(max(words[i - 1][1], words[i][0] - LEAD), 2), score))
    cuts, start = [0.0], 0.0
    while dur - start > hi:
        inside = [c for c in cands if lo <= c[0] - start <= hi]
        # a long phrase: run to its natural break (sub-cuts go inside the shot) rather than cut mid-phrase
        longer = [c for c in cands if hi < c[0] - start <= hi * 1.7]
        if inside:
            t = max(inside, key=lambda c: c[1])[0]
        elif longer:
            t = longer[0][0]
        else:  # no natural break: the word start nearest the max length
            t = min((round(w[0] - .02, 2) for w in words if w[0] - start > lo), key=lambda x: abs(x - start - hi), default=start + hi)
        if t <= start:
            break
        cuts.append(t)
        start = t
    return cuts + [dur]


def shots(words, cuts):
    out = []
    for k in range(len(cuts) - 1):
        a, b = cuts[k], cuts[k + 1]
        line = " ".join(w[2] for w in words if a <= (w[0] + w[1]) / 2 < b)
        out.append((k + 1, a, b, line))
    return out


def selftest():
    w = [[0.0, .3, "This"], [.32, .7, "plane"], [.72, 1.1, "leaked"], [1.12, 1.5, "fuel."], [1.9, 2.2, "By"], [2.22, 2.8, "design."],
         [3.3, 3.6, "The"], [3.62, 4.0, "SR-71"], [4.02, 4.6, "flew"], [4.62, 5.0, "fast,"], [5.3, 5.8, "really"], [5.82, 6.4, "fast."]]
    c = draft_cuts(w, 6.6, 1.5, 3.0)
    assert c[0] == 0 and c[-1] == 6.6 and all(b > a for a, b in zip(c, c[1:])), c
    assert all(1.5 <= b - a <= 3.0 * 1.7 for a, b in zip(c[:-2], c[1:-1])), c
    for t in c[1:-1]:  # never inside a word
        assert not any(x[0] < t < x[1] for x in w), (t, c)
    assert norm_words("It’s Mach 3.2!") == ["it's", "mach", "3", "2"]
    print("selftest ok", c)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("audio", nargs="?")
    ap.add_argument("--out")
    ap.add_argument("--script")
    ap.add_argument("--model", default="small.en")
    ap.add_argument("--min", type=float, default=1.8)
    ap.add_argument("--max", type=float, default=3.5)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.audio or not a.out:
        ap.error("audio and --out are required")
    os.makedirs(a.out, exist_ok=True)
    run([tool("ffmpeg"), "-y", "-v", "error", "-i", a.audio, "-ar", "48000", "-ac", "2", os.path.join(a.out, "voice48k.wav")])
    words, dur = transcribe(a.audio, a.model)
    json.dump(words, open(os.path.join(a.out, "words.json"), "w"))
    print(f"DURATION {dur:.2f} s  (= the video length)   {len(words)} words")

    if a.script:
        said = norm_words(" ".join(w[2] for w in words))
        # skip markdown headings and bold title lines: only the spoken script counts
        lines = [l for l in open(a.script, encoding="utf-8").read().splitlines() if not l.lstrip().startswith(("#", "**"))]
        want = norm_words(" ".join(lines))
        diffs = [op for op in difflib.SequenceMatcher(None, want, said, autojunk=False).get_opcodes() if op[0] != "equal"]
        if not diffs:
            print("script check: transcript matches the script word for word")
        for tag, i1, i2, j1, j2 in diffs:
            print(f"script check: {tag}: script '{' '.join(want[i1:i2])}' vs heard '{' '.join(said[j1:j2])}'")
        print("  (numbers and names often differ only in spelling; re-record only real wording changes)")

    print("\nPAUSES > 0.18 s (natural cut points):")
    for i in range(1, len(words)):
        g = words[i][0] - words[i - 1][1]
        if g > .18:
            print(f"  {words[i - 1][1]:6.2f} -> {words[i][0]:6.2f}  ({g:.2f} s)  ...{words[i - 1][2]} | {words[i][2]}...")

    cuts = draft_cuts(words, dur, a.min, a.max)
    rows = shots(words, cuts)
    path = os.path.join(a.out, "draft_timing.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        wr = csv.writer(f)
        wr.writerow(["shot", "start", "end", "voice", "visual"])
        for n, s, e, line in rows:
            wr.writerow([n, f"{s:.2f}", f"{e:.2f}", line, ""])
    print(f"\nDRAFT {len(rows)} shots -> {path}  (edit it into <EP>_timing.csv: merge/split for meaning, fill 'visual')")
    for n, s, e, line in rows:
        print(f"  {n:2d} {s:6.2f}-{e:6.2f} ({e - s:4.2f}s) {line}" + ("   <- long: plan 2-3 sub-cuts" if e - s > a.max else ""))
    print("\nWORDS " + " ".join(f"{w[0]}:{w[2]}" for w in words))


if __name__ == "__main__":
    main()
