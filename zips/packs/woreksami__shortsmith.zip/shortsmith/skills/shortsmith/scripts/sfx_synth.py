"""Synthesis library for the abstract sounds of a Short: reveal shimmers (build), rumbles, pops, plucks, whooshes,
relay clicks, blips, slowed impacts (stretch), small outdoor reverb. All 48 kHz stereo float arrays.
Use it for ABSTRACT sounds only. Engines, crashes, traffic and voices come from real recordings (see references/audio.md).
Imported by mix_audio.py ("synth" cues). Every function returns an (n, 2) array; place(buf, clip, at) mixes one in.
"""
import os
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 48000
DURATION = 60.0  # only used by the bed helpers below; mix_audio.py sets its own length
rng = np.random.default_rng(7)


def t_axis(d):
    return np.arange(int(d * SR)) / SR


def bandpass(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    return signal.sosfilt(sos, x)


def lowpass(x, f, order=2):
    return signal.sosfilt(signal.butter(order, f, btype="low", fs=SR, output="sos"), x)


def highpass(x, f, order=2):
    return signal.sosfilt(signal.butter(order, f, btype="high", fs=SR, output="sos"), x)


def env_adsr(n, a, r, curve=2.0):
    """attack/release fractions of the length"""
    e = np.ones(n)
    na, nr = max(1, int(n * a)), max(1, int(n * r))
    e[:na] = np.linspace(0, 1, na) ** curve
    e[-nr:] *= np.linspace(1, 0, nr) ** curve
    return e


def stereo(m, pan=0.0):
    l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    return np.stack([m * l, m * r], axis=1)


def ping(d, f, decay, pan=0.0):
    t = t_axis(d)
    return stereo(np.sin(2 * np.pi * f * t) * np.exp(-t / decay), pan)


def place(buf, clip, at):
    i = int(at * SR)
    j = min(len(buf), i + len(clip))
    if j > i:
        buf[i:j] += clip[: j - i]


def norm(x, peak=0.9):
    m = np.max(np.abs(x))
    return x * (peak / m) if m > 0 else x


# ---------------- builds: rising shimmer that lasts exactly as long as the reveal ----------------
def build(d, size=1.0, down=False, base=220.0, chord=((1.0, .35), (1.5, .22), (2.0, .18), (3.0, .08)), sparkle=(2200, 7000), band=350, pan_sweep=False, chime=(1318.5, 1975.5, 2637)):
    tail = 0.6
    n = int((d + tail) * SR)
    t = np.arange(n) / SR
    prog = np.clip(t / d, 0, 1)
    out = np.zeros((n, 2))
    # swept band of noise (the "front" moving through the structure)
    noise = rng.standard_normal(n)
    centre = band * (9 ** (1 - prog if down else prog))
    sweep = np.zeros(n)
    hop = 1024
    for k in range(0, n, hop):
        c = centre[min(k, n - 1)]
        seg = bandpass(noise[max(0, k - 2048):k + hop], c * 0.7, min(c * 1.4, SR / 2 - 100))[-min(hop, n - k):]
        sweep[k:k + len(seg)] = seg
    sweep *= env_adsr(n, 0.25, 0.35) * 0.5
    if pan_sweep:  # follows a front travelling across the frame (entrances)
        pan = np.clip(prog * 2 - 1, -1, 1)
        out += np.stack([sweep * np.cos((pan + 1) * np.pi / 4), sweep * np.sin((pan + 1) * np.pi / 4)], axis=1)
    else:
        out += stereo(sweep)
    # tonal riser: a soft chord gliding up (or down) an octave
    for ratio, amp in chord:
        f0 = base * ratio * size ** -0.3
        f = f0 * (2 ** (1 - prog if down else prog))
        ph = 2 * np.pi * np.cumsum(f) / SR
        out += stereo(np.sin(ph) * amp * env_adsr(n, .3, .3) * 0.6)
    # sparkles: grains get denser as the front advances (dissolve: sparser)
    count = int(40 * d * size)
    for _ in range(count):
        p = rng.random() ** (0.6 if not down else 1.6)
        at = p * d
        out[int(at * SR):] += 0  # keep indices simple
        g = ping(0.25, rng.uniform(*sparkle), rng.uniform(.03, .09), rng.uniform(-.8, .8)) * rng.uniform(.08, .2)
        place(out, g, at)
    # settle chime at the end of a build (not on dissolves)
    if not down:
        for f, a in zip(chime, (.25, .15, .1)):
            place(out, ping(1.2, f * size ** -0.2, .35, rng.uniform(-.3, .3)) * a, d - 0.05)
    # big builds get a low swell
    if size > 1.5:
        tt = np.arange(n) / SR
        boom = np.sin(2 * np.pi * (45 + 25 * prog) * tt) * env_adsr(n, .6, .25) * .55
        out += stereo(lowpass(boom, 200))
    return out


# ---------------- extra layers per reveal ----------------
def rumble(d):
    """low gravelly spread (asphalt pouring over the corners)"""
    n = int((d + .6) * SR)
    x = lowpass(rng.standard_normal(n), 260) * (1 + .6 * np.sin(2 * np.pi * 11 * np.arange(n) / SR))
    return stereo(x * env_adsr(n, .3, .45) * .9)


def thocks(d, count=7):
    """soft earthy pops as the island fills in"""
    out = np.zeros((int((d + .6) * SR), 2))
    t = t_axis(.18)
    for i in range(count):
        f = rng.uniform(140, 260)
        body = np.sin(2 * np.pi * f * t * (1 + .4 * np.exp(-t * 30))) * np.exp(-t / .045)
        place(out, stereo(body * .55, rng.uniform(-.5, .5)), d * (i + .3) / count)
    return out


def plucks(d, notes=(523.3, 659.3, 784.0, 1046.5)):
    """one bright pluck per splitter island, rising"""
    out = np.zeros((int((d + .8) * SR), 2))
    t = t_axis(.7)
    for i, f in enumerate(notes):
        tone = (np.sin(2 * np.pi * f * t) + .35 * np.sin(4 * np.pi * f * t)) * np.exp(-t / .16)
        place(out, stereo(tone * .45, -.6 + 1.2 * i / (len(notes) - 1)), d * (i + .4) / len(notes))
    return out


def layer(a, b):
    n = max(len(a), len(b))
    out = np.zeros((n, 2))
    out[:len(a)] += a
    out[:len(b)] += b
    return out


# ---------------- crash pieces ----------------
def metal_crunch(d=1.6, size=1.0):
    n = int(d * SR)
    t = np.arange(n) / SR
    out = np.zeros((n, 2))
    # thump
    f = 70 * np.exp(-t * 6) + 35
    thump = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .18)
    out += stereo(thump * 1.2)
    # broadband crunch
    burst = lowpass(rng.standard_normal(n), 4500) * np.exp(-t / .12)
    out += stereo(burst * .9)
    # bent-metal modes (inharmonic partials)
    for _ in range(36):
        fr = rng.uniform(180, 3200) / size
        dec = rng.uniform(.08, .9)
        out += ping(d, fr, dec, rng.uniform(-.6, .6)) * rng.uniform(.04, .14)
    # crumple: a few delayed secondary hits
    for _ in range(7):
        at = rng.uniform(.02, .25)
        place(out, stereo(lowpass(rng.standard_normal(int(.08 * SR)), 2500) * np.exp(-t_axis(.08) / .02), rng.uniform(-.5, .5)) * rng.uniform(.3, .6), at)
    return out


def glass(d=2.0, count=70):
    out = np.zeros((int(d * SR), 2))
    for _ in range(count):
        at = rng.exponential(.25)
        if at > d - .2:
            continue
        place(out, ping(.2, rng.uniform(3000, 9500), rng.uniform(.01, .05), rng.uniform(-.9, .9)) * rng.uniform(.05, .18), at)
    out += stereo(highpass(rng.standard_normal(len(out)), 5000) * np.exp(-t_axis(d) / .08) * .25)
    return out


def debris(d=2.5, count=40):
    out = np.zeros((int(d * SR), 2))
    for _ in range(count):
        at = .2 + rng.exponential(.5)
        if at > d - .1:
            continue
        click = bandpass(rng.standard_normal(int(.03 * SR)), 800, 5000) * np.exp(-t_axis(.03) / .006)
        place(out, stereo(click, rng.uniform(-.8, .8)) * rng.uniform(.1, .35), at)
    return out


def stretch(x, factor):
    """slow down by `factor` (>1) with pitch drop, like slowed-down film audio"""
    n = int(len(x) * factor)
    return np.stack([signal.resample(x[:, c], n) for c in range(2)], axis=1)


def whoosh(d=.7):
    n = int(d * SR)
    t = np.arange(n) / SR
    x = rng.standard_normal(n)
    out = np.zeros(n)
    hop = 512
    for k in range(0, n, hop):
        c = 3000 * (1 - t[k] / d) + 200
        seg = bandpass(x[max(0, k - 1024):k + hop], c * .6, c * 1.5)[-min(hop, n - k):]
        out[k:k + len(seg)] = seg
    return stereo(out * env_adsr(n, .5, .4) * .8)


def horn(d=.55):
    t = t_axis(d)
    tone = sum(signal.square(2 * np.pi * f * t, .4) for f in (392, 494)) * .5
    tone = lowpass(tone, 2200) * env_adsr(len(t), .05, .15, 1)
    return stereo(tone * .45, -.4)


def screech(d=1.75):
    n = int(d * SR)
    t = np.arange(n) / SR
    f = 1050 + 120 * np.sin(2 * np.pi * 7 * t) + 80 * rng.standard_normal(n).cumsum() / np.sqrt(np.arange(1, n + 1))
    ph = 2 * np.pi * np.cumsum(f) / SR
    tone = (np.sin(ph) + .4 * np.sin(2 * ph) + .2 * np.sin(3 * ph)) * .35
    rough = bandpass(rng.standard_normal(n), 700, 2600) * .5
    e = env_adsr(n, .08, .45, 1.5) * (1 - .5 * t / d)
    return stereo((tone + rough) * e)


def scrape(d=.45):
    n = int(d * SR)
    grit = bandpass(rng.standard_normal(n), 500, 3500) * (1 + 2 * (rng.random(n) > .985))
    out = stereo(grit * env_adsr(n, .15, .5) * .6, .2)
    t = t_axis(.4)
    thud = np.sin(2 * np.pi * (90 * np.exp(-t * 8) + 50) * t) * np.exp(-t / .1)
    place(out, stereo(thud * .8), .12)
    return out


def blip():
    t = t_axis(.12)
    return stereo(np.sin(2 * np.pi * 1400 * t) * np.exp(-t / .03) * .35 + np.sin(2 * np.pi * 2100 * t) * np.exp(-t / .02) * .15)


def relay_click():
    t = t_axis(.05)
    return stereo(bandpass(rng.standard_normal(len(t)), 1500, 6000) * np.exp(-t / .004) * .5, .3)


def pop():
    t = t_axis(.35)
    f = 900 * np.exp(-t * 18) + 220
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .07)
    out = stereo(body * .9)
    for _ in range(10):
        place(out, ping(.15, rng.uniform(2500, 6000), .03, rng.uniform(-.6, .6)) * .12, rng.uniform(.03, .15))
    return out


def water(d):
    n = int(d * SR)
    x = bandpass(rng.standard_normal(n), 900, 7000)
    am = lowpass(np.abs(rng.standard_normal(n)), 30) * 3 + .4
    drops = np.zeros(n)
    for _ in range(int(d * 25)):
        i = rng.integers(0, n - 2000)
        drops[i:i + 2000] += np.sin(2 * np.pi * rng.uniform(900, 2500) * t_axis(2000 / SR)) * np.exp(-t_axis(2000 / SR) / .006) * .3
    out = (x * am * .25 + drops) * env_adsr(n, .08, .05, 1)
    return np.stack([out, np.roll(out, 300)], axis=1)


def night(d):
    n = int(d * SR)
    out = np.zeros((n, 2))
    wind = lowpass(rng.standard_normal(n), 400) * .25 * env_adsr(n, .1, .1, 1)
    out += stereo(wind)
    for k, pan in ((0, -.6), (1, .5), (2, .1)):  # three crickets
        f = 4300 + 300 * k
        period = .55 + .12 * k
        tt = 0.1 * k
        while tt < d - .2:
            for p in range(3):  # trill: 3 pulses
                place(out, ping(.04, f, .008, pan) * .12, tt + p * .045)
            tt += period
    return out * env_adsr(n, .08, .08, 1)[:, None]


# ---------------- traffic, ambience, space ----------------
def passby(pan, v):
    """whoosh + engine note dropping as the car goes past (doppler), sweeping across the stereo field"""
    d = 1.4
    n = int(d * SR)
    t = np.arange(n) / SR
    env = np.exp(-((t - d / 2) / .22) ** 2)
    f = 95 * (1.12 - .24 / (1 + np.exp(-(t - d / 2) * 9)))  # high approaching, low leaving
    tone = (np.sin(2 * np.pi * np.cumsum(f) / SR) + .5 * np.sin(4 * np.pi * np.cumsum(f) / SR)) * .5
    air = bandpass(rng.standard_normal(n), 400, 3000) * .7
    mono = (tone + air) * env * min(1.0, v / 13)
    p = np.clip(np.linspace(pan - .7, pan + .7, n), -1, 1)
    return np.stack([mono * np.cos((p + 1) * np.pi / 4), mono * np.sin((p + 1) * np.pi / 4)], axis=1)


def day_ambience():
    """soft wind and the odd bird for the daytime shots (silent during the night crickets)"""
    n = int(DURATION * SR)
    t = np.arange(n) / SR
    wind = lowpass(rng.standard_normal(n), 500) * (.6 + .4 * np.sin(2 * np.pi * .07 * t + 1)) * .35
    out = stereo(wind)
    k = 0.4
    while k < DURATION - 1:
        if not (3.0 < k < 6.6):
            tt = t_axis(.18)
            f0 = rng.uniform(2800, 4200)
            chirp = np.sin(2 * np.pi * (f0 + 900 * np.sin(2 * np.pi * 14 * tt)) * tt) * np.exp(-tt / .05)
            for rep in range(rng.integers(1, 4)):
                place(out, stereo(chirp * .1, rng.uniform(-.8, .8)), k + rep * .16)
        k += rng.uniform(1.8, 4.5)
    night = (t > 3.25) & (t < 6.5)
    out[night] *= .15
    return out


def reverb(x, decay=.7, wet=.14):
    """small outdoor space: convolve with an exponentially decaying noise burst"""
    n = int(decay * SR)
    ir = rng.standard_normal(n) * np.exp(-np.arange(n) / SR / (decay / 5))
    ir = lowpass(ir, 6000)
    ir /= np.sqrt(np.sum(ir ** 2))
    tail = np.stack([signal.fftconvolve(x[:, c], ir * (1 + .1 * c))[:len(x)] for c in range(2)], axis=1)
    return x + tail * wet
