"""Poly Haven (CC0): search and download PBR texture sets and HDRIs. No account needed.

usage:
  python polyhaven.py search concrete [--type textures|hdris|models]
  python polyhaven.py tex <id> [--res 4k] --out Assets/PolyHaven      # diffuse, nor_gl, rough, ao, (arm), disp
  python polyhaven.py hdri <id> [--res 4k] --out Assets/PolyHaven     # .hdr
"""
import argparse
import json
import sys
import os
import urllib.request

UA = {"User-Agent": "shortsmith/1.0"}
MAPS = ["Diffuse", "nor_gl", "Rough", "AO", "Displacement", "arm"]
sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # Windows consoles default to cp1252



def get(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
        return json.load(r)


def fetch(url, dst):
    if os.path.exists(dst):
        print("have " + dst)
        return
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=600) as r, open(dst, "wb") as f:
        f.write(r.read())
    print("got  " + dst)


def search(q, t):
    assets = get(f"https://api.polyhaven.com/assets?t={t}")
    q = q.lower()
    hits = [(k, v) for k, v in assets.items() if q in k or q in v.get("name", "").lower() or any(q in x for x in v.get("tags", []) + v.get("categories", []))]
    for k, v in sorted(hits, key=lambda kv: -kv[1].get("download_count", 0))[:40]:
        print(f"{k:40s} {v.get('name', '')[:40]:40s} max {v.get('max_resolution', ['?'])[0]}  dl {v.get('download_count', 0)}")


def tex(id_, res, out):
    files = get(f"https://api.polyhaven.com/files/{id_}")
    os.makedirs(out, exist_ok=True)
    for m in MAPS:
        if m not in files:
            continue
        r = files[m].get(res) or files[m][sorted(files[m])[-1]]
        f = r.get("jpg") or r.get("png") or next(iter(r.values()))
        fetch(f["url"], os.path.join(out, os.path.basename(f["url"])))
    print(f'credit: "{id_}" textures, Poly Haven (CC0)')


def hdri(id_, res, out):
    files = get(f"https://api.polyhaven.com/files/{id_}")["hdri"]
    f = (files.get(res) or files[sorted(files)[-1]])["hdr"]
    os.makedirs(out, exist_ok=True)
    fetch(f["url"], os.path.join(out, os.path.basename(f["url"])))
    print(f'credit: "{id_}" HDRI, Poly Haven (CC0). Rotate it so its sun matches the scene\'s directional light.')


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    s = sp.add_parser("search"); s.add_argument("q"); s.add_argument("--type", default="textures")
    for n in ("tex", "hdri"):
        p = sp.add_parser(n); p.add_argument("id"); p.add_argument("--res", default="4k"); p.add_argument("--out", required=True)
    a = ap.parse_args()
    if a.cmd == "search":
        search(a.q, a.type)
    elif a.cmd == "tex":
        tex(a.id, a.res, a.out)
    else:
        hdri(a.id, a.res, a.out)


if __name__ == "__main__":
    main()
