"""Frames (f00000.png ..., frame k = time k/fps) + overlay readouts + audio -> 1080x1920 H.264 master.

usage: python assemble.py --frames Recordings/EPFrames --audio Assets/Audio/EP/mix.wav --dur 59.04 --out Recordings/EP_Short.mp4
                          [--fps 60] [--overlays Tools/ep_overlays.json] [--preview] [--crf 14]
       python assemble.py --selftest
Overlay JSON: a list of readouts, drawn in the bottom-centre safe zone, fading in/out:
  {"start": 4.94, "end": 9.98, "label": "SPEED",
   "value": {"fmt": "MACH {:.1f}", "from": 2.6, "to": 3.2, "t0": 5.2, "t1": 8.6},   # or "value": "80,000 FT"
   "color": {"from": [240,245,250], "to": [255,110,30], "t0": 10.6, "t1": 14.3}}  # or "color": [240,245,250]
Final mode refuses missing frames; --preview fills them black (and says how many).
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import tool  # noqa: E402


def font(size, bold=True):
    names = ["bahnschrift.ttf", "segoeuib.ttf" if bold else "segoeui.ttf", "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf", "Arial.ttf"]
    for d in [os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"), "/usr/share/fonts/truetype/dejavu", "/Library/Fonts"]:
        for f in names:
            p = os.path.join(d, f)
            if os.path.exists(p):
                return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def sm(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


def ease(t, a, b):
    return sm((t - a) / (b - a)) if b > a else float(t >= a)


def value_at(v, t):
    if isinstance(v, str):
        return v
    x = v["from"] + (v["to"] - v["from"]) * ease(t, v["t0"], v["t1"])
    return v["fmt"].format(x)


def color_at(c, t):
    if isinstance(c, list):
        return tuple(c)
    k = ease(t, c["t0"], c["t1"])
    return tuple(int(a + (b - a) * k) for a, b in zip(c["from"], c["to"]))


def draw(img, t, r):
    d = ImageDraw.Draw(img, "RGBA")
    W, H = img.size
    k = W / 1080
    a = sm((t - r["start"]) / .25) * sm((r["end"] - t) / .2)
    d.rounded_rectangle((W * .2, H * .72, W * .8, H * .82), radius=int(26 * k), fill=(8, 10, 14, int(165 * a)),
                        outline=(255, 255, 255, int(55 * a)), width=max(1, int(2 * k)))
    d.text((W * .5, H * .745), r.get("label", ""), font=font(int(34 * k), False), fill=(200, 210, 220, int(255 * a)), anchor="mm")
    d.text((W * .5, H * .79), value_at(r["value"], t), font=font(int(78 * k)), fill=color_at(r.get("color", [240, 245, 250], ), t) + (int(255 * a),), anchor="mm")


def probe(path):
    out = subprocess.run([tool("ffprobe"), "-v", "error", "-count_frames", "-select_streams", "v:0", "-show_entries",
                          "stream=width,height,nb_read_frames,r_frame_rate:format=duration", "-of", "json", path], capture_output=True, text=True, check=True)
    return json.loads(out.stdout)


def main(a):
    overlays = json.load(open(a.overlays, encoding="utf-8")) if a.overlays else []
    work = os.path.join(os.path.dirname(os.path.abspath(a.out)), "_assemble_work")
    shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work)
    n = round(a.dur * a.fps)
    first = next((os.path.join(a.frames, f) for f in sorted(os.listdir(a.frames)) if f.endswith(".png")), None)
    if not first:
        sys.exit("no frames in " + a.frames)
    size = Image.open(first).size
    black = os.path.join(work, "black.png")
    Image.new("RGB", size).save(black)
    missing = []
    src_fps = a.src_fps or a.fps
    for k in range(n):
        t = k / a.fps
        src = os.path.join(a.frames, "f%05d.png" % round(t * src_fps))
        if not os.path.exists(src) and (a.preview or a.hold):  # step renders (every Nth frame): hold the last one
            j = round(t * src_fps)
            while j > 0 and not os.path.exists(os.path.join(a.frames, "f%05d.png" % j)) and round(t * src_fps) - j < 4:
                j -= 1
            src = os.path.join(a.frames, "f%05d.png" % j)
        if not os.path.exists(src):
            missing.append(k)
            if not a.preview:
                continue
            src = black
        dst = os.path.join(work, "%05d.png" % k)
        r = next((r for r in overlays if r["start"] <= t < r["end"]), None)
        if r:
            img = Image.open(src).convert("RGB")
            draw(img, t, r)
            img.save(dst)
        else:
            try:
                os.link(src, dst)
            except OSError:
                shutil.copy(src, dst)
    if missing and not a.preview:
        sys.exit(f"{len(missing)} missing frames, first at frame {missing[0]} (t={missing[0] / a.fps:.3f}). Render them, or use --preview.")
    vf = "scale=540:960:flags=lanczos" if a.preview else "scale=1080:1920:flags=lanczos"
    args = [tool("ffmpeg"), "-y", "-v", "error", "-framerate", str(a.fps), "-i", os.path.join(work, "%05d.png")]
    if a.audio:
        args += ["-i", a.audio]
    args += ["-vf", vf, "-c:v", "libx264", "-profile:v", "high", "-preset", "slow" if not a.preview else "veryfast", "-crf", str(a.crf),
             "-pix_fmt", "yuv420p", "-r", str(a.fps)]
    if a.audio:
        # YouTube plays at about -14 LUFS: master there with -1.5 dBTP headroom so nothing clips after its re-encode
        # single-pass loudnorm overshoots its TP on sharp transients (gravel, brakes): a -2 dB limiter after it holds the ceiling
        args += ["-af", "loudnorm=I=-14:TP=-1.5:LRA=11,alimiter=limit=0.79:level=disabled", "-ar", "48000", "-c:a", "aac", "-b:a", "256k"]
    args += ["-t", "%.3f" % a.dur, a.out]
    subprocess.run(args, check=True)
    shutil.rmtree(work, ignore_errors=True)
    p = probe(a.out)
    s = p["streams"][0]
    print(f"{a.out}: {s['width']}x{s['height']} {s['r_frame_rate']} fps, {s['nb_read_frames']} frames, {float(p['format']['duration']):.3f} s, "
          f"{os.path.getsize(a.out) / 1e6:.0f} MB" + (f", {len(missing)} missing frames filled black" if missing else ""))
    if int(s["nb_read_frames"]) != n:
        print(f"WARNING: expected {n} frames")


def selftest():
    r = {"start": 0, "end": 2, "label": "SKIN", "value": {"fmt": "{:.0f} °C", "from": 20, "to": 316, "t0": .5, "t1": 1.5},
         "color": {"from": [255, 255, 255], "to": [255, 100, 0], "t0": .5, "t1": 1.5}}
    assert value_at(r["value"], 0) == "20 °C" and value_at(r["value"], 2) == "316 °C" and value_at("80,000 FT", 1) == "80,000 FT"
    assert color_at(r["color"], 2) == (255, 100, 0) and color_at([1, 2, 3], 0) == (1, 2, 3)
    img = Image.new("RGB", (1080, 1920))
    draw(img, 1.0, r)
    assert img.getbbox() is not None
    print("selftest ok")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames"); ap.add_argument("--audio"); ap.add_argument("--dur", type=float); ap.add_argument("--out")
    ap.add_argument("--fps", type=int, default=60); ap.add_argument("--src-fps", type=int, help="fps the frames were rendered at (default = --fps)")
    ap.add_argument("--overlays"); ap.add_argument("--preview", action="store_true"); ap.add_argument("--hold", action="store_true", help="final quality from a -step render: fill gaps with the nearest earlier frame"); ap.add_argument("--crf", type=int, default=14)
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()
    if args.selftest:
        selftest()
    else:
        if not (args.frames and args.dur and args.out):
            ap.error("--frames, --dur and --out are required")
        main(args)
