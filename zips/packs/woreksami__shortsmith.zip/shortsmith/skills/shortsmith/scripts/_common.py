"""Shared helpers: locate ffmpeg/ffprobe, decode audio to 48 kHz stereo float, read timing CSVs."""
import csv
import glob
import os
import shutil
import subprocess
import sys

import numpy as np

SR = 48000


def tool(name):
    """ffmpeg / ffprobe: $FFMPEG_DIR, PATH, then the winget install location (Windows)."""
    exe = name + (".exe" if os.name == "nt" else "")
    d = os.environ.get("FFMPEG_DIR")
    if d and os.path.exists(os.path.join(d, exe)):
        return os.path.join(d, exe)
    p = shutil.which(name)
    if p:
        return p
    hits = glob.glob(os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WinGet", "Packages", "Gyan.FFmpeg*", "*", "bin", exe))
    if hits:
        return sorted(hits)[-1]
    sys.exit(f"{name} not found: install ffmpeg (winget install Gyan.FFmpeg) or set FFMPEG_DIR")


def run(args, **kw):
    return subprocess.run(args, check=True, **kw)


def load_audio(path, start=0.0, dur=None):
    """any audio file -> (n, 2) float64 in [-1, 1] at 48 kHz"""
    args = [tool("ffmpeg"), "-v", "error", "-ss", str(start)] + (["-t", str(dur)] if dur else []) + \
           ["-i", path, "-f", "f32le", "-ac", "2", "-ar", str(SR), "-"]
    raw = subprocess.run(args, check=True, capture_output=True).stdout
    return np.frombuffer(raw, dtype=np.float32).reshape(-1, 2).astype(np.float64)


def read_timing(path):
    """<EP>_timing.csv -> [(shot, start, end, voice, visual)]"""
    with open(path, newline="", encoding="utf-8") as f:
        return [(int(r["shot"]), float(r["start"]), float(r["end"]), r.get("voice", ""), r.get("visual", "")) for r in csv.DictReader(f)]
