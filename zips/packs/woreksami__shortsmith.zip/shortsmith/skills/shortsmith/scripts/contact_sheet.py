"""Review sheet: every still in a folder (e.g. s01_02.50.png from ShortCli.Stills) in a labelled grid.

usage: python contact_sheet.py Captures/EP_review --out Captures/EP_sheet.jpg [--cols 4] [--width 360]
Send this to the director at the review gate, with an honest strong/weak list.
"""
import argparse
import os

from PIL import Image, ImageDraw, ImageFont


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder"); ap.add_argument("--out", required=True)
    ap.add_argument("--cols", type=int, default=4); ap.add_argument("--width", type=int, default=360)
    a = ap.parse_args()
    files = sorted(f for f in os.listdir(a.folder) if f.lower().endswith((".png", ".jpg")))
    if not files:
        raise SystemExit("no images in " + a.folder)
    first = Image.open(os.path.join(a.folder, files[0]))
    w = a.width
    h = round(w * first.height / first.width)
    lab = 30
    rows = (len(files) + a.cols - 1) // a.cols
    sheet = Image.new("RGB", (a.cols * w, rows * (h + lab)), (18, 18, 20))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype(os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", "bahnschrift.ttf"), 20)
    except OSError:
        font = ImageFont.load_default()
    for i, f in enumerate(files):
        x, y = (i % a.cols) * w, (i // a.cols) * (h + lab)
        sheet.paste(Image.open(os.path.join(a.folder, f)).convert("RGB").resize((w, h), Image.LANCZOS), (x, y + lab))
        d.text((x + 8, y + 5), os.path.splitext(f)[0], fill=(230, 230, 230), font=font)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    sheet.save(a.out, quality=92)
    print(f"{a.out}: {len(files)} frames")


if __name__ == "__main__":
    main()
