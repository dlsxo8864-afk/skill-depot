"""Voice + real recordings + synth accents -> mix.wav and sfx_stem.wav, exactly the video's length.

usage: python mix_audio.py Tools/<ep>_cues.json        python mix_audio.py --selftest
Cue file (paths relative to the cue file's folder unless absolute):
{
  "duration": 59.04,
  "voice": "../Assets/Audio/SR71/voiceover.mp3",
  "timing": "../SR71_timing.csv",            # whoosh on every cut (and every "subcuts" time)
  "subcuts": [1.24, 2.64, 7.1],
  "out_dir": "../Assets/Audio/SR71",
  "cut_whoosh": 0.22,                         # 0 = none
  "beds": [ {"file": "real/traffic.ogg", "offset": 8.0, "gain": 0.9,
             "levels": [[0, 3.16, 1.0], [3.16, 4.5, 0.45]],   # near/far per shot: far = quieter + low-passed
             "far_lowpass": 900} ],
  "cues": [ {"t": 20.31, "file": "real/crash.wav", "gain": 1.0, "pan": 0.0, "start": 0, "dur": 1.5,
             "stretch": 1.8, "pitch": 1.0},
            {"t": 45.28, "synth": "whoosh", "args": [0.9], "gain": 0.6} ],
  "speech_under_db": 9, "duck_db": 8, "reverb": 0.12
}
"""
import json
import os
import sys

import numpy as np
from scipy import signal
from scipy.io import wavfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import SR, load_audio, read_timing  # noqa: E402
import sfx_synth  # noqa: E402


def lowpass(x, f):
    b, a = signal.butter(2, f / (SR / 2))
    return signal.filtfilt(b, a, x, axis=0)


def place(buf, clip, at):
    i = int(round(at * SR))
    if i >= len(buf) or i + len(clip) <= 0:
        return
    a, b = max(0, -i), min(len(clip), len(buf) - i)
    buf[i + a:i + b] += clip[a:b]


def pan(x, p):
    l, r = np.cos((p + 1) * np.pi / 4), np.sin((p + 1) * np.pi / 4)
    return x * np.array([l, r]) * np.sqrt(2)


def speed(x, f):
    """resample by f (>1 = slower and lower, like slowed film audio)"""
    return np.stack([signal.resample(x[:, c], max(1, int(len(x) * f))) for c in range(2)], axis=1)


def level_curve(n, levels):
    t = np.arange(n) / SR
    lv = np.zeros(n)
    for a, b, v in levels:
        lv[(t >= a) & (t < b)] = v
    k = int(.25 * SR)  # 0.25 s crossfade at changes, no clicks at cuts
    return np.convolve(lv, np.ones(k) / k, mode="same")


def build(cfg, base):
    P = lambda p: p if os.path.isabs(p) else os.path.normpath(os.path.join(base, p))
    n = int(round(cfg["duration"] * SR))
    sfx = np.zeros((n, 2))
    for bed in cfg.get("beds", []):
        x = load_audio(P(bed["file"]), bed.get("offset", 0), cfg["duration"] + 1)
        if len(x) < n:  # loop short beds with a crossfade-free tile (beds should be long recordings)
            x = np.tile(x, (n // max(1, len(x)) + 1, 1))
        x = x[:n] / (np.abs(x).max() + 1e-9)
        lv = level_curve(n, bed.get("levels", [[0, cfg["duration"], 1.0]]))[:, None]
        far = lowpass(x, bed.get("far_lowpass", 900))
        sfx += (x * lv + far * (1 - lv) * .55) * bed.get("gain", 1.0)
    placed = {}
    warnings = []
    cues = list(cfg.get("cues", []))
    if cfg.get("cut_whoosh", 0) and cfg.get("timing"):
        cuts = [s for _, s, _, _, _ in read_timing(P(cfg["timing"]))][1:] + cfg.get("subcuts", [])
        for k, c in enumerate(sorted(cuts)):
            cues.append({"t": c - .28, "synth": "whoosh", "args": [.45 + .1 * (k % 3)], "gain": cfg["cut_whoosh"], "pan": [-.3, 0, .3][k % 3]})
    for c in cues:
        if "synth" in c:
            clip = getattr(sfx_synth, c["synth"])(*c.get("args", []))
            key = (c["synth"], tuple(c.get("args", [])))
        else:
            clip = load_audio(P(c["file"]), c.get("start", 0), c.get("dur"))
            clip = clip / (np.abs(clip).max() + 1e-9)
            fi, fo = min(len(clip) // 4, int(.01 * SR)), min(len(clip) // 3, int(c.get("fade_out", .12) * SR))
            if fi: clip[:fi] *= np.linspace(0, 1, fi)[:, None]  # trimmed clips click without fades
            if fo: clip[-fo:] *= np.linspace(1, 0, fo)[:, None]
            key =(c["file"], c.get("start", 0), c.get("stretch", 1), c.get("pitch", 1))
        if c.get("stretch", 1) != 1:
            clip = speed(clip, c["stretch"])
        if c.get("pitch", 1) != 1:
            clip = speed(clip, 1 / c["pitch"])
        if c.get("pan"):
            clip = pan(clip, c["pan"])
        if key[0] != "whoosh":
            for prev in placed.get(key, []):
                if abs(prev - c["t"]) < 3:
                    warnings.append(f"same sound {key[0]} at {prev:.2f} and {c['t']:.2f}: vary pitch/start/length or layer it")
        placed.setdefault(key, []).append(c["t"])
        place(sfx, clip * c.get("gain", 1.0), c["t"])
    if cfg.get("reverb", .12):
        sfx = sfx_synth.reverb(sfx, wet=cfg.get("reverb", .12))
    sfx = sfx / (np.abs(sfx).max() + 1e-9) * .89

    voice = np.zeros((n, 2))
    if cfg.get("voice"):
        v = load_audio(P(cfg["voice"]))[:n]
        voice[:len(v)] = v
    env = np.convolve(np.abs(voice).mean(axis=1), np.ones(int(SR / 6)) / int(SR / 6), mode="same")
    env = np.clip(env / (np.percentile(env, 95) + 1e-9), 0, 1)
    duck = 1 - (1 - 10 ** (-cfg.get("duck_db", 8) / 20)) * env
    speech = env > .15
    rms = lambda x: np.sqrt(np.mean(x ** 2)) + 1e-9
    k = 1.0
    if speech.any():
        k = rms(voice[speech]) / rms(sfx[np.abs(sfx).mean(axis=1) > 1e-3]) * 10 ** (-cfg.get("speech_under_db", 9) / 20)
    mix = voice + sfx * duck[:, None] * k
    mix = mix / (np.abs(mix).max() + 1e-9) * .93
    assert len(mix) == n and len(sfx) == n
    return mix, sfx, warnings


def write(path, x):
    wavfile.write(path, SR, (np.clip(x, -1, 1) * 32767).astype(np.int16))


def selftest():
    import tempfile
    d = tempfile.mkdtemp()
    t = np.arange(SR * 2) / SR
    write(os.path.join(d, "voice.wav"), np.stack([np.sin(2 * np.pi * 220 * t) * (t % 1 < .5)] * 2, axis=1) * .5)
    write(os.path.join(d, "hit.wav"), np.stack([np.random.default_rng(1).standard_normal(SR // 4) * .3] * 2, axis=1))
    open(os.path.join(d, "t.csv"), "w").write("shot,start,end,voice,visual\n1,0.00,1.00,a,b\n2,1.00,3.00,c,d\n")
    cfg = {"duration": 3.0, "voice": "voice.wav", "timing": "t.csv", "cut_whoosh": .2,
           "cues": [{"t": .5, "file": "hit.wav"}, {"t": 1.5, "file": "hit.wav"}, {"t": 2.0, "synth": "blip"}]}
    mix, sfx, warn = build(cfg, d)
    assert len(mix) == 3 * SR and np.abs(mix).max() <= .94
    assert any("hit.wav" in w for w in warn), warn
    print("selftest ok", warn)


def main():
    if "--selftest" in sys.argv:
        return selftest()
    cue_path = sys.argv[1]
    cfg = json.load(open(cue_path, encoding="utf-8"))
    base = os.path.dirname(os.path.abspath(cue_path))
    mix, sfx, warnings = build(cfg, base)
    out = cfg.get("out_dir", ".")
    out = out if os.path.isabs(out) else os.path.join(base, out)
    os.makedirs(out, exist_ok=True)
    write(os.path.join(out, "mix.wav"), mix)
    write(os.path.join(out, "sfx_stem.wav"), sfx)
    for w in warnings:
        print("WARNING " + w)
    print(f"mix.wav + sfx_stem.wav -> {out}  ({len(mix) / SR:.2f} s, {len(cfg.get('cues', []))} cues)")
    print("next: python qa_video.py --sfx " + os.path.join(out, "sfx_stem.wav") + "   (fails if any words are heard in the effects)")


if __name__ == "__main__":
    main()
