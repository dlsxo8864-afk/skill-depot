"""Sketchfab: search, triage and download models (glb) with automatic credits.

The API token comes ONLY from the SKETCHFAB_API_TOKEN environment variable. It is never printed, logged or put in a URL.
usage:
  python sketchfab.py search "sr-71 blackbird" [--license by|cc0|by-sa|any] [--max-faces 1500000] [--count 24]
  python sketchfab.py info <uid>
  python sketchfab.py download <uid> --out Assets/Models/name [--credits CREDITS.md] [--format gltf|glb|source]
  Default gltf: the "glb" download is re-compressed to 1K textures; the gltf zip keeps the full 2K-4K maps.
"""
import argparse
import json
import os
import sys
import urllib.parse
import urllib.request
import zipfile

API = "https://api.sketchfab.com/v3"
UA = {"User-Agent": "shortsmith/1.0"}
sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # Windows consoles default to cp1252



def get(url, token=None):
    h = dict(UA)
    if token:
        h["Authorization"] = "Token " + token
    with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=60) as r:
        return json.load(r)


def token():
    t = os.environ.get("SKETCHFAB_API_TOKEN", "").strip()
    if not t and os.name == "nt":  # saved after this shell started: read the user variable from the registry
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
                t = str(winreg.QueryValueEx(k, "SKETCHFAB_API_TOKEN")[0]).strip()
        except OSError:
            t = ""
    if not t:
        sys.exit("SKETCHFAB_API_TOKEN is not set. Ask the user for their token (sketchfab.com > Settings > Password & API) "
                 "and store it as a user environment variable; never echo it.")
    return t


def lic(m):
    l = m.get("license") or {}
    return l.get("label") or l.get("slug") or str(l) if isinstance(l, dict) else str(l)


def archives_line(m):
    out = []
    for k, a in (m.get("archives") or {}).items():
        if k not in ("glb", "gltf"):
            continue
        if isinstance(a, list):  # search results list one entry per texture flavour: report the sharpest
            a = max(a, key=lambda x: x.get("textureMaxResolution") or 0, default=None)
        if a:
            res = a.get("textureMaxResolution")
            out.append(f"{k}: {a.get('size', 0) / 1e6:.0f} MB, tex max {res or '?'} px x{a.get('textureCount', '?')}, {a.get('faceCount', '?')} faces")
    return " | ".join(out) or "no archive info"


def search(q, license_, max_faces, count):
    p = {"type": "models", "q": q, "downloadable": "true", "count": count, "sort_by": "-likeCount", "archives_flavours": "true"}
    if license_ != "any":
        p["license"] = license_
    res = get(API + "/search?" + urllib.parse.urlencode(p)).get("results", [])
    for m in res:
        faces = m.get("faceCount") or 0
        if max_faces and faces > max_faces:
            continue
        print(f"{m['uid']}  {m['name'][:60]!r} by {m['user']['username']}  [{lic(m)}]  {faces:,} faces  likes {m.get('likeCount', 0)}")
        print(f"    {m.get('viewerUrl', '')}   {archives_line(m)}")
    if not res:
        print("no results (try fewer words, or --license any)")


def info(uid):
    m = get(f"{API}/models/{uid}")
    if not m.get("archives"):  # the model endpoint omits archive details; the search endpoint has them
        p = {"type": "models", "q": m["name"], "downloadable": "true", "count": 24, "archives_flavours": "true"}
        hit = next((r for r in get(API + "/search?" + urllib.parse.urlencode(p)).get("results", []) if r["uid"] == uid), None)
        m["archives"] = (hit or {}).get("archives")
    print(f"{m['name']} by {m['user']['username']} ({m['user'].get('displayName', '')})")
    print(f"licence: {lic(m)}   faces {m.get('faceCount', 0):,}   vertices {m.get('vertexCount', 0):,}   animated: {bool(m.get('animationCount'))}")
    print(f"url: {m.get('viewerUrl')}")
    print("archives: " + archives_line(m))
    desc = (m.get("description") or "").strip().replace("\n", " ")
    print("description: " + desc[:600])
    print("tags: " + ", ".join(t.get("name", "") for t in m.get("tags", [])))
    print("TRIAGE: 4K textures + normal map for close-ups? sane metallic? real origin (not a game rip)? right variant/markings?")


def download(uid, out, credits, fmt):
    t = token()
    m = get(f"{API}/models/{uid}")
    links = get(f"{API}/models/{uid}/download", t)
    if fmt not in links:
        fmt = "gltf" if "gltf" in links else "glb"
    if fmt == "glb" and "gltf" in links and links["gltf"].get("size", 0) > links["glb"].get("size", 0) * 1.5:
        print(f"note: glb is {links['glb'].get('size', 0) / 1e6:.0f} MB vs gltf {links['gltf'].get('size', 0) / 1e6:.0f} MB, so the glb has downscaled textures")
    os.makedirs(out, exist_ok=True)
    name = "".join(c if c.isalnum() else "_" for c in m["name"]).strip("_")[:50] or uid
    dst = os.path.join(out, name + (".glb" if fmt == "glb" else ".zip"))
    req = urllib.request.Request(links[fmt]["url"], headers=UA)  # signed URL: never print it
    with urllib.request.urlopen(req, timeout=600) as r, open(dst, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
    if dst.endswith(".zip"):
        with zipfile.ZipFile(dst) as z:
            for n in z.namelist():  # no path traversal out of the target folder
                p = os.path.realpath(os.path.join(out, n))
                if not p.startswith(os.path.realpath(out)):
                    sys.exit("unsafe path in archive: " + n)
            z.extractall(out)
        os.remove(dst)
        dst = out
    print(f"downloaded -> {dst} ({fmt})")
    line = f'- "{m["name"]}" by {m["user"]["username"]} ({lic(m)}), {m.get("viewerUrl")} | used for: TODO\n'
    if credits:
        existing = open(credits, encoding="utf-8").read() if os.path.exists(credits) else "# Credits\n\n"
        if uid not in existing:
            open(credits, "w", encoding="utf-8").write(existing.rstrip() + "\n" + line)
            print("credit added to " + credits)
    else:
        print("CREDIT: " + line.strip())


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    s = sp.add_parser("search"); s.add_argument("q"); s.add_argument("--license", default="by"); s.add_argument("--max-faces", type=int, default=0); s.add_argument("--count", type=int, default=24)
    i = sp.add_parser("info"); i.add_argument("uid")
    d = sp.add_parser("download"); d.add_argument("uid"); d.add_argument("--out", required=True); d.add_argument("--credits"); d.add_argument("--format", default="gltf")
    a = ap.parse_args()
    if a.cmd == "search":
        search(a.q, a.license, a.max_faces, a.count)
    elif a.cmd == "info":
        info(a.uid)
    else:
        download(a.uid, a.out, a.credits, a.format)


if __name__ == "__main__":
    main()
