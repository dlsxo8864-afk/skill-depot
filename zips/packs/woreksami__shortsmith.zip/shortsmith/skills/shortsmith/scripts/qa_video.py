"""Automated QA gate for a finished Short (run before the director sees anything). Exit code 1 = failed.

usage: python qa_video.py Recordings/EP_Short.mp4 --dur 59.04 [--fps 60] [--sfx Assets/Audio/EP/sfx_stem.wav]
                          [--timing EP_timing.csv] [--sheet Captures/EP_sheet.jpg]
       python qa_video.py --sfx some_recording.ogg        (speech check only: "is this file really a blinker?")
Checks: size/fps/duration/frame count, black frames, dark stretches, frozen video, shimmer/flicker,
loudness (EBU R128), and speech hiding in the effects (the "Blinker" rule).
"""
import argparse
import json
import os
import re
import subprocess
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import tool, read_timing  # noqa: E402

W, H = 272, 480  # multiples of 8 (shimmer uses 8x8 blocks)
fails, notes = [], []
sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # Windows consoles default to cp1252



def fail(m):
    fails.append(m)
    print("FAIL  " + m)


def ok(m):
    print("ok    " + m)


def warn(m):
    notes.append(m)
    print("WARN  " + m)


def container(path, dur, fps):
    p = json.loads(subprocess.run([tool("ffprobe"), "-v", "error", "-count_frames", "-show_entries",
                                   "stream=codec_type,width,height,r_frame_rate,nb_read_frames:format=duration", "-of", "json", path],
                                  capture_output=True, text=True, check=True).stdout)
    v = next(s for s in p["streams"] if s["codec_type"] == "video")
    has_audio = any(s["codec_type"] == "audio" for s in p["streams"])
    num, den = map(int, v["r_frame_rate"].split("/"))
    rate, frames, d = num / den, int(v["nb_read_frames"]), float(p["format"]["duration"])
    (ok if (v["width"], v["height"]) == (1080, 1920) else fail)(f"resolution {v['width']}x{v['height']}")
    (ok if abs(rate - fps) < .01 else fail)(f"frame rate {rate:.2f}")
    if dur:
        (ok if abs(d - dur) <= 1.5 / fps else fail)(f"duration {d:.3f} s (voiceover {dur:.2f})")
        (ok if abs(frames - round(dur * fps)) <= 1 else fail)(f"frames {frames} (expected {round(dur * fps)})")
    (ok if has_audio else fail)("audio track present" if has_audio else "no audio track")
    return rate


def frames_stats(path, fps, timing, allow_dark=()):
    proc = subprocess.Popen([tool("ffmpeg"), "-v", "error", "-i", path, "-vf", f"scale={W}:{H},format=gray", "-f", "rawvideo", "-"], stdout=subprocess.PIPE)
    prev, k = None, 0
    mean, peak, shimmer, motion = [], [], [], []
    while True:
        b = proc.stdout.read(W * H)
        if len(b) < W * H:
            break
        f = np.frombuffer(b, np.uint8).astype(np.float32)
        f = f.reshape(H, W)
        mean.append(f.mean() / 255)
        peak.append(np.percentile(f, 99.5) / 255)
        if prev is not None:
            d = f - prev
            # low-frequency part of the change = real motion; what's left = per-pixel shimmer/flicker
            lo = d.reshape(H // 8, 8, W // 8, 8).mean(axis=(1, 3)).repeat(8, 0).repeat(8, 1)
            shimmer.append(float((np.abs(d - lo) > 10).mean()))
            motion.append(float(np.abs(d).mean()))
        else:
            shimmer.append(0.0); motion.append(99.0)
        prev = f
        k += 1
    proc.wait()
    mean, peak, shimmer, motion = map(np.array, (mean, peak, shimmer, motion))
    t = np.arange(len(mean)) / fps

    blacks = np.where(peak < .06)[0]  # nothing lit at all: a missing render or a black fill
    (fail if len(blacks) else ok)(f"black frames: {len(blacks)}" + (f" (first at {t[blacks[0]]:.2f} s)" if len(blacks) else ""))

    def runs(mask, min_len):
        out, start = [], None
        for i, m in enumerate(list(mask) + [False]):
            if m and start is None:
                start = i
            if not m and start is not None:
                if i - start >= min_len:
                    out.append((start / fps, i / fps))
                start = None
        return out

    dark = [(a, b) for a, b in runs(mean < .12, int(fps)) if not any(x <= a + .05 and b - .05 <= y for x, y in allow_dark)]
    (fail if dark else ok)("dark stretches > 1 s: " + (", ".join(f"{a:.1f}-{b:.1f}s" for a, b in dark) or "none")
                           + ("  (a dark frame reads as nothing on a phone: light the subject, or --allow-dark a deliberate void shot)" if dark else ""))
    frozen = runs(motion < .05, int(fps * .5))
    (fail if frozen else ok)("frozen > 0.5 s: " + (", ".join(f"{a:.1f}-{b:.1f}s" for a, b in frozen) or "none"))
    calm = motion < 4  # judge shimmer where the camera is not sweeping
    bad = runs(calm & (shimmer > .05), int(fps * .5))
    (warn if bad else ok)(f"flicker/shimmer (>5% of pixels on calm stretches): " + (", ".join(f"{a:.1f}-{b:.1f}s" for a, b in bad) or "none")
                          + f"  [median on calm frames {np.median(shimmer[calm]) * 100 if calm.any() else 0:.1f}%]"
                          + ("  -> step through those frames: real flicker, or fine detail under a slow move?" if bad else ""))
    if timing:
        for n, a, b, _, _ in read_timing(timing):
            m = (t >= a) & (t < b)
            if m.any():
                print(f"      shot {n:2d} {a:6.2f}-{b:6.2f}: brightness {mean[m].mean():.2f}  shimmer {np.median(shimmer[m]) * 100:4.1f}%  motion {np.median(motion[m]):5.1f}")


def loudness(path):
    err = subprocess.run([tool("ffmpeg"), "-v", "info", "-nostats", "-i", path, "-af", "ebur128=peak=true", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    i = re.findall(r"I:\s+(-?[\d.]+) LUFS", err)
    p = re.findall(r"Peak:\s+(-?[\d.]+) dBFS", err)
    if not i:
        return fail("loudness: could not measure")
    I, P = float(i[-1]), float(p[-1]) if p else 0.0
    (ok if -16.5 <= I <= -11.5 else fail)(f"loudness {I:.1f} LUFS (target -14)")
    (ok if P <= -0.9 else fail)(f"true peak {P:.1f} dBTP (max -1)")


def speech(path):
    from faster_whisper import WhisperModel
    m = WhisperModel("small.en", device="cpu", compute_type="int8")
    segs, _ = m.transcribe(path, vad_filter=True, language="en")
    heard = [(s.start, s.end, s.text.strip()) for s in segs if s.no_speech_prob < .5 and s.avg_logprob > -1.0 and re.search(r"[A-Za-z]{2,}", s.text)]
    if heard:
        for a, b, txt in heard:
            fail(f"speech in effects {os.path.basename(path)} {a:.2f}-{b:.2f}s: \"{txt}\"")
    else:
        ok(f"no speech in {os.path.basename(path)}")


def sheet(path, out, fps_sheet=2):
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    base = os.path.splitext(out)[0]
    subprocess.run([tool("ffmpeg"), "-y", "-v", "error", "-i", path, "-vf", f"fps={fps_sheet},scale=180:320,tile=12x5:padding=4",
                    base + "_%02d.jpg"], check=True)
    print(f"      contact sheets: {base}_01.jpg ... (2 fps, look at every tile)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("video", nargs="?")
    ap.add_argument("--dur", type=float); ap.add_argument("--fps", type=float, default=60)
    ap.add_argument("--sfx"); ap.add_argument("--timing"); ap.add_argument("--sheet")
    ap.add_argument("--allow-dark", help="deliberate dark/void stretches, e.g. 10-15.4,32.4-38.6 (say why in the report)")
    a = ap.parse_args()
    if a.video:
        container(a.video, a.dur, a.fps)
        allow = [tuple(map(float, r.split("-"))) for r in (a.allow_dark or "").split(",") if r]
        frames_stats(a.video, a.fps, a.timing, allow)
        loudness(a.video)
        if a.sheet:
            sheet(a.video, a.sheet)
    if a.sfx:
        speech(a.sfx)
    print(("\nQA FAILED: " + str(len(fails)) + " problem(s)") if fails else "\nQA PASSED (now watch it, with sound)"
          + (f"  [{len(notes)} warning(s) to look at]" if notes else ""))
    sys.exit(1 if fails else 0)
