# Unity drop-ins

Copy into the Unity project (URP, Unity 6):

| File | To | What |
|---|---|---|
| `ShortFilm.cs`, `ShotKit.cs`, `ShortCli.cs` | `Assets/Editor/` | offline renderer, motion/camera helpers, headless render/stills |
| `RevealController.cs` | `Assets/Scripts/` (runtime) | drives the reveal shader (needs `com.unity.splines`) |
| `shaders/*.shader`, `shaders/*.hlsl` | `Assets/Shaders/` (keep the .hlsl next to RevealLit) | film passes, plume, fuel mirror, altitude sky, heat, x-ray, reveal |
| `EpisodeShots.template.cs.txt` | `Assets/Editor/<EP>Shots.cs` (rename class) | the shape every episode's shot file follows |

The shaders are named `Shortsmith/...` and `Hidden/Shortsmith/FilmPasses`. `ShortFilm` looks up `Hidden/Shortsmith/FilmPasses` and `RevealController` looks up `Shortsmith/RevealLit`, so rename them together or not at all. If a project already has these shaders, don't copy them twice, because duplicate shader names conflict.

Compile check without opening the editor: see `references/unity-setup.md`, "Compile check without a licence". These files were compiled against Unity 6000.6 + URP with zero errors.
