"""Headless Blender clean-up pass for any downloaded or self-built model, before Unity.

usage: blender -b -P fix_asset.py -- --in model.glb --out out.glb [--length 32.7] [--axis y] [--decimate 0.5]
                                     [--bevel 0.004] [--merge 0.0001] [--smooth 30] [--join]
  --length   scale so the longest dimension is this many metres (real size: SR-71 32.7, A-10 16.3, car ~4.6)
  --axis     glTF forward axis is -Z/+Y by convention; this only reports which axis is the long one
  --decimate keep this fraction of faces (0.1-1). Skip for hero close-ups.
  --bevel    weighted-normal bevel width in metres on hard edges (the single biggest step away from "CG" edges)
  --join     join all meshes into one object (static props); default keeps parts separate (moving parts!)
Prints bounds, face counts and materials whose metallic looks wrong for paint (the A-10 grey-plane bug).
"""
import math
import sys

import bpy
from mathutils import Vector


def args():
    import argparse
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--length", type=float); ap.add_argument("--axis", default="y")
    ap.add_argument("--decimate", type=float, default=1.0); ap.add_argument("--bevel", type=float, default=0.0)
    ap.add_argument("--merge", type=float, default=0.0001); ap.add_argument("--smooth", type=float, default=30.0)
    ap.add_argument("--join", action="store_true")
    return ap.parse_args(argv)


def load(path):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    p = path.lower()
    if p.endswith((".glb", ".gltf")):
        bpy.ops.import_scene.gltf(filepath=path)
    elif p.endswith(".fbx"):
        bpy.ops.import_scene.fbx(filepath=path)
    elif p.endswith(".obj"):
        bpy.ops.wm.obj_import(filepath=path)
    else:
        sys.exit("unsupported: " + path)


def meshes():
    return [o for o in bpy.context.scene.objects if o.type == "MESH"]


def bounds(objs):
    lo = Vector((1e9, 1e9, 1e9)); hi = -lo
    for o in objs:
        for c in o.bound_box:
            w = o.matrix_world @ Vector(c)
            lo = Vector(map(min, lo, w)); hi = Vector(map(max, hi, w))
    return lo, hi


def faces(objs):
    return sum(len(o.data.polygons) for o in objs)


def main():
    a = args()
    load(a.inp)
    objs = meshes()
    if not objs:
        sys.exit("no meshes in " + a.inp)
    print(f"in : {len(objs)} meshes, {faces(objs):,} faces")
    # apply transforms (glTF imports often carry rotated/scaled empties)
    for o in bpy.context.scene.objects:
        o.select_set(o.type == "MESH")
    bpy.context.view_layer.objects.active = objs[0]
    for o in objs:  # unparent but keep world transform, so applying is safe
        if o.parent:
            m = o.matrix_world.copy(); o.parent = None; o.matrix_world = m
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    for o in list(bpy.context.scene.objects):
        if o.type == "EMPTY" and not o.children:
            bpy.data.objects.remove(o)
    if a.join and len(objs) > 1:
        bpy.ops.object.join()
        objs = meshes()
    for o in objs:
        bpy.context.view_layer.objects.active = o
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.remove_doubles(threshold=a.merge)
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode="OBJECT")
        o.data.polygons.foreach_set("use_smooth", [True] * len(o.data.polygons))
        try:  # Blender 4.1+: smooth-by-angle modifier; older: auto smooth
            bpy.ops.object.shade_smooth_by_angle(angle=math.radians(a.smooth))
        except Exception:
            if hasattr(o.data, "use_auto_smooth"):
                o.data.use_auto_smooth = True; o.data.auto_smooth_angle = math.radians(a.smooth)
        if a.decimate < 1.0:
            m = o.modifiers.new("Decimate", "DECIMATE"); m.ratio = a.decimate
        if a.bevel > 0:
            m = o.modifiers.new("Bevel", "BEVEL"); m.width = a.bevel; m.segments = 2; m.limit_method = "ANGLE"; m.harden_normals = True
            o.modifiers.new("WeightedNormal", "WEIGHTED_NORMAL").keep_sharp = True
        bpy.ops.object.modifier_apply(modifier="Decimate") if "Decimate" in o.modifiers else None
        for name in ("Bevel", "WeightedNormal"):
            if name in o.modifiers:
                bpy.ops.object.modifier_apply(modifier=name)
    lo, hi = bounds(objs)
    size = hi - lo
    if a.length:
        s = a.length / max(size)
        for o in objs:
            o.scale = (s, s, s)
        bpy.ops.object.select_all(action="SELECT")
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        lo, hi = bounds(objs); size = hi - lo
    # origin: bottom centre on the ground (y-up in Unity = z-up here)
    shift = Vector(((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, lo.z))
    for o in objs:
        o.location -= shift
    long_axis = "xyz"[list(size).index(max(size))]
    print(f"out: {len(objs)} meshes, {faces(objs):,} faces, size {size.x:.2f} x {size.y:.2f} x {size.z:.2f} m (Blender XYZ, Z up), long axis {long_axis}")
    for mat in bpy.data.materials:
        if not mat.use_nodes:
            continue
        b = next((n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
        if b and not b.inputs["Metallic"].is_linked and b.inputs["Metallic"].default_value > .5:
            print(f"CHECK material '{mat.name}': metallic {b.inputs['Metallic'].default_value:.2f}. Paint must be 0; only bare metal is metallic")
    bpy.ops.export_scene.gltf(filepath=a.out, export_format="GLB", export_apply=True, export_yup=True)
    print("wrote " + a.out)


main()
