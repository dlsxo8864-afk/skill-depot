---
name: shorts-new
description: Start a brand-new studio-grade 3D YouTube Short. Pitch one strong idea with a scroll-stopping hook, write the voiceover script, fact-check it, and set up the episode (timing, assets, Unity). Use when the user says "new video", "new idea", "next episode", "make a short about X", or "come up with a video for my channel".
---

# New Short

Load the main skill first: read `../shortsmith/SKILL.md` and `../shortsmith/references/hall-of-shame.md` (relative to this skill's base directory). Then run phases 0 and 1 of `../shortsmith/references/pipeline.md`:

1. **Preflight:** check Unity and MCP, ffmpeg, Python packages, disk space, and whether `SKETCHFAB_API_TOKEN` and Blender are available. Fix what you can yourself.
2. **Ask once, in a single AskUserQuestion, only what you can't decide:**
   - the channel, if it isn't clear. With no channel profile in the project's `CLAUDE.md`, set one up (`../shortsmith/references/channels.md`);
   - Blender asset work: yes or no;
   - the Sketchfab token, if missing;
   - any topic preference.
3. **Pitch one idea** using `../shortsmith/references/story-and-script.md`:
   - title equal to the hook;
   - why it stops the scroll;
   - the hook frame;
   - the script (140–165 words);
   - shot ideas;
   - a fact-check table with sources;
   - a check that a hero-quality model exists for the subject (search Sketchfab before pitching).
4. **GATE:** wait for script approval. Then give the director the exact recording notes (ElevenLabs, other TTS, or their own voice) and wait for the MP3.
5. **When the MP3 arrives,** run `../shortsmith/scripts/voice_timing.py`, write `<EP>_timing.csv`, update the project's `CLAUDE.md` with the episode brief, and continue with phase 3 of the pipeline.
