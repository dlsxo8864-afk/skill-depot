---
name: shorts-publish
description: Write the YouTube Shorts title, description, hashtags and licence-correct credits for a finished video, plus music suggestions and channel branding prompts (banner, profile picture, channel description). Use when the user asks for "title", "description", "credits", "hashtags", "music", "channel name", "banner" or "pfp".
---

# Publish copy

Read `../shortsmith/references/publish.md` (relative to this skill's base directory). Then:

1. Write the **title** from the video's hook: one pick and two alternates.
2. Write the **description** with the restated hook, the engineering in 2–4 sentences with key numbers, the twist, and 5–8 hashtags including #Shorts.
3. Build the **credits** from `CREDITS.md`, using **only the assets and sounds actually in the final cut**. Check the shot code and cue file, because dropped assets must not be credited. Use exact titles, authors and licences. CC BY and CC BY-SA lines are mandatory.
4. If downloads happened this video, remind the director to **rotate the Sketchfab token**. Never print it.
5. Branding requests cover the whole channel, never one episode.
