---
name: shorts-fix
description: Respond to the director's criticism of a Short ("this looks bad", "weird", "low quality", "boring", "needs more action", "2009 game", "what is that", "make it the absolute best") with root-cause diagnosis and fixes across the whole video, not just the named spot. Use whenever the user is unhappy with a render, a shot, the pacing, the sound or the realism.
---

# When the director says it's not good enough

They are right until the frames prove otherwise. Every past complaint traced back to a fixable decision, never to "the engine". Read `../shortsmith/references/hall-of-shame.md` now (relative to this skill's base directory). Your exact mistake may already be in it.

## Protocol

1. **Look before you talk.** Pull the frames they're reacting to from the *delivered file*: `ffmpeg -ss <t> -i <video> -frames:v 1`, plus a 2 fps contact sheet via `../shortsmith/scripts/qa_video.py --sheet`. Run the QA script, and read the shot code for those times.
2. **Diagnose concretely.** Make a numbered list of defects, each with its cause in the code, scene or asset. Use their words: "trees flicker" means the leaves run on a real clock; "floating roads" means the terrain didn't save.
3. **Widen the net.** Hunt the same class of defect in *every* shot: anything floating, clipping, dark, uncanny-material, wrong-scale, slow, repetitive in sound, or with an accidental background. Fix them all.
4. **Own it in one line** ("That was my mistake"), with no defending and no blaming the tools. If a real limit exists, give the director the option with its cost, and then recommend one.
5. **Fix at the root, in the shared code,** so the next episode inherits the fix. Add it to `hall-of-shame.md` if it's a new kind of mistake.
6. **Re-gate:** send finished-quality stills of the changed shots, then (if pacing changed) a preview with sound. Re-render only the affected shots and re-assemble. Run QA.
7. **Report:** what was wrong, what changed, what is still weak, and what you didn't verify.

## Common complaints, and what they really mean

| They say | Look for |
|---|---|
| "low quality", "2009 game" | low-res or no-normal textures, flat lighting with no AO or bounce, no structure detail, primitive stand-ins, a 1× render, synthetic sound |
| "weird", "not nice" | uncanny details: wrong scale, mirror-metal paint, something floating or clipping, an accidental background, wrong motion |
| "boring", "needs action", "retention" | holds over 3 s, no sub-cuts, nothing ripping past the lens, no whooshes or impacts, a slow hook |
| "too fast" | whip moves and constant camera shake; keep information changing but steady the camera |
| "physics" | welded-to-camera subjects, wrong pivots, things from thin air, no gravity, weightless crashes |
| "dark", "can't see" | subject on the unlit side, a void with a tiny subject, a dark subject on a dark background |
| "annoying sounds" | the same sample repeating, synthesized beeps, mislabeled recordings (the Blinker) |
