---
name: shorts-qa
description: Run the quality gate on a rendered Short before the director sees it. Checks duration, frames, black or dark frames, flicker, frozen video, loudness and speech leaking into the effects, then does a visual pass on a contact sheet. Use before any delivery, after any re-render, or when the user asks "is it good?", "check it" or "did you watch it?".
---

# QA gate

Read `../shortsmith/references/qa-checklist.md` (relative to this skill's base directory).

1. **Run the automated check:**
   ```
   python ../shortsmith/scripts/qa_video.py <video> --dur <voiceover length> --timing <EP>_timing.csv --sfx <sfx_stem.wav> --sheet Captures/<EP>_qa/sheet.jpg
   ```
   Use `--allow-dark a-b` only for a deliberate void shot, and name it in the report.
2. **Fix every FAIL.** Look at every WARN frame range yourself.
3. **Open every contact-sheet tile.** Walk the human-eye list in the checklist, shot by shot.
4. **Check that each sound cue sits on its word** in `words.json`, and that no same sample repeats within 3 s.
5. **Report** using the template in the checklist. Say exactly what you checked and what you didn't.
